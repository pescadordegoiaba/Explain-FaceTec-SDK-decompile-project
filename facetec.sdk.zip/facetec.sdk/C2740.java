package com.facetec.sdk;

/* JADX INFO: renamed from: com.facetec.sdk.剑灵, reason: contains not printable characters */
/* JADX INFO: loaded from: classes4.dex */
public final /* synthetic */ class C2740 {
}