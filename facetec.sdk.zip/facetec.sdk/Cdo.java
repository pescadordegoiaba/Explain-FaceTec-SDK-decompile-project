package com.facetec.sdk;

import android.content.Context;
import android.util.AttributeSet;
import android.widget.RelativeLayout;

/* JADX INFO: renamed from: com.facetec.sdk.do, reason: invalid class name */
/* JADX INFO: loaded from: classes4.dex */
class Cdo extends RelativeLayout {
    private int c;

    public Cdo(Context context) {
        super(context);
        this.c = b();
    }

    private static int b() {
        return (int) (dq.c().width * dm.c());
    }

    public void setXFraction(float f) {
        int i = this.c;
        setX(i > 0 ? f * i : -9999.0f);
    }

    public Cdo(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        this.c = b();
    }
}