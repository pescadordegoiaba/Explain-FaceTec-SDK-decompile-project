package com.facetec.sdk;

/* JADX INFO: renamed from: com.facetec.sdk.r, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes4.dex */
public enum EnumC39477r {
    FACE_SCAN,
    ID_SCAN_MATCH,
    ID_SCAN_ONLY
}