package com.facetec.sdk;

/* JADX INFO: loaded from: classes4.dex */
public enum FaceTecAuditTrailImagesToReturn {
    ONE,
    UP_TO_SIX
}