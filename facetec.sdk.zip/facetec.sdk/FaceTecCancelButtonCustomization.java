package com.facetec.sdk;

import android.graphics.Rect;
import androidx.annotation.NonNull;

/* JADX INFO: loaded from: classes4.dex */
public final class FaceTecCancelButtonCustomization {
    public int customImage = 0;

    @NonNull
    ButtonLocation b = ButtonLocation.TOP_LEFT;
    Rect e = null;
    public boolean hideForCameraPermissions = false;

    public enum ButtonLocation {
        TOP_LEFT("Top Left"),
        TOP_RIGHT("Top Right"),
        CUSTOM("Custom"),
        DISABLED("Disabled");

        private final String a;

        ButtonLocation(String str) {
            this.a = str;
        }

        @Override // java.lang.Enum
        @NonNull
        public final String toString() {
            return this.a;
        }
    }

    public final Rect getCustomLocation() {
        return this.e;
    }

    @NonNull
    public final ButtonLocation getLocation() {
        return this.b;
    }

    public final void setCustomLocation(Rect rect) {
        this.e = rect;
    }

    public final void setLocation(ButtonLocation buttonLocation) {
        if (buttonLocation == null) {
            buttonLocation = ButtonLocation.TOP_LEFT;
        }
        this.b = buttonLocation;
    }
}