package com.facetec.sdk;

import androidx.annotation.NonNull;
import java.util.HashMap;
import java.util.Map;

/* JADX INFO: loaded from: classes4.dex */
public final class FaceTecCustomization {
    public static int activityThemeId;
    public static String overrideResultScreenSuccessMessage;
    static HashMap<dr, String> p;
    static HashMap<cz, String> t;
    boolean a;
    boolean b;
    boolean c;
    boolean d;
    boolean e;
    public boolean enableOfficialIDPhoto;
    public int exitAnimationSuccessResourceID;
    public int exitAnimationUnsuccessResourceID;

    @NonNull
    FaceTecIDScanCustomization f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    @NonNull
    FaceTecResultScreenCustomization f95813g;

    @NonNull
    FaceTecOverlayCustomization h;

    @NonNull
    FaceTecGuidanceCustomization i;

    @NonNull
    FaceTecOCRConfirmationCustomization j;

    @NonNull
    FaceTecInitialLoadingAnimationCustomization k;

    @NonNull
    FaceTecFeedbackCustomization l;

    @NonNull
    FaceTecCancelButtonCustomization m;

    @NonNull
    FaceTecOvalCustomization n;

    @NonNull
    FaceTecFrameCustomization o;

    @NonNull
    FaceTecExitAnimationStyle q;
    Map<String, String> r;

    @NonNull
    FaceTecExitAnimationStyle s;
    public FaceTecSecurityWatermarkImage securityWatermarkImage;

    @NonNull
    public FaceTecVocalGuidanceCustomization vocalGuidanceCustomization;

    public FaceTecCustomization(Map<String, String> map) {
        this.d = true;
        this.c = false;
        this.b = false;
        this.a = false;
        this.e = false;
        this.enableOfficialIDPhoto = false;
        this.o = new FaceTecFrameCustomization();
        this.l = new FaceTecFeedbackCustomization();
        this.n = new FaceTecOvalCustomization();
        this.m = new FaceTecCancelButtonCustomization();
        this.i = new FaceTecGuidanceCustomization();
        this.f95813g = new FaceTecResultScreenCustomization();
        this.h = new FaceTecOverlayCustomization();
        this.f = new FaceTecIDScanCustomization();
        this.j = new FaceTecOCRConfirmationCustomization();
        this.k = new FaceTecInitialLoadingAnimationCustomization();
        this.q = FaceTecExitAnimationStyle.RIPPLE_OUT;
        this.s = FaceTecExitAnimationStyle.NONE;
        this.exitAnimationUnsuccessResourceID = -1;
        this.exitAnimationSuccessResourceID = -1;
        this.r = map;
        this.securityWatermarkImage = FaceTecSecurityWatermarkImage.FACETEC_ZOOM;
        this.vocalGuidanceCustomization = new FaceTecVocalGuidanceCustomization();
    }

    public static void setIDScanResultScreenMessageOverrides(@NonNull String str, @NonNull String str2, @NonNull String str3, @NonNull String str4, @NonNull String str5, @NonNull String str6, @NonNull String str7, @NonNull String str8, @NonNull String str9, @NonNull String str10, @NonNull String str11, @NonNull String str12, @NonNull String str13, @NonNull String str14, @NonNull String str15) {
        HashMap<cz, String> map = new HashMap<>();
        t = map;
        map.put(cz.IDSCAN_RETRY_FACE_DID_NOT_MATCH, str11);
        t.put(cz.IDSCAN_RETRY_ID_NOT_FULLY_VISIBLE, str12);
        t.put(cz.IDSCAN_RETRY_OCR_RESULTS_NOT_GOOD_ENOUGH, str13);
        t.put(cz.IDSCAN_RETRY_ID_TYPE_NOT_SUPPORTED, str14);
        t.put(cz.IDSCAN_SKIP_OR_ERROR_NFC, str15);
        t.put(cz.IDSCAN_SUCCESS_FRONT_SIDE, str);
        t.put(cz.IDSCAN_SUCCESS_FRONT_SIDE_BACK_NEXT, str2);
        t.put(cz.IDSCAN_SUCCESS_FRONT_SIDE_NFC_NEXT, str3);
        t.put(cz.IDSCAN_SUCCESS_BACK_SIDE, str4);
        t.put(cz.IDSCAN_SUCCESS_BACK_SIDE_NFC_NEXT, str5);
        t.put(cz.IDSCAN_SUCCESS_PASSPORT, str6);
        t.put(cz.IDSCAN_SUCCESS_PASSPORT_NFC_NEXT, str7);
        t.put(cz.IDSCAN_SUCCESS_USER_CONFIRMATION, str8);
        t.put(cz.IDSCAN_SUCCESS_NFC, str9);
        t.put(cz.IDSCAN_SUCCESS_ADDITIONAL_REVIEW, str10);
    }

    public static void setIDScanUploadMessageOverrides(String str, String str2, String str3, String str4, String str5, String str6, String str7, String str8, String str9, String str10, String str11, String str12, String str13, String str14, String str15, String str16, String str17, String str18, String str19, String str20) {
        HashMap<dr, String> map = new HashMap<>();
        p = map;
        map.put(dr.IDSCAN_FRONT_SIDE_UPLOAD_STARTED, str);
        p.put(dr.IDSCAN_FRONT_SIDE_STILL_UPLOADING, str2);
        p.put(dr.IDSCAN_FRONT_SIDE_UPLOAD_COMPLETE_AWAITING_RESPONSE, str3);
        p.put(dr.IDSCAN_FRONT_SIDE_UPLOAD_COMPLETE_AWAITING_PROCESSING, str4);
        p.put(dr.IDSCAN_BACK_SIDE_UPLOAD_STARTED, str5);
        p.put(dr.IDSCAN_BACK_SIDE_STILL_UPLOADING, str6);
        p.put(dr.IDSCAN_BACK_SIDE_UPLOAD_COMPLETE_AWAITING_RESPONSE, str7);
        p.put(dr.IDSCAN_BACK_SIDE_UPLOAD_COMPLETE_AWAITING_PROCESSING, str8);
        p.put(dr.IDSCAN_USER_CONFIRMED_INFO_UPLOAD_STARTED, str9);
        p.put(dr.IDSCAN_USER_CONFIRMED_INFO_STILL_UPLOADING, str10);
        p.put(dr.IDSCAN_USER_CONFIRMED_INFO_UPLOAD_COMPLETE_AWAITING_RESPONSE, str11);
        p.put(dr.IDSCAN_USER_CONFIRMED_INFO_UPLOAD_COMPLETE_AWAITING_PROCESSING, str12);
        p.put(dr.NFC_UPLOAD_STARTED, str13);
        p.put(dr.NFC_STILL_UPLOADING, str14);
        p.put(dr.NFC_UPLOAD_COMPLETE_AWAITING_RESPONSE, str15);
        p.put(dr.NFC_UPLOAD_COMPLETE_AWAITING_PROCESSING, str16);
        p.put(dr.SKIPPED_NFC_UPLOAD_STARTED, str17);
        p.put(dr.SKIPPED_NFC_STILL_UPLOADING, str18);
        p.put(dr.SKIPPED_NFC_UPLOAD_COMPLETE_AWAITING_RESPONSE, str19);
        p.put(dr.SKIPPED_NFC_UPLOAD_COMPLETE_AWAITING_PROCESSING, str20);
    }

    @NonNull
    public final FaceTecCancelButtonCustomization getCancelButtonCustomization() {
        return this.m;
    }

    @NonNull
    public final FaceTecExitAnimationStyle getExitAnimationSuccessCustom() {
        return this.q;
    }

    @NonNull
    public final FaceTecExitAnimationStyle getExitAnimationUnsuccessCustom() {
        return this.s;
    }

    @NonNull
    public final FaceTecFeedbackCustomization getFeedbackCustomization() {
        return this.l;
    }

    @NonNull
    public final FaceTecFrameCustomization getFrameCustomization() {
        return this.o;
    }

    @NonNull
    public final FaceTecGuidanceCustomization getGuidanceCustomization() {
        return this.i;
    }

    @NonNull
    public final FaceTecIDScanCustomization getIdScanCustomization() {
        return this.f;
    }

    @NonNull
    public final FaceTecInitialLoadingAnimationCustomization getInitialLoadingAnimationCustomization() {
        return this.k;
    }

    @NonNull
    public final FaceTecOCRConfirmationCustomization getOcrConfirmationCustomization() {
        return this.j;
    }

    @NonNull
    public final FaceTecOvalCustomization getOvalCustomization() {
        return this.n;
    }

    @NonNull
    public final FaceTecOverlayCustomization getOverlayCustomization() {
        return this.h;
    }

    @NonNull
    public final FaceTecResultScreenCustomization getResultScreenCustomization() {
        return this.f95813g;
    }

    public final void setCancelButtonCustomization(FaceTecCancelButtonCustomization faceTecCancelButtonCustomization) {
        if (faceTecCancelButtonCustomization == null) {
            faceTecCancelButtonCustomization = new FaceTecCancelButtonCustomization();
        }
        this.m = faceTecCancelButtonCustomization;
    }

    public final void setExitAnimationSuccessCustom(FaceTecExitAnimationStyle faceTecExitAnimationStyle) {
        if (faceTecExitAnimationStyle == null) {
            faceTecExitAnimationStyle = FaceTecExitAnimationStyle.CIRCLE_FADE;
        }
        this.q = faceTecExitAnimationStyle;
        FaceTecExitAnimationStyle faceTecExitAnimationStyle2 = FaceTecExitAnimationStyle.CIRCLE_FADE;
    }

    public final void setExitAnimationUnsuccessCustom(FaceTecExitAnimationStyle faceTecExitAnimationStyle) {
        if (faceTecExitAnimationStyle == null) {
            faceTecExitAnimationStyle = FaceTecExitAnimationStyle.CIRCLE_FADE;
        }
        this.s = faceTecExitAnimationStyle;
        FaceTecExitAnimationStyle faceTecExitAnimationStyle2 = FaceTecExitAnimationStyle.CIRCLE_FADE;
    }

    public final void setFeedbackCustomization(FaceTecFeedbackCustomization faceTecFeedbackCustomization) {
        if (faceTecFeedbackCustomization == null) {
            faceTecFeedbackCustomization = new FaceTecFeedbackCustomization();
        }
        this.l = faceTecFeedbackCustomization;
    }

    public final void setFrameCustomization(FaceTecFrameCustomization faceTecFrameCustomization) {
        if (faceTecFrameCustomization == null) {
            faceTecFrameCustomization = new FaceTecFrameCustomization();
        }
        this.o = faceTecFrameCustomization;
    }

    public final void setGuidanceCustomization(FaceTecGuidanceCustomization faceTecGuidanceCustomization) {
        if (faceTecGuidanceCustomization == null) {
            faceTecGuidanceCustomization = new FaceTecGuidanceCustomization();
        }
        this.i = faceTecGuidanceCustomization;
    }

    public final void setIdScanCustomization(FaceTecIDScanCustomization faceTecIDScanCustomization) {
        if (faceTecIDScanCustomization == null) {
            faceTecIDScanCustomization = new FaceTecIDScanCustomization();
        }
        this.f = faceTecIDScanCustomization;
    }

    public final void setInitialLoadingAnimationCustomization(FaceTecInitialLoadingAnimationCustomization faceTecInitialLoadingAnimationCustomization) {
        if (faceTecInitialLoadingAnimationCustomization == null) {
            faceTecInitialLoadingAnimationCustomization = new FaceTecInitialLoadingAnimationCustomization();
        }
        this.k = faceTecInitialLoadingAnimationCustomization;
    }

    public final void setOcrConfirmationCustomization(FaceTecOCRConfirmationCustomization faceTecOCRConfirmationCustomization) {
        if (faceTecOCRConfirmationCustomization == null) {
            faceTecOCRConfirmationCustomization = new FaceTecOCRConfirmationCustomization();
        }
        this.j = faceTecOCRConfirmationCustomization;
    }

    public final void setOvalCustomization(FaceTecOvalCustomization faceTecOvalCustomization) {
        if (faceTecOvalCustomization == null) {
            faceTecOvalCustomization = new FaceTecOvalCustomization();
        }
        this.n = faceTecOvalCustomization;
    }

    public final void setOverlayCustomization(FaceTecOverlayCustomization faceTecOverlayCustomization) {
        if (faceTecOverlayCustomization == null) {
            faceTecOverlayCustomization = new FaceTecOverlayCustomization();
        }
        this.h = faceTecOverlayCustomization;
    }

    public final void setResultScreenCustomization(FaceTecResultScreenCustomization faceTecResultScreenCustomization) {
        if (faceTecResultScreenCustomization == null) {
            faceTecResultScreenCustomization = new FaceTecResultScreenCustomization();
        }
        this.f95813g = faceTecResultScreenCustomization;
    }

    @Deprecated
    public static void setIDScanResultScreenMessageOverrides(@NonNull String str, @NonNull String str2, @NonNull String str3, @NonNull String str4, @NonNull String str5, @NonNull String str6, @NonNull String str7, @NonNull String str8, @NonNull String str9, @NonNull String str10, @NonNull String str11, @NonNull String str12, @NonNull String str13, @NonNull String str14) {
        bb.e(String.format("FaceTec SDK Deprecated Method Warning:  The %s function with these arguments is deprecated, please use the updated overload in order to customize all available strings.", "setIDScanResultScreenMessageOverrides"));
        HashMap<cz, String> map = new HashMap<>();
        t = map;
        map.put(cz.IDSCAN_RETRY_FACE_DID_NOT_MATCH, str10);
        t.put(cz.IDSCAN_RETRY_ID_NOT_FULLY_VISIBLE, str11);
        t.put(cz.IDSCAN_RETRY_OCR_RESULTS_NOT_GOOD_ENOUGH, str12);
        t.put(cz.IDSCAN_RETRY_ID_TYPE_NOT_SUPPORTED, str13);
        t.put(cz.IDSCAN_SKIP_OR_ERROR_NFC, str14);
        t.put(cz.IDSCAN_SUCCESS_FRONT_SIDE, str);
        t.put(cz.IDSCAN_SUCCESS_FRONT_SIDE_BACK_NEXT, str2);
        t.put(cz.IDSCAN_SUCCESS_FRONT_SIDE_NFC_NEXT, str3);
        t.put(cz.IDSCAN_SUCCESS_BACK_SIDE, str4);
        t.put(cz.IDSCAN_SUCCESS_BACK_SIDE_NFC_NEXT, str5);
        t.put(cz.IDSCAN_SUCCESS_PASSPORT, str6);
        t.put(cz.IDSCAN_SUCCESS_PASSPORT_NFC_NEXT, str7);
        t.put(cz.IDSCAN_SUCCESS_USER_CONFIRMATION, str8);
        t.put(cz.IDSCAN_SUCCESS_NFC, str9);
    }

    public FaceTecCustomization() {
        this(new HashMap());
    }
}