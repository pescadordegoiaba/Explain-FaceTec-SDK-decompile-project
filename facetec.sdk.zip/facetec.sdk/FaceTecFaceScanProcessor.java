package com.facetec.sdk;

/* JADX INFO: loaded from: classes4.dex */
public interface FaceTecFaceScanProcessor {
    void processSessionWhileFaceTecSDKWaits(FaceTecSessionResult faceTecSessionResult, FaceTecFaceScanResultCallback faceTecFaceScanResultCallback);
}