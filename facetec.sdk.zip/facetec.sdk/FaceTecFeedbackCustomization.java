package com.facetec.sdk;

import android.content.Context;
import android.graphics.Color;
import android.graphics.ImageFormat;
import android.graphics.Typeface;
import android.graphics.drawable.Drawable;
import android.os.SystemClock;
import android.telephony.cdma.CdmaCellLocation;
import android.text.TextUtils;
import android.util.TypedValue;
import android.view.KeyEvent;
import android.view.View;
import android.view.ViewConfiguration;
import android.widget.ExpandableListView;
import com.facetec.sdk.ov;
import com.incode.welcome_sdk.modules.SelfieScan;
import com.plaid.internal.EnumC41897g;
import java.io.ByteArrayInputStream;
import java.io.InputStream;
import java.lang.reflect.Method;
import net.sf.scuba.smartcards.ISO7816;
import org.bouncycastle.i18n.LocalizedMessage;

/* JADX INFO: loaded from: classes4.dex */
public final class FaceTecFeedbackCustomization {
    private static final byte[] $$a = null;
    private static final int $$b = 0;
    private static int $10;
    private static int $11;
    private static int a;
    private static long b;
    private static boolean c;
    private static boolean d;
    private static char[] e;
    public int backgroundColors = Color.parseColor("#417FB2");
    public int textColor = -1;
    public int cornerRadius = -1;
    public Typeface textFont = null;
    public boolean enablePulsatingText = true;
    public int elevation = 10;

    /* JADX WARN: Removed duplicated region for block: B:10:0x0023  */
    /* JADX WARN: Removed duplicated region for block: B:8:0x001d  */
    /* JADX WARN: Unsupported multi-entry loop pattern (BACK_EDGE: B:10:0x0023 -> B:11:0x0028). Please report as a decompilation issue!!! */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    private static java.lang.String $$c(short r6, short r7, int r8) {
        /*
            byte[] r0 = com.facetec.sdk.FaceTecFeedbackCustomization.$$a
            int r8 = 118 - r8
            int r6 = r6 * 2
            int r6 = r6 + 1
            int r7 = r7 * 2
            int r7 = r7 + 4
            byte[] r1 = new byte[r6]
            r2 = 0
            if (r0 != 0) goto L15
            r4 = r8
            r3 = r2
            r8 = r7
            goto L28
        L15:
            r3 = r2
        L16:
            byte r4 = (byte) r8
            r1[r3] = r4
            int r3 = r3 + 1
            if (r3 != r6) goto L23
            java.lang.String r6 = new java.lang.String
            r6.<init>(r1, r2)
            return r6
        L23:
            r4 = r0[r7]
            r5 = r8
            r8 = r7
            r7 = r5
        L28:
            int r7 = r7 + r4
            int r8 = r8 + 1
            r5 = r8
            r8 = r7
            r7 = r5
            goto L16
        */
        throw new UnsupportedOperationException("Method not decompiled: com.facetec.sdk.FaceTecFeedbackCustomization.$$c(short, short, int):java.lang.String");
    }

    static {
        init$0();
        $10 = 0;
        $11 = 1;
        e = new char[]{8630, 8633, 8648, 8628, 8601, 8599, 8581, 8602, 8604, 8683, 8631, 8592, 8597, 8576, 8594, 8671, 8634, 8608, 8614, 8596, 8665, 8598, 8583, 8579, 8635, 8606, 8600, 8603, 8636, 8593, 8582, 8605, 8577, 8588, 8611, 8640, 8667, 8652, 8607};
        a = 1071522059;
        d = true;
        c = true;
        b = 1010030050837827131L;
    }

    public static Object[] b(Context context, int i, int i2) {
        Class<String> cls = String.class;
        if (context != null) {
            try {
                Object[] objArr = new Object[1];
                f(null, null, 127 - (ViewConfiguration.getScrollBarFadeDuration() >> 16), "\u0093\u0092\u0083\u0081\u0090\u0086\u0089\u0088\u0087\u0086\u0085\u0084\u0083\u0091\u0090\u008f\u008e\u008d\u008c\u008b\u008a\u0086\u0089\u0088\u0087\u0086\u0085\u0084\u0083\u0082\u0081", objArr);
                try {
                    Object[] objArr2 = {(String) objArr[0]};
                    int i3 = -(ViewConfiguration.getZoomControlsTimeout() > 0L ? 1 : (ViewConfiguration.getZoomControlsTimeout() == 0L ? 0 : -1));
                    int iA = ov.d.a();
                    int i4 = i3 * 495;
                    int i5 = (i4 & (-447644)) + (i4 | (-447644));
                    int i6 = -(-((i3 | (-909)) * (-988)));
                    int i7 = ((i5 | i6) << 1) - (i5 ^ i6);
                    int i8 = ~i3;
                    int i9 = (i8 ^ 908) | (i8 & 908);
                    int i10 = ~iA;
                    int i11 = ((i9 & i10) | (i9 ^ i10)) * 494;
                    int i12 = ((i7 | i11) << 1) - (i7 ^ i11);
                    int i13 = ~i3;
                    int i14 = (~(i10 | 908)) | (~((i13 & (-909)) | (i13 ^ (-909))));
                    int i15 = ~((i3 & 908) | (i3 ^ 908));
                    int i16 = ((i15 & i14) | (i14 ^ i15)) * 494;
                    int i17 = ((i12 | i16) << 1) - (i16 ^ i12);
                    Object[] objArr3 = new Object[1];
                    g("\uefe6\uec66\ue8ec\ue54c\ue1d8︕諾\uf724\uf3b7\uf01a첐줜야쇺\ude38\udac8흉폃퀢곳ꤨꗞꉎ뻁몪띇뎧뀕貈襣薴舰麂鬄鞓鏽遡泷", i17, objArr3);
                    Object objNewInstance = Class.forName((String) objArr3[0]).getDeclaredConstructor(cls).newInstance(objArr2);
                    Object[] objArr4 = new Object[1];
                    f(null, null, 126 - (~(-View.resolveSize(0, 0))), "\u008f\u008e\u008d\u008c\u008b\u008a\u0086\u0089\u0088\u0087\u0086\u0085\u0084\u0083\u0082\u0081\u0090\u0086\u0089\u0088\u0087\u0086\u0085\u0084\u0083\u0091\u0090\u0093\u0092\u0083\u0081", objArr4);
                    try {
                        Object[] objArr5 = {(String) objArr4[0]};
                        int keyRepeatTimeout = ViewConfiguration.getKeyRepeatTimeout() >> 16;
                        int iA2 = ov.d.a();
                        int i18 = keyRepeatTimeout * (-515);
                        int i19 = (i18 ^ 468919) + ((i18 & 468919) << 1);
                        int i20 = ~(((-908) & iA2) | ((-908) ^ iA2));
                        int i21 = ~iA2;
                        int i22 = ~((i21 ^ keyRepeatTimeout) | (i21 & keyRepeatTimeout));
                        int i23 = (i20 ^ i22) | (i22 & i20);
                        int i24 = ~((i21 ^ 907) | (i21 & 907));
                        int i25 = -(-(((i23 & i24) | (i23 ^ i24)) * (-516)));
                        int i26 = (i19 & i25) + (i19 | i25);
                        int i27 = ~keyRepeatTimeout;
                        int i28 = ~((i27 & (-908)) | (i27 ^ (-908)) | iA2);
                        int i29 = ~keyRepeatTimeout;
                        int i30 = ~iA2;
                        int i31 = ~(i29 | i30 | 907);
                        int i32 = -(-(((i28 & i31) | (i28 ^ i31)) * 516));
                        int i33 = ((i26 | i32) << 1) - (i32 ^ i26);
                        int i34 = ~(i27 | 907);
                        int i35 = ~(i30 | 907);
                        int i36 = -(-(((i34 & i35) | (i34 ^ i35)) * 516));
                        int i37 = ((i33 | i36) << 1) - (i36 ^ i33);
                        Object[] objArr6 = new Object[1];
                        g("\uefe6\uec66\ue8ec\ue54c\ue1d8︕諾\uf724\uf3b7\uf01a첐줜야쇺\ude38\udac8흉폃퀢곳ꤨꗞꉎ뻁몪띇뎧뀕貈襣薴舰麂鬄鞓鏽遡泷", i37, objArr6);
                        Object objNewInstance2 = Class.forName((String) objArr6[0]).getDeclaredConstructor(cls).newInstance(objArr5);
                        try {
                            int i38 = -(ViewConfiguration.getGlobalActionKeyTimeout() > 0L ? 1 : (ViewConfiguration.getGlobalActionKeyTimeout() == 0L ? 0 : -1));
                            int i39 = (i38 * 960) - 245376;
                            int i40 = ~i;
                            int i41 = ~(((-129) ^ i40) | ((-129) & i40));
                            int i42 = ~(i38 | i);
                            int i43 = -(-(((i41 & i42) | (i41 ^ i42)) * 959));
                            int i44 = (((i39 | i43) << 1) - (i39 ^ i43)) - (-123711);
                            int i45 = ((~(i38 | i40)) | (~(((-129) ^ i) | ((-129) & i)))) * 959;
                            int i46 = (i44 & i45) + (i45 | i44);
                            Object[] objArr7 = new Object[1];
                            f(null, null, i46, "\u0097\u0098\u008c\u0097\u0085\u0088\u0081\u0095\u0097\u0085\u008c\u0097\u0085\u0088\u0096\u0095\u0086\u0089\u0088\u0087\u0086\u0085\u0094", objArr7);
                            Class<?> cls2 = Class.forName((String) objArr7[0]);
                            int scrollBarSize = ViewConfiguration.getScrollBarSize() >> 8;
                            int i47 = (scrollBarSize * (-317)) - (-14716427);
                            int i48 = ~scrollBarSize;
                            int i49 = (i40 ^ scrollBarSize) | (i40 & scrollBarSize);
                            int i50 = -(-(((~((i48 ^ (-46134)) | (i48 & (-46134)) | i)) | (~((i49 ^ 46133) | (i49 & 46133)))) * (-318)));
                            int i51 = (i47 & i50) + (i47 | i50);
                            int i52 = ~(((-46134) ^ scrollBarSize) | ((-46134) & scrollBarSize));
                            int i53 = ~((scrollBarSize ^ i) | (scrollBarSize & i));
                            int i54 = -(-(((i52 ^ i53) | (i52 & i53)) * (-318)));
                            int i55 = (i51 ^ i54) + ((i54 & i51) << 1);
                            int i56 = ~scrollBarSize;
                            int i57 = ((-46134) | (~((i56 & i) | (i56 ^ i)))) * EnumC41897g.SDK_ASSET_ILLUSTRATION_CONSUMER_REPORT_DARK_APPEARANCE_VALUE;
                            int i58 = (i55 ^ i57) + ((i57 & i55) << 1);
                            Object[] objArr8 = new Object[1];
                            g("\uefeb寜螒\uf343㼹櫦훙ʞ乃먴\ue5d3冪鶞쥜㔍惲겮", i58, objArr8);
                            Object objInvoke = cls2.getMethod((String) objArr8[0], null).invoke(context, null);
                            try {
                                Object[] objArr9 = new Object[1];
                                f(null, null, 126 - (~(-View.getDefaultSize(0, 0))), "\u0097\u0098\u008c\u0097\u0085\u0088\u0081\u0095\u0097\u0085\u008c\u0097\u0085\u0088\u0096\u0095\u0086\u0089\u0088\u0087\u0086\u0085\u0094", objArr9);
                                Class<?> cls3 = Class.forName((String) objArr9[0]);
                                int i59 = -TextUtils.lastIndexOf("", '0', 0);
                                Object[] objArr10 = new Object[1];
                                f(null, null, ((i59 | 126) << 1) - (i59 ^ 126), "\u008c\u009b\u0094\u0082\u008c\u008f\u0094\u009a\u0096\u0094\u0099\u0097\u008c\u008f", objArr10);
                                try {
                                    Object[] objArr11 = {cls3.getMethod((String) objArr10[0], null).invoke(context, null), 64};
                                    int i60 = -(TypedValue.complexToFraction(0, SelfieScan.RECOGNITION_FAIL_RESULT, SelfieScan.RECOGNITION_FAIL_RESULT) > SelfieScan.RECOGNITION_FAIL_RESULT ? 1 : (TypedValue.complexToFraction(0, SelfieScan.RECOGNITION_FAIL_RESULT, SelfieScan.RECOGNITION_FAIL_RESULT) == SelfieScan.RECOGNITION_FAIL_RESULT ? 0 : -1));
                                    int iA3 = ov.d.a();
                                    int i61 = (i60 * 628) - (-36418348);
                                    int i62 = (iA3 ^ 57991) | (iA3 & 57991);
                                    int i63 = ~i60;
                                    int i64 = -(-(((i62 ^ i63) | (i62 & i63)) * (-627)));
                                    int i65 = (i61 ^ i64) + ((i61 & i64) << 1);
                                    int i66 = ~(((-57992) & iA3) | ((-57992) ^ iA3));
                                    int i67 = ((i66 & i60) | (i60 ^ i66)) * (-627);
                                    int i68 = (i65 & i67) + (i65 | i67);
                                    int i69 = ~iA3;
                                    int i70 = ~((i69 ^ 57991) | (i69 & 57991));
                                    int i71 = ~((i60 ^ iA3) | (i60 & iA3));
                                    int i72 = (i68 - (~(((i71 & i70) | (i70 ^ i71)) * 627))) - 1;
                                    Object[] objArr12 = new Object[1];
                                    g("\uefed\u0d65⫦䡫旿荆ꃂ\ude13ﯗᥜ㚤吵熽漹貚ꩋ잌\ue516˜㿙嵡竼顽뗌퍃\uf0c6\uee77ௐ⤦䚦搹膰뼞", i72, objArr12);
                                    Class<?> cls4 = Class.forName((String) objArr12[0]);
                                    int i73 = -TextUtils.indexOf((CharSequence) "", '0', 0, 0);
                                    int iA4 = ov.d.a();
                                    int i74 = ~i73;
                                    int i75 = (i74 ^ 60538) | (i74 & 60538);
                                    int i76 = (((i73 * 71) - 4177122) - (~(((~i75) | (~((iA4 ^ 60538) | (iA4 & 60538)))) * (-140)))) - 1;
                                    int i77 = (i73 ^ 60538) | (i73 & 60538);
                                    int i78 = -(-((~((i77 & iA4) | (i77 ^ iA4))) * 70));
                                    int i79 = (i76 & i78) + (i78 | i76);
                                    int i80 = ~i75;
                                    int i81 = ~(((-60539) & i73) | ((-60539) ^ i73));
                                    int i82 = ((i80 & i81) | (i80 ^ i81) | (~((i73 ^ iA4) | (i73 & iA4)))) * 70;
                                    int i83 = (i79 ^ i82) + ((i82 & i79) << 1);
                                    Object[] objArr13 = new Object[1];
                                    g("\uefebΒ㜎⪭币熈攅颰谳뾺팋욫郞\ueddc", i83, objArr13);
                                    Object objInvoke2 = cls4.getMethod((String) objArr13[0], cls, Integer.TYPE).invoke(objInvoke, objArr11);
                                    int iResolveOpacity = Drawable.resolveOpacity(0, 0);
                                    Object[] objArr14 = new Object[1];
                                    f(null, null, ((iResolveOpacity | 127) << 1) - (iResolveOpacity ^ 127), "\u0088\u009e\u0085\u009d\u008c\u008f\u0094\u009a\u0096\u0094\u0099\u0095\u009b\u009c\u0095\u0097\u0085\u008c\u0097\u0085\u0088\u0096\u0095\u0086\u0089\u0088\u0087\u0086\u0085\u0094", objArr14);
                                    Class<?> cls5 = Class.forName((String) objArr14[0]);
                                    int i84 = (CdmaCellLocation.convertQuartSecToDecDegrees(0) > 0.0d ? 1 : (CdmaCellLocation.convertQuartSecToDecDegrees(0) == 0.0d ? 0 : -1));
                                    int i85 = i84 * (-519);
                                    int i86 = (i85 ^ 66167) + ((i85 & 66167) << 1);
                                    int i87 = ~i84;
                                    int i88 = -128;
                                    int i89 = (i87 & (-128)) | (i87 ^ (-128));
                                    int i90 = ~i;
                                    int i91 = ~((i89 & i90) | (i89 ^ i90));
                                    int i92 = ~((i ^ 127) | (i & 127));
                                    int i93 = ((i91 & i92) | (i91 ^ i92)) * 520;
                                    int i94 = ((i86 | i93) << 1) - (i93 ^ i86);
                                    int i95 = ~(((-128) ^ i40) | ((-128) & i40));
                                    int i96 = (i84 ^ i) | (i84 & i);
                                    int i97 = ~i96;
                                    int i98 = i94 + (((i95 & i97) | (i95 ^ i97)) * (-1040));
                                    int i99 = ~i84;
                                    int i100 = (~((i84 & (-128)) | ((-128) ^ i84))) | (~((i99 & i40) | (i99 ^ i40)));
                                    int i101 = ~i96;
                                    int i102 = ((i100 & i101) | (i100 ^ i101)) * 520;
                                    Object[] objArr15 = new Object[1];
                                    f(null, null, (i98 ^ i102) + ((i102 & i98) << 1), "\u009f\u008c\u0087\u008e\u0097\u0094\u0085\u008f\u0089\u009f", objArr15);
                                    Object[] objArr16 = (Object[]) cls5.getField((String) objArr15[0]).get(objInvoke2);
                                    int length = objArr16.length;
                                    int i103 = 0;
                                    while (i103 < length) {
                                        Object obj = objArr16[i103];
                                        int i104 = (ExpandableListView.getPackedPositionForGroup(0) > 0L ? 1 : (ExpandableListView.getPackedPositionForGroup(0) == 0L ? 0 : -1));
                                        int iA5 = ov.d.a();
                                        int i105 = i104 * (-574);
                                        int i106 = (i105 & (-1316182)) + (i105 | (-1316182));
                                        int i107 = ~i104;
                                        int i108 = ~iA5;
                                        int i109 = i88;
                                        int i110 = ~(i107 | i108);
                                        Object[] objArr17 = objArr16;
                                        int i111 = ~((-2294) | iA5);
                                        int i112 = i106 + (((i110 ^ i111) | (i111 & i110)) * 1150);
                                        int i113 = ~((-2294) | iA5);
                                        int i114 = ~((~iA5) | 2293);
                                        int i115 = i112 + (((i113 ^ i114) | (i113 & i114)) * (-575));
                                        int i116 = -(-(((~((i107 ^ iA5) | (i107 & iA5))) | (~(i104 | i108))) * 575));
                                        int i117 = (i115 ^ i116) + ((i115 & i116) << 1);
                                        Object[] objArr18 = new Object[1];
                                        g("\uefd4\ue757\ufe53\uf563챡", i117, objArr18);
                                        try {
                                            Object[] objArr19 = {(String) objArr18[0]};
                                            int i118 = -(-(SystemClock.elapsedRealtime() > 0L ? 1 : (SystemClock.elapsedRealtime() == 0L ? 0 : -1)));
                                            int i119 = ((i118 | 24228) << 1) - (i118 ^ 24228);
                                            Object[] objArr20 = new Object[1];
                                            g("\uefe6녈劰\uf402锶㛆\ud837祬\u1ad1밳嶗ﻯ聉⇃싩摂֮꜍䠸\ue9f0謍ⱷ췖漶を퇸猭ᒊ뗴坘\uf89c騖㭏\udcbd縉άꃁ", i119, objArr20);
                                            Class<?> cls6 = Class.forName((String) objArr20[0]);
                                            Object[] objArr21 = new Object[1];
                                            f(null, null, 127 - TextUtils.indexOf("", ""), "\u008c\u0096\u0085\u0094\u0097\u009f\u0085\u009d\u0097\u008c\u008f", objArr21);
                                            Object objInvoke3 = cls6.getMethod((String) objArr21[0], cls).invoke(null, objArr19);
                                            try {
                                                int i120 = -(-(SystemClock.uptimeMillis() > 0L ? 1 : (SystemClock.uptimeMillis() == 0L ? 0 : -1)));
                                                Object[] objArr22 = new Object[1];
                                                f(null, null, ((i120 | 126) << 1) - (i120 ^ 126), "\u008c\u0087\u008e\u0097\u0094\u0085\u008f\u0089\u0093\u0095\u009b\u009c\u0095\u0097\u0085\u008c\u0097\u0085\u0088\u0096\u0095\u0086\u0089\u0088\u0087\u0086\u0085\u0094", objArr22);
                                                Class<?> cls7 = Class.forName((String) objArr22[0]);
                                                Object[] objArr23 = new Object[1];
                                                g("\ueff8ම⭸䣤暔萮ꇯ\udf83ﴦ\u1ade㡻", 57946 - TextUtils.lastIndexOf("", '0', 0), objArr23);
                                                try {
                                                    Object[] objArr24 = {new ByteArrayInputStream((byte[]) cls7.getMethod((String) objArr23[0], null).invoke(obj, null))};
                                                    int i121 = -TextUtils.lastIndexOf("", '0');
                                                    int i122 = i121 * (-129);
                                                    int i123 = (i122 & 3173868) + (i122 | 3173868);
                                                    int i124 = ((-24229) & i40) | ((-24229) ^ i40);
                                                    int i125 = (~((i124 & i121) | (i124 ^ i121))) * 130;
                                                    int i126 = ((i123 | i125) << 1) - (i125 ^ i123);
                                                    int i127 = ((-24229) & i121) | ((-24229) ^ i121);
                                                    int i128 = (i126 - (~(-(-((~i127) * (-260)))))) - 1;
                                                    int i129 = ~i121;
                                                    int i130 = i128 + (((~((i129 & 24228) | (i129 ^ 24228))) | (~((i127 & i) | (i127 ^ i)))) * 130);
                                                    Object[] objArr25 = new Object[1];
                                                    g("\uefe6녈劰\uf402锶㛆\ud837祬\u1ad1밳嶗ﻯ聉⇃싩摂֮꜍䠸\ue9f0謍ⱷ췖漶を퇸猭ᒊ뗴坘\uf89c騖㭏\udcbd縉άꃁ", i130, objArr25);
                                                    Class<?> cls8 = Class.forName((String) objArr25[0]);
                                                    int i131 = -ImageFormat.getBitsPerPixel(0);
                                                    int iA6 = ov.d.a();
                                                    int i132 = i131 * 85;
                                                    int i133 = ((i132 | 370770) << 1) - (i132 ^ 370770);
                                                    int i134 = ~i131;
                                                    int i135 = ~(i134 | (-4363));
                                                    int i136 = length;
                                                    int i137 = ~iA6;
                                                    int i138 = ~((i134 ^ i137) | (i134 & i137));
                                                    int i139 = (i135 ^ i138) | (i135 & i138);
                                                    int i140 = ~(((-4363) ^ i137) | ((-4363) & i137));
                                                    int i141 = (i139 ^ i140) | (i139 & i140);
                                                    Class<String> cls9 = cls;
                                                    int i142 = (i131 & 4362) | (i131 ^ 4362);
                                                    int i143 = ~((i142 ^ iA6) | (i142 & iA6));
                                                    int i144 = -(-(((i141 ^ i143) | (i141 & i143)) * (-84)));
                                                    int i145 = (i133 ^ i144) + ((i133 & i144) << 1);
                                                    int i146 = ~(((-4363) ^ iA6) | ((-4363) & iA6));
                                                    int i147 = (i131 ^ i146) | (i131 & i146);
                                                    int i148 = ~iA6;
                                                    int i149 = ~((i148 & 4362) | (i148 ^ 4362));
                                                    int i150 = ((i147 & i149) | (i147 ^ i149)) * (-84);
                                                    int i151 = (i145 ^ i150) + ((i150 & i145) << 1);
                                                    int i152 = ((~((i137 & 4362) | (i137 ^ 4362))) | (~i142)) * 84;
                                                    int i153 = ((i151 | i152) << 1) - (i152 ^ i151);
                                                    Object[] objArr26 = new Object[1];
                                                    g("\uefebﻢ췴\udcc8ꯒ뫚覺颤林皊䖐咁⍡㉥ſ၊｝칃\udd2f", i153, objArr26);
                                                    Object objInvoke4 = cls8.getMethod((String) objArr26[0], InputStream.class).invoke(objInvoke3, objArr24);
                                                    try {
                                                        int i154 = -(ViewConfiguration.getEdgeSlop() >> 16);
                                                        Object[] objArr27 = new Object[1];
                                                        f(null, null, (i154 & 127) + (i154 | 127), "\u008c\u0097\u0094\u0096\u0089\u009e\u0089\u0097\u0087\u008c\u0081¦¥¤£\u0095\u0097\u0087\u008c\u0096\u0095¢\u0097\u0089\u0087\u008e\u0096\u008c\u009f\u0095\u0094¡\u0094 ", objArr27);
                                                        Class<?> cls10 = Class.forName((String) objArr27[0]);
                                                        int iKeyCodeFromString = KeyEvent.keyCodeFromString("");
                                                        int iA7 = ov.d.a();
                                                        int i155 = iKeyCodeFromString * (-563);
                                                        int i156 = (i155 ^ 71755) + ((i155 & 71755) << 1);
                                                        int i157 = ~iKeyCodeFromString;
                                                        int i158 = ~iA7;
                                                        int i159 = (~((i109 ^ i158) | (i109 & i158))) | i157;
                                                        int i160 = ~(iA7 | 127);
                                                        int i161 = -(-(((i159 & i160) | (i159 ^ i160)) * (-564)));
                                                        int i162 = ((i156 | i161) << 1) - (i156 ^ i161);
                                                        int i163 = ~iKeyCodeFromString;
                                                        int i164 = (~(iA7 | (i163 & 127) | (i163 ^ 127))) * 1128;
                                                        int i165 = ((i162 | i164) << 1) - (i164 ^ i162);
                                                        int i166 = ~((i157 ^ i158) | (i157 & i158));
                                                        int i167 = ~(iKeyCodeFromString | 127);
                                                        int i168 = (i165 - (~(((i167 & i166) | (i166 ^ i167)) * 564))) - 1;
                                                        Object[] objArr28 = new Object[1];
                                                        f(null, null, i168, "§\u0094\u009c\u0089\u0096\u0085\u0089\u0087\u0099¥¥¤£\u0097\u0096\u008c \u008d\u008e\u0093\u0097\u008c\u008f", objArr28);
                                                        if (!objNewInstance.equals(cls10.getMethod((String) objArr28[0], null).invoke(objInvoke4, null))) {
                                                            try {
                                                                int i169 = -TextUtils.getOffsetAfter("", 0);
                                                                int iA8 = ov.d.a();
                                                                int i170 = i169 * 1773;
                                                                int i171 = (i170 & (-112395)) + (i170 | (-112395));
                                                                int i172 = ~i169;
                                                                int i173 = ~((i172 & (-128)) | (i172 ^ (-128)));
                                                                int i174 = ~((i109 ^ iA8) | (i109 & iA8));
                                                                int i175 = (i173 & i174) | (i173 ^ i174);
                                                                int i176 = ~iA8;
                                                                int i177 = (i176 & i169) | (i176 ^ i169);
                                                                int i178 = ~((i177 ^ 127) | (i177 & 127));
                                                                int i179 = (i171 - (~(-(-(((i175 & i178) | (i175 ^ i178)) * 886))))) - 1;
                                                                int i180 = ~iA8;
                                                                int i181 = ~((i180 & 127) | (i180 ^ 127));
                                                                int i182 = ((i169 & i181) | (i169 ^ i181)) * (-1772);
                                                                Object[] objArr29 = new Object[1];
                                                                f(null, null, ((((i179 | i182) << 1) - (i182 ^ i179)) - (~((~i177) * 886))) - 1, "\u008c\u0097\u0094\u0096\u0089\u009e\u0089\u0097\u0087\u008c\u0081¦¥¤£\u0095\u0097\u0087\u008c\u0096\u0095¢\u0097\u0089\u0087\u008e\u0096\u008c\u009f\u0095\u0094¡\u0094 ", objArr29);
                                                                Class<?> cls11 = Class.forName((String) objArr29[0]);
                                                                int keyRepeatDelay = ViewConfiguration.getKeyRepeatDelay() >> 16;
                                                                int i183 = (keyRepeatDelay * (-1975)) + 125603;
                                                                int i184 = ~keyRepeatDelay;
                                                                int i185 = ~((i184 & 127) | (i184 ^ 127));
                                                                int i186 = -(-(((i185 & i) | (i ^ i185)) * 988));
                                                                int i187 = ((i183 | i186) << 1) - (i183 ^ i186);
                                                                int i188 = ~((i109 ^ keyRepeatDelay) | (i109 & keyRepeatDelay));
                                                                int i189 = ~((i40 ^ keyRepeatDelay) | (i40 & keyRepeatDelay));
                                                                int i190 = i187 + (((i188 & i189) | (i188 ^ i189)) * (-1976));
                                                                int i191 = ~keyRepeatDelay;
                                                                int i192 = ~((i191 & 127) | (i191 ^ 127));
                                                                int i193 = ~((i109 ^ i) | (i109 & i));
                                                                int i194 = -(-(((i192 & i193) | (i192 ^ i193) | (~((i40 ^ 127) | (i40 & 127)))) * 988));
                                                                Object[] objArr30 = new Object[1];
                                                                f(null, null, ((i190 | i194) << 1) - (i194 ^ i190), "§\u0094\u009c\u0089\u0096\u0085\u0089\u0087\u0099¥¥¤£\u0097\u0096\u008c \u008d\u008e\u0093\u0097\u008c\u008f", objArr30);
                                                                if (!objNewInstance2.equals(cls11.getMethod((String) objArr30[0], null).invoke(objInvoke4, null))) {
                                                                    i103++;
                                                                    i88 = i109;
                                                                    length = i136;
                                                                    objArr16 = objArr17;
                                                                    cls = cls9;
                                                                }
                                                            } catch (Throwable th) {
                                                                Throwable cause = th.getCause();
                                                                if (cause != null) {
                                                                    throw cause;
                                                                }
                                                                throw th;
                                                            }
                                                        }
                                                        Object[] objArr31 = {null, new int[1], new int[]{(i & (-2)) | (i40 & 1)}, new int[]{i}};
                                                        int i195 = ~((int) SystemClock.uptimeMillis());
                                                        int i196 = -(-((((-1740947663) + (((~((-445728001) | i195)) | 624959494) * (-828))) + ((i195 | (-445728001)) * (-828))) - 304403440));
                                                        int i197 = ((i2 | i196) << 1) - (i2 ^ i196);
                                                        int i198 = i197 << 13;
                                                        int i199 = (i198 & (~i197)) | ((~i198) & i197);
                                                        int i200 = i199 >>> 17;
                                                        int i201 = ((~i199) & i200) | ((~i200) & i199);
                                                        int i202 = i201 << 5;
                                                        ((int[]) objArr31[1])[0] = (i201 | i202) & (~(i201 & i202));
                                                        return objArr31;
                                                    } catch (Throwable th2) {
                                                        Throwable cause2 = th2.getCause();
                                                        if (cause2 != null) {
                                                            throw cause2;
                                                        }
                                                        throw th2;
                                                    }
                                                } catch (Throwable th3) {
                                                    Throwable cause3 = th3.getCause();
                                                    if (cause3 != null) {
                                                        throw cause3;
                                                    }
                                                    throw th3;
                                                }
                                            } catch (Throwable th4) {
                                                Throwable cause4 = th4.getCause();
                                                if (cause4 != null) {
                                                    throw cause4;
                                                }
                                                throw th4;
                                            }
                                        } catch (Throwable th5) {
                                            Throwable cause5 = th5.getCause();
                                            if (cause5 != null) {
                                                throw cause5;
                                            }
                                            throw th5;
                                        }
                                    }
                                } catch (Throwable th6) {
                                    Throwable cause6 = th6.getCause();
                                    if (cause6 != null) {
                                        throw cause6;
                                    }
                                    throw th6;
                                }
                            } catch (Throwable th7) {
                                Throwable cause7 = th7.getCause();
                                if (cause7 != null) {
                                    throw cause7;
                                }
                                throw th7;
                            }
                        } catch (Throwable th8) {
                            Throwable cause8 = th8.getCause();
                            if (cause8 != null) {
                                throw cause8;
                            }
                            throw th8;
                        }
                    } catch (Throwable th9) {
                        Throwable cause9 = th9.getCause();
                        if (cause9 != null) {
                            throw cause9;
                        }
                        throw th9;
                    }
                } catch (Throwable th10) {
                    Throwable cause10 = th10.getCause();
                    if (cause10 != null) {
                        throw cause10;
                    }
                    throw th10;
                }
            } catch (Throwable unused) {
            }
        }
        int[] iArr = new int[1];
        Object[] objArr32 = {null, iArr, new int[]{i}, new int[]{i}};
        int i203 = ~(594308293 | i);
        int i204 = ~i;
        int i205 = -(-((-1116308209) + ((i203 | (~((-23341061) | i204))) * (-406)) + ((~(796880847 | i204)) * (-406)) + (((~(i | (-773539788))) | (~((-594308294) | i204))) * 406)));
        int i206 = ((i2 | i205) << 1) - (i2 ^ i205);
        int i207 = i206 << 13;
        int i208 = (i207 | i206) & (~(i206 & i207));
        int i209 = i208 >>> 17;
        int i210 = ((~i208) & i209) | ((~i209) & i208);
        int i211 = i210 << 5;
        iArr[0] = ((~i210) & i211) | ((~i211) & i210);
        return objArr32;
    }

    private static void f(int[] iArr, String str, int i, String str2, Object[] objArr) throws Throwable {
        char[] charArray;
        long j;
        int i2;
        String str3 = str2;
        Object obj = str3;
        if (str3 != null) {
            byte[] bytes = str3.getBytes(LocalizedMessage.DEFAULT_ENCODING);
            $11 = ($10 + 63) % 128;
            obj = bytes;
        }
        byte[] bArr = (byte[]) obj;
        if (str != null) {
            charArray = str.toCharArray();
            $10 = ($11 + 115) % 128;
        } else {
            charArray = str;
        }
        char[] cArr = charArray;
        hn hnVar = new hn();
        char[] cArr2 = e;
        Class cls = Integer.TYPE;
        long j2 = 0;
        int i3 = 0;
        if (cArr2 != null) {
            int length = cArr2.length;
            char[] cArr3 = new char[length];
            int i4 = 0;
            while (i4 < length) {
                try {
                    Object[] objArr2 = {Integer.valueOf(cArr2[i4])};
                    Object objD = an.d(-814569747);
                    if (objD == null) {
                        int i5 = 1804 - (ViewConfiguration.getZoomControlsTimeout() > j2 ? 1 : (ViewConfiguration.getZoomControlsTimeout() == j2 ? 0 : -1));
                        char cRgb = (char) (Color.rgb(i3, i3, i3) + 16786908);
                        int i6 = (ViewConfiguration.getGlobalActionKeyTimeout() > j2 ? 1 : (ViewConfiguration.getGlobalActionKeyTimeout() == j2 ? 0 : -1)) + 23;
                        j = j2;
                        byte b2 = (byte) i3;
                        byte b3 = b2;
                        i2 = i3;
                        objD = an.d(i5, cRgb, i6, -1189907018, false, $$c(b2, b3, b3), new Class[]{cls});
                    } else {
                        j = j2;
                        i2 = i3;
                    }
                    cArr3[i4] = ((Character) ((Method) objD).invoke(null, objArr2)).charValue();
                    i4++;
                    i3 = i2;
                    j2 = j;
                } catch (Throwable th) {
                    Throwable cause = th.getCause();
                    if (cause == null) {
                        throw th;
                    }
                    throw cause;
                }
            }
            cArr2 = cArr3;
        }
        long j3 = j2;
        int i7 = i3;
        Object[] objArr3 = {Integer.valueOf(a)};
        Object objD2 = an.d(-1578986303);
        if (objD2 == null) {
            byte b4 = (byte) i7;
            byte b5 = b4;
            objD2 = an.d(2566 - KeyEvent.normalizeMetaState(i7), (char) ((-1) - ExpandableListView.getPackedPositionChild(j3)), (ExpandableListView.getPackedPositionForGroup(i7) > j3 ? 1 : (ExpandableListView.getPackedPositionForGroup(i7) == j3 ? 0 : -1)) + 23, -679262310, false, $$c(b4, b5, (byte) (b5 + 1)), new Class[]{cls});
        }
        int iIntValue = ((Integer) ((Method) objD2).invoke(null, objArr3)).intValue();
        if (c) {
            int length2 = bArr.length;
            hnVar.b = length2;
            char[] cArr4 = new char[length2];
            hnVar.c = 0;
            while (true) {
                int i8 = hnVar.c;
                int i9 = hnVar.b;
                if (i8 >= i9) {
                    objArr[0] = new String(cArr4);
                    return;
                }
                cArr4[i8] = (char) (cArr2[bArr[(i9 - 1) - i8] + i] - iIntValue);
                Object[] objArr4 = {hnVar, hnVar};
                Object objD3 = an.d(717234065);
                if (objD3 == null) {
                    objD3 = an.d(1970 - TextUtils.getCapsMode("", 0, 0), (char) (Color.rgb(0, 0, 0) + 16777216), View.resolveSizeAndState(0, 0, 0) + 24, 1554107594, false, "x", new Class[]{Object.class, Object.class});
                }
                ((Method) objD3).invoke(null, objArr4);
            }
        } else if (d) {
            int length3 = cArr.length;
            hnVar.b = length3;
            char[] cArr5 = new char[length3];
            hnVar.c = 0;
            while (true) {
                int i10 = hnVar.c;
                int i11 = hnVar.b;
                if (i10 >= i11) {
                    objArr[0] = new String(cArr5);
                    return;
                }
                cArr5[i10] = (char) (cArr2[cArr[(i11 - 1) - i10] - i] - iIntValue);
                Object[] objArr5 = {hnVar, hnVar};
                Object objD4 = an.d(717234065);
                if (objD4 == null) {
                    objD4 = an.d(View.MeasureSpec.getMode(0) + 1970, (char) ((ExpandableListView.getPackedPositionForChild(0, 0) > j3 ? 1 : (ExpandableListView.getPackedPositionForChild(0, 0) == j3 ? 0 : -1)) + 1), Drawable.resolveOpacity(0, 0) + 24, 1554107594, false, "x", new Class[]{Object.class, Object.class});
                }
                ((Method) objD4).invoke(null, objArr5);
            }
        } else {
            int length4 = iArr.length;
            hnVar.b = length4;
            char[] cArr6 = new char[length4];
            hnVar.c = 0;
            while (true) {
                int i12 = hnVar.c;
                int i13 = hnVar.b;
                if (i12 >= i13) {
                    objArr[0] = new String(cArr6);
                    return;
                } else {
                    cArr6[i12] = (char) (cArr2[iArr[(i13 - 1) - i12] - i] - iIntValue);
                    hnVar.c = i12 + 1;
                }
            }
        }
    }

    /* JADX WARN: Removed duplicated region for block: B:47:0x01f1  */
    /* JADX WARN: Removed duplicated region for block: B:48:0x01f2  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    private static void g(java.lang.String r29, int r30, java.lang.Object[] r31) throws java.lang.Throwable {
        /*
            Method dump skipped, instruction units count: 510
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: com.facetec.sdk.FaceTecFeedbackCustomization.g(java.lang.String, int, java.lang.Object[]):void");
    }

    public static void init$0() {
        $$a = new byte[]{ISO7816.INS_MANAGE_CHANNEL, ISO7816.INS_UNBLOCK_CHV, ISO7816.INS_WRITE_RECORD, -27};
        $$b = 180;
    }
}