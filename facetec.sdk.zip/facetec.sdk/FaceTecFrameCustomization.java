package com.facetec.sdk;

import android.content.Context;
import android.graphics.Color;
import com.facetec.sdk.cb;
import java.lang.reflect.Method;
import net.sf.scuba.smartcards.ISOFileInfo;
import org.jmrtd.lds.CVCAFile;

/* JADX INFO: loaded from: classes4.dex */
public final class FaceTecFrameCustomization {
    private static final byte[] $$a = null;
    private static final int $$b = 0;
    private static int b;
    private static int e;
    public int borderColor = Color.parseColor("#417FB2");
    public int backgroundColor = -1;
    public int borderWidth = -1;
    public int cornerRadius = -1;
    public int elevation = 0;

    static {
        init$0();
        e = 0;
        b = 1;
    }

    /* JADX WARN: Removed duplicated region for block: B:10:0x0028  */
    /* JADX WARN: Removed duplicated region for block: B:8:0x0020  */
    /* JADX WARN: Unsupported multi-entry loop pattern (BACK_EDGE: B:10:0x0028 -> B:11:0x002f). Please report as a decompilation issue!!! */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    private static void a(int r7, short r8, byte r9, java.lang.Object[] r10) {
        /*
            int r8 = r8 * 2
            int r8 = 101 - r8
            int r9 = r9 * 17
            int r9 = 18 - r9
            byte[] r0 = com.facetec.sdk.FaceTecFrameCustomization.$$a
            int r7 = r7 * 17
            int r7 = r7 + 4
            byte[] r1 = new byte[r9]
            r2 = 0
            if (r0 != 0) goto L18
            r8 = r7
            r3 = r0
            r4 = r2
            r0 = r9
            goto L2f
        L18:
            r3 = r2
        L19:
            int r4 = r3 + 1
            byte r5 = (byte) r8
            r1[r3] = r5
            if (r4 != r9) goto L28
            java.lang.String r7 = new java.lang.String
            r7.<init>(r1, r2)
            r10[r2] = r7
            return
        L28:
            r3 = r0[r7]
            r6 = r8
            r8 = r7
            r7 = r3
            r3 = r0
            r0 = r6
        L2f:
            int r7 = -r7
            int r8 = r8 + 1
            int r0 = r0 + r7
            int r7 = r0 + 3
            r0 = r8
            r8 = r7
            r7 = r0
            r0 = r3
            r3 = r4
            goto L19
        */
        throw new UnsupportedOperationException("Method not decompiled: com.facetec.sdk.FaceTecFrameCustomization.a(int, short, byte, java.lang.Object[]):void");
    }

    public static void e(long j, long j2) throws Throwable {
        int i = e;
        b = ((i ^ 87) + ((i & 87) << 1)) % 128;
        Object obj = cb.a.class.getField("c").get(null);
        int i2 = e;
        int i3 = i2 & 31;
        b = (i3 + ((i2 ^ 31) | i3)) % 128;
        try {
            Object[] objArr = {null, obj};
            byte[] bArr = $$a;
            byte b2 = bArr[9];
            byte b3 = (byte) (b2 - 1);
            byte b4 = b2;
            Object[] objArr2 = new Object[1];
            a(b3, b4, (byte) (b4 - 1), objArr2);
            Class<?> cls = Class.forName((String) objArr2[0]);
            byte b5 = bArr[9];
            byte b6 = b5;
            Object[] objArr3 = new Object[1];
            a(b6, (byte) (b6 - 1), b5, objArr3);
            Method method = cls.getMethod((String) objArr3[0], Context.class, cb.a.class);
            method.setAccessible(true);
            method.invoke(null, objArr);
            e = (b + 91) % 128;
        } catch (Throwable th) {
            Throwable cause = th.getCause();
            if (cause == null) {
                throw th;
            }
            throw cause;
        }
    }

    public static void init$0() {
        $$a = new byte[]{93, 49, 76, ISOFileInfo.CHANNEL_SECURITY, -9, 5, CVCAFile.CAR_TAG, -53, 8, 1, 1, -12, 18, 5, 56, -66, 18, -4, 64, -50, 4};
        $$b = 160;
    }
}