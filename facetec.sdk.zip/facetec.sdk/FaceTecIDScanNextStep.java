package com.facetec.sdk;

/* JADX INFO: loaded from: classes4.dex */
public enum FaceTecIDScanNextStep {
    SELECTION_SCREEN,
    SKIP
}