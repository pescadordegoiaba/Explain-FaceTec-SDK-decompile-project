package com.facetec.sdk;

/* JADX INFO: loaded from: classes4.dex */
public interface FaceTecIDScanProcessor {
    void processIDScanWhileFaceTecSDKWaits(FaceTecIDScanResult faceTecIDScanResult, FaceTecIDScanResultCallback faceTecIDScanResultCallback);
}