package com.facetec.sdk;

import android.os.Parcel;
import android.os.Parcelable;
import android.util.Base64;
import androidx.annotation.NonNull;
import java.util.ArrayList;

/* JADX INFO: loaded from: classes4.dex */
public final class FaceTecIDScanResult implements Parcelable {
    public static final Parcelable.Creator<FaceTecIDScanResult> CREATOR = new Parcelable.Creator<FaceTecIDScanResult>() { // from class: com.facetec.sdk.FaceTecIDScanResult.2
        @Override // android.os.Parcelable.Creator
        public final /* synthetic */ FaceTecIDScanResult createFromParcel(Parcel parcel) {
            return new FaceTecIDScanResult(parcel);
        }

        @Override // android.os.Parcelable.Creator
        public final /* synthetic */ FaceTecIDScanResult[] newArray(int i) {
            return new FaceTecIDScanResult[i];
        }
    };
    ArrayList<String> a;
    String b;
    private final FaceTecIDScanStatus c;
    byte[] d;
    ArrayList<String> e;

    public FaceTecIDScanResult(Parcel parcel) {
        this.a = new ArrayList<>();
        this.e = new ArrayList<>();
        this.c = (FaceTecIDScanStatus) parcel.readSerializable();
        this.a = (ArrayList) cq.d(parcel);
        this.e = (ArrayList) cq.d(parcel);
        this.d = (byte[]) cq.d(parcel);
        this.b = (String) cq.d(parcel);
    }

    @Override // android.os.Parcelable
    public final int describeContents() {
        return 0;
    }

    @NonNull
    public final ArrayList<String> getBackImagesCompressedBase64() {
        return this.e;
    }

    @NonNull
    public final ArrayList<String> getFrontImagesCompressedBase64() {
        return this.a;
    }

    public final byte[] getIDScan() {
        byte[] bArr = new byte[0];
        byte[] bArr2 = this.d;
        return bArr2 != null ? bArr2 : bArr;
    }

    public final String getIDScanBase64() {
        byte[] bArr = new byte[0];
        byte[] bArr2 = this.d;
        if (bArr2 != null) {
            bArr = bArr2;
        }
        return Base64.encodeToString(bArr, 2);
    }

    public final String getSessionId() {
        return this.b;
    }

    public final FaceTecIDScanStatus getStatus() {
        return this.c;
    }

    @Override // android.os.Parcelable
    public final void writeToParcel(Parcel parcel, int i) {
        parcel.writeSerializable(this.c);
        cq.a(this.a, parcel);
        cq.a(this.e, parcel);
        cq.a(this.d, parcel);
        cq.a(this.b, parcel);
    }

    public FaceTecIDScanResult(@NonNull FaceTecIDScanStatus faceTecIDScanStatus) {
        this.a = new ArrayList<>();
        this.e = new ArrayList<>();
        this.c = faceTecIDScanStatus;
    }
}