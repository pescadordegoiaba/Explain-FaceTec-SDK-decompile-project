package com.facetec.sdk;

import android.graphics.Color;
import android.graphics.Typeface;
import android.os.Process;

/* JADX INFO: loaded from: classes4.dex */
public final class FaceTecOCRConfirmationCustomization {
    public static int c;
    public static int d;
    public int backgroundColors = -1;
    public int mainHeaderDividerLineColor = Color.parseColor("#417FB2");
    public int mainHeaderTextColor = Color.parseColor("#417FB2");
    public int sectionHeaderTextColor = Color.parseColor("#333333");
    public int fieldLabelTextColor = Color.parseColor("#333333");
    public int fieldValueTextColor = Color.parseColor("#333333");
    public int inputFieldBackgroundColor = 0;
    public int inputFieldTextColor = 0;
    public int inputFieldBorderColor = Color.parseColor("#333333");
    public int inputFieldPlaceholderTextColor = 0;
    public int buttonTextNormalColor = -1;
    public int buttonBackgroundNormalColor = Color.parseColor("#417FB2");
    public int buttonTextHighlightColor = -1;
    public int buttonBackgroundHighlightColor = Color.parseColor("#396E99");
    public int buttonTextDisabledColor = -1;
    public int buttonBackgroundDisabledColor = Color.parseColor("#66417FB2");
    public int buttonBorderColor = 0;
    public int scrollIndicatorBackgroundNormalColor = Color.parseColor("#417FB2");
    public int scrollIndicatorBackgroundHighlightColor = Color.parseColor("#396E99");
    public int scrollIndicatorForegroundNormalColor = -1;
    public int scrollIndicatorForegroundHighlightColor = -1;
    public int scrollIndicatorBorderColor = 0;
    public int customScrollIndicatorAnimation = 0;
    public int scrollIndicatorElevation = 10;
    public int mainHeaderDividerLineWidth = -1;
    public Typeface mainHeaderFont = null;
    public Typeface sectionHeaderFont = null;
    public Typeface fieldLabelFont = null;
    public Typeface fieldValueFont = null;
    public Typeface inputFieldFont = null;
    public int inputFieldBorderWidth = -1;
    public int inputFieldCornerRadius = -1;
    public Typeface inputFieldPlaceholderFont = null;
    public boolean showInputFieldBottomBorderOnly = false;
    public Typeface buttonFont = null;
    public int buttonCornerRadius = -1;
    public int buttonBorderWidth = -1;
    public Typeface scrollIndicatorFont = null;
    public int scrollIndicatorCornerRadius = -1;
    public int scrollIndicatorBorderWidth = -1;
    public boolean enableScrollIndicator = true;
    public boolean enableScrollIndicatorTextAnimation = true;
    public boolean enableFixedConfirmButton = false;
    public boolean showScrollIndicatorImage = true;

    public static int d() {
        int i = c;
        int i2 = i % 8224614;
        c = i + 1;
        if (i2 != 0) {
            return d;
        }
        int iMyUid = Process.myUid();
        d = iMyUid;
        return iMyUid;
    }
}