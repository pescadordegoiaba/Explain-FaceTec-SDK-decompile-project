package com.facetec.sdk;

/* JADX INFO: loaded from: classes4.dex */
public final class FaceTecOverlayCustomization {
    public int backgroundColor = -1;
    public int brandingImage = 0;
    public boolean showBrandingImage = true;
}