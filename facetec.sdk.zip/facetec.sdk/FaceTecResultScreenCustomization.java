package com.facetec.sdk;

import android.graphics.Color;
import android.graphics.Typeface;

/* JADX INFO: loaded from: classes4.dex */
public final class FaceTecResultScreenCustomization {
    public static int a;
    public static int c;
    public int foregroundColor = Color.parseColor("#417FB2");
    public int backgroundColors = -1;
    public int activityIndicatorColor = Color.parseColor("#417FB2");
    public int customActivityIndicatorImage = 0;
    public int customActivityIndicatorRotationInterval = 1000;
    public int customActivityIndicatorAnimation = 0;
    public boolean showUploadProgressBar = true;
    public int uploadProgressFillColor = Color.parseColor("#417FB2");
    public int uploadProgressTrackColor = Color.parseColor("#66000000");
    public int resultAnimationBackgroundColor = Color.parseColor("#417FB2");
    public int resultAnimationForegroundColor = -1;
    public int resultAnimationSuccessBackgroundImage = 0;
    public int resultAnimationUnsuccessBackgroundImage = 0;
    public int customResultAnimationSuccess = 0;
    public int customResultAnimationUnsuccess = 0;
    public double resultAnimationDisplayTime = 2.0d;
    public Typeface messageFont = null;
    public float animationRelativeScale = 1.0f;

    public static int b() {
        int i = c;
        int i2 = i % 5282411;
        c = i + 1;
        if (i2 != 0) {
            return a;
        }
        int iMaxMemory = (int) Runtime.getRuntime().maxMemory();
        a = iMaxMemory;
        return iMaxMemory;
    }
}