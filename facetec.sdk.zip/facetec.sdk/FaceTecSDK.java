package com.facetec.sdk;

import android.content.Context;
import androidx.annotation.NonNull;
import com.facetec.sdk.nf;
import com.facetec.sdk.pg;
import java.util.Map;
import org.json.JSONObject;

/* JADX INFO: loaded from: classes4.dex */
public final class FaceTecSDK {
    public static final String EXTRA_ID_SCAN_RESULTS = "facetecsdk.signup.idScanResult";
    public static final String EXTRA_SESSION_RESULTS = "facetecsdk.signup.sessionResult";
    public static final int REQUEST_CODE_SESSION = 1002;
    private static final boolean isMinimalLibrary = bk.c();

    @NonNull
    static FaceTecCustomization d = new FaceTecCustomization();
    static FaceTecCustomization e = null;
    static FaceTecCustomization a = null;
    static c c = c.NORMAL;
    protected static int b = 0;
    protected static int i = 0;
    protected static int h = 0;

    /* JADX INFO: renamed from: com.facetec.sdk.FaceTecSDK$5, reason: invalid class name */
    public static /* synthetic */ class AnonymousClass5 {
        static final /* synthetic */ int[] c;

        static {
            int[] iArr = new int[du.values().length];
            c = iArr;
            try {
                iArr[du.CLICKABLE_READY_SCREEN_SUBTEXT.ordinal()] = 1;
            } catch (NoSuchFieldError unused) {
            }
            try {
                c[du.DEV_MODE_TAG.ordinal()] = 2;
            } catch (NoSuchFieldError unused2) {
            }
            try {
                c[du.UNCONSTRAINED_GUIDANCE_STRING_LENGTHS.ordinal()] = 3;
            } catch (NoSuchFieldError unused3) {
            }
            try {
                c[du.STANDALONE_IDSCAN_WATERMARK_CUSTOMIZATION.ordinal()] = 4;
            } catch (NoSuchFieldError unused4) {
            }
            try {
                c[du.ENABLE_SCREEN_CAPTURING.ordinal()] = 5;
            } catch (NoSuchFieldError unused5) {
            }
        }
    }

    public enum CameraPermissionStatus {
        GRANTED("Authorized"),
        NOT_YET_REQUESTED("Not Yet Requested"),
        DENIED("Denied");

        private final String a;

        CameraPermissionStatus(String str) {
            this.a = str;
        }

        @Override // java.lang.Enum
        @NonNull
        public final String toString() {
            return this.a;
        }
    }

    public interface InitializeCallback {
        void onCompletion(boolean z);
    }

    public enum c {
        NORMAL,
        LOW_LIGHT_FROM_PHX_FACE,
        LOW_LIGHT_FROM_PHX_ENV,
        LOW_LIGHT_FROM_SENSOR,
        BRIGHT_LIGHT
    }

    private FaceTecSDK() {
    }

    public static boolean a() {
        return c == c.LOW_LIGHT_FROM_PHX_FACE || c == c.LOW_LIGHT_FROM_PHX_ENV || c == c.LOW_LIGHT_FROM_SENSOR;
    }

    public static boolean b() {
        return a() && e != null;
    }

    private static boolean c(int i2) {
        boolean z = (i2 >= 0 && i2 <= 20) || i2 == -1;
        if (!z) {
            bb.e("An error occurred while setting FaceTecCustomization due to a border width value set outside allowed range. Reverting border width value to default.");
        }
        return z;
    }

    public static void configureOCRLocalization(JSONObject jSONObject) {
        bk.d(1284459851, nf.a.e(), nf.a.e(), nf.a.e(), nf.a.e(), new Object[]{jSONObject}, -1284459847);
    }

    @NonNull
    public static String createFaceTecAPIUserAgentString(String str) {
        return bk.e(str);
    }

    private static boolean d(int i2) {
        boolean z = (i2 >= 0 && i2 <= 40) || i2 == -1;
        if (!z) {
            bb.e("An error occurred while setting FaceTecCustomization due to a corner radius value set outside allowed range. Reverting corner radius value to default.");
        }
        return z;
    }

    public static void deinitialize() throws Throwable {
        bk.a();
    }

    public static boolean e() {
        return c == c.BRIGHT_LIGHT && a != null;
    }

    public static CameraPermissionStatus getCameraPermissionStatus(Context context) {
        return bk.c(context);
    }

    public static Long getLockoutEndTime(Context context) {
        return bk.a(context);
    }

    public static FaceTecSDKStatus getStatus(Context context) {
        return bk.b(context);
    }

    public static void initializeInDevelopmentMode(@NonNull Context context, @NonNull String str, @NonNull String str2, InitializeCallback initializeCallback) throws Throwable {
        bk.a(context, str, str2, (bl) null, initializeCallback);
    }

    public static void initializeInProductionMode(@NonNull Context context, @NonNull String str, @NonNull String str2, @NonNull String str3, InitializeCallback initializeCallback) throws Throwable {
        bk.a(context, str, str2, str3, initializeCallback);
    }

    public static boolean isLockedOut(Context context) {
        return bk.e(context);
    }

    public static void preload(Context context) {
        bk.d(-1868685366, nf.a.e(), nf.a.e(), nf.a.e(), nf.a.e(), new Object[]{context, Boolean.FALSE}, 1868685371);
    }

    public static void setAuditTrailType(FaceTecAuditTrailType faceTecAuditTrailType) {
        bk.d(-2043363712, nf.a.e(), nf.a.e(), nf.a.e(), nf.a.e(), new Object[]{faceTecAuditTrailType}, 2043363715);
    }

    public static void setCustomization(FaceTecCustomization faceTecCustomization) {
        if (faceTecCustomization != null) {
            for (int i2 = 0; i2 < ds.b.length(); i2++) {
                try {
                    JSONObject jSONObject = ds.b.getJSONObject(i2);
                    String string = jSONObject.getString("overrideKey");
                    du duVar = (du) jSONObject.get("type");
                    if (faceTecCustomization.r.get(string) != null && faceTecCustomization.r.get(string).equals(jSONObject.getString("overrideValue"))) {
                        int i3 = AnonymousClass5.c[duVar.ordinal()];
                        if (i3 == 1) {
                            faceTecCustomization.c = true;
                        } else if (i3 == 2) {
                            faceTecCustomization.d = false;
                        } else if (i3 == 3) {
                            faceTecCustomization.b = true;
                        } else if (i3 == 4) {
                            faceTecCustomization.a = true;
                        } else if (i3 == 5) {
                            faceTecCustomization.e = true;
                            ds.e(duVar);
                        }
                    }
                } catch (Exception unused) {
                }
            }
            if (!c(faceTecCustomization.i.buttonBorderWidth)) {
                faceTecCustomization.i.buttonBorderWidth = -1;
            }
            if (!c(faceTecCustomization.f.buttonBorderWidth)) {
                faceTecCustomization.f.buttonBorderWidth = -1;
            }
            if (!c(faceTecCustomization.o.borderWidth)) {
                faceTecCustomization.o.borderWidth = -1;
            }
            if (!c(faceTecCustomization.f.captureScreenTextBackgroundBorderWidth)) {
                faceTecCustomization.f.captureScreenTextBackgroundBorderWidth = -1;
            }
            if (!c(faceTecCustomization.f.reviewScreenTextBackgroundBorderWidth)) {
                faceTecCustomization.f.reviewScreenTextBackgroundBorderWidth = -1;
            }
            if (!c(faceTecCustomization.i.retryScreenImageBorderWidth)) {
                faceTecCustomization.i.retryScreenImageBorderWidth = -1;
            }
            if (!c(faceTecCustomization.j.mainHeaderDividerLineWidth)) {
                faceTecCustomization.j.mainHeaderDividerLineWidth = -1;
            }
            if (!c(faceTecCustomization.j.inputFieldBorderWidth)) {
                faceTecCustomization.j.inputFieldBorderWidth = -1;
            }
            int i4 = faceTecCustomization.o.cornerRadius;
            boolean z = (i4 >= 0 && i4 <= 30) || i4 == -1;
            if (!z) {
                bb.e("An error occurred while setting FaceTecCustomization due to a corner radius value set outside allowed range. Reverting corner radius value to default.");
            }
            if (!z) {
                faceTecCustomization.o.cornerRadius = -1;
            }
            if (!d(faceTecCustomization.l.cornerRadius)) {
                faceTecCustomization.l.cornerRadius = -1;
            }
            if (!d(faceTecCustomization.i.buttonCornerRadius)) {
                faceTecCustomization.i.buttonCornerRadius = -1;
            }
            if (!d(faceTecCustomization.f.buttonCornerRadius)) {
                faceTecCustomization.f.buttonCornerRadius = -1;
            }
            if (!d(faceTecCustomization.f.captureScreenTextBackgroundCornerRadius)) {
                faceTecCustomization.f.captureScreenTextBackgroundCornerRadius = -1;
            }
            if (!d(faceTecCustomization.f.reviewScreenTextBackgroundCornerRadius)) {
                faceTecCustomization.f.reviewScreenTextBackgroundCornerRadius = -1;
            }
            if (!d(faceTecCustomization.i.readyScreenTextBackgroundCornerRadius)) {
                faceTecCustomization.i.readyScreenTextBackgroundCornerRadius = -1;
            }
            if (!d(faceTecCustomization.i.retryScreenImageCornerRadius)) {
                faceTecCustomization.i.retryScreenImageCornerRadius = -1;
            }
            if (!d(faceTecCustomization.j.inputFieldCornerRadius)) {
                faceTecCustomization.j.inputFieldCornerRadius = -1;
            }
            if (!e(faceTecCustomization.n.strokeWidth)) {
                faceTecCustomization.n.strokeWidth = -1;
            }
            if (!e(faceTecCustomization.n.progressStrokeWidth)) {
                faceTecCustomization.n.progressStrokeWidth = -1;
            }
            int i5 = faceTecCustomization.n.progressRadialOffset;
            boolean z2 = (i5 >= 2 && i5 <= 20) || i5 == -1;
            if (!z2) {
                bb.e("An error occurred while setting FaceTecCustomization due to a radial offset value set outside allowed range. Reverting radial offset value to default.");
            }
            if (!z2) {
                faceTecCustomization.n.progressRadialOffset = -1;
            }
            String str = faceTecCustomization.i.retryScreenHeaderAttributedString;
            if (str != null && !str.isEmpty()) {
                dm.g(true);
            }
            String str2 = faceTecCustomization.i.retryScreenSubtextAttributedString;
            if (str2 != null && !str2.isEmpty()) {
                dm.i(true);
            }
            String str3 = faceTecCustomization.i.readyScreenHeaderAttributedString;
            if (str3 != null && !str3.isEmpty()) {
                dm.j(true);
            }
            String str4 = faceTecCustomization.i.readyScreenSubtextAttributedString;
            if (str4 != null && !str4.isEmpty()) {
                dm.e(pg.a.a(), pg.a.a(), -1480234844, new Object[]{Boolean.TRUE}, pg.a.a(), 1480234855, pg.a.a());
            }
            d = faceTecCustomization;
            bj.a();
        }
    }

    public static void setDynamicDimmingCustomization(FaceTecCustomization faceTecCustomization) {
        a = faceTecCustomization;
    }

    public static void setDynamicStrings(Map<Integer, String> map) {
        dp.e(map);
    }

    public static void setLowLightCustomization(FaceTecCustomization faceTecCustomization) {
        e = faceTecCustomization;
    }

    public static void setMaxAuditTrailImages(FaceTecAuditTrailImagesToReturn faceTecAuditTrailImagesToReturn) {
        bk.d = faceTecAuditTrailImagesToReturn;
    }

    @Deprecated
    public static void unload() throws Throwable {
        bk.a();
    }

    public static String version() {
        return "9.7.130";
    }

    private static boolean e(int i2) {
        boolean z = (i2 >= 2 && i2 <= 20) || i2 == -1;
        if (!z) {
            bb.e("An error occurred while setting FaceTecCustomization due to a stroke width value set outside allowed range. Reverting stroke width value to default.");
        }
        return z;
    }
}