package com.facetec.sdk;

/* JADX INFO: loaded from: classes4.dex */
public enum FaceTecSecurityWatermarkImage {
    FACETEC_ZOOM,
    FACETEC,
    FACETEC_POWERED_BY
}