package com.facetec.sdk;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.res.Configuration;
import android.os.Bundle;
import androidx.annotation.NonNull;

/* JADX INFO: loaded from: classes4.dex */
public final class FaceTecSessionActivity extends bi {
    static FaceTecFaceScanProcessor c;
    static FaceTecIDScanProcessor f;

    public static void createAndLaunchSession(Context context, FaceTecFaceScanProcessor faceTecFaceScanProcessor) {
        createAndLaunchSession(context, faceTecFaceScanProcessor, null, "");
    }

    public static FaceTecIDScanResult getIDScanResultFromActivityResult(@NonNull Intent intent) {
        if (intent != null) {
            return (FaceTecIDScanResult) intent.getParcelableExtra(FaceTecSDK.EXTRA_ID_SCAN_RESULTS);
        }
        return null;
    }

    public static FaceTecSessionResult getSessionResultFromActivityResult(@NonNull Intent intent) {
        if (intent != null) {
            return (FaceTecSessionResult) intent.getParcelableExtra(FaceTecSDK.EXTRA_SESSION_RESULTS);
        }
        return null;
    }

    @Override // com.facetec.sdk.bi, com.facetec.sdk.bm, android.app.Activity, android.view.ContextThemeWrapper, android.content.ContextWrapper
    public final void attachBaseContext(Context context) {
        super.attachBaseContext(context);
    }

    @Override // com.facetec.sdk.bi, android.app.Activity
    public final /* bridge */ /* synthetic */ void onBackPressed() {
        super.onBackPressed();
    }

    @Override // com.facetec.sdk.bm, android.app.Activity, android.content.ComponentCallbacks
    public final /* bridge */ /* synthetic */ void onConfigurationChanged(Configuration configuration) {
        super.onConfigurationChanged(configuration);
    }

    @Override // com.facetec.sdk.bi, com.facetec.sdk.bm, android.app.Activity
    public final void onCreate(Bundle bundle) {
        super.onCreate(bundle);
    }

    @Override // com.facetec.sdk.bi, android.app.Activity
    public final /* bridge */ /* synthetic */ void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
    }

    @Override // com.facetec.sdk.bi, com.facetec.sdk.bm, android.app.Activity
    public final void onPause() {
        super.onPause();
    }

    @Override // com.facetec.sdk.bi, android.app.Activity
    public final /* bridge */ /* synthetic */ void onRequestPermissionsResult(int i, @NonNull String[] strArr, @NonNull int[] iArr) throws Throwable {
        super.onRequestPermissionsResult(i, strArr, iArr);
    }

    @Override // com.facetec.sdk.bi, com.facetec.sdk.bm, android.app.Activity
    public final void onResume() throws Throwable {
        super.onResume();
    }

    @Override // com.facetec.sdk.bi, com.facetec.sdk.bm, android.app.Activity
    public final void onStart() {
        super.onStart();
    }

    @Override // com.facetec.sdk.bi, android.app.Activity, android.view.Window.Callback
    public final /* bridge */ /* synthetic */ void onWindowFocusChanged(boolean z) {
        super.onWindowFocusChanged(z);
    }

    @Override // com.facetec.sdk.bi, com.facetec.sdk.dk.a
    public final /* bridge */ /* synthetic */ void p() {
        super.p();
    }

    public static void createAndLaunchSession(Context context, FaceTecFaceScanProcessor faceTecFaceScanProcessor, String str) {
        createAndLaunchSession(context, faceTecFaceScanProcessor, null, str);
    }

    public static void createAndLaunchSession(Context context, FaceTecFaceScanProcessor faceTecFaceScanProcessor, FaceTecIDScanProcessor faceTecIDScanProcessor) {
        createAndLaunchSession(context, faceTecFaceScanProcessor, faceTecIDScanProcessor, "");
    }

    public static void createAndLaunchSession(Context context, FaceTecFaceScanProcessor faceTecFaceScanProcessor, FaceTecIDScanProcessor faceTecIDScanProcessor, String str) {
        bk.i();
        Intent intent = new Intent(context, (Class<?>) FaceTecSessionActivity.class);
        if (str != null) {
            intent.putExtra("facetec.serverSessionToken", str);
        }
        c = faceTecFaceScanProcessor;
        f = faceTecIDScanProcessor;
        ((Activity) context).startActivityForResult(intent, 1002);
    }

    public static void createAndLaunchSession(Context context, FaceTecIDScanProcessor faceTecIDScanProcessor, String str) {
        bk.i();
        Intent intent = new Intent(context, (Class<?>) FaceTecSessionActivity.class);
        if (str != null) {
            intent.putExtra("facetec.serverSessionToken", str);
        }
        c = null;
        f = faceTecIDScanProcessor;
        intent.putExtra("facetec.idScanOnlyMode", true);
        ((Activity) context).startActivityForResult(intent, 1002);
    }
}