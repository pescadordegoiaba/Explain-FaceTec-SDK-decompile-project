package com.facetec.sdk;

import android.os.Parcel;
import android.os.Parcelable;
import android.util.Base64;
import androidx.annotation.NonNull;

/* JADX INFO: loaded from: classes4.dex */
public final class FaceTecSessionResult implements Parcelable {
    public static final Parcelable.Creator<FaceTecSessionResult> CREATOR = new Parcelable.Creator<FaceTecSessionResult>() { // from class: com.facetec.sdk.FaceTecSessionResult.1
        @Override // android.os.Parcelable.Creator
        public final /* synthetic */ FaceTecSessionResult createFromParcel(Parcel parcel) {
            return new FaceTecSessionResult(parcel);
        }

        @Override // android.os.Parcelable.Creator
        public final /* synthetic */ FaceTecSessionResult[] newArray(int i) {
            return new FaceTecSessionResult[i];
        }
    };
    private final byte[][] a;
    private final FaceTecSessionStatus b;
    private final byte[] c;
    private final byte[][] d;
    private String e;

    public FaceTecSessionResult(Parcel parcel) {
        this.b = FaceTecSessionStatus.valueOf(parcel.readString());
        this.e = parcel.readString();
        this.a = (byte[][]) cq.d(parcel);
        this.d = (byte[][]) cq.d(parcel);
        this.c = (byte[]) cq.d(parcel);
    }

    public final void a(String str) {
        this.e = str;
    }

    @Override // android.os.Parcelable
    public final int describeContents() {
        return 0;
    }

    @NonNull
    public final String[] getAuditTrailCompressedBase64() {
        byte[][] bArr = this.a;
        int i = 0;
        if (bArr == null) {
            return new String[0];
        }
        String[] strArr = new String[bArr.length];
        while (true) {
            byte[][] bArr2 = this.a;
            if (i >= bArr2.length) {
                return strArr;
            }
            strArr[i] = Base64.encodeToString(bArr2[i], 2);
            i++;
        }
    }

    public final byte[] getFaceScan() {
        byte[] bArr = new byte[0];
        byte[] bArr2 = this.c;
        return bArr2 != null ? bArr2 : bArr;
    }

    public final String getFaceScanBase64() {
        byte[] bArr = new byte[0];
        byte[] bArr2 = this.c;
        if (bArr2 != null) {
            bArr = bArr2;
        }
        return Base64.encodeToString(bArr, 2);
    }

    @NonNull
    public final String[] getLowQualityAuditTrailCompressedBase64() {
        byte[][] bArr = this.d;
        int i = 0;
        if (bArr == null) {
            return new String[0];
        }
        String[] strArr = new String[bArr.length];
        while (true) {
            byte[][] bArr2 = this.d;
            if (i >= bArr2.length) {
                return strArr;
            }
            strArr[i] = Base64.encodeToString(bArr2[i], 2);
            i++;
        }
    }

    public final String getSessionId() {
        return this.e;
    }

    public final FaceTecSessionStatus getStatus() {
        return this.b;
    }

    @Override // android.os.Parcelable
    public final void writeToParcel(Parcel parcel, int i) {
        parcel.writeString(this.b.name());
        parcel.writeString(this.e);
        cq.a(this.a, parcel);
        cq.a(this.d, parcel);
        cq.a(this.c, parcel);
    }

    public FaceTecSessionResult(FaceTecSessionStatus faceTecSessionStatus, byte[][] bArr, byte[][] bArr2, byte[] bArr3) {
        this.b = faceTecSessionStatus;
        this.a = bArr;
        this.d = bArr2;
        this.c = bArr3;
    }
}