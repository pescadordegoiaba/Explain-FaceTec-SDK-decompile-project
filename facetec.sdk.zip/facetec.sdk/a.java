package com.facetec.sdk;

import java.lang.reflect.Member;

/* JADX INFO: loaded from: classes4.dex */
public class a {
    public static /* synthetic */ Member[] a = new Member[e()];

    static {
        b.c();
    }

    private static int e() {
        return 1;
    }
}