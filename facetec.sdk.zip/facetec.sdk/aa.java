package com.facetec.sdk;

import android.content.Context;
import android.view.View;
import com.facetec.sdk.aa;
import com.facetec.sdk.cb;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Iterator;
import java.util.List;
import net.sf.scuba.smartcards.ISO7816;
import org.jmrtd.lds.CVCAFile;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

/* JADX INFO: loaded from: classes4.dex */
final class aa {
    private Context c;
    List<v> d = new ArrayList();
    private int b = 2;
    private int f = 0;
    int a = 0;
    int e = 0;
    private boolean j = false;
    private boolean h = false;

    /* JADX INFO: renamed from: com.facetec.sdk.aa$5, reason: invalid class name */
    public static /* synthetic */ class AnonymousClass5 {
        static final /* synthetic */ int[] a;

        static {
            int[] iArr = new int[b.values().length];
            a = iArr;
            try {
                iArr[b.a.ordinal()] = 1;
            } catch (NoSuchFieldError unused) {
            }
            try {
                a[b.c.ordinal()] = 2;
            } catch (NoSuchFieldError unused2) {
            }
            try {
                a[b.d.ordinal()] = 3;
            } catch (NoSuchFieldError unused3) {
            }
            try {
                a[b.e.ordinal()] = 4;
            } catch (NoSuchFieldError unused4) {
            }
            try {
                a[b.b.ordinal()] = 5;
            } catch (NoSuchFieldError unused5) {
            }
            try {
                a[b.f.ordinal()] = 6;
            } catch (NoSuchFieldError unused6) {
            }
        }
    }

    public static class a {
        private static final byte[] $$a = null;
        private static final int $$b = 0;
        private static int d;
        private static int e;
        int a;
        int b;

        static {
            init$0();
            e = 0;
            d = 1;
        }

        public a(int i, int i2) {
            this.b = i;
            this.a = i2;
        }

        private static void c(int i, byte b, int i2, Object[] objArr) {
            int i3 = 101 - (i2 * 2);
            byte[] bArr = $$a;
            int i4 = b * 17;
            int i5 = (i * 17) + 4;
            byte[] bArr2 = new byte[i4 + 1];
            int i6 = -1;
            if (bArr == null) {
                i3 = i5 + (-i4) + 3;
                i5++;
            }
            while (true) {
                i6++;
                bArr2[i6] = (byte) i3;
                if (i6 == i4) {
                    objArr[0] = new String(bArr2, 0);
                    return;
                }
                int i7 = i3;
                int i8 = i5 + 1;
                i3 = i7 + (-bArr[i5]) + 3;
                i5 = i8;
            }
        }

        public static void d(long j, long j2) throws Throwable {
            d = (e + 29) % 128;
            Object obj = cb.a.class.getField("a").get(null);
            int i = e;
            int i2 = i & 107;
            d = ((((~i2) & (i | 107)) - (~(i2 << 1))) - 1) % 128;
            int i3 = (i & (-24)) | ((~i) & 23);
            int i4 = (i & 23) << 1;
            d = (((i3 | i4) << 1) - (i4 ^ i3)) % 128;
            try {
                Object[] objArr = {null, obj};
                byte[] bArr = $$a;
                byte b = bArr[9];
                byte b2 = (byte) (b - 1);
                byte b3 = b;
                Object[] objArr2 = new Object[1];
                c(b2, b3, b3, objArr2);
                Class<?> cls = Class.forName((String) objArr2[0]);
                byte b4 = bArr[9];
                byte b5 = (byte) (b4 - 1);
                Object[] objArr3 = new Object[1];
                c(b4, b5, b5, objArr3);
                Method method = cls.getMethod((String) objArr3[0], Context.class, cb.a.class);
                method.setAccessible(true);
                method.invoke(null, objArr);
                e = (d + 111) % 128;
            } catch (Throwable th) {
                Throwable cause = th.getCause();
                if (cause == null) {
                    throw th;
                }
                throw cause;
            }
        }

        public static void init$0() {
            $$a = new byte[]{119, ISO7816.INS_LOAD_KEY_FILE, 16, 123, -9, 5, CVCAFile.CAR_TAG, -53, 8, 1, 1, -12, 18, 5, 56, -66, 18, -4, 64, -50, 4};
            $$b = 20;
        }
    }

    /* JADX WARN: Failed to restore enum class, 'enum' modifier and super class removed */
    /* JADX WARN: Unknown enum class pattern. Please report as an issue! */
    public static final class b {
        private static final byte[] $$a = null;
        private static final int $$b = 0;
        private static int $10;
        private static int $11;
        public static final b a;
        public static final b b;
        public static final b c;
        public static final b d;
        public static final b e;
        public static final b f;

        /* JADX INFO: renamed from: g, reason: collision with root package name */
        private static final /* synthetic */ b[] f95814g;
        private static int h;
        private static long i;
        private static int k;
        private static int l;
        private static int m;
        final String j;

        /* JADX WARN: Removed duplicated region for block: B:10:0x0023  */
        /* JADX WARN: Removed duplicated region for block: B:8:0x001d  */
        /* JADX WARN: Unsupported multi-entry loop pattern (BACK_EDGE: B:10:0x0023 -> B:11:0x0025). Please report as a decompilation issue!!! */
        /*
            Code decompiled incorrectly, please refer to instructions dump.
            To view partially-correct code enable 'Show inconsistent code' option in preferences
        */
        private static java.lang.String $$c(short r5, byte r6, byte r7) {
            /*
                int r7 = r7 + 99
                int r5 = r5 + 4
                byte[] r0 = com.facetec.sdk.aa.b.$$a
                int r6 = r6 * 3
                int r6 = 1 - r6
                byte[] r1 = new byte[r6]
                r2 = 0
                if (r0 != 0) goto L13
                r4 = r7
                r3 = r2
                r7 = r6
                goto L25
            L13:
                r3 = r2
            L14:
                byte r4 = (byte) r7
                r1[r3] = r4
                int r3 = r3 + 1
                int r5 = r5 + 1
                if (r3 != r6) goto L23
                java.lang.String r5 = new java.lang.String
                r5.<init>(r1, r2)
                return r5
            L23:
                r4 = r0[r5]
            L25:
                int r7 = r7 + r4
                goto L14
            */
            throw new UnsupportedOperationException("Method not decompiled: com.facetec.sdk.aa.b.$$c(short, byte, byte):java.lang.String");
        }

        static {
            init$0();
            $10 = 0;
            $11 = 1;
            l = 0;
            k = 1;
            h = 0;
            m = 1;
            d();
            a = new b("HASH_SET_ARRAY", 0, "haia");
            c = new b("VERSION", 1, "v");
            Object[] objArr = new Object[1];
            n("譖", View.resolveSize(0, 0) + 13781, objArr);
            d = new b("REVISION", 2, ((String) objArr[0]).intern());
            e = new b("SIZE", 3, "s");
            b = new b("SESSION_COUNT", 4, "sc");
            f = new b("TAMPERING_DETECTED", 5, "td");
            f95814g = a();
            int i2 = k + 71;
            l = i2 % 128;
            if (i2 % 2 != 0) {
                int i3 = 93 / 0;
            }
        }

        private b(String str, int i2, String str2) {
            this.j = str2;
        }

        private static /* synthetic */ b[] a() {
            b[] bVarArr;
            int i2 = h + 31;
            int i3 = i2 % 128;
            m = i3;
            if (i2 % 2 == 0) {
                bVarArr = new b[19];
                bVarArr[0] = a;
                bVarArr[1] = c;
                bVarArr[4] = d;
                bVarArr[3] = e;
                bVarArr[3] = b;
                bVarArr[5] = f;
            } else {
                bVarArr = new b[]{a, c, d, e, b, f};
            }
            int i4 = i3 + 1;
            h = i4 % 128;
            if (i4 % 2 != 0) {
                int i5 = 88 / 0;
            }
            return bVarArr;
        }

        public static void d() {
            i = -5013583331370341741L;
        }

        public static void init$0() {
            $$a = new byte[]{4, ISO7816.INS_READ_BINARY, 45, 109};
            $$b = 67;
        }

        /* JADX WARN: Removed duplicated region for block: B:38:0x014a  */
        /* JADX WARN: Removed duplicated region for block: B:39:0x014b  */
        /* JADX WARN: Removed duplicated region for block: B:8:0x0017  */
        /* JADX WARN: Removed duplicated region for block: B:9:0x001c  */
        /*
            Code decompiled incorrectly, please refer to instructions dump.
            To view partially-correct code enable 'Show inconsistent code' option in preferences
        */
        private static void n(java.lang.String r22, int r23, java.lang.Object[] r24) throws java.lang.Throwable {
            /*
                Method dump skipped, instruction units count: 340
                To view this dump change 'Code comments level' option to 'DEBUG'
            */
            throw new UnsupportedOperationException("Method not decompiled: com.facetec.sdk.aa.b.n(java.lang.String, int, java.lang.Object[]):void");
        }

        public static b valueOf(String str) {
            h = (m + 9) % 128;
            b bVar = (b) Enum.valueOf(b.class, str);
            int i2 = m + 23;
            h = i2 % 128;
            if (i2 % 2 == 0) {
                return bVar;
            }
            throw null;
        }

        public static b[] values() {
            h = (m + 111) % 128;
            b[] bVarArr = (b[]) f95814g.clone();
            int i2 = h + 41;
            m = i2 % 128;
            if (i2 % 2 == 0) {
                int i3 = 72 / 0;
            }
            return bVarArr;
        }
    }

    public aa(Context context) {
        this.c = context.getApplicationContext();
    }

    public static aa b(Context context, String str) {
        aa aaVar = new aa(context);
        if (str != null && !str.isEmpty()) {
            try {
                JSONObject jSONObject = new JSONObject(str);
                JSONArray jSONArray = jSONObject.getJSONArray(b.a.j);
                ArrayList arrayList = new ArrayList();
                for (int i = 0; i < jSONArray.length(); i++) {
                    arrayList.add(v.a(jSONArray.getJSONObject(i).toString()));
                }
                for (b bVar : b.values()) {
                    switch (AnonymousClass5.a[bVar.ordinal()]) {
                        case 1:
                            aaVar.d = arrayList;
                            break;
                        case 2:
                            aaVar.b = jSONObject.getInt(bVar.j);
                            break;
                        case 3:
                            aaVar.f = jSONObject.getInt(bVar.j);
                            break;
                        case 4:
                            aaVar.a = jSONObject.getInt(bVar.j);
                            break;
                        case 5:
                            aaVar.e = jSONObject.getInt(bVar.j);
                            break;
                        case 6:
                            aaVar.j = jSONObject.getBoolean(bVar.j);
                            break;
                    }
                }
                aaVar.h = true;
                aaVar.f++;
                return aaVar;
            } catch (Exception e) {
                aaVar.j = true;
                c cVar = c.F2F_ERROR;
                StringBuilder sb = new StringBuilder("Error 4471: ");
                sb.append(e.getMessage());
                t.d(context, cVar, sb.toString(), e);
            }
        }
        return aaVar;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static /* synthetic */ int e(a aVar, a aVar2) {
        return aVar.a - aVar2.a;
    }

    public final JSONObject c() {
        int i;
        JSONObject jSONObject = new JSONObject();
        JSONArray jSONArray = new JSONArray();
        Iterator<v> it = this.d.iterator();
        while (it.hasNext()) {
            jSONArray.put(it.next().d());
        }
        try {
        } catch (JSONException e) {
            Context context = this.c;
            c cVar = c.F2F_ERROR;
            StringBuilder sb = new StringBuilder("Error 4470: ");
            sb.append(e.getMessage());
            t.d(context, cVar, sb.toString(), e);
            return jSONObject;
        }
        for (b bVar : b.values()) {
            switch (AnonymousClass5.a[bVar.ordinal()]) {
                case 1:
                    jSONObject.put(bVar.j, jSONArray);
                    continue;
                    break;
                case 2:
                    jSONObject.put(bVar.j, this.b);
                    continue;
                    break;
                case 3:
                    jSONObject.put(bVar.j, this.f);
                    continue;
                    break;
                case 4:
                    jSONObject.put(bVar.j, this.a);
                    continue;
                    break;
                case 5:
                    jSONObject.put(bVar.j, this.e);
                    continue;
                    break;
                case 6:
                    jSONObject.put(bVar.j, this.j);
                    continue;
                    break;
                default:
                    continue;
                    break;
            }
            Context context2 = this.c;
            c cVar2 = c.F2F_ERROR;
            StringBuilder sb2 = new StringBuilder("Error 4470: ");
            sb2.append(e.getMessage());
            t.d(context2, cVar2, sb2.toString(), e);
            return jSONObject;
        }
        return jSONObject;
    }

    public final List<a> d() {
        ArrayList arrayList = new ArrayList();
        for (int i = 0; i < this.d.size(); i++) {
            a aVar = new a(i, i);
            y yVar = this.d.get(i).a;
            y yVar2 = y.DETECTED;
            if (yVar == yVar2) {
                aVar.a -= this.d.size();
            }
            if (this.d.get(i).d == yVar2) {
                aVar.a -= this.d.size();
            }
            if (this.d.get(i).f95951g == yVar2) {
                aVar.a -= this.d.size();
            }
            arrayList.add(aVar);
        }
        Collections.sort(arrayList, new Comparator() { // from class: com.facetec.sdk.丹
            @Override // java.util.Comparator
            public final int compare(Object obj, Object obj2) {
                return aa.e((aa.a) obj, (aa.a) obj2);
            }
        });
        return arrayList;
    }
}