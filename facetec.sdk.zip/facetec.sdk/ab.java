package com.facetec.sdk;

/* JADX INFO: loaded from: classes4.dex */
enum ab {
    INITIALIZED,
    STARTED,
    ENDED
}