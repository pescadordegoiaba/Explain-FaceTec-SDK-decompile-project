package com.facetec.sdk;

import android.content.Context;
import com.facetec.sdk.aa;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.concurrent.atomic.AtomicReference;

/* JADX INFO: loaded from: classes4.dex */
final class ac {
    private Context c;
    private int d = 50;
    private int b = 3;
    private ae a = new ae();
    private aa e = null;
    private final AtomicReference<ab> h = new AtomicReference<>(ab.INITIALIZED);
    private w j = new w();

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    private List<w> f95815g = new ArrayList();
    private List<w> i = new ArrayList();
    private int f = -1;
    private int o = 0;
    private boolean l = false;
    private boolean k = false;
    private boolean m = false;
    private int n = 0;

    public ac(Context context) {
        this.c = context;
    }

    /* JADX INFO: Access modifiers changed from: private */
    /* JADX INFO: renamed from: e, reason: merged with bridge method [inline-methods] */
    public synchronized void b(Runnable runnable) {
        try {
            e(0);
            ArrayList arrayList = new ArrayList();
            int i = 0;
            int i2 = -1;
            while (i < this.j.a.size()) {
                ai aiVar = this.j.a.get(i);
                if (i2 == -1 || i2 != aiVar.d) {
                    ArrayList arrayList2 = new ArrayList();
                    int i3 = aiVar.d;
                    int i4 = i;
                    while (i < this.j.a.size() && this.j.a.get(i).d == i3) {
                        arrayList2.add(Integer.valueOf(this.j.a.get(i).c));
                        i4 = i;
                        i++;
                    }
                    arrayList.add(arrayList2);
                    i2 = i3;
                    i = i4;
                }
                i++;
            }
            this.j.e = arrayList;
            z zVar = new z();
            w wVar = this.j;
            List<w> list = this.f95815g;
            List<w> list2 = this.i;
            zVar.a = wVar;
            ad adVar = zVar.e;
            adVar.d = new ArrayList(list2);
            ArrayList arrayList3 = new ArrayList(list);
            adVar.e = arrayList3;
            arrayList3.add(wVar);
            adVar.b = af.b(adVar.e);
            adVar.c = new ArrayList(wVar.e);
            adVar.a = af.b(list).size();
            ArrayList arrayList4 = new ArrayList();
            adVar.f = arrayList4;
            arrayList4.add(adVar.b);
            for (int i5 = 0; i5 < list2.size(); i5++) {
                adVar.f.add(list2.get(i5).e);
            }
            adVar.f95816g = new ArrayList();
            for (int i6 = 0; i6 < adVar.f.size(); i6++) {
                adVar.f95816g.addAll(adVar.f.get(i6));
            }
            zVar.d = zVar.a(zVar.e.c, 0, u.INTRA_SESSION);
            ad adVar2 = zVar.e;
            zVar.c = zVar.a(adVar2.b, adVar2.a, u.INTRA_FACETEC_SESSION);
            ad adVar3 = zVar.e;
            boolean zA = zVar.a(adVar3.f95816g, adVar3.b.size(), u.INTER_FACETEC_SESSION);
            zVar.b = zA;
            w wVar2 = zVar.a;
            wVar2.i = zVar.d ? y.DETECTED : y.NOT_DETECTED;
            wVar2.j = zVar.c ? y.DETECTED : y.NOT_DETECTED;
            wVar2.h = zA ? y.DETECTED : y.NOT_DETECTED;
            zVar.e = new ad();
            this.j = zVar.a;
            if (runnable != null) {
                runnable.run();
            }
            this.a.a(true);
            dj.a(new Runnable() { // from class: com.facetec.sdk.书
                @Override // java.lang.Runnable
                public final void run() {
                    this.f6871.j();
                }
            });
        } catch (Throwable th) {
            throw th;
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public synchronized void j() {
        if (this.m) {
            t.d(this.c, c.F2F_ERROR, "Error 4472", null);
            return;
        }
        ArrayList arrayList = new ArrayList();
        if (this.f95815g.size() > 0) {
            arrayList = new ArrayList(Arrays.asList(this.f95815g.get(r1.size() - 1)));
        }
        arrayList.add(this.j);
        ArrayList<w> arrayList2 = new ArrayList(Arrays.asList(af.a(arrayList)));
        arrayList2.addAll(this.i);
        aa aaVar = new aa(this.c);
        ArrayList arrayList3 = new ArrayList();
        for (w wVar : arrayList2) {
            v vVar = new v();
            List<List<Integer>> list = wVar.e;
            vVar.b = list;
            vVar.c = list.size();
            vVar.a = wVar.i;
            vVar.d = wVar.j;
            vVar.f95951g = wVar.h;
            vVar.e = af.a(vVar.d().toString());
            arrayList3.add(vVar);
        }
        aaVar.d = arrayList3;
        aaVar.e = arrayList2.size();
        aaVar.a = af.a(aaVar.c().toString());
        int iA = af.a(aaVar.c().toString());
        aaVar.a = iA;
        if (iA > 4500) {
            aaVar.d.remove(r0.size() - 1);
            aaVar.a = af.a(aaVar.c().toString());
            List<aa.a> listD = aaVar.d();
            for (int size = listD.size() - 1; size >= 0 && aaVar.a > 4500; size--) {
                aaVar.d.remove(listD.get(size).b);
                aaVar.a = af.a(aaVar.c().toString());
            }
        }
        this.e = aaVar;
        h.e(this.c, aaVar);
    }

    public final synchronized void a() {
        this.f95815g = null;
        this.i = null;
        this.e = null;
        this.m = true;
        this.a.a(true);
    }

    public final synchronized void b(boolean z) {
        try {
            ab abVar = this.h.get();
            ab abVar2 = ab.STARTED;
            if (abVar != abVar2 && !this.m) {
                this.h.set(abVar2);
                this.l = false;
                this.k = false;
                this.f++;
                this.a.a(false);
                int i = this.f;
                if (i != 0) {
                    if (!z && i > 0 && !this.j.e.isEmpty()) {
                        this.o = 0;
                        if (this.f95815g.size() == 50) {
                            this.f95815g.remove(0);
                        }
                        this.j.d = new ArrayList();
                        this.f95815g.add(this.j);
                        this.j = new w();
                    }
                    return;
                }
                if (this.e == null) {
                    this.e = h.e(this.c);
                }
                ArrayList arrayList = new ArrayList();
                for (v vVar : this.e.d) {
                    if (vVar.b.size() > 0) {
                        arrayList.add(vVar.b);
                    }
                }
                ArrayList arrayList2 = new ArrayList();
                for (int i2 = 0; i2 < arrayList.size(); i2++) {
                    ArrayList arrayList3 = new ArrayList();
                    w wVar = new w();
                    wVar.e = (List) arrayList.get(i2);
                    for (int i3 = 0; i3 < wVar.e.size(); i3++) {
                        for (int i4 = 0; i4 < wVar.e.get(i3).size(); i4++) {
                            ai aiVar = new ai();
                            aiVar.d = i3;
                            aiVar.c = wVar.e.get(i3).get(i4).intValue();
                            arrayList3.add(aiVar);
                        }
                    }
                    wVar.a = arrayList3;
                    arrayList2.add(wVar);
                }
                this.i.addAll(arrayList2);
            }
        } finally {
        }
    }

    public final void c(boolean z, final Runnable runnable) {
        ab abVar = this.h.get();
        ab abVar2 = ab.ENDED;
        if (abVar == abVar2 || this.m) {
            if (runnable != null) {
                runnable.run();
                return;
            }
            return;
        }
        this.h.set(abVar2);
        synchronized (this) {
            try {
                if (z) {
                    this.n = 0;
                } else {
                    int i = this.n + 1;
                    this.n = i;
                    if (i > 3) {
                        this.j = new w();
                        this.a.a(true);
                        if (runnable != null) {
                            runnable.run();
                        }
                        return;
                    }
                }
                dj.a(new Runnable() { // from class: com.facetec.sdk.乐
                    @Override // java.lang.Runnable
                    public final void run() {
                        this.f6796.b(runnable);
                    }
                });
            } catch (Throwable th) {
                throw th;
            }
        }
    }

    public final synchronized w d() {
        return this.j;
    }

    public final void h() {
        if (c()) {
            ae aeVar = this.a;
            synchronized (aeVar.a) {
                if (aeVar.e) {
                    return;
                }
                try {
                    aeVar.a.wait(5000L);
                    if (!ae.b && !aeVar.e) {
                        throw new AssertionError();
                    }
                } catch (InterruptedException unused) {
                }
            }
        }
    }

    public final boolean c() {
        return this.h.get() == ab.ENDED;
    }

    public final synchronized void c(byte[] bArr) {
        try {
            if (b() && bArr.length != 0) {
                ai aiVar = new ai();
                aiVar.e = bArr;
                aiVar.a = this.j.a.size();
                aiVar.d = this.f;
                this.j.a.add(aiVar);
                if (this.j.a.size() % 20 == 0) {
                    this.k = true;
                }
                if (this.k && !this.l) {
                    e(this.o);
                }
            }
        } finally {
        }
    }

    public final synchronized boolean b() {
        if (this.h.get() == ab.STARTED) {
            if (!this.m) {
                return true;
            }
        }
        return false;
    }

    public final boolean e() {
        return this.h.get() == ab.STARTED;
    }

    private void e(int i) {
        if (i == 0 || (!this.l && this.k)) {
            this.l = true;
            this.k = false;
            while (i < this.j.a.size()) {
                if (this.j.a.get(i).e.length != 0) {
                    this.j.a.get(i).c = Arrays.hashCode(this.j.a.get(i).e);
                    this.j.a.get(i).e = new byte[0];
                    this.o = i + 1;
                }
                i++;
            }
            this.l = false;
        }
    }
}