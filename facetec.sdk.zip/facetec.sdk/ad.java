package com.facetec.sdk;

import java.util.ArrayList;
import java.util.List;

/* JADX INFO: loaded from: classes4.dex */
final class ad {
    List<List<Integer>> c = new ArrayList();
    int a = 0;
    List<w> e = new ArrayList();
    List<List<Integer>> b = new ArrayList();
    List<w> d = new ArrayList();
    List<List<List<Integer>>> f = new ArrayList();

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    List<List<Integer>> f95816g = new ArrayList();
}