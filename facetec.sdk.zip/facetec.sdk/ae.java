package com.facetec.sdk;

/* JADX INFO: loaded from: classes4.dex */
class ae {
    static final /* synthetic */ boolean b = true;
    final Object a = new Object();
    boolean e = false;

    public final void a(boolean z) {
        synchronized (this.a) {
            try {
                if (this.e != z) {
                    this.e = z;
                    this.a.notifyAll();
                }
            } catch (Throwable th) {
                throw th;
            }
        }
    }
}