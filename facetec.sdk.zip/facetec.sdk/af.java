package com.facetec.sdk;

import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashSet;
import java.util.List;
import org.json.JSONArray;

/* JADX INFO: loaded from: classes4.dex */
final class af {
    public static w a(List<w> list) {
        ArrayList arrayList = new ArrayList();
        ArrayList arrayList2 = new ArrayList();
        for (int i = 0; i < list.size(); i++) {
            arrayList.addAll(list.get(i).e);
            arrayList2.addAll(list.get(i).a);
        }
        w wVar = new w();
        wVar.e = arrayList;
        wVar.a = arrayList2;
        return wVar;
    }

    public static List<List<Integer>> b(List<w> list) {
        ArrayList arrayList = new ArrayList();
        for (int i = 0; i < list.size(); i++) {
            arrayList.addAll(list.get(i).e);
        }
        return arrayList;
    }

    public static Integer[] c(List<Integer> list) {
        return (Integer[]) new HashSet(list).toArray(new Integer[0]);
    }

    public static JSONArray d(List<List<List<ai>>> list) {
        JSONArray jSONArray = new JSONArray();
        for (int i = 0; i < list.size(); i++) {
            JSONArray jSONArray2 = new JSONArray();
            for (int i2 = 0; i2 < list.get(i).size(); i2++) {
                JSONArray jSONArray3 = new JSONArray();
                for (int i3 = 0; i3 < list.get(i).size(); i3++) {
                    jSONArray3.put(list.get(i).get(i2).get(i3).d());
                }
                jSONArray2.put(jSONArray3);
            }
            jSONArray.put(jSONArray2);
        }
        return jSONArray;
    }

    public static JSONArray e(List<List<ai>> list) {
        JSONArray jSONArray = new JSONArray();
        for (int i = 0; i < list.size(); i++) {
            JSONArray jSONArray2 = new JSONArray();
            for (int i2 = 0; i2 < list.get(i).size(); i2++) {
                jSONArray2.put(list.get(i).get(i2).d());
            }
            jSONArray.put(jSONArray2);
        }
        return jSONArray;
    }

    public static boolean i(List<Integer> list) {
        return c(list).length >= 3;
    }

    public static List j(List list) {
        List list2 = list;
        int i = 0;
        while (i <= 0) {
            try {
                ArrayList arrayList = new ArrayList();
                for (int i2 = 0; i2 < list2.size(); i2++) {
                    if (list2.get(i2) instanceof List) {
                        arrayList.addAll((Collection) list2.get(i2));
                    } else {
                        arrayList.add(list2.get(i2));
                    }
                }
                i++;
                list2 = arrayList;
            } catch (Exception unused) {
                return list;
            }
        }
        return list2;
    }

    public static int a(String str) {
        return Math.round(str.getBytes(StandardCharsets.UTF_8).length / 1000.0f);
    }
}