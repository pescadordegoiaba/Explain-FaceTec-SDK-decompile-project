package com.facetec.sdk;

import android.graphics.Color;
import android.graphics.PointF;
import android.media.AudioTrack;
import android.os.Process;
import android.telephony.cdma.CdmaCellLocation;
import android.text.TextUtils;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.View;
import android.view.ViewConfiguration;
import com.incode.welcome_sdk.modules.SelfieScan;
import com.plaid.internal.EnumC41897g;
import java.lang.reflect.Method;
import java.util.Arrays;
import javax.crypto.Cipher;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;
import org.jmrtd.PassportService;

/* JADX INFO: loaded from: classes4.dex */
final class ag extends aq {
    private static final byte[] $$a = null;
    private static final int $$b = 0;
    private static int $10;
    private static int $11;
    private static int[] a;
    private static int b;
    private static int c;
    private static int e;
    private static int h;
    private static int i;
    private final SecretKeySpec d;

    /* JADX WARN: Removed duplicated region for block: B:10:0x0022  */
    /* JADX WARN: Removed duplicated region for block: B:8:0x001c  */
    /* JADX WARN: Unsupported multi-entry loop pattern (BACK_EDGE: B:10:0x0022 -> B:11:0x002d). Please report as a decompilation issue!!! */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    private static java.lang.String $$c(int r6, int r7, short r8) {
        /*
            int r8 = r8 * 3
            int r0 = r8 + 1
            int r6 = r6 + 107
            int r7 = r7 * 2
            int r7 = 3 - r7
            byte[] r1 = com.facetec.sdk.ag.$$a
            byte[] r0 = new byte[r0]
            r2 = 0
            if (r1 != 0) goto L16
            r6 = r8
            r3 = r1
            r4 = r2
            r1 = r7
            goto L2d
        L16:
            r3 = r2
        L17:
            byte r4 = (byte) r6
            r0[r3] = r4
            if (r3 != r8) goto L22
            java.lang.String r6 = new java.lang.String
            r6.<init>(r0, r2)
            return r6
        L22:
            int r7 = r7 + 1
            int r3 = r3 + 1
            r4 = r1[r7]
            r5 = r1
            r1 = r7
            r7 = r4
            r4 = r3
            r3 = r5
        L2d:
            int r7 = -r7
            int r6 = r6 + r7
            r7 = r1
            r1 = r3
            r3 = r4
            goto L17
        */
        throw new UnsupportedOperationException("Method not decompiled: com.facetec.sdk.ag.$$c(int, int, short):java.lang.String");
    }

    static {
        init$0();
        $10 = 0;
        $11 = 1;
        h = 0;
        i = 1;
        b = 0;
        e = 1;
        a();
        e();
        AudioTrack.getMaxVolume();
        TypedValue.complexToFloat(0);
        View.resolveSizeAndState(0, 0, 0);
        h = (i + 113) % 128;
    }

    public ag(byte[] bArr) throws Throwable {
        Object[] objArr = new Object[1];
        f(3 - (ViewConfiguration.getScrollDefaultDelay() >> 16), true, (ViewConfiguration.getMaximumDrawingCacheSize() >> 24) + EnumC41897g.SDK_ASSET_ILLUSTRATION_SDK_NAVBAR_PLAID_LOGO_VALUE, "\u000b�\ufff9", Color.alpha(0) + 3, objArr);
        this.d = new SecretKeySpec(bArr, ((String) objArr[0]).intern());
    }

    public static void a() {
        a = new int[]{1860638621, -1544290097, -1293693415, 200648876, 1231998658, 1816122012, 2052658763, -30574894, 357319307, -61123179, -1574328329, -874602373, -634963767, -316038725, -26801423, -1343253263, 580294811, -972207079};
    }

    public static void e() {
        c = 1605274399;
    }

    /* JADX WARN: Removed duplicated region for block: B:39:0x0172  */
    /* JADX WARN: Removed duplicated region for block: B:40:0x0173  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    private static void f(int r25, boolean r26, int r27, java.lang.String r28, int r29, java.lang.Object[] r30) throws java.lang.Throwable {
        /*
            Method dump skipped, instruction units count: 383
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: com.facetec.sdk.ag.f(int, boolean, int, java.lang.String, int, java.lang.Object[]):void");
    }

    private static void g(int[] iArr, int i2, Object[] objArr) throws Throwable {
        int i3;
        int i4;
        byte b2;
        char[] cArr;
        int[] iArr2;
        hg hgVar = new hg();
        char[] cArr2 = new char[4];
        char[] cArr3 = new char[iArr.length * 2];
        int[] iArr3 = a;
        int i5 = 14;
        Class cls = Integer.TYPE;
        char c2 = '0';
        int i6 = 0;
        if (iArr3 != null) {
            int length = iArr3.length;
            i4 = 2027942060;
            int[] iArr4 = new int[length];
            i3 = 2;
            int i7 = 0;
            while (i7 < length) {
                try {
                    Object[] objArr2 = {Integer.valueOf(iArr3[i7])};
                    Object objD = an.d(2027942060);
                    if (objD == null) {
                        byte b3 = (byte) i5;
                        byte b4 = (byte) i6;
                        objD = an.d(KeyEvent.getDeadChar(i6, i6) + 617, (char) ((-1) - TextUtils.indexOf("", c2)), (ViewConfiguration.getKeyRepeatDelay() >> 16) + 23, 247342071, false, $$c(b3, b4, b4), new Class[]{cls});
                    }
                    iArr4[i7] = ((Integer) ((Method) objD).invoke(null, objArr2)).intValue();
                    i7++;
                    i5 = 14;
                    c2 = '0';
                    i6 = 0;
                } catch (Throwable th) {
                    Throwable cause = th.getCause();
                    if (cause == null) {
                        throw th;
                    }
                    throw cause;
                }
            }
            iArr3 = iArr4;
        } else {
            i3 = 2;
            i4 = 2027942060;
        }
        int i8 = 16;
        int length2 = iArr3.length;
        int[] iArr5 = new int[length2];
        int[] iArr6 = a;
        if (iArr6 != null) {
            int length3 = iArr6.length;
            int[] iArr7 = new int[length3];
            int i9 = 0;
            while (i9 < length3) {
                Object[] objArr3 = {Integer.valueOf(iArr6[i9])};
                Object objD2 = an.d(i4);
                if (objD2 == null) {
                    cArr = cArr2;
                    iArr2 = iArr6;
                    byte b5 = (byte) 0;
                    objD2 = an.d(617 - TextUtils.getCapsMode("", 0, 0), (char) ((-1) - TextUtils.lastIndexOf("", '0', 0)), 23 - KeyEvent.keyCodeFromString(""), 247342071, false, $$c((byte) 14, b5, b5), new Class[]{cls});
                } else {
                    cArr = cArr2;
                    iArr2 = iArr6;
                }
                iArr7[i9] = ((Integer) ((Method) objD2).invoke(null, objArr3)).intValue();
                i9++;
                cArr2 = cArr;
                iArr6 = iArr2;
            }
            iArr6 = iArr7;
        }
        char[] cArr4 = cArr2;
        char c3 = 0;
        System.arraycopy(iArr6, 0, iArr5, 0, length2);
        hgVar.c = 0;
        while (true) {
            int i10 = hgVar.c;
            if (i10 >= iArr.length) {
                objArr[0] = new String(cArr3, 0, i2);
                return;
            }
            int i11 = iArr[i10];
            char c4 = (char) (i11 >> 16);
            cArr4[c3] = c4;
            char c5 = (char) i11;
            byte b6 = 1;
            cArr4[1] = c5;
            char c6 = (char) (iArr[i10 + 1] >> 16);
            cArr4[i3] = c6;
            char c7 = (char) iArr[i10 + 1];
            cArr4[3] = c7;
            hgVar.d = (c4 << 16) + c5;
            hgVar.a = (c6 << 16) + c7;
            hg.a(iArr5);
            int i12 = 0;
            while (i12 < i8) {
                int i13 = hgVar.d ^ iArr5[i12];
                hgVar.d = i13;
                int iB = hg.b(i13);
                Object[] objArr4 = new Object[4];
                objArr4[3] = hgVar;
                objArr4[i3] = hgVar;
                objArr4[b6] = Integer.valueOf(iB);
                objArr4[0] = hgVar;
                Object objD3 = an.d(-1264699187);
                if (objD3 == null) {
                    int i14 = (CdmaCellLocation.convertQuartSecToDecDegrees(0) > 0.0d ? 1 : (CdmaCellLocation.convertQuartSecToDecDegrees(0) == 0.0d ? 0 : -1)) + 1558;
                    char touchSlop = (char) ((ViewConfiguration.getTouchSlop() >> 8) + 63317);
                    int iIndexOf = 32 - TextUtils.indexOf("", "", 0, 0);
                    byte b7 = (byte) ($$a[i3] + b6);
                    b2 = b6;
                    byte b8 = (byte) 0;
                    objD3 = an.d(i14, touchSlop, iIndexOf, -1023415402, false, $$c(b7, b8, b8), new Class[]{Object.class, cls, Object.class, Object.class});
                } else {
                    b2 = b6;
                }
                int iIntValue = ((Integer) ((Method) objD3).invoke(null, objArr4)).intValue();
                hgVar.d = hgVar.a;
                hgVar.a = iIntValue;
                i12++;
                b6 = b2;
                i8 = 16;
            }
            byte b9 = b6;
            int i15 = hgVar.d;
            int i16 = hgVar.a;
            hgVar.d = i16;
            hgVar.a = i15;
            int i17 = i15 ^ iArr5[16];
            hgVar.a = i17;
            int i18 = i16 ^ iArr5[17];
            hgVar.d = i18;
            cArr4[0] = (char) (i18 >>> 16);
            cArr4[b9] = (char) i18;
            cArr4[i3] = (char) (i17 >>> 16);
            cArr4[3] = (char) i17;
            hg.a(iArr5);
            int i19 = hgVar.c;
            cArr3[i19 * 2] = cArr4[0];
            cArr3[(i19 * 2) + 1] = cArr4[b9];
            cArr3[(i19 * 2) + 2] = cArr4[i3];
            cArr3[(i19 * 2) + 3] = cArr4[3];
            int i20 = i3;
            Object[] objArr5 = new Object[i20];
            objArr5[b9] = hgVar;
            objArr5[0] = hgVar;
            Object objD4 = an.d(-204410541);
            if (objD4 == null) {
                i8 = 16;
                objD4 = an.d((ViewConfiguration.getLongPressTimeout() >> 16) + EnumC41897g.SDK_ASSET_PLAID_LOGO_LOADING_INDICATOR_SUCCESS_VALUE, (char) (PointF.length(SelfieScan.RECOGNITION_FAIL_RESULT, SelfieScan.RECOGNITION_FAIL_RESULT) > SelfieScan.RECOGNITION_FAIL_RESULT ? 1 : (PointF.length(SelfieScan.RECOGNITION_FAIL_RESULT, SelfieScan.RECOGNITION_FAIL_RESULT) == SelfieScan.RECOGNITION_FAIL_RESULT ? 0 : -1)), 22 - TextUtils.indexOf((CharSequence) "", '0', 0), -2051988984, false, "A", new Class[]{Object.class, Object.class});
            } else {
                i8 = 16;
            }
            ((Method) objD4).invoke(null, objArr5);
            i3 = i20;
            c3 = 0;
        }
    }

    public static void init$0() {
        $$a = new byte[]{87, -2, PassportService.SFI_DG11, -41};
        $$b = 160;
    }

    public final byte[] b(byte[] bArr) {
        byte[] bArrCopyOfRange = Arrays.copyOfRange(bArr, 0, 16);
        byte[] bArrCopyOfRange2 = Arrays.copyOfRange(bArr, 16, bArr.length);
        IvParameterSpec ivParameterSpec = new IvParameterSpec(bArrCopyOfRange);
        Object[] objArr = new Object[1];
        f(20 - TextUtils.getOffsetAfter("", 0), false, View.getDefaultSize(0, 0) + EnumC41897g.SDK_ASSET_ILLUSTRATION_DEV_RAISE_INSTITUTION_CENTERED_VALUE, "￡\u0002�\ufff5\u0005\uffe7\u0002\u0013\u0016\u0016\u001b \u0019\ufff3\ufff7\u0005￡\ufff5\ufff4\ufff5", TextUtils.indexOf("", "", 0) + 13, objArr);
        Cipher cipher = Cipher.getInstance(((String) objArr[0]).intern());
        cipher.init(2, this.d, ivParameterSpec);
        byte[] bArrE = aq.e(cipher, bArrCopyOfRange2);
        e = (b + 29) % 128;
        return bArrE;
    }

    public final byte[] c(byte[] bArr) throws Throwable {
        byte[] bArrD;
        IvParameterSpec ivParameterSpec;
        Cipher cipher;
        try {
            bArrD = aq.d();
            ivParameterSpec = new IvParameterSpec(bArrD);
            Object[] objArr = new Object[1];
            f(20 - View.resolveSizeAndState(0, 0, 0), false, View.MeasureSpec.makeMeasureSpec(0, 0) + EnumC41897g.SDK_ASSET_ILLUSTRATION_DEV_RAISE_INSTITUTION_CENTERED_VALUE, "￡\u0002�\ufff5\u0005\uffe7\u0002\u0013\u0016\u0016\u001b \u0019\ufff3\ufff7\u0005￡\ufff5\ufff4\ufff5", TextUtils.indexOf((CharSequence) "", '0', 0) + 14, objArr);
            cipher = Cipher.getInstance(((String) objArr[0]).intern());
        } catch (Exception unused) {
        }
        try {
            cipher.init(1, this.d, ivParameterSpec);
            byte[] bArrC = aq.c(cipher, bArr);
            byte[] bArr2 = new byte[bArrC.length + bArrD.length];
            int length = bArrD.length;
            e = (b + 27) % 128;
            try {
                Object[] objArr2 = {bArrD, 0, bArr2, 0, Integer.valueOf(length)};
                Object[] objArr3 = new Object[1];
                g(new int[]{259710220, -1662211088, 2136657792, 1205004446, -1267595271, 1728765406, 33788929, 861799168}, (PointF.length(SelfieScan.RECOGNITION_FAIL_RESULT, SelfieScan.RECOGNITION_FAIL_RESULT) > SelfieScan.RECOGNITION_FAIL_RESULT ? 1 : (PointF.length(SelfieScan.RECOGNITION_FAIL_RESULT, SelfieScan.RECOGNITION_FAIL_RESULT) == SelfieScan.RECOGNITION_FAIL_RESULT ? 0 : -1)) + 16, objArr3);
                Class<?> cls = Class.forName((String) objArr3[0]);
                Object[] objArr4 = new Object[1];
                g(new int[]{985367360, -1563329375, -1796645118, 1437987605, -1452962389, 377534565}, 9 - (ViewConfiguration.getMaximumDrawingCacheSize() >> 24), objArr4);
                String str = (String) objArr4[0];
                Class cls2 = Integer.TYPE;
                cls.getMethod(str, Object.class, cls2, Object.class, cls2, cls2).invoke(null, objArr2);
                int length2 = bArrD.length;
                int length3 = bArrC.length;
                b = (e + 3) % 128;
                try {
                    Object[] objArr5 = {bArrC, 0, bArr2, Integer.valueOf(length2), Integer.valueOf(length3)};
                    Object[] objArr6 = new Object[1];
                    g(new int[]{259710220, -1662211088, 2136657792, 1205004446, -1267595271, 1728765406, 33788929, 861799168}, Process.getGidForName("") + 17, objArr6);
                    Class<?> cls3 = Class.forName((String) objArr6[0]);
                    Object[] objArr7 = new Object[1];
                    g(new int[]{985367360, -1563329375, -1796645118, 1437987605, -1452962389, 377534565}, Gravity.getAbsoluteGravity(0, 0) + 9, objArr7);
                    cls3.getMethod((String) objArr7[0], Object.class, cls2, Object.class, cls2, cls2).invoke(null, objArr5);
                    int i2 = e + 55;
                    b = i2 % 128;
                    if (i2 % 2 != 0) {
                        int i3 = 82 / 0;
                    }
                    return bArr2;
                } catch (Throwable th) {
                    Throwable cause = th.getCause();
                    if (cause != null) {
                        throw cause;
                    }
                    throw th;
                }
            } catch (Throwable th2) {
                Throwable cause2 = th2.getCause();
                if (cause2 != null) {
                    throw cause2;
                }
                throw th2;
            }
        } catch (Exception unused2) {
            return null;
        }
    }
}