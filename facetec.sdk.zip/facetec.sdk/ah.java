package com.facetec.sdk;

import android.app.Activity;
import android.content.Context;
import android.hardware.Camera;
import android.os.Handler;
import android.os.Looper;
import android.view.View;
import android.view.ViewGroup;
import android.widget.RelativeLayout;
import androidx.annotation.NonNull;
import com.facetec.sdk.FaceTecSDK;
import java.lang.ref.WeakReference;
import java.util.Timer;
import java.util.TimerTask;

/* JADX INFO: loaded from: classes4.dex */
abstract class ah {
    static boolean a = false;
    static String b = "";
    static boolean c = false;
    protected static ar d = null;
    static ar e = null;
    static int h = 0;
    static float i = -1.0f;
    static float j = -1.0f;
    private static WeakReference<ah> k = null;
    private static ar m = null;
    static ar n = null;
    private static /* synthetic */ boolean s = true;
    protected boolean f = false;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    protected boolean f95817g = true;
    protected boolean o = false;
    private static a r = a.NONE;
    private static boolean p = false;
    static boolean l = true;
    private static int t = 0;

    public enum a {
        NONE,
        CONTEXT_SWITCH_BEFORE_CAMERA_INIT,
        CONTEXT_SWITCH_AFTER_CAMERA_INIT
    }

    public static final class e {

        /* JADX INFO: renamed from: com.facetec.sdk.ah$e$e, reason: collision with other inner class name */
        public static final class C2355e {
            static final String[] d = {"SM-J", "SM-G570", "SM-G611", "SM-G615", "SM-G532", "SM-G610", "SM-S767VL", "SM-A23", "SM-S236DL", "SM-C710", "SM-A105", "SM-A115", "SM-A205", "SM-A207", "SM-A236", "SM-A260", "SM-A305", "SM-A325", "SM-A730", "LM-G900", "220333QAG", "PRA-LA1", "23026RN54G", "23028RN4DG", "220733SG", "220733SI", "220733SL", "220743FI", "220733SH", "23028RNCAG", "RMX3710", "RT112", "moto g"};
            static final String[] e = {"Infinix X6515", "Nokia C2 Tennen"};
            static final String[] a = {"LM-X210", "LM-X410", "LG-K200", "Moto E (4)", "moto e5 play", "23026RN54G"};
            static final String[] b = {"Surface Duo 2", "2203129G"};
            static final String[] c = {"ZTE B2017G"};
            static final String[] j = {"22111317PG", "LG-M250"};
            static final String[] f = {"RT112"};
        }
    }

    public static ah a(ViewGroup viewGroup, Activity activity, boolean z, boolean z2) {
        ah ahVarE;
        a = z2;
        c = z;
        a(activity);
        if (!z) {
            bc.b(activity);
        }
        if (bj.i) {
            c(activity);
            if (!s && m == null) {
                throw new AssertionError();
            }
        } else {
            a((Context) activity);
            if (!s && d == null) {
                throw new AssertionError();
            }
        }
        if (m().booleanValue()) {
            ahVarE = new al();
        } else if (a) {
            ahVarE = ap.e(activity);
        } else if (e(activity).booleanValue()) {
            am amVar = new am(activity);
            o.a = 2;
            ahVarE = amVar;
        } else {
            ahVarE = ap.e(activity);
            o.a = 1;
        }
        View viewC = ahVarE.c();
        viewGroup.addView(viewC);
        RelativeLayout.LayoutParams layoutParams = new RelativeLayout.LayoutParams(-1, -1);
        layoutParams.addRule(13, -1);
        viewC.setLayoutParams(layoutParams);
        k = new WeakReference<>(ahVarE);
        return ahVarE;
    }

    public static synchronized void c(Context context) {
        try {
            if (m == null) {
                try {
                    m = e(context).booleanValue() ? am.h(context) : ap.n();
                } catch (Exception e2) {
                    t.d(context, c.CAMERA_ERROR, e2.toString(), e2);
                }
            }
        } catch (Throwable th) {
            throw th;
        }
    }

    public static synchronized ar f() {
        return d;
    }

    public static String g() {
        StringBuilder sb = new StringBuilder("CR: ");
        sb.append(p);
        sb.append(" | CSB: ");
        sb.append(r);
        sb.append(" | CSF: ");
        sb.append(l);
        sb.append(" | CSC: ");
        sb.append(t);
        return sb.toString();
    }

    public static synchronized ar h() {
        return m;
    }

    public static void i() {
        p = true;
    }

    public static float j() {
        if (d != null) {
            return r0.b / r0.e;
        }
        return 1.7777778f;
    }

    private static Boolean m() {
        try {
            return Boolean.FALSE;
        } catch (Throwable unused) {
            return Boolean.FALSE;
        }
    }

    public abstract void a();

    public abstract void a(boolean z);

    public abstract void b();

    public abstract void b(boolean z);

    public abstract View c();

    public abstract void c(ViewGroup viewGroup);

    public abstract void c(boolean z, ViewGroup viewGroup);

    public abstract void d();

    public final void d(@NonNull final Runnable runnable) {
        final Timer timer = new Timer();
        final Handler handler = new Handler(Looper.getMainLooper());
        final TimerTask timerTask = new TimerTask() { // from class: com.facetec.sdk.ah.2
            @Override // java.util.TimerTask, java.lang.Runnable
            public final void run() {
                if (ah.this.f) {
                    synchronized (timer) {
                        cancel();
                        handler.removeCallbacksAndMessages(null);
                        handler.post(runnable);
                    }
                }
            }
        };
        timer.scheduleAtFixedRate(timerTask, 0L, 100L);
        handler.postDelayed(new Runnable() { // from class: com.facetec.sdk.人
            @Override // java.lang.Runnable
            public final void run() {
                ah.d(timer, timerTask, runnable);
            }
        }, 8000L);
    }

    public abstract void d(boolean z);

    public void e() {
    }

    public abstract void e(Camera.PictureCallback pictureCallback);

    public static Boolean e(Context context) {
        return bh.c(e.C2355e.d) ? Boolean.FALSE : !bj.i ? Boolean.valueOf(am.d(context)) : Boolean.valueOf(am.b(context));
    }

    public static void c(boolean z) {
        if (l == z) {
            return;
        }
        l = z;
        if (z) {
            WeakReference<ah> weakReference = k;
            if (weakReference == null || weakReference.get() == null) {
                return;
            }
            k.get().b();
            return;
        }
        t++;
        if (p) {
            r = a.CONTEXT_SWITCH_AFTER_CAMERA_INIT;
        } else {
            r = a.CONTEXT_SWITCH_BEFORE_CAMERA_INIT;
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static /* synthetic */ void d(Timer timer, TimerTask timerTask, Runnable runnable) {
        synchronized (timer) {
            timerTask.cancel();
            runnable.run();
        }
    }

    public static synchronized void a(Context context) {
        try {
            if (d == null) {
                t.d(context, c.CALCULATE_FRONT_CAMERA_SIZE_START, null, null);
                try {
                    if (e(context).booleanValue()) {
                        d = am.j(context);
                    } else if (bk.c(context) == FaceTecSDK.CameraPermissionStatus.GRANTED) {
                        d = ap.b(context);
                    }
                } catch (Exception e2) {
                    t.d(context, c.CALCULATE_FRONT_CAMERA_SIZE_EXCEPTION, null, e2);
                }
                if (d != null) {
                    c cVar = c.SELECTED_FRONT_CAMERA_SIZE;
                    StringBuilder sb = new StringBuilder();
                    sb.append(d.b);
                    sb.append("x");
                    sb.append(d.e);
                    t.d(context, cVar, sb.toString(), null);
                }
            }
        } catch (Throwable th) {
            throw th;
        }
    }

    public static void a(Activity activity) {
        r = a.NONE;
        p = false;
        l = activity.hasWindowFocus();
        t = 0;
    }
}