package com.facetec.sdk;

import ai.luciq.library.screenshot.analytics.ScreenShotAnalyticsMapper;
import com.plaid.internal.EnumC41897g;
import io.sentry.Session;
import java.lang.reflect.Constructor;
import java.lang.reflect.Method;
import java.util.Date;
import org.jmrtd.PassportService;
import org.jmrtd.lds.CVCAFile;
import org.json.JSONException;
import org.json.JSONObject;

/* JADX INFO: loaded from: classes4.dex */
public final class ai {
    private static final byte[] $$a = null;
    private static final int $$b = 0;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    private static int f95818g;
    private static int i;
    int a = -1;
    int d = -1;
    int c = -1;
    private long b = new Date().getTime();
    byte[] e = new byte[0];

    static {
        init$0();
        i = 0;
        f95818g = 1;
    }

    public static void e(long j, long j2) throws Throwable {
        int i2 = i;
        int i3 = ((i2 ^ 9) | (i2 & 9)) << 1;
        int i4 = -(((~i2) & 9) | (i2 & (-10)));
        f95818g = ((i3 & i4) + (i4 | i3)) % 128;
        byte[] bArr = $$a;
        byte b = bArr[9];
        Object[] objArr = new Object[1];
        f((byte) (b - 1), (byte) (-b), b, objArr);
        if (Class.forName((String) objArr[0]).getField(ScreenShotAnalyticsMapper.capturedErrorCodes).getBoolean(null)) {
            int i5 = f95818g;
            i = ((i5 ^ 57) + ((i5 & 57) << 1)) % 128;
            return;
        }
        byte b2 = bArr[9];
        Object[] objArr2 = new Object[1];
        f((byte) (b2 - 1), (byte) (-b2), b2, objArr2);
        Class.forName((String) objArr2[0]).getField(ScreenShotAnalyticsMapper.capturedErrorCodes).setBoolean(null, true);
        int i6 = f95818g;
        int i7 = i6 & 9;
        i = (((i6 | 9) & (~i7)) + (i7 << 1)) % 128;
        try {
            byte b3 = bArr[9];
            byte b4 = (byte) (b3 - 1);
            Object[] objArr3 = new Object[1];
            f(b4, (byte) (b4 | 16), (byte) (b3 - 1), objArr3);
            Constructor<?> declaredConstructor = Class.forName((String) objArr3[0]).getDeclaredConstructor(null);
            declaredConstructor.setAccessible(true);
            Object[] objArr4 = {declaredConstructor.newInstance(null)};
            Method method = dj.class.getMethod("a", Runnable.class);
            method.setAccessible(true);
            method.invoke(null, objArr4);
            int i8 = f95818g;
            int i9 = i8 & 81;
            int i10 = -(-((i8 ^ 81) | i9));
            i = (((i9 | i10) << 1) - (i10 ^ i9)) % 128;
        } catch (Throwable th) {
            Throwable cause = th.getCause();
            if (cause == null) {
                throw th;
            }
            throw cause;
        }
    }

    /* JADX WARN: Removed duplicated region for block: B:10:0x002a  */
    /* JADX WARN: Removed duplicated region for block: B:8:0x0022  */
    /* JADX WARN: Unsupported multi-entry loop pattern (BACK_EDGE: B:10:0x002a -> B:11:0x0034). Please report as a decompilation issue!!! */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    private static void f(byte r6, int r7, byte r8, java.lang.Object[] r9) {
        /*
            int r8 = r8 * 2
            int r0 = 20 - r8
            byte[] r1 = com.facetec.sdk.ai.$$a
            int r7 = r7 + 4
            int r6 = r6 * 4
            int r6 = r6 + 99
            byte[] r0 = new byte[r0]
            int r8 = 19 - r8
            r2 = 0
            if (r1 != 0) goto L17
            r3 = r1
            r4 = r2
            r1 = r7
            goto L34
        L17:
            r3 = r7
            r7 = r6
            r6 = r3
            r3 = r2
        L1b:
            byte r4 = (byte) r7
            r0[r3] = r4
            int r6 = r6 + 1
            if (r3 != r8) goto L2a
            java.lang.String r6 = new java.lang.String
            r6.<init>(r0, r2)
            r9[r2] = r6
            return
        L2a:
            int r3 = r3 + 1
            r4 = r1[r6]
            r5 = r7
            r7 = r6
            r6 = r4
            r4 = r3
            r3 = r1
            r1 = r5
        L34:
            int r6 = -r6
            int r1 = r1 + r6
            int r6 = r1 + 3
            r1 = r7
            r7 = r6
            r6 = r1
            r1 = r3
            r3 = r4
            goto L1b
        */
        throw new UnsupportedOperationException("Method not decompiled: com.facetec.sdk.ai.f(byte, int, byte, java.lang.Object[]):void");
    }

    public static void init$0() {
        $$a = new byte[]{87, -2, PassportService.SFI_DG11, -41, -9, 5, CVCAFile.CAR_TAG, -53, 8, 1, 1, -12, 18, 5, 56, -66, 18, -4, 64, -50, 4, -9, 5, CVCAFile.CAR_TAG, -53, 8, 1, 1, -12, 18, 5, 56, -66, 18, -4, 64, -50, 4, 65, -12};
        $$b = EnumC41897g.SDK_ASSET_ICON_PAUSE_VALUE;
    }

    public final JSONObject d() {
        JSONObject jSONObject = new JSONObject();
        try {
            jSONObject.put("i", this.a);
            jSONObject.put(Session.JsonKeys.SID, this.d);
            jSONObject.put("ct", this.b);
            jSONObject.put("h", this.c);
        } catch (JSONException unused) {
        }
        return jSONObject;
    }
}