package com.facetec.sdk;

import java.util.Locale;

/* JADX INFO: loaded from: classes4.dex */
final class ak extends Exception {

    public enum b {
        UNKNOWN(0),
        PERMISSION_DENIED(1),
        OPEN_TIMEOUT(2),
        LOCK_OPEN_TIMEOUT(3),
        CLOSE_ERROR(4),
        FRONT_FACING_NOT_FOUND(5),
        NO_OUTPUT_SIZES(6),
        ACCESS_ERROR(7);

        final int i;

        b(int i) {
            this.i = i;
        }
    }

    public ak(b bVar) {
        this(bVar, "");
    }

    private static String b(b bVar, String str) {
        String str2 = String.format(Locale.US, "Camera error (%d)", Integer.valueOf(bVar.i));
        if (str.isEmpty()) {
            return str2;
        }
        StringBuilder sb = new StringBuilder();
        sb.append(str2);
        sb.append(": ");
        sb.append(str);
        return sb.toString();
    }

    public ak(b bVar, String str) {
        super(b(bVar, str));
    }

    public ak(Throwable th) {
        super(b(b.UNKNOWN, ""), th);
    }

    public ak(b bVar, Throwable th) {
        super(b(bVar, ""), th);
    }
}