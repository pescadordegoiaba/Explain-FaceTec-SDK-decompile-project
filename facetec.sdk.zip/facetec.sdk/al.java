package com.facetec.sdk;

import android.hardware.Camera;
import android.view.View;
import android.view.ViewGroup;

/* JADX INFO: loaded from: classes4.dex */
final class al extends ah {
    public al() {
        throw new RuntimeException("Not supported");
    }

    public static boolean o() {
        return false;
    }

    @Override // com.facetec.sdk.ah
    public final void a() {
    }

    @Override // com.facetec.sdk.ah
    public final void b() {
    }

    @Override // com.facetec.sdk.ah
    public final View c() {
        return null;
    }

    @Override // com.facetec.sdk.ah
    public final void d() {
    }

    @Override // com.facetec.sdk.ah
    public final void e(Camera.PictureCallback pictureCallback) {
    }

    @Override // com.facetec.sdk.ah
    public final void a(boolean z) {
    }

    @Override // com.facetec.sdk.ah
    public final void b(boolean z) {
    }

    @Override // com.facetec.sdk.ah
    public final void c(ViewGroup viewGroup) {
    }

    @Override // com.facetec.sdk.ah
    public final void d(boolean z) {
    }

    @Override // com.facetec.sdk.ah
    public final void c(boolean z, ViewGroup viewGroup) {
    }
}