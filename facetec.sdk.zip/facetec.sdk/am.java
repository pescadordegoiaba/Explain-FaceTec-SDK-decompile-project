package com.facetec.sdk;

import android.app.Activity;
import android.content.Context;
import android.graphics.Color;
import android.graphics.Matrix;
import android.graphics.Point;
import android.graphics.RectF;
import android.graphics.SurfaceTexture;
import android.graphics.drawable.Drawable;
import android.hardware.Camera;
import android.hardware.camera2.CameraAccessException;
import android.hardware.camera2.CameraCaptureSession;
import android.hardware.camera2.CameraCharacteristics;
import android.hardware.camera2.CameraDevice;
import android.hardware.camera2.CameraManager;
import android.hardware.camera2.CaptureFailure;
import android.hardware.camera2.CaptureRequest;
import android.hardware.camera2.TotalCaptureResult;
import android.hardware.camera2.params.StreamConfigurationMap;
import android.os.Build;
import android.os.Handler;
import android.os.HandlerThread;
import android.os.Process;
import android.text.TextUtils;
import android.util.Range;
import android.util.Size;
import android.view.Surface;
import android.view.TextureView;
import android.view.View;
import android.view.ViewConfiguration;
import android.view.ViewGroup;
import android.widget.ExpandableListView;
import androidx.annotation.NonNull;
import com.facetec.sdk.ah;
import com.facetec.sdk.ak;
import com.facetec.sdk.cb;
import com.facetec.sdk.nf;
import com.incode.welcome_sdk.modules.SelfieScan;
import com.plaid.internal.EnumC41897g;
import java.lang.ref.WeakReference;
import java.lang.reflect.Method;
import java.nio.ByteBuffer;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.List;
import java.util.concurrent.Semaphore;
import java.util.concurrent.TimeUnit;
import kotlin.C6852;
import org.bouncycastle.i18n.LocalizedMessage;
import org.jmrtd.PassportService;
import org.json.JSONException;
import org.json.JSONObject;

/* JADX INFO: loaded from: classes4.dex */
final class am extends ah {
    private static final byte[] $$a = null;
    private static final int $$b = 0;
    private static final byte[] $$c = null;
    private static final int $$d = 0;
    private static Boolean O;
    private static Boolean P;
    private static Surface R;
    private static int T;
    private static /* synthetic */ boolean U;
    private static int V;
    private static char[] X;
    private static final byte[] Y = null;
    private static final int aa = 0;
    private static long ab;
    private int A;
    private CameraCaptureSession B;
    private HandlerThread C;
    private CameraDevice D;
    private CaptureRequest.Builder F;
    private Object G;
    private Handler I;
    private final TextureView.SurfaceTextureListener W;
    private final WeakReference<bm> p;
    private String w;
    private final g x;
    private final ar y;
    private CameraCharacteristics z;
    private final eh u = new eh() { // from class: com.facetec.sdk.凤
        @Override // com.facetec.sdk.eh
        public final void oia(Object obj) throws Throwable {
            this.f7116.b(obj);
        }
    };
    private final Semaphore v = new Semaphore(1);
    private boolean E = false;
    private boolean H = false;
    private boolean K = false;
    boolean k = false;
    int m = 0;
    int t = 0;
    int s = 0;
    private boolean M = false;
    int q = 0;
    private boolean N = false;
    private boolean L = false;
    private boolean J = false;
    private CameraCaptureSession.StateCallback S = new CameraCaptureSession.StateCallback() { // from class: com.facetec.sdk.am.1
        @Override // android.hardware.camera2.CameraCaptureSession.StateCallback
        public final void onConfigureFailed(@NonNull CameraCaptureSession cameraCaptureSession) {
            am.e(am.this, c.CAMERA_CONFIGURE_FAILED_DEFAULT, "");
        }

        @Override // android.hardware.camera2.CameraCaptureSession.StateCallback
        public final void onConfigured(@NonNull CameraCaptureSession cameraCaptureSession) {
            ba.d("CTCCST");
            am.d(am.this, cameraCaptureSession);
        }

        @Override // android.hardware.camera2.CameraCaptureSession.StateCallback
        public final void onReady(@NonNull CameraCaptureSession cameraCaptureSession) {
            super.onReady(cameraCaptureSession);
            am.e(am.this);
            if (!am.this.L || am.this.F == null || am.this.B == null) {
                return;
            }
            am.d(am.this);
            try {
                am.this.B.setRepeatingRequest(am.this.F.build(), am.this.r, null);
            } catch (Exception unused) {
            }
        }
    };
    CameraCaptureSession.CaptureCallback r = new CameraCaptureSession.CaptureCallback() { // from class: com.facetec.sdk.am.2
        @Override // android.hardware.camera2.CameraCaptureSession.CaptureCallback
        public final void onCaptureCompleted(@NonNull CameraCaptureSession cameraCaptureSession, @NonNull CaptureRequest captureRequest, @NonNull TotalCaptureResult totalCaptureResult) {
            super.onCaptureCompleted(cameraCaptureSession, captureRequest, totalCaptureResult);
            am amVar = am.this;
            if (!amVar.k) {
                amVar.k = true;
            }
            if (amVar.s > 1) {
                c cVar = c.CAMERA_CAPTURE_FAILED_DEFAULT;
                StringBuilder sb = new StringBuilder("Capture Complete After No Data Consec. Fails:  ");
                sb.append(am.this.t);
                am.e(amVar, cVar, sb.toString());
            }
            am amVar2 = am.this;
            amVar2.t = 0;
            amVar2.s = 0;
            amVar2.q = 0;
        }

        @Override // android.hardware.camera2.CameraCaptureSession.CaptureCallback
        public final void onCaptureFailed(@NonNull CameraCaptureSession cameraCaptureSession, @NonNull CaptureRequest captureRequest, @NonNull CaptureFailure captureFailure) {
            super.onCaptureFailed(cameraCaptureSession, captureRequest, captureFailure);
            if (captureFailure.getReason() == 1) {
                return;
            }
            am amVar = am.this;
            if (amVar.m == 0) {
                if (!amVar.k && !captureFailure.wasImageCaptured()) {
                    am.e(am.this, c.CAMERA_CAPTURE_FAILED_DEFAULT, "Fallback To Legacy Camera");
                    am.e(am.this, c.CAMERA_CAPTURE_FAILED_ATTEMPT_FALLBACK, ah.g());
                }
            } else if (amVar.s != 1 || captureFailure.wasImageCaptured()) {
                am amVar2 = am.this;
                if (amVar2.t == 20) {
                    c cVar = c.CAMERA_CAPTURE_FAILED_DEFAULT;
                    StringBuilder sb = new StringBuilder("Camera Capture Hang Detected -- Consec. Fails:  ");
                    sb.append(am.this.t + 1);
                    sb.append(" | Captured: ");
                    sb.append(captureFailure.wasImageCaptured());
                    am.e(amVar2, cVar, sb.toString());
                }
            } else {
                am amVar3 = am.this;
                c cVar2 = c.CAMERA_CAPTURE_FAILED_DEFAULT;
                StringBuilder sb2 = new StringBuilder("Detected No Data Consec. Fails:  ");
                sb2.append(am.this.s + 1);
                sb2.append(" | Consec. Fails:  ");
                sb2.append(am.this.t + 1);
                sb2.append(" | Captured: ");
                sb2.append(captureFailure.wasImageCaptured());
                am.e(amVar3, cVar2, sb2.toString());
            }
            if (!captureFailure.wasImageCaptured()) {
                am.this.s++;
            }
            am amVar4 = am.this;
            amVar4.m++;
            int i = amVar4.t + 1;
            amVar4.t = i;
            o.e = Math.max(i, o.e);
            o.f95927g = Math.max(am.this.s, o.f95927g);
        }
    };
    private final CameraDevice.StateCallback Q = new CameraDevice.StateCallback() { // from class: com.facetec.sdk.am.5
        @Override // android.hardware.camera2.CameraDevice.StateCallback
        public final void onClosed(@NonNull CameraDevice cameraDevice) throws Throwable {
            am.j(am.this);
        }

        @Override // android.hardware.camera2.CameraDevice.StateCallback
        public final void onDisconnected(@NonNull CameraDevice cameraDevice) {
            am.b(am.this, cameraDevice);
        }

        @Override // android.hardware.camera2.CameraDevice.StateCallback
        public final void onError(@NonNull CameraDevice cameraDevice, int i) {
            am.c(am.this, cameraDevice, i);
        }

        @Override // android.hardware.camera2.CameraDevice.StateCallback
        public final void onOpened(@NonNull CameraDevice cameraDevice) {
            ba.d("CTOT");
            am.c(am.this, cameraDevice);
        }
    };

    /* JADX INFO: renamed from: com.facetec.sdk.am$3, reason: invalid class name */
    public class AnonymousClass3 implements TextureView.SurfaceTextureListener {
        public static int c;
        public static int e;

        public AnonymousClass3() {
        }

        public static int d() {
            int i = e;
            int i2 = i % 7741189;
            e = i + 1;
            if (i2 != 0) {
                return c;
            }
            int iFreeMemory = (int) Runtime.getRuntime().freeMemory();
            c = iFreeMemory;
            return iFreeMemory;
        }

        @Override // android.view.TextureView.SurfaceTextureListener
        public final void onSurfaceTextureAvailable(SurfaceTexture surfaceTexture, int i, int i2) {
            am.d(am.this, i, i2);
        }

        @Override // android.view.TextureView.SurfaceTextureListener
        public final boolean onSurfaceTextureDestroyed(SurfaceTexture surfaceTexture) {
            try {
                am.this.e(false);
                return true;
            } catch (Exception unused) {
                return true;
            }
        }

        @Override // android.view.TextureView.SurfaceTextureListener
        public final void onSurfaceTextureSizeChanged(SurfaceTexture surfaceTexture, int i, int i2) {
            am.this.e(i, i2);
        }

        @Override // android.view.TextureView.SurfaceTextureListener
        public final void onSurfaceTextureUpdated(SurfaceTexture surfaceTexture) {
        }
    }

    public static class e {
        String a;
        boolean c = false;
        CameraCharacteristics d;
        StreamConfigurationMap e;
    }

    /* JADX WARN: Removed duplicated region for block: B:10:0x0023  */
    /* JADX WARN: Removed duplicated region for block: B:8:0x001d  */
    /* JADX WARN: Unsupported multi-entry loop pattern (BACK_EDGE: B:10:0x0023 -> B:11:0x002a). Please report as a decompilation issue!!! */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    private static java.lang.String $$e(byte r6, short r7, int r8) {
        /*
            int r7 = 111 - r7
            byte[] r0 = com.facetec.sdk.am.$$c
            int r6 = r6 * 2
            int r6 = r6 + 1
            int r8 = r8 * 3
            int r8 = r8 + 4
            byte[] r1 = new byte[r6]
            r2 = 0
            if (r0 != 0) goto L15
            r3 = r0
            r4 = r2
            r0 = r8
            goto L2a
        L15:
            r3 = r2
        L16:
            byte r4 = (byte) r7
            r1[r3] = r4
            int r3 = r3 + 1
            if (r3 != r6) goto L23
            java.lang.String r6 = new java.lang.String
            r6.<init>(r1, r2)
            return r6
        L23:
            r4 = r0[r8]
            r5 = r0
            r0 = r7
            r7 = r4
            r4 = r3
            r3 = r5
        L2a:
            int r8 = r8 + 1
            int r7 = -r7
            int r7 = r7 + r0
            r0 = r3
            r3 = r4
            goto L16
        */
        throw new UnsupportedOperationException("Method not decompiled: com.facetec.sdk.am.$$e(byte, short, int):java.lang.String");
    }

    static {
        init$1();
        init$0();
        n();
        l();
        V = 0;
        T = 1;
        U = true;
        R = null;
        O = null;
        P = null;
    }

    public am(Activity activity) throws Throwable {
        AnonymousClass3 anonymousClass3 = new AnonymousClass3();
        this.W = anonymousClass3;
        this.p = new WeakReference<>((bm) activity);
        if (bj.i) {
            this.y = ah.h();
        } else {
            this.y = ah.f();
        }
        g gVar = new g(activity);
        this.x = gVar;
        HandlerThread handlerThread = new HandlerThread("CameraBackground");
        this.C = handlerThread;
        handlerThread.start();
        this.I = new Handler(this.C.getLooper());
        if (gVar.isAvailable()) {
            c(activity, gVar.getWidth(), gVar.getHeight());
        } else {
            gVar.setSurfaceTextureListener(anonymousClass3);
        }
    }

    /* JADX WARN: Removed duplicated region for block: B:10:0x0026  */
    /* JADX WARN: Removed duplicated region for block: B:8:0x001e  */
    /* JADX WARN: Unsupported multi-entry loop pattern (BACK_EDGE: B:10:0x0026 -> B:11:0x002d). Please report as a decompilation issue!!! */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    private static void Z(int r7, int r8, int r9, java.lang.Object[] r10) {
        /*
            byte[] r0 = com.facetec.sdk.am.Y
            int r9 = 775 - r9
            int r8 = r8 + 91
            int r7 = r7 + 3
            byte[] r1 = new byte[r7]
            r2 = 0
            if (r0 != 0) goto L11
            r3 = r0
            r4 = r2
            r0 = r9
            goto L2d
        L11:
            r3 = r9
            r9 = r8
            r8 = r3
            r3 = r2
        L15:
            int r4 = r3 + 1
            byte r5 = (byte) r9
            r1[r3] = r5
            int r8 = r8 + 1
            if (r4 != r7) goto L26
            java.lang.String r7 = new java.lang.String
            r7.<init>(r1, r2)
            r10[r2] = r7
            return
        L26:
            r3 = r0[r8]
            r6 = r9
            r9 = r8
            r8 = r3
            r3 = r0
            r0 = r6
        L2d:
            int r8 = r8 + r0
            r0 = r9
            r9 = r8
            r8 = r0
            r0 = r3
            r3 = r4
            goto L15
        */
        throw new UnsupportedOperationException("Method not decompiled: com.facetec.sdk.am.Z(int, int, int, java.lang.Object[]):void");
    }

    /* JADX WARN: Removed duplicated region for block: B:35:0x016c  */
    /* JADX WARN: Removed duplicated region for block: B:36:0x016d  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    private static void ac(int r24, char r25, int r26, java.lang.Object[] r27) throws java.lang.Throwable {
        /*
            Method dump skipped, instruction units count: 374
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: com.facetec.sdk.am.ac(int, char, int, java.lang.Object[]):void");
    }

    /* JADX WARN: Removed duplicated region for block: B:10:0x002a  */
    /* JADX WARN: Removed duplicated region for block: B:8:0x0022  */
    /* JADX WARN: Unsupported multi-entry loop pattern (BACK_EDGE: B:10:0x002a -> B:11:0x0031). Please report as a decompilation issue!!! */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    private static void ad(byte r6, byte r7, short r8, java.lang.Object[] r9) {
        /*
            byte[] r0 = com.facetec.sdk.am.$$a
            int r7 = r7 + 4
            int r6 = r6 * 2
            int r1 = 1 - r6
            int r8 = 99 - r8
            byte[] r1 = new byte[r1]
            r2 = 0
            int r6 = 0 - r6
            r3 = -1
            if (r0 != 0) goto L16
            r4 = r3
            r3 = r0
            r0 = r7
            goto L31
        L16:
            r5 = r8
            r8 = r7
            r7 = r5
        L19:
            int r3 = r3 + 1
            byte r4 = (byte) r7
            r1[r3] = r4
            int r8 = r8 + 1
            if (r3 != r6) goto L2a
            java.lang.String r6 = new java.lang.String
            r6.<init>(r1, r2)
            r9[r2] = r6
            return
        L2a:
            r4 = r0[r8]
            r5 = r0
            r0 = r8
            r8 = r4
            r4 = r3
            r3 = r5
        L31:
            int r8 = -r8
            int r7 = r7 + r8
            r8 = r0
            r0 = r3
            r3 = r4
            goto L19
        */
        throw new UnsupportedOperationException("Method not decompiled: com.facetec.sdk.am.ad(byte, byte, short, java.lang.Object[]):void");
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Removed duplicated region for block: B:438:0x1157  */
    /* JADX WARN: Removed duplicated region for block: B:443:0x1164  */
    /* JADX WARN: Removed duplicated region for block: B:450:0x118d  */
    /* JADX WARN: Removed duplicated region for block: B:53:0x03ee A[PHI: r0
      0x03ee: PHI (r0v104 int) = (r0v17 int), (r0v17 int), (r0v100 int), (r0v17 int) binds: [B:83:0x048e, B:62:0x040a, B:63:0x040c, B:51:0x03ea] A[DONT_GENERATE, DONT_INLINE]] */
    /* JADX WARN: Type inference failed for: r19v0 */
    /* JADX WARN: Type inference failed for: r19v1 */
    /* JADX WARN: Type inference failed for: r19v10 */
    /* JADX WARN: Type inference failed for: r19v11 */
    /* JADX WARN: Type inference failed for: r19v12 */
    /* JADX WARN: Type inference failed for: r19v13 */
    /* JADX WARN: Type inference failed for: r19v14 */
    /* JADX WARN: Type inference failed for: r19v15 */
    /* JADX WARN: Type inference failed for: r19v2 */
    /* JADX WARN: Type inference failed for: r19v3 */
    /* JADX WARN: Type inference failed for: r19v41 */
    /* JADX WARN: Type inference failed for: r19v42 */
    /* JADX WARN: Type inference failed for: r19v43 */
    /* JADX WARN: Type inference failed for: r19v44 */
    /* JADX WARN: Type inference failed for: r19v45 */
    /* JADX WARN: Type inference failed for: r19v46 */
    /* JADX WARN: Type inference failed for: r19v47 */
    /* JADX WARN: Type inference failed for: r19v48 */
    /* JADX WARN: Type inference failed for: r19v49 */
    /* JADX WARN: Type inference failed for: r19v50 */
    /* JADX WARN: Type inference failed for: r19v51 */
    /* JADX WARN: Type inference failed for: r6v163 */
    /* JADX WARN: Type inference failed for: r6v164, types: [boolean] */
    /* JADX WARN: Type inference failed for: r6v165 */
    /* JADX WARN: Type inference failed for: r7v11 */
    /* JADX WARN: Type inference failed for: r7v14, types: [int] */
    /* JADX WARN: Type inference failed for: r7v157 */
    /* JADX WARN: Type inference failed for: r7v16 */
    /* JADX WARN: Type inference failed for: r7v17 */
    /* JADX WARN: Type inference failed for: r7v18 */
    /* JADX WARN: Type inference failed for: r7v183 */
    /* JADX WARN: Type inference failed for: r7v184 */
    /* JADX WARN: Type inference failed for: r7v185 */
    /* JADX WARN: Type inference failed for: r7v27, types: [java.lang.reflect.Constructor] */
    /* JADX WARN: Type inference failed for: r7v28 */
    /* JADX WARN: Type inference failed for: r7v29 */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    private void b(android.content.Context r38, android.hardware.camera2.params.StreamConfigurationMap r39) throws java.lang.Throwable {
        /*
            Method dump skipped, instruction units count: 4776
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: com.facetec.sdk.am.b(android.content.Context, android.hardware.camera2.params.StreamConfigurationMap):void");
    }

    private static e g(Context context) {
        return a(context, 1);
    }

    public static ar h(Context context) {
        return d(context, g(context));
    }

    private static CameraManager i(Context context) {
        return (CameraManager) context.getApplicationContext().getSystemService("camera");
    }

    public static void init$0() {
        $$a = new byte[]{120, PassportService.SFI_DG11, 65, 93};
        $$b = EnumC41897g.SDK_ASSET_ILLUSTRATION_BUBBLES_QUESTION_VALUE;
    }

    public static void init$1() {
        $$c = new byte[]{119, -27, PassportService.SFI_DG13, -93};
        $$d = 224;
    }

    public static ar j(Context context) {
        return d(context, f(context));
    }

    private void k() throws Throwable {
        if (this.N) {
            int i = this.q;
            if (i > 0) {
                e(ao.aq);
                return;
            }
            this.N = false;
            this.q = i + 1;
            if (!this.x.isAvailable()) {
                e(ao.aw);
                return;
            }
            try {
                bm bmVar = this.p.get();
                if (bmVar != null) {
                    c(bmVar, this.x.getWidth(), this.x.getHeight());
                }
            } catch (ak unused) {
                e(ao.an);
            }
        }
    }

    public static void l() {
        char[] cArr = new char[1657];
        ByteBuffer.wrap("#õ9H\u0016¶l\u000fIp¦Ð¼,\u0099\u0093öýÌB)¾\u0007\u001e\u001c`yÙW;¬\u0082\u0089äçDü¼Ú\u00077a\fÚj\"G\u0082\\õºM\u0097¶í\u000fÊs'É=+\u001a\u009fwÔM4ª\u0083\u0087÷\u009dHú±Ð\u0013-n\nÀ`=}\u009fZâ°E\u008d¹ë\u001bÀfÝÚ;%\u0010\u0093mçKA ¼¾\u001d\u009bcðÍÎ0+\u0096\u0000ï\u001eI{´Q\u0013®k\u008bµá\bþlÛ×1-\u000e\u008ckòAR^¡´\u0006\u0091~îÂÄ&!\u0099>ç\u0014Dq¤O\u0004¤{\u0081Ó\u009f ô\u0080Ñÿ/V\u0004¬b\f\u007fpTÓ²(\u008f\u0088äôÂVß\u00944è\u0012No·E\u0011¢o¿Ì\u00953ò\u0084Ïý%_\u0002¡\u0018\u0007uyRÛ¨%\u0085\u009câåø[Õ¾3\u0000\b`eÜC:X\u008cµì\u0093PèµÆ\b#t8Ð\u0016+siHÎ¦6\u0083\u008a\u0098äöQÓ³)\r\u0006gcÝy#V\u008a³ø\u0089Xæ¤ü\u0006Ùd6Ø\f3i\u0087Fá\\_¹¿\u0097\u0003ìmÉÓ':<\u008f\u0019öwULªª\u0015\u0087I\u009cµú\u0017×i,Å\n1g\u008f|éZ\\·£\u008d\u0000ê\u007fÇÙÝ&:\u0086\u0017ûmEJº \u001b½g\u009aÁð>Í\u009c*ã\u0000M\u001d²{\u0011Po\u00adÉ\u008b3à\u008aýêÛ/0\u0095\rèkO@°^\u000f»k\u0090Óî!Ë\u0089 þ>^\u001b¡q\u0019N{«Ä\u0081<\u009e\u0085ûøÑ]. \u0004\u001fay~ÃT-±\u0092\u008e÷äOÁµß\u00134j\u0011Õo\nDu¡×¿(\u0094\u008aññÏS$¬\u0002\u0007\u001f}tßR ¯\u008c\u0084ùâ[ÿ¤Õ\u00102e\u000fÇe9B\u0094_áµ\\\u0092¶è\fÅr\"Ò8/\u0015\u0096ròHJ¥ª\u0082ê\u0098@õ¶Ó\n(j\u0005Ñc,x\u008dUü³\\\u0088¡æ\nÃxØØ6\"\u0013\u0087häFD£¾¹\u001a\u0096`óÀÉ=&\u009c\u0003ì\u0019Pv»L\u000f©w\u0086Ô\u009c*ù\u008aÖÌ,+\t\u0096fê|DY±·\u0013\u008cméÁÇ=Ü\u009f9ç\u0017Gl¹J\u0005§d¼Ä\u009a$÷\u009eÌÿ*@\u0007¾\u001d\u001azcWÍ\u00ad5\u008a\u0096çïýIÚ±0\u0013\rkj¯@\u0015]wºÏ\u0090*í\u0091Êí J=¼\u001b\u001cpfMÅE\fâ{øÆ×8\u00ad\u0081\u0088þg^}¢X\u001d7s\rÌè0Æ\u0090Ýî¸W\u0096µm\fHj&Ô=3\u001b\u0089öïÍU«¬\u0086\u0015\u009db{ÂV;,\u0081\u000bçæSü¤Û\u0004¶O\u008c»k\u0019Fd\\Â;?\u0011\u0084ìýËS¡¨¼\u0010\u009biqÖL6*\u0089\u0001è\u001cJúªÑ\u0015¬w\u008aÎa.\u007f\u0091Zò1B\u000f¢ê\u001dÁyßÆº:\u0090\u009eoåJ' \u0081?ø\u001aFð«Ï\u001fª}\u0080À\u009f+u\u0093Pè/M\u0005¶à\bÿaÕÕ°+\u008e\u0096eô@I^³5\u001a\u0010lîÌÅ?£\u0099¾à\u0095@s»N\u001c%d\u0003Ý\u001e\u0007õ{ÓÆ®$\u0084\u009ecþ~AT©3\u0012\u000enäËÃ1Ù\u0097´ê\u0093AiµD\u000b#u9Ô\u0014)ò\u008fÉñ¤Q\u0082\u00ad\u0099\u001at}RÀ)?\u0007\u0098âçùY×±²ú\u0089Zg¥B\u0005Y~7Þ\u0012\"è\u0083Çò¢K¸¯\u0097\u0011riHË'4=\u008d\u0018ò÷KÍ¶¨\u0014\u0087n\u009dÎx2V\u0092-â\b^æºý\u0001Øx¶Ù\u008d$k\u0084FÄ]#;\u0098\u0016øí@Ë¦¦\u001c½|\u009bÌv)L\u0090+ð\u0006H\u001c¬û\u0014Öh¬ß\u008b+a\u0097|ô[N1®\f\u0012ëyÁÂÜ>º\u0094\u0091álGJº!\u001e<e\u001a»ñ\u0005ÌmªÙ\u0081&\u009f\u0086züQ\\/\u00ad\n\u000fápÿÉÚ,°\u0097\u008fõjJ@¶_\u000b:i\u0010Öï3Å\u008f ô¿V\u0095¢p\u0002O\u007f%ß\u0000&\u001e\u009fõðÐE®\u009b\u0085ä`F~¹U\u001f0`\u000eÃå=Ã\u008dÞêµP\u0093°n\tEo#Ô>.\u0014\u008aóêÎW¤±gÜ}aR\u009f(#\rDâøø\u001aÝ¤²Õ\u0088um\u0088C6XL=î\u0013\u0013è¯ÍÒ£l¸\u008e\u009e6sIHé.\u0012\u0003ª\u0018Äþ~Ó\u0087©;\u008e\\cày\u001b^·3ý\t\u001dî¤ÃÞÙx¾\u008c\u0094;i[Nà$\u00149¶\u001eËômÉ\u0090¯2\u0084O\u0099ð\u007f\fT®)Ó\u000fwä\u0088ú2ßV´å\u008a\u0005oºDÙZa?\u0099\u0015>êBÏ\u0084¥\"º_\u009fáu\u0000J¸/Â\u0005e\u001a\u0095ð5ÕJªî\u0080\u0011e©zËPr5\u0094\u000b6àOÅïÛ\u0014°±\u0095Ëkk@\u0098&>;G\u0010çö\u001cË» Ã\u0086c\u009b pÈV\u007f+\u0087\u0001\"æXûâÑ\u0002¶µ\u008bÍacF\u0096\\01M\u0016æì\u0012Á¬¦Ò¼s\u0091\u008ew(LV!ö\u0007\n\u001c¤ñÚ×y¬\u0086\u00828gU|ãR\u001b7I\füâ\u001eÇ ÜÆ²x\u0097\u009am$BI'ô=\u0016\u0012¨÷ÉÍp¢\u0089¸.\u009dMröH\u0012-®\u0002È\u0018vý\u0092Ó*¨D\u008dúc\u001dx¦]Û3~\b\u0083î#ÃcØ\u0087¾?\u0093_hçN\f#»8Û\u001ekó\u0081É7®M\u0083ñ\u0099\u0011~¬SÎ)m\u000e\u0096ä0ùNÞè´\u0017\u0089¶nÊD\u007fY\u009c?'\u0014GéþÏ\u001c¤£¹Ø\u009f\u0004t¼IÅ/d\u0004\u0099\u001a\"ÿ@Ôúª\u0014\u008f«dÉzv_\u00905/\nLïòÅ\u0017Ú¸¿Ï\u0095sj\u0093@(%J:õ\u0010\u001dõ¤ÊÆ y\u0085\u0098\u009b pBUý+'\u0000\\åäû\u001eÐ µÆ\u008b{`\u009bF*[O0÷\u0016\rë\u00adÀÐ¦r»\u008f\u00915vLKõ!\u0014\u0006©\u001bÉñtÖ\u009e¬%\u0081Yfý|\u0006Q 6ß\fvá\u0082ÆÜÜd±\u0083\u0097>lXAà'\u0006<º\u0011Î÷jÌ\u0097¢7\u0087I\u009cîr\u0013W³,Õ\u0002qç\u008fý/ÒQ·÷\u008d\u000bb±GÅ]e2\u009f\b>íAÂÿØ\u001a½¢\u0092üh\u0004M¦\"Þ8`\u001d\u0087ó;È[\u00adí\u0083\u000e\u0098·}ÏSi(\u0090\u000e2ãJøöÞ\f³®\u0088Ön}C\u0088Y*>R\u0013ðé\u0004Î¦£ß¹}\u009e\u0080t\"I[.\u0080\u0004<\u0019DþáÔ\u0019©£\u008eÃdzy\u0094_-4I\töï\u0010Ä©ÙÌ¿r\u0094\u0096j5OO$ï:\u0010\u001f°ôËÊq¯\u009f\u0085$\u009aF\u007fÿU\u0018* \u000fÂå{ú§ßÜµd\u008a\u0085`9EYZâ0\u0003\u0015µêÕÀn¥\u008d»1\u0090KuçK\u0012 ¶\u0005Ù\u001boð\u008fÖ4«]\u0080ëf\u001e{¹PÄ6f\u000b\u0098á>Æ@Û÷±\u001f\u0096]kèA\u0001&¾;Ä\u0011bö\u009bÌ.¡J\u0086ô\u009c\u0003q®VÑ,j\u0001\u0089ç2üPÑò·\u000f\u008cºaÐGh\\\u009423\u0017EìðÂ\u001d§¦¼À\u0092yw\u0097M\"\"i\u0007\u0087\u001d?òJ×í\u00ad\u0018\u0082ºgÃ}`R\u0094(6\rLâíø\u0010Ý²²È\u0088pm\u008cC;X[=é\u0013\u0015èµÍÊ£p¸\u0098\u009e'sGHÿ.\u001f\u0003£\u0018×þ\u0000Ó¼¨Þ\u008ecc\u008cy8^N3ä\t\u0015î¬ÃÏÙv¾\u0084\u0094/iSNó$\u00179²\u001eÏôoÉ\u0093¯7\u0084K\u0099ë\u007f\u001fT¼)Ç\u000fsä\u0098ú ßB´ø\u008a$o\\DþZ\u0004?£\u0014ØêzÏ\u0080¥-ºT\u009fâu\u000bJ±/Ñ\u0005n\u001a\u0087ð-ÕWªû\u0080\u000ee¼zÕPk5\u008b\u000b;à[ÅçÛ\u001d°µ\u0095Àkv@\u0098%Ý;i\u0010\u0084ö>ËL í\u0086\u001b\u009b»pÏVo+\u0097\u0001+æMûíÑ\u0013¶³\u008b×axF\u008f\\/1S\u0016ýì\u000bÁ«¦Þ¼x\u0091\u0087w3L\\!à\u0007\u001e\u001c¾ñã×\u001c¬¢\u0081Âgd|\u0098R:7A\fèâ\u0014Ç¶ÜÍ²o\u0097\u0090m2BI'ò=\f\u0012²÷ÒÍv¢\u0088¸*\u009dQrýH\u0004-º\u0002Û\u0018aý\u0081Ó8¨[\u008d\u009dc=xD]ä3\u0019\b¹íÀÃaØ\u0095¾)\u0093KhîN\u0011#±8È\u001eió\u008dÉ-®T\u0083ú\u0099\t~µSÖ)j\u000e\u0084ä?ùRÞæ´\u001c\u0089¼nÚDbY¼>Å\u0014eé\u009eÏ$¤E¹û\u009f\u001bt¬IÏ/w\u0004\u0097\u001a(ÿHÔóª\u000f\u008f²dÌzn_\u00955=\nHïöÅ\u0017Ú¥¿Å\u0095zj\u0093@!%]:þ\u0010\u0002õ\\Êâ \u0000\u0085¾\u009aØplU\u0087+:\u0000Tåàû\nÐ¶µÐ\u008bm`\u0087F2[P0ñ\u0016\u000fë¯ÀÔ¦}»\u008b\u0091+v[Kø!\u0007\u0006§\u001bßñ}Ö\u0083¬#\u0081cf\u0082|?QC6ä\f\u0018áºÆÄÜj±\u0094\u00976lHAí'\u0010<²\u0011Ì÷uÌ\u008c¢.\u0087Z\u009c÷r\bW¶,Ö\u0002\u007fç\u0084ý:Ò[·á\u008d\u0001b·GÝ]\u001d2½\u0017ËífÂ\u0099Ø ½[\u0092ûh\u0001M\u00ad\"×8w\u001d\u0085ó*ÈS\u00adó\u0083\u0019\u0098·}ÏSo(\u009d\u000e<ãKøòÞ\u0005³¥\u0088ÓnsC\u0081Y8>C\u0013ãé(Î@£ÿ¹\u001f\u009e¬sÅI{.\u009b\u0004!\u0019@þ÷Ô\u0017©¤\u008eÎdsy\u0087_-4M\túï\u0011Ä©ÙÉ¿~\u0094\u0092j%OE$ò:\u001f\u001f¡ôÝÊ~¯\u0082\u0084Ü\u009ai\u007f\u0085U>*X\u000fíå\u0000úºßÔµj\u008a\u0089`6ELZì0\b\u0015²êÌÀy¥\u009b».\u0090HuõK\u0015 ª\u0005Ý\u001bxð\u0087Ö9«T\u0080àf\u0002{·Pè6\u001c\u000b¢àÄÆyÛ\u0085±!\u0096ZkêA\u0001&·;×\u0011iö\u0088Ì3¡O\u0086÷\u009c\fq²VÔ,i\u0001\u0097ç>üJÑä·\u001d\u008c³aÆG`\\\u009d2?\u0017^ì\u009dÂ!§C¼ê\u0092\u0019w LÃ\"z\u0007\u008b\u001d)òW×÷\u00ad\f\u0082¬gÎ}rR\u0090(7\rOâïø\u0014Ý´²Õ\u0088jm\u0084C9X[=ù\u0013\u0001è¡ÍÞ£~¸¥\u009dÜs~H\u0083.%\u0003@\u0018ûþ\u001bÓ¨¨È\u008ekc\u0096y,^L3æ\t\u0012î°ÃÑÙs¾\u008e\u00947iVNë$\u000b9¸\u001eØôzÉ\u0086¯<\u0084Z\u0099ã\u007f\u001cTC)ü\u000f\u001eä£ùÅßa´\u009b\u008a;oHDèZ\r?¶\u0014ÐêmÏ\u008f¥)ºM\u009fíu\u0012J°/É\u0005u\u001a\u0096ð*ÕDªú\u0080\u0007e§zÞP`5\u0096\u000b\"à`Å\u0081Û\"°^\u0095äk\f@»%Û;h\u0010\u0088ö#ËV ð\u0086\r\u009b¯pÇVm+\u008d\u0001;æNûèÑ\u0015¶¶\u008bÖaeF\u0099\\:1X\u0016áì\u001fÁ¿¦Â¼\u0000\u0091¡vÀL~!\u0087\u0007&\u001c[ñû×\b¬©\u0081Êgv|\u008cR*7S\fìâ\u0013Ç¬ÜÎ²s\u0097\u0094m6BK'ë=\u0018\u0012¹÷ØÍf¢\u0080¸=\u009d^rúH=-]\u0002â\u0018\u0003ý¡ÒØ¨z\u008d\u0087c(xM]÷3\u000b\b¬íÎÃsØ\u0093¾0\u0093QhõN\u000e#´8Õ\u001esó\u008aÉ$®Y\u0083ú\u0099\u001c~¡SÁ)~\u000e\u009fãÆù|Þ\u0084´>\u0089XnåD\u0006Y®>Õ\u0014ké\u008eÏ6¤P¹í\u009f\u000et¦IÍ/m\u0004\u0092\u001a3ÿ\\Ôèª\u0010\u008fªdÄzy_\u00995:\nAïÿÅ\u001aÚ¢¿ü\u0095\u0001j¡OÂ%y:\u0099\u0010&õDÊè \u0014\u0085¨\u009aÏpqU\u0091+.\u0000Låóû\fÐ´µÎ\u008bh`\u0095F5[T".getBytes(LocalizedMessage.DEFAULT_ENCODING)).asCharBuffer().get(cArr, 0, 1657);
        X = cArr;
        ab = -630043547879671561L;
    }

    public static void n() {
        byte[] bArr = new byte[801];
        System.arraycopy("0V:G\rö\u000eýúûÊHóü\u0012·(\u0013ü\u0012Ì,ÿø\u0003þ\u000eýï\u0013õ\u0006ÿþ\u000fÒ\u001b\u0003\u0005\u0005ùÞ\u001f\u0003þç\u0019\tù\rô\rö\u000eýúûÊA\u0004»%&ú\u0001ñ\bÖ)\u0003ô\bû\u0004õ\u0004øè\u001c\u0003\u0000ý\nþ\u000fã\u0012\u0005ö\u000b\bÝ\u001b\u0006î\u0005ë\u0019\u0003\u0001þ\u000fà\r\u000fä\u0015\u0004ø\n\u0006ÿ\rö\u000eýúûÊHóü\u0012·\u001d\u001a\u0014Ì1ï\t\u0006\u0001\u0003ûô\u000bý\u0011ëè\u0018\u000fíò!í\u0013ñ\rö\u000eýúûÊFñ\u0013üº&\u0011\u0013üá\u001fõ\u0003\u0007\u0005ö\u0001\u0013×\u0017÷\u0015ëÍ>õ\rùÇ\u0015%ù\u0011á\u0012\f\u0004ð\tõ\u0002÷\u0015ëÍ>õ\rùÇ%!þ÷\u0005ùýüý\u000b÷\u0015ëÍ>õ\rùÇ\u001b%\u0006ñ\u0002þ\rë\u000b\tðê\u0017\u0005\u0006â\u000b\u000b\tð÷\u0015ëÍ>õ\rùÇDó\u0001È$\u0013\u0001ÿ\ró\tõ\u0002þ\u000fþ\u000fÙ\u0014\u0017ñ\u0004\bø×.ï\u0016ò\u0005ùÜ\u001e\u0002\u0005ýî\u0016\u0011ëþ\u000f×\u001a\u0014Ù\u0013\u000bõü\u0013à\u0015\u0004ø\n\u0006ÿ\rö\u000eýúûÊIòû\u0003þ\u000fº\u00173øñ\röý\u0001\nùç\u001d\n\u0001â\u0013ü\u0012þ\u000fÜ\u0011\u0002\búÿì\u001f\u0004ö\u000bõ\u0006ÿØ)\u0003Õ+ý\u0006ûþ\u000fÙ\u0014\u0017Ó\u001a\u0014Ê,õ\u0001\u0012ý\u0000ó\t\u0006à\u0014\nóü\u0003ð\u0015\u0004øè\u001c\u0003\u0000ý\nõ\u0012\u0001Õ%ö\u0001\u0013×\u0017þ\u000fÜ\u0011\u0002\búÿì\u001f\u0004ö\u000bõ\u0006ÿÕ%\u0001\u0003ø\rö\u000eýúûÊHóü\u0012·(\u0013ü\u0012\fþõ\u0007\u0005÷è\u0018ü\u0012\u0002ýóÿï!í\u0013ñ\u000e\rö\u000eýúûÊDó\tö\u0001\r\u0001ð\u000f÷\u0007\u0004º\u0013+\u0000\u0003ôþ\u0013õ\u0006ÿ\rö\u000eýúûÊ:ù\u0011ò\u0013ê\u0011óÉ5þ\fø\rïÑüBñ\u0011ï\f\u0006»%!þóü\fÖ,ÿø\u0003þ\u000eýï\u0013õ\u0006ÿß\u0014\u000fþ\u000fÛ&ÿü\u0005ÿß\u0016\u0011ë\u000e÷\u0015ëÍGÿõ\u0003Â\u001a\u0019\u0012õå\u0014\u000f÷\u0015ëÍ>õ\rùÇ%!þ÷\u0005ùÛ3ô\u0003ø\u0001\r\rö\u000eýúûÊGÿõ\u0003Â%\u0016\u0011ëþ\u000fã\u0012û\u0010ô\u000f\u0000õ\töþ\u000fÔ\u001d\u0004þ\u0001\f÷\u0015ëÍGÿõ\u0003Â\u0013!\u0011\u0001þï\u0002\u0011Ù\u0014\u000f÷\u0015ëÍ>õ\rùÇ!\u0013\bûþ\u0011÷\u0015ëÍ>õ\rùÇ 'øõ\u0003\r\u0005ÿö\u0011ë÷\u0015ëÍGÿõ\u0003Â\u00131\u0000ï\u0018úü\u0003\u0002ñ\u001e÷\u0015ëÍ>õ\rùÇ!\u0013\bûþ\u0011Ç÷\u0015ëÍGÿõ\u0003Â\u0015,þ\u0003ñ\u0011ï\u0013û\u0003÷\u0015ëÍ>õ\rùÇ&\u0014\ný\bê\u0001\nùþ\u000fÙ\u0018\u000e\u0000î\u0006þ÷\u0015ëÍ>õ\rùÇ$#ù\u0006õ\u0004øà3ë\u0002\u000b\u0004õ\u0006ÿ".getBytes(LocalizedMessage.DEFAULT_ENCODING), 0, bArr, 0, 801);
        Y = bArr;
        aa = EnumC41897g.SDK_ASSET_ICON_PAUSE_VALUE;
    }

    private CaptureRequest.Builder o() throws CameraAccessException {
        try {
            CaptureRequest.Builder builderCreateCaptureRequest = this.D.createCaptureRequest(1);
            builderCreateCaptureRequest.set(CaptureRequest.CONTROL_MODE, 1);
            CaptureRequest.Key key = CaptureRequest.CONTROL_AWB_LOCK;
            Boolean bool = Boolean.FALSE;
            builderCreateCaptureRequest.set(key, bool);
            builderCreateCaptureRequest.set(CaptureRequest.CONTROL_AE_LOCK, bool);
            builderCreateCaptureRequest.set(CaptureRequest.STATISTICS_FACE_DETECT_MODE, 0);
            if (bh.c(ah.e.C2355e.e)) {
                builderCreateCaptureRequest.set(CaptureRequest.CONTROL_SCENE_MODE, 0);
            } else if (d(CameraCharacteristics.CONTROL_AVAILABLE_SCENE_MODES, 11)) {
                builderCreateCaptureRequest.set(CaptureRequest.CONTROL_SCENE_MODE, 11);
            }
            if (bh.c(ah.e.C2355e.j)) {
                CaptureRequest.Key key2 = CaptureRequest.CONTROL_CAPTURE_INTENT;
                if (builderCreateCaptureRequest.get(key2) != null) {
                    builderCreateCaptureRequest.set(key2, 4);
                }
                CaptureRequest.Key key3 = CaptureRequest.CONTROL_AWB_MODE;
                if (builderCreateCaptureRequest.get(key3) != null) {
                    builderCreateCaptureRequest.set(key3, 0);
                }
            }
            if (bh.c(ah.e.C2355e.b)) {
                CaptureRequest.Key key4 = CaptureRequest.EDGE_MODE;
                if (builderCreateCaptureRequest.get(key4) != null) {
                    builderCreateCaptureRequest.set(key4, 0);
                }
                CaptureRequest.Key key5 = CaptureRequest.NOISE_REDUCTION_MODE;
                if (builderCreateCaptureRequest.get(key5) != null) {
                    builderCreateCaptureRequest.set(key5, 0);
                }
            }
            return builderCreateCaptureRequest;
        } catch (IllegalArgumentException e2) {
            if (this.p.get() == null) {
                return null;
            }
            this.p.get().e(e2.toString());
            return null;
        }
    }

    @Override // com.facetec.sdk.ah
    public final void a(boolean z) {
    }

    @Override // com.facetec.sdk.ah
    public final void c(ViewGroup viewGroup) {
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Removed duplicated region for block: B:120:0x04f2  */
    /* JADX WARN: Removed duplicated region for block: B:182:0x0506 A[ADDED_TO_REGION, REMOVE, SYNTHETIC] */
    @Override // com.facetec.sdk.ah
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public final void d() throws java.lang.Throwable {
        /*
            Method dump skipped, instruction units count: 1368
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: com.facetec.sdk.am.d():void");
    }

    @Override // com.facetec.sdk.ah
    public final void e(Camera.PictureCallback pictureCallback) {
    }

    /* JADX INFO: Access modifiers changed from: private */
    /* JADX WARN: Removed duplicated region for block: B:153:0x05a5 A[ADDED_TO_REGION] */
    /* JADX WARN: Removed duplicated region for block: B:155:0x05aa  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public void b(java.lang.Object r25) throws java.lang.Throwable {
        /*
            Method dump skipped, instruction units count: 1574
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: com.facetec.sdk.am.b(java.lang.Object):void");
    }

    public static /* synthetic */ boolean e(am amVar) {
        amVar.J = true;
        return true;
    }

    private static e f(Context context) {
        return a(context, 0);
    }

    @Override // com.facetec.sdk.ah
    public final void c(boolean z, ViewGroup viewGroup) {
    }

    @Override // com.facetec.sdk.ah
    public final void d(boolean z) {
    }

    private static e a(Context context, int i) throws ak {
        CameraCharacteristics cameraCharacteristics;
        Integer num;
        StreamConfigurationMap streamConfigurationMap;
        CameraManager cameraManagerI = i(context);
        try {
            String[] cameraIdList = cameraManagerI.getCameraIdList();
            CameraAccessException e2 = null;
            for (String str : cameraIdList) {
                try {
                    cameraCharacteristics = cameraManagerI.getCameraCharacteristics(str);
                    num = (Integer) cameraCharacteristics.get(CameraCharacteristics.LENS_FACING);
                } catch (CameraAccessException e3) {
                    e2 = e3;
                    e2.getMessage();
                }
                if ((num == null || num.intValue() == i || (Build.MODEL.equals("Lenovo YT3-850F") && cameraIdList.length == 1)) && (streamConfigurationMap = (StreamConfigurationMap) cameraCharacteristics.get(CameraCharacteristics.SCALER_STREAM_CONFIGURATION_MAP)) != null) {
                    Integer num2 = (Integer) cameraCharacteristics.get(CameraCharacteristics.INFO_SUPPORTED_HARDWARE_LEVEL);
                    e eVar = new e();
                    eVar.a = str;
                    eVar.d = cameraCharacteristics;
                    eVar.e = streamConfigurationMap;
                    if (num2.intValue() != 2) {
                        eVar.c = true;
                    }
                    return eVar;
                }
            }
            if (e2 == null) {
                return null;
            }
            throw new ak(ak.b.ACCESS_ERROR, e2);
        } catch (CameraAccessException e4) {
            throw new ak(e4);
        }
    }

    public static /* synthetic */ boolean d(am amVar) {
        amVar.L = false;
        return false;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static /* synthetic */ int e(Size size, Size size2) {
        return Integer.compare(size.getHeight() * size.getWidth(), size2.getHeight() * size2.getWidth());
    }

    public static /* synthetic */ void j(am amVar) throws Throwable {
        amVar.M = true;
        if (ah.l && amVar.N) {
            amVar.k();
        }
    }

    private void b(Activity activity) throws Throwable {
        c(activity, g(activity));
    }

    private void d(Activity activity) throws Throwable {
        c(activity, f(activity));
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void e(boolean z) {
        boolean zTryAcquire;
        try {
            zTryAcquire = this.v.tryAcquire(z ? 1L : 10L, TimeUnit.SECONDS);
        } catch (InterruptedException e2) {
            n.a(e2);
            zTryAcquire = false;
        }
        try {
            try {
                CameraCaptureSession cameraCaptureSession = this.B;
                if (cameraCaptureSession != null) {
                    cameraCaptureSession.close();
                    this.B = null;
                }
                CameraDevice cameraDevice = this.D;
                if (cameraDevice != null) {
                    cameraDevice.close();
                    this.D = null;
                }
                if (zTryAcquire) {
                    this.v.release();
                }
            } catch (Exception e3) {
                throw new ak(ak.b.CLOSE_ERROR, e3);
            }
        } catch (Throwable th) {
            if (zTryAcquire) {
                this.v.release();
            }
            throw th;
        }
    }

    @Override // com.facetec.sdk.ah
    public final View c() {
        return this.x;
    }

    public static synchronized boolean b(Context context) {
        if (P == null) {
            e eVarG = g(context);
            if (eVarG == null) {
                return false;
            }
            P = Boolean.valueOf(eVarG.c);
        }
        return P.booleanValue();
    }

    private void c(Activity activity, e eVar) throws Throwable {
        if (eVar != null) {
            String str = eVar.a;
            CameraCharacteristics cameraCharacteristics = eVar.d;
            StreamConfigurationMap streamConfigurationMap = eVar.e;
            int iIntValue = ((Integer) cameraCharacteristics.get(CameraCharacteristics.SENSOR_ORIENTATION)).intValue();
            this.A = iIntValue;
            ah.h = iIntValue;
            activity.getWindowManager().getDefaultDisplay().getSize(new Point());
            activity.getWindowManager().getDefaultDisplay().getRealSize(new Point());
            if (dq.a((Context) activity).getConfiguration().orientation == 2) {
                g gVar = this.x;
                ar arVar = this.y;
                gVar.setAspectRatio(arVar.b, arVar.e);
            } else {
                g gVar2 = this.x;
                ar arVar2 = this.y;
                gVar2.setAspectRatio(arVar2.e, arVar2.b);
            }
            b(activity, streamConfigurationMap);
            this.w = str;
            this.z = cameraCharacteristics;
            return;
        }
        throw new ak(ak.b.FRONT_FACING_NOT_FOUND);
    }

    public static synchronized boolean d(Context context) {
        if (O == null) {
            e eVarF = f(context);
            if (eVarF == null) {
                return false;
            }
            O = Boolean.valueOf(eVarF.c);
        }
        return O.booleanValue();
    }

    private boolean d(CameraCharacteristics.Key<int[]> key, int i) {
        int[] iArr = (int[]) this.z.get(key);
        if (iArr != null) {
            for (int i2 : iArr) {
                if (i2 == i) {
                    return true;
                }
            }
        }
        return false;
    }

    @Override // com.facetec.sdk.ah
    public final void b() throws Throwable {
        if (this.N) {
            if (this.M) {
                k();
            } else {
                c(this.D);
            }
        }
    }

    private static ar d(Context context, e eVar) throws ak {
        float[] fArr = {1.7f, 1.6f, 1.5f, 1.4f, 1.3f};
        ArrayList arrayList = new ArrayList();
        if (eVar != null) {
            Size[] outputSizes = eVar.e.getOutputSizes(SurfaceTexture.class);
            if (outputSizes.length != 0) {
                Arrays.sort(outputSizes, new Comparator() { // from class: com.facetec.sdk.古
                    @Override // java.util.Comparator
                    public final int compare(Object obj, Object obj2) {
                        return am.b((Size) obj, (Size) obj2);
                    }
                });
                StringBuilder sb = new StringBuilder();
                sb.append(outputSizes[0].getWidth());
                sb.append("x");
                sb.append(outputSizes[0].getHeight());
                ah.b = sb.toString();
                o.e(outputSizes);
                bh.e(context).getDefaultDisplay().getRealSize(new Point());
                for (int i = 0; i < 5; i++) {
                    float f = fArr[i];
                    for (Size size : outputSizes) {
                        float width = size.getWidth();
                        float height = size.getHeight();
                        if (width <= 1920.0f && height <= 1080.0f) {
                            float f2 = width / height;
                            if (f2 >= f && f2 <= 1.9f && width >= 640.0f && width <= r3.y && height <= r3.x) {
                                arrayList.add(size);
                            }
                        }
                    }
                    if (arrayList.size() > 0) {
                        break;
                    }
                }
                if (arrayList.size() > 0) {
                    return new ar(((Size) arrayList.get(0)).getWidth(), ((Size) arrayList.get(0)).getHeight());
                }
                return new ar(outputSizes[0].getWidth(), outputSizes[0].getHeight());
            }
            throw new ak(ak.b.NO_OUTPUT_SIZES);
        }
        throw new ak(ak.b.FRONT_FACING_NOT_FOUND);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static /* synthetic */ int b(Size size, Size size2) {
        return (size2.getWidth() * size2.getHeight()) - (size.getWidth() * size.getHeight());
    }

    private void e(String str) {
        bm bmVar = this.p.get();
        if (bmVar != null) {
            bmVar.e("Camera2 device error: UNRECOVERABLE");
            c cVar = c.CAMERA2_ERROR;
            StringBuilder sb = new StringBuilder("Camera2 device error: UNRECOVERABLE | ");
            sb.append(str);
            sb.append(" | ");
            sb.append(ah.g());
            t.d(bmVar, cVar, sb.toString(), null);
        }
    }

    @Override // com.facetec.sdk.ah
    public final void b(boolean z) throws Throwable {
        HandlerThread handlerThread = this.C;
        if (handlerThread != null) {
            handlerThread.quitSafely();
            try {
                this.C.join();
                this.C = null;
                this.I.removeCallbacksAndMessages(null);
                this.I = null;
            } catch (InterruptedException e2) {
                n.a(e2);
            }
        }
        try {
            e(z);
        } catch (Exception unused) {
        }
        Object obj = this.G;
        if (obj != null) {
            try {
                Object objD = an.d(949540237);
                if (objD == null) {
                    int fadingEdgeLength = (ViewConfiguration.getFadingEdgeLength() >> 16) + 24;
                    char threadPriority = (char) ((Process.getThreadPriority(0) + 20) >> 6);
                    int iRgb = Color.rgb(0, 0, 0) + 16777240;
                    byte b = (byte) 0;
                    byte b2 = (byte) (b - 1);
                    Object[] objArr = new Object[1];
                    ad(b, b2, (byte) (b2 + 3), objArr);
                    objD = an.d(fadingEdgeLength, threadPriority, iRgb, 1324943062, false, (String) objArr[0], new Class[0]);
                }
                ((Method) objD).invoke(obj, null);
                this.G = null;
            } catch (Throwable th) {
                Throwable cause = th.getCause();
                if (cause == null) {
                    throw th;
                }
                throw cause;
            }
        }
        this.H = true;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void e(int i, int i2) {
        bm bmVar = this.p.get();
        if (this.x == null || bmVar == null) {
            return;
        }
        int rotation = bmVar.getWindowManager().getDefaultDisplay().getRotation();
        Matrix matrix = new Matrix();
        float f = i;
        float f2 = i2;
        RectF rectF = new RectF(SelfieScan.RECOGNITION_FAIL_RESULT, SelfieScan.RECOGNITION_FAIL_RESULT, f, f2);
        ar arVar = this.y;
        RectF rectF2 = new RectF(SelfieScan.RECOGNITION_FAIL_RESULT, SelfieScan.RECOGNITION_FAIL_RESULT, arVar.e, arVar.b);
        float fCenterX = rectF.centerX();
        float fCenterY = rectF.centerY();
        if (1 == rotation || 3 == rotation) {
            rectF2.offset(fCenterX - rectF2.centerX(), fCenterY - rectF2.centerY());
            matrix.setRectToRect(rectF, rectF2, Matrix.ScaleToFit.FILL);
            ar arVar2 = this.y;
            float fMax = Math.max(f2 / arVar2.e, f / arVar2.b);
            matrix.postScale(fMax, fMax, fCenterX, fCenterY);
            matrix.postRotate((rotation - 2) * 90, fCenterX, fCenterY);
        } else if (2 == rotation) {
            matrix.postRotate(180.0f, fCenterX, fCenterY);
        }
        this.x.setTransform(matrix);
    }

    @Override // com.facetec.sdk.ah
    public final void a() throws Throwable {
        CaptureRequest.Builder builderCreateCaptureRequest;
        try {
            builderCreateCaptureRequest = this.D.createCaptureRequest(2);
        } catch (Exception e2) {
            cb.e(this.p.get(), ao.as, e2);
            builderCreateCaptureRequest = null;
        }
        boolean z = false;
        if (builderCreateCaptureRequest != null) {
            try {
                Object obj = this.G;
                try {
                    Object objD = an.d(949542159);
                    if (objD == null) {
                        int minimumFlingVelocity = (ViewConfiguration.getMinimumFlingVelocity() >> 16) + 24;
                        char cRed = (char) Color.red(0);
                        int iArgb = Color.argb(0, 0, 0, 0) + 24;
                        byte b = (byte) 0;
                        byte b2 = (byte) (b - 1);
                        Object[] objArr = new Object[1];
                        ad(b, b2, (byte) (b2 + 1), objArr);
                        objD = an.d(minimumFlingVelocity, cRed, iArgb, 1324944980, false, (String) objArr[0], new Class[0]);
                    }
                    builderCreateCaptureRequest.addTarget((Surface) ((Method) objD).invoke(obj, null));
                    this.B.capture(builderCreateCaptureRequest.build(), null, this.I);
                } catch (Throwable th) {
                    Throwable cause = th.getCause();
                    if (cause == null) {
                        throw th;
                    }
                    throw cause;
                }
            } catch (IllegalArgumentException unused) {
                z = true;
            } catch (Exception e3) {
                cb.e(this.p.get(), ao.at, e3);
            }
        }
        cb.e(cb.b.c, z);
    }

    private void c(Activity activity, int i, int i2) throws Throwable {
        if (this.H) {
            return;
        }
        if (C6852.checkSelfPermission(activity, "android.permission.CAMERA") == 0) {
            try {
                if (!bj.i) {
                    d(activity);
                } else {
                    b(activity);
                }
                e(i, i2);
                CameraManager cameraManagerI = i(activity);
                if (cameraManagerI != null) {
                    try {
                        if (this.v.tryAcquire(2500L, TimeUnit.MILLISECONDS)) {
                            ba.e("CTOT");
                            ba.e("CTFFT");
                            try {
                                t.d(activity, c.OPEN_FRONT_CAMERA2, null, null);
                                cameraManagerI.openCamera(this.w, this.Q, (Handler) null);
                                return;
                            } catch (Exception e2) {
                                this.v.release();
                                throw new ak(ak.b.UNKNOWN, e2.getMessage());
                            }
                        }
                        throw new ak(ak.b.OPEN_TIMEOUT);
                    } catch (InterruptedException e3) {
                        n.a(e3);
                        throw new ak(ak.b.LOCK_OPEN_TIMEOUT, e3);
                    }
                }
                throw new ak(ak.b.PERMISSION_DENIED);
            } catch (CameraAccessException e4) {
                throw new ak(ak.b.UNKNOWN, e4.getMessage());
            }
        }
        throw new ak(ak.b.PERMISSION_DENIED);
    }

    public static /* synthetic */ void b(am amVar, CameraDevice cameraDevice) {
        amVar.c(cameraDevice);
        if (ah.l) {
            return;
        }
        amVar.N = true;
    }

    @Override // com.facetec.sdk.ah
    public final void e() throws Throwable {
        Object obj = this.G;
        try {
            Object objD = an.d(949541198);
            if (objD == null) {
                int iRed = Color.red(0) + 24;
                char c = (char) ((ExpandableListView.getPackedPositionForChild(0, 0) > 0L ? 1 : (ExpandableListView.getPackedPositionForChild(0, 0) == 0L ? 0 : -1)) + 1);
                int iResolveOpacity = Drawable.resolveOpacity(0, 0) + 24;
                byte b = (byte) 0;
                byte b2 = (byte) (b - 1);
                Object[] objArr = new Object[1];
                ad(b, b2, (byte) (-b2), objArr);
                objD = an.d(iRed, c, iResolveOpacity, 1324943893, false, (String) objArr[0], new Class[0]);
            }
            ((Method) objD).invoke(obj, null);
        } catch (Throwable th) {
            Throwable cause = th.getCause();
            if (cause == null) {
                throw th;
            }
            throw cause;
        }
    }

    private static int d(Integer num) {
        if (num == null) {
            return -1;
        }
        return num.intValue();
    }

    public static /* synthetic */ void e(am amVar, c cVar, String str) {
        bm bmVar = amVar.p.get();
        if (bmVar != null) {
            t.d(bmVar, cVar, str, null);
        }
    }

    public static /* synthetic */ void d(am amVar, CameraCaptureSession cameraCaptureSession) {
        boolean zTryAcquire = false;
        try {
            try {
                zTryAcquire = amVar.v.tryAcquire(2L, TimeUnit.SECONDS);
                if (zTryAcquire && amVar.D != null && amVar.B == null) {
                    amVar.B = cameraCaptureSession;
                    if (!bj.i) {
                        if (amVar.d(CameraCharacteristics.CONTROL_AF_AVAILABLE_MODES, 4)) {
                            amVar.F.set(CaptureRequest.CONTROL_AF_MODE, 4);
                        }
                    } else if (amVar.d(CameraCharacteristics.CONTROL_AF_AVAILABLE_MODES, 3)) {
                        amVar.F.set(CaptureRequest.CONTROL_AF_MODE, 3);
                    }
                    if (amVar.d(CameraCharacteristics.CONTROL_AE_AVAILABLE_MODES, 1)) {
                        amVar.F.set(CaptureRequest.CONTROL_AE_MODE, 1);
                    }
                    ba.e("CTPRT");
                    if (amVar.f && amVar.J) {
                        amVar.B.setRepeatingRequest(amVar.F.build(), amVar.r, null);
                    } else {
                        amVar.L = true;
                    }
                    ba.d("CTPRT");
                    if (!zTryAcquire) {
                    }
                }
            } catch (Exception e2) {
                n.a(e2);
                if (!zTryAcquire) {
                }
            }
        } finally {
            if (zTryAcquire) {
                amVar.v.release();
            }
        }
    }

    private void c(@NonNull CameraDevice cameraDevice) {
        this.v.release();
        cameraDevice.close();
        this.D = null;
    }

    private JSONObject c(@NonNull CaptureRequest.Builder builder) {
        Integer num;
        Integer num2;
        Integer num3 = (Integer) builder.get(CaptureRequest.EDGE_MODE);
        Integer num4 = (Integer) builder.get(CaptureRequest.NOISE_REDUCTION_MODE);
        Integer num5 = (Integer) builder.get(CaptureRequest.TONEMAP_MODE);
        Integer num6 = (Integer) builder.get(CaptureRequest.SHADING_MODE);
        Integer num7 = (Integer) builder.get(CaptureRequest.COLOR_CORRECTION_ABERRATION_MODE);
        Integer num8 = (Integer) builder.get(CaptureRequest.COLOR_CORRECTION_MODE);
        Integer num9 = (Integer) builder.get(CaptureRequest.CONTROL_AF_MODE);
        Integer num10 = (Integer) builder.get(CaptureRequest.CONTROL_AE_MODE);
        Integer num11 = (Integer) builder.get(CaptureRequest.CONTROL_AE_ANTIBANDING_MODE);
        Integer num12 = (Integer) builder.get(CaptureRequest.CONTROL_AWB_MODE);
        Integer num13 = (Integer) builder.get(CaptureRequest.CONTROL_MODE);
        Integer num14 = (Integer) builder.get(CaptureRequest.CONTROL_SCENE_MODE);
        Integer num15 = (Integer) builder.get(CaptureRequest.CONTROL_EFFECT_MODE);
        Integer num16 = (Integer) builder.get(CaptureRequest.CONTROL_VIDEO_STABILIZATION_MODE);
        Integer num17 = (Integer) builder.get(CaptureRequest.HOT_PIXEL_MODE);
        Integer num18 = (Integer) builder.get(CaptureRequest.LENS_OPTICAL_STABILIZATION_MODE);
        Range range = (Range) builder.get(CaptureRequest.CONTROL_AE_TARGET_FPS_RANGE);
        CameraCharacteristics cameraCharacteristics = this.z;
        Range[] rangeArr = cameraCharacteristics != null ? (Range[]) cameraCharacteristics.get(CameraCharacteristics.CONTROL_AE_AVAILABLE_TARGET_FPS_RANGES) : null;
        int i = Build.VERSION.SDK_INT;
        Range[] rangeArr2 = rangeArr;
        if (i < 31) {
            num = -1;
        } else {
            num = (Integer) builder.get(CaptureRequest.SENSOR_PIXEL_MODE);
        }
        if (i < 30) {
            num2 = -1;
        } else {
            num2 = (Integer) builder.get(CaptureRequest.CONTROL_EXTENDED_SCENE_MODE);
        }
        Integer num19 = (Integer) builder.get(CaptureRequest.DISTORTION_CORRECTION_MODE);
        JSONObject jSONObject = new JSONObject();
        try {
            jSONObject.putOpt("edgeMode", Integer.valueOf(d(num3)));
            jSONObject.put("noiseReductionMode", d(num4));
            jSONObject.put("toneMapMode", d(num5));
            jSONObject.put("shaderMode", d(num6));
            jSONObject.put("colorCorrectionAberrationMode", d(num7));
            jSONObject.put("colorCorrectionMode", d(num8));
            jSONObject.put("afMode", d(num9));
            jSONObject.put("aeMode", d(num10));
            jSONObject.put("aeAntiBandingMode", d(num11));
            jSONObject.put("awbMode", d(num12));
            jSONObject.put("controlMode", d(num13));
            jSONObject.put("controlSceneMode", d(num14));
            jSONObject.put("controlEffectMode", d(num15));
            jSONObject.put("videoStabilizationMode", d(num16));
            jSONObject.put("hotPixelMode", d(num17));
            jSONObject.put("lensOpticalStabilizationMode", d(num18));
            jSONObject.put("sensorPixelMode", d(num));
            jSONObject.put("controlExtendedSceneMode", d(num2));
            jSONObject.put("distortionCorrectionMode", d(num19));
            if (rangeArr2 != null) {
                jSONObject.put("availableAETargetFPSRange", new JSONObject(Arrays.toString(rangeArr2)));
            }
            if (range != null) {
                jSONObject.put("aeTargetFPSRange", new JSONObject(String.valueOf(range)));
            }
        } catch (JSONException unused) {
        }
        return jSONObject;
    }

    public static /* synthetic */ void d(am amVar, int i, int i2) {
        bm bmVar = amVar.p.get();
        if (bmVar != null) {
            try {
                amVar.c(bmVar, i, i2);
            } catch (Throwable th) {
                c cVar = c.CAMERA2_ERROR;
                StringBuilder sb = new StringBuilder("Camera2 SurfaceTexture error: ");
                sb.append(th.getMessage());
                t.d(bmVar, cVar, sb.toString(), th);
                StringBuilder sb2 = new StringBuilder("Camera 2 SurfaceTexture error: ");
                sb2.append(th.getMessage());
                bmVar.e(sb2.toString());
            }
        }
    }

    public static /* synthetic */ void c(am amVar, CameraDevice cameraDevice) {
        List<Surface> listAsList;
        ba.e("CTCPT");
        amVar.D = cameraDevice;
        amVar.M = false;
        try {
            try {
                try {
                    if (amVar.G != null) {
                        SurfaceTexture surfaceTexture = amVar.x.getSurfaceTexture();
                        if (!U && surfaceTexture == null) {
                            throw new AssertionError();
                        }
                        ar arVar = amVar.y;
                        surfaceTexture.setDefaultBufferSize(arVar.b, arVar.e);
                        Surface surface = new Surface(surfaceTexture);
                        Object obj = amVar.G;
                        try {
                            Object objD = an.d(949542159);
                            if (objD == null) {
                                int iLastIndexOf = TextUtils.lastIndexOf("", '0') + 25;
                                char cAlpha = (char) Color.alpha(0);
                                int i = 25 - (ViewConfiguration.getScrollFriction() > SelfieScan.RECOGNITION_FAIL_RESULT ? 1 : (ViewConfiguration.getScrollFriction() == SelfieScan.RECOGNITION_FAIL_RESULT ? 0 : -1));
                                byte b = (byte) 0;
                                byte b2 = (byte) (b - 1);
                                Object[] objArr = new Object[1];
                                ad(b, b2, (byte) (b2 + 1), objArr);
                                objD = an.d(iLastIndexOf, cAlpha, i, 1324944980, false, (String) objArr[0], new Class[0]);
                            }
                            Surface surface2 = (Surface) ((Method) objD).invoke(obj, null);
                            CaptureRequest.Builder builderO = amVar.o();
                            amVar.F = builderO;
                            if (builderO != null) {
                                builderO.addTarget(surface);
                                amVar.F.addTarget(surface2);
                                Surface surface3 = R;
                                if (surface3 != null) {
                                    amVar.F.addTarget(surface3);
                                }
                                if (!amVar.K) {
                                    if (((Boolean) bk.d(-261957882, nf.a.e(), nf.a.e(), nf.a.e(), nf.a.e(), new Object[0], 261957889)).booleanValue()) {
                                        amVar.K = true;
                                        o.d = amVar.c(amVar.F);
                                    }
                                }
                                ba.e("CTCCST");
                                Surface surface4 = R;
                                if (surface4 == null) {
                                    listAsList = Arrays.asList(surface, surface2);
                                } else {
                                    listAsList = Arrays.asList(surface, surface2, surface4);
                                }
                                amVar.D.createCaptureSession(listAsList, amVar.S, null);
                            }
                        } catch (Throwable th) {
                            Throwable cause = th.getCause();
                            if (cause == null) {
                                throw th;
                            }
                            throw cause;
                        }
                    }
                } catch (IllegalStateException unused) {
                    if (amVar.p.get() != null) {
                        bm bmVar = amVar.p.get();
                        c cVar = c.CAMERA_ALREADY_CLOSED;
                        bmVar.e(cVar.toString());
                        t.d(amVar.p.get(), cVar, null, null);
                    }
                }
            } catch (CameraAccessException e2) {
                n.a(e2);
            }
            amVar.v.release();
            ba.d("CTCPT");
        } catch (Throwable th2) {
            amVar.v.release();
            throw th2;
        }
    }

    public static /* synthetic */ void c(am amVar, CameraDevice cameraDevice, int i) {
        amVar.c(cameraDevice);
        bm bmVar = amVar.p.get();
        if (bmVar != null) {
            if (ah.l) {
                bmVar.e("Camera2 device error: ".concat(String.valueOf(i)));
            } else {
                amVar.N = true;
            }
            t.d(bmVar, c.CAMERA2_ERROR, "Camera2 device error: ".concat(String.valueOf(i)), null);
        }
    }
}