package com.facetec.sdk;

/* JADX INFO: loaded from: classes4.dex */
final class ao {
    static final String[] d = {"th"};
    static String e = "i9";
    static String c = "2f";
    static String b = "b7";
    static String a = "7f";
    static String j = "13";
    static String i = "fj";
    static String h = "h7";

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    static String f95821g = "93";
    static String f = "z7";
    static String m = "e1";
    static String n = "e2";
    static String l = "i2";
    static String o = "o3";
    static String k = "u4";
    static String t = "y6";
    static String p = "y8";
    static String r = "y9";
    static String q = "RetryTimeoutPresession";
    static String s = "FaceScanSession";
    static String u = "PreSession";
    static String y = "SDKActivityOnResume";
    static String w = "aca";
    static String x = "av";
    static String v = "sfcs";
    static String A = "afc1r";
    static String D = "abc1r";
    static String B = "afc2r";
    static String z = "abc2r";
    static String C = "cu_df";
    static String F = "cu_dn";
    static String E = "cu_dcn";
    static String I = "cu_mn";
    static String G = "cu_pn";
    static String H = "t_bt";
    static String K = "t_ctot";
    static String N = "t_clot";
    static String M = "t_rwt";
    static String J = "t_umt";
    static String L = "t_udt";
    static String R = "t_ctcpt";
    static String S = "t_clcpt";
    static String P = "t_ctccst";
    static String O = "t_ctprt";
    static String Q = "t_ctfft";
    static String T = "t_clfft";
    static String W = "ict";
    static String U = "c2s";
    static String V = "c1s";
    static String X = "pns";
    static String Y = "nasbpl";
    static String ab = "umealo";
    static String Z = "rcf";
    static String ac = "ellmfs";
    static String aa = "c2mccf";
    static String ah = "c2mcndcf";
    static String ag = "ulb";
    static String af = "cpss";
    static String ad = "lpms";
    static String ae = "lpmu";
    static String al = "ahdf";

    /* JADX INFO: renamed from: ai, reason: collision with root package name */
    static String f95820ai = "ahrf";
    static String am = "ahec";
    static String ak = "ahcv";
    static String aj = "vtatdha";
    static String ao = "sapic";
    static String ap = "rapic";
    static String ar = "capic";
    static String aq = "CRF001";
    static String an = "CRF002";
    static String aw = "CRF003";
    static String as = "HCE001";
    static String at = "HCE002";
    static String av = "deviceFingerprint";
    static String au = "deviceName";
    static String ay = "deviceBrand";
    static String aA = "deviceBootloader";
    static String ax = "deviceSDKVersion";
    static String aB = "deviceSupportedABIs";
}