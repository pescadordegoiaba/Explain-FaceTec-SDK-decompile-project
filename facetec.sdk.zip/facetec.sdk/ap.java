package com.facetec.sdk;

import android.app.Activity;
import android.content.Context;
import android.graphics.Color;
import android.graphics.PointF;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.hardware.Camera;
import android.media.AudioTrack;
import android.os.Handler;
import android.os.HandlerThread;
import android.os.Looper;
import android.os.Process;
import android.os.SystemClock;
import android.text.AndroidCharacter;
import android.text.TextUtils;
import android.util.TypedValue;
import android.view.KeyEvent;
import android.view.SurfaceHolder;
import android.view.View;
import android.view.ViewConfiguration;
import android.view.ViewGroup;
import android.widget.ExpandableListView;
import androidx.annotation.NonNull;
import com.facetec.sdk.ah;
import com.facetec.sdk.cb;
import com.incode.welcome_sdk.modules.SelfieScan;
import com.plaid.internal.EnumC41897g;
import java.lang.ref.WeakReference;
import java.lang.reflect.Constructor;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Objects;
import java.util.concurrent.atomic.AtomicBoolean;
import org.bouncycastle.i18n.LocalizedMessage;
import org.json.JSONException;
import org.json.JSONObject;

/* JADX INFO: loaded from: classes4.dex */
public class ap extends ah implements Camera.AutoFocusCallback, Camera.ErrorCallback {
    private static final byte[] $$a = null;
    private static final int $$b = 0;
    private static int J;
    private static int K;
    private static int L;
    private static int M;
    private static /* synthetic */ boolean N;
    private static byte[] O;
    private static short[] P;
    private static int Q;
    private static int R;
    private static final byte[] S = null;
    private static final int T = 0;
    private final WeakReference<bm> r;
    private final Handler s;
    private boolean u;
    private final i v;
    private SurfaceHolder w;
    private int x;
    private e q = new e();
    private boolean t = false;
    private Camera p = null;
    private boolean y = false;
    ar m = null;
    private boolean A = false;
    boolean k = false;
    private boolean z = false;
    private boolean B = false;
    private final Handler D = new Handler(Looper.getMainLooper());
    private String C = "";
    private long I = -1;
    private boolean E = false;
    private final AtomicBoolean G = new AtomicBoolean(false);
    private final Camera.AutoFocusMoveCallback H = new Camera.AutoFocusMoveCallback() { // from class: com.facetec.sdk.城
        @Override // android.hardware.Camera.AutoFocusMoveCallback
        public final void onAutoFocusMoving(boolean z, Camera camera) throws Throwable {
            this.f7255.a(z, camera);
        }
    };
    private final Camera.AutoFocusCallback F = new Camera.AutoFocusCallback() { // from class: com.facetec.sdk.天
        @Override // android.hardware.Camera.AutoFocusCallback
        public final void onAutoFocus(boolean z, Camera camera) throws Throwable {
            this.f7256.c(z, camera);
        }
    };

    public class e implements SurfaceHolder.Callback {
        public e() {
        }

        @Override // android.view.SurfaceHolder.Callback
        public final void surfaceChanged(SurfaceHolder surfaceHolder, int i, int i2, int i3) {
        }

        @Override // android.view.SurfaceHolder.Callback
        public final void surfaceCreated(SurfaceHolder surfaceHolder) {
            ap.this.w = surfaceHolder;
            ap.c(ap.this);
        }

        @Override // android.view.SurfaceHolder.Callback
        public final void surfaceDestroyed(SurfaceHolder surfaceHolder) {
            ap.this.r();
            bi biVar = (bi) ap.this.r.get();
            if (biVar == null || !biVar.G || surfaceHolder == null || surfaceHolder.getSurface() == null) {
                return;
            }
            surfaceHolder.removeCallback(this);
            surfaceHolder.getSurface().release();
            ap.b(ap.this);
        }
    }

    /* JADX WARN: Removed duplicated region for block: B:10:0x0024  */
    /* JADX WARN: Removed duplicated region for block: B:8:0x001e  */
    /* JADX WARN: Unsupported multi-entry loop pattern (BACK_EDGE: B:10:0x0024 -> B:11:0x002a). Please report as a decompilation issue!!! */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    private static java.lang.String $$c(short r5, short r6, short r7) {
        /*
            int r5 = r5 * 2
            int r5 = 3 - r5
            int r6 = r6 + 102
            int r7 = r7 * 4
            int r0 = r7 + 1
            byte[] r1 = com.facetec.sdk.ap.$$a
            byte[] r0 = new byte[r0]
            r2 = 0
            if (r1 != 0) goto L15
            r6 = r5
            r4 = r7
            r3 = r2
            goto L2a
        L15:
            r3 = r6
            r6 = r5
            r5 = r3
            r3 = r2
        L19:
            byte r4 = (byte) r5
            r0[r3] = r4
            if (r3 != r7) goto L24
            java.lang.String r5 = new java.lang.String
            r5.<init>(r0, r2)
            return r5
        L24:
            int r6 = r6 + 1
            int r3 = r3 + 1
            r4 = r1[r6]
        L2a:
            int r4 = -r4
            int r5 = r5 + r4
            goto L19
        */
        throw new UnsupportedOperationException("Method not decompiled: com.facetec.sdk.ap.$$c(short, short, short):java.lang.String");
    }

    static {
        init$0();
        o();
        l();
        J = 0;
        K = 1;
        k();
        N = true;
    }

    private ap(Activity activity) {
        this.r = new WeakReference<>((bm) activity);
        HandlerThread handlerThread = new HandlerThread("CameraHandlerThread");
        handlerThread.start();
        this.s = new Handler(handlerThread.getLooper());
        this.v = new i(activity);
    }

    /* JADX WARN: Removed duplicated region for block: B:10:0x0021  */
    /* JADX WARN: Removed duplicated region for block: B:8:0x0019  */
    /* JADX WARN: Unsupported multi-entry loop pattern (BACK_EDGE: B:10:0x0021 -> B:11:0x0026). Please report as a decompilation issue!!! */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    private static void U(byte r7, byte r8, int r9, java.lang.Object[] r10) {
        /*
            int r7 = r7 + 97
            int r9 = r9 + 4
            int r8 = r8 + 3
            byte[] r0 = com.facetec.sdk.ap.S
            byte[] r1 = new byte[r8]
            r2 = 0
            if (r0 != 0) goto L11
            r3 = r8
            r7 = r9
            r4 = r2
            goto L26
        L11:
            r3 = r2
        L12:
            int r4 = r3 + 1
            byte r5 = (byte) r7
            r1[r3] = r5
            if (r4 != r8) goto L21
            java.lang.String r7 = new java.lang.String
            r7.<init>(r1, r2)
            r10[r2] = r7
            return
        L21:
            r3 = r0[r9]
            r6 = r9
            r9 = r7
            r7 = r6
        L26:
            int r9 = r9 + r3
            int r7 = r7 + 1
            r3 = r9
            r9 = r7
            r7 = r3
            r3 = r4
            goto L12
        */
        throw new UnsupportedOperationException("Method not decompiled: com.facetec.sdk.ap.U(byte, byte, int, java.lang.Object[]):void");
    }

    private static void V(int i, byte b, int i2, int i3, short s, Object[] objArr) throws Throwable {
        int i4;
        int i5;
        float f;
        long j;
        int i6;
        int i7;
        int i8;
        int i9;
        hh hhVar = new hh();
        StringBuilder sb = new StringBuilder();
        try {
            int i10 = 1;
            Object[] objArr2 = {Integer.valueOf(i3), Integer.valueOf(Q)};
            int i11 = 0;
            Object objD = an.d(962055330);
            Class cls = Integer.TYPE;
            if (objD == null) {
                int i12 = (SystemClock.elapsedRealtimeNanos() > 0L ? 1 : (SystemClock.elapsedRealtimeNanos() == 0L ? 0 : -1)) + 2401;
                char cArgb = (char) Color.argb(0, 0, 0, 0);
                int i13 = (ViewConfiguration.getGlobalActionKeyTimeout() > 0L ? 1 : (ViewConfiguration.getGlobalActionKeyTimeout() == 0L ? 0 : -1)) + 23;
                byte length = (byte) $$a.length;
                i4 = 962055330;
                objD = an.d(i12, cArgb, i13, 1328947193, false, $$c((byte) 0, length, (byte) (length - 4)), new Class[]{cls, cls});
            } else {
                i4 = 962055330;
            }
            int iIntValue = ((Integer) ((Method) objD).invoke(null, objArr2)).intValue();
            int i14 = iIntValue == -1 ? 1 : 0;
            if (i14 != 0) {
                byte[] bArr = O;
                if (bArr != null) {
                    int length2 = bArr.length;
                    byte[] bArr2 = new byte[length2];
                    int i15 = 0;
                    while (i15 < length2) {
                        Object[] objArr3 = {Integer.valueOf(bArr[i15])};
                        Object objD2 = an.d(399840230);
                        if (objD2 == null) {
                            int packedPositionType = ExpandableListView.getPackedPositionType(0L) + 2064;
                            char c = (char) (14867 - (ViewConfiguration.getGlobalActionKeyTimeout() > 0L ? 1 : (ViewConfiguration.getGlobalActionKeyTimeout() == 0L ? 0 : -1)));
                            int i16 = 24 - (TypedValue.complexToFloat(i11) > SelfieScan.RECOGNITION_FAIL_RESULT ? 1 : (TypedValue.complexToFloat(i11) == SelfieScan.RECOGNITION_FAIL_RESULT ? 0 : -1));
                            i8 = i10;
                            byte b2 = (byte) i11;
                            i9 = i11;
                            byte b3 = (byte) (b2 + 1);
                            objD2 = an.d(packedPositionType, c, i16, 1639235773, false, $$c(b2, b3, (byte) (b3 - 1)), new Class[]{cls});
                        } else {
                            i8 = i10;
                            i9 = i11;
                        }
                        bArr2[i15] = ((Byte) ((Method) objD2).invoke(null, objArr3)).byteValue();
                        i15++;
                        i10 = i8;
                        i11 = i9;
                    }
                    bArr = bArr2;
                }
                i5 = i10;
                int i17 = i11;
                f = SelfieScan.RECOGNITION_FAIL_RESULT;
                j = -7666492657327691677L;
                if (bArr != null) {
                    byte[] bArr3 = O;
                    Object[] objArr4 = new Object[2];
                    objArr4[i5] = Integer.valueOf(M);
                    objArr4[i17] = Integer.valueOf(i);
                    Object objD3 = an.d(i4);
                    if (objD3 == null) {
                        int pressedStateDuration = 2402 - (ViewConfiguration.getPressedStateDuration() >> 16);
                        char cResolveOpacity = (char) Drawable.resolveOpacity(i17, i17);
                        int tapTimeout = (ViewConfiguration.getTapTimeout() >> 16) + 24;
                        byte length3 = (byte) $$a.length;
                        objD3 = an.d(pressedStateDuration, cResolveOpacity, tapTimeout, 1328947193, false, $$c((byte) i17, length3, (byte) (length3 - 4)), new Class[]{cls, cls});
                    }
                    iIntValue = (byte) (((byte) (((long) bArr3[((Integer) ((Method) objD3).invoke(null, objArr4)).intValue()]) ^ (-7666492657327691677L))) + ((int) (((long) Q) ^ (-7666492657327691677L))));
                } else {
                    iIntValue = (short) (((short) (((long) P[i + ((int) (((long) M) ^ (-7666492657327691677L)))]) ^ (-7666492657327691677L))) + ((int) (((long) Q) ^ (-7666492657327691677L))));
                }
            } else {
                i5 = 1;
                f = SelfieScan.RECOGNITION_FAIL_RESULT;
                j = -7666492657327691677L;
            }
            if (iIntValue > 0) {
                hhVar.d = ((i + iIntValue) - 2) + ((int) (((long) M) ^ j)) + i14;
                int i18 = R;
                Object[] objArr5 = new Object[4];
                objArr5[3] = sb;
                objArr5[2] = Integer.valueOf(i18);
                objArr5[i5] = Integer.valueOf(i2);
                objArr5[0] = hhVar;
                Object objD4 = an.d(-1066327576);
                if (objD4 == null) {
                    byte b4 = (byte) 0;
                    byte b5 = b4;
                    objD4 = an.d(1803 - Color.argb(0, 0, 0, 0), (char) (9691 - ((byte) KeyEvent.getModifierMetaStateMask())), (TypedValue.complexToFloat(0) > f ? 1 : (TypedValue.complexToFloat(0) == f ? 0 : -1)) + 24, -1240403277, false, $$c(b4, b5, b5), new Class[]{Object.class, cls, cls, Object.class});
                }
                ((StringBuilder) ((Method) objD4).invoke(null, objArr5)).append(hhVar.e);
                hhVar.c = hhVar.e;
                byte[] bArr4 = O;
                if (bArr4 != null) {
                    int length4 = bArr4.length;
                    byte[] bArr5 = new byte[length4];
                    for (int i19 = 0; i19 < length4; i19++) {
                        bArr5[i19] = (byte) (((long) bArr4[i19]) ^ j);
                    }
                    bArr4 = bArr5;
                }
                if (bArr4 != null) {
                    i7 = i5;
                    i6 = i7;
                } else {
                    i6 = i5;
                    i7 = 0;
                }
                while (true) {
                    hhVar.b = i6;
                    if (hhVar.b >= iIntValue) {
                        break;
                    }
                    if (i7 != 0) {
                        byte[] bArr6 = O;
                        hhVar.d = hhVar.d - 1;
                        hhVar.e = (char) (hhVar.c + (((byte) (((byte) (((long) bArr6[r4]) ^ j)) + s)) ^ b));
                    } else {
                        short[] sArr = P;
                        hhVar.d = hhVar.d - 1;
                        hhVar.e = (char) (hhVar.c + (((short) (((short) (((long) sArr[r4]) ^ j)) + s)) ^ b));
                    }
                    sb.append(hhVar.e);
                    hhVar.c = hhVar.e;
                    i6 = hhVar.b + 1;
                }
            }
            objArr[0] = sb.toString();
        } catch (Throwable th) {
            Throwable cause = th.getCause();
            if (cause == null) {
                throw th;
            }
            throw cause;
        }
    }

    /* JADX WARN: Removed duplicated region for block: B:37:0x0139  */
    /* JADX WARN: Removed duplicated region for block: B:38:0x013a  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    private static void W(int r22, int r23, int r24, boolean r25, java.lang.String r26, java.lang.Object[] r27) throws java.lang.Throwable {
        /*
            Method dump skipped, instruction units count: 326
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: com.facetec.sdk.ap.W(int, int, int, boolean, java.lang.String, java.lang.Object[]):void");
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void c(byte[] bArr, Camera camera) throws Throwable {
        if (bArr != null) {
            ar arVar = this.m;
            try {
                Object[] objArr = {bArr, Integer.valueOf(arVar.b), Integer.valueOf(arVar.e), Boolean.FALSE};
                Object objD = an.d(-2047753903);
                if (objD == null) {
                    int keyRepeatTimeout = ViewConfiguration.getKeyRepeatTimeout() >> 16;
                    char offsetBefore = (char) TextUtils.getOffsetBefore("", 0);
                    int i = (TypedValue.complexToFloat(0) > SelfieScan.RECOGNITION_FAIL_RESULT ? 1 : (TypedValue.complexToFloat(0) == SelfieScan.RECOGNITION_FAIL_RESULT ? 0 : -1)) + 24;
                    Class cls = Integer.TYPE;
                    objD = an.d(keyRepeatTimeout, offsetBefore, i, -208662006, false, null, new Class[]{byte[].class, cls, cls, Boolean.TYPE});
                }
                d(((Constructor) objD).newInstance(objArr));
            } catch (Throwable th) {
                Throwable cause = th.getCause();
                if (cause == null) {
                    throw th;
                }
                throw cause;
            }
        }
    }

    /* JADX WARN: Removed duplicated region for block: B:232:0x0990  */
    /* JADX WARN: Removed duplicated region for block: B:343:0x099e A[ADDED_TO_REGION, REMOVE, SYNTHETIC] */
    /* JADX WARN: Removed duplicated region for block: B:70:0x0570 A[PHI: r0
      0x0570: PHI (r0v56 int) = 
      (r0v26 int)
      (r0v53 int)
      (r0v26 int)
      (r0v26 int)
      (r0v54 int)
      (r0v26 int)
      (r0v55 int)
      (r0v26 int)
      (r0v26 int)
      (r0v57 int)
     binds: [B:148:0x0794, B:149:0x0796, B:141:0x075f, B:135:0x072d, B:136:0x072f, B:95:0x062d, B:96:0x062f, B:77:0x0599, B:68:0x056c, B:69:0x056e] A[DONT_GENERATE, DONT_INLINE]] */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    private void d(java.lang.Object r35) throws java.lang.Throwable {
        /*
            Method dump skipped, instruction units count: 2618
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: com.facetec.sdk.ap.d(java.lang.Object):void");
    }

    public static ap e(Activity activity) {
        ap apVar = new ap(activity);
        apVar.v.getHolder().addCallback(apVar.q);
        apVar.u = true;
        return apVar;
    }

    public static void init$0() {
        $$a = new byte[]{89, 120, -98, -110};
        $$b = 39;
    }

    public static void k() {
        L = 1605274587;
    }

    public static void l() {
        M = 850857930;
        Q = -60265637;
        R = 1435336914;
        byte[] bArr = new byte[905];
        System.arraycopy(",%,õ,2Ã,%,ô-2Â-%,õú%,þ(õú%,ùú0ôû%,÷ø%,÷ú2÷ø%,öû2öù%,ùö%,ùö%,þ02,Á12,ô,3À.2,÷-3þ23Á33À03Ã/2,õ/0,þ%0Â,2,À30ùû3õ-2,ôú2,÷û2,öø2,ô,3À13,÷-3Â.3Ã.3,ùû0,þ%1,ùú0õ%Á21,õ/3À31,÷0,õ%ùù2,þ33,Á03,ô,3À13,÷-3öú3Ã.3,õ/0,ùû3õ/0,ùû3Â/3,þ%0Á20õ/0,õ,3,À30ô-3,÷ú3,öû3,Ã00ùø3,þ20,Á30,À00,Ã10,Â.0,õ%Â10õ/0,þ%1,õ.0Á21,õ.0ô,0,÷0,õ%÷-0,öú0,õ%÷0,õ%ùû0,þ%1,ùú0õ%Á21,ùú0õ%À31,÷0,õ%Ã01,Â11,õ.1,À&ô/1,÷,1,Â%,ö-1,ùú1,ùú0ùú1,þ(þ),Á&,À',À&Ã$,õ%Â%,õ2,ô3,÷0,õ%ö1uelvwdvuelwvdwtel~ndl~hk~ndl\u007fok\u007fmdlxldlxnkxldlymkysdlxoil{sjlzrdl~kh{qdlxihuqjl\u007fhil~ijtpdluwdlvvdlwudlzlkuqk~oklusi~ji{sk\u007fnklxmklxmklylklzskltli{rklusitrktqklwqhlwqiupkl~khtliuqkwqhlvwkl{miwvklxnjlymjl{kzljlyhhvrhl~ijwvkl~hjl\u007fojlydlwqhlxnjlymjl{kzljlyhhvrhl~ijxoil{sjltrjluqjl\u007fhil~ijvpjlwwjl~iil\u007fhil~ijxoilynilzmilydlwpil~kh{liltsilvpkwwkurilvqilwpil~jhl\u007fihlxhhlwrhyohl{kznhl{mhltlhlushlvrhl~ijwqhl~kol\u007fjolxiol\u007fhjynjyholzool{nol{ktmolulol{nhzklvsolwrol~gl\u007fflxelydlzkl{jltiluhl{kvo".getBytes(LocalizedMessage.DEFAULT_ENCODING), 0, bArr, 0, 905);
        O = bArr;
    }

    public static synchronized ar n() {
        ar arVarD;
        Camera cameraA = a(new Camera.CameraInfo());
        arVarD = d(cameraA);
        cameraA.stopPreview();
        cameraA.release();
        return arVarD;
    }

    public static void o() {
        byte[] bArr = new byte[764];
        System.arraycopy("\u0004\bê·\rö\u000eýúûÊFñ\u0013üº&\u0011\u0013üá\u001fõ\u0003\u0007õ\u0012\u0001Õ%ö\u0001\u0013×\u0017÷\u0015ëÍ>õ\rùÇ\u0015%ù\u0011á\u0012\f\u0004ð\tõ\u0002\rö\u000eýúûÊIòû\u0003þ\u000fº\u00173øñ\röý\u0001\nùç\u001d\n\u0001â\u0013ü\u0012þ\u000fÜ\u0011\u0002\búÿì\u001f\u0004ö\u000bõ\u0006ÿØ)\u0003Ñ%\u0001\u0003ø\rö\u000eýúûÊHóü\u0012·(\u0013ü\u0012Ì,ÿø\u0003þ\u000eýï\u0013õ\u0006ÿþ\u000fÖ+ø\u0003ä\r\u000fä\u0015\u0004ø\n\u0006ÿ\rö\u000eýúûÊ9\u000bï\u000fø\u0001ú\u0010»\u0015,ý\u0003\u0003óÿ\rö\u000eýúûÊHóü\u0012·\u001d\u001a\u0014Ì1ï\t\u0006þ\u000fÐ!ü\u0003ß%ù\u0011þ\u000fã\u0012\u0005ö\u000b\bÝ\u001b\u0006î\u0005ë\u0019\u0003\u0001\rö\u000eýúûÊ?øÿ\u0005øÍ\u00134ï\u0005\u0006å\u001eï\u0002\bþ\u000fÙ\u001c\u0005è\u0019ý\tøø\rö\u000eýúûÊA\u0004»%&ú\u0001ñ\bÖ)\u0003ô\b\u0007õ\u000f\u0003òÿî\u0013ü\u000b\bõ\u0004øþ\u000f×\u001a\u0014Ù\u0013\u000bõü\u0013Ð!\u0007õ\u0018þ\u000fÑ\u001f\u0003þî\u0019\u0003\u0001÷\u0015ëÍ>õ\rùÇ%!þ÷\u0005ùýüý\u000b÷\u0015ëÍ>õ\rùÇ\u001b%\u0006ñ\u0002þ\rë\u000b\tðê\u0017\u0005\u0006â\u000b\u000b\tð\rö\u000eýúûÊ:ù\u0011ò\u0013ê\u0011óÉ\u0015\u001e\fø\rï\u0001û\u0001à\"ó\u0011óü\u0012ò\u000fÜ\"ó\u0011óü\u0012Ì\u001e\u000b\u0000öÿ\u0002\b\rö\u000eýúûÊ:ù\u0011ò\u0013ê\u0011óÉ\u0015\u001e\fø\rïÃ,\"ó\u0011óü\u0012Ì\u001e\u000b\u0000öÿ\u0002\b\u0001í\u0011\u0002Ü\"ó\u0011óü\u0012÷\u0015ëÍ>õ\rùÇDó\u0001È$\u0013\u0001ÿ\ró\tõ\u0002þ\u000f÷\u0015ëÍ>õ\rùÇ%!þ÷\u0005ùÛ3ô\u0003ø\u0001\r÷\u0015ëÍ>õ\rùÇ&\u0014\ný\bê\u0001\nùþ\u000fÙ\u0018\u000e\u0000î\u0006þ\u000f\u0000õ\tö÷\u0015ëÍ>õ\rùÇ\u00173ë\u0002\u000b\u0004õ\u0006ÿþ\u000fÙ\u0014\u0017ñ\u0004\bø×.ï\u0016ò\u0005ùÜ\u001e\u0002\u0005ýî\u0016\u0011ëþ\u000fÜ\u0011\u0002\búÿì\u001f\u0004ö\u000bõ\u0006ÿÙ+ý\u0006ûþ\u000fÜ\u0011\u0002\búÿì\u001f\u0004ö\u000bõ\u0006ÿæ%÷õþ\u000fß\u0010\u000fýý\u0000Ö\u001f\u0011Ô\u001b\u0003\u0001ß1ýï\u0013õ\u0006ÿ\u0011õûþ\u000fæ\u0015\u0000þÖ,ÿ\u0006þýý\u0007á\u0015\u0004ø\n\u0006ÿ÷\u0015ëÍGÿõ\u0003Â5\fÿõ\u0012ý\u0000ó\t\u0006º3\u0013ûþüúË\u00133ûþüúß-\u0000ýùü\rþ\u000fÍ-öï\u0012\u000f÷\u0015ëÍ>õ\rùÇ&\u0014\nóü\u0003\u0012ý\u0000ó\t\u0006à\u0014\nóü\u0003þ\u000fß!í\u0002\bé\u001eï\u0002\u0002".getBytes(LocalizedMessage.DEFAULT_ENCODING), 0, bArr, 0, 764);
        S = bArr;
        T = EnumC41897g.SDK_ASSET_ILLUSTRATION_FALLBACK_INSTITUTION_VALUE;
    }

    private void p() throws Throwable {
        if (this.p == null || this.C.isEmpty()) {
            return;
        }
        try {
            Camera.Parameters parameters = this.p.getParameters();
            parameters.setFocusMode(this.C);
            if (parameters.getMaxNumFocusAreas() > 0) {
                parameters.setFocusAreas(null);
            }
            if (parameters.getMaxNumMeteringAreas() > 0) {
                parameters.setMeteringAreas(null);
            }
            this.p.setParameters(parameters);
            a(false);
        } catch (Exception e2) {
            e2.getMessage();
        }
    }

    /* JADX WARN: Removed duplicated region for block: B:69:0x00f6  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    private synchronized void q() {
        /*
            Method dump skipped, instruction units count: 761
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: com.facetec.sdk.ap.q():void");
    }

    /* JADX INFO: Access modifiers changed from: private */
    public synchronized void r() {
        Camera camera = this.p;
        if (camera != null) {
            try {
                try {
                    camera.cancelAutoFocus();
                    a(true);
                    this.p.setPreviewCallback(null);
                    this.p.release();
                } catch (Exception e2) {
                    bh.e(e2.getMessage());
                }
            } finally {
                this.p = null;
            }
        }
        Handler handler = this.s;
        if (handler != null) {
            handler.removeCallbacksAndMessages(null);
        }
    }

    private long s() throws Throwable {
        if (this.I == -1) {
            return 0L;
        }
        try {
            Object[] objArr = new Object[1];
            W(16 - KeyEvent.keyCodeFromString(""), 236 - (ViewConfiguration.getMinimumFlingVelocity() >> 16), (ViewConfiguration.getScrollFriction() > SelfieScan.RECOGNITION_FAIL_RESULT ? 1 : (ViewConfiguration.getScrollFriction() == SelfieScan.RECOGNITION_FAIL_RESULT ? 0 : -1)) + 14, true, "\u0003\u0012\u0011\u0017\ufff1ￌ\u0005\f\uffff\nￌ\uffff\u0014\uffff\b\u000b", objArr);
            Class<?> cls = Class.forName((String) objArr[0]);
            Object[] objArr2 = new Object[1];
            W(TextUtils.getCapsMode("", 0, 0) + 8, TextUtils.getCapsMode("", 0, 0) + EnumC41897g.SDK_ASSET_ILLUSTRATION_PLAID_LOGO_NAVBAR_VALUE, View.getDefaultSize(0, 0) + 5, false, "\b￭\u0002\u0006\ufffe\u0007\ufffa\u0007", objArr2);
            long jLongValue = (((Long) cls.getMethod((String) objArr2[0], null).invoke(null, null)).longValue() / 1000000) - this.I;
            if (jLongValue < 8000) {
                return 8000 - jLongValue;
            }
            return 0L;
        } catch (Throwable th) {
            Throwable cause = th.getCause();
            if (cause != null) {
                throw cause;
            }
            throw th;
        }
    }

    private void t() {
        this.t = false;
        Camera camera = this.p;
        if (camera == null) {
            return;
        }
        try {
            camera.cancelAutoFocus();
        } catch (Exception unused) {
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void u() {
        this.B = false;
    }

    private boolean v() {
        String str = this.C;
        return str == "continuous-picture" || str == "continuous-video";
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void w() throws Throwable {
        if (this.B) {
            this.k = true;
            return;
        }
        t();
        p();
        this.k = true;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void x() {
        try {
            q();
        } catch (Exception e2) {
            n.a(e2);
            bh.e(e2.getMessage());
            b(e2.getMessage());
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void y() {
        i iVar = this.v;
        ar arVar = this.m;
        iVar.setAspectRatio(arVar.e, arVar.b);
    }

    @Override // com.facetec.sdk.ah
    public final void a() {
    }

    @Override // com.facetec.sdk.ah
    public final void b() {
    }

    public final void m() {
        if (this.u) {
            return;
        }
        this.v.getHolder().addCallback(this.q);
        this.u = true;
    }

    @Override // android.hardware.Camera.AutoFocusCallback
    public void onAutoFocus(boolean z, Camera camera) {
    }

    @Override // android.hardware.Camera.ErrorCallback
    public void onError(int i, Camera camera) {
        if (i == 100) {
            try {
                r();
                q();
                return;
            } catch (Exception e2) {
                n.a(e2);
                StringBuilder sb = new StringBuilder("Legacy camera error during cleanup and setup camera: ");
                sb.append(e2.getMessage());
                b(sb.toString());
                return;
            }
        }
        bi biVar = (bi) this.r.get();
        if (biVar.t() && i == 2) {
            t.d(biVar, c.CAMERA_EVICTED_CONTEXT_SWITCH, null, null);
            return;
        }
        try {
            throw new RuntimeException("Legacy camera error: ".concat(String.valueOf(i)));
        } catch (Exception e3) {
            n.a(e3);
            b("Legacy camera error with code: ".concat(String.valueOf(i)));
        }
    }

    public static /* synthetic */ boolean b(ap apVar) {
        apVar.u = false;
        return false;
    }

    /* JADX WARN: Removed duplicated region for block: B:223:0x09da  */
    /* JADX WARN: Removed duplicated region for block: B:228:0x09e7  */
    @Override // com.facetec.sdk.ah
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public void a(boolean r34) throws java.lang.Throwable {
        /*
            Method dump skipped, instruction units count: 2688
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: com.facetec.sdk.ap.a(boolean):void");
    }

    @Override // com.facetec.sdk.ah
    public final void b(boolean z) {
        r();
    }

    private static int a(int i) {
        int iRound = Math.round(150.0f);
        return Math.abs(i) + iRound > 1000 ? i > 0 ? 1000 - iRound : iRound - 1000 : i - iRound;
    }

    private void b(ViewGroup viewGroup) throws Throwable {
        if (this.p == null || this.t) {
            return;
        }
        e(b(ah.i, ah.j, viewGroup));
    }

    @Override // com.facetec.sdk.ah
    public final void c(boolean z, final ViewGroup viewGroup) throws Throwable {
        if (z) {
            this.y = true;
        }
        if (this.B) {
            return;
        }
        if (this.z) {
            new Handler(Looper.getMainLooper()).postDelayed(new Runnable() { // from class: com.facetec.sdk.字
                @Override // java.lang.Runnable
                public final void run() throws Throwable {
                    this.f7259.e(viewGroup);
                }
            }, s());
            return;
        }
        b(viewGroup);
    }

    @Override // com.facetec.sdk.ah
    public void d() throws Throwable {
        if (ah.c) {
            a(true);
            a(false);
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void e(ViewGroup viewGroup) throws Throwable {
        if (s() > 0) {
            return;
        }
        b(viewGroup);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void a(boolean z, Camera camera) throws Throwable {
        this.z = !z;
        this.t = z;
        try {
            Object[] objArr = new Object[1];
            W(16 - View.getDefaultSize(0, 0), (TypedValue.complexToFloat(0) > SelfieScan.RECOGNITION_FAIL_RESULT ? 1 : (TypedValue.complexToFloat(0) == SelfieScan.RECOGNITION_FAIL_RESULT ? 0 : -1)) + EnumC41897g.SDK_ASSET_ILLUSTRATION_INSTITUTION_TRANSFER_CIRCLE_VALUE, (AudioTrack.getMaxVolume() > SelfieScan.RECOGNITION_FAIL_RESULT ? 1 : (AudioTrack.getMaxVolume() == SelfieScan.RECOGNITION_FAIL_RESULT ? 0 : -1)) + 14, true, "\u0003\u0012\u0011\u0017\ufff1ￌ\u0005\f\uffff\nￌ\uffff\u0014\uffff\b\u000b", objArr);
            Class<?> cls = Class.forName((String) objArr[0]);
            Object[] objArr2 = new Object[1];
            W((ViewConfiguration.getZoomControlsTimeout() > 0L ? 1 : (ViewConfiguration.getZoomControlsTimeout() == 0L ? 0 : -1)) + 7, Drawable.resolveOpacity(0, 0) + EnumC41897g.SDK_ASSET_ILLUSTRATION_PLAID_LOGO_NAVBAR_VALUE, 5 - ((Process.getThreadPriority(0) + 20) >> 6), false, "\b￭\u0002\u0006\ufffe\u0007\ufffa\u0007", objArr2);
            this.I = ((Long) cls.getMethod((String) objArr2[0], null).invoke(null, null)).longValue() / 1000000;
            boolean z2 = this.z;
            if (this.y && z2) {
                cv.m(true);
                this.y = false;
            }
        } catch (Throwable th) {
            Throwable cause = th.getCause();
            if (cause == null) {
                throw th;
            }
            throw cause;
        }
    }

    private static Rect b(float f, float f2, @NonNull ViewGroup viewGroup) {
        int iA = a(Float.valueOf(((f / viewGroup.getWidth()) * 2000.0f) - 1000.0f).intValue());
        int iA2 = a(Float.valueOf(((f2 / viewGroup.getHeight()) * 2000.0f) - 1000.0f).intValue());
        return new Rect(iA, iA2, iA + EnumC41897g.SDK_ASSET_TRANSFER_ICON_CIRCLE_VALUE, iA2 + EnumC41897g.SDK_ASSET_TRANSFER_ICON_CIRCLE_VALUE);
    }

    private void e(Rect rect) throws Throwable {
        if (this.t || this.p == null || !this.A) {
            return;
        }
        this.t = true;
        try {
            Object[] objArr = new Object[1];
            W(KeyEvent.getDeadChar(0, 0) + 16, (ExpandableListView.getPackedPositionForChild(0, 0) > 0L ? 1 : (ExpandableListView.getPackedPositionForChild(0, 0) == 0L ? 0 : -1)) + EnumC41897g.SDK_ASSET_ILLUSTRATION_MD_ERROR_ATTEMPT_01_VALUE, 15 - (ViewConfiguration.getKeyRepeatTimeout() >> 16), true, "\u0003\u0012\u0011\u0017\ufff1ￌ\u0005\f\uffff\nￌ\uffff\u0014\uffff\b\u000b", objArr);
            Class<?> cls = Class.forName((String) objArr[0]);
            Object[] objArr2 = new Object[1];
            W(TextUtils.getCapsMode("", 0, 0) + 8, 241 - (ViewConfiguration.getScrollBarFadeDuration() >> 16), 5 - (TypedValue.complexToFraction(0, SelfieScan.RECOGNITION_FAIL_RESULT, SelfieScan.RECOGNITION_FAIL_RESULT) > SelfieScan.RECOGNITION_FAIL_RESULT ? 1 : (TypedValue.complexToFraction(0, SelfieScan.RECOGNITION_FAIL_RESULT, SelfieScan.RECOGNITION_FAIL_RESULT) == SelfieScan.RECOGNITION_FAIL_RESULT ? 0 : -1)), false, "\b￭\u0002\u0006\ufffe\u0007\ufffa\u0007", objArr2);
            this.I = ((Long) cls.getMethod((String) objArr2[0], null).invoke(null, null)).longValue() / 1000000;
            try {
                this.p.cancelAutoFocus();
                Camera.Parameters parameters = this.p.getParameters();
                if (parameters.getSupportedFocusModes().contains("auto")) {
                    parameters.setFocusMode("auto");
                }
                ArrayList arrayList = new ArrayList();
                arrayList.add(new Camera.Area(rect, 1000));
                if (parameters.getMaxNumFocusAreas() > 0) {
                    parameters.setFocusAreas(arrayList);
                }
                this.p.setParameters(parameters);
                a(false);
                this.p.autoFocus(this.F);
            } catch (Exception e2) {
                e2.getMessage();
                t();
                p();
            }
        } catch (Throwable th) {
            Throwable cause = th.getCause();
            if (cause == null) {
                throw th;
            }
            throw cause;
        }
    }

    @Override // com.facetec.sdk.ah
    public final void d(boolean z) throws Throwable {
        Camera camera = this.p;
        if (camera == null) {
            return;
        }
        Camera.Parameters parameters = camera.getParameters();
        List<String> supportedFlashModes = parameters.getSupportedFlashModes();
        if (supportedFlashModes != null && supportedFlashModes.size() > 0) {
            if (z && supportedFlashModes.contains("torch")) {
                parameters.setFlashMode("torch");
            } else if (!z && supportedFlashModes.contains("off")) {
                parameters.setFlashMode("off");
            }
        }
        this.p.setParameters(parameters);
        a(false);
    }

    /* JADX INFO: Access modifiers changed from: private */
    /* JADX INFO: renamed from: b, reason: merged with bridge method [inline-methods] */
    public void d(StackTraceElement[] stackTraceElementArr) {
        boolean z;
        int i = K;
        J = (i + 33) % 128;
        if (stackTraceElementArr.length < 4) {
            J = ((i & 113) + (i | 113)) % 128;
            return;
        }
        int i2 = 2;
        while (true) {
            if (!Objects.equals(stackTraceElementArr[i2].getClassName(), Method.class.getName())) {
                break;
            }
            int i3 = J;
            int i4 = (i3 & 65) + (i3 | 65);
            K = i4 % 128;
            if (i4 % 2 == 0) {
                int i5 = ((i2 | 7) << 1) - (i2 ^ 7);
                i2 = (i5 ^ 53) + ((i5 & 53) << 1);
            } else {
                i2++;
            }
        }
        Package r2 = getClass().getPackage();
        Objects.requireNonNull(r2);
        String name = r2.getName();
        int i6 = K + 117;
        while (true) {
            J = i6 % 128;
            if (i2 >= stackTraceElementArr.length) {
                break;
            }
            K = (J + 35) % 128;
            String className = stackTraceElementArr[i2].getClassName();
            if (!className.startsWith(name)) {
                int i7 = K + 93;
                J = i7 % 128;
                if (i7 % 2 == 0) {
                    z = className.startsWith("android.") ^ true;
                    int i8 = J;
                    K = ((i8 & 103) + (i8 | 103)) % 128;
                } else {
                    className.startsWith("android.");
                    throw null;
                }
            } else {
                int i9 = (i2 ^ EnumC41897g.SDK_ASSET_ILLUSTRATION_SIGNATURE_VALUE) + ((i2 & EnumC41897g.SDK_ASSET_ILLUSTRATION_SIGNATURE_VALUE) << 1);
                i2 = (i9 ^ (-123)) + ((i9 & (-123)) << 1);
                i6 = K + 91;
            }
        }
        cb.e(cb.b.a, z);
    }

    @Override // com.facetec.sdk.ah
    public final View c() {
        return this.v;
    }

    @Override // com.facetec.sdk.ah
    public final void c(ViewGroup viewGroup) {
        if (this.r.get() == null || this.p == null || !this.A) {
            return;
        }
        this.B = true;
        this.D.removeCallbacksAndMessages(null);
        this.D.postDelayed(new Runnable() { // from class: com.facetec.sdk.国
            @Override // java.lang.Runnable
            public final void run() {
                this.f7251.u();
            }
        }, 6000L);
        final Rect rectB = b(ah.i, ah.j, viewGroup);
        this.s.post(new Runnable() { // from class: com.facetec.sdk.土
            @Override // java.lang.Runnable
            public final void run() throws Throwable {
                this.f7252.d(rectB);
            }
        });
    }

    private static Camera a(Camera.CameraInfo cameraInfo) {
        int i = 0;
        try {
            Camera.getCameraInfo(0, cameraInfo);
        } catch (RuntimeException unused) {
            i = 1;
        }
        return Camera.open(i);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static /* synthetic */ int a(Camera.Size size, Camera.Size size2) {
        return (size2.width * size2.height) - (size.width * size.height);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void d(Rect rect) throws Throwable {
        try {
            t();
            e(rect);
        } catch (Exception unused) {
            t();
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void c(boolean z, Camera camera) throws Throwable {
        this.z = z;
        try {
            Object[] objArr = new Object[1];
            W((SystemClock.currentThreadTimeMillis() > (-1L) ? 1 : (SystemClock.currentThreadTimeMillis() == (-1L) ? 0 : -1)) + 15, 236 - View.MeasureSpec.makeMeasureSpec(0, 0), 14 - TextUtils.indexOf((CharSequence) "", '0'), true, "\u0003\u0012\u0011\u0017\ufff1ￌ\u0005\f\uffff\nￌ\uffff\u0014\uffff\b\u000b", objArr);
            Class<?> cls = Class.forName((String) objArr[0]);
            Object[] objArr2 = new Object[1];
            W(8 - (PointF.length(SelfieScan.RECOGNITION_FAIL_RESULT, SelfieScan.RECOGNITION_FAIL_RESULT) > SelfieScan.RECOGNITION_FAIL_RESULT ? 1 : (PointF.length(SelfieScan.RECOGNITION_FAIL_RESULT, SelfieScan.RECOGNITION_FAIL_RESULT) == SelfieScan.RECOGNITION_FAIL_RESULT ? 0 : -1)), 289 - AndroidCharacter.getMirror('0'), 5 - ExpandableListView.getPackedPositionType(0L), false, "\b￭\u0002\u0006\ufffe\u0007\ufffa\u0007", objArr2);
            this.I = ((Long) cls.getMethod((String) objArr2[0], null).invoke(null, null)).longValue() / 1000000;
            t();
            if (v()) {
                p();
            }
            if (this.y && z) {
                cv.m(true);
                this.y = false;
            }
        } catch (Throwable th) {
            Throwable cause = th.getCause();
            if (cause == null) {
                throw th;
            }
            throw cause;
        }
    }

    private static synchronized ar d(Camera camera) {
        ArrayList arrayList;
        try {
            arrayList = new ArrayList();
            List<Camera.Size> supportedPreviewSizes = camera.getParameters().getSupportedPreviewSizes();
            float fJ = ah.j();
            Collections.sort(supportedPreviewSizes, new Comparator() { // from class: com.facetec.sdk.史
                @Override // java.util.Comparator
                public final int compare(Object obj, Object obj2) {
                    return ap.b((Camera.Size) obj, (Camera.Size) obj2);
                }
            });
            StringBuilder sb = new StringBuilder();
            sb.append(supportedPreviewSizes.get(0).width);
            sb.append("x");
            sb.append(supportedPreviewSizes.get(0).height);
            ah.b = sb.toString();
            for (Camera.Size size : supportedPreviewSizes) {
                float f = size.width;
                if (f / size.height == fJ && f <= 1920.0f) {
                    arrayList.add(size);
                }
            }
        } catch (Throwable th) {
            throw th;
        }
        return new ar(((Camera.Size) arrayList.get(0)).width, ((Camera.Size) arrayList.get(0)).height);
    }

    @Override // com.facetec.sdk.ah
    public final void e(Camera.PictureCallback pictureCallback) throws Throwable {
        a(false);
        this.o = false;
        this.p.takePicture(null, null, pictureCallback);
    }

    public static synchronized ar b(Context context) {
        ar arVarB;
        Camera cameraE = e(context, new Camera.CameraInfo());
        arVarB = b(cameraE);
        cameraE.stopPreview();
        cameraE.release();
        return arVarB;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static /* synthetic */ int c(Camera.Size size, Camera.Size size2) {
        return (size2.width * size2.height) - (size.width * size.height);
    }

    private static JSONObject c(Camera.Parameters parameters) {
        JSONObject jSONObject = new JSONObject();
        try {
            jSONObject.put("SupportedVideoSizes", d(parameters.getSupportedVideoSizes()));
            jSONObject.put("SupportedPreviewSizes", d(parameters.getSupportedPreviewSizes()));
        } catch (JSONException unused) {
        }
        return jSONObject;
    }

    private static Camera e(Context context, Camera.CameraInfo cameraInfo) throws aw {
        int i;
        try {
            Camera.getCameraInfo(1, cameraInfo);
            i = 1;
        } catch (RuntimeException unused) {
            i = 0;
            Camera.getCameraInfo(0, cameraInfo);
        }
        ba.e("CLOT");
        ba.e("CLFFT");
        if (cameraInfo.facing == 1) {
            t.d(context, c.OPEN_FRONT_CAMERA1, null, null);
            Camera cameraOpen = Camera.open(i);
            ba.d("CLOT");
            return cameraOpen;
        }
        throw new aw("Front facing camera not available");
    }

    public static /* synthetic */ void c(final ap apVar) {
        apVar.s.post(new Runnable() { // from class: com.facetec.sdk.山
            @Override // java.lang.Runnable
            public final void run() {
                this.f7261.x();
            }
        });
    }

    private static String d(List<Camera.Size> list) throws Throwable {
        if (list == null) {
            return "";
        }
        StringBuilder sb = new StringBuilder();
        for (Camera.Size size : list) {
            sb.append(size.width);
            sb.append("x");
            sb.append(size.height);
            Object[] objArr = new Object[1];
            V((-878749184) - (ExpandableListView.getPackedPositionForGroup(0) > 0L ? 1 : (ExpandableListView.getPackedPositionForGroup(0) == 0L ? 0 : -1)), (byte) ((ViewConfiguration.getFadingEdgeLength() >> 16) + 71), View.getDefaultSize(0, 0) - 1398417541, 88095945 - TextUtils.getOffsetAfter("", 0), (short) ((-81) - (ViewConfiguration.getMaximumFlingVelocity() >> 16)), objArr);
            sb.append((String) objArr[0]);
        }
        if (sb.length() > 0) {
            sb.deleteCharAt(sb.length() - 1);
        }
        return sb.toString();
    }

    private static synchronized ar b(Camera camera) {
        Camera.Size preferredPreviewSizeForVideo;
        if (bh.c(ah.e.C2355e.a) && (preferredPreviewSizeForVideo = camera.getParameters().getPreferredPreviewSizeForVideo()) != null) {
            StringBuilder sb = new StringBuilder();
            sb.append(preferredPreviewSizeForVideo.width);
            sb.append("x");
            sb.append(preferredPreviewSizeForVideo.height);
            o.i = sb.toString();
            return new ar(preferredPreviewSizeForVideo.width, preferredPreviewSizeForVideo.height);
        }
        float[] fArr = {1.7f, 1.6f, 1.5f, 1.4f, 1.3f};
        ArrayList arrayList = new ArrayList();
        List<Camera.Size> supportedPreviewSizes = camera.getParameters().getSupportedPreviewSizes();
        Collections.sort(supportedPreviewSizes, new Comparator() { // from class: com.facetec.sdk.宫
            @Override // java.util.Comparator
            public final int compare(Object obj, Object obj2) {
                return ap.c((Camera.Size) obj, (Camera.Size) obj2);
            }
        });
        StringBuilder sb2 = new StringBuilder();
        sb2.append(supportedPreviewSizes.get(0).width);
        sb2.append("x");
        sb2.append(supportedPreviewSizes.get(0).height);
        ah.b = sb2.toString();
        o.e(supportedPreviewSizes);
        for (int i = 0; i < 5; i++) {
            float f = fArr[i];
            for (Camera.Size size : supportedPreviewSizes) {
                float f2 = size.width;
                float f3 = f2 / size.height;
                if (f3 >= f && f3 <= 1.9f && f2 >= 640.0f && f2 <= 1920.0f) {
                    arrayList.add(size);
                }
            }
            if (arrayList.size() > 0) {
                break;
            }
        }
        Camera.Size size2 = (Camera.Size) arrayList.get(0);
        List<Camera.Size> supportedVideoSizes = camera.getParameters().getSupportedVideoSizes();
        if (supportedVideoSizes != null && !supportedVideoSizes.contains(size2)) {
            o.h = true;
        }
        StringBuilder sb3 = new StringBuilder();
        sb3.append(((Camera.Size) arrayList.get(0)).width);
        sb3.append("x");
        sb3.append(((Camera.Size) arrayList.get(0)).height);
        o.i = sb3.toString();
        return new ar(((Camera.Size) arrayList.get(0)).width, ((Camera.Size) arrayList.get(0)).height);
    }

    @Override // com.facetec.sdk.ah
    public final void e() {
        this.G.set(true);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static /* synthetic */ int b(Camera.Size size, Camera.Size size2) {
        return (size2.width * size2.height) - (size.width * size.height);
    }

    private void b(String str) {
        bm bmVar = this.r.get();
        if (bmVar != null) {
            t.d(bmVar, c.CAMERA_LEGACY_ERROR, "CameraLegacy error: ".concat(String.valueOf(str)), null);
            bmVar.e(str);
        }
    }
}