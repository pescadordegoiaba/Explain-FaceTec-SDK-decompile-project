package com.facetec.sdk;

import android.view.ViewConfiguration;
import com.plaid.internal.EnumC41897g;
import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;
import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;
import net.sf.scuba.smartcards.ISO7816;
import net.sf.scuba.smartcards.ISOFileInfo;

/* JADX INFO: loaded from: classes4.dex */
abstract class aq {
    private static final byte[] $$d = null;
    private static final int $$e = 0;
    private static int $10;
    private static int $11;
    private static int c;
    private static long d;
    private static int e;

    /* JADX WARN: Removed duplicated region for block: B:10:0x0025  */
    /* JADX WARN: Removed duplicated region for block: B:8:0x001f  */
    /* JADX WARN: Unsupported multi-entry loop pattern (BACK_EDGE: B:10:0x0025 -> B:11:0x002a). Please report as a decompilation issue!!! */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    private static java.lang.String $$f(int r6, byte r7, int r8) {
        /*
            byte[] r0 = com.facetec.sdk.aq.$$d
            int r7 = r7 * 2
            int r1 = 1 - r7
            int r8 = r8 + 99
            int r6 = r6 + 4
            byte[] r1 = new byte[r1]
            r2 = 0
            int r7 = 0 - r7
            if (r0 != 0) goto L15
            r8 = r6
            r3 = r7
            r4 = r2
            goto L2a
        L15:
            r3 = r2
        L16:
            byte r4 = (byte) r8
            r1[r3] = r4
            int r4 = r3 + 1
            int r6 = r6 + 1
            if (r3 != r7) goto L25
            java.lang.String r6 = new java.lang.String
            r6.<init>(r1, r2)
            return r6
        L25:
            r3 = r0[r6]
            r5 = r8
            r8 = r6
            r6 = r5
        L2a:
            int r6 = r6 + r3
            r3 = r8
            r8 = r6
            r6 = r3
            r3 = r4
            goto L16
        */
        throw new UnsupportedOperationException("Method not decompiled: com.facetec.sdk.aq.$$f(int, byte, int):java.lang.String");
    }

    static {
        init$0();
        $10 = 0;
        $11 = 1;
        c = 0;
        e = 1;
        d = 2063519787685783347L;
    }

    public static byte[] c(Cipher cipher, byte[] bArr) {
        byte[] bArrDoFinal;
        int i = e + 109;
        c = i % 128;
        try {
            if (i % 2 != 0) {
                bArrDoFinal = cipher.doFinal(bArr);
                int i2 = 68 / 0;
            } else {
                bArrDoFinal = cipher.doFinal(bArr);
            }
            c = (e + 111) % 128;
            return bArrDoFinal;
        } catch (Exception e2) {
            n.a(e2);
            return null;
        }
    }

    public static byte[] d() throws Exception {
        SecureRandom secureRandom = new SecureRandom();
        try {
            Object[] objArr = new Object[1];
            j("䛅⋔軽", 25622 - (ViewConfiguration.getZoomControlsTimeout() > 0L ? 1 : (ViewConfiguration.getZoomControlsTimeout() == 0L ? 0 : -1)), objArr);
            KeyGenerator keyGenerator = KeyGenerator.getInstance(((String) objArr[0]).intern());
            keyGenerator.init(128, secureRandom);
            byte[] encoded = keyGenerator.generateKey().getEncoded();
            e = (c + 95) % 128;
            return encoded;
        } catch (NoSuchAlgorithmException e2) {
            throw new Exception(bh.e(e2.getMessage()));
        }
    }

    public static byte[] e(Cipher cipher, byte[] bArr) {
        int i = c + 109;
        e = i % 128;
        try {
            if (i % 2 == 0) {
                cipher.doFinal(bArr);
                throw null;
            }
            byte[] bArrDoFinal = cipher.doFinal(bArr);
            e = (c + 47) % 128;
            return bArrDoFinal;
        } catch (Exception e2) {
            n.a(e2);
            return null;
        }
    }

    public static void init$0() {
        $$d = new byte[]{ISO7816.INS_REHABILITATE_CHV, ISOFileInfo.DATA_BYTES2, 122, -15};
        $$e = EnumC41897g.SDK_ASSET_ICON_CHEVRON_LEFT_DOUBLE_S2_VALUE;
    }

    /* JADX WARN: Removed duplicated region for block: B:34:0x0150  */
    /* JADX WARN: Removed duplicated region for block: B:35:0x0151  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    private static void j(java.lang.String r22, int r23, java.lang.Object[] r24) throws java.lang.Throwable {
        /*
            Method dump skipped, instruction units count: 348
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: com.facetec.sdk.aq.j(java.lang.String, int, java.lang.Object[]):void");
    }
}