package com.facetec.sdk;

/* JADX INFO: loaded from: classes4.dex */
final class ar {
    public final int b;
    public final int e;

    public ar(int i, int i2) {
        this.b = i;
        this.e = i2;
    }
}