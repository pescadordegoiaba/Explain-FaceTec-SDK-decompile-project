package com.facetec.sdk;

import android.content.Context;
import android.graphics.Color;
import android.graphics.PointF;
import android.media.AudioTrack;
import android.os.Process;
import android.os.SystemClock;
import android.text.AndroidCharacter;
import android.text.TextUtils;
import android.util.TypedValue;
import android.view.KeyEvent;
import android.view.View;
import android.view.ViewConfiguration;
import android.widget.ExpandableListView;
import androidx.annotation.NonNull;
import com.facetec.sdk.cb;
import com.facetec.sdk.gn;
import com.facetec.sdk.j;
import com.facetec.sdk.mw;
import com.facetec.sdk.nf;
import com.incode.welcome_sdk.modules.SelfieScan;
import com.plaid.internal.EnumC41897g;
import java.io.File;
import java.io.IOException;
import java.lang.reflect.Method;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Date;
import java.util.List;
import java.util.concurrent.Semaphore;
import net.sf.scuba.smartcards.ISO7816;
import net.sf.scuba.smartcards.ISOFileInfo;
import org.jmrtd.PassportService;
import org.jmrtd.lds.CVCAFile;

/* JADX INFO: loaded from: classes4.dex */
class at {
    private static final byte[] $$a = null;
    private static final int $$b = 0;
    private static int $10;
    private static int $11;
    private static int a;
    private static volatile boolean b;
    private static int c;
    private static /* synthetic */ boolean d;

    @NonNull
    private static final Semaphore e;
    private static int f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    private static int f95822g;
    private static int h;
    private static short[] i;
    private static byte[] j;
    private static int m;
    private static int n;
    private static int o;

    /* JADX INFO: renamed from: com.facetec.sdk.at$2, reason: invalid class name */
    public static /* synthetic */ class AnonymousClass2 {
        static final /* synthetic */ int[] a;
        static final /* synthetic */ int[] d;

        static {
            int[] iArr = new int[FaceTecSessionStatus.values().length];
            a = iArr;
            try {
                iArr[FaceTecSessionStatus.SESSION_COMPLETED_SUCCESSFULLY.ordinal()] = 1;
            } catch (NoSuchFieldError unused) {
            }
            try {
                a[FaceTecSessionStatus.TIMEOUT.ordinal()] = 2;
            } catch (NoSuchFieldError unused2) {
            }
            try {
                a[FaceTecSessionStatus.CONTEXT_SWITCH.ordinal()] = 3;
            } catch (NoSuchFieldError unused3) {
            }
            try {
                a[FaceTecSessionStatus.REVERSE_PORTRAIT_NOT_ALLOWED.ordinal()] = 4;
            } catch (NoSuchFieldError unused4) {
            }
            try {
                a[FaceTecSessionStatus.LANDSCAPE_MODE_NOT_ALLOWED.ordinal()] = 5;
            } catch (NoSuchFieldError unused5) {
            }
            try {
                a[FaceTecSessionStatus.NON_PRODUCTION_MODE_KEY_INVALID.ordinal()] = 6;
            } catch (NoSuchFieldError unused6) {
            }
            try {
                a[FaceTecSessionStatus.USER_CANCELLED.ordinal()] = 7;
            } catch (NoSuchFieldError unused7) {
            }
            try {
                a[FaceTecSessionStatus.CAMERA_PERMISSION_DENIED.ordinal()] = 8;
            } catch (NoSuchFieldError unused8) {
            }
            try {
                a[FaceTecSessionStatus.SESSION_UNSUCCESSFUL.ordinal()] = 9;
            } catch (NoSuchFieldError unused9) {
            }
            int[] iArr2 = new int[ax.values().length];
            d = iArr2;
            try {
                iArr2[ax.FT_EVENT_ENROLL_SESSION_START.ordinal()] = 1;
            } catch (NoSuchFieldError unused10) {
            }
            try {
                d[ax.FT_EVENT_MID_ENROLL_SESSION_GLASSES_SUCCESS.ordinal()] = 2;
            } catch (NoSuchFieldError unused11) {
            }
            try {
                d[ax.FT_EVENT_ENROLL_SESSION_SUCCESS.ordinal()] = 3;
            } catch (NoSuchFieldError unused12) {
            }
            try {
                d[ax.FT_EVENT_ENROLL_SESSION_FAIL.ordinal()] = 4;
            } catch (NoSuchFieldError unused13) {
            }
            try {
                d[ax.FT_EVENT_ENROLL_SESSION_CANCEL.ordinal()] = 5;
            } catch (NoSuchFieldError unused14) {
            }
            try {
                d[ax.FT_EVENT_VERIFY_SESSION_START.ordinal()] = 6;
            } catch (NoSuchFieldError unused15) {
            }
            try {
                d[ax.FT_EVENT_VERIFY_SESSION_SUCCESS.ordinal()] = 7;
            } catch (NoSuchFieldError unused16) {
            }
            try {
                d[ax.FT_EVENT_VERIFY_SESSION_FAIL.ordinal()] = 8;
            } catch (NoSuchFieldError unused17) {
            }
            try {
                d[ax.FT_EVENT_VERIFY_SESSION_CANCEL.ordinal()] = 9;
            } catch (NoSuchFieldError unused18) {
            }
            try {
                d[ax.FT_EVENT_AUTH_SESSION_START.ordinal()] = 10;
            } catch (NoSuchFieldError unused19) {
            }
            try {
                d[ax.FT_EVENT_AUTH_SESSION_SUCCESS.ordinal()] = 11;
            } catch (NoSuchFieldError unused20) {
            }
            try {
                d[ax.FT_EVENT_AUTH_SESSION_FAIL.ordinal()] = 12;
            } catch (NoSuchFieldError unused21) {
            }
            try {
                d[ax.FT_EVENT_AUTH_SESSION_CANCEL.ordinal()] = 13;
            } catch (NoSuchFieldError unused22) {
            }
            try {
                d[ax.FT_EVENT_DIAGNOSTIC_UPLOAD_FAIL.ordinal()] = 14;
            } catch (NoSuchFieldError unused23) {
            }
            try {
                d[ax.FT_EVENT_FACESCAN_SESSION_SUCCESS.ordinal()] = 15;
            } catch (NoSuchFieldError unused24) {
            }
            try {
                d[ax.FT_EVENT_PHOENIX_SESSION_FAIL.ordinal()] = 16;
            } catch (NoSuchFieldError unused25) {
            }
            try {
                d[ax.FT_EVENT_FACESCAN_SESSION_FAIL.ordinal()] = 17;
            } catch (NoSuchFieldError unused26) {
            }
        }
    }

    public static class b {

        @fe(a = "diagnosticSessionId")
        private String a;

        @fe(a = "time")
        private long b;

        @fe(a = "event")
        private String c;

        @fe(a = "diagnosticId")
        private String e;

        public b(String str, long j, String str2, String str3) {
            this.c = str;
            this.b = j;
            this.a = str2;
            this.e = str3;
        }
    }

    /* JADX WARN: Removed duplicated region for block: B:10:0x0023  */
    /* JADX WARN: Removed duplicated region for block: B:8:0x001d  */
    /* JADX WARN: Unsupported multi-entry loop pattern (BACK_EDGE: B:10:0x0023 -> B:11:0x0028). Please report as a decompilation issue!!! */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    private static java.lang.String $$c(short r7, int r8, short r9) {
        /*
            byte[] r0 = com.facetec.sdk.at.$$a
            int r7 = r7 + 102
            int r8 = r8 * 4
            int r8 = 1 - r8
            int r9 = r9 * 2
            int r9 = 4 - r9
            byte[] r1 = new byte[r8]
            r2 = 0
            if (r0 != 0) goto L15
            r3 = r8
            r7 = r9
            r5 = r2
            goto L28
        L15:
            r3 = r2
        L16:
            byte r4 = (byte) r7
            int r5 = r3 + 1
            r1[r3] = r4
            if (r5 != r8) goto L23
            java.lang.String r7 = new java.lang.String
            r7.<init>(r1, r2)
            return r7
        L23:
            r3 = r0[r9]
            r6 = r9
            r9 = r7
            r7 = r6
        L28:
            int r9 = r9 + r3
            int r7 = r7 + 1
            r3 = r9
            r9 = r7
            r7 = r3
            r3 = r5
            goto L16
        */
        throw new UnsupportedOperationException("Method not decompiled: com.facetec.sdk.at.$$c(short, int, short):java.lang.String");
    }

    static {
        init$0();
        $10 = 0;
        $11 = 1;
        n = 0;
        o = 1;
        h = 0;
        m = 1;
        b();
        o = (n + 83) % 128;
        d = true;
        e = new Semaphore(1);
        b = false;
        int i2 = o + 37;
        n = i2 % 128;
        if (i2 % 2 != 0) {
            int i3 = 1 / 0;
        }
    }

    public static /* synthetic */ boolean a() {
        int i2 = h + 61;
        m = i2 % 128;
        if (i2 % 2 != 0) {
            return b;
        }
        int i3 = 26 / 0;
        return b;
    }

    private static /* synthetic */ Object b(Object[] objArr) {
        Context context = (Context) objArr[0];
        String str = (String) objArr[1];
        long jLongValue = ((Number) objArr[2]).longValue();
        String str2 = (String) objArr[3];
        String str3 = (String) objArr[4];
        int i2 = m + EnumC41897g.SDK_ASSET_ILLUSTRATION_CALENDAR_VALUE;
        h = i2 % 128;
        int i3 = i2 % 2;
        e(context, str, jLongValue, str2, str3);
        if (i3 != 0) {
            int i4 = 13 / 0;
        }
        int i5 = m + 63;
        h = i5 % 128;
        if (i5 % 2 != 0) {
            int i6 = 2 / 0;
        }
        return null;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static /* synthetic */ void c(final Context context, final String str, final String str2, final String str3, final boolean z, final long j2, final Runnable runnable) throws Throwable {
        Object obj;
        nf nfVarB = ay.b(context);
        StringBuilder sb = new StringBuilder();
        Object[] objArr = new Object[1];
        k((short) (34 - TextUtils.lastIndexOf("", '0', 0, 0)), 328318479 - View.MeasureSpec.getMode(0), (ExpandableListView.getPackedPositionForChild(0, 0) > 0L ? 1 : (ExpandableListView.getPackedPositionForChild(0, 0) == 0L ? 0 : -1)) - 80, (-1047137232) + (TypedValue.complexToFraction(0, SelfieScan.RECOGNITION_FAIL_RESULT, SelfieScan.RECOGNITION_FAIL_RESULT) > SelfieScan.RECOGNITION_FAIL_RESULT ? 1 : (TypedValue.complexToFraction(0, SelfieScan.RECOGNITION_FAIL_RESULT, SelfieScan.RECOGNITION_FAIL_RESULT) == SelfieScan.RECOGNITION_FAIL_RESULT ? 0 : -1)), (byte) ((-98) - (ViewConfiguration.getKeyRepeatDelay() >> 16)), objArr);
        sb.append(((String) objArr[0]).intern());
        sb.append(bk.e);
        String string = sb.toString();
        mw.c cVar = new mw.c();
        Object[] objArr2 = new Object[1];
        k((short) ((ExpandableListView.getPackedPositionForGroup(0) > 0L ? 1 : (ExpandableListView.getPackedPositionForGroup(0) == 0L ? 0 : -1)) + 10), TextUtils.indexOf("", "") + 328318476, 65459 - AndroidCharacter.getMirror('0'), (ViewConfiguration.getJumpTapTimeout() >> 16) - 1047137188, (byte) (10 - TextUtils.getOffsetBefore("", 0)), objArr2);
        mw.c cVarE = cVar.e(((String) objArr2[0]).intern(), str);
        Object[] objArr3 = new Object[1];
        l(TextUtils.lastIndexOf("", '0') + 20, false, TextUtils.getOffsetBefore("", 0) + EnumC41897g.SDK_ASSET_ILLUSTRATION_PINWHEEL_LOGO_VALUE, "\u0002￼￬\ufffe\f\f\u0002\b\u0007￢��\u0002\ufffa\u0000\u0007\b\f\r", TextUtils.indexOf((CharSequence) "", '0') + 12, objArr3);
        cVarE.e(((String) objArr3[0]).intern(), str2);
        if (str3 != null) {
            int i2 = h + 29;
            m = i2 % 128;
            if (i2 % 2 == 0) {
                Object[] objArr4 = new Object[1];
                l(Process.getGidForName("") * 17, true, 23102 >> (ViewConfiguration.getWindowTouchSlop() - 12), "\ufffe\u0003\ufffb\u0001\b\t\r\u000e\u0003�￣\ufffe", 85 % (SystemClock.uptimeMillis() > 1L ? 1 : (SystemClock.uptimeMillis() == 1L ? 0 : -1)), objArr4);
                obj = objArr4[0];
            } else {
                Object[] objArr5 = new Object[1];
                l(Process.getGidForName("") + 13, false, 181 - (ViewConfiguration.getWindowTouchSlop() >> 8), "\ufffe\u0003\ufffb\u0001\b\t\r\u000e\u0003�￣\ufffe", 13 - (SystemClock.uptimeMillis() > 0L ? 1 : (SystemClock.uptimeMillis() == 0L ? 0 : -1)), objArr5);
                obj = objArr5[0];
            }
            cVarE.e(((String) obj).intern(), str3);
        }
        try {
            nfVarB.b(j.e(context, string).b(cVarE.b()).d()).e(new mm() { // from class: com.facetec.sdk.at.1
                private static final byte[] $$a = null;
                private static final int $$b = 0;
                private static int i;
                private static int j;

                static {
                    init$0();
                    i = 0;
                    j = 1;
                }

                public static void e(long j3, long j4) throws Throwable {
                    Object obj2;
                    int i3 = j;
                    int i4 = i3 ^ 41;
                    int i5 = (i3 & 41) << 1;
                    int i6 = (i4 & i5) + (i5 | i4);
                    i = i6 % 128;
                    if (i6 % 2 != 0) {
                        obj2 = cb.a.class.getField("a").get(null);
                        int i7 = 67 / 0;
                    } else {
                        obj2 = cb.a.class.getField("a").get(null);
                    }
                    int i8 = i;
                    int i9 = i8 & 25;
                    int i10 = (i8 ^ 25) | i9;
                    int i11 = ((i9 & i10) + (i10 | i9)) % 128;
                    j = i11;
                    int i12 = i11 & 65;
                    i = ((((i11 ^ 65) | i12) << 1) - ((~i12) & (i11 | 65))) % 128;
                    try {
                        Object[] objArr6 = {null, obj2};
                        byte[] bArr = $$a;
                        byte b2 = bArr[1];
                        byte b3 = (byte) (-b2);
                        Object[] objArr7 = new Object[1];
                        h(b3, (byte) (b3 - 1), (byte) (-b2), objArr7);
                        Class<?> cls = Class.forName((String) objArr7[0]);
                        byte b4 = bArr[1];
                        byte b5 = (byte) (b4 + 1);
                        byte b6 = (byte) (-b4);
                        Object[] objArr8 = new Object[1];
                        h(b5, b6, (byte) (b6 - 1), objArr8);
                        Method method = cls.getMethod((String) objArr8[0], Context.class, cb.a.class);
                        method.setAccessible(true);
                        method.invoke(null, objArr6);
                        int i13 = j;
                        int i14 = i13 & 87;
                        int i15 = (i13 | 87) & (~i14);
                        int i16 = -(-(i14 << 1));
                        int i17 = (i15 & i16) + (i15 | i16);
                        i = i17 % 128;
                        if (i17 % 2 != 0) {
                            int i18 = 12 / 0;
                        }
                    } catch (Throwable th) {
                        Throwable cause = th.getCause();
                        if (cause == null) {
                            throw th;
                        }
                        throw cause;
                    }
                }

                /* JADX WARN: Removed duplicated region for block: B:10:0x0025  */
                /* JADX WARN: Removed duplicated region for block: B:8:0x001d  */
                /* JADX WARN: Unsupported multi-entry loop pattern (BACK_EDGE: B:10:0x0025 -> B:11:0x002e). Please report as a decompilation issue!!! */
                /*
                    Code decompiled incorrectly, please refer to instructions dump.
                    To view partially-correct code enable 'Show inconsistent code' option in preferences
                */
                private static void h(byte r6, short r7, short r8, java.lang.Object[] r9) {
                    /*
                        int r6 = r6 * 17
                        int r0 = r6 + 1
                        int r7 = r7 * 2
                        int r7 = r7 + 99
                        int r8 = r8 * 17
                        int r8 = 20 - r8
                        byte[] r1 = com.facetec.sdk.at.AnonymousClass1.$$a
                        byte[] r0 = new byte[r0]
                        r2 = 0
                        if (r1 != 0) goto L17
                        r4 = r6
                        r7 = r8
                        r3 = r2
                        goto L2e
                    L17:
                        r3 = r2
                    L18:
                        byte r4 = (byte) r7
                        r0[r3] = r4
                        if (r3 != r6) goto L25
                        java.lang.String r6 = new java.lang.String
                        r6.<init>(r0, r2)
                        r9[r2] = r6
                        return
                    L25:
                        int r8 = r8 + 1
                        int r3 = r3 + 1
                        r4 = r1[r8]
                        r5 = r8
                        r8 = r7
                        r7 = r5
                    L2e:
                        int r8 = r8 + r4
                        int r8 = r8 + 3
                        r5 = r8
                        r8 = r7
                        r7 = r5
                        goto L18
                    */
                    throw new UnsupportedOperationException("Method not decompiled: com.facetec.sdk.at.AnonymousClass1.h(byte, short, short, java.lang.Object[]):void");
                }

                public static void init$0() {
                    $$a = new byte[]{108, -1, ISO7816.INS_UPDATE_RECORD, 99, 9, -5, -66, 53, -8, -1, -1, PassportService.SFI_DG12, -18, -5, -56, CVCAFile.CAR_TAG, -18, 4, ISO7816.INS_GET_RESPONSE, ISO7816.INS_INCREASE, -4};
                    $$b = EnumC41897g.SDK_ASSET_ICON_CHECKMARK_BLUE_VALUE;
                }

                @Override // com.facetec.sdk.mm
                public final void b(nh nhVar) {
                    if (at.a()) {
                        Object[] objArr6 = {context};
                        int iC = gn.AnonymousClass22.c();
                        int iC2 = gn.AnonymousClass22.c();
                        at.d(gn.AnonymousClass22.c(), gn.AnonymousClass22.c(), iC, objArr6, iC2, 1567752626, -1567752625);
                    }
                }

                @Override // com.facetec.sdk.mm
                public final void c(IOException iOException) {
                    if (z) {
                        Context context2 = context;
                        String str4 = str;
                        long j3 = j2;
                        Object[] objArr6 = {context2, str4, Long.valueOf(j3), str2, str3};
                        int iC = gn.AnonymousClass22.c();
                        int iC2 = gn.AnonymousClass22.c();
                        at.d(gn.AnonymousClass22.c(), gn.AnonymousClass22.c(), iC, objArr6, iC2, -1467494892, 1467494892);
                    }
                    Runnable runnable2 = runnable;
                    if (runnable2 != null) {
                        runnable2.run();
                    }
                }
            });
            h = (m + 125) % 128;
        } catch (j.c unused) {
            e(context, str, j2, str2, str3);
        }
    }

    public static /* synthetic */ Object d(int i2, int i3, int i4, Object[] objArr, int i5, int i6, int i7) {
        int i8 = ~i4;
        int i9 = (~(i8 | i7)) | i6;
        int i10 = ~i7;
        int i11 = i8 | i6;
        int i12 = (~(i4 | i10 | i6)) | (~(i11 | i7));
        int i13 = (~i11) | (~(i10 | (~i6)));
        int i14 = i6 + i7 + i5 + (1353909401 * i3) + ((-1351514252) * i2);
        int i15 = i14 * i14;
        int i16 = (1883508457 * i6) + 799145984 + ((-1483212659) * i7) + (2050486552 * i9) + (i12 * 1122240372) + (1122240372 * i13) + ((-360972288) * i5) + (337379328 * i3) + ((-1540358144) * i2) + (669122560 * i15);
        int i17 = ((i6 * 521834465) - 1171472169) + (i7 * 521833829) + (i9 * (-424)) + (i12 * EnumC41897g.SDK_ASSET_ICON_OVERRIDE_VALUE) + (i13 * EnumC41897g.SDK_ASSET_ICON_OVERRIDE_VALUE) + (i5 * 521834041) + (i3 * 1123214353) + (i2 * (-684621612)) + (i15 * 1028784128);
        int i18 = i16 + (i17 * i17 * 1635647488);
        return i18 != 1 ? i18 != 2 ? b(objArr) : c(objArr) : d(objArr);
    }

    public static void e(@NonNull Context context, @NonNull ax axVar) {
        h = (m + 125) % 128;
        d(context, axVar, true, null);
        int i2 = h + EnumC41897g.SDK_ASSET_ILLUSTRATION_DEPOSIT_SWITCH_VALUE;
        m = i2 % 128;
        if (i2 % 2 == 0) {
            throw null;
        }
    }

    public static void init$0() {
        $$a = new byte[]{51, -39, ISOFileInfo.FCP_BYTE, -44};
        $$b = EnumC41897g.SDK_ASSET_ILLUSTRATION_CALENDAR_VALUE;
    }

    private static void k(short s, int i2, int i3, int i4, byte b2, Object[] objArr) throws Throwable {
        int i5;
        long j2;
        int i6;
        long j3;
        int i7;
        int i8;
        int i9;
        int i10;
        int i11;
        int i12;
        byte b3;
        hh hhVar = new hh();
        StringBuilder sb = new StringBuilder();
        try {
            int i13 = 1;
            Object[] objArr2 = {Integer.valueOf(i3), Integer.valueOf(c)};
            int i14 = 0;
            Object objD = an.d(962055330);
            byte b4 = -1;
            Class cls = Integer.TYPE;
            if (objD == null) {
                int iBlue = 24 - Color.blue(0);
                byte length = (byte) $$a.length;
                i5 = 962055330;
                byte b5 = (byte) (length - 4);
                j2 = 0;
                objD = an.d(2402 - TextUtils.indexOf("", ""), (char) ((ViewConfiguration.getZoomControlsTimeout() > 0L ? 1 : (ViewConfiguration.getZoomControlsTimeout() == 0L ? 0 : -1)) - 1), iBlue, 1328947193, false, $$c(length, b5, b5), new Class[]{cls, cls});
            } else {
                i5 = 962055330;
                j2 = 0;
            }
            int iIntValue = ((Integer) ((Method) objD).invoke(null, objArr2)).intValue();
            boolean z = iIntValue == -1;
            if (z) {
                byte[] bArr = j;
                if (bArr != null) {
                    int length2 = bArr.length;
                    byte[] bArr2 = new byte[length2];
                    int i15 = 0;
                    j3 = -7666492657327691677L;
                    while (i15 < length2) {
                        $10 = ($11 + 21) % 128;
                        Object[] objArr3 = {Integer.valueOf(bArr[i15])};
                        Object objD2 = an.d(399840230);
                        if (objD2 == null) {
                            b3 = b4;
                            int i16 = (SystemClock.elapsedRealtime() > j2 ? 1 : (SystemClock.elapsedRealtime() == j2 ? 0 : -1)) + 2063;
                            i11 = i13;
                            char defaultSize = (char) (View.getDefaultSize(i14, i14) + 14866);
                            int iIndexOf = 23 - TextUtils.indexOf((CharSequence) "", '0', i14);
                            byte b6 = (byte) ($$b & 5);
                            i12 = i14;
                            byte b7 = (byte) (b6 - 1);
                            objD2 = an.d(i16, defaultSize, iIndexOf, 1639235773, false, $$c(b6, b7, b7), new Class[]{cls});
                        } else {
                            i11 = i13;
                            i12 = i14;
                            b3 = b4;
                        }
                        bArr2[i15] = ((Byte) ((Method) objD2).invoke(null, objArr3)).byteValue();
                        i15++;
                        i13 = i11;
                        b4 = b3;
                        i14 = i12;
                    }
                    bArr = bArr2;
                } else {
                    j3 = -7666492657327691677L;
                }
                i6 = i13;
                int i17 = i14;
                if (bArr != null) {
                    byte[] bArr3 = j;
                    Object[] objArr4 = new Object[2];
                    objArr4[i6] = Integer.valueOf(a);
                    objArr4[i17] = Integer.valueOf(i4);
                    Object objD3 = an.d(i5);
                    if (objD3 == null) {
                        int defaultSize2 = 24 - View.getDefaultSize(i17, i17);
                        byte length3 = (byte) $$a.length;
                        byte b8 = (byte) (length3 - 4);
                        objD3 = an.d((ViewConfiguration.getMinimumFlingVelocity() >> 16) + 2402, (char) ((Process.getElapsedCpuTime() > j2 ? 1 : (Process.getElapsedCpuTime() == j2 ? 0 : -1)) - 1), defaultSize2, 1328947193, false, $$c(length3, b8, b8), new Class[]{cls, cls});
                    }
                    iIntValue = (byte) (((byte) (((long) bArr3[((Integer) ((Method) objD3).invoke(null, objArr4)).intValue()]) ^ j3)) + ((int) (((long) c) ^ j3)));
                } else {
                    iIntValue = (short) (((short) (((long) i[i4 + ((int) (((long) a) ^ j3))]) ^ j3)) + ((int) (((long) c) ^ j3)));
                }
            } else {
                i6 = 1;
                j3 = -7666492657327691677L;
            }
            if (iIntValue > 0) {
                int i18 = ($11 + 29) % 128;
                $10 = i18;
                int i19 = ((i4 + iIntValue) - 2) + ((int) (((long) a) ^ j3));
                if (z) {
                    $11 = (i18 + 41) % 128;
                    i7 = i6;
                } else {
                    i7 = 0;
                }
                hhVar.d = i19 + i7;
                int i20 = f;
                Object[] objArr5 = new Object[4];
                objArr5[3] = sb;
                objArr5[2] = Integer.valueOf(i20);
                objArr5[i6] = Integer.valueOf(i2);
                objArr5[0] = hhVar;
                Object objD4 = an.d(-1066327576);
                if (objD4 == null) {
                    byte b9 = (byte) 0;
                    byte b10 = b9;
                    objD4 = an.d(1803 - (TypedValue.complexToFraction(0, SelfieScan.RECOGNITION_FAIL_RESULT, SelfieScan.RECOGNITION_FAIL_RESULT) > SelfieScan.RECOGNITION_FAIL_RESULT ? 1 : (TypedValue.complexToFraction(0, SelfieScan.RECOGNITION_FAIL_RESULT, SelfieScan.RECOGNITION_FAIL_RESULT) == SelfieScan.RECOGNITION_FAIL_RESULT ? 0 : -1)), (char) (9692 - (ViewConfiguration.getFadingEdgeLength() >> 16)), (TypedValue.complexToFraction(0, SelfieScan.RECOGNITION_FAIL_RESULT, SelfieScan.RECOGNITION_FAIL_RESULT) > SelfieScan.RECOGNITION_FAIL_RESULT ? 1 : (TypedValue.complexToFraction(0, SelfieScan.RECOGNITION_FAIL_RESULT, SelfieScan.RECOGNITION_FAIL_RESULT) == SelfieScan.RECOGNITION_FAIL_RESULT ? 0 : -1)) + 24, -1240403277, false, $$c(b9, b10, b10), new Class[]{Object.class, cls, cls, Object.class});
                }
                ((StringBuilder) ((Method) objD4).invoke(null, objArr5)).append(hhVar.e);
                hhVar.c = hhVar.e;
                byte[] bArr4 = j;
                if (bArr4 != null) {
                    int length4 = bArr4.length;
                    byte[] bArr5 = new byte[length4];
                    for (int i21 = 0; i21 < length4; i21++) {
                        bArr5[i21] = (byte) (((long) bArr4[i21]) ^ j3);
                    }
                    bArr4 = bArr5;
                }
                if (bArr4 != null) {
                    i8 = i6;
                    i9 = i8;
                } else {
                    i8 = i6;
                    i9 = 0;
                }
                hhVar.b = i8;
                while (hhVar.b < iIntValue) {
                    if ((i9 ^ 1) != i8) {
                        int i22 = $11 + 15;
                        $10 = i22 % 128;
                        if (i22 % 2 != 0) {
                            byte[] bArr6 = j;
                            hhVar.d = hhVar.d + 1;
                            i10 = hhVar.c % (((byte) (((byte) (((long) bArr6[r3]) + j3)) * s)) ^ b2);
                        } else {
                            byte[] bArr7 = j;
                            hhVar.d = hhVar.d - 1;
                            i10 = hhVar.c + (((byte) (((byte) (((long) bArr7[r3]) ^ j3)) + s)) ^ b2);
                        }
                        hhVar.e = (char) i10;
                    } else {
                        short[] sArr = i;
                        hhVar.d = hhVar.d - 1;
                        hhVar.e = (char) (hhVar.c + (((short) (((short) (((long) sArr[r3]) ^ j3)) + s)) ^ b2));
                    }
                    sb.append(hhVar.e);
                    hhVar.c = hhVar.e;
                    hhVar.b++;
                    i8 = 1;
                }
            }
            objArr[0] = sb.toString();
        } catch (Throwable th) {
            Throwable cause = th.getCause();
            if (cause == null) {
                throw th;
            }
            throw cause;
        }
    }

    /* JADX WARN: Removed duplicated region for block: B:40:0x0177  */
    /* JADX WARN: Removed duplicated region for block: B:41:0x0178  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    private static void l(int r28, boolean r29, int r30, java.lang.String r31, int r32, java.lang.Object[] r33) throws java.lang.Throwable {
        /*
            Method dump skipped, instruction units count: 389
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: com.facetec.sdk.at.l(int, boolean, int, java.lang.String, int, java.lang.Object[]):void");
    }

    private static void a(Context context, List<b> list) throws Throwable {
        Object[] objArr = new Object[1];
        k((short) (TextUtils.lastIndexOf("", '0', 0, 0) - 86), 328318480 - (ViewConfiguration.getGlobalActionKeyTimeout() > 0L ? 1 : (ViewConfiguration.getGlobalActionKeyTimeout() == 0L ? 0 : -1)), (-74) - (ViewConfiguration.getWindowTouchSlop() >> 8), (-1047137348) + (Process.myTid() >> 22), (byte) (Color.argb(0, 0, 0, 0) - 126), objArr);
        try {
            ay.b(context).b(j.b(context, ((String) objArr[0]).intern(), list)).e(new mm() { // from class: com.facetec.sdk.at.5
                @Override // com.facetec.sdk.mm
                public final void b(nh nhVar) {
                }

                @Override // com.facetec.sdk.mm
                public final void c(IOException iOException) {
                }
            });
            int i2 = m + 15;
            h = i2 % 128;
            if (i2 % 2 != 0) {
                throw null;
            }
        } catch (j.c e2) {
            Object[] objArr2 = new Object[1];
            k((short) ((ViewConfiguration.getScrollFriction() > SelfieScan.RECOGNITION_FAIL_RESULT ? 1 : (ViewConfiguration.getScrollFriction() == SelfieScan.RECOGNITION_FAIL_RESULT ? 0 : -1)) + EnumC41897g.SDK_ASSET_ILLUSTRATION_CALENDAR_VALUE), ((byte) KeyEvent.getModifierMetaStateMask()) + 328318443, TextUtils.indexOf((CharSequence) "", '0', 0, 0) - 78, Color.rgb(0, 0, 0) - 1030360081, (byte) ((-53) - (ViewConfiguration.getMaximumDrawingCacheSize() >> 24)), objArr2);
            ((String) objArr2[0]).intern();
            e2.getMessage();
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static /* synthetic */ void b(Context context) throws Throwable {
        List<b> listC;
        try {
            try {
                Semaphore semaphore = e;
                semaphore.acquire();
                listC = c(context, Boolean.TRUE);
                semaphore.release();
                m = (h + 49) % 128;
            } catch (Exception e2) {
                e2.printStackTrace();
                e.release();
                listC = null;
            }
            if (listC == null || !(!listC.isEmpty())) {
                return;
            }
            m = (h + 47) % 128;
            a(context, listC);
        } catch (Throwable th) {
            e.release();
            throw th;
        }
    }

    public static void d(@NonNull Context context, @NonNull ax axVar, boolean z, final Runnable runnable) {
        Context context2;
        String str;
        h = (m + 23) % 128;
        if (!((Boolean) bk.d(-261957882, nf.a.e(), nf.a.e(), nf.a.e(), nf.a.e(), new Object[0], 261957889)).booleanValue()) {
            h = (m + EnumC41897g.SDK_ASSET_ILLUSTRATION_CALENDAR_VALUE) % 128;
            return;
        }
        final String strC = cj.c(d(axVar));
        final long time = new Date().getTime();
        String str2 = null;
        if (axVar.c()) {
            int i2 = h + 63;
            m = i2 % 128;
            if (i2 % 2 == 0) {
                String str3 = cp.a;
                throw null;
            }
            str2 = cp.c;
        }
        final String str4 = str2;
        String str5 = cp.a;
        if (bk.e == null) {
            context2 = context;
            e(context2, strC, time, str5, str4);
            str = str5;
            str4 = str4;
        } else {
            context2 = context;
            str = str5;
        }
        final Context context3 = context2;
        final boolean z2 = true;
        final String str6 = str;
        dj.d(new Runnable() { // from class: com.facetec.sdk.弓
            @Override // java.lang.Runnable
            public final void run() throws Throwable {
                at.c(context3, strC, str6, str4, z2, time, runnable);
            }
        });
    }

    private static void e(@NonNull Context context, String str, long j2, String str2, String str3) {
        d(context, Collections.singletonList(new b(str, j2, str2, str3)));
        h = (m + 25) % 128;
    }

    public static void a(@NonNull Context context) {
        int iC = gn.AnonymousClass22.c();
        int iC2 = gn.AnonymousClass22.c();
        int iC3 = gn.AnonymousClass22.c();
        d(gn.AnonymousClass22.c(), iC3, iC, new Object[]{context}, iC2, 1567752626, -1567752625);
    }

    @NonNull
    private static List<b> c(@NonNull Context context, Boolean bool) {
        File cacheDir = context.getCacheDir();
        int iC = gn.AnonymousClass22.c();
        int iC2 = gn.AnonymousClass22.c();
        int iC3 = gn.AnonymousClass22.c();
        File file = new File(cacheDir, (String) d(gn.AnonymousClass22.c(), iC3, iC, new Object[0], iC2, -1470815423, 1470815425));
        if (file.exists()) {
            b[] bVarArr = (b[]) new el().c(new String(bq.e(file, d(context)), StandardCharsets.UTF_8), b[].class);
            if (bool.booleanValue()) {
                int i2 = h + 95;
                m = i2 % 128;
                int i3 = i2 % 2;
                file.delete();
                b = false;
            }
            return new ArrayList(Arrays.asList(bVarArr));
        }
        ArrayList arrayList = new ArrayList();
        int i4 = m + 103;
        h = i4 % 128;
        if (i4 % 2 == 0) {
            return arrayList;
        }
        throw null;
    }

    private static void b(@NonNull Context context, List<b> list) throws Throwable {
        String strE = new el().e(list);
        byte[] bArrD = d(context);
        File cacheDir = context.getCacheDir();
        int iC = gn.AnonymousClass22.c();
        int iC2 = gn.AnonymousClass22.c();
        int iC3 = gn.AnonymousClass22.c();
        bq.d(new File(cacheDir, (String) d(gn.AnonymousClass22.c(), iC3, iC, new Object[0], iC2, -1470815423, 1470815425)), bArrD, strE.getBytes(StandardCharsets.UTF_8));
        m = (h + 81) % 128;
    }

    private static /* synthetic */ Object d(Object[] objArr) {
        Context context = (Context) objArr[0];
        int i2 = h + 29;
        m = i2 % 128;
        if (i2 % 2 != 0) {
            final Context applicationContext = context.getApplicationContext();
            dj.d(new Runnable() { // from class: com.facetec.sdk.战
                @Override // java.lang.Runnable
                public final void run() throws Throwable {
                    at.b(applicationContext);
                }
            });
            return null;
        }
        final Context applicationContext2 = context.getApplicationContext();
        dj.d(new Runnable() { // from class: com.facetec.sdk.战
            @Override // java.lang.Runnable
            public final void run() throws Throwable {
                at.b(applicationContext2);
            }
        });
        throw null;
    }

    public static void b() {
        a = 951952423;
        c = 114796573;
        f = -356914630;
        j = new byte[]{-81, -67, -75, -72, -70, -81, 122, -7, -73, -72, -88, -70, ISOFileInfo.DATA_BYTES1, -92, 126, -12, ISO7816.INS_READ_BINARY, -70, -83, 67, ISO7816.INS_READ_BINARY, -13, 127, -8, ISO7816.INS_READ_BINARY2, ISOFileInfo.FCI_EXT, ISOFileInfo.FMD_BYTE, -12, ISO7816.INS_READ_BINARY, -122, 109, -8, -82, -73, ISOFileInfo.CHANNEL_SECURITY, -82, ISO7816.INS_READ_BINARY, -70, -83, 70, -3, ISO7816.INS_READ_BINARY2, ISOFileInfo.FCI_EXT, ISOFileInfo.FMD_BYTE, -70, -83, -1, -69, ISO7816.INS_READ_RECORD_STAMPED, -70, -122, ISO7816.INS_WRITE_RECORD, -14, 45, ISO7816.INS_PSO, ISO7816.INS_UPDATE_RECORD, ISO7816.INS_DECREASE, 40, -33, 126, -119, -37, ISO7816.INS_INCREASE, 37, -53, 61, 113, -105, -93, 49, -39, ISO7816.INS_INCREASE, ISO7816.INS_UNBLOCK_CHV, -93, 107, -105, -35, 63, ISO7816.INS_PUT_DATA, ISO7816.INS_UPDATE_BINARY, ISOFileInfo.A1, ISO7816.INS_INCREASE, 37, -39, ISOFileInfo.A0, -37, 0, 109, -120, 49, 45, 106, -104, -44, -93, ISO7816.INS_INCREASE, 8, 123, 122, ISOFileInfo.SECURITY_ATTR_EXP, -101, 67, 122, 116, 79, 73, ISOFileInfo.ENV_TEMP_EF, 107, -102, 46, -75, 51, 103, 79, 114, -34, 95, 93, 22, 38, 24, 14, ISO7816.INS_PSO, -44, 90, 94, 24, 43, -47, 94, 97, -43, 86, 39, PassportService.SFI_DG13, -22, 90, 94, PassportService.SFI_DG12, -21, 86, ISO7816.INS_CHANGE_CHV, 93, 4, ISO7816.INS_CHANGE_CHV, 94, 24, 43, -52, 91, 39, PassportService.SFI_DG13, -22, 24, 43, 85, 25, 92, 24, PassportService.SFI_DG12, 99, 99, 99, 99, 99, 99, 99, 99, 99, 99, 99, 99, 99, 99, 99, 99, 99, 99};
        f95822g = 1605274398;
    }

    private static void d(@NonNull Context context, @NonNull List<b> list) {
        m = (h + 103) % 128;
        try {
            try {
                Semaphore semaphore = e;
                semaphore.acquire();
                List<b> listC = c(context, Boolean.FALSE);
                listC.addAll(list);
                b(context, listC);
                b = true;
                semaphore.release();
                int i2 = m + EnumC41897g.SDK_ASSET_ILLUSTRATION_CALENDAR_VALUE;
                h = i2 % 128;
                if (i2 % 2 != 0) {
                    throw null;
                }
            } catch (Exception e2) {
                e2.printStackTrace();
                e.release();
            }
        } catch (Throwable th) {
            e.release();
            throw th;
        }
    }

    private static /* synthetic */ Object c(Object[] objArr) throws Throwable {
        h = (m + 77) % 128;
        Object[] objArr2 = new Object[1];
        k((short) (110 - View.resolveSize(0, 0)), View.getDefaultSize(0, 0) + 328318477, (ViewConfiguration.getMaximumDrawingCacheSize() >> 24) - 107, (-1047137251) + (ViewConfiguration.getMaximumDrawingCacheSize() >> 24), (byte) ((SystemClock.uptimeMillis() > 0L ? 1 : (SystemClock.uptimeMillis() == 0L ? 0 : -1)) + 112), objArr2);
        String strIntern = ((String) objArr2[0]).intern();
        int i2 = h + 117;
        m = i2 % 128;
        if (i2 % 2 != 0) {
            return strIntern;
        }
        throw null;
    }

    public static void c(Context context, FaceTecSessionStatus faceTecSessionStatus) {
        int i2 = h + 83;
        m = i2 % 128;
        if (i2 % 2 != 0) {
            av.d(faceTecSessionStatus, context);
            switch (AnonymousClass2.a[faceTecSessionStatus.ordinal()]) {
                case 1:
                    e(context, ax.FT_EVENT_VERIFY_SESSION_SUCCESS);
                    return;
                case 2:
                case 3:
                case 4:
                case 5:
                    e(context, ax.FT_EVENT_VERIFY_SESSION_FAIL);
                    m = (h + 99) % 128;
                    return;
                case 6:
                default:
                    return;
                case 7:
                case 8:
                case 9:
                    e(context, ax.FT_EVENT_VERIFY_SESSION_CANCEL);
                    return;
            }
        }
        av.d(faceTecSessionStatus, context);
        int i3 = AnonymousClass2.a[faceTecSessionStatus.ordinal()];
        throw null;
    }

    private static byte[] d(Context context) throws Throwable {
        h = (m + 49) % 128;
        byte[] bArrD = h.d(context);
        Object[] objArr = new Object[1];
        l(17 - ((byte) KeyEvent.getModifierMetaStateMask()), true, (AudioTrack.getMinVolume() > SelfieScan.RECOGNITION_FAIL_RESULT ? 1 : (AudioTrack.getMinVolume() == SelfieScan.RECOGNITION_FAIL_RESULT ? 0 : -1)) + EnumC41897g.SDK_ASSET_ILLUSTRATION_NETWORK_SWITCH_VALUE, "\uffc1\u0015\u000f\u0006\u0017￦\u0015\u0006\u0013\u0004\u0006\u0014\uffc1\u0006\t\u0004\u0002\u0004", 6 - (PointF.length(SelfieScan.RECOGNITION_FAIL_RESULT, SelfieScan.RECOGNITION_FAIL_RESULT) > SelfieScan.RECOGNITION_FAIL_RESULT ? 1 : (PointF.length(SelfieScan.RECOGNITION_FAIL_RESULT, SelfieScan.RECOGNITION_FAIL_RESULT) == SelfieScan.RECOGNITION_FAIL_RESULT ? 0 : -1)), objArr);
        byte[] bArrB = bp.b(bArrD, ((String) objArr[0]).intern());
        int i2 = m + 5;
        h = i2 % 128;
        if (i2 % 2 != 0) {
            int i3 = 67 / 0;
        }
        return bArrB;
    }

    @NonNull
    private static String c() {
        int iC = gn.AnonymousClass22.c();
        int iC2 = gn.AnonymousClass22.c();
        int iC3 = gn.AnonymousClass22.c();
        return (String) d(gn.AnonymousClass22.c(), iC3, iC, new Object[0], iC2, -1470815423, 1470815425);
    }

    /* JADX WARN: Removed duplicated region for block: B:15:0x0074  */
    /* JADX WARN: Removed duplicated region for block: B:17:0x009c  */
    /* JADX WARN: Removed duplicated region for block: B:19:0x00c3  */
    /* JADX WARN: Removed duplicated region for block: B:21:0x00ee  */
    /* JADX WARN: Removed duplicated region for block: B:23:0x0129  */
    /* JADX WARN: Removed duplicated region for block: B:25:0x0164  */
    /* JADX WARN: Removed duplicated region for block: B:27:0x0188  */
    /* JADX WARN: Removed duplicated region for block: B:29:0x01c3  */
    /* JADX WARN: Removed duplicated region for block: B:31:0x01fd  */
    /* JADX WARN: Removed duplicated region for block: B:33:0x0234  */
    /* JADX WARN: Removed duplicated region for block: B:38:0x027c  */
    /* JADX WARN: Removed duplicated region for block: B:40:0x02b7  */
    /* JADX WARN: Removed duplicated region for block: B:42:0x02f2  */
    /* JADX WARN: Removed duplicated region for block: B:44:0x032a  */
    /* JADX WARN: Removed duplicated region for block: B:46:0x035e  */
    /* JADX WARN: Removed duplicated region for block: B:48:0x0383  */
    /* JADX WARN: Removed duplicated region for block: B:50:0x03be  */
    /* JADX WARN: Removed duplicated region for block: B:9:0x0038  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    private static java.lang.String d(com.facetec.sdk.ax r17) throws java.lang.Throwable {
        /*
            Method dump skipped, instruction units count: 1088
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: com.facetec.sdk.at.d(com.facetec.sdk.ax):java.lang.String");
    }

    public static /* synthetic */ void d(Context context, String str, long j2, String str2, String str3) {
        Object[] objArr = {context, str, Long.valueOf(j2), str2, str3};
        int iC = gn.AnonymousClass22.c();
        int iC2 = gn.AnonymousClass22.c();
        d(gn.AnonymousClass22.c(), gn.AnonymousClass22.c(), iC, objArr, iC2, -1467494892, 1467494892);
    }
}