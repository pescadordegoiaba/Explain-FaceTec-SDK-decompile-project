package com.facetec.sdk;

import android.app.Activity;
import android.app.Fragment;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;

/* JADX INFO: loaded from: classes4.dex */
abstract class au extends Fragment {

    public class c implements Runnable {
        private final Runnable b;

        public c(Runnable runnable) {
            this.b = runnable;
        }

        @Override // java.lang.Runnable
        public final void run() {
            Activity activity;
            au auVar = au.this;
            if (auVar == null || !auVar.isAdded() || (activity = auVar.getActivity()) == null || activity.isFinishing()) {
                return;
            }
            this.b.run();
        }
    }

    public static void e(c cVar, long j) {
        new Handler(Looper.getMainLooper()).postDelayed(cVar, j);
    }

    public final void b(Runnable runnable, long j) {
        new Handler().postDelayed(new c(runnable), j);
    }

    public final void c(Runnable runnable) {
        if (getActivity() == null) {
            return;
        }
        new Handler(Looper.getMainLooper()).post(new c(runnable));
    }

    @Override // android.app.Fragment
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
    }

    public final boolean b() {
        return isAdded() && !isRemoving();
    }

    public final void c(Runnable runnable, long j) {
        e(new c(runnable), j);
    }
}