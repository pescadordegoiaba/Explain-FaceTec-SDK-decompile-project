package com.facetec.sdk;

import android.content.Context;
import android.graphics.Color;
import android.graphics.ImageFormat;
import android.media.AudioTrack;
import android.os.Process;
import android.os.SystemClock;
import android.provider.Settings;
import android.view.View;
import android.view.ViewConfiguration;
import android.widget.ExpandableListView;
import androidx.annotation.NonNull;
import com.facetec.sdk.am;
import com.incode.welcome_sdk.modules.SelfieScan;
import com.plaid.internal.EnumC41897g;
import java.io.File;
import java.io.FileNotFoundException;
import java.lang.reflect.Method;
import java.nio.charset.StandardCharsets;
import java.util.HashMap;
import java.util.Iterator;
import org.bouncycastle.i18n.LocalizedMessage;
import org.json.JSONObject;

/* JADX INFO: loaded from: classes4.dex */
final class av {
    private static final byte[] $$a = null;
    private static final int $$b = 0;
    private static int $10;
    private static int $11;
    private static char[] a;
    private static String b;
    private static HashMap<String, Integer> c;
    private static boolean d;
    private static String e;
    private static int f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    private static int f95824g;
    private static int i;
    private static int j;

    /* JADX INFO: renamed from: com.facetec.sdk.av$5, reason: invalid class name */
    public static /* synthetic */ class AnonymousClass5 {
        static final /* synthetic */ int[] c;

        static {
            int[] iArr = new int[FaceTecSessionStatus.values().length];
            c = iArr;
            try {
                iArr[FaceTecSessionStatus.NON_PRODUCTION_MODE_KEY_INVALID.ordinal()] = 1;
            } catch (NoSuchFieldError unused) {
            }
            try {
                c[FaceTecSessionStatus.NON_PRODUCTION_MODE_NETWORK_REQUIRED.ordinal()] = 2;
            } catch (NoSuchFieldError unused2) {
            }
            try {
                c[FaceTecSessionStatus.USER_CANCELLED.ordinal()] = 3;
            } catch (NoSuchFieldError unused3) {
            }
            try {
                c[FaceTecSessionStatus.USER_CANCELLED_VIA_HARDWARE_BUTTON.ordinal()] = 4;
            } catch (NoSuchFieldError unused4) {
            }
            try {
                c[FaceTecSessionStatus.SESSION_COMPLETED_SUCCESSFULLY.ordinal()] = 5;
            } catch (NoSuchFieldError unused5) {
            }
            try {
                c[FaceTecSessionStatus.SESSION_UNSUCCESSFUL.ordinal()] = 6;
            } catch (NoSuchFieldError unused6) {
            }
            try {
                c[FaceTecSessionStatus.CAMERA_PERMISSION_DENIED.ordinal()] = 7;
            } catch (NoSuchFieldError unused7) {
            }
            try {
                c[FaceTecSessionStatus.ENCRYPTION_KEY_INVALID.ordinal()] = 8;
            } catch (NoSuchFieldError unused8) {
            }
            try {
                c[FaceTecSessionStatus.TIMEOUT.ordinal()] = 9;
            } catch (NoSuchFieldError unused9) {
            }
            try {
                c[FaceTecSessionStatus.CONTEXT_SWITCH.ordinal()] = 10;
            } catch (NoSuchFieldError unused10) {
            }
            try {
                c[FaceTecSessionStatus.CAMERA_INITIALIZATION_ISSUE.ordinal()] = 11;
            } catch (NoSuchFieldError unused11) {
            }
            try {
                c[FaceTecSessionStatus.UNKNOWN_INTERNAL_ERROR.ordinal()] = 12;
            } catch (NoSuchFieldError unused12) {
            }
            try {
                c[FaceTecSessionStatus.LANDSCAPE_MODE_NOT_ALLOWED.ordinal()] = 13;
            } catch (NoSuchFieldError unused13) {
            }
            try {
                c[FaceTecSessionStatus.REVERSE_PORTRAIT_NOT_ALLOWED.ordinal()] = 14;
            } catch (NoSuchFieldError unused14) {
            }
            try {
                c[FaceTecSessionStatus.LOCKED_OUT.ordinal()] = 15;
            } catch (NoSuchFieldError unused15) {
            }
            try {
                c[FaceTecSessionStatus.MISSING_GUIDANCE_IMAGES.ordinal()] = 16;
            } catch (NoSuchFieldError unused16) {
            }
            try {
                c[FaceTecSessionStatus.INITIALIZATION_NOT_COMPLETED.ordinal()] = 17;
            } catch (NoSuchFieldError unused17) {
            }
            try {
                c[FaceTecSessionStatus.USER_CANCELLED_VIA_CLICKABLE_READY_SCREEN_SUBTEXT.ordinal()] = 18;
            } catch (NoSuchFieldError unused18) {
            }
            try {
                c[FaceTecSessionStatus.SESSION_EXPIRED.ordinal()] = 19;
            } catch (NoSuchFieldError unused19) {
            }
            try {
                c[FaceTecSessionStatus.DEVICE_NOT_SUPPORTED.ordinal()] = 20;
            } catch (NoSuchFieldError unused20) {
            }
        }
    }

    /* JADX WARN: Removed duplicated region for block: B:10:0x0022  */
    /* JADX WARN: Removed duplicated region for block: B:8:0x001c  */
    /* JADX WARN: Unsupported multi-entry loop pattern (BACK_EDGE: B:10:0x0022 -> B:11:0x0026). Please report as a decompilation issue!!! */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    private static java.lang.String $$c(short r5, byte r6, byte r7) {
        /*
            int r5 = r5 * 4
            int r0 = r5 + 1
            int r6 = r6 * 4
            int r6 = 3 - r6
            int r7 = r7 + 66
            byte[] r1 = com.facetec.sdk.av.$$a
            byte[] r0 = new byte[r0]
            r2 = 0
            if (r1 != 0) goto L14
            r4 = r5
            r3 = r2
            goto L26
        L14:
            r3 = r2
        L15:
            byte r4 = (byte) r7
            r0[r3] = r4
            int r6 = r6 + 1
            if (r3 != r5) goto L22
            java.lang.String r5 = new java.lang.String
            r5.<init>(r0, r2)
            return r5
        L22:
            int r3 = r3 + 1
            r4 = r1[r6]
        L26:
            int r4 = -r4
            int r7 = r7 + r4
            goto L15
        */
        throw new UnsupportedOperationException("Method not decompiled: com.facetec.sdk.av.$$c(short, byte, byte):java.lang.String");
    }

    static {
        init$0();
        $10 = 0;
        $11 = 1;
        i = 0;
        j = 1;
        f95824g = 0;
        f = 1;
        c();
        b = "";
        d = false;
        e = "";
        int i2 = i + 35;
        j = i2 % 128;
        if (i2 % 2 == 0) {
            int i3 = 0 / 0;
        }
    }

    public static /* synthetic */ Object a(int i2, int i3, int i4, int i5, int i6, Object[] objArr, int i7) {
        int i8 = ~i6;
        int i9 = ~i4;
        int i10 = (~(i8 | i9)) | (~(i9 | i7));
        int i11 = ~i7;
        int i12 = i10 | (~(i11 | i6 | i4));
        int i13 = i9 | i6;
        int i14 = (~(i7 | i6)) | (~i13);
        int i15 = i13 | i11;
        int i16 = i6 + i4 + i2 + ((-1468046718) * i5) + (327422179 * i3);
        int i17 = i16 * i16;
        int i18 = (677926197 * i6) + 1810235392 + (1154460365 * i4) + (i12 * (-238267084)) + ((-238267084) * i14) + (238267084 * i15) + (916193280 * i2) + (1933049856 * i5) + (743702528 * i3) + (286654464 * i17);
        int i19 = (i6 * (-645773371)) + 280972133 + (i4 * (-645772067)) + (i12 * (-652)) + (i14 * (-652)) + (i15 * 652) + (i2 * (-645772719)) + (i5 * 1523302178) + (i3 * 1475409363) + (i17 * (-1007288320));
        return i18 + ((i19 * i19) * (-492175360)) != 1 ? b(objArr) : e(objArr);
    }

    private static /* synthetic */ Object b(Object[] objArr) {
        f95824g = (f + 1) % 128;
        if (!c.containsKey("FC")) {
            return 0;
        }
        int iIntValue = c.get("FC").intValue();
        int i2 = f + 9;
        f95824g = i2 % 128;
        if (i2 % 2 == 0) {
            return Integer.valueOf(iIntValue);
        }
        int i3 = 13 / 0;
        return Integer.valueOf(iIntValue);
    }

    private static void c(final Context context) {
        f95824g = (f + 107) % 128;
        if (context == null) {
            return;
        }
        dj.d(new Runnable() { // from class: com.facetec.sdk.日
            @Override // java.lang.Runnable
            public final void run() throws Throwable {
                av.j(context);
            }
        });
        f95824g = (f + 79) % 128;
    }

    public static void d(@NonNull FaceTecSessionStatus faceTecSessionStatus, Context context) {
        HashMap<String, Integer> map;
        if (!d) {
            int i2 = f + 99;
            f95824g = i2 % 128;
            if (i2 % 2 != 0) {
                throw null;
            }
            return;
        }
        String strC = c(faceTecSessionStatus);
        int i3 = 1;
        if (c.get(strC) == null) {
            int i4 = f95824g + 65;
            f = i4 % 128;
            if (i4 % 2 == 0) {
                map = c;
            } else {
                map = c;
                i3 = 0;
            }
            map.put(strC, Integer.valueOf(i3));
        } else {
            HashMap<String, Integer> map2 = c;
            map2.put(strC, Integer.valueOf(map2.get(strC).intValue() + 1));
            f = (f95824g + EnumC41897g.SDK_ASSET_ILLUSTRATION_DEPOSIT_SWITCH_VALUE) % 128;
        }
        c(context);
        f95824g = (f + EnumC41897g.SDK_ASSET_ILLUSTRATION_DEPOSIT_SWITCH_VALUE) % 128;
    }

    /* JADX WARN: Removed duplicated region for block: B:9:0x0023  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public static int e(android.content.Context r3) {
        /*
            int r0 = com.facetec.sdk.av.f95824g
            int r0 = r0 + 109
            int r1 = r0 % 128
            com.facetec.sdk.av.f = r1
            int r0 = r0 % 2
            java.lang.String r1 = "FC"
            if (r0 != 0) goto L1b
            java.util.HashMap<java.lang.String, java.lang.Integer> r0 = com.facetec.sdk.av.c
            boolean r0 = r0.containsKey(r1)
            r2 = 46
            int r2 = r2 / 0
            if (r0 != 0) goto L2e
            goto L23
        L1b:
            java.util.HashMap<java.lang.String, java.lang.Integer> r0 = com.facetec.sdk.av.c
            boolean r0 = r0.containsKey(r1)
            if (r0 != 0) goto L2e
        L23:
            b(r3)
            int r3 = com.facetec.sdk.av.f
            int r3 = r3 + 115
            int r3 = r3 % 128
            com.facetec.sdk.av.f95824g = r3
        L2e:
            java.util.HashMap<java.lang.String, java.lang.Integer> r3 = com.facetec.sdk.av.c
            java.lang.Object r3 = r3.get(r1)
            java.lang.Integer r3 = (java.lang.Integer) r3
            int r3 = r3.intValue()
            int r0 = com.facetec.sdk.av.f
            int r0 = r0 + 41
            int r0 = r0 % 128
            com.facetec.sdk.av.f95824g = r0
            return r3
        */
        throw new UnsupportedOperationException("Method not decompiled: com.facetec.sdk.av.e(android.content.Context):int");
    }

    private static void f(@NonNull Context context) {
        byte[] bArrE = bq.e(new File(context.getCacheDir(), a()), e());
        JSONObject jSONObject = new JSONObject(new String(bArrE, 0, bArrE.length, StandardCharsets.UTF_8));
        c.clear();
        JSONObject jSONObjectOptJSONObject = jSONObject.optJSONObject("history");
        if (jSONObjectOptJSONObject != null) {
            f95824g = (f + 101) % 128;
            Iterator<String> itKeys = jSONObjectOptJSONObject.keys();
            while (itKeys.hasNext()) {
                int i2 = f + EnumC41897g.SDK_ASSET_ILLUSTRATION_DEPOSIT_SWITCH_VALUE;
                f95824g = i2 % 128;
                if (i2 % 2 != 0) {
                    String next = itKeys.next();
                    c.put(next, Integer.valueOf(jSONObjectOptJSONObject.optInt(next)));
                    int i3 = 86 / 0;
                } else {
                    String next2 = itKeys.next();
                    c.put(next2, Integer.valueOf(jSONObjectOptJSONObject.optInt(next2)));
                }
            }
        }
        f95824g = (f + 31) % 128;
    }

    private static void h(String str, int[] iArr, boolean z, Object[] objArr) throws Throwable {
        int i2;
        long j2;
        byte[] bArr;
        String str2 = str;
        int i3 = $11;
        $10 = (i3 + 107) % 128;
        int i4 = 0;
        Object bytes = str2;
        if (str2 != null) {
            int i5 = i3 + 75;
            $10 = i5 % 128;
            if (i5 % 2 != 0) {
                int i6 = 43 / 0;
                bytes = str2.getBytes(LocalizedMessage.DEFAULT_ENCODING);
            } else {
                bytes = str2.getBytes(LocalizedMessage.DEFAULT_ENCODING);
            }
        }
        byte[] bArr2 = (byte[]) bytes;
        hk hkVar = new hk();
        int i7 = iArr[0];
        int i8 = iArr[1];
        int i9 = iArr[2];
        int i10 = iArr[3];
        char[] cArr = a;
        Class cls = Integer.TYPE;
        if (cArr != null) {
            $10 = ($11 + 87) % 128;
            int length = cArr.length;
            char[] cArr2 = new char[length];
            int i11 = 0;
            while (i11 < length) {
                try {
                    Object[] objArr2 = {Integer.valueOf(cArr[i11])};
                    Object objD = an.d(-803102734);
                    if (objD == null) {
                        int touchSlop = 1756 - (ViewConfiguration.getTouchSlop() >> 8);
                        char doubleTapTimeout = (char) (ViewConfiguration.getDoubleTapTimeout() >> 16);
                        int threadPriority = 24 - ((Process.getThreadPriority(i4) + 20) >> 6);
                        bArr = bArr2;
                        byte b2 = (byte) i4;
                        byte b3 = b2;
                        objD = an.d(touchSlop, doubleTapTimeout, threadPriority, -1505735511, false, $$c(b2, b3, (byte) (b3 + 1)), new Class[]{cls});
                    } else {
                        bArr = bArr2;
                    }
                    cArr2[i11] = ((Character) ((Method) objD).invoke(null, objArr2)).charValue();
                    i11++;
                    bArr2 = bArr;
                    i4 = 0;
                } catch (Throwable th) {
                    Throwable cause = th.getCause();
                    if (cause == null) {
                        throw th;
                    }
                    throw cause;
                }
            }
            cArr = cArr2;
        }
        byte[] bArr3 = bArr2;
        char[] cArr3 = new char[i8];
        System.arraycopy(cArr, i7, cArr3, 0, i8);
        if (bArr3 != null) {
            $10 = ($11 + 87) % 128;
            char[] cArr4 = new char[i8];
            hkVar.a = 0;
            char c2 = 0;
            while (true) {
                int i12 = hkVar.a;
                if (i12 >= i8) {
                    break;
                }
                $10 = ($11 + 69) % 128;
                if (bArr3[i12] == 1) {
                    Object[] objArr3 = {Integer.valueOf(cArr3[i12]), Integer.valueOf(c2)};
                    Object objD2 = an.d(663167313);
                    if (objD2 == null) {
                        objD2 = an.d(2016 - ImageFormat.getBitsPerPixel(0), (char) ((AudioTrack.getMaxVolume() > SelfieScan.RECOGNITION_FAIL_RESULT ? 1 : (AudioTrack.getMaxVolume() == SelfieScan.RECOGNITION_FAIL_RESULT ? 0 : -1)) + 14310), ExpandableListView.getPackedPositionGroup(0L) + 24, 1374089738, false, "D", new Class[]{cls, cls});
                    }
                    cArr4[i12] = ((Character) ((Method) objD2).invoke(null, objArr3)).charValue();
                    j2 = 0;
                } else {
                    Object[] objArr4 = {Integer.valueOf(cArr3[i12]), Integer.valueOf(c2)};
                    Object objD3 = an.d(-537001977);
                    if (objD3 == null) {
                        byte b4 = (byte) 0;
                        byte b5 = b4;
                        j2 = 0;
                        objD3 = an.d(1139 - (AudioTrack.getMaxVolume() > SelfieScan.RECOGNITION_FAIL_RESULT ? 1 : (AudioTrack.getMaxVolume() == SelfieScan.RECOGNITION_FAIL_RESULT ? 0 : -1)), (char) ((AudioTrack.getMaxVolume() > SelfieScan.RECOGNITION_FAIL_RESULT ? 1 : (AudioTrack.getMaxVolume() == SelfieScan.RECOGNITION_FAIL_RESULT ? 0 : -1)) + 12387), Color.blue(0) + 24, -1449143460, false, $$c(b4, b5, b5), new Class[]{cls, cls});
                    } else {
                        j2 = 0;
                    }
                    cArr4[i12] = ((Character) ((Method) objD3).invoke(null, objArr4)).charValue();
                }
                c2 = cArr4[hkVar.a];
                Object[] objArr5 = {hkVar, hkVar};
                Object objD4 = an.d(693882396);
                if (objD4 == null) {
                    byte b6 = (byte) 0;
                    byte b7 = b6;
                    objD4 = an.d(View.MeasureSpec.getMode(0) + 1803, (char) (9692 - View.MeasureSpec.getMode(0)), (SystemClock.uptimeMillis() > j2 ? 1 : (SystemClock.uptimeMillis() == j2 ? 0 : -1)) + 23, 1597644103, false, $$c(b6, b7, (byte) (b7 | 56)), new Class[]{Object.class, Object.class});
                }
                ((Method) objD4).invoke(null, objArr5);
            }
            cArr3 = cArr4;
        }
        if (i10 > 0) {
            char[] cArr5 = new char[i8];
            i2 = 0;
            System.arraycopy(cArr3, 0, cArr5, 0, i8);
            int i13 = i8 - i10;
            System.arraycopy(cArr5, 0, cArr3, i13, i10);
            System.arraycopy(cArr5, i10, cArr3, 0, i13);
        } else {
            i2 = 0;
        }
        if (z) {
            char[] cArr6 = new char[i8];
            hkVar.a = i2;
            while (true) {
                int i14 = hkVar.a;
                if (i14 >= i8) {
                    break;
                }
                int i15 = $10;
                int i16 = i15 + 69;
                $11 = i16 % 128;
                if (i16 % 2 == 0) {
                    cArr6[i14] = cArr3[i8 >>> i14];
                    hkVar.a = i14 >>> 1;
                } else {
                    cArr6[i14] = cArr3[(i8 - i14) - 1];
                    hkVar.a = i14 + 1;
                }
                $11 = (i15 + 61) % 128;
            }
            cArr3 = cArr6;
        }
        if (i9 > 0) {
            hkVar.a = 0;
            while (true) {
                int i17 = hkVar.a;
                if (i17 >= i8) {
                    break;
                }
                $10 = ($11 + 45) % 128;
                cArr3[i17] = (char) (cArr3[i17] - iArr[2]);
                hkVar.a = i17 + 1;
            }
        }
        objArr[0] = new String(cArr3);
    }

    public static void init$0() {
        $$a = new byte[]{86, 117, -27, 75};
        $$b = 19;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static /* synthetic */ void j(Context context) throws Throwable {
        f95824g = (f + 103) % 128;
        try {
            b(context.getCacheDir());
            int i2 = f + 33;
            f95824g = i2 % 128;
            if (i2 % 2 != 0) {
                throw null;
            }
        } catch (Exception e2) {
            bh.e(e2.getMessage());
        }
    }

    public static void a(@NonNull Context context) {
        f = (f95824g + 57) % 128;
        if (d) {
            return;
        }
        c = new HashMap<>();
        FaceTecSessionStatus[] faceTecSessionStatusArrValues = FaceTecSessionStatus.values();
        f = (f95824g + 91) % 128;
        for (FaceTecSessionStatus faceTecSessionStatus : faceTecSessionStatusArrValues) {
            c.put(c(faceTecSessionStatus), 0);
        }
        c.put("FC", 1);
        b = context.getPackageName();
        e = Settings.Secure.getString(context.getContentResolver(), "android_id");
        a(am.AnonymousClass3.d(), am.AnonymousClass3.d(), -922499967, am.AnonymousClass3.d(), 922499968, new Object[]{context}, am.AnonymousClass3.d());
        d = true;
    }

    @NonNull
    private static String c(@NonNull FaceTecSessionStatus faceTecSessionStatus) {
        switch (AnonymousClass5.c[faceTecSessionStatus.ordinal()]) {
            case 1:
                return "LI";
            case 2:
                return "DM";
            case 3:
                return "UC";
            case 4:
                f95824g = (f + 23) % 128;
                return "CH";
            case 5:
                return "PS";
            case 6:
                return "NP";
            case 7:
                return "CD";
            case 8:
                return "EI";
            case 9:
                int i2 = f + 71;
                f95824g = i2 % 128;
                if (i2 % 2 != 0) {
                    int i3 = 44 / 0;
                }
                return "TO";
            case 10:
                return "CS";
            case 11:
                return "CE";
            case 12:
                return "IE";
            case 13:
                f95824g = (f + 43) % 128;
                return "LA";
            case 14:
                return "RP";
            case 15:
                return "UL";
            case 16:
                return "GI";
            case 17:
                return "IN";
            case 18:
                return "RS";
            case 19:
                return "SE";
            case 20:
                return "DN";
            default:
                return "NA";
        }
    }

    public static void b(Context context) {
        int i2 = f + 51;
        int i3 = i2 % 128;
        f95824g = i3;
        if (i2 % 2 == 0) {
            if (!d) {
                int i4 = i3 + 47;
                f = i4 % 128;
                if (i4 % 2 == 0) {
                    throw null;
                }
                return;
            }
            if (c.get("FC") == null) {
                int i5 = f95824g + 91;
                f = i5 % 128;
                int i6 = i5 % 2;
                c.put("FC", 1);
            } else {
                HashMap<String, Integer> map = c;
                map.put("FC", Integer.valueOf(map.get("FC").intValue() + 1));
            }
            c(context);
            return;
        }
        throw null;
    }

    private static /* synthetic */ Object e(Object[] objArr) {
        Context context = (Context) objArr[0];
        int i2 = f + 27;
        f95824g = i2 % 128;
        try {
            if (i2 % 2 != 0) {
                f(context);
                int i3 = 58 / 0;
            } else {
                f(context);
            }
            return null;
        } catch (FileNotFoundException unused) {
            return null;
        } catch (Exception e2) {
            bh.e(e2.getMessage());
            e2.getStackTrace();
            return null;
        }
    }

    @NonNull
    public static String d() {
        String string;
        int i2 = f95824g + 83;
        f = i2 % 128;
        if (i2 % 2 == 0) {
            string = c.toString();
            int i3 = 46 / 0;
        } else {
            string = c.toString();
        }
        f95824g = (f + 3) % 128;
        return string;
    }

    private static byte[] e() {
        StringBuilder sb = new StringBuilder();
        sb.append(b);
        sb.append(e);
        sb.append("history_key");
        byte[] bArrA = bp.a(sb.toString());
        f95824g = (f + 41) % 128;
        return bArrA;
    }

    private static void d(@NonNull Context context) {
        int iD = am.AnonymousClass3.d();
        int iD2 = am.AnonymousClass3.d();
        int iD3 = am.AnonymousClass3.d();
        a(iD2, am.AnonymousClass3.d(), -922499967, iD3, 922499968, new Object[]{context}, iD);
    }

    @NonNull
    private static String a() {
        StringBuilder sb = new StringBuilder();
        sb.append(b);
        sb.append(e);
        sb.append("history_file_internal");
        String strB = bp.b(sb.toString());
        f95824g = (f + 95) % 128;
        return strB;
    }

    private static void b(File file) throws Throwable {
        JSONObject jSONObject = new JSONObject();
        jSONObject.put("history", new JSONObject(c));
        Object[] objArr = new Object[1];
        h(null, new int[]{0, 1, 24, 1}, true, objArr);
        jSONObject.put(((String) objArr[0]).intern(), bh.b(16, 128));
        bq.d(new File(file, a()), e(), jSONObject.toString().getBytes(StandardCharsets.UTF_8));
        int i2 = f + 33;
        f95824g = i2 % 128;
        if (i2 % 2 != 0) {
            throw null;
        }
    }

    public static int b() {
        int iD = am.AnonymousClass3.d();
        int iD2 = am.AnonymousClass3.d();
        int iD3 = am.AnonymousClass3.d();
        return ((Integer) a(iD2, am.AnonymousClass3.d(), 225112006, iD3, -225112006, new Object[0], iD)).intValue();
    }

    public static void c() {
        a = new char[]{18380};
    }
}