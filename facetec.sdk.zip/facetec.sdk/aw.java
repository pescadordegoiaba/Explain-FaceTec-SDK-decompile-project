package com.facetec.sdk;

/* JADX INFO: loaded from: classes4.dex */
final class aw extends Exception {
    public aw(String str) {
        super(str);
    }

    public aw(Throwable th) {
        super(th.getMessage(), th);
    }

    public aw(String str, Throwable th) {
        super(str, th);
    }
}