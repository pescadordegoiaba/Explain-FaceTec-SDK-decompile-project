package com.facetec.sdk;

import android.annotation.SuppressLint;
import android.content.Context;
import android.util.AttributeSet;
import android.widget.TextView;

/* JADX INFO: loaded from: classes4.dex */
@SuppressLint({"AppCompatCustomView"})
class az extends TextView {
    private boolean e;

    public az(Context context) {
        super(context);
        this.e = false;
        e();
    }

    private void e() {
        if (this.e) {
            return;
        }
        this.e = true;
        setIncludeFontPadding(bh.b(ao.d));
    }

    public az(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        this.e = false;
        e();
    }

    public az(Context context, AttributeSet attributeSet, int i) {
        super(context, attributeSet, i);
        this.e = false;
        e();
    }
}