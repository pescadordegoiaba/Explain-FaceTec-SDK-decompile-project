package com.facetec.sdk;

/* JADX INFO: loaded from: classes4.dex */
public class b {
    public static int d = 9;

    public static /* synthetic */ void c() {
        a.a[0] = b.class.getDeclaredField("d");
    }
}