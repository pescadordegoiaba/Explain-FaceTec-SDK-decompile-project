package com.facetec.sdk;

import android.graphics.PointF;
import android.os.Process;
import android.text.AndroidCharacter;
import android.text.TextUtils;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewConfiguration;
import android.widget.ExpandableListView;
import androidx.annotation.NonNull;
import com.incode.welcome_sdk.modules.SelfieScan;
import java.util.HashMap;
import net.sf.scuba.smartcards.ISO7816;

/* JADX INFO: loaded from: classes4.dex */
final class ba {
    private static final byte[] $$a = null;
    private static final int $$b = 0;
    private static int a;
    private static HashMap<String, Long> c;

    /* JADX WARN: Removed duplicated region for block: B:10:0x0025  */
    /* JADX WARN: Removed duplicated region for block: B:8:0x001f  */
    /* JADX WARN: Unsupported multi-entry loop pattern (BACK_EDGE: B:10:0x0025 -> B:11:0x0029). Please report as a decompilation issue!!! */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    private static java.lang.String $$c(int r5, short r6, byte r7) {
        /*
            int r5 = r5 * 3
            int r0 = 1 - r5
            byte[] r1 = com.facetec.sdk.ba.$$a
            int r7 = r7 * 3
            int r7 = r7 + 107
            int r6 = r6 * 3
            int r6 = r6 + 4
            byte[] r0 = new byte[r0]
            r2 = 0
            int r5 = 0 - r5
            if (r1 != 0) goto L19
            r4 = r5
            r7 = r6
            r3 = r2
            goto L29
        L19:
            r3 = r2
        L1a:
            byte r4 = (byte) r7
            r0[r3] = r4
            if (r3 != r5) goto L25
            java.lang.String r5 = new java.lang.String
            r5.<init>(r0, r2)
            return r5
        L25:
            r4 = r1[r6]
            int r3 = r3 + 1
        L29:
            int r6 = r6 + 1
            int r7 = r7 + r4
            goto L1a
        */
        throw new UnsupportedOperationException("Method not decompiled: com.facetec.sdk.ba.$$c(int, short, byte):java.lang.String");
    }

    static {
        init$0();
        b();
        c = new HashMap<>();
    }

    private static String a(String str) {
        StringBuilder sb = new StringBuilder();
        sb.append(str);
        sb.append("__E");
        return sb.toString();
    }

    private static String b(String str) {
        StringBuilder sb = new StringBuilder();
        sb.append(str);
        sb.append("__S");
        return sb.toString();
    }

    public static long c(@NonNull String str) throws Throwable {
        long jLongValue = c.containsKey(b(str)) ? c.get(b(str)).longValue() : -1L;
        long jLongValue2 = c.containsKey(a(str)) ? c.get(a(str)).longValue() : -1L;
        if (jLongValue == -1) {
            return 0L;
        }
        if (jLongValue2 != -1) {
            return jLongValue2 - jLongValue;
        }
        try {
            Object[] objArr = new Object[1];
            f(View.MeasureSpec.getMode(0) + 16, TextUtils.lastIndexOf("", '0', 0, 0) + 158, (ViewConfiguration.getEdgeSlop() >> 16) + 2, false, "\u0003\u000b\b\uffff\u0014\uffffￌ\n\uffff\f\u0005ￌ\ufff1\u0017\u0011\u0012", objArr);
            Class<?> cls = Class.forName((String) objArr[0]);
            Object[] objArr2 = new Object[1];
            f((KeyEvent.getMaxKeyCode() >> 16) + 8, 162 - ((Process.getThreadPriority(0) + 20) >> 6), 1 - (ViewConfiguration.getTapTimeout() >> 16), false, "\ufffe\u0007\ufffa\u0007\b￭\u0002\u0006", objArr2);
            return ((Long) cls.getMethod((String) objArr2[0], null).invoke(null, null)).longValue() - jLongValue;
        } catch (Throwable th) {
            Throwable cause = th.getCause();
            if (cause != null) {
                throw cause;
            }
            throw th;
        }
    }

    public static void d(@NonNull String str) {
        if (!c.containsKey(b(str)) || c.containsKey(a(str))) {
            return;
        }
        HashMap<String, Long> map = c;
        String strA = a(str);
        try {
            Object[] objArr = new Object[1];
            f(TextUtils.getTrimmedLength("") + 16, 156 - (ExpandableListView.getPackedPositionForChild(0, 0) > 0L ? 1 : (ExpandableListView.getPackedPositionForChild(0, 0) == 0L ? 0 : -1)), MotionEvent.axisFromString("") + 3, false, "\u0003\u000b\b\uffff\u0014\uffffￌ\n\uffff\f\u0005ￌ\ufff1\u0017\u0011\u0012", objArr);
            Class<?> cls = Class.forName((String) objArr[0]);
            Object[] objArr2 = new Object[1];
            f(TextUtils.getOffsetBefore("", 0) + 8, AndroidCharacter.getMirror('0') + 'r', (PointF.length(SelfieScan.RECOGNITION_FAIL_RESULT, SelfieScan.RECOGNITION_FAIL_RESULT) > SelfieScan.RECOGNITION_FAIL_RESULT ? 1 : (PointF.length(SelfieScan.RECOGNITION_FAIL_RESULT, SelfieScan.RECOGNITION_FAIL_RESULT) == SelfieScan.RECOGNITION_FAIL_RESULT ? 0 : -1)) + 1, false, "\ufffe\u0007\ufffa\u0007\b￭\u0002\u0006", objArr2);
            Long l = (Long) cls.getMethod((String) objArr2[0], null).invoke(null, null);
            l.longValue();
            map.put(strA, l);
        } catch (Throwable th) {
            Throwable cause = th.getCause();
            if (cause == null) {
                throw th;
            }
            throw cause;
        }
    }

    public static void e(@NonNull String str) {
        c.remove(b(str));
        c.remove(a(str));
        HashMap<String, Long> map = c;
        String strB = b(str);
        try {
            Object[] objArr = new Object[1];
            f(16 - ExpandableListView.getPackedPositionGroup(0L), 157 - View.MeasureSpec.getMode(0), (ViewConfiguration.getEdgeSlop() >> 16) + 2, false, "\u0003\u000b\b\uffff\u0014\uffffￌ\n\uffff\f\u0005ￌ\ufff1\u0017\u0011\u0012", objArr);
            Class<?> cls = Class.forName((String) objArr[0]);
            Object[] objArr2 = new Object[1];
            f((ViewConfiguration.getMinimumFlingVelocity() >> 16) + 8, 162 - (ViewConfiguration.getJumpTapTimeout() >> 16), 1 - (ViewConfiguration.getScrollBarSize() >> 8), false, "\ufffe\u0007\ufffa\u0007\b￭\u0002\u0006", objArr2);
            Long l = (Long) cls.getMethod((String) objArr2[0], null).invoke(null, null);
            l.longValue();
            map.put(strB, l);
        } catch (Throwable th) {
            Throwable cause = th.getCause();
            if (cause == null) {
                throw th;
            }
            throw cause;
        }
    }

    /* JADX WARN: Removed duplicated region for block: B:37:0x014c  */
    /* JADX WARN: Removed duplicated region for block: B:38:0x014d  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    private static void f(int r26, int r27, int r28, boolean r29, java.lang.String r30, java.lang.Object[] r31) throws java.lang.Throwable {
        /*
            Method dump skipped, instruction units count: 343
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: com.facetec.sdk.ba.f(int, int, int, boolean, java.lang.String, java.lang.Object[]):void");
    }

    public static void init$0() {
        $$a = new byte[]{93, ISO7816.INS_LOAD_KEY_FILE, 95, -94};
        $$b = 211;
    }

    public static void b() {
        a = 1605274474;
    }
}