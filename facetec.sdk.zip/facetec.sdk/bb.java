package com.facetec.sdk;

import android.os.Process;
import android.util.Log;

/* JADX INFO: loaded from: classes4.dex */
final class bb {
    public static int b;
    public static int c;

    public static void a(String str) {
        Log.w("FaceTecSDK", str);
    }

    public static int d() {
        int i = c;
        int i2 = i % 8112930;
        c = i + 1;
        if (i2 != 0) {
            return b;
        }
        int iMyPid = Process.myPid();
        b = iMyPid;
        return iMyPid;
    }

    public static void e(String str) {
        Log.i("FaceTecSDK", str);
    }
}