package com.facetec.sdk;

import android.content.Context;
import java.io.FileInputStream;
import java.io.FileOutputStream;

/* JADX INFO: loaded from: classes4.dex */
final class bc {
    public static void b(final Context context) {
        dj.d(new Runnable() { // from class: com.facetec.sdk.月
            @Override // java.lang.Runnable
            public final void run() {
                bc.c(context);
            }
        });
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static /* synthetic */ void c(Context context) {
        ba.e("BT");
        ba.d("BT");
        ba.e("RWT");
        try {
            FileOutputStream fileOutputStreamOpenFileOutput = context.openFileOutput("tmp_rw", 0);
            fileOutputStreamOpenFileOutput.write("abcdefghijklmnopqrstuvwxyz1234567890".getBytes());
            fileOutputStreamOpenFileOutput.flush();
            fileOutputStreamOpenFileOutput.close();
        } catch (Exception unused) {
        }
        try {
            FileInputStream fileInputStreamOpenFileInput = context.openFileInput("tmp_rw");
            while (fileInputStreamOpenFileInput.read() != -1) {
            }
            fileInputStreamOpenFileInput.close();
        } catch (Exception unused2) {
        }
        ba.d("RWT");
    }
}