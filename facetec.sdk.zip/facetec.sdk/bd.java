package com.facetec.sdk;

import android.animation.Animator;
import android.animation.AnimatorSet;
import android.animation.ObjectAnimator;
import android.annotation.SuppressLint;
import android.content.Context;
import android.graphics.Color;
import android.graphics.ImageFormat;
import android.graphics.PointF;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.GradientDrawable;
import android.media.AudioTrack;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.Process;
import android.os.SystemClock;
import android.telephony.cdma.CdmaCellLocation;
import android.text.TextUtils;
import android.util.Property;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewConfiguration;
import android.view.ViewGroup;
import android.view.ViewOutlineProvider;
import android.view.ViewTreeObserver;
import android.widget.ExpandableListView;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;
import com.facetec.sdk.FaceTecCancelButtonCustomization;
import com.facetec.sdk.FaceTecVocalGuidanceCustomization;
import com.facetec.sdk.au;
import com.facetec.sdk.bi;
import com.facetec.sdk.cp;
import com.facetec.sdk.cy;
import com.facetec.sdk.ed;
import com.facetec.sdk.gn;
import com.facetec.sdk.pg;
import com.incode.welcome_sdk.modules.SelfieScan;
import com.plaid.internal.EnumC41897g;
import io.sentry.protocol.ViewHierarchyNode;
import java.lang.reflect.Constructor;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Random;
import java.util.concurrent.Semaphore;
import java.util.concurrent.TimeUnit;
import kotlin.C29160;
import kotlin.C6852;
import net.sf.scuba.smartcards.ISO7816;
import net.sf.scuba.smartcards.ISOFileInfo;
import org.bouncycastle.crypto.signers.PSSSigner;

/* JADX INFO: loaded from: classes4.dex */
public final class bd extends au {
    private static final byte[] $$a = null;
    private static final int $$b = 0;
    private static final byte[] $$c = null;
    private static final int $$d = 0;
    private static int $10;
    private static int $11;
    private static int B;
    private static int E;
    private static int F;
    private static short[] G;
    private static int H;
    private static byte[] I;
    private static int L;
    private static int M;
    private static int N;
    public static boolean a;
    private TextView b;
    public ImageView c;
    cs d;
    private LinearLayout e;
    private cy f;
    private de h;
    private d i;
    private View j;
    private FrameLayout k;
    private Handler l;
    private Handler n;
    private Handler o;
    private Semaphore v;
    private Handler x;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    private boolean f95827g = false;
    private boolean m = false;
    private boolean s = false;
    private boolean r = false;
    private boolean t = false;
    private boolean p = false;
    private cu q = null;
    private boolean u = false;
    private final int y = (int) bh.a(12);
    private boolean w = false;
    private boolean A = false;
    private final ViewTreeObserver.OnGlobalLayoutListener z = new ViewTreeObserver.OnGlobalLayoutListener() { // from class: com.facetec.sdk.bd.3
        @Override // android.view.ViewTreeObserver.OnGlobalLayoutListener
        public final void onGlobalLayout() {
            bd.b(bd.this);
            if (bd.a(bd.this)) {
                return;
            }
            bd.e(bd.this);
            float fB = dm.b();
            float fC = dm.c();
            int iIntValue = ((Integer) dm.e(pg.a.a(), pg.a.a(), 1933108801, new Object[0], pg.a.a(), -1933108792, pg.a.a())).intValue();
            int iA = (int) (bh.a(35) * fC * fB);
            float f = iIntValue / 2.0f;
            int iRound = Math.round(f);
            int iRound2 = Math.round(f);
            RelativeLayout.LayoutParams layoutParams = (RelativeLayout.LayoutParams) bd.this.c.getLayoutParams();
            layoutParams.setMargins(iRound, iRound, 0, 0);
            layoutParams.setMarginStart(iRound);
            layoutParams.setMarginEnd(iRound);
            bd.this.c.setLayoutParams(layoutParams);
            bd.this.c.setPadding(iRound2, iRound2, iRound2, iRound2);
            bd.this.c.getLayoutParams().height = iA;
            bd.this.c.getLayoutParams().width = iA;
            bd.this.c.requestLayout();
        }
    };
    private final Runnable C = new Runnable() { // from class: com.facetec.sdk.水
        @Override // java.lang.Runnable
        public final void run() {
            this.f7280.m();
        }
    };
    private final cp.b D = new cp.b() { // from class: com.facetec.sdk.海
        @Override // com.facetec.sdk.cp.b
        public final void onPreSessionProgress(da daVar, cw cwVar, cs csVar, ct ctVar) throws Throwable {
            this.f7281.e(daVar, cwVar, csVar, ctVar);
        }
    };

    /* JADX INFO: renamed from: com.facetec.sdk.bd$2, reason: invalid class name */
    public static /* synthetic */ class AnonymousClass2 {
        static final /* synthetic */ int[] c;
        static final /* synthetic */ int[] d;

        static {
            int[] iArr = new int[FaceTecCancelButtonCustomization.ButtonLocation.values().length];
            c = iArr;
            try {
                iArr[FaceTecCancelButtonCustomization.ButtonLocation.TOP_LEFT.ordinal()] = 1;
            } catch (NoSuchFieldError unused) {
            }
            try {
                c[FaceTecCancelButtonCustomization.ButtonLocation.TOP_RIGHT.ordinal()] = 2;
            } catch (NoSuchFieldError unused2) {
            }
            try {
                c[FaceTecCancelButtonCustomization.ButtonLocation.CUSTOM.ordinal()] = 3;
            } catch (NoSuchFieldError unused3) {
            }
            try {
                c[FaceTecCancelButtonCustomization.ButtonLocation.DISABLED.ordinal()] = 4;
            } catch (NoSuchFieldError unused4) {
            }
            int[] iArr2 = new int[FaceTecSecurityWatermarkImage.values().length];
            d = iArr2;
            try {
                iArr2[FaceTecSecurityWatermarkImage.FACETEC_ZOOM.ordinal()] = 1;
            } catch (NoSuchFieldError unused5) {
            }
            try {
                d[FaceTecSecurityWatermarkImage.FACETEC.ordinal()] = 2;
            } catch (NoSuchFieldError unused6) {
            }
            try {
                d[FaceTecSecurityWatermarkImage.FACETEC_POWERED_BY.ordinal()] = 3;
            } catch (NoSuchFieldError unused7) {
            }
        }
    }

    public class d implements cp.e {
        public static int c;
        public static int e;

        public d() {
        }

        @Override // com.facetec.sdk.cp.e
        public final void a() {
            bd.d(bd.this);
            bd.f(bd.this);
        }

        @Override // com.facetec.sdk.cp.e
        public final void b() {
            bd.d(bd.this);
            bd.j(bd.this);
        }

        @Override // com.facetec.sdk.cp.e
        public final void c(cu cuVar, cm cmVar) throws Throwable {
            bd.c(bd.this, cuVar, cmVar);
        }

        @Override // com.facetec.sdk.cp.e
        public final void d() {
            bd.d(bd.this);
            bd.h(bd.this);
        }

        @Override // com.facetec.sdk.cp.e
        public final void e() {
            bd.d(bd.this);
            bd.c(bd.this);
        }

        public static int c() {
            int i = e;
            int i2 = i % 8790790;
            e = i + 1;
            if (i2 != 0) {
                return c;
            }
            int iFreeMemory = (int) Runtime.getRuntime().freeMemory();
            c = iFreeMemory;
            return iFreeMemory;
        }
    }

    /* JADX WARN: Removed duplicated region for block: B:10:0x0022  */
    /* JADX WARN: Removed duplicated region for block: B:8:0x001c  */
    /* JADX WARN: Unsupported multi-entry loop pattern (BACK_EDGE: B:10:0x0022 -> B:11:0x0024). Please report as a decompilation issue!!! */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    private static java.lang.String $$e(short r5, short r6, short r7) {
        /*
            int r7 = r7 + 102
            byte[] r0 = com.facetec.sdk.bd.$$c
            int r5 = r5 * 3
            int r1 = r5 + 1
            int r6 = r6 * 2
            int r6 = r6 + 4
            byte[] r1 = new byte[r1]
            r2 = 0
            if (r0 != 0) goto L14
            r3 = r5
            r4 = r2
            goto L24
        L14:
            r3 = r2
        L15:
            byte r4 = (byte) r7
            r1[r3] = r4
            int r4 = r3 + 1
            if (r3 != r5) goto L22
            java.lang.String r5 = new java.lang.String
            r5.<init>(r1, r2)
            return r5
        L22:
            r3 = r0[r6]
        L24:
            int r3 = -r3
            int r7 = r7 + r3
            int r6 = r6 + 1
            r3 = r4
            goto L15
        */
        throw new UnsupportedOperationException("Method not decompiled: com.facetec.sdk.bd.$$e(short, short, short):java.lang.String");
    }

    static {
        init$1();
        $10 = 0;
        $11 = 1;
        init$0();
        L = 0;
        N = 1;
        H = 0;
        M = 1;
        a();
        a = false;
        N = (L + 109) % 128;
    }

    /* JADX WARN: Removed duplicated region for block: B:10:0x0026  */
    /* JADX WARN: Removed duplicated region for block: B:8:0x001e  */
    /* JADX WARN: Unsupported multi-entry loop pattern (BACK_EDGE: B:10:0x0026 -> B:11:0x0030). Please report as a decompilation issue!!! */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    private static void J(byte r6, byte r7, byte r8, java.lang.Object[] r9) {
        /*
            int r8 = r8 * 4
            int r0 = r8 + 1
            int r6 = 99 - r6
            int r7 = r7 * 2
            int r7 = 3 - r7
            byte[] r1 = com.facetec.sdk.bd.$$a
            byte[] r0 = new byte[r0]
            r2 = 0
            if (r1 != 0) goto L16
            r3 = r1
            r4 = r2
            r1 = r7
            r7 = r8
            goto L30
        L16:
            r3 = r2
        L17:
            int r7 = r7 + 1
            byte r4 = (byte) r6
            r0[r3] = r4
            if (r3 != r8) goto L26
            java.lang.String r6 = new java.lang.String
            r6.<init>(r0, r2)
            r9[r2] = r6
            return
        L26:
            r4 = r1[r7]
            int r3 = r3 + 1
            r5 = r7
            r7 = r6
            r6 = r4
            r4 = r3
            r3 = r1
            r1 = r5
        L30:
            int r6 = -r6
            int r6 = r6 + r7
            r7 = r1
            r1 = r3
            r3 = r4
            goto L17
        */
        throw new UnsupportedOperationException("Method not decompiled: com.facetec.sdk.bd.J(byte, byte, byte, java.lang.Object[]):void");
    }

    private static void K(short s, int i, byte b, int i2, int i3, Object[] objArr) throws Throwable {
        int i4;
        int i5;
        int i6;
        int i7;
        char c;
        long j;
        long j2;
        int i8;
        int i9;
        int length;
        byte[] bArr;
        int i10;
        int i11;
        int i12;
        int i13;
        hh hhVar = new hh();
        StringBuilder sb = new StringBuilder();
        int i14 = 2;
        try {
            int i15 = 1;
            Object[] objArr2 = {Integer.valueOf(i), Integer.valueOf(E)};
            int i16 = 0;
            Object objD = an.d(962055330);
            Class cls = Integer.TYPE;
            if (objD == null) {
                int maximumFlingVelocity = 2402 - (ViewConfiguration.getMaximumFlingVelocity() >> 16);
                char cMyTid = (char) (Process.myTid() >> 22);
                int gidForName = 23 - Process.getGidForName("");
                byte b2 = (byte) ($$d - 3);
                i4 = 962055330;
                objD = an.d(maximumFlingVelocity, cMyTid, gidForName, 1328947193, false, $$e(b2, b2, (byte) $$c.length), new Class[]{cls, cls});
            } else {
                i4 = 962055330;
            }
            int iIntValue = ((Integer) ((Method) objD).invoke(null, objArr2)).intValue();
            if (iIntValue == -1) {
                $10 = ($11 + 65) % 128;
                i5 = 1;
            } else {
                i5 = 0;
            }
            if (i5 != 0) {
                byte[] bArr2 = I;
                if (bArr2 != null) {
                    c = 3;
                    int length2 = bArr2.length;
                    j = 0;
                    byte[] bArr3 = new byte[length2];
                    int i17 = 0;
                    while (i17 < length2) {
                        Object[] objArr3 = {Integer.valueOf(bArr2[i17])};
                        Object objD2 = an.d(399840230);
                        if (objD2 == null) {
                            i12 = i15;
                            i13 = i16;
                            byte b3 = (byte) ($$d - 3);
                            i11 = i14;
                            byte b4 = b3;
                            objD2 = an.d(View.combineMeasuredStates(i16, i16) + 2064, (char) (14866 - TextUtils.getCapsMode("", i16, i16)), (ViewConfiguration.getScrollDefaultDelay() >> 16) + 24, 1639235773, false, $$e(b3, b4, (byte) (b4 + 1)), new Class[]{cls});
                        } else {
                            i11 = i14;
                            i12 = i15;
                            i13 = i16;
                        }
                        bArr3[i17] = ((Byte) ((Method) objD2).invoke(null, objArr3)).byteValue();
                        i17++;
                        i15 = i12;
                        i16 = i13;
                        i14 = i11;
                    }
                    bArr2 = bArr3;
                } else {
                    c = 3;
                    j = 0;
                }
                int i18 = i14;
                i6 = i15;
                i7 = i16;
                j2 = -7666492657327691677L;
                if (bArr2 != null) {
                    int i19 = $11 + 113;
                    $10 = i19 % 128;
                    if (i19 % 2 != 0) {
                        byte[] bArr4 = I;
                        Object[] objArr4 = new Object[i18];
                        objArr4[i6] = Integer.valueOf(B);
                        objArr4[i7] = Integer.valueOf(i3);
                        Object objD3 = an.d(i4);
                        if (objD3 == null) {
                            byte b5 = (byte) ($$d - 3);
                            objD3 = an.d(2402 - ExpandableListView.getPackedPositionType(j), (char) (ViewConfiguration.getWindowTouchSlop() >> 8), 24 - (ViewConfiguration.getMaximumDrawingCacheSize() >> 24), 1328947193, false, $$e(b5, b5, (byte) $$c.length), new Class[]{cls, cls});
                        }
                        i10 = ((byte) (((long) bArr4[((Integer) ((Method) objD3).invoke(null, objArr4)).intValue()]) / (-7666492657327691677L))) / ((int) (((long) E) & (-7666492657327691677L)));
                    } else {
                        byte[] bArr5 = I;
                        Object[] objArr5 = new Object[2];
                        objArr5[i6] = Integer.valueOf(B);
                        objArr5[i7] = Integer.valueOf(i3);
                        Object objD4 = an.d(i4);
                        if (objD4 == null) {
                            byte b6 = (byte) ($$d - 3);
                            objD4 = an.d(2403 - (SystemClock.elapsedRealtimeNanos() > j ? 1 : (SystemClock.elapsedRealtimeNanos() == j ? 0 : -1)), (char) (ViewConfiguration.getWindowTouchSlop() >> 8), Color.red(i7) + 24, 1328947193, false, $$e(b6, b6, (byte) $$c.length), new Class[]{cls, cls});
                        }
                        i10 = ((byte) (((long) bArr5[((Integer) ((Method) objD4).invoke(null, objArr5)).intValue()]) ^ (-7666492657327691677L))) + ((int) (((long) E) ^ (-7666492657327691677L)));
                    }
                    iIntValue = (byte) i10;
                } else {
                    iIntValue = (short) (((short) (((long) G[i3 + ((int) (((long) B) ^ (-7666492657327691677L)))]) ^ (-7666492657327691677L))) + ((int) (((long) E) ^ (-7666492657327691677L))));
                }
            } else {
                i6 = 1;
                i7 = 0;
                c = 3;
                j = 0;
                j2 = -7666492657327691677L;
            }
            if (iIntValue > 0) {
                hhVar.d = ((i3 + iIntValue) - 2) + ((int) (((long) B) ^ j2)) + i5;
                int i20 = F;
                Object[] objArr6 = new Object[4];
                objArr6[c] = sb;
                objArr6[2] = Integer.valueOf(i20);
                objArr6[i6] = Integer.valueOf(i2);
                objArr6[i7] = hhVar;
                Object objD5 = an.d(-1066327576);
                if (objD5 == null) {
                    byte b7 = (byte) ($$d - 3);
                    byte b8 = b7;
                    objD5 = an.d(((Process.getThreadPriority(i7) + 20) >> 6) + 1803, (char) (9691 - TextUtils.indexOf((CharSequence) "", '0', i7)), (ViewConfiguration.getGlobalActionKeyTimeout() > j ? 1 : (ViewConfiguration.getGlobalActionKeyTimeout() == j ? 0 : -1)) + 23, -1240403277, false, $$e(b7, b8, b8), new Class[]{Object.class, cls, cls, Object.class});
                }
                ((StringBuilder) ((Method) objD5).invoke(null, objArr6)).append(hhVar.e);
                hhVar.c = hhVar.e;
                byte[] bArr6 = I;
                if (bArr6 != null) {
                    int i21 = $11 + 67;
                    $10 = i21 % 128;
                    if (i21 % 2 != 0) {
                        length = bArr6.length;
                        bArr = new byte[length];
                    } else {
                        length = bArr6.length;
                        bArr = new byte[length];
                    }
                    for (int i22 = 0; i22 < length; i22++) {
                        bArr[i22] = (byte) (((long) bArr6[i22]) ^ j2);
                    }
                    bArr6 = bArr;
                }
                if (bArr6 != null) {
                    i8 = i6;
                    i9 = i8;
                } else {
                    i8 = i6;
                    i9 = 0;
                }
                while (true) {
                    hhVar.b = i8;
                    if (hhVar.b >= iIntValue) {
                        break;
                    }
                    $10 = ($11 + 103) % 128;
                    if (i9 != 0) {
                        byte[] bArr7 = I;
                        hhVar.d = hhVar.d - 1;
                        hhVar.e = (char) (hhVar.c + (((byte) (((byte) (((long) bArr7[r3]) ^ j2)) + s)) ^ b));
                    } else {
                        short[] sArr = G;
                        hhVar.d = hhVar.d - 1;
                        hhVar.e = (char) (hhVar.c + (((short) (((short) (((long) sArr[r3]) ^ j2)) + s)) ^ b));
                    }
                    sb.append(hhVar.e);
                    hhVar.c = hhVar.e;
                    i8 = hhVar.b + 1;
                }
            }
            objArr[0] = sb.toString();
        } catch (Throwable th) {
            Throwable cause = th.getCause();
            if (cause == null) {
                throw th;
            }
            throw cause;
        }
    }

    public static /* synthetic */ boolean a(bd bdVar) {
        int i = M;
        int i2 = i + 125;
        H = i2 % 128;
        int i3 = i2 % 2;
        boolean z = bdVar.p;
        if (i3 != 0) {
            int i4 = 24 / 0;
        }
        H = (i + 101) % 128;
        return z;
    }

    /* JADX WARN: Removed duplicated region for block: B:18:0x0120  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public static /* synthetic */ java.lang.Object b(int r7, int r8, int r9, int r10, java.lang.Object[] r11, int r12, int r13) {
        /*
            Method dump skipped, instruction units count: 422
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: com.facetec.sdk.bd.b(int, int, int, int, java.lang.Object[], int, int):java.lang.Object");
    }

    public static /* synthetic */ void c(final bd bdVar) {
        int i = H + 7;
        M = i % 128;
        if (i % 2 == 0) {
            throw null;
        }
        bi biVar = (bi) bdVar.getActivity();
        if (biVar != null) {
            biVar.M.e();
            M = (H + 3) % 128;
        }
        final bm bmVarJ = bdVar.j();
        if (!bdVar.b() || bmVarJ == null) {
            return;
        }
        bdVar.i();
        ce.e(bmVarJ);
        if (bdVar.s) {
            H = (M + 59) % 128;
            at.e(bmVarJ, ax.FT_EVENT_FACESCAN_SESSION_FAIL);
        }
        bdVar.d((Runnable) new au.c(new Runnable() { // from class: com.facetec.sdk.气
            @Override // java.lang.Runnable
            public final void run() {
                this.f7278.a(bmVarJ);
            }
        }), false);
    }

    public static /* synthetic */ void d(bd bdVar) {
        M = (H + 3) % 128;
        ed.e();
        bdVar.h.setImportantForAccessibility(2);
        bdVar.h.setOnTouchListener(null);
        M = (H + 81) % 128;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static /* synthetic */ boolean e(Context context, View view, MotionEvent motionEvent) {
        int i = M + 53;
        H = i % 128;
        if (i % 2 == 0 ? motionEvent.getAction() == 1 : motionEvent.getAction() == 0) {
            int i2 = M + 55;
            H = i2 % 128;
            if (i2 % 2 != 0) {
                ed.d(context, ed.d.BLIND_USER_ASSIST_FACESCAN_FEEDBACK);
                throw null;
            }
            ed.d(context, ed.d.BLIND_USER_ASSIST_FACESCAN_FEEDBACK);
        }
        return true;
    }

    private cp f() {
        M = (H + 55) % 128;
        bm bmVarJ = j();
        if (bmVarJ == null) {
            return null;
        }
        int i = H + 89;
        M = i % 128;
        if (i % 2 != 0) {
            return bmVarJ.e;
        }
        int i2 = 41 / 0;
        return bmVarJ.e;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void g(final bm bmVar) {
        this.l.post(new au.c(new Runnable() { // from class: com.facetec.sdk.金
            @Override // java.lang.Runnable
            public final void run() {
                bd.j(bmVar);
            }
        }));
        H = (M + 77) % 128;
    }

    private void h() {
        int i = H + 77;
        int i2 = i % 128;
        M = i2;
        if (i % 2 == 0) {
            throw null;
        }
        if ((!this.u) && this.s) {
            int i3 = i2 + 109;
            H = i3 % 128;
            if (i3 % 2 != 0) {
                this.h.c();
                this.u = false;
            } else {
                this.h.c();
                this.u = true;
            }
        }
        H = (M + 119) % 128;
    }

    private static /* synthetic */ Object i(Object[] objArr) {
        bd bdVar = (bd) objArr[0];
        int i = M + 51;
        H = i % 128;
        if (i % 2 != 0) {
            ImageView imageView = bdVar.c;
            throw null;
        }
        ImageView imageView2 = bdVar.c;
        if (imageView2 != null) {
            imageView2.getViewTreeObserver().removeOnGlobalLayoutListener(bdVar.z);
        }
        int i2 = M + 63;
        H = i2 % 128;
        if (i2 % 2 == 0) {
            return null;
        }
        throw null;
    }

    public static void init$0() {
        $$a = new byte[]{20, 103, 109, ISO7816.INS_DECREASE_STAMPED};
        $$b = EnumC41897g.SDK_ASSET_ICON_PROGRESS_VALUE;
    }

    public static void init$1() {
        $$c = new byte[]{5, 64, 127, 81};
        $$d = 3;
    }

    public static /* synthetic */ void j(final bd bdVar) {
        int i = H + 1;
        M = i % 128;
        if (i % 2 == 0) {
            int i2 = 98 / 0;
            if (bdVar.A) {
                return;
            }
        } else if (bdVar.A) {
            return;
        }
        bdVar.A = true;
        final bm bmVarJ = bdVar.j();
        if (bdVar.b() && bmVarJ != null) {
            bdVar.d((Runnable) new au.c(new Runnable() { // from class: com.facetec.sdk.王
                @Override // java.lang.Runnable
                public final void run() {
                    this.f7285.e(bmVarJ);
                }
            }), true);
            return;
        }
        int i3 = M + 53;
        H = i3 % 128;
        if (i3 % 2 != 0) {
            int i4 = 19 / 0;
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void k() {
        int i = M + 93;
        H = i % 128;
        if (i % 2 != 0) {
            this.f.e();
            throw null;
        }
        this.f.e();
        int i2 = H + 37;
        M = i2 % 128;
        if (i2 % 2 == 0) {
            int i3 = 64 / 0;
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void l() {
        int i = M + 61;
        H = i % 128;
        if (i % 2 == 0) {
            this.c.setImageResource(dm.aQ());
            this.h.e();
        } else {
            this.c.setImageResource(dm.aQ());
            this.h.e();
            throw null;
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    /* JADX WARN: Removed duplicated region for block: B:9:0x0021  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public /* synthetic */ void m() {
        /*
            r3 = this;
            int r0 = com.facetec.sdk.bd.H
            int r0 = r0 + 55
            int r1 = r0 % 128
            com.facetec.sdk.bd.M = r1
            int r0 = r0 % 2
            if (r0 != 0) goto L19
            com.facetec.sdk.cu r0 = com.facetec.sdk.cv.i()
            com.facetec.sdk.cu r1 = com.facetec.sdk.cu.ZOOM_CLOSE
            r2 = 78
            int r2 = r2 / 0
            if (r0 != r1) goto L32
            goto L21
        L19:
            com.facetec.sdk.cu r0 = com.facetec.sdk.cv.i()
            com.facetec.sdk.cu r1 = com.facetec.sdk.cu.ZOOM_CLOSE
            if (r0 != r1) goto L32
        L21:
            com.facetec.sdk.bm r0 = r3.j()
            com.facetec.sdk.ed$d r1 = com.facetec.sdk.ed.d.FACE_CAPTURE_MOVE_CLOSER_DELAYED
            com.facetec.sdk.ed.d(r0, r1)
            int r0 = com.facetec.sdk.bd.M
            int r0 = r0 + 61
            int r0 = r0 % 128
            com.facetec.sdk.bd.H = r0
        L32:
            int r0 = com.facetec.sdk.bd.M
            int r0 = r0 + 1
            int r1 = r0 % 128
            com.facetec.sdk.bd.H = r1
            int r0 = r0 % 2
            if (r0 != 0) goto L3f
            return
        L3f:
            r0 = 0
            throw r0
        */
        throw new UnsupportedOperationException("Method not decompiled: com.facetec.sdk.bd.m():void");
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void n() {
        int i = H + 9;
        M = i % 128;
        if (i % 2 == 0) {
            this.v.release();
            throw null;
        }
        this.v.release();
        H = (M + 105) % 128;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void o() {
        int iE = gn.AnonymousClass24.e();
        int iE2 = gn.AnonymousClass24.e();
        int iE3 = gn.AnonymousClass24.e();
        b(gn.AnonymousClass24.e(), iE2, iE3, 525446058, new Object[]{this}, iE, -525446055);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void q() {
        int iE = gn.AnonymousClass24.e();
        int iE2 = gn.AnonymousClass24.e();
        int iE3 = gn.AnonymousClass24.e();
        b(gn.AnonymousClass24.e(), iE2, iE3, 1840238770, new Object[]{this}, iE, -1840238766);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void r() {
        if (this.f95827g) {
            return;
        }
        this.e.setAlpha(SelfieScan.RECOGNITION_FAIL_RESULT);
        if (!(!bj.i)) {
            this.e.setVisibility(4);
        } else {
            int i = M + 97;
            H = i % 128;
            if (i % 2 != 0) {
                this.e.setVisibility(1);
            } else {
                this.e.setVisibility(0);
            }
        }
        this.b.setAlpha(SelfieScan.RECOGNITION_FAIL_RESULT);
        this.w = false;
        this.h.d(false);
        int iG = this.h.g() - (this.y << 1);
        if ((((int) this.h.c.bottom) - this.e.getHeight()) - (this.y << 1) >= iG && dm.a() < 1.4d) {
            int i2 = H + 1;
            M = i2 % 128;
            if (i2 % 2 == 0) {
                this.e.setY(iG);
                throw null;
            }
            this.e.setY(iG);
        }
        this.e.animate().alpha(1.0f).setDuration(500L).setListener(null).start();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void s() {
        int i = M;
        int i2 = i + 33;
        H = i2 % 128;
        this.m = i2 % 2 == 0;
        int i3 = i + 61;
        H = i3 % 128;
        if (i3 % 2 != 0) {
            throw null;
        }
    }

    @Override // com.facetec.sdk.au, android.app.Fragment
    public final void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        this.s = false;
        this.r = false;
        this.t = false;
        this.v = new Semaphore(1);
        int i = H + 109;
        M = i % 128;
        if (i % 2 == 0) {
            throw null;
        }
    }

    @Override // android.app.Fragment
    public final Animator onCreateAnimator(int i, boolean z, int i2) {
        int i3 = (M + 15) % 128;
        H = i3;
        if (z) {
            return super.onCreateAnimator(i, z, i2);
        }
        M = (i3 + 49) % 128;
        return ObjectAnimator.ofFloat((Object) null, ViewHierarchyNode.JsonKeys.ALPHA, 1.0f, SelfieScan.RECOGNITION_FAIL_RESULT).setDuration(400L);
    }

    @Override // android.app.Fragment
    @SuppressLint({"ClickableViewAccessibility"})
    public final View onCreateView(LayoutInflater layoutInflater, ViewGroup viewGroup, Bundle bundle) {
        int i;
        boolean z;
        int i2 = H + 13;
        M = i2 % 128;
        if (i2 % 2 == 0) {
            i = R.layout.facetec_facescan_fragment;
            z = true;
        } else {
            i = R.layout.facetec_facescan_fragment;
            z = false;
        }
        View viewInflate = layoutInflater.inflate(i, viewGroup, z);
        H = (M + 3) % 128;
        return viewInflate;
    }

    @Override // android.app.Fragment
    public final void onDestroy() {
        int iE = gn.AnonymousClass24.e();
        int iE2 = gn.AnonymousClass24.e();
        int iE3 = gn.AnonymousClass24.e();
        b(gn.AnonymousClass24.e(), iE2, iE3, -840435256, new Object[]{this}, iE, 840435258);
    }

    @Override // android.app.Fragment
    public final void onPause() {
        int iE = gn.AnonymousClass24.e();
        int iE2 = gn.AnonymousClass24.e();
        int iE3 = gn.AnonymousClass24.e();
        b(gn.AnonymousClass24.e(), iE2, iE3, -1908459676, new Object[]{this}, iE, 1908459677);
    }

    @Override // android.app.Fragment
    public final void onViewCreated(View view, Bundle bundle) throws Throwable {
        super.onViewCreated(view, bundle);
        final bm bmVarJ = j();
        cp cpVarF = f();
        if (cpVarF == null) {
            int i = M + 19;
            H = i % 128;
            if (i % 2 != 0) {
                throw null;
            }
            return;
        }
        t.d = ao.n;
        d dVar = new d();
        this.i = dVar;
        cpVarF.c(dVar);
        da daVarO = cpVarF.o();
        cs csVarK = cpVarF.k();
        cm cmVarT = cpVarF.t();
        da daVar = da.READY_TO_START_FACESCAN_SESSION;
        if (daVarO != daVar) {
            int i2 = M + 51;
            H = i2 % 128;
            if (i2 % 2 != 0) {
                cpVarF.d(this.D);
                throw null;
            }
            cpVarF.d(this.D);
        }
        this.e = (LinearLayout) view.findViewById(R.id.zoomLogoContainer);
        this.b = (TextView) view.findViewById(R.id.zoomLogoText);
        String packageName = bmVarJ.getPackageName();
        ImageView imageView = (ImageView) view.findViewById(R.id.securityWatermark);
        int i3 = AnonymousClass2.d[FaceTecSDK.d.securityWatermarkImage.ordinal()];
        if (i3 == 1) {
            imageView.setImageDrawable(C6852.getDrawable(getActivity(), R.drawable.facetec_internal_zoom_watermark));
        } else if (i3 == 2) {
            imageView.setImageDrawable(C6852.getDrawable(getActivity(), R.drawable.facetec_internal_facetec_watermark));
        } else if (i3 == 3) {
            imageView.setImageDrawable(C6852.getDrawable(getActivity(), R.drawable.facetec_internal_facetec_powered_by_watermark));
        }
        float fB = dm.b();
        imageView.setLayoutParams(new LinearLayout.LayoutParams(-2, (int) (dq.b().heightPixels * dm.c() * 0.15f * fB)));
        this.b.setVisibility(0);
        this.b.setTextSize(dm.c() * 8.0f * fB);
        if (packageName.contains("com.facetec.zoomlogin")) {
            this.b.setText("v9.7.130");
        } else {
            this.b.setText("v9.7.130".concat(Build.CPU_ABI.equals("arm64-v8a") ? " 64-bit" : ""));
        }
        this.e.setPadding(0, 0, 0, 12);
        this.h = (de) view.findViewById(R.id.zoomOval);
        this.j = view.findViewById(R.id.instructionsBackground);
        this.c = (ImageView) view.findViewById(R.id.backButton);
        cy cyVar = (cy) view.findViewById(R.id.zoomProgressBar);
        this.f = cyVar;
        cyVar.setVisibility(4);
        TextView textView = (TextView) cyVar.findViewById(R.id.feedbackText);
        cyVar.e = textView;
        textView.setImportantForAccessibility(2);
        C29160.m74376(cyVar.e, 1);
        C29160.m74375(cyVar.e, 5, 50, 1, 2);
        int iC = cy.c(cmVarT);
        cyVar.a = cmVarT;
        if (daVarO != daVar) {
            int i4 = M + 69;
            H = i4 % 128;
            if (i4 % 2 != 0) {
                int i5 = cy.AnonymousClass1.b[csVarK.ordinal()];
                throw null;
            }
            switch (cy.AnonymousClass1.b[csVarK.ordinal()]) {
                case 1:
                    cyVar.d = cs.FRAME_YOUR_FACE;
                    break;
                case 2:
                    cyVar.d = cs.FRAME_YOUR_FACE;
                    break;
                case 3:
                    cyVar.d = cs.WEARING_SUNGLASSES;
                    break;
                case 4:
                    cyVar.d = cs.BAD_POSE;
                    break;
                case 5:
                    cyVar.d = cs.TOO_BRIGHT;
                    break;
                case 6:
                    cyVar.d = cs.TOO_DARK;
                    break;
                case 7:
                    cyVar.d = cs.MAKING_FACE;
                    break;
                case 8:
                    cyVar.d = cs.HOLD_STEADY_3;
                    break;
                case 9:
                    cyVar.d = cs.HOLD_STEADY_2;
                    break;
                case 10:
                    cyVar.d = cs.HOLD_STEADY_1;
                    break;
                case 11:
                    cyVar.d = cs.MOVE_CLOSER;
                    break;
                case 12:
                    cyVar.d = cs.MOVE_AWAY;
                    break;
            }
            iC = cy.a(cyVar.d);
        }
        ed.b(iC);
        dp.e(cyVar.e, iC);
        cyVar.e.setTypeface(FaceTecSDK.d.l.textFont);
        dm.a(cyVar.e);
        GradientDrawable gradientDrawableV = dm.v(cyVar.getContext());
        View viewFindViewById = cyVar.findViewById(R.id.zoomFeedbackContainer);
        cyVar.b = viewFindViewById;
        viewFindViewById.setBackground(gradientDrawableV);
        cyVar.setPadding(10, 10, 10, 15);
        cyVar.b.setElevation(bh.a(FaceTecSDK.d.l.elevation));
        cyVar.b.setOutlineProvider(ViewOutlineProvider.BACKGROUND);
        cyVar.b.setClipToOutline(false);
        cyVar.b.requestLayout();
        TextView textView2 = cyVar.e;
        Property property = View.ALPHA;
        ObjectAnimator objectAnimatorOfFloat = ObjectAnimator.ofFloat(textView2, (Property<TextView, Float>) property, SelfieScan.RECOGNITION_FAIL_RESULT);
        cyVar.j = objectAnimatorOfFloat;
        objectAnimatorOfFloat.setDuration(500L);
        cyVar.j.addListener(cyVar.h);
        ObjectAnimator objectAnimatorOfFloat2 = ObjectAnimator.ofFloat(cyVar.e, (Property<TextView, Float>) property, 1.0f);
        cyVar.i = objectAnimatorOfFloat2;
        objectAnimatorOfFloat2.setDuration(500L);
        float fA = bh.a(((FaceTecSize) dm.e(pg.a.a(), pg.a.a(), -1527441011, new Object[0], pg.a.a(), 1527441052, pg.a.a())).height) * dm.c();
        float fA2 = bh.a(((FaceTecSize) dm.e(pg.a.a(), pg.a.a(), -1527441011, new Object[0], pg.a.a(), 1527441052, pg.a.a())).width) * dm.c();
        cyVar.e.getLayoutParams().height = (int) fA;
        cyVar.e.getLayoutParams().width = (int) fA2;
        int iRound = Math.round(bh.a(10) * dm.c() * dm.b());
        cyVar.e.setPadding(iRound, Math.round(iRound * 1.1f), iRound, iRound);
        cyVar.e.requestLayout();
        cy cyVar2 = this.f;
        if (cyVar2.getLayoutParams() instanceof ViewGroup.MarginLayoutParams) {
            RelativeLayout.LayoutParams layoutParams = (RelativeLayout.LayoutParams) cyVar2.getLayoutParams();
            dm.f();
            layoutParams.addRule(13, -1);
            layoutParams.setMargins(0, 0, 0, 0);
            cyVar2.requestLayout();
        }
        FrameLayout frameLayout = (FrameLayout) view.findViewById(R.id.transitionView);
        this.k = frameLayout;
        dm.b(frameLayout);
        this.l = new Handler(Looper.getMainLooper());
        this.n = new Handler();
        if (daVarO == daVar) {
            a((Context) bmVarJ);
        }
        if (ed.b()) {
            H = (M + 11) % 128;
            ((FaceTecSessionActivity) bmVarJ).setTitle(" ");
            this.h.setImportantForAccessibility(1);
            this.h.setContentDescription(bmVarJ.getString(R.string.FaceTec_accessibility_tap_guidance));
            this.h.setOnTouchListener(new View.OnTouchListener() { // from class: com.facetec.sdk.木
                @Override // android.view.View.OnTouchListener
                public final boolean onTouch(View view2, MotionEvent motionEvent) {
                    return bd.e(bmVarJ, view2, motionEvent);
                }
            });
        }
        this.c.setEnabled(true);
        if (FaceTecSDK.d.m.b != FaceTecCancelButtonCustomization.ButtonLocation.DISABLED) {
            int iAQ = dm.aQ();
            if (iAQ == 0) {
                iAQ = R.drawable.facetec_cancel;
                t.d(bmVarJ, c.CANCEL_BUTTON_RESOURCE_ID_ERROR, null, null);
            }
            this.c.setImageDrawable(C6852.getDrawable(bmVarJ, iAQ));
        }
        int i6 = AnonymousClass2.c[FaceTecSDK.d.m.b.ordinal()];
        if (i6 == 2) {
            RelativeLayout.LayoutParams layoutParams2 = (RelativeLayout.LayoutParams) this.c.getLayoutParams();
            layoutParams2.removeRule(20);
            layoutParams2.addRule(21);
            this.c.setLayoutParams(layoutParams2);
        } else if (i6 == 3 || i6 == 4) {
            this.c.setVisibility(8);
        }
        this.c.getViewTreeObserver().addOnGlobalLayoutListener(this.z);
        this.c.setOnClickListener(new View.OnClickListener() { // from class: com.facetec.sdk.神
            @Override // android.view.View.OnClickListener
            public final void onClick(View view2) {
                this.f7292.d(bmVarJ, view2);
            }
        });
        this.c.setOnTouchListener(new View.OnTouchListener() { // from class: com.facetec.sdk.祭
            @Override // android.view.View.OnTouchListener
            public final boolean onTouch(View view2, MotionEvent motionEvent) {
                return this.f7294.d(view2, motionEvent);
            }
        });
        bm bmVarJ2 = j();
        if (bmVarJ2 != null) {
            M = (H + 17) % 128;
            bmVarJ2.runOnUiThread(new Runnable() { // from class: com.facetec.sdk.符
                @Override // java.lang.Runnable
                public final void run() {
                    this.f7295.l();
                }
            });
        }
        this.m = false;
        this.h.setVisibility(0);
        this.h.setAlpha(1.0f);
        this.k.setAlpha(SelfieScan.RECOGNITION_FAIL_RESULT);
        this.c.setAlpha(SelfieScan.RECOGNITION_FAIL_RESULT);
        new Handler().postDelayed(new au.c(new Runnable() { // from class: com.facetec.sdk.药
            @Override // java.lang.Runnable
            public final void run() {
                this.f7296.q();
            }
        }), 0L);
    }

    private void a(final Context context) throws Throwable {
        t.d = ao.o;
        this.f95827g = false;
        final bi biVar = (bi) getActivity();
        if (biVar != null) {
            H = (M + 55) % 128;
            biVar.H = bi.e.FACESCAN_SESSION_STARTED;
            H = (M + 117) % 128;
        }
        this.l.postDelayed(new au.c(new Runnable() { // from class: com.facetec.sdk.祖
            @Override // java.lang.Runnable
            public final void run() {
                this.f7289.b(context, biVar);
            }
        }), 20L);
        t.b(dh.FACE_SCAN_UNZOOMED);
    }

    private void g() {
        if (this.h.h()) {
            int i = M + 103;
            H = i % 128;
            if (i % 2 == 0) {
                this.h.j();
                H = (M + 47) % 128;
            } else {
                this.h.j();
                throw null;
            }
        }
    }

    public static /* synthetic */ void f(bd bdVar) {
        bdVar.A = false;
        bi biVar = (bi) bdVar.getActivity();
        if (biVar != null) {
            int i = M + 93;
            H = i % 128;
            if (i % 2 == 0) {
                biVar.M.e();
            } else {
                biVar.M.e();
                throw null;
            }
        }
        final bm bmVarJ = bdVar.j();
        if (bmVarJ != null) {
            bdVar.i();
            if (bdVar.r) {
                ce.a(bmVarJ);
                bdVar.r = false;
            }
            if (bdVar.t) {
                int i2 = H + 115;
                M = i2 % 128;
                try {
                    if (i2 % 2 == 0) {
                        bdVar.t = true;
                    } else {
                        bdVar.t = false;
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
            at.e(bmVarJ, ax.FT_EVENT_FACESCAN_SESSION_SUCCESS);
            bdVar.l.post(new Runnable() { // from class: com.facetec.sdk.玉
                @Override // java.lang.Runnable
                public final void run() {
                    bd.d(bmVarJ);
                }
            });
        }
    }

    public static bd d() {
        bd bdVar = new bd();
        int i = M + 35;
        H = i % 128;
        if (i % 2 == 0) {
            return bdVar;
        }
        throw null;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void e(final bm bmVar) {
        this.l.post(new au.c(new Runnable() { // from class: com.facetec.sdk.雨
            @Override // java.lang.Runnable
            public final void run() {
                bd.b(bmVar);
            }
        }));
        int i = M + 85;
        H = i % 128;
        if (i % 2 != 0) {
            throw null;
        }
    }

    private void i() {
        M = (H + 63) % 128;
        cp cpVarF = f();
        if (cpVarF != null) {
            M = (H + 81) % 128;
            cpVarF.d(this.i);
            this.i = null;
        }
        int i = H + 3;
        M = i % 128;
        if (i % 2 == 0) {
            throw null;
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void d(bm bmVar, View view) {
        if (this.s) {
            H = (M + 93) % 128;
            at.e(bmVar, ax.FT_EVENT_FACESCAN_SESSION_FAIL);
        }
        bmVar.o();
        int i = M + 43;
        H = i % 128;
        if (i % 2 != 0) {
            throw null;
        }
    }

    private static /* synthetic */ Object e(Object[] objArr) {
        bd bdVar = (bd) objArr[0];
        final bm bmVar = (bm) objArr[1];
        bdVar.l.post(new au.c(new Runnable() { // from class: com.facetec.sdk.风
            @Override // java.lang.Runnable
            public final void run() {
                bd.c(bmVar);
            }
        }));
        int i = H + 99;
        M = i % 128;
        if (i % 2 == 0) {
            int i2 = 54 / 0;
        }
        return null;
    }

    private bm j() {
        M = (H + 97) % 128;
        bm bmVar = (bm) getActivity();
        int i = H + 35;
        M = i % 128;
        if (i % 2 != 0) {
            return bmVar;
        }
        throw null;
    }

    public static /* synthetic */ void h(final bd bdVar) {
        bi biVar = (bi) bdVar.getActivity();
        if (biVar != null) {
            biVar.M.e();
        }
        final bm bmVarJ = bdVar.j();
        if (!bdVar.b() || bmVarJ == null) {
            return;
        }
        bdVar.i();
        ce.e(bmVarJ);
        if (bdVar.s) {
            M = (H + 115) % 128;
            at.e(bmVarJ, ax.FT_EVENT_FACESCAN_SESSION_FAIL);
            H = (M + 67) % 128;
        }
        bdVar.d((Runnable) new au.c(new Runnable() { // from class: com.facetec.sdk.礼
            @Override // java.lang.Runnable
            public final void run() {
                this.f7287.g(bmVarJ);
            }
        }), false);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static /* synthetic */ void j(bm bmVar) {
        H = (M + 35) % 128;
        bmVar.f();
        int i = M + 83;
        H = i % 128;
        if (i % 2 != 0) {
            int i2 = 9 / 0;
        }
    }

    private static /* synthetic */ Object a(Object[] objArr) throws Throwable {
        int i;
        int i2;
        float f;
        char c;
        char c2;
        Object[] objArr2;
        int i3;
        Object[] objArr3;
        int i4 = 0;
        bd bdVar = (bd) objArr[0];
        Object objD = an.d(-1397726040);
        if (objD == null) {
            int iRgb = Color.rgb(0, 0, 0) + 16777927;
            char offsetAfter = (char) (49308 - TextUtils.getOffsetAfter("", 0));
            int threadPriority = 24 - ((Process.getThreadPriority(0) + 20) >> 6);
            byte b = (byte) 0;
            byte b2 = b;
            Object[] objArr4 = new Object[1];
            J(b, b2, b2, objArr4);
            objD = an.d(iRgb, offsetAfter, threadPriority, -623790093, false, (String) objArr4[0], null);
        }
        long j = ((Field) objD).getLong(null);
        Object[] objArr5 = new Object[1];
        K((short) (View.resolveSizeAndState(0, 0, 0) - 74), (-64) - (Process.myPid() >> 22), (byte) (TextUtils.getTrimmedLength("") - 108), (-979242682) - TextUtils.indexOf("", "", 0), (-416843818) - (ExpandableListView.getPackedPositionForGroup(0) > 0L ? 1 : (ExpandableListView.getPackedPositionForGroup(0) == 0L ? 0 : -1)), objArr5);
        Class<?> cls = Class.forName((String) objArr5[0]);
        Object[] objArr6 = new Object[1];
        K((short) (ExpandableListView.getPackedPositionType(0L) + 14), Color.red(0) - 71, (byte) ((-50) - (ExpandableListView.getPackedPositionForChild(0, 0) > 0L ? 1 : (ExpandableListView.getPackedPositionForChild(0, 0) == 0L ? 0 : -1))), (KeyEvent.getMaxKeyCode() >> 16) - 979242678, (ViewConfiguration.getScrollBarSize() >> 8) - 416843797, objArr6);
        long jLongValue = ((Long) cls.getDeclaredMethod((String) objArr6[0], null).invoke(null, null)).longValue();
        Object objD2 = an.d(-1398649561);
        if (objD2 == null) {
            int iIndexOf = 711 - TextUtils.indexOf("", "", 0);
            char c3 = (char) (49308 - (PointF.length(SelfieScan.RECOGNITION_FAIL_RESULT, SelfieScan.RECOGNITION_FAIL_RESULT) > SelfieScan.RECOGNITION_FAIL_RESULT ? 1 : (PointF.length(SelfieScan.RECOGNITION_FAIL_RESULT, SelfieScan.RECOGNITION_FAIL_RESULT) == SelfieScan.RECOGNITION_FAIL_RESULT ? 0 : -1)));
            int tapTimeout = (ViewConfiguration.getTapTimeout() >> 16) + 24;
            byte b3 = (byte) ($$b & 7);
            i = -1397726040;
            byte b4 = (byte) (b3 - 1);
            i2 = 49308;
            f = 0.0f;
            Object[] objArr7 = new Object[1];
            J(b3, b4, b4, objArr7);
            objD2 = an.d(iIndexOf, c3, tapTimeout, -624714116, false, (String) objArr7[0], null);
        } else {
            i = -1397726040;
            i2 = 49308;
            f = 0.0f;
        }
        if (j == ((jLongValue - ((((Field) objD2).getLong(null) << 52) >>> 52)) >> 12)) {
            H = (M + 73) % 128;
            Object objD3 = an.d(-1399573082);
            if (objD3 == null) {
                int iAxisFromString = 710 - MotionEvent.axisFromString("");
                char scrollDefaultDelay = (char) ((ViewConfiguration.getScrollDefaultDelay() >> 16) + i2);
                int packedPositionChild = 23 - ExpandableListView.getPackedPositionChild(0L);
                byte b5 = (byte) 2;
                byte b6 = (byte) (b5 - 2);
                c = '4';
                c2 = 3;
                Object[] objArr8 = new Object[1];
                J(b5, b6, b6, objArr8);
                objD3 = an.d(iAxisFromString, scrollDefaultDelay, packedPositionChild, -621418755, false, (String) objArr8[0], null);
            } else {
                c = '4';
                c2 = 3;
            }
            Object[] objArr9 = (Object[]) ((Field) objD3).get(null);
            objArr2 = new Object[4];
            objArr2[1] = new int[]{i};
            objArr2[2] = new int[]{i};
            objArr2[c2] = new int[1];
            int i5 = ((int[]) objArr9[1])[0];
            int i6 = ((int[]) objArr9[2])[0];
            objArr2[0] = (String[]) objArr9[0];
            int iFreeMemory = (int) Runtime.getRuntime().freeMemory();
            int i7 = ~iFreeMemory;
            int i8 = (~((-461348231) | i7)) | 40179072;
            int i9 = ((((i8 | r3) * (-252)) - 1712988386) + (((~(iFreeMemory | 1006608286)) | (~(i7 | (-421169159)))) * EnumC41897g.SDK_ASSET_ILLUSTRATION_ROUTING_NUMBER_CONFIRMED_CIRCLE_VALUE)) - 2070357364;
            int i10 = (i9 << 13) ^ i9;
            int i11 = i10 ^ (i10 >>> 17);
            ((int[]) objArr2[c2])[0] = i11 ^ (i11 << 5);
            i3 = 2;
        } else {
            c = '4';
            c2 = 3;
            Object[] objArr10 = new Object[1];
            K((short) ((-123) - (SystemClock.elapsedRealtimeNanos() > 0L ? 1 : (SystemClock.elapsedRealtimeNanos() == 0L ? 0 : -1))), (-70) - (ViewConfiguration.getKeyRepeatDelay() >> 16), (byte) ((Process.getElapsedCpuTime() > 0L ? 1 : (Process.getElapsedCpuTime() == 0L ? 0 : -1)) - 117), TextUtils.lastIndexOf("", '0') - 979242672, TextUtils.lastIndexOf("", '0') - 416843782, objArr10);
            Class<?> cls2 = Class.forName((String) objArr10[0]);
            float f2 = f;
            Object[] objArr11 = new Object[1];
            K((short) (42 - View.resolveSize(0, 0)), (ViewConfiguration.getScrollFriction() > f ? 1 : (ViewConfiguration.getScrollFriction() == f ? 0 : -1)) - 71, (byte) (48 - Color.red(0)), (-979242674) - (PointF.length(f2, f2) > f2 ? 1 : (PointF.length(f2, f2) == f2 ? 0 : -1)), (-416843768) - (ViewConfiguration.getWindowTouchSlop() >> 8), objArr11);
            int iIntValue = ((Integer) cls2.getMethod((String) objArr11[0], Object.class).invoke(null, bdVar)).intValue();
            try {
                Object[] objArr12 = {2009534160};
                Object objD4 = an.d(1683332522);
                if (objD4 == null) {
                    objD4 = an.d(KeyEvent.normalizeMetaState(0) + 830, (char) (PointF.length(SelfieScan.RECOGNITION_FAIL_RESULT, SelfieScan.RECOGNITION_FAIL_RESULT) > SelfieScan.RECOGNITION_FAIL_RESULT ? 1 : (PointF.length(SelfieScan.RECOGNITION_FAIL_RESULT, SelfieScan.RECOGNITION_FAIL_RESULT) == SelfieScan.RECOGNITION_FAIL_RESULT ? 0 : -1)), TextUtils.indexOf("", "", 0, 0) + 24, 305417969, false, null, new Class[]{Integer.TYPE});
                }
                Object[] objArr13 = {Integer.valueOf(iIntValue), 0, -2070357364, ((Constructor) objD4).newInstance(objArr12), Boolean.FALSE};
                Object objD5 = an.d(1794077343);
                if (objD5 == null) {
                    int iMyPid = (Process.myPid() >> 22) + 711;
                    char cAxisFromString = (char) (MotionEvent.axisFromString("") + 49309);
                    int iMyTid = (Process.myTid() >> 22) + 24;
                    byte b7 = (byte) ($$b & 7);
                    byte b8 = (byte) (b7 - 1);
                    Object[] objArr14 = new Object[1];
                    J(b7, b8, b8, objArr14);
                    String str = (String) objArr14[0];
                    Class cls3 = Integer.TYPE;
                    objD5 = an.d(iMyPid, cAxisFromString, iMyTid, 479109572, false, str, new Class[]{cls3, cls3, cls3, (Class) an.b(View.MeasureSpec.getMode(0) + 799, (char) (PointF.length(SelfieScan.RECOGNITION_FAIL_RESULT, SelfieScan.RECOGNITION_FAIL_RESULT) > SelfieScan.RECOGNITION_FAIL_RESULT ? 1 : (PointF.length(SelfieScan.RECOGNITION_FAIL_RESULT, SelfieScan.RECOGNITION_FAIL_RESULT) == SelfieScan.RECOGNITION_FAIL_RESULT ? 0 : -1)), 31 - (ViewConfiguration.getKeyRepeatDelay() >> 16)), Boolean.TYPE});
                }
                objArr2 = (Object[]) ((Method) objD5).invoke(null, objArr13);
                Object objD6 = an.d(-1399573082);
                if (objD6 == null) {
                    int offsetAfter2 = 711 - TextUtils.getOffsetAfter("", 0);
                    char cAlpha = (char) (Color.alpha(0) + i2);
                    int iMyPid2 = 24 - (Process.myPid() >> 22);
                    byte b9 = (byte) 2;
                    byte b10 = (byte) (b9 - 2);
                    Object[] objArr15 = new Object[1];
                    J(b9, b10, b10, objArr15);
                    objD6 = an.d(offsetAfter2, cAlpha, iMyPid2, -621418755, false, (String) objArr15[0], null);
                }
                ((Field) objD6).set(null, objArr2);
                try {
                    Object[] objArr16 = new Object[1];
                    K((short) (TextUtils.lastIndexOf("", '0') - 73), (-64) - (ViewConfiguration.getScrollDefaultDelay() >> 16), (byte) ((-109) - ImageFormat.getBitsPerPixel(0)), (-979242682) - KeyEvent.getDeadChar(0, 0), Gravity.getAbsoluteGravity(0, 0) - 416843818, objArr16);
                    Class<?> cls4 = Class.forName((String) objArr16[0]);
                    Object[] objArr17 = new Object[1];
                    K((short) (TextUtils.lastIndexOf("", '0', 0, 0) + 15), (ViewConfiguration.getWindowTouchSlop() >> 8) - 71, (byte) ((-50) - ExpandableListView.getPackedPositionChild(0L)), (-979242679) - TextUtils.lastIndexOf("", '0'), (ViewConfiguration.getTapTimeout() >> 16) - 416843797, objArr17);
                    long jLongValue2 = ((Long) cls4.getDeclaredMethod((String) objArr17[0], null).invoke(null, null)).longValue();
                    Long lValueOf = Long.valueOf(jLongValue2);
                    Object objD7 = an.d(-1398649561);
                    if (objD7 == null) {
                        int iAlpha = Color.alpha(0) + 711;
                        char c4 = (char) (i2 - (ExpandableListView.getPackedPositionForGroup(0) > 0L ? 1 : (ExpandableListView.getPackedPositionForGroup(0) == 0L ? 0 : -1)));
                        int scrollBarSize = (ViewConfiguration.getScrollBarSize() >> 8) + 24;
                        byte b11 = (byte) ($$b & 7);
                        i3 = 2;
                        byte b12 = (byte) (b11 - 1);
                        Object[] objArr18 = new Object[1];
                        J(b11, b12, b12, objArr18);
                        objD7 = an.d(iAlpha, c4, scrollBarSize, -624714116, false, (String) objArr18[0], null);
                    } else {
                        i3 = 2;
                    }
                    ((Field) objD7).set(null, lValueOf);
                    Long lValueOf2 = Long.valueOf(jLongValue2 >> 12);
                    Object objD8 = an.d(i);
                    if (objD8 == null) {
                        int scrollBarFadeDuration = (ViewConfiguration.getScrollBarFadeDuration() >> 16) + 711;
                        char bitsPerPixel = (char) (ImageFormat.getBitsPerPixel(0) + 49309);
                        int i12 = 23 - (ExpandableListView.getPackedPositionForChild(0, 0) > 0L ? 1 : (ExpandableListView.getPackedPositionForChild(0, 0) == 0L ? 0 : -1));
                        byte b13 = (byte) 0;
                        byte b14 = b13;
                        Object[] objArr19 = new Object[1];
                        J(b13, b14, b14, objArr19);
                        objD8 = an.d(scrollBarFadeDuration, bitsPerPixel, i12, -623790093, false, (String) objArr19[0], null);
                    }
                    ((Field) objD8).set(null, lValueOf2);
                } catch (Exception unused) {
                    throw new RuntimeException();
                }
            } catch (Throwable th) {
                Throwable cause = th.getCause();
                if (cause != null) {
                    throw cause;
                }
                throw th;
            }
        }
        int i13 = ((int[]) objArr2[i3])[0];
        int i14 = ((int[]) objArr2[1])[0];
        if (i14 == i13) {
            H = (M + 75) % 128;
            Object[] objArr20 = new Object[4];
            objArr20[1] = new int[]{i};
            objArr20[i3] = new int[]{i};
            objArr20[c2] = new int[1];
            int i15 = ((int[]) objArr2[c2])[0];
            int i16 = ((int[]) objArr2[1])[0];
            int i17 = ((int[]) objArr2[i3])[0];
            objArr20[0] = (String[]) objArr2[0];
            int iNextInt = new Random().nextInt(506472452);
            int i18 = i15 + (-373926418) + (((~(839600008 | iNextInt)) | (-1046179743) | (~(207187350 | iNextInt))) * (-744)) + (((~iNextInt) | 607616) * 744) + ((iNextInt | 1046179742) * 744);
            int i19 = (i18 << 13) ^ i18;
            int i20 = i19 ^ (i19 >>> 17);
            ((int[]) objArr20[c2])[0] = i20 ^ (i20 << 5);
            H = (M + 125) % 128;
            Object objD9 = an.d(i);
            if (objD9 == null) {
                int iKeyCodeFromString = KeyEvent.keyCodeFromString("") + 711;
                char scrollBarFadeDuration2 = (char) (i2 - (ViewConfiguration.getScrollBarFadeDuration() >> 16));
                int iIndexOf2 = TextUtils.indexOf((CharSequence) "", '0') + 25;
                byte b15 = (byte) 0;
                byte b16 = b15;
                Object[] objArr21 = new Object[1];
                J(b15, b16, b16, objArr21);
                objD9 = an.d(iKeyCodeFromString, scrollBarFadeDuration2, iIndexOf2, -623790093, false, (String) objArr21[0], null);
            }
            long j2 = ((Field) objD9).getLong(null);
            Object[] objArr22 = new Object[1];
            K((short) ((-73) - (ViewConfiguration.getScrollFriction() > SelfieScan.RECOGNITION_FAIL_RESULT ? 1 : (ViewConfiguration.getScrollFriction() == SelfieScan.RECOGNITION_FAIL_RESULT ? 0 : -1))), (-64) - (ViewConfiguration.getKeyRepeatTimeout() >> 16), (byte) (Color.argb(0, 0, 0, 0) - 108), Color.green(0) - 979242682, (-416843818) - (Process.myPid() >> 22), objArr22);
            Class<?> cls5 = Class.forName((String) objArr22[0]);
            Object[] objArr23 = new Object[1];
            K((short) (View.MeasureSpec.getSize(0) + 14), (-71) - (ViewConfiguration.getJumpTapTimeout() >> 16), (byte) ((ExpandableListView.getPackedPositionForChild(0, 0) > 0L ? 1 : (ExpandableListView.getPackedPositionForChild(0, 0) == 0L ? 0 : -1)) - 48), (-979242679) - ImageFormat.getBitsPerPixel(0), (-416843797) - (CdmaCellLocation.convertQuartSecToDecDegrees(0) > 0.0d ? 1 : (CdmaCellLocation.convertQuartSecToDecDegrees(0) == 0.0d ? 0 : -1)), objArr23);
            long jLongValue3 = ((Long) cls5.getDeclaredMethod((String) objArr23[0], null).invoke(null, null)).longValue();
            Object objD10 = an.d(-1398649561);
            if (objD10 == null) {
                int packedPositionType = 711 - ExpandableListView.getPackedPositionType(0L);
                char cRgb = (char) ((-16727908) - Color.rgb(0, 0, 0));
                int i21 = 24 - (ExpandableListView.getPackedPositionForGroup(0) > 0L ? 1 : (ExpandableListView.getPackedPositionForGroup(0) == 0L ? 0 : -1));
                byte b17 = (byte) ($$b & 7);
                byte b18 = (byte) (b17 - 1);
                Object[] objArr24 = new Object[1];
                J(b17, b18, b18, objArr24);
                objD10 = an.d(packedPositionType, cRgb, i21, -624714116, false, (String) objArr24[0], null);
            }
            if (j2 == ((jLongValue3 - ((((Field) objD10).getLong(null) << c) >>> c)) >> 12)) {
                Object objD11 = an.d(-1399573082);
                if (objD11 == null) {
                    int touchSlop = 711 - (ViewConfiguration.getTouchSlop() >> 8);
                    char c5 = (char) (i2 - (TypedValue.complexToFloat(0) > SelfieScan.RECOGNITION_FAIL_RESULT ? 1 : (TypedValue.complexToFloat(0) == SelfieScan.RECOGNITION_FAIL_RESULT ? 0 : -1)));
                    int i22 = (TypedValue.complexToFloat(0) > SelfieScan.RECOGNITION_FAIL_RESULT ? 1 : (TypedValue.complexToFloat(0) == SelfieScan.RECOGNITION_FAIL_RESULT ? 0 : -1)) + 24;
                    byte b19 = (byte) i3;
                    byte b20 = (byte) (b19 - 2);
                    Object[] objArr25 = new Object[1];
                    J(b19, b20, b20, objArr25);
                    objD11 = an.d(touchSlop, c5, i22, -621418755, false, (String) objArr25[0], null);
                }
                Object[] objArr26 = (Object[]) ((Field) objD11).get(null);
                objArr3 = new Object[4];
                objArr3[1] = new int[]{i};
                objArr3[2] = new int[]{i};
                objArr3[c2] = new int[1];
                int i23 = ((int[]) objArr26[1])[0];
                int i24 = ((int[]) objArr26[2])[0];
                objArr3[0] = (String[]) objArr26[0];
                int iMyUid = Process.myUid();
                int i25 = 252464536 + (((-621842569) | iMyUid) * (-627)) + (((~((-414131030) | iMyUid)) | 632656329) * (-627)) + (((~(iMyUid | 632656329)) | (~((~iMyUid) | 414131029))) * 627) + 1161717415;
                int i26 = (i25 << 13) ^ i25;
                int i27 = i26 ^ (i26 >>> 17);
                ((int[]) objArr3[c2])[0] = i27 ^ (i27 << 5);
            } else {
                Object[] objArr27 = new Object[1];
                K((short) ((Process.myPid() >> 22) - 124), (-70) - Drawable.resolveOpacity(0, 0), (byte) ((AudioTrack.getMinVolume() > SelfieScan.RECOGNITION_FAIL_RESULT ? 1 : (AudioTrack.getMinVolume() == SelfieScan.RECOGNITION_FAIL_RESULT ? 0 : -1)) - 116), (-979242673) - TextUtils.indexOf("", "", 0, 0), (-433620999) - Color.rgb(0, 0, 0), objArr27);
                Class<?> cls6 = Class.forName((String) objArr27[0]);
                Object[] objArr28 = new Object[1];
                K((short) ((ViewConfiguration.getZoomControlsTimeout() > 0L ? 1 : (ViewConfiguration.getZoomControlsTimeout() == 0L ? 0 : -1)) + 41), (TypedValue.complexToFloat(0) > SelfieScan.RECOGNITION_FAIL_RESULT ? 1 : (TypedValue.complexToFloat(0) == SelfieScan.RECOGNITION_FAIL_RESULT ? 0 : -1)) - 70, (byte) (TextUtils.lastIndexOf("", '0', 0, 0) + 49), (ViewConfiguration.getFadingEdgeLength() >> 16) - 979242674, Gravity.getAbsoluteGravity(0, 0) - 416843768, objArr28);
                int iIntValue2 = ((Integer) cls6.getMethod((String) objArr28[0], Object.class).invoke(null, bdVar)).intValue();
                Object[] objArr29 = {-3337713};
                Object objD12 = an.d(1683332522);
                if (objD12 == null) {
                    objD12 = an.d(View.MeasureSpec.getMode(0) + 830, (char) (1 - (SystemClock.elapsedRealtime() > 0L ? 1 : (SystemClock.elapsedRealtime() == 0L ? 0 : -1))), (ViewConfiguration.getLongPressTimeout() >> 16) + 24, 305417969, false, null, new Class[]{Integer.TYPE});
                }
                Object objNewInstance = ((Constructor) objD12).newInstance(objArr29);
                Object[] objArr30 = new Object[5];
                objArr30[4] = Boolean.FALSE;
                objArr30[c2] = objNewInstance;
                objArr30[2] = 1161717415;
                objArr30[1] = 0;
                objArr30[0] = Integer.valueOf(iIntValue2);
                Object objD13 = an.d(1794077343);
                if (objD13 == null) {
                    int mode = View.MeasureSpec.getMode(0) + 711;
                    char mode2 = (char) (i2 - View.MeasureSpec.getMode(0));
                    int iGreen = 24 - Color.green(0);
                    byte b21 = (byte) ($$b & 7);
                    byte b22 = (byte) (b21 - 1);
                    Object[] objArr31 = new Object[1];
                    J(b21, b22, b22, objArr31);
                    String str2 = (String) objArr31[0];
                    Class cls7 = Integer.TYPE;
                    objD13 = an.d(mode, mode2, iGreen, 479109572, false, str2, new Class[]{cls7, cls7, cls7, (Class) an.b((ViewConfiguration.getScrollBarSize() >> 8) + 799, (char) (1 - (ViewConfiguration.getGlobalActionKeyTimeout() > 0L ? 1 : (ViewConfiguration.getGlobalActionKeyTimeout() == 0L ? 0 : -1))), (KeyEvent.getMaxKeyCode() >> 16) + 31), Boolean.TYPE});
                }
                objArr3 = (Object[]) ((Method) objD13).invoke(null, objArr30);
                Object objD14 = an.d(-1399573082);
                if (objD14 == null) {
                    int i28 = (SystemClock.currentThreadTimeMillis() > (-1L) ? 1 : (SystemClock.currentThreadTimeMillis() == (-1L) ? 0 : -1)) + 710;
                    char cIndexOf = (char) (49307 - TextUtils.indexOf((CharSequence) "", '0', 0));
                    int windowTouchSlop = (ViewConfiguration.getWindowTouchSlop() >> 8) + 24;
                    byte b23 = (byte) 2;
                    byte b24 = (byte) (b23 - 2);
                    Object[] objArr32 = new Object[1];
                    J(b23, b24, b24, objArr32);
                    objD14 = an.d(i28, cIndexOf, windowTouchSlop, -621418755, false, (String) objArr32[0], null);
                }
                ((Field) objD14).set(null, objArr3);
                try {
                    Object[] objArr33 = new Object[1];
                    K((short) ((-74) - TextUtils.getCapsMode("", 0, 0)), Color.rgb(0, 0, 0) + 16777152, (byte) (TextUtils.lastIndexOf("", '0', 0, 0) - 107), (CdmaCellLocation.convertQuartSecToDecDegrees(0) > 0.0d ? 1 : (CdmaCellLocation.convertQuartSecToDecDegrees(0) == 0.0d ? 0 : -1)) - 979242682, (ViewConfiguration.getKeyRepeatDelay() >> 16) - 416843818, objArr33);
                    Class<?> cls8 = Class.forName((String) objArr33[0]);
                    Object[] objArr34 = new Object[1];
                    K((short) (14 - TextUtils.getCapsMode("", 0, 0)), (-71) - (ViewConfiguration.getWindowTouchSlop() >> 8), (byte) ((-49) - TextUtils.getOffsetAfter("", 0)), (-979242678) - TextUtils.getOffsetAfter("", 0), ExpandableListView.getPackedPositionGroup(0L) - 416843797, objArr34);
                    long jLongValue4 = ((Long) cls8.getDeclaredMethod((String) objArr34[0], null).invoke(null, null)).longValue();
                    Long lValueOf3 = Long.valueOf(jLongValue4);
                    Object objD15 = an.d(-1398649561);
                    if (objD15 == null) {
                        int i29 = 712 - (SystemClock.uptimeMillis() > 0L ? 1 : (SystemClock.uptimeMillis() == 0L ? 0 : -1));
                        char packedPositionChild2 = (char) (ExpandableListView.getPackedPositionChild(0L) + 49309);
                        int iNormalizeMetaState = 24 - KeyEvent.normalizeMetaState(0);
                        byte b25 = (byte) ($$b & 7);
                        byte b26 = (byte) (b25 - 1);
                        Object[] objArr35 = new Object[1];
                        J(b25, b26, b26, objArr35);
                        objD15 = an.d(i29, packedPositionChild2, iNormalizeMetaState, -624714116, false, (String) objArr35[0], null);
                    }
                    ((Field) objD15).set(null, lValueOf3);
                    Long lValueOf4 = Long.valueOf(jLongValue4 >> 12);
                    Object objD16 = an.d(i);
                    if (objD16 == null) {
                        int jumpTapTimeout = 711 - (ViewConfiguration.getJumpTapTimeout() >> 16);
                        char scrollBarFadeDuration3 = (char) (i2 - (ViewConfiguration.getScrollBarFadeDuration() >> 16));
                        int modifierMetaStateMask = ((byte) KeyEvent.getModifierMetaStateMask()) + 25;
                        byte b27 = (byte) 0;
                        byte b28 = b27;
                        Object[] objArr36 = new Object[1];
                        J(b27, b28, b28, objArr36);
                        objD16 = an.d(jumpTapTimeout, scrollBarFadeDuration3, modifierMetaStateMask, -623790093, false, (String) objArr36[0], null);
                    }
                    ((Field) objD16).set(null, lValueOf4);
                } catch (Exception unused2) {
                    throw new RuntimeException();
                }
            }
            if (((int[]) objArr3[1])[0] == ((int[]) objArr3[2])[0]) {
                M = (H + 19) % 128;
                Object[] objArr37 = new Object[4];
                objArr37[1] = new int[]{i};
                objArr37[2] = new int[]{i};
                objArr37[c2] = new int[1];
                int i30 = ((int[]) objArr3[c2])[0];
                int i31 = ((int[]) objArr3[1])[0];
                int i32 = ((int[]) objArr3[2])[0];
                objArr37[0] = (String[]) objArr3[0];
                int i33 = ~Process.myUid();
                int i34 = i30 + (-1704760658) + ((~(1046474653 | i33)) * 52) + (((~(1045424021 | i33)) | (~((-1363338) | i33)) | 1050632) * (-52)) + (((~(i33 | (-1045424022))) | 1045111316) * 52);
                int i35 = (i34 << 13) ^ i34;
                int i36 = i35 ^ (i35 >>> 17);
                ((int[]) objArr37[c2])[0] = i36 ^ (i36 << 5);
                int i37 = H + 51;
                M = i37 % 128;
                if (i37 % 2 == 0) {
                    int i38 = 58 / 0;
                }
                return null;
            }
            ArrayList arrayList = new ArrayList();
            String[] strArr = (String[]) objArr3[0];
            if (strArr != null) {
                while (i4 < strArr.length) {
                    arrayList.add(strArr[i4]);
                    i4++;
                }
                throw null;
            }
            throw null;
        }
        ArrayList arrayList2 = new ArrayList();
        String[] strArr2 = (String[]) objArr2[0];
        if (strArr2 != null) {
            M = (H + 29) % 128;
            while (i4 < strArr2.length) {
                int i39 = M + 101;
                H = i39 % 128;
                if (i39 % 2 != 0) {
                    arrayList2.add(strArr2[i4]);
                    i4 += 112;
                } else {
                    arrayList2.add(strArr2[i4]);
                    i4++;
                }
            }
        }
        throw new RuntimeException(String.valueOf(i14));
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void e(da daVar, cw cwVar, cs csVar, ct ctVar) throws Throwable {
        if (daVar == da.TIMEOUT_GO_TO_RETRY) {
            cp cpVarF = f();
            if (cpVarF != null) {
                int i = H + 27;
                M = i % 128;
                if (i % 2 == 0) {
                    cpVarF.i();
                    cpVarF.b(this.D);
                    int i2 = 70 / 0;
                } else {
                    cpVarF.i();
                    cpVarF.b(this.D);
                }
            }
            bm bmVarJ = j();
            if (bmVarJ != null) {
                int i3 = H + 1;
                M = i3 % 128;
                if (i3 % 2 != 0) {
                    bmVarJ.i();
                    return;
                } else {
                    bmVarJ.i();
                    throw null;
                }
            }
            return;
        }
        if (this.m && daVar != da.DETECTING_LIGHT_MODE) {
            M = (H + 107) % 128;
            if (daVar == da.DETECTING_FACE_FEEDBACK) {
                int i4 = M + 97;
                H = i4 % 128;
                if (i4 % 2 != 0) {
                    int i5 = 72 / 0;
                    if (!b()) {
                        return;
                    }
                } else if (!b()) {
                    return;
                }
                if (this.f95827g) {
                    return;
                }
                M = (H + 69) % 128;
                this.d = csVar;
                b(csVar);
                return;
            }
            cp cpVarF2 = f();
            if (cpVarF2 != null) {
                cpVarF2.i();
                cpVarF2.b(this.D);
            }
            a((Context) j());
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ boolean d(View view, MotionEvent motionEvent) {
        if (motionEvent.getAction() == 0) {
            this.c.setAlpha(0.4f);
            H = (M + 125) % 128;
        } else if (motionEvent.getAction() != 3 && motionEvent.getX() >= SelfieScan.RECOGNITION_FAIL_RESULT && motionEvent.getX() <= this.c.getWidth() + this.c.getLeft() + 10 && motionEvent.getY() >= SelfieScan.RECOGNITION_FAIL_RESULT && motionEvent.getY() <= this.c.getHeight() + this.c.getTop() + 10) {
            if (motionEvent.getAction() == 1) {
                H = (M + 7) % 128;
                this.c.setAlpha(1.0f);
                this.c.setEnabled(false);
                if (j() == null) {
                    int i = M + 109;
                    int i2 = i % 128;
                    H = i2;
                    boolean z = i % 2 != 0;
                    M = (i2 + 61) % 128;
                    return z;
                }
                this.c.performClick();
            }
        } else {
            this.c.setAlpha(1.0f);
        }
        return true;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static /* synthetic */ void c(bm bmVar) {
        H = (M + 21) % 128;
        bmVar.h();
        int i = M + 15;
        H = i % 128;
        if (i % 2 != 0) {
            throw null;
        }
    }

    private static /* synthetic */ Object c(Object[] objArr) {
        Semaphore semaphore;
        bd bdVar = (bd) objArr[0];
        if (bdVar.b() && (semaphore = bdVar.v) != null) {
            try {
                if (semaphore.tryAcquire(2000L, TimeUnit.MILLISECONDS)) {
                    M = (H + 67) % 128;
                    bdVar.v.release();
                }
                int i = H + 11;
                M = i % 128;
                if (i % 2 != 0) {
                    return null;
                }
                throw null;
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
        return null;
    }

    public static /* synthetic */ void b(bd bdVar) {
        M = (H + 113) % 128;
        int iE = gn.AnonymousClass24.e();
        int iE2 = gn.AnonymousClass24.e();
        int iE3 = gn.AnonymousClass24.e();
        b(gn.AnonymousClass24.e(), iE2, iE3, -1749308899, new Object[]{bdVar}, iE, 1749308906);
        int i = H + 21;
        M = i % 128;
        if (i % 2 == 0) {
            throw null;
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void b(Context context, bi biVar) {
        H = (M + 1) % 128;
        cp cpVarF = f();
        if (cpVarF == null || cpVarF.d(context, biVar.j)) {
            return;
        }
        H = (M + EnumC41897g.SDK_ASSET_ILLUSTRATION_CALENDAR_VALUE) % 128;
        bm bmVarJ = j();
        if (bmVarJ != null) {
            bmVarJ.d(ao.s);
        }
    }

    public static /* synthetic */ void c(final bd bdVar, cu cuVar, cm cmVar) throws Throwable {
        bm bmVarJ = bdVar.j();
        if (!bdVar.b() || bmVarJ == null) {
            H = (M + 49) % 128;
            return;
        }
        if (bdVar.h.h() && cmVar == cm.HOLD_STEADY) {
            int i = M + 85;
            H = i % 128;
            if (i % 2 == 0) {
                if (!bdVar.w) {
                    bdVar.b.animate().alpha(1.0f).setDuration(500L).setStartDelay(0L).setListener(null).start();
                    bdVar.w = true;
                }
            } else {
                throw null;
            }
        }
        if (!bdVar.s && cmVar != cm.FACE_NOT_FOUND) {
            bdVar.s = true;
            if (!bdVar.r) {
                H = (M + 17) % 128;
                bdVar.r = true;
                ce.b(bmVarJ);
            }
            bmVarJ.j();
        }
        if (!(!bdVar.b()) && !bdVar.f95827g) {
            H = (M + 33) % 128;
            cu cuVar2 = bdVar.q;
            if (cuVar2 != cuVar) {
                if (cuVar2 != null) {
                    bdVar.h();
                }
                bdVar.q = cuVar;
                bdVar.u = false;
            }
            if (cuVar == cu.ZOOM_CLOSE) {
                t.d = ao.k;
                if (!bdVar.h.h()) {
                    dj.a(new Runnable() { // from class: com.facetec.sdk.鬼
                        @Override // java.lang.Runnable
                        public final void run() {
                            this.f7301.o();
                        }
                    });
                    de deVar = bdVar.h;
                    deVar.setOvalHasExpanded(true);
                    deVar.a(deVar.n);
                    if (ed.b()) {
                        ed.a(bdVar.j(), bdVar.getString(R.string.FaceTec_accessibility_feedback_move_phone_closer));
                    }
                    if (FaceTecSDK.d.vocalGuidanceCustomization.mode == FaceTecVocalGuidanceCustomization.VocalGuidanceMode.FULL_VOCAL_GUIDANCE) {
                        ed.d(bdVar.j(), ed.d.FACE_CAPTURE_MOVE_CLOSER_AUTOMATIC);
                        Handler handler = new Handler();
                        bdVar.x = handler;
                        handler.postDelayed(bdVar.C, 4500L);
                    }
                    if (FaceTecSDK.d.l.enablePulsatingText) {
                        Handler handler2 = new Handler();
                        bdVar.o = handler2;
                        handler2.postDelayed(new au.c(new Runnable() { // from class: com.facetec.sdk.梦
                            @Override // java.lang.Runnable
                            public final void run() {
                                this.f7277.k();
                            }
                        }), 3000L);
                    }
                    t.b(dh.FACE_SCAN_ZOOMED);
                }
            }
            bdVar.b(cuVar, cmVar);
        }
        M = (H + 97) % 128;
    }

    private static /* synthetic */ Object d(Object[] objArr) {
        bd bdVar = (bd) objArr[0];
        int i = M + 33;
        H = i % 128;
        if (i % 2 == 0) {
            super.onDestroy();
            int iE = gn.AnonymousClass24.e();
            int iE2 = gn.AnonymousClass24.e();
            int iE3 = gn.AnonymousClass24.e();
            b(gn.AnonymousClass24.e(), iE2, iE3, -1749308899, new Object[]{bdVar}, iE, 1749308906);
            M = (H + 99) % 128;
            return null;
        }
        super.onDestroy();
        int iE4 = gn.AnonymousClass24.e();
        int iE5 = gn.AnonymousClass24.e();
        int iE6 = gn.AnonymousClass24.e();
        b(gn.AnonymousClass24.e(), iE5, iE6, -1749308899, new Object[]{bdVar}, iE4, 1749308906);
        throw null;
    }

    private static /* synthetic */ Object b(Object[] objArr) {
        bd bdVar = (bd) objArr[0];
        int i = M + 111;
        H = i % 128;
        if (i % 2 == 0) {
            super.onPause();
            Handler handler = bdVar.l;
            if (handler != null) {
                handler.removeCallbacksAndMessages(null);
            }
            Handler handler2 = bdVar.n;
            if (handler2 != null) {
                M = (H + 117) % 128;
                handler2.removeCallbacksAndMessages(null);
            }
            Handler handler3 = bdVar.o;
            if (handler3 != null) {
                handler3.removeCallbacksAndMessages(null);
            }
            cy cyVar = bdVar.f;
            if (cyVar != null) {
                int i2 = H + 65;
                int i3 = i2 % 128;
                M = i3;
                if (i2 % 2 != 0) {
                    Handler handler4 = cyVar.f95862g;
                    if (handler4 != null) {
                        int i4 = i3 + 103;
                        H = i4 % 128;
                        if (i4 % 2 != 0) {
                            handler4.removeCallbacksAndMessages(null);
                            cyVar.f95862g = null;
                            int i5 = 18 / 0;
                        } else {
                            handler4.removeCallbacksAndMessages(null);
                            cyVar.f95862g = null;
                        }
                        M = (H + 95) % 128;
                    }
                } else {
                    Handler handler5 = cyVar.f95862g;
                    throw null;
                }
            }
            Handler handler6 = bdVar.x;
            if (handler6 != null) {
                int i6 = M + 75;
                H = i6 % 128;
                if (i6 % 2 != 0) {
                    handler6.removeCallbacksAndMessages(null);
                    bdVar.x = null;
                    int i7 = 81 / 0;
                } else {
                    handler6.removeCallbacksAndMessages(null);
                    bdVar.x = null;
                }
            }
            int i8 = M + 91;
            H = i8 % 128;
            if (i8 % 2 != 0) {
                int i9 = 5 / 0;
            }
            return null;
        }
        super.onPause();
        throw null;
    }

    private void d(Runnable runnable, boolean z) {
        h();
        int i = !z ? EnumC41897g.SDK_ASSET_TRANSFER_ICON_CIRCLE_VALUE : 400;
        de deVar = this.h;
        AnimatorSet animatorSet = deVar.n;
        if (animatorSet != null) {
            animatorSet.cancel();
        }
        AnimatorSet animatorSet2 = deVar.j;
        if (animatorSet2 != null) {
            int i2 = H + 73;
            M = i2 % 128;
            if (i2 % 2 == 0) {
                animatorSet2.cancel();
                int i3 = 61 / 0;
            } else {
                animatorSet2.cancel();
            }
        }
        AnimatorSet animatorSet3 = deVar.l;
        if (animatorSet3 != null) {
            animatorSet3.cancel();
            H = (M + 9) % 128;
        }
        this.h.a(new au.c(new Runnable() { // from class: com.facetec.sdk.道
            @Override // java.lang.Runnable
            public final void run() {
                this.f7297.n();
            }
        }), z);
        try {
            this.v.acquire();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        this.c.setVisibility(4);
        this.j.setVisibility(4);
        dm.j(this.k);
        this.k.animate().alpha(1.0f).setDuration(i + 100).setStartDelay(0L).setListener(null).start();
        AnimatorSet duration = new AnimatorSet().setDuration(i);
        LinearLayout linearLayout = this.e;
        Property property = View.ALPHA;
        duration.playTogether(ObjectAnimator.ofFloat(linearLayout, (Property<LinearLayout, Float>) property, SelfieScan.RECOGNITION_FAIL_RESULT), ObjectAnimator.ofFloat(this.f, (Property<cy, Float>) property, SelfieScan.RECOGNITION_FAIL_RESULT), ObjectAnimator.ofFloat(this.c, (Property<ImageView, Float>) property, SelfieScan.RECOGNITION_FAIL_RESULT), ObjectAnimator.ofFloat(this.f, (Property<cy, Float>) View.TRANSLATION_Y, (-r7.getHeight()) / 2));
        duration.start();
        runnable.run();
    }

    private void e() {
        int iE = gn.AnonymousClass24.e();
        int iE2 = gn.AnonymousClass24.e();
        int iE3 = gn.AnonymousClass24.e();
        b(gn.AnonymousClass24.e(), iE2, iE3, -1749308899, new Object[]{this}, iE, 1749308906);
    }

    public static /* synthetic */ boolean e(bd bdVar) {
        int iE = gn.AnonymousClass24.e();
        int iE2 = gn.AnonymousClass24.e();
        int iE3 = gn.AnonymousClass24.e();
        return ((Boolean) b(gn.AnonymousClass24.e(), iE2, iE3, 516772891, new Object[]{bdVar}, iE, -516772883)).booleanValue();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static /* synthetic */ void b(bm bmVar) {
        H = (M + 83) % 128;
        bmVar.a();
        int i = H + 37;
        M = i % 128;
        if (i % 2 == 0) {
            int i2 = 31 / 0;
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static /* synthetic */ void d(bm bmVar) {
        int iE = gn.AnonymousClass24.e();
        int iE2 = gn.AnonymousClass24.e();
        int iE3 = gn.AnonymousClass24.e();
        b(gn.AnonymousClass24.e(), iE2, iE3, 1219397518, new Object[]{bmVar}, iE, -1219397518);
    }

    private synchronized void b(cu cuVar, cm cmVar) {
        try {
            H = (M + 83) % 128;
            if (cuVar == cu.ZOOM_FAR) {
                H = (M + 69) % 128;
                g();
            }
            if (cmVar == cm.HOLD_STEADY) {
                this.h.c();
                this.u = true;
            }
            cy cyVar = this.f;
            if (cmVar != cyVar.a && !cyVar.f) {
                cyVar.a = cmVar;
                cyVar.e(cy.c(cmVar));
            }
        } finally {
        }
    }

    public final void c() {
        int iE = gn.AnonymousClass24.e();
        int iE2 = gn.AnonymousClass24.e();
        int iE3 = gn.AnonymousClass24.e();
        b(gn.AnonymousClass24.e(), iE2, iE3, -1809926626, new Object[]{this}, iE, 1809926632);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void a(bm bmVar) {
        int iE = gn.AnonymousClass24.e();
        int iE2 = gn.AnonymousClass24.e();
        int iE3 = gn.AnonymousClass24.e();
        b(gn.AnonymousClass24.e(), iE2, iE3, 1085354640, new Object[]{this, bmVar}, iE, -1085354635);
    }

    /* JADX WARN: Removed duplicated region for block: B:16:0x0028 A[Catch: all -> 0x001d, PHI: r0
      0x0028: PHI (r0v4 com.facetec.sdk.cy) = (r0v3 com.facetec.sdk.cy), (r0v6 com.facetec.sdk.cy) binds: [B:15:0x0026, B:8:0x0018] A[DONT_GENERATE, DONT_INLINE], TryCatch #1 {all -> 0x001d, blocks: (B:3:0x0001, B:5:0x000e, B:16:0x0028, B:18:0x0034, B:21:0x0039, B:23:0x0043, B:25:0x004f, B:32:0x005b, B:30:0x0057, B:33:0x0069, B:11:0x001c, B:14:0x001f, B:7:0x0017, B:27:0x0053, B:37:0x0074), top: B:43:0x0001 }] */
    /* JADX WARN: Removed duplicated region for block: B:32:0x005b A[Catch: all -> 0x001d, TryCatch #1 {all -> 0x001d, blocks: (B:3:0x0001, B:5:0x000e, B:16:0x0028, B:18:0x0034, B:21:0x0039, B:23:0x0043, B:25:0x004f, B:32:0x005b, B:30:0x0057, B:33:0x0069, B:11:0x001c, B:14:0x001f, B:7:0x0017, B:27:0x0053, B:37:0x0074), top: B:43:0x0001 }] */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    private synchronized void b(com.facetec.sdk.cs r5) {
        /*
            r4 = this;
            monitor-enter(r4)
            int r0 = com.facetec.sdk.bd.M     // Catch: java.lang.Throwable -> L1d
            int r0 = r0 + 71
            int r1 = r0 % 128
            com.facetec.sdk.bd.H = r1     // Catch: java.lang.Throwable -> L1d
            int r0 = r0 % 2
            r1 = 0
            if (r0 == 0) goto L1f
            r4.g()     // Catch: java.lang.Throwable -> L1d
            com.facetec.sdk.cy r0 = r4.f     // Catch: java.lang.Throwable -> L1d
            com.facetec.sdk.cs r2 = r0.d     // Catch: java.lang.Throwable -> L1d
            r3 = 55
            int r3 = r3 / r1
            if (r5 == r2) goto L75
            goto L28
        L1b:
            r5 = move-exception
            throw r5     // Catch: java.lang.Throwable -> L1d
        L1d:
            r5 = move-exception
            goto L77
        L1f:
            r4.g()     // Catch: java.lang.Throwable -> L1d
            com.facetec.sdk.cy r0 = r4.f     // Catch: java.lang.Throwable -> L1d
            com.facetec.sdk.cs r2 = r0.d     // Catch: java.lang.Throwable -> L1d
            if (r5 == r2) goto L75
        L28:
            int r2 = com.facetec.sdk.bd.M     // Catch: java.lang.Throwable -> L1d
            int r2 = r2 + 91
            int r3 = r2 % 128
            com.facetec.sdk.bd.H = r3     // Catch: java.lang.Throwable -> L1d
            int r2 = r2 % 2
            if (r2 != 0) goto L73
            boolean r2 = r0.f     // Catch: java.lang.Throwable -> L1d
            if (r2 == 0) goto L39
            goto L75
        L39:
            r0.d = r5     // Catch: java.lang.Throwable -> L1d
            int r5 = com.facetec.sdk.cy.a(r5)     // Catch: java.lang.Throwable -> L1d
            boolean r2 = r0.f     // Catch: java.lang.Throwable -> L1d
            if (r2 != 0) goto L69
            int r2 = com.facetec.sdk.bd.H     // Catch: java.lang.Throwable -> L1d
            int r2 = r2 + 15
            int r3 = r2 % 128
            com.facetec.sdk.bd.M = r3     // Catch: java.lang.Throwable -> L1d
            int r2 = r2 % 2
            if (r2 != 0) goto L57
            int r2 = r0.c     // Catch: java.lang.Throwable -> L1d
            r3 = 9
            int r3 = r3 / r1
            if (r5 == r2) goto L69
            goto L5b
        L57:
            int r2 = r0.c     // Catch: java.lang.Throwable -> L1d
            if (r5 == r2) goto L69
        L5b:
            r0.c = r5     // Catch: java.lang.Throwable -> L1d
            r0.f = r1     // Catch: java.lang.Throwable -> L1d
            com.facetec.sdk.ed.b(r5)     // Catch: java.lang.Throwable -> L1d
            android.widget.TextView r5 = r0.e     // Catch: java.lang.Throwable -> L1d
            int r0 = r0.c     // Catch: java.lang.Throwable -> L1d
            com.facetec.sdk.dp.e(r5, r0)     // Catch: java.lang.Throwable -> L1d
        L69:
            int r5 = com.facetec.sdk.bd.H     // Catch: java.lang.Throwable -> L1d
            int r5 = r5 + 5
            int r5 = r5 % 128
            com.facetec.sdk.bd.M = r5     // Catch: java.lang.Throwable -> L1d
            monitor-exit(r4)
            return
        L73:
            r5 = 0
            throw r5     // Catch: java.lang.Throwable -> L1b
        L75:
            monitor-exit(r4)
            return
        L77:
            monitor-exit(r4)     // Catch: java.lang.Throwable -> L1d
            throw r5
        */
        throw new UnsupportedOperationException("Method not decompiled: com.facetec.sdk.bd.b(com.facetec.sdk.cs):void");
    }

    public static void a() {
        B = 504307785;
        E = 114796597;
        F = 1015654264;
        I = new byte[]{ISOFileInfo.PROP_INFO, -55, -126, ISOFileInfo.FMD_BYTE, -17, ISOFileInfo.PROP_INFO, -52, PSSSigner.TRAILER_IMPLICIT, -37, -97, -104, 26, -71, 124, -53, ISO7816.INS_PUT_DATA, -37, ISO7816.INS_WRITE_BINARY, ISOFileInfo.FCI_EXT, -49, ISOFileInfo.DATA_BYTES1, 74, -34, 79, ISO7816.INS_PUT_DATA, -43, 70, -83, ISO7816.INS_MANAGE_CHANNEL, 65, 76, -35, -47, 79, -39, 99, -102, 106, -111, 69, 70, -92, -110, -98, -106, 77, -34, ISOFileInfo.DATA_BYTES1, 118, -108, ISOFileInfo.FMD_BYTE, -8, -111, -94, -8, -101, -100, ISO7816.INS_READ_RECORD_STAMPED, 104, 114, -8, ISOFileInfo.FCI_BYTE, 108, ISOFileInfo.FMD_BYTE, ISO7816.INS_ENVELOPE, 99, 99, 99, 99};
    }
}