package com.facetec.sdk;

import android.animation.ValueAnimator;
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.drawable.Drawable;
import android.util.AttributeSet;
import android.view.animation.DecelerateInterpolator;
import com.incode.welcome_sdk.modules.SelfieScan;

/* JADX INFO: loaded from: classes4.dex */
class be extends de {
    Paint e;
    private Drawable k;
    private final Context m;
    private final Matrix o;
    private float p;
    private boolean q;
    private float r;
    private final float[] s;
    private int t;
    private int u;

    public be(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        this.o = new Matrix();
        this.s = new float[9];
        this.p = SelfieScan.RECOGNITION_FAIL_RESULT;
        this.r = SelfieScan.RECOGNITION_FAIL_RESULT;
        this.q = false;
        this.t = -1;
        this.u = -1;
        this.m = context;
        post(new Runnable() { // from class: com.facetec.sdk.丹兵
            @Override // java.lang.Runnable
            public final void run() {
                this.f6730.m();
            }
        });
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void a(int i, int i2) {
        ValueAnimator valueAnimatorOfInt = ValueAnimator.ofInt(255, i);
        valueAnimatorOfInt.setDuration(i2);
        valueAnimatorOfInt.addUpdateListener(new ValueAnimator.AnimatorUpdateListener() { // from class: com.facetec.sdk.丹丹
            @Override // android.animation.ValueAnimator.AnimatorUpdateListener
            public final void onAnimationUpdate(ValueAnimator valueAnimator) {
                this.f6724.d(valueAnimator);
            }
        });
        valueAnimatorOfInt.start();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void c(ValueAnimator valueAnimator) {
        Paint paint = this.d;
        if (paint == null) {
            return;
        }
        paint.setAlpha(((Integer) valueAnimator.getAnimatedValue()).intValue());
        postInvalidateOnAnimation();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void d(ValueAnimator valueAnimator) {
        Drawable drawable = this.k;
        if (drawable == null) {
            return;
        }
        drawable.setAlpha(((Integer) valueAnimator.getAnimatedValue()).intValue());
        postInvalidateOnAnimation();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void e(ValueAnimator valueAnimator) {
        this.u = ((Integer) valueAnimator.getAnimatedValue()).intValue();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void i() {
        ValueAnimator valueAnimatorOfFloat = ValueAnimator.ofFloat(this.p, SelfieScan.RECOGNITION_FAIL_RESULT);
        valueAnimatorOfFloat.setInterpolator(new DecelerateInterpolator());
        valueAnimatorOfFloat.setDuration(800L);
        valueAnimatorOfFloat.addUpdateListener(new ValueAnimator.AnimatorUpdateListener() { // from class: com.facetec.sdk.魂
            @Override // android.animation.ValueAnimator.AnimatorUpdateListener
            public final void onAnimationUpdate(ValueAnimator valueAnimator) {
                this.f7302.a(valueAnimator);
            }
        });
        valueAnimatorOfFloat.start();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void m() {
        setLayerType(2, null);
        Paint paint = new Paint(1);
        this.e = paint;
        paint.setStyle(Paint.Style.FILL);
        this.e.setColor(dm.m(this.m));
    }

    public final void b() {
        Paint paint = this.e;
        if (paint == null) {
            return;
        }
        bh.e(this.e, this, paint.getColor(), dm.m(this.m)).start();
        bh.e(this.d, this, this.d.getColor(), dm.l(this.m)).start();
        ValueAnimator valueAnimatorB = bh.b(this.k, this, this.u, dm.W());
        valueAnimatorB.addUpdateListener(new ValueAnimator.AnimatorUpdateListener() { // from class: com.facetec.sdk.丹凤
            @Override // android.animation.ValueAnimator.AnimatorUpdateListener
            public final void onAnimationUpdate(ValueAnimator valueAnimator) {
                this.f6731.e(valueAnimator);
            }
        });
        valueAnimatorB.start();
    }

    @Override // com.facetec.sdk.de, android.view.View
    public void onDraw(Canvas canvas) {
        Drawable drawable = this.k;
        if (drawable == null) {
            canvas.drawColor(dq.c(dm.k(this.m), 255));
            return;
        }
        drawable.draw(canvas);
        if (!this.q || this.b == null || this.i == null || this.f == null || this.e == null || this.a == null || this.d == null) {
            return;
        }
        canvas.concat(this.o);
        canvas.drawOval(this.b, this.a);
        canvas.drawOval(this.f, this.e);
        canvas.drawOval(this.i, this.d);
    }

    @Override // android.view.View
    public void onLayout(boolean z, int i, int i2, int i3, int i4) {
        super.onLayout(z, i, i2, i3, i4);
        int width = getWidth();
        if (width != this.t) {
            if (this.k == null) {
                this.u = dm.W();
                Drawable drawableP = dm.p(this.m);
                this.k = drawableP;
                drawableP.setAlpha(255);
            }
            this.k.setBounds(0, 0, getWidth(), getHeight());
            if (this.t != -1) {
                d(true);
            }
            this.t = width;
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void e(int i) {
        int alpha = this.e.getAlpha();
        Context context = this.m;
        ValueAnimator valueAnimatorOfInt = ValueAnimator.ofInt(alpha, dm.d(context, dm.m(context)));
        long j = i;
        valueAnimatorOfInt.setDuration(j);
        valueAnimatorOfInt.addUpdateListener(new ValueAnimator.AnimatorUpdateListener() { // from class: com.facetec.sdk.丹乐
            @Override // android.animation.ValueAnimator.AnimatorUpdateListener
            public final void onAnimationUpdate(ValueAnimator valueAnimator) {
                this.f6725.b(valueAnimator);
            }
        });
        int alpha2 = this.d.getAlpha();
        Context context2 = this.m;
        ValueAnimator valueAnimatorOfInt2 = ValueAnimator.ofInt(alpha2, dm.d(context2, dm.l(context2)));
        valueAnimatorOfInt2.setDuration(j);
        valueAnimatorOfInt2.addUpdateListener(new ValueAnimator.AnimatorUpdateListener() { // from class: com.facetec.sdk.丹书
            @Override // android.animation.ValueAnimator.AnimatorUpdateListener
            public final void onAnimationUpdate(ValueAnimator valueAnimator) {
                this.f6726.c(valueAnimator);
            }
        });
        valueAnimatorOfInt.start();
        valueAnimatorOfInt2.start();
    }

    public final void d(final int i) {
        postDelayed(new Runnable() { // from class: com.facetec.sdk.丹仙
            @Override // java.lang.Runnable
            public final void run() {
                this.f6728.e(i);
            }
        }, 0L);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void a(ValueAnimator valueAnimator) {
        Matrix matrix = this.o;
        if (matrix == null) {
            return;
        }
        matrix.getValues(this.s);
        float f = -((valueAnimator.getAnimatedFraction() * this.p) - (this.p - this.s[2]));
        this.r = f;
        this.o.postTranslate(f, SelfieScan.RECOGNITION_FAIL_RESULT);
        postInvalidateOnAnimation();
    }

    public final void d() {
        this.q = true;
        float fC = dq.c().width * dm.c();
        this.p = fC;
        this.o.setTranslate(fC, SelfieScan.RECOGNITION_FAIL_RESULT);
        post(new Runnable() { // from class: com.facetec.sdk.丹人
            @Override // java.lang.Runnable
            public final void run() {
                this.f6727.i();
            }
        });
    }

    public final void a() {
        this.q = true;
        postInvalidate();
    }

    public final void b(final int i, final int i2, int i3) {
        postDelayed(new Runnable() { // from class: com.facetec.sdk.龙
            @Override // java.lang.Runnable
            public final void run() {
                this.f7303.a(i, i2);
            }
        }, i3);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void b(ValueAnimator valueAnimator) {
        Paint paint = this.e;
        if (paint == null) {
            return;
        }
        paint.setAlpha(((Integer) valueAnimator.getAnimatedValue()).intValue());
        postInvalidateOnAnimation();
    }
}