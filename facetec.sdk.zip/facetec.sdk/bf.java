package com.facetec.sdk;

import android.os.Process;
import androidx.annotation.NonNull;
import java.lang.ref.WeakReference;

/* JADX INFO: loaded from: classes4.dex */
public final class bf implements FaceTecFaceScanResultCallback {
    public static int a;
    public static int c;
    private final WeakReference<bi> b;

    public bf(bi biVar) {
        this.b = new WeakReference<>(biVar);
    }

    private bi d(boolean z) {
        bi biVar = this.b.get();
        if (z) {
            this.b.clear();
        }
        return biVar;
    }

    @Override // com.facetec.sdk.FaceTecFaceScanResultCallback
    public final void cancel() {
        FaceTecSDK.h++;
        bi biVarD = d(true);
        if (bh.b(biVarD)) {
            biVarD.E = true;
            t.d(biVarD, c.DEVELOPER_USED_FACESCAN_CALLBACK, "cancel", null);
            biVarD.a(biVarD.z.getStatus());
        }
    }

    @Override // com.facetec.sdk.FaceTecFaceScanResultCallback
    public final boolean proceedToNextStep(@NonNull String str) {
        return proceedToNextStep(str, FaceTecIDScanNextStep.SELECTION_SCREEN);
    }

    @Override // com.facetec.sdk.FaceTecFaceScanResultCallback
    public final void retry() {
        FaceTecSDK.i++;
        bi biVarD = d(true);
        if (bh.b(biVarD)) {
            bi.e(FaceTecOCRConfirmationCustomization.d(), -302800720, 302800746, FaceTecOCRConfirmationCustomization.d(), new Object[]{biVarD}, FaceTecOCRConfirmationCustomization.d(), FaceTecOCRConfirmationCustomization.d());
        }
    }

    @Override // com.facetec.sdk.FaceTecFaceScanResultCallback
    public final void succeed() {
        succeed(FaceTecIDScanNextStep.SELECTION_SCREEN);
    }

    @Override // com.facetec.sdk.FaceTecFaceScanResultCallback
    public final void uploadMessageOverride(String str) {
        bi biVarD = d(false);
        if (bh.b(biVarD)) {
            biVarD.a(str);
        }
    }

    @Override // com.facetec.sdk.FaceTecFaceScanResultCallback
    public final void uploadProgress(float f) {
        bi biVarD = d(false);
        if (bh.b(biVarD)) {
            biVarD.c(f);
        }
    }

    @Override // com.facetec.sdk.FaceTecFaceScanResultCallback
    public final boolean proceedToNextStep(@NonNull String str, FaceTecIDScanNextStep faceTecIDScanNextStep) {
        bi biVarD = d(true);
        if (bh.b(biVarD)) {
            return biVarD.a(str, faceTecIDScanNextStep);
        }
        return false;
    }

    @Override // com.facetec.sdk.FaceTecFaceScanResultCallback
    public final void succeed(FaceTecIDScanNextStep faceTecIDScanNextStep) {
        FaceTecSDK.b++;
        bi biVarD = d(true);
        if (bh.b(biVarD)) {
            biVarD.b(faceTecIDScanNextStep);
        }
    }

    public static int d() {
        int i = c;
        int i2 = i % 6589787;
        c = i + 1;
        if (i2 != 0) {
            return a;
        }
        int iMyUid = Process.myUid();
        a = iMyUid;
        return iMyUid;
    }
}