package com.facetec.sdk;

import android.animation.Animator;
import android.animation.AnimatorSet;
import android.animation.ObjectAnimator;
import android.annotation.SuppressLint;
import android.content.Context;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.util.Property;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewTreeObserver;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;
import androidx.annotation.NonNull;
import com.facetec.sdk.FaceTecCancelButtonCustomization;
import com.facetec.sdk.FaceTecSDK;
import com.facetec.sdk.au;
import com.facetec.sdk.bi;
import com.facetec.sdk.bm;
import com.facetec.sdk.cg;
import com.facetec.sdk.cp;
import com.facetec.sdk.pg;
import com.incode.welcome_sdk.modules.SelfieScan;
import io.sentry.protocol.ViewHierarchyNode;

/* JADX INFO: loaded from: classes4.dex */
abstract class bg extends au {
    private cp.b C;
    private cg D;
    protected e a;
    protected RelativeLayout b;
    protected ImageView c;
    protected be d;
    protected ViewGroup e;
    protected View f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    protected ViewGroup f95828g;
    protected Animator j;
    private ImageView k;
    private TextView n;
    private TextView o;
    private ImageView p;
    private TextView q;
    private TextView r;
    private TextView s;
    private TextView t;
    private AnimatorSet u;
    private Animator w;
    private View x;
    private Handler y;
    private Runnable z;
    private boolean v = false;
    protected boolean h = false;
    protected boolean i = false;
    protected boolean m = false;
    boolean l = false;
    private Handler A = new Handler(Looper.getMainLooper());
    private au.c B = null;
    private final cg.e I = new cg.e() { // from class: com.facetec.sdk.丹宫
        @Override // com.facetec.sdk.cg.e
        public final void onDarkLightDetected() {
            this.f6747.H();
        }
    };
    private final ViewTreeObserver.OnGlobalLayoutListener G = new ViewTreeObserver.OnGlobalLayoutListener() { // from class: com.facetec.sdk.bg.2
        @Override // android.view.ViewTreeObserver.OnGlobalLayoutListener
        public final void onGlobalLayout() {
            bg bgVar = bg.this;
            if (bgVar.l) {
                return;
            }
            bgVar.l = true;
            float fB = dm.b() * dm.c();
            int iA = (int) (bh.a(50) * fB);
            int iA2 = (int) (bh.a(35) * fB);
            int iIntValue = ((Integer) dm.e(pg.a.a(), pg.a.a(), 1933108801, new Object[0], pg.a.a(), -1933108792, pg.a.a())).intValue();
            float f = iIntValue / 2.0f;
            int iRound = Math.round(f);
            int iRound2 = Math.round(f);
            RelativeLayout.LayoutParams layoutParams = (RelativeLayout.LayoutParams) bg.this.f95828g.getLayoutParams();
            layoutParams.setMargins(0, 0, 0, iIntValue);
            bg.this.f95828g.setLayoutParams(layoutParams);
            bg.this.a.setLayoutParams(new LinearLayout.LayoutParams((int) ((dq.c().width * dm.c()) - (iIntValue << 1)), iA));
            bg.this.a.requestLayout();
            RelativeLayout.LayoutParams layoutParams2 = (RelativeLayout.LayoutParams) bg.this.c.getLayoutParams();
            layoutParams2.setMargins(iRound, iRound, 0, 0);
            layoutParams2.setMarginStart(iRound);
            layoutParams2.setMarginEnd(iRound);
            bg.this.c.setLayoutParams(layoutParams2);
            bg.this.c.setPadding(iRound2, iRound2, iRound2, iRound2);
            bg.this.c.getLayoutParams().height = iA2;
            bg.this.c.getLayoutParams().width = iA2;
            bg.this.c.requestLayout();
            bg.this.f.animate().alpha(1.0f).setDuration(500L).setListener(null).start();
        }
    };

    /* JADX INFO: renamed from: com.facetec.sdk.bg$1, reason: invalid class name */
    public static /* synthetic */ class AnonymousClass1 {
        static final /* synthetic */ int[] a;
        static final /* synthetic */ int[] c;
        static final /* synthetic */ int[] d;

        static {
            int[] iArr = new int[FaceTecCancelButtonCustomization.ButtonLocation.values().length];
            c = iArr;
            try {
                iArr[FaceTecCancelButtonCustomization.ButtonLocation.TOP_LEFT.ordinal()] = 1;
            } catch (NoSuchFieldError unused) {
            }
            try {
                c[FaceTecCancelButtonCustomization.ButtonLocation.TOP_RIGHT.ordinal()] = 2;
            } catch (NoSuchFieldError unused2) {
            }
            try {
                c[FaceTecCancelButtonCustomization.ButtonLocation.CUSTOM.ordinal()] = 3;
            } catch (NoSuchFieldError unused3) {
            }
            try {
                c[FaceTecCancelButtonCustomization.ButtonLocation.DISABLED.ordinal()] = 4;
            } catch (NoSuchFieldError unused4) {
            }
            int[] iArr2 = new int[cw.values().length];
            a = iArr2;
            try {
                iArr2[cw.DEFAULT.ordinal()] = 1;
            } catch (NoSuchFieldError unused5) {
            }
            try {
                a[cw.DARK_AS_POSSIBLE.ordinal()] = 2;
            } catch (NoSuchFieldError unused6) {
            }
            try {
                a[cw.BRIGHT_AS_POSSIBLE.ordinal()] = 3;
            } catch (NoSuchFieldError unused7) {
            }
            int[] iArr3 = new int[ct.values().length];
            d = iArr3;
            try {
                iArr3[ct.ENABLE.ordinal()] = 1;
            } catch (NoSuchFieldError unused8) {
            }
            try {
                d[ct.DISABLE.ordinal()] = 2;
            } catch (NoSuchFieldError unused9) {
            }
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void A() {
        t();
        if (f() == null || f().G) {
            return;
        }
        boolean zH = h();
        boolean z = this.h || ed.b();
        boolean zIsEnabled = this.a.isEnabled();
        if (zH && z && zIsEnabled) {
            D();
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void B() {
        this.D = cg.b(f());
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void C() {
        if (b()) {
            e eVar = this.a;
            if (!eVar.a && !this.v && eVar.isEnabled()) {
                this.a.b(true, false);
            }
        }
        this.y.postDelayed(this.z, 5000L);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void H() {
        bi biVarF = f();
        if (biVarF != null) {
            biVarF.M.b(Boolean.TRUE);
        }
    }

    private void b(ct ctVar) {
        if (h()) {
            if (ed.b()) {
                if (this.a.isEnabled()) {
                    return;
                }
                this.a.b(true, true);
                return;
            }
            int i = AnonymousClass1.d[ctVar.ordinal()];
            if (i == 1) {
                if (this.a.isEnabled()) {
                    return;
                }
                this.a.b(true, true);
            } else if (i == 2 && this.a.isEnabled() && !this.h) {
                this.a.b(false, true);
            }
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void c(boolean z, ImageView imageView) {
        if (b() && !z) {
            imageView.setVisibility(8);
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void d(View view) {
        this.c.setAlpha(1.0f);
        this.c.setEnabled(false);
        e(false);
        this.a.b(false, true);
        d();
    }

    private void p() {
        v();
        cp cpVarR = r();
        if (cpVarR != null) {
            cpVarR.b(this.C);
            this.C = null;
        }
    }

    private au.c q() {
        return new au.c(new Runnable() { // from class: com.facetec.sdk.丹古
            @Override // java.lang.Runnable
            public final void run() {
                this.f6735.A();
            }
        });
    }

    private cp r() {
        bi biVarF = f();
        if (biVarF != null) {
            return biVarF.e;
        }
        return null;
    }

    public static void s() {
        cc.c = false;
        cv.C(false);
    }

    private void t() {
        this.A.removeCallbacksAndMessages(null);
        this.B = null;
    }

    private void u() {
        if (f() == null) {
            return;
        }
        dj.a(new Runnable() { // from class: com.facetec.sdk.丹史
            @Override // java.lang.Runnable
            public final void run() {
                this.f6736.B();
            }
        });
    }

    private void v() {
        cg cgVar = this.D;
        if (cgVar != null) {
            cgVar.a();
            this.D = null;
        }
    }

    private void w() {
        this.y = new Handler();
        Runnable runnable = new Runnable() { // from class: com.facetec.sdk.丹地
            @Override // java.lang.Runnable
            public final void run() {
                this.f6742.C();
            }
        };
        this.z = runnable;
        this.y.post(runnable);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void x() {
        if (getActivity() != null) {
            e(true);
            this.c.setEnabled(true);
            this.a.setEnabled(true);
            a();
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    /* JADX INFO: renamed from: y, reason: merged with bridge method [inline-methods] */
    public void D() {
        this.v = true;
        this.c.setEnabled(false);
        e(false);
        this.a.b(false, true);
        this.j = ObjectAnimator.ofFloat((Object) null, ViewHierarchyNode.JsonKeys.ALPHA, 1.0f, SelfieScan.RECOGNITION_FAIL_RESULT).setDuration(1000L);
        o();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void z() {
        cp cpVarR = r();
        cg cgVar = this.D;
        if (cgVar == null || cpVarR == null) {
            return;
        }
        cgVar.d(this.I, cpVarR);
    }

    public abstract void a();

    public final void a(final boolean z, int i, int i2) {
        final ImageView imageViewG;
        if (b() && (imageViewG = g()) != null) {
            float f = z ? 1.0f : SelfieScan.RECOGNITION_FAIL_RESULT;
            if (i == 0 && i2 == 0) {
                imageViewG.setAlpha(f);
                imageViewG.setVisibility(z ? 0 : 8);
            } else {
                if (z) {
                    imageViewG.setVisibility(0);
                }
                imageViewG.animate().alpha(f).setDuration(i).setStartDelay(i2).setListener(null).withEndAction(new au.c(new Runnable() { // from class: com.facetec.sdk.丹名
                    @Override // java.lang.Runnable
                    public final void run() {
                        this.f6737.c(z, imageViewG);
                    }
                })).start();
            }
        }
    }

    public abstract void c();

    public abstract void d();

    public abstract void e();

    public final void e(boolean z) {
        if (b() && FaceTecSDK.d.m.b == FaceTecCancelButtonCustomization.ButtonLocation.CUSTOM) {
            this.p.setEnabled(z);
        }
    }

    public final bi f() {
        return (bi) getActivity();
    }

    public final ImageView g() {
        if (FaceTecSDK.d.m.b == FaceTecCancelButtonCustomization.ButtonLocation.CUSTOM) {
            return this.p;
        }
        if (FaceTecSDK.d.m.b != FaceTecCancelButtonCustomization.ButtonLocation.DISABLED) {
            return this.c;
        }
        return null;
    }

    public abstract boolean h();

    public abstract void i();

    public final bm j() {
        return (bm) getActivity();
    }

    public final void k() {
        if (b()) {
            e eVar = this.a;
            if (eVar == null || this.c == null) {
                t.d(f(), c.NON_FATAL_ERROR, "XML views are null unexpectedly. [0]", null);
            } else {
                eVar.d();
            }
            c();
        }
    }

    @SuppressLint({"ClickableViewAccessibility"})
    public void l() {
        this.c.setEnabled(false);
        e(false);
        if (FaceTecSDK.d.m.b != FaceTecCancelButtonCustomization.ButtonLocation.DISABLED) {
            this.c.setImageResource(dm.aQ());
        }
        int i = AnonymousClass1.c[FaceTecSDK.d.m.b.ordinal()];
        if (i == 2) {
            RelativeLayout.LayoutParams layoutParams = (RelativeLayout.LayoutParams) this.c.getLayoutParams();
            layoutParams.removeRule(20);
            layoutParams.addRule(21);
            this.c.setLayoutParams(layoutParams);
        } else if (i == 3 || i == 4) {
            this.c.setVisibility(8);
        }
        float fB = dm.b() * dm.c();
        dm.e(this.b);
        this.o.setTypeface(br.e);
        float f = 20.0f * fB;
        this.o.setTextSize(2, f);
        dm.c(this.o);
        this.o.setLineSpacing(SelfieScan.RECOGNITION_FAIL_RESULT, 1.1f);
        this.n.setTypeface(br.c);
        dm.c(this.n);
        this.n.setTypeface(br.c);
        this.n.setTextSize(2, fB * 28.0f);
        this.n.setLineSpacing(SelfieScan.RECOGNITION_FAIL_RESULT, 1.1f);
        this.q.setTypeface(br.e);
        this.r.setTypeface(br.e);
        this.t.setTypeface(br.e);
        this.s.setTypeface(br.e);
        this.q.setTextSize(2, f);
        this.r.setTextSize(2, f);
        this.t.setTextSize(2, f);
        this.s.setTextSize(2, f);
        this.q.setLineSpacing(SelfieScan.RECOGNITION_FAIL_RESULT, 1.1f);
        this.r.setLineSpacing(SelfieScan.RECOGNITION_FAIL_RESULT, 1.1f);
        this.t.setLineSpacing(SelfieScan.RECOGNITION_FAIL_RESULT, 1.1f);
        this.s.setLineSpacing(SelfieScan.RECOGNITION_FAIL_RESULT, 1.1f);
        dm.c(this.q);
        dm.c(this.r);
        dm.c(this.t);
        dm.c(this.s);
        this.a.setEnabled(false);
        this.a.a();
        this.a.setAlpha(SelfieScan.RECOGNITION_FAIL_RESULT);
        this.f.setAlpha(SelfieScan.RECOGNITION_FAIL_RESULT);
        a(false, 0, 0);
        this.a.getViewTreeObserver().addOnGlobalLayoutListener(this.G);
        bh.a(getActivity());
        this.c.setOnClickListener(new View.OnClickListener() { // from class: com.facetec.sdk.丹城
            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                this.f6743.d(view);
            }
        });
        this.c.setOnTouchListener(new View.OnTouchListener() { // from class: com.facetec.sdk.丹天
            @Override // android.view.View.OnTouchListener
            public final boolean onTouch(View view, MotionEvent motionEvent) {
                return this.f6744.e(view, motionEvent);
            }
        });
        this.a.c(new au.c(new Runnable() { // from class: com.facetec.sdk.丹妖
            @Override // java.lang.Runnable
            public final void run() {
                this.f6745.D();
            }
        }));
        this.x.post(new au.c(new Runnable() { // from class: com.facetec.sdk.丹字
            @Override // java.lang.Runnable
            public final void run() {
                this.f6746.x();
            }
        }));
    }

    public final void m() {
        this.v = false;
    }

    public final void n() {
        ImageView imageView = this.c;
        if (imageView == null || FaceTecSDK.d.m.b == FaceTecCancelButtonCustomization.ButtonLocation.DISABLED) {
            return;
        }
        imageView.setImageResource(dm.aQ());
    }

    public void o() {
        e();
    }

    @Override // com.facetec.sdk.au, android.app.Fragment
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
    }

    @Override // android.app.Fragment
    public Animator onCreateAnimator(int i, boolean z, int i2) {
        Animator animator;
        Animator animator2;
        return (!z || (animator2 = this.w) == null) ? (z || (animator = this.j) == null) ? super.onCreateAnimator(i, z, i2) : animator : animator2;
    }

    @Override // android.app.Fragment
    public View onCreateView(LayoutInflater layoutInflater, ViewGroup viewGroup, Bundle bundle) {
        View viewInflate = layoutInflater.inflate(R.layout.facetec_guidance_fragment, viewGroup, false);
        this.x = viewInflate;
        return viewInflate;
    }

    @Override // android.app.Fragment
    public void onDestroy() {
        super.onDestroy();
        v();
        e eVar = this.a;
        if (eVar != null) {
            eVar.getViewTreeObserver().removeOnGlobalLayoutListener(this.G);
        }
    }

    @Override // android.app.Fragment
    public void onPause() {
        Runnable runnable;
        super.onPause();
        this.x.removeCallbacks(null);
        AnimatorSet animatorSet = this.u;
        if (animatorSet != null) {
            animatorSet.cancel();
        }
        Handler handler = this.y;
        if (handler == null || (runnable = this.z) == null) {
            return;
        }
        handler.removeCallbacks(runnable);
    }

    @Override // android.app.Fragment
    public void onViewCreated(View view, Bundle bundle) {
        super.onViewCreated(view, bundle);
        bd.a = false;
        this.f = view.findViewById(R.id.centerContentView);
        this.d = (be) view.findViewById(R.id.zoomDialogBackground);
        this.f95828g = (ViewGroup) view.findViewById(R.id.bottomLayout);
        this.e = (ViewGroup) view.findViewById(R.id.zoomDialogForeground);
        this.c = (ImageView) view.findViewById(R.id.backButton);
        this.o = (TextView) view.findViewById(R.id.zoomDialogIconSubtext);
        this.k = (ImageView) view.findViewById(R.id.iconImageView);
        this.n = (TextView) view.findViewById(R.id.zoomDialogHeader);
        this.q = (TextView) view.findViewById(R.id.messageView1);
        this.r = (TextView) view.findViewById(R.id.messageView2);
        this.t = (TextView) view.findViewById(R.id.zoomDialogText3);
        this.s = (TextView) view.findViewById(R.id.zoomDialogText4);
        this.a = (e) view.findViewById(R.id.zoomDialogActionButton);
        this.b = (RelativeLayout) view.findViewById(R.id.guidanceTransitionView);
        bi biVarF = f();
        if (r() != null && biVarF != null && biVarF.e() == bm.b.GRANTED && !this.i) {
            e(biVarF, this.m);
        }
        this.p = biVarF.w;
        l();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void c(Context context, boolean z) throws Throwable {
        cp cpVarR = r();
        if (cpVarR != null) {
            cp.b bVar = new cp.b() { // from class: com.facetec.sdk.丹山
                @Override // com.facetec.sdk.cp.b
                public final void onPreSessionProgress(da daVar, cw cwVar, cs csVar, ct ctVar) throws Throwable {
                    this.f6748.a(daVar, cwVar, csVar, ctVar);
                }
            };
            this.C = bVar;
            cpVarR.d(bVar);
            if (cpVarR.b(context, z) || f() == null) {
                return;
            }
            f().d(ao.u);
        }
    }

    public final void e(@NonNull final Context context, final boolean z) {
        bi biVarF = f();
        if (biVarF != null) {
            biVarF.H = bi.e.PRE_SESSION_STARTED;
        }
        b(new Runnable() { // from class: com.facetec.sdk.丹剑
            @Override // java.lang.Runnable
            public final void run() throws Throwable {
                this.f6732.c(context, z);
            }
        }, 20L);
        w();
        if (FaceTecSDK.c == FaceTecSDK.c.NORMAL) {
            if (r() != null) {
                u();
            }
            b(new Runnable() { // from class: com.facetec.sdk.丹国
                @Override // java.lang.Runnable
                public final void run() {
                    this.f6740.z();
                }
            }, 185L);
        }
    }

    public final void d(@NonNull final Runnable runnable, int i) {
        AnimatorSet animatorSet = new AnimatorSet();
        this.u = animatorSet;
        animatorSet.playTogether(ObjectAnimator.ofFloat(this.e, (Property<ViewGroup, Float>) View.ALPHA, 1.0f, SelfieScan.RECOGNITION_FAIL_RESULT));
        this.u.setDuration(i);
        this.u.addListener(new f() { // from class: com.facetec.sdk.丹土
            @Override // android.animation.Animator.AnimatorListener
            public final void onAnimationEnd(Animator animator) {
                runnable.run();
            }
        });
        this.u.start();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void a(da daVar, cw cwVar, cs csVar, ct ctVar) throws Throwable {
        bi biVarF;
        if (this.v || !b() || (biVarF = f()) == null) {
            return;
        }
        if (daVar == da.TIMEOUT_GO_TO_RETRY) {
            if (biVarF.e != null && cp.l() && h()) {
                p();
                q().run();
                return;
            } else {
                b(ctVar);
                p();
                biVarF.i();
                return;
            }
        }
        if (daVar == da.DETECTING_LIGHT_MODE) {
            b(ctVar);
            int i = AnonymousClass1.a[cwVar.ordinal()];
            if (i == 2) {
                biVarF.M.b();
            } else if (i == 3) {
                biVarF.M.b(Boolean.FALSE);
            }
            if (ctVar == ct.ENABLE) {
                boolean zH = h();
                boolean z = this.h;
                boolean zIsEnabled = this.a.isEnabled();
                boolean z2 = this.B != null;
                if (zH && z && zIsEnabled && !z2) {
                    t();
                    au.c cVarQ = q();
                    this.B = cVarQ;
                    this.A.postDelayed(cVarQ, 2000L);
                    return;
                }
                return;
            }
            t();
            return;
        }
        p();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ boolean e(View view, MotionEvent motionEvent) {
        if (motionEvent.getAction() == 0) {
            this.c.setAlpha(0.4f);
        } else if (motionEvent.getAction() != 3 && motionEvent.getX() >= SelfieScan.RECOGNITION_FAIL_RESULT && motionEvent.getX() <= this.c.getWidth() + this.c.getLeft() + 10 && motionEvent.getY() >= SelfieScan.RECOGNITION_FAIL_RESULT && motionEvent.getY() <= this.c.getHeight() + this.c.getTop() + 10) {
            if (motionEvent.getAction() == 1) {
                this.c.performClick();
            }
        } else {
            this.c.setAlpha(1.0f);
        }
        return true;
    }
}