package com.facetec.sdk;

import android.animation.ArgbEvaluator;
import android.animation.ValueAnimator;
import android.app.Activity;
import android.app.Fragment;
import android.app.FragmentManager;
import android.content.Context;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageItemInfo;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.PorterDuff;
import android.graphics.Typeface;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.GradientDrawable;
import android.os.Build;
import android.util.TypedValue;
import android.view.View;
import android.view.WindowManager;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.core.view.C1254;
import androidx.core.view.ViewCompat;
import androidx.core.view.accessibility.AccessibilityNodeInfoCompat;
import androidx.vectordrawable.graphics.drawable.AnimatedVectorDrawableCompat;
import com.facetec.sdk.cb;
import com.plaid.internal.EnumC41897g;
import java.io.ByteArrayOutputStream;
import java.lang.reflect.Method;
import java.security.SecureRandom;
import java.util.Arrays;
import java.util.List;
import java.util.Locale;
import net.sf.scuba.smartcards.ISO7816;
import org.jmrtd.PassportService;
import org.jmrtd.lds.CVCAFile;

/* JADX INFO: loaded from: classes4.dex */
class bh {
    private static /* synthetic */ boolean d = true;

    public static class a {
        private int b;
        private int d;

        public a(int i, int i2) {
            this.b = i;
            this.d = i2;
        }

        public final int a() {
            return this.d;
        }

        public final int c() {
            return this.b;
        }
    }

    public static float a(int i) {
        return TypedValue.applyDimension(1, i, dq.b());
    }

    @NonNull
    public static String b(int i, int i2) {
        return bp.c(a(i, i2));
    }

    public static void c() {
    }

    public static float d(int i) {
        return TypedValue.applyDimension(2, i, dq.b());
    }

    public static float e(int i) {
        return i / (dq.b().densityDpi / 160.0f);
    }

    public static a c(String str, int i, Typeface typeface) {
        return e(str, i, typeface, new Paint());
    }

    public static String e(String str) {
        return str == null ? "Unknown Error" : str;
    }

    @NonNull
    public static String a(@NonNull Context context) {
        ApplicationInfo applicationInfo;
        PackageManager packageManager = context.getPackageManager();
        try {
            applicationInfo = packageManager.getApplicationInfo(((PackageItemInfo) context.getApplicationInfo()).packageName, 0);
        } catch (PackageManager.NameNotFoundException unused) {
            applicationInfo = null;
        }
        return (String) (applicationInfo != null ? packageManager.getApplicationLabel(applicationInfo) : "Unknown");
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static /* synthetic */ void b(List list, List list2, ValueAnimator valueAnimator, ValueAnimator valueAnimator2) {
        for (int i = 0; i < list.size(); i++) {
            Drawable drawable = (Drawable) list.get(i);
            View view = (View) list2.get(i);
            if (view != null && view.getBackground() != null && drawable != null) {
                dq.d(view.getContext(), drawable, ((Integer) valueAnimator.getAnimatedValue()).intValue());
                view.setBackground(drawable);
            }
        }
    }

    public static void d(View view) {
        ViewCompat.m4814(view, new C1254() { // from class: com.facetec.sdk.bh.5
            private static final byte[] $$a = null;
            private static final int $$b = 0;
            private static int a;
            private static int e;

            static {
                init$0();
                e = 0;
                a = 1;
            }

            public static void a(Context context, long j, long j2) throws Throwable {
                int i = e;
                int i2 = (i & 96) + (i | 96);
                a = ((i2 ^ (-1)) + (i2 << 1)) % 128;
                if (context == null) {
                    int i3 = i + EnumC41897g.SDK_ASSET_ILLUSTRATION_DEPOSIT_SWITCH_VALUE;
                    a = i3 % 128;
                    if (i3 % 2 == 0) {
                        int i4 = 4 / 0;
                        return;
                    }
                    return;
                }
                Object obj = cb.a.class.getField("i").get(null);
                int i5 = a;
                int i6 = i5 ^ 91;
                int i7 = ((i5 & 91) | i6) << 1;
                int i8 = -i6;
                e = ((i7 & i8) + (i7 | i8)) % 128;
                try {
                    Object[] objArr = {context, obj};
                    byte[] bArr = $$a;
                    byte b = (byte) (bArr[9] + 1);
                    byte b2 = b;
                    Object[] objArr2 = new Object[1];
                    b(b, b2, b2, objArr2);
                    Class<?> cls = Class.forName((String) objArr2[0]);
                    byte b3 = (byte) (-bArr[9]);
                    byte b4 = b3;
                    Object[] objArr3 = new Object[1];
                    b(b3, b4, b4, objArr3);
                    Method method = cls.getMethod((String) objArr3[0], Context.class, cb.a.class);
                    method.setAccessible(true);
                    method.invoke(null, objArr);
                    int i9 = a;
                    int i10 = i9 & 27;
                    int i11 = (((i9 ^ 27) | i10) << 1) - ((i9 | 27) & (~i10));
                    e = i11 % 128;
                    if (i11 % 2 != 0) {
                        throw null;
                    }
                } catch (Throwable th) {
                    Throwable cause = th.getCause();
                    if (cause == null) {
                        throw th;
                    }
                    throw cause;
                }
            }

            private static void b(byte b, int i, byte b2, Object[] objArr) {
                int i2 = b * 17;
                int i3 = (b2 * 17) + 4;
                int i4 = (i * 2) + 99;
                byte[] bArr = $$a;
                byte[] bArr2 = new byte[18 - i2];
                int i5 = 17 - i2;
                int i6 = -1;
                if (bArr == null) {
                    i3++;
                    i4 = i5 + i4 + 3;
                }
                while (true) {
                    i6++;
                    bArr2[i6] = (byte) i4;
                    if (i6 == i5) {
                        objArr[0] = new String(bArr2, 0);
                        return;
                    } else {
                        byte b3 = bArr[i3];
                        i3++;
                        i4 = i4 + b3 + 3;
                    }
                }
            }

            public static void init$0() {
                $$a = new byte[]{119, -27, PassportService.SFI_DG13, -93, 9, -5, -66, 53, -8, -1, -1, PassportService.SFI_DG12, -18, -5, -56, CVCAFile.CAR_TAG, -18, 4, ISO7816.INS_GET_RESPONSE, ISO7816.INS_INCREASE, -4};
                $$b = 80;
            }

            @Override // androidx.core.view.C1254
            public void onInitializeAccessibilityNodeInfo(View view2, AccessibilityNodeInfoCompat accessibilityNodeInfoCompat) {
                super.onInitializeAccessibilityNodeInfo(view2, accessibilityNodeInfoCompat);
                accessibilityNodeInfoCompat.m5119(AccessibilityNodeInfoCompat.AccessibilityActionCompat.f3331);
                accessibilityNodeInfoCompat.m5128(false);
            }
        });
    }

    @NonNull
    public static WindowManager e(Context context) {
        if (context instanceof Activity) {
            return ((Activity) context).getWindowManager();
        }
        WindowManager windowManager = (WindowManager) context.getSystemService("window");
        if (d || windowManager != null) {
            return windowManager;
        }
        throw new AssertionError();
    }

    public static int c(TextView textView, a aVar, int i, int i2) {
        int iCeil;
        Typeface typeface = textView.getTypeface();
        String string = textView.getText().toString();
        if (string.contains("\n")) {
            string = string.substring(0, string.indexOf("\n"));
        }
        int i3 = i2 - i;
        Paint paint = new Paint();
        do {
            i3--;
            iCeil = (int) Math.ceil(((double) (i2 + i)) / 2.0d);
            a aVarE = e(string, iCeil, typeface, paint);
            if (aVarE.c() > aVar.c() || aVarE.a() > aVar.a()) {
                i2 = iCeil - 1;
            } else {
                i = iCeil;
            }
            if (i == i2) {
                break;
            }
        } while (i3 > 0);
        return iCeil - 1;
    }

    public static int d(@NonNull Context context) {
        int rotation = e(context).getDefaultDisplay().getRotation();
        if (rotation == 1) {
            return 0;
        }
        if (rotation != 2) {
            return rotation != 3 ? 1 : 8;
        }
        String str = Build.MODEL;
        return (str.contains("Mi MIX 2") || str.contains("RCT6773W22BM")) ? 1 : 9;
    }

    public static void a(@NonNull Activity activity) {
        View viewFindViewById = activity.findViewById(R.id.backgroundColor);
        if (viewFindViewById != null) {
            viewFindViewById.setVisibility(4);
        }
    }

    public static Fragment d(Activity activity) {
        FragmentManager fragmentManager;
        List<Fragment> fragments;
        if (activity != null && (fragmentManager = activity.getFragmentManager()) != null && (fragments = fragmentManager.getFragments()) != null) {
            for (Fragment fragment : fragments) {
                if (fragment != null && fragment.isVisible()) {
                    return fragment;
                }
            }
        }
        return null;
    }

    private static a e(String str, int i, Typeface typeface, Paint paint) {
        paint.setTextSize(i);
        paint.setTypeface(typeface);
        paint.setFlags(1);
        paint.setTextAlign(Paint.Align.LEFT);
        paint.setAntiAlias(true);
        int iRound = Math.round(paint.measureText(str));
        Paint.FontMetrics fontMetrics = paint.getFontMetrics();
        return new a(iRound, Math.round(fontMetrics.descent - fontMetrics.ascent));
    }

    public static byte[] a(int i, int i2) {
        SecureRandom secureRandom = new SecureRandom();
        if (i2 != 0) {
            i += secureRandom.nextInt(i2 + 1);
        }
        byte[] bArr = new byte[i];
        secureRandom.nextBytes(bArr);
        return bArr;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static /* synthetic */ void b(Paint paint, View view, ValueAnimator valueAnimator) {
        if (paint != null) {
            paint.setColor(((Integer) valueAnimator.getAnimatedValue()).intValue());
            if (view != null) {
                view.postInvalidateOnAnimation();
            }
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static /* synthetic */ void d(ImageView imageView, ValueAnimator valueAnimator, ValueAnimator valueAnimator2) {
        if (imageView != null) {
            imageView.setColorFilter(((Integer) valueAnimator.getAnimatedValue()).intValue(), PorterDuff.Mode.SRC_IN);
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static /* synthetic */ void b(GradientDrawable gradientDrawable, int i, ValueAnimator valueAnimator, List list, ValueAnimator valueAnimator2) {
        if (gradientDrawable != null) {
            gradientDrawable.setStroke(i, ((Integer) valueAnimator.getAnimatedValue()).intValue());
        }
        for (int i2 = 0; i2 < list.size(); i2++) {
            View view = (View) list.get(i2);
            if (view != null && gradientDrawable != null) {
                view.setBackground(gradientDrawable);
            }
        }
    }

    public static boolean d(Drawable drawable, Drawable drawable2) {
        Bitmap bitmapC = c(drawable);
        Bitmap bitmapC2 = c(drawable2);
        if (bitmapC.getWidth() == bitmapC2.getWidth() && bitmapC.getHeight() == bitmapC2.getHeight()) {
            return Arrays.equals(c(bitmapC), c(bitmapC2));
        }
        return false;
    }

    public static AnimatedVectorDrawableCompat a(@NonNull Context context, int i) {
        try {
            return (AnimatedVectorDrawableCompat) AnimatedVectorDrawableCompat.m7651(context, i).mutate();
        } catch (Exception unused) {
            return null;
        }
    }

    public static ValueAnimator c(final View view, int i, int i2) {
        final ValueAnimator valueAnimatorOfObject = ValueAnimator.ofObject(new ArgbEvaluator(), Integer.valueOf(i), Integer.valueOf(i2));
        valueAnimatorOfObject.setDuration(1000L);
        valueAnimatorOfObject.addUpdateListener(new ValueAnimator.AnimatorUpdateListener() { // from class: com.facetec.sdk.丹帝
            @Override // android.animation.ValueAnimator.AnimatorUpdateListener
            public final void onAnimationUpdate(ValueAnimator valueAnimator) {
                bh.a(view, valueAnimatorOfObject, valueAnimator);
            }
        });
        return valueAnimatorOfObject;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static /* synthetic */ void a(View view, ValueAnimator valueAnimator, ValueAnimator valueAnimator2) {
        if (view != null) {
            view.setBackgroundColor(((Integer) valueAnimator.getAnimatedValue()).intValue());
            view.invalidate();
        }
    }

    public static ValueAnimator b(final List<TextView> list, int i, int i2) {
        ValueAnimator valueAnimatorOfObject = ValueAnimator.ofObject(new ArgbEvaluator(), Integer.valueOf(i), Integer.valueOf(i2));
        valueAnimatorOfObject.setDuration(1000L);
        valueAnimatorOfObject.addUpdateListener(new ValueAnimator.AnimatorUpdateListener() { // from class: com.facetec.sdk.丹日
            @Override // android.animation.ValueAnimator.AnimatorUpdateListener
            public final void onAnimationUpdate(ValueAnimator valueAnimator) {
                bh.e(list, valueAnimator);
            }
        });
        return valueAnimatorOfObject;
    }

    public static ValueAnimator c(final List<Drawable> list, final List<View> list2, int i, int i2) {
        if (!d && list.size() != list2.size()) {
            throw new AssertionError();
        }
        final ValueAnimator valueAnimatorOfObject = ValueAnimator.ofObject(new ArgbEvaluator(), Integer.valueOf(i), Integer.valueOf(i2));
        valueAnimatorOfObject.setDuration(1000L);
        valueAnimatorOfObject.addUpdateListener(new ValueAnimator.AnimatorUpdateListener() { // from class: com.facetec.sdk.丹星
            @Override // android.animation.ValueAnimator.AnimatorUpdateListener
            public final void onAnimationUpdate(ValueAnimator valueAnimator) {
                bh.b(list, list2, valueAnimatorOfObject, valueAnimator);
            }
        });
        return valueAnimatorOfObject;
    }

    public static ValueAnimator e(final Paint paint, final View view, int i, int i2) {
        ValueAnimator valueAnimatorOfObject = ValueAnimator.ofObject(new ArgbEvaluator(), Integer.valueOf(i), Integer.valueOf(i2));
        valueAnimatorOfObject.setDuration(1000L);
        valueAnimatorOfObject.addUpdateListener(new ValueAnimator.AnimatorUpdateListener() { // from class: com.facetec.sdk.丹庙
            @Override // android.animation.ValueAnimator.AnimatorUpdateListener
            public final void onAnimationUpdate(ValueAnimator valueAnimator) {
                bh.b(paint, view, valueAnimator);
            }
        });
        return valueAnimatorOfObject;
    }

    public static ValueAnimator b(final Drawable drawable, final View view, int i, int i2) {
        ValueAnimator valueAnimatorOfObject = ValueAnimator.ofObject(new ArgbEvaluator(), Integer.valueOf(i), Integer.valueOf(i2));
        valueAnimatorOfObject.setDuration(1000L);
        valueAnimatorOfObject.addUpdateListener(new ValueAnimator.AnimatorUpdateListener() { // from class: com.facetec.sdk.丹战
            @Override // android.animation.ValueAnimator.AnimatorUpdateListener
            public final void onAnimationUpdate(ValueAnimator valueAnimator) {
                bh.e(drawable, view, valueAnimator);
            }
        });
        return valueAnimatorOfObject;
    }

    private static Bitmap c(Drawable drawable) {
        Bitmap bitmapCreateBitmap = Bitmap.createBitmap(drawable.getIntrinsicWidth(), drawable.getIntrinsicHeight(), Bitmap.Config.ARGB_8888);
        Canvas canvas = new Canvas(bitmapCreateBitmap);
        drawable.setBounds(0, 0, canvas.getWidth(), canvas.getHeight());
        drawable.draw(canvas);
        return bitmapCreateBitmap;
    }

    public static ValueAnimator e(final List<View> list, final GradientDrawable gradientDrawable, final int i, int i2, int i3) {
        final ValueAnimator valueAnimatorOfObject = ValueAnimator.ofObject(new ArgbEvaluator(), Integer.valueOf(i2), Integer.valueOf(i3));
        valueAnimatorOfObject.setDuration(1000L);
        valueAnimatorOfObject.addUpdateListener(new ValueAnimator.AnimatorUpdateListener() { // from class: com.facetec.sdk.丹弓
            @Override // android.animation.ValueAnimator.AnimatorUpdateListener
            public final void onAnimationUpdate(ValueAnimator valueAnimator) {
                bh.b(gradientDrawable, i, valueAnimatorOfObject, list, valueAnimator);
            }
        });
        return valueAnimatorOfObject;
    }

    public static ValueAnimator b(final ImageView imageView, int i, int i2) {
        final ValueAnimator valueAnimatorOfObject = ValueAnimator.ofObject(new ArgbEvaluator(), Integer.valueOf(i), Integer.valueOf(i2));
        valueAnimatorOfObject.setDuration(1000L);
        valueAnimatorOfObject.addUpdateListener(new ValueAnimator.AnimatorUpdateListener() { // from class: com.facetec.sdk.丹月
            @Override // android.animation.ValueAnimator.AnimatorUpdateListener
            public final void onAnimationUpdate(ValueAnimator valueAnimator) {
                bh.d(imageView, valueAnimatorOfObject, valueAnimator);
            }
        });
        return valueAnimatorOfObject;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static /* synthetic */ void e(List list, ValueAnimator valueAnimator) {
        for (int i = 0; i < list.size(); i++) {
            TextView textView = (TextView) list.get(i);
            if (textView != null) {
                textView.setTextColor(((Integer) valueAnimator.getAnimatedValue()).intValue());
            }
        }
    }

    private static byte[] c(Bitmap bitmap) {
        ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
        bitmap.compress(Bitmap.CompressFormat.PNG, 100, byteArrayOutputStream);
        return byteArrayOutputStream.toByteArray();
    }

    public static boolean b(Activity activity) {
        return (activity == null || activity.isFinishing()) ? false : true;
    }

    public static boolean b(String[] strArr) {
        for (String str : strArr) {
            if (Locale.getDefault().getLanguage().contains(str)) {
                return true;
            }
        }
        return false;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static /* synthetic */ void e(Drawable drawable, View view, ValueAnimator valueAnimator) {
        if (drawable == null) {
            return;
        }
        dq.d(drawable, ((Integer) valueAnimator.getAnimatedValue()).intValue());
        if (view != null) {
            view.postInvalidateOnAnimation();
        }
    }

    public static boolean c(String[] strArr) {
        for (String str : strArr) {
            if (Build.MODEL.contains(str)) {
                return true;
            }
        }
        return false;
    }
}