package com.facetec.sdk;

import android.app.FragmentTransaction;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.graphics.ImageFormat;
import android.graphics.PointF;
import android.graphics.drawable.GradientDrawable;
import android.media.AudioTrack;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.os.PowerManager;
import android.os.Process;
import android.os.SystemClock;
import android.telephony.cdma.CdmaCellLocation;
import android.text.AndroidCharacter;
import android.text.TextUtils;
import android.util.Base64;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewConfiguration;
import android.view.ViewGroup;
import android.view.ViewOutlineProvider;
import android.view.ViewPropertyAnimator;
import android.widget.ExpandableListView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.Toast;
import android.window.OnBackInvokedCallback;
import androidx.core.view.WindowInsetsCompat;
import com.facetec.sdk.FaceTecCancelButtonCustomization;
import com.facetec.sdk.FaceTecSDK;
import com.facetec.sdk.FaceTecVocalGuidanceCustomization;
import com.facetec.sdk.au;
import com.facetec.sdk.bm;
import com.facetec.sdk.bv;
import com.facetec.sdk.cx;
import com.facetec.sdk.dk;
import com.facetec.sdk.ed;
import com.facetec.sdk.gn;
import com.facetec.sdk.pg;
import com.facetec.sdk.t;
import com.incode.welcome_sdk.modules.SelfieScan;
import com.plaid.internal.EnumC41897g;
import java.lang.reflect.Constructor;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Objects;
import java.util.Timer;
import java.util.TimerTask;
import java.util.UUID;
import kotlin.C6852;
import net.sf.scuba.smartcards.ISO7816;
import net.sf.scuba.smartcards.ISOFileInfo;
import org.bouncycastle.asn1.cmc.BodyPartID;
import org.jmrtd.PassportService;
import org.jmrtd.lds.CVCAFile;
import org.json.JSONObject;

/* JADX INFO: loaded from: classes4.dex */
abstract class bi extends bm implements dk.a {
    private static final byte[] $$a = null;
    private static final int $$b = 0;
    private static final byte[] $$c = null;
    private static final byte[] $$d = null;
    private static final int $$e = 0;
    private static final int $$f = 0;
    private static int $10;
    private static int $11;
    private static int aM;
    private static int aN;
    private static int aQ;
    bv A;
    String D;
    protected boolean G;
    Bitmap I;
    ImageView J;
    private volatile ch K;
    df L;
    cc M;
    View N;
    private volatile byte[][] O;
    private volatile byte[][] P;
    private volatile bu Q;
    private volatile byte[] R;
    private volatile d S;
    private volatile di T;
    private FaceTecIDScanResult aA;
    private TimerTask aD;
    private TimerTask aE;
    private Timer aF;
    private Timer aG;
    private OnBackInvokedCallback aI;
    private cr aL;
    private ah aj;
    private int an;
    private View ao;
    private RelativeLayout ap;
    private RelativeLayout as;
    private RelativeLayout at;
    private LinearLayout au;
    private RelativeLayout av;
    private String ax;
    private volatile bd c;
    private volatile cx f;
    volatile by h;
    volatile dd i;
    m k;
    String l;
    float n;
    float o;
    cf s;
    RelativeLayout u;
    RelativeLayout v;
    ImageView w;
    View x;
    RelativeLayout y;
    FaceTecSessionResult z;
    private boolean V = false;
    private boolean W = false;
    private boolean U = false;
    private boolean X = false;
    private boolean Y = false;
    private boolean aa = false;
    private boolean Z = false;
    private boolean ac = false;
    private boolean ab = false;
    private boolean ah = false;
    private boolean ad = false;
    private boolean ag = false;
    private boolean ae = false;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    boolean f95830g = false;
    String j = "";
    boolean m = false;
    private boolean af = false;
    private boolean al = false;

    /* JADX INFO: renamed from: ai, reason: collision with root package name */
    private boolean f95829ai = false;
    private boolean am = false;
    private boolean ak = false;
    boolean t = false;
    int r = 0;
    boolean q = false;
    private boolean aq = false;
    private boolean ar = false;
    boolean p = false;
    private boolean aw = false;
    private boolean aB = false;
    private int ay = 0;
    FaceTecIDScanNextStep B = FaceTecIDScanNextStep.SELECTION_SCREEN;
    private bw az = new bw();
    boolean C = false;
    private JSONObject aC = null;
    boolean F = false;
    boolean E = false;
    private cx.d aK = cx.d.DEFAULT;
    e H = e.NOT_STARTED;
    private boolean aJ = false;
    private final Object aH = new Object();
    private boolean aO = false;

    /* JADX INFO: renamed from: com.facetec.sdk.bi$5, reason: invalid class name */
    public static /* synthetic */ class AnonymousClass5 {
        static final /* synthetic */ int[] c;

        static {
            int[] iArr = new int[FaceTecSDKStatus.values().length];
            c = iArr;
            try {
                iArr[FaceTecSDKStatus.INVALID_DEVICE_KEY_IDENTIFIER.ordinal()] = 1;
            } catch (NoSuchFieldError unused) {
            }
            try {
                c[FaceTecSDKStatus.NETWORK_ISSUES.ordinal()] = 2;
            } catch (NoSuchFieldError unused2) {
            }
            try {
                c[FaceTecSDKStatus.DEVICE_LOCKED_OUT.ordinal()] = 3;
            } catch (NoSuchFieldError unused3) {
            }
            try {
                c[FaceTecSDKStatus.ENCRYPTION_KEY_INVALID.ordinal()] = 4;
            } catch (NoSuchFieldError unused4) {
            }
            try {
                c[FaceTecSDKStatus.DEVICE_IN_LANDSCAPE_MODE.ordinal()] = 5;
            } catch (NoSuchFieldError unused5) {
            }
            try {
                c[FaceTecSDKStatus.DEVICE_IN_REVERSE_PORTRAIT_MODE.ordinal()] = 6;
            } catch (NoSuchFieldError unused6) {
            }
            try {
                c[FaceTecSDKStatus.DEVICE_NOT_SUPPORTED.ordinal()] = 7;
            } catch (NoSuchFieldError unused7) {
            }
        }
    }

    @FunctionalInterface
    public interface b {
        byte[] getIdScanBytes(String str);
    }

    public enum e {
        NOT_STARTED,
        PRE_SESSION_STARTED,
        FACESCAN_SESSION_STARTED
    }

    private static String $$g(short s, short s2, byte b2) {
        int i = (s * 2) + 4;
        int i2 = 110 - (s2 * 3);
        int i3 = b2 * 2;
        byte[] bArr = $$c;
        byte[] bArr2 = new byte[i3 + 1];
        int i4 = -1;
        if (bArr == null) {
            i++;
            i2 += i3;
        }
        while (true) {
            i4++;
            bArr2[i4] = (byte) i2;
            if (i4 == i3) {
                return new String(bArr2, 0);
            }
            byte b3 = bArr[i];
            i++;
            i2 += b3;
        }
    }

    static {
        init$2();
        $10 = 0;
        $11 = 1;
        init$1();
        init$0();
        aQ = 0;
        aN = 1;
        aM = 1605274442;
    }

    /* JADX WARN: Removed duplicated region for block: B:29:0x00b6  */
    /* JADX WARN: Removed duplicated region for block: B:30:0x00c4  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    private void E() throws java.lang.Throwable {
        /*
            Method dump skipped, instruction units count: 278
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: com.facetec.sdk.bi.E():void");
    }

    private boolean F() {
        aQ = (aN + 25) % 128;
        if (!isFinishing() && hasWindowFocus()) {
            return false;
        }
        aN = (aQ + 101) % 128;
        return true;
    }

    private synchronized boolean G() {
        try {
            int i = aN;
            int i2 = i + 33;
            aQ = i2 % 128;
            if (i2 % 2 != 0) {
                throw null;
            }
            if (!this.W) {
                int i3 = i + 107;
                aQ = i3 % 128;
                if (i3 % 2 != 0) {
                    isFinishing();
                    throw null;
                }
                if (!isFinishing()) {
                    int i4 = aQ + 95;
                    aN = i4 % 128;
                    if (i4 % 2 != 0) {
                        return false;
                    }
                    throw null;
                }
            }
            return true;
        } finally {
        }
    }

    private synchronized void H() {
        int i;
        if (this.f95829ai) {
            return;
        }
        boolean z = true;
        this.f95829ai = true;
        dm.e();
        dm.c(this.N);
        dm.e(this.y);
        try {
            float fJ = ah.j();
            FaceTecSessionActivity faceTecSessionActivity = (FaceTecSessionActivity) this.T.d.get();
            int iA = (int) (bh.a(dm.l()) * dm.c());
            dm.g();
            if (dm.c() < 1.0f) {
                int i2 = dq.c().width;
                if (dq.c) {
                    i = dq.c().height;
                    aQ = (aN + 39) % 128;
                } else {
                    i = (int) (((double) i2) * ((double) fJ));
                }
                float fC = dm.c();
                float f = i2;
                faceTecSessionActivity.o = fC * f;
                faceTecSessionActivity.n = i * fC;
                RelativeLayout.LayoutParams layoutParams = new RelativeLayout.LayoutParams((int) faceTecSessionActivity.o, (int) faceTecSessionActivity.n);
                float f2 = faceTecSessionActivity.o;
                layoutParams.setMargins(((int) (f - f2)) / 2, (iA / 2) + 10, ((int) (f - f2)) / 2, 0);
                faceTecSessionActivity.v.setLayoutParams(layoutParams);
                RelativeLayout.LayoutParams layoutParams2 = new RelativeLayout.LayoutParams(((int) faceTecSessionActivity.o) + iA, ((int) faceTecSessionActivity.n) + iA);
                float f3 = faceTecSessionActivity.o;
                float f4 = iA;
                layoutParams2.setMargins(((int) (f - (f3 + f4))) / 2, 10, ((int) (f - (f3 + f4))) / 2, 0);
                faceTecSessionActivity.u.setLayoutParams(layoutParams2);
                ((View) faceTecSessionActivity.x.getParent()).setLayoutParams(layoutParams2);
                RelativeLayout.LayoutParams layoutParams3 = new RelativeLayout.LayoutParams((int) faceTecSessionActivity.o, (int) faceTecSessionActivity.n);
                layoutParams3.setMargins(0, 0, 0, 0);
                faceTecSessionActivity.av.setLayoutParams(layoutParams3);
                RelativeLayout.LayoutParams layoutParams4 = new RelativeLayout.LayoutParams((int) faceTecSessionActivity.o, (int) faceTecSessionActivity.n);
                layoutParams4.setMargins(0, 0, 0, 0);
                faceTecSessionActivity.at.setLayoutParams(layoutParams4);
                GradientDrawable gradientDrawable = new GradientDrawable();
                float fA = bh.a(((Integer) dm.e(pg.a.a(), pg.a.a(), -547259901, new Object[0], pg.a.a(), 547259923, pg.a.a())).intValue()) * fC;
                gradientDrawable.setCornerRadius(fA);
                int iB = dq.b(faceTecSessionActivity, FaceTecSDK.d.o.borderColor);
                gradientDrawable.setStroke(iA, iB);
                faceTecSessionActivity.v.setBackground(gradientDrawable);
                faceTecSessionActivity.u.setBackground(gradientDrawable);
                RelativeLayout relativeLayout = faceTecSessionActivity.v;
                ViewOutlineProvider viewOutlineProvider = ViewOutlineProvider.BACKGROUND;
                relativeLayout.setOutlineProvider(viewOutlineProvider);
                faceTecSessionActivity.v.setClipToOutline(true);
                if (FaceTecSDK.d.o.elevation > 0) {
                    GradientDrawable gradientDrawable2 = new GradientDrawable();
                    gradientDrawable2.setCornerRadius(fA);
                    gradientDrawable2.setStroke(iA, iB);
                    gradientDrawable2.setColor(dq.b(faceTecSessionActivity, dm.W()));
                    faceTecSessionActivity.x.setBackground(gradientDrawable2);
                    faceTecSessionActivity.x.setElevation(bh.a(FaceTecSDK.d.o.elevation));
                    faceTecSessionActivity.x.setOutlineProvider(viewOutlineProvider);
                    faceTecSessionActivity.x.setClipToOutline(false);
                    faceTecSessionActivity.x.requestLayout();
                }
            }
            FaceTecSessionActivity faceTecSessionActivity2 = (FaceTecSessionActivity) this.T.d.get();
            FaceTecOverlayCustomization faceTecOverlayCustomization = FaceTecSDK.d.h;
            int i3 = faceTecOverlayCustomization.brandingImage;
            if (i3 != 0) {
                int i4 = aN + 15;
                aQ = i4 % 128;
                if (i4 % 2 != 0) {
                    boolean z2 = faceTecOverlayCustomization.showBrandingImage;
                    throw null;
                }
                if (faceTecOverlayCustomization.showBrandingImage) {
                    faceTecSessionActivity2.J.setImageDrawable(C6852.getDrawable(faceTecSessionActivity2, i3));
                    faceTecSessionActivity2.J.setVisibility(0);
                    float f5 = faceTecSessionActivity2.o;
                    if (f5 > SelfieScan.RECOGNITION_FAIL_RESULT) {
                        faceTecSessionActivity2.J.setMaxWidth((int) f5);
                    } else {
                        faceTecSessionActivity2.J.setMaxWidth(dq.c().width);
                    }
                    if ((dq.a((Context) faceTecSessionActivity2).getConfiguration().screenLayout & 15) >= 3) {
                        aQ = (aN + 27) % 128;
                        faceTecSessionActivity2.au.setWeightSum(1.0f);
                        faceTecSessionActivity2.J.setMaxHeight((int) bh.a(50));
                        LinearLayout.LayoutParams layoutParams5 = (LinearLayout.LayoutParams) faceTecSessionActivity2.J.getLayoutParams();
                        ((ViewGroup.MarginLayoutParams) layoutParams5).topMargin = (int) bh.a(15);
                        layoutParams5.gravity = 48;
                        faceTecSessionActivity2.J.setLayoutParams(layoutParams5);
                        faceTecSessionActivity2.J.requestLayout();
                        faceTecSessionActivity2.au.requestLayout();
                    }
                }
            }
            this.T.a();
            if (e() == bm.b.GRANTED) {
                T();
            }
            O();
        } catch (ak e2) {
            c cVar = c.CAMERA_ERROR;
            StringBuilder sb = new StringBuilder("FTCameraException: ");
            sb.append(e2.getMessage());
            String string = sb.toString();
            if (ah.c) {
                z = false;
            } else {
                aQ = (aN + 21) % 128;
            }
            FaceTecSessionStatus faceTecSessionStatus = FaceTecSessionStatus.CAMERA_INITIALIZATION_ISSUE;
            t.d(this, e2, cVar, string, z, faceTecSessionStatus.ordinal());
            e(faceTecSessionStatus, (FaceTecIDScanStatus) null);
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void I() {
        aQ = (aN + 65) % 128;
        if (bk.b()) {
            aN = (aQ + 25) % 128;
            a(FaceTecSessionStatus.NON_PRODUCTION_MODE_NETWORK_REQUIRED);
        }
    }

    private void J() {
        int i = aQ + 63;
        aN = i % 128;
        if (i % 2 == 0) {
            this.c = null;
            this.h = null;
            this.i = null;
            this.f = null;
            this.K = null;
            this.S = null;
            this.Q = null;
            int i2 = 1 / 0;
        } else {
            this.c = null;
            this.h = null;
            this.i = null;
            this.f = null;
            this.K = null;
            this.S = null;
            this.Q = null;
        }
        aN = (aQ + 19) % 128;
    }

    private void K() throws Throwable {
        int i = aN + 95;
        aQ = i % 128;
        if (i % 2 != 0) {
            F();
            throw null;
        }
        if (F()) {
            return;
        }
        this.ag = false;
        FragmentTransaction fragmentTransactionBeginTransaction = getFragmentManager().beginTransaction();
        this.S = new d();
        fragmentTransactionBeginTransaction.setCustomAnimations(R.animator.facetec_no_delay_fade_in, 0).add(this.an, this.S, "AdditionalReview").commitAllowingStateLoss();
        e(1000);
        t.b(dh.RESULT_ADDITIONAL_REVIEW);
        aQ = (aN + 5) % 128;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void L() throws Throwable {
        int i;
        int i2;
        float f;
        Object[] objArr;
        aQ = (aN + 25) % 128;
        Object objD = an.d(-2104069968);
        if (objD == null) {
            int tapTimeout = (ViewConfiguration.getTapTimeout() >> 16) + 1352;
            char cArgb = (char) Color.argb(0, 0, 0, 0);
            int minimumFlingVelocity = (ViewConfiguration.getMinimumFlingVelocity() >> 16) + 24;
            byte b2 = (byte) 0;
            byte b3 = b2;
            Object[] objArr2 = new Object[1];
            aS(b2, b3, b3, objArr2);
            objD = an.d(tapTimeout, cArgb, minimumFlingVelocity, -185097237, false, (String) objArr2[0], null);
        }
        long j = ((Field) objD).getLong(null);
        Object[] objArr3 = new Object[1];
        aU(22 - TextUtils.indexOf("", "", 0, 0), View.getDefaultSize(0, 0) + 126, (ViewConfiguration.getPressedStateDuration() >> 16) + 4, true, "\u000f\u0001\u000b\ufffe\b\u0000\f\t￠\n\u0002\u0011\u0010\u0016\ufff0ￋ\u0010\fￋ\u0001\u0006\f", objArr3);
        Class<?> cls = Class.forName((String) objArr3[0]);
        Object[] objArr4 = new Object[1];
        aU(15 - View.combineMeasuredStates(0, 0), (TypedValue.complexToFraction(0, SelfieScan.RECOGNITION_FAIL_RESULT, SelfieScan.RECOGNITION_FAIL_RESULT) > SelfieScan.RECOGNITION_FAIL_RESULT ? 1 : (TypedValue.complexToFraction(0, SelfieScan.RECOGNITION_FAIL_RESULT, SelfieScan.RECOGNITION_FAIL_RESULT) == SelfieScan.RECOGNITION_FAIL_RESULT ? 0 : -1)) + 130, -ImageFormat.getBitsPerPixel(0), true, "\ufffe\ufffe\u0006\u0002\r\u0005\ufffa\ufffe￫�\ufffe\f\t\ufffa\u0005", objArr4);
        long jLongValue = ((Long) cls.getDeclaredMethod((String) objArr4[0], null).invoke(null, null)).longValue();
        Object objD2 = an.d(-2106840531);
        if (objD2 == null) {
            int i3 = 1352 - (AudioTrack.getMinVolume() > SelfieScan.RECOGNITION_FAIL_RESULT ? 1 : (AudioTrack.getMinVolume() == SelfieScan.RECOGNITION_FAIL_RESULT ? 0 : -1));
            char packedPositionType = (char) ExpandableListView.getPackedPositionType(0L);
            int scrollBarSize = (ViewConfiguration.getScrollBarSize() >> 8) + 24;
            byte b4 = (byte) 0;
            i = -2104069968;
            byte b5 = b4;
            i2 = -2106840531;
            f = 0.0f;
            Object[] objArr5 = new Object[1];
            aS(b4, b5, (byte) (b5 + 3), objArr5);
            objD2 = an.d(i3, packedPositionType, scrollBarSize, -200410762, false, (String) objArr5[0], null);
        } else {
            i = -2104069968;
            i2 = -2106840531;
            f = 0.0f;
        }
        if (j == ((jLongValue - ((((Field) objD2).getLong(null) << 52) >>> 52)) >> 12)) {
            Object objD3 = an.d(-2107764052);
            if (objD3 == null) {
                int absoluteGravity = Gravity.getAbsoluteGravity(0, 0) + 1352;
                char cIndexOf = (char) TextUtils.indexOf("", "", 0);
                int iIndexOf = TextUtils.indexOf("", "") + 24;
                byte b6 = (byte) 0;
                Object[] objArr6 = new Object[1];
                aS(b6, b6, (byte) $$a.length, objArr6);
                objD3 = an.d(absoluteGravity, cIndexOf, iIndexOf, -197148169, false, (String) objArr6[0], null);
            }
            objArr = (Object[]) ((Field) objD3).get(null);
        } else {
            Object[] objArr7 = new Object[1];
            aU((AudioTrack.getMaxVolume() > f ? 1 : (AudioTrack.getMaxVolume() == f ? 0 : -1)) + 15, (ExpandableListView.getPackedPositionForChild(0, 0) > 0L ? 1 : (ExpandableListView.getPackedPositionForChild(0, 0) == 0L ? 0 : -1)) + 126, 1 - TextUtils.lastIndexOf("", '0', 0), false, "\u0003\u000b\b\uffff\u0014\uffffￌ\n\uffff\f\u0005ￌ\ufff1\u0017\u0011\u0012", objArr7);
            Class<?> cls2 = Class.forName((String) objArr7[0]);
            Object[] objArr8 = new Object[1];
            aU(KeyEvent.normalizeMetaState(0) + 16, 129 - TextUtils.getOffsetBefore("", 0), 12 - (ViewConfiguration.getZoomControlsTimeout() > 0L ? 1 : (ViewConfiguration.getZoomControlsTimeout() == 0L ? 0 : -1)), true, "\r\ufffb￢\u0013\u000e\u0003\u000e\b\uffff\ufffe\u0003\uffff\ufffe\t\uffdd\u0002", objArr8);
            int iIntValue = ((Integer) cls2.getMethod((String) objArr8[0], Object.class).invoke(null, this)).intValue();
            try {
                Object[] objArr9 = {-995461662};
                Object objD4 = an.d(-458211269);
                if (objD4 == null) {
                    objD4 = an.d(1328 - KeyEvent.keyCodeFromString(""), (char) (View.combineMeasuredStates(0, 0) + 60543), ImageFormat.getBitsPerPixel(0) + 25, -1831759008, false, null, new Class[]{Integer.TYPE});
                }
                Object[] objArrA$5fe48fd = gn.AnonymousClass18.a$5fe48fd(iIntValue, ((Constructor) objD4).newInstance(objArr9));
                Object objD5 = an.d(-2107764052);
                if (objD5 == null) {
                    int packedPositionChild = ExpandableListView.getPackedPositionChild(0L) + 1353;
                    char cIndexOf2 = (char) (TextUtils.indexOf((CharSequence) "", '0') + 1);
                    int iKeyCodeFromString = KeyEvent.keyCodeFromString("") + 24;
                    byte b7 = (byte) 0;
                    Object[] objArr10 = new Object[1];
                    aS(b7, b7, (byte) $$a.length, objArr10);
                    objD5 = an.d(packedPositionChild, cIndexOf2, iKeyCodeFromString, -197148169, false, (String) objArr10[0], null);
                }
                ((Field) objD5).set(null, objArrA$5fe48fd);
                try {
                    Object[] objArr11 = new Object[1];
                    aU(View.resolveSize(0, 0) + 22, 126 - View.MeasureSpec.getSize(0), Color.alpha(0) + 4, true, "\u000f\u0001\u000b\ufffe\b\u0000\f\t￠\n\u0002\u0011\u0010\u0016\ufff0ￋ\u0010\fￋ\u0001\u0006\f", objArr11);
                    Class<?> cls3 = Class.forName((String) objArr11[0]);
                    Object[] objArr12 = new Object[1];
                    aU(MotionEvent.axisFromString("") + 16, 130 - Gravity.getAbsoluteGravity(0, 0), (SystemClock.elapsedRealtime() > 0L ? 1 : (SystemClock.elapsedRealtime() == 0L ? 0 : -1)), true, "\ufffe\ufffe\u0006\u0002\r\u0005\ufffa\ufffe￫�\ufffe\f\t\ufffa\u0005", objArr12);
                    long jLongValue2 = ((Long) cls3.getDeclaredMethod((String) objArr12[0], null).invoke(null, null)).longValue();
                    Long lValueOf = Long.valueOf(jLongValue2);
                    Object objD6 = an.d(i2);
                    if (objD6 == null) {
                        int packedPositionType2 = 1352 - ExpandableListView.getPackedPositionType(0L);
                        char jumpTapTimeout = (char) (ViewConfiguration.getJumpTapTimeout() >> 16);
                        int edgeSlop = 24 - (ViewConfiguration.getEdgeSlop() >> 16);
                        byte b8 = (byte) 0;
                        byte b9 = b8;
                        Object[] objArr13 = new Object[1];
                        aS(b8, b9, (byte) (b9 + 3), objArr13);
                        objD6 = an.d(packedPositionType2, jumpTapTimeout, edgeSlop, -200410762, false, (String) objArr13[0], null);
                    }
                    ((Field) objD6).set(null, lValueOf);
                    Long lValueOf2 = Long.valueOf(jLongValue2 >> 12);
                    Object objD7 = an.d(i);
                    if (objD7 == null) {
                        int iIndexOf2 = TextUtils.indexOf("", "") + 1352;
                        char minimumFlingVelocity2 = (char) (ViewConfiguration.getMinimumFlingVelocity() >> 16);
                        int mode = 24 - View.MeasureSpec.getMode(0);
                        byte b10 = (byte) 0;
                        byte b11 = b10;
                        Object[] objArr14 = new Object[1];
                        aS(b10, b11, b11, objArr14);
                        objD7 = an.d(iIndexOf2, minimumFlingVelocity2, mode, -185097237, false, (String) objArr14[0], null);
                    }
                    ((Field) objD7).set(null, lValueOf2);
                    aN = (aQ + 13) % 128;
                    objArr = objArrA$5fe48fd;
                } catch (Exception unused) {
                    throw new RuntimeException();
                }
            } catch (Throwable th) {
                Throwable cause = th.getCause();
                if (cause == null) {
                    throw th;
                }
                throw cause;
            }
        }
        int i4 = ((int[]) objArr[3])[0];
        int i5 = ((int[]) objArr[1])[0];
        if (i5 != i4) {
            ArrayList arrayList = new ArrayList();
            String[] strArr = (String[]) objArr[2];
            if (strArr != null) {
                aN = (aQ + 15) % 128;
                int i6 = 0;
                while (i6 < strArr.length) {
                    int i7 = aN + 91;
                    aQ = i7 % 128;
                    if (i7 % 2 != 0) {
                        arrayList.add(strArr[i6]);
                        i6 += 102;
                    } else {
                        arrayList.add(strArr[i6]);
                        i6++;
                    }
                }
            }
            long j2 = (((long) (i4 ^ i5)) & BodyPartID.bodyIdMax) ^ (-1846733296151560192L);
            aQ = (aN + 15) % 128;
            try {
                Object[] objArr15 = {Long.valueOf(j2), -429976104L};
                byte[] bArr = $$d;
                byte b12 = bArr[9];
                byte b13 = b12;
                Object[] objArr16 = new Object[1];
                aW(b13, (byte) (b13 + 1), (byte) (-b12), objArr16);
                Class<?> cls4 = Class.forName((String) objArr16[0]);
                byte b14 = (byte) ($$e & 80);
                byte b15 = (byte) (-bArr[9]);
                Object[] objArr17 = new Object[1];
                aW(b14, b15, (byte) (b15 - 1), objArr17);
                String str = (String) objArr17[0];
                Class cls5 = Long.TYPE;
                cls4.getMethod(str, cls5, cls5).invoke(null, objArr15);
            } catch (Throwable th2) {
                Throwable cause2 = th2.getCause();
                if (cause2 == null) {
                    throw th2;
                }
                throw cause2;
            }
        }
    }

    private void M() throws Throwable {
        aQ = (aN + 55) % 128;
        if (F()) {
            aN = (aQ + 59) % 128;
            return;
        }
        this.ad = false;
        FragmentTransaction fragmentTransactionBeginTransaction = getFragmentManager().beginTransaction();
        this.K = ch.d(this.aC);
        fragmentTransactionBeginTransaction.setCustomAnimations(R.animator.facetec_no_delay_fade_in, 0).add(this.an, this.K, "OCRConfirmation").commitAllowingStateLoss();
        e(1000);
        t.b(dh.RESULT_OCR);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void N() throws Throwable {
        aQ = (aN + 51) % 128;
        if (F()) {
            int i = aQ + 81;
            aN = i % 128;
            if (i % 2 == 0) {
                int i2 = 38 / 0;
                return;
            }
            return;
        }
        this.ae = false;
        this.aB = true;
        FragmentTransaction fragmentTransactionBeginTransaction = getFragmentManager().beginTransaction();
        this.Q = new bu();
        fragmentTransactionBeginTransaction.setCustomAnimations(R.animator.facetec_no_delay_fade_in, 0).add(this.an, this.Q, "IDFeedback").commitAllowingStateLoss();
        e(1000);
        t.b(dh.RESULT_ID_FEEDBACK);
    }

    private synchronized void O() {
        try {
            int i = aN + 61;
            aQ = i % 128;
            if (i % 2 != 0) {
                e();
                cv.d();
                boolean z = FaceTecSDK.d.enableOfficialIDPhoto;
                throw null;
            }
            bm.b bVarE = e();
            cv.d();
            if (FaceTecSDK.d.enableOfficialIDPhoto) {
                cv.X();
            }
            cc ccVar = this.M;
            float fA = ccVar.a();
            ccVar.b = fA;
            if (fA > 0.70000005f) {
                ccVar.d = true;
                ccVar.a(fA, 0.6f, 0);
            }
            if (bVarE == bm.b.GRANTED && !this.f95830g) {
                if (this.aj == null) {
                    c("Begin Verification");
                    return;
                }
                this.aO = true;
                try {
                    if (this.am) {
                        aQ = (aN + 57) % 128;
                        this.as.setVisibility(0);
                        this.aj.d(new Runnable() { // from class: com.facetec.sdk.乐鬼
                            @Override // java.lang.Runnable
                            public final void run() {
                                this.f6867.aK();
                            }
                        });
                    }
                    aN = (aQ + 1) % 128;
                } catch (Exception unused) {
                }
                this.aj.d();
            }
            t.c = bk.b();
            t.e = 0;
            this.h = by.a(bVarE, this.f95830g);
            getFragmentManager().beginTransaction().replace(this.an, this.h, "PreEnroll").commitAllowingStateLoss();
        } catch (Throwable th) {
            throw th;
        }
    }

    private synchronized void P() {
        this.c = bd.d();
        if (this.aj == null) {
            aN = (aQ + 9) % 128;
            this.aj = ah.a(this.as, this, false, false);
            t.d(this, c.FACESCAN_CAMERA_CREATED, null, null);
            this.am = this.aj instanceof am;
            aN = (aQ + 99) % 128;
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void Q() {
        int i = aQ;
        aN = (i + 109) % 128;
        if (!this.aO) {
            aN = (i + 15) % 128;
            return;
        }
        this.aO = false;
        runOnUiThread(new Runnable() { // from class: com.facetec.sdk.乐书
            @Override // java.lang.Runnable
            public final void run() {
                this.f6802.aI();
            }
        });
        int i2 = aQ + 85;
        aN = i2 % 128;
        if (i2 % 2 == 0) {
            throw null;
        }
    }

    /* JADX WARN: Code restructure failed: missing block: B:108:0x0186, code lost:
    
        if (e() != com.facetec.sdk.bm.b.b) goto L114;
     */
    /* JADX WARN: Code restructure failed: missing block: B:113:0x0191, code lost:
    
        if (e() != com.facetec.sdk.bm.b.b) goto L114;
     */
    /* JADX WARN: Code restructure failed: missing block: B:114:0x0193, code lost:
    
        s();
     */
    /* JADX WARN: Code restructure failed: missing block: B:116:0x0197, code lost:
    
        return;
     */
    /* JADX WARN: Code restructure failed: missing block: B:117:0x0198, code lost:
    
        k();
     */
    /* JADX WARN: Code restructure failed: missing block: B:119:0x019c, code lost:
    
        return;
     */
    /* JADX WARN: Removed duplicated region for block: B:30:0x0059 A[Catch: all -> 0x001e, TryCatch #3 {all -> 0x001e, blocks: (B:3:0x0001, B:7:0x0009, B:9:0x0010, B:11:0x0014, B:16:0x0021, B:19:0x0031, B:21:0x0036, B:23:0x0042, B:70:0x00d6, B:71:0x00e7, B:73:0x00ed, B:75:0x00f6, B:77:0x0104, B:79:0x0110, B:81:0x0115, B:83:0x0119, B:85:0x011f, B:86:0x0133, B:89:0x013a, B:91:0x0140, B:94:0x014a, B:96:0x014e, B:98:0x015a, B:101:0x016b, B:103:0x0171, B:105:0x017d, B:117:0x0198, B:114:0x0193, B:111:0x018a, B:112:0x018b, B:120:0x019d, B:26:0x004e, B:29:0x0058, B:30:0x0059, B:32:0x005d, B:34:0x0065, B:35:0x006b, B:37:0x0071, B:38:0x0076, B:40:0x007a, B:42:0x0082, B:44:0x0086, B:46:0x0092, B:51:0x0099, B:52:0x009a, B:53:0x009f, B:55:0x00a3, B:58:0x00ac, B:60:0x00be, B:61:0x00c3, B:63:0x00c8, B:65:0x00cc, B:67:0x00d0, B:27:0x0056, B:49:0x0097, B:62:0x00c7, B:107:0x0185), top: B:132:0x0001 }] */
    /* JADX WARN: Removed duplicated region for block: B:53:0x009f A[Catch: all -> 0x001e, TryCatch #3 {all -> 0x001e, blocks: (B:3:0x0001, B:7:0x0009, B:9:0x0010, B:11:0x0014, B:16:0x0021, B:19:0x0031, B:21:0x0036, B:23:0x0042, B:70:0x00d6, B:71:0x00e7, B:73:0x00ed, B:75:0x00f6, B:77:0x0104, B:79:0x0110, B:81:0x0115, B:83:0x0119, B:85:0x011f, B:86:0x0133, B:89:0x013a, B:91:0x0140, B:94:0x014a, B:96:0x014e, B:98:0x015a, B:101:0x016b, B:103:0x0171, B:105:0x017d, B:117:0x0198, B:114:0x0193, B:111:0x018a, B:112:0x018b, B:120:0x019d, B:26:0x004e, B:29:0x0058, B:30:0x0059, B:32:0x005d, B:34:0x0065, B:35:0x006b, B:37:0x0071, B:38:0x0076, B:40:0x007a, B:42:0x0082, B:44:0x0086, B:46:0x0092, B:51:0x0099, B:52:0x009a, B:53:0x009f, B:55:0x00a3, B:58:0x00ac, B:60:0x00be, B:61:0x00c3, B:63:0x00c8, B:65:0x00cc, B:67:0x00d0, B:27:0x0056, B:49:0x0097, B:62:0x00c7, B:107:0x0185), top: B:132:0x0001 }] */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    private synchronized void R() {
        /*
            Method dump skipped, instruction units count: 422
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: com.facetec.sdk.bi.R():void");
    }

    private synchronized void S() {
        if (G()) {
            aN = (aQ + 87) % 128;
            return;
        }
        if (this.aj == null) {
            aQ = (aN + 101) % 128;
            c("Start FaceScan");
            return;
        }
        ImageView imageView = this.w;
        if (imageView != null) {
            imageView.setEnabled(false);
            new Handler(Looper.getMainLooper()).postDelayed(new Runnable() { // from class: com.facetec.sdk.乐海
                @Override // java.lang.Runnable
                public final void run() {
                    this.f6845.aJ();
                }
            }, 800L);
            aN = (aQ + 67) % 128;
        }
        this.aj.d();
        if (FaceTecSDK.a()) {
            cc ccVar = this.M;
            if (!ccVar.e) {
                ccVar.e = true;
                ccVar.d = false;
                ccVar.a = false;
                ccVar.a(ccVar.i.e(), ccVar.i.b ? 0.55f : 0.8f, 0);
            }
        }
        FragmentTransaction fragmentTransactionBeginTransaction = getFragmentManager().beginTransaction();
        if (this.h == null && this.i == null) {
            fragmentTransactionBeginTransaction.setCustomAnimations(R.animator.facetec_no_delay_fade_in, 0).replace(this.an, this.c, "FaceScan").commitAllowingStateLoss();
        } else {
            fragmentTransactionBeginTransaction.replace(this.an, this.c, "FaceScan").commitAllowingStateLoss();
            this.h = null;
            this.i = null;
        }
        ed.d(this);
    }

    private synchronized void T() {
        int i = aN;
        int i2 = i + 25;
        aQ = i2 % 128;
        if (i2 % 2 != 0) {
            throw null;
        }
        if (FaceTecSessionActivity.c != null) {
            P();
            return;
        }
        boolean z = this.f95830g;
        if (!z) {
            t.d(this, c.UNEXPECTED_EARLY_EXIT_FACESCAN, "Error when setting up primary fragment", null);
            e(FaceTecSessionStatus.UNKNOWN_INTERNAL_ERROR, FaceTecIDScanStatus.UNSUCCESS);
            return;
        }
        aQ = (i + 95) % 128;
        this.A = bv.b(false, z);
        int i3 = aQ + 107;
        aN = i3 % 128;
        if (i3 % 2 != 0) {
            return;
        } else {
            throw null;
        }
    }

    private void U() {
        aN = (aQ + 87) % 128;
        this.aB = true;
        if (this.A == null || F()) {
            return;
        }
        e(this.az, this.ax);
        int i = aQ + 87;
        aN = i % 128;
        if (i % 2 == 0) {
            throw null;
        }
    }

    private void V() {
        final View viewC;
        int i = (aQ + 99) % 128;
        aN = i;
        ah ahVar = this.aj;
        if (ahVar != null) {
            int i2 = i + 87;
            aQ = i2 % 128;
            if (i2 % 2 != 0) {
                ahVar.c();
                throw null;
            }
            viewC = ahVar.c();
        } else {
            viewC = null;
        }
        dm.j(this.y);
        this.y.animate().alpha(1.0f).setDuration(500L).setListener(null).withEndAction(new Runnable() { // from class: com.facetec.sdk.乐乐
            @Override // java.lang.Runnable
            public final void run() {
                this.f6800.e(viewC);
            }
        }).start();
        e(false);
        aQ = (aN + 29) % 128;
    }

    private void W() {
        boolean z;
        int i = aQ + 55;
        aN = i % 128;
        if (i % 2 == 0) {
            cv.O(ed.b());
            z = false;
        } else {
            cv.O(ed.b());
            z = true;
        }
        bd.a = z;
        t.d(this, c.PRE_SESSION_PHASE_2_START, null, null);
        int i2 = aN + 53;
        aQ = i2 % 128;
        if (i2 % 2 != 0) {
            throw null;
        }
    }

    private void X() throws Throwable {
        int i = aQ;
        aN = (i + 77) % 128;
        this.ae = true;
        if (this.ay == 1) {
            aN = (i + 5) % 128;
            d(new Runnable() { // from class: com.facetec.sdk.丹水
                @Override // java.lang.Runnable
                public final void run() throws Throwable {
                    this.f6768.N();
                }
            });
        } else if (!(!ae())) {
            this.f.d(new Runnable() { // from class: com.facetec.sdk.丹水
                @Override // java.lang.Runnable
                public final void run() throws Throwable {
                    this.f6768.N();
                }
            });
        } else {
            N();
        }
    }

    private void Y() {
        aN = (aQ + 15) % 128;
        Timer timer = this.aG;
        if (timer != null) {
            timer.cancel();
            this.aG = null;
        }
        TimerTask timerTask = this.aD;
        if (timerTask != null) {
            timerTask.cancel();
            this.aD = null;
            aQ = (aN + 87) % 128;
        }
    }

    private void Z() {
        this.aw = true;
        this.D = UUID.randomUUID().toString();
        this.e.c(this.A.o);
        getFragmentManager().beginTransaction().replace(this.an, this.A, "IDScan").commitAllowingStateLoss();
        if (this.f95830g) {
            aQ = (aN + 73) % 128;
            e(FaceTecOCRConfirmationCustomization.d(), 1365199073, -1365199063, FaceTecOCRConfirmationCustomization.d(), new Object[]{this, t.b.USER_WAS_SUCCESSFUL, Boolean.TRUE}, FaceTecOCRConfirmationCustomization.d(), FaceTecOCRConfirmationCustomization.d());
            aN = (aQ + 73) % 128;
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void aA() {
        int i = aQ + 37;
        aN = i % 128;
        int i2 = i % 2;
        Q();
        if (i2 == 0) {
            int i3 = 50 / 0;
        }
        int i4 = aN + 59;
        aQ = i4 % 128;
        if (i4 % 2 != 0) {
            int i5 = 53 / 0;
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void aB() throws Throwable {
        aQ = (aN + 65) % 128;
        if (!F()) {
            E();
            return;
        }
        int i = aN + 47;
        aQ = i % 128;
        if (i % 2 != 0) {
            int i2 = 89 / 0;
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void aC() throws Throwable {
        int i = aN + 63;
        aQ = i % 128;
        if (i % 2 == 0) {
            E();
        } else {
            E();
            int i2 = 79 / 0;
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void aD() {
        e(FaceTecOCRConfirmationCustomization.d(), 1224265264, -1224265261, FaceTecOCRConfirmationCustomization.d(), new Object[]{this}, FaceTecOCRConfirmationCustomization.d(), FaceTecOCRConfirmationCustomization.d());
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void aE() {
        aQ = (aN + 61) % 128;
        e(false);
        aQ = (aN + 111) % 128;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void aF() {
        int i = aN + 77;
        aQ = i % 128;
        if (i % 2 != 0) {
            getFragmentManager().beginTransaction().replace(this.an, this.f, "Results").addToBackStack("zoom").commitAllowingStateLoss();
            throw null;
        }
        getFragmentManager().beginTransaction().replace(this.an, this.f, "Results").addToBackStack("zoom").commitAllowingStateLoss();
        aN = (aQ + 77) % 128;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void aG() {
        e(FaceTecOCRConfirmationCustomization.d(), -1306312186, 1306312206, FaceTecOCRConfirmationCustomization.d(), new Object[]{this}, FaceTecOCRConfirmationCustomization.d(), FaceTecOCRConfirmationCustomization.d());
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void aH() {
        e(FaceTecOCRConfirmationCustomization.d(), -1711652342, 1711652367, FaceTecOCRConfirmationCustomization.d(), new Object[]{this}, FaceTecOCRConfirmationCustomization.d(), FaceTecOCRConfirmationCustomization.d());
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void aI() {
        int i = aN + 7;
        aQ = i % 128;
        int i2 = i % 2;
        this.y.animate().alpha(SelfieScan.RECOGNITION_FAIL_RESULT).setDuration(500L).setListener(null).start();
        int i3 = aN + 9;
        aQ = i3 % 128;
        if (i3 % 2 != 0) {
            int i4 = 56 / 0;
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void aJ() {
        int i = (aQ + 31) % 128;
        aN = i;
        ImageView imageView = this.w;
        if (imageView != null) {
            aQ = (i + 79) % 128;
            imageView.setEnabled(true);
        }
        aQ = (aN + 99) % 128;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void aK() {
        aN = (aQ + 69) % 128;
        Q();
        aN = (aQ + 113) % 128;
    }

    /* JADX INFO: Access modifiers changed from: private */
    /* JADX WARN: Code restructure failed: missing block: B:12:0x0037, code lost:
    
        if (r3.aj == null) goto L16;
     */
    /* JADX WARN: Code restructure failed: missing block: B:15:0x003c, code lost:
    
        if (r3.aj == null) goto L16;
     */
    /* JADX WARN: Code restructure failed: missing block: B:16:0x003e, code lost:
    
        c("Transition in Main Interface");
     */
    /* JADX WARN: Code restructure failed: missing block: B:17:0x0043, code lost:
    
        return;
     */
    /* JADX WARN: Code restructure failed: missing block: B:18:0x0044, code lost:
    
        r3.aj.d(new com.facetec.sdk.RunnableC2420(r3));
     */
    /* JADX WARN: Code restructure failed: missing block: B:19:0x004e, code lost:
    
        return;
     */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public /* synthetic */ void aL() throws java.lang.Throwable {
        /*
            r3 = this;
            com.facetec.sdk.bm$b r0 = r3.e()
            com.facetec.sdk.bm$b r1 = com.facetec.sdk.bm.b.GRANTED
            if (r0 != r1) goto L4e
            int r0 = com.facetec.sdk.bi.aN
            int r0 = r0 + 17
            int r0 = r0 % 128
            com.facetec.sdk.bi.aQ = r0
            boolean r0 = r3.f95830g
            if (r0 == 0) goto L15
            goto L4e
        L15:
            android.widget.RelativeLayout r0 = r3.as
            r1 = 0
            r0.setVisibility(r1)
            android.widget.RelativeLayout r0 = r3.as
            r2 = 1065353216(0x3f800000, float:1.0)
            r0.setAlpha(r2)
            boolean r0 = r3.aO
            if (r0 == 0) goto L4e
            int r0 = com.facetec.sdk.bi.aQ
            int r0 = r0 + 63
            int r2 = r0 % 128
            com.facetec.sdk.bi.aN = r2
            int r0 = r0 % 2
            if (r0 != 0) goto L3a
            com.facetec.sdk.ah r0 = r3.aj
            r2 = 47
            int r2 = r2 / r1
            if (r0 != 0) goto L44
            goto L3e
        L3a:
            com.facetec.sdk.ah r0 = r3.aj
            if (r0 != 0) goto L44
        L3e:
            java.lang.String r0 = "Transition in Main Interface"
            r3.c(r0)
            return
        L44:
            com.facetec.sdk.ah r0 = r3.aj
            com.facetec.sdk.乐地 r1 = new com.facetec.sdk.乐地
            r1.<init>()
            r0.d(r1)
        L4e:
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: com.facetec.sdk.bi.aL():void");
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void aM() {
        aQ = (aN + 99) % 128;
        e(0);
        aQ = (aN + 89) % 128;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void aN() {
        int i = aQ + 7;
        aN = i % 128;
        e(i % 2 == 0);
        aQ = (aN + 53) % 128;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void aO() {
        aN = (aQ + 19) % 128;
        if (F() || this.A == null) {
            int i = aQ + EnumC41897g.SDK_ASSET_ILLUSTRATION_DEPOSIT_SWITCH_VALUE;
            aN = i % 128;
            if (i % 2 == 0) {
                throw null;
            }
            return;
        }
        A();
        int i2 = aN + 3;
        aQ = i2 % 128;
        if (i2 % 2 != 0) {
            int i3 = 33 / 0;
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void aP() throws Throwable {
        int i;
        char c;
        int i2;
        char c2;
        Object[] objArr;
        char c3;
        float f;
        char c4;
        Object[] objArr2;
        Object objD = an.d(-1397726040);
        if (objD == null) {
            int iIndexOf = 710 - TextUtils.indexOf((CharSequence) "", '0', 0, 0);
            char keyRepeatDelay = (char) ((ViewConfiguration.getKeyRepeatDelay() >> 16) + 49308);
            int i3 = (ViewConfiguration.getScrollFriction() > SelfieScan.RECOGNITION_FAIL_RESULT ? 1 : (ViewConfiguration.getScrollFriction() == SelfieScan.RECOGNITION_FAIL_RESULT ? 0 : -1)) + 23;
            byte b2 = (byte) 0;
            byte b3 = b2;
            Object[] objArr3 = new Object[1];
            aS(b2, b3, (byte) (b3 + 2), objArr3);
            objD = an.d(iIndexOf, keyRepeatDelay, i3, -623790093, false, (String) objArr3[0], null);
        }
        long j = ((Field) objD).getLong(null);
        Object[] objArr4 = new Object[1];
        aU(Color.red(0) + 22, 126 - View.resolveSizeAndState(0, 0, 0), 4 - (ExpandableListView.getPackedPositionForGroup(0) > 0L ? 1 : (ExpandableListView.getPackedPositionForGroup(0) == 0L ? 0 : -1)), true, "\u000f\u0001\u000b\ufffe\b\u0000\f\t￠\n\u0002\u0011\u0010\u0016\ufff0ￋ\u0010\fￋ\u0001\u0006\f", objArr4);
        Class<?> cls = Class.forName((String) objArr4[0]);
        Object[] objArr5 = new Object[1];
        aU('?' - AndroidCharacter.getMirror('0'), 130 - Color.blue(0), (ViewConfiguration.getTouchSlop() >> 8) + 1, true, "\ufffe\ufffe\u0006\u0002\r\u0005\ufffa\ufffe￫�\ufffe\f\t\ufffa\u0005", objArr5);
        long jLongValue = ((Long) cls.getDeclaredMethod((String) objArr5[0], null).invoke(null, null)).longValue();
        Object objD2 = an.d(-1398649561);
        if (objD2 == null) {
            int keyRepeatDelay2 = (ViewConfiguration.getKeyRepeatDelay() >> 16) + 711;
            char cIndexOf = (char) (TextUtils.indexOf("", "") + 49308);
            int tapTimeout = (ViewConfiguration.getTapTimeout() >> 16) + 24;
            i = -1397726040;
            byte b4 = (byte) 0;
            i2 = 49308;
            byte b5 = b4;
            c = '0';
            Object[] objArr6 = new Object[1];
            aS(b4, b5, (byte) (b5 + 3), objArr6);
            objD2 = an.d(keyRepeatDelay2, cIndexOf, tapTimeout, -624714116, false, (String) objArr6[0], null);
        } else {
            i = -1397726040;
            c = '0';
            i2 = 49308;
        }
        if (j == ((jLongValue - ((((Field) objD2).getLong(null) << 52) >>> 52)) >> 12)) {
            aN = (aQ + 99) % 128;
            Object objD3 = an.d(-1399573082);
            if (objD3 == null) {
                int maximumDrawingCacheSize = (ViewConfiguration.getMaximumDrawingCacheSize() >> 24) + 711;
                char packedPositionType = (char) (i2 - ExpandableListView.getPackedPositionType(0L));
                int i4 = (PointF.length(SelfieScan.RECOGNITION_FAIL_RESULT, SelfieScan.RECOGNITION_FAIL_RESULT) > SelfieScan.RECOGNITION_FAIL_RESULT ? 1 : (PointF.length(SelfieScan.RECOGNITION_FAIL_RESULT, SelfieScan.RECOGNITION_FAIL_RESULT) == SelfieScan.RECOGNITION_FAIL_RESULT ? 0 : -1)) + 24;
                byte b6 = (byte) 0;
                Object[] objArr7 = new Object[1];
                aS(b6, b6, (byte) $$a.length, objArr7);
                objD3 = an.d(maximumDrawingCacheSize, packedPositionType, i4, -621418755, false, (String) objArr7[0], null);
            }
            Object[] objArr8 = (Object[]) ((Field) objD3).get(null);
            objArr = new Object[]{strArr, new int[]{i}, new int[]{i}, new int[1]};
            int i5 = ((int[]) objArr8[1])[0];
            int i6 = ((int[]) objArr8[2])[0];
            String[] strArr = (String[]) objArr8[0];
            int iIdentityHashCode = System.identityHashCode(this);
            int i7 = ~((-874766553) | iIdentityHashCode);
            int i8 = ~iIdentityHashCode;
            int i9 = 673781934 + ((i7 | (~(172020806 | i8))) * (-1808)) + (((~((-49217) | iIdentityHashCode)) | (~(i8 | 1046738142))) * 904) + (((~(iIdentityHashCode | (-172020807))) | 874717336 | (~(874766552 | i8))) * 904) + 925601011;
            int i10 = (i9 << 13) ^ i9;
            int i11 = i10 ^ (i10 >>> 17);
            ((int[]) objArr[3])[0] = i11 ^ (i11 << 5);
            aQ = (aN + 19) % 128;
            c2 = '\f';
            c3 = 2;
            f = 0.0f;
            c4 = 3;
        } else {
            Object[] objArr9 = new Object[1];
            aU((KeyEvent.getMaxKeyCode() >> 16) + 16, (Process.myTid() >> 22) + 125, Color.rgb(0, 0, 0) + 16777218, false, "\u0003\u000b\b\uffff\u0014\uffffￌ\n\uffff\f\u0005ￌ\ufff1\u0017\u0011\u0012", objArr9);
            Class<?> cls2 = Class.forName((String) objArr9[0]);
            Object[] objArr10 = new Object[1];
            aU(((Process.getThreadPriority(0) + 20) >> 6) + 16, Color.green(0) + 129, (-16777205) - Color.rgb(0, 0, 0), true, "\r\ufffb￢\u0013\u000e\u0003\u000e\b\uffff\ufffe\u0003\uffff\ufffe\t\uffdd\u0002", objArr10);
            int iIntValue = ((Integer) cls2.getMethod((String) objArr10[0], Object.class).invoke(null, this)).intValue();
            try {
                Object[] objArr11 = {317600837};
                Object objD4 = an.d(1683332522);
                if (objD4 == null) {
                    objD4 = an.d(831 - (ViewConfiguration.getZoomControlsTimeout() > 0L ? 1 : (ViewConfiguration.getZoomControlsTimeout() == 0L ? 0 : -1)), (char) ((SystemClock.elapsedRealtimeNanos() > 0L ? 1 : (SystemClock.elapsedRealtimeNanos() == 0L ? 0 : -1)) - 1), (AudioTrack.getMinVolume() > SelfieScan.RECOGNITION_FAIL_RESULT ? 1 : (AudioTrack.getMinVolume() == SelfieScan.RECOGNITION_FAIL_RESULT ? 0 : -1)) + 24, 305417969, false, null, new Class[]{Integer.TYPE});
                }
                Object[] objArr12 = {Integer.valueOf(iIntValue), 0, 925601011, ((Constructor) objD4).newInstance(objArr11), Boolean.FALSE};
                Object objD5 = an.d(1794077343);
                if (objD5 == null) {
                    int bitsPerPixel = 710 - ImageFormat.getBitsPerPixel(0);
                    char c5 = (char) ((CdmaCellLocation.convertQuartSecToDecDegrees(0) > 0.0d ? 1 : (CdmaCellLocation.convertQuartSecToDecDegrees(0) == 0.0d ? 0 : -1)) + i2);
                    int iKeyCodeFromString = KeyEvent.keyCodeFromString("") + 24;
                    byte b7 = (byte) 0;
                    byte b8 = b7;
                    c2 = '\f';
                    Object[] objArr13 = new Object[1];
                    aS(b7, b8, (byte) (b8 + 3), objArr13);
                    String str = (String) objArr13[0];
                    Class cls3 = Integer.TYPE;
                    objD5 = an.d(bitsPerPixel, c5, iKeyCodeFromString, 479109572, false, str, new Class[]{cls3, cls3, cls3, (Class) an.b(799 - (ViewConfiguration.getScrollDefaultDelay() >> 16), (char) (ExpandableListView.getPackedPositionForGroup(0) > 0L ? 1 : (ExpandableListView.getPackedPositionForGroup(0) == 0L ? 0 : -1)), (AudioTrack.getMinVolume() > SelfieScan.RECOGNITION_FAIL_RESULT ? 1 : (AudioTrack.getMinVolume() == SelfieScan.RECOGNITION_FAIL_RESULT ? 0 : -1)) + 31), Boolean.TYPE});
                } else {
                    c2 = '\f';
                }
                objArr = (Object[]) ((Method) objD5).invoke(null, objArr12);
                Object objD6 = an.d(-1399573082);
                if (objD6 == null) {
                    int packedPositionType2 = 711 - ExpandableListView.getPackedPositionType(0L);
                    char c6 = (char) (49309 - (ViewConfiguration.getScrollFriction() > SelfieScan.RECOGNITION_FAIL_RESULT ? 1 : (ViewConfiguration.getScrollFriction() == SelfieScan.RECOGNITION_FAIL_RESULT ? 0 : -1)));
                    int mode = View.MeasureSpec.getMode(0) + 24;
                    byte b9 = (byte) 0;
                    Object[] objArr14 = new Object[1];
                    aS(b9, b9, (byte) $$a.length, objArr14);
                    objD6 = an.d(packedPositionType2, c6, mode, -621418755, false, (String) objArr14[0], null);
                }
                ((Field) objD6).set(null, objArr);
                try {
                    Object[] objArr15 = new Object[1];
                    aU('F' - AndroidCharacter.getMirror(c), 126 - Gravity.getAbsoluteGravity(0, 0), 3 - TextUtils.lastIndexOf("", c, 0), true, "\u000f\u0001\u000b\ufffe\b\u0000\f\t￠\n\u0002\u0011\u0010\u0016\ufff0ￋ\u0010\fￋ\u0001\u0006\f", objArr15);
                    Class<?> cls4 = Class.forName((String) objArr15[0]);
                    Object[] objArr16 = new Object[1];
                    aU(Color.argb(0, 0, 0, 0) + 15, ExpandableListView.getPackedPositionType(0L) + 130, 1 - View.resolveSize(0, 0), true, "\ufffe\ufffe\u0006\u0002\r\u0005\ufffa\ufffe￫�\ufffe\f\t\ufffa\u0005", objArr16);
                    long jLongValue2 = ((Long) cls4.getDeclaredMethod((String) objArr16[0], null).invoke(null, null)).longValue();
                    Long lValueOf = Long.valueOf(jLongValue2);
                    Object objD7 = an.d(-1398649561);
                    if (objD7 == null) {
                        int i12 = (ExpandableListView.getPackedPositionForChild(0, 0) > 0L ? 1 : (ExpandableListView.getPackedPositionForChild(0, 0) == 0L ? 0 : -1)) + 712;
                        char touchSlop = (char) (i2 - (ViewConfiguration.getTouchSlop() >> 8));
                        int doubleTapTimeout = (ViewConfiguration.getDoubleTapTimeout() >> 16) + 24;
                        byte b10 = (byte) 0;
                        c3 = 2;
                        byte b11 = b10;
                        f = 0.0f;
                        c4 = 3;
                        Object[] objArr17 = new Object[1];
                        aS(b10, b11, (byte) (b11 + 3), objArr17);
                        objD7 = an.d(i12, touchSlop, doubleTapTimeout, -624714116, false, (String) objArr17[0], null);
                    } else {
                        c3 = 2;
                        f = 0.0f;
                        c4 = 3;
                    }
                    ((Field) objD7).set(null, lValueOf);
                    Long lValueOf2 = Long.valueOf(jLongValue2 >> c2);
                    Object objD8 = an.d(i);
                    if (objD8 == null) {
                        int edgeSlop = (ViewConfiguration.getEdgeSlop() >> 16) + 711;
                        char cNormalizeMetaState = (char) (KeyEvent.normalizeMetaState(0) + i2);
                        int iArgb = 24 - Color.argb(0, 0, 0, 0);
                        byte b12 = (byte) 0;
                        byte b13 = b12;
                        Object[] objArr18 = new Object[1];
                        aS(b12, b13, (byte) (b13 + 2), objArr18);
                        objD8 = an.d(edgeSlop, cNormalizeMetaState, iArgb, -623790093, false, (String) objArr18[0], null);
                    }
                    ((Field) objD8).set(null, lValueOf2);
                } catch (Exception unused) {
                    throw new RuntimeException();
                }
            } catch (Throwable th) {
                Throwable cause = th.getCause();
                if (cause == null) {
                    throw th;
                }
                throw cause;
            }
        }
        int i13 = ((int[]) objArr[c3])[0];
        int i14 = ((int[]) objArr[1])[0];
        if (i14 != i13) {
            ArrayList arrayList = new ArrayList();
            String[] strArr2 = (String[]) objArr[0];
            if (strArr2 != null) {
                for (String str2 : strArr2) {
                    arrayList.add(str2);
                }
            }
            throw new RuntimeException(String.valueOf(i14));
        }
        aN = (aQ + 89) % 128;
        Object[] objArr19 = new Object[4];
        objArr19[1] = new int[]{i};
        objArr19[c3] = new int[]{i};
        objArr19[c4] = new int[1];
        int i15 = ((int[]) objArr[c4])[0];
        int i16 = ((int[]) objArr[1])[0];
        int i17 = ((int[]) objArr[c3])[0];
        objArr19[0] = (String[]) objArr[0];
        int iElapsedRealtime = (int) SystemClock.elapsedRealtime();
        int i18 = (~((-187631073) | iElapsedRealtime)) | 52757792;
        int i19 = ~iElapsedRealtime;
        int i20 = i15 + 20930822 + ((i18 | (~(994029566 | i19))) * 886) + (((~(i19 | 187631072)) | 859156286) * (-1772)) + ((~(i19 | 859156286)) * 886);
        int i21 = (i20 << 13) ^ i20;
        int i22 = i21 ^ (i21 >>> 17);
        ((int[]) objArr19[c4])[0] = i22 ^ (i22 << 5);
        aN = (aQ + 31) % 128;
        cv.e();
        cv.a();
        cv.G(h.c());
        Object objD9 = an.d(i);
        if (objD9 == null) {
            int i23 = 712 - (ViewConfiguration.getScrollFriction() > f ? 1 : (ViewConfiguration.getScrollFriction() == f ? 0 : -1));
            char c7 = (char) ((AudioTrack.getMinVolume() > f ? 1 : (AudioTrack.getMinVolume() == f ? 0 : -1)) + i2);
            int iArgb2 = Color.argb(0, 0, 0, 0) + 24;
            byte b14 = (byte) 0;
            byte b15 = b14;
            Object[] objArr20 = new Object[1];
            aS(b14, b15, (byte) (b15 + 2), objArr20);
            objD9 = an.d(i23, c7, iArgb2, -623790093, false, (String) objArr20[0], null);
        }
        long j2 = ((Field) objD9).getLong(null);
        Object[] objArr21 = new Object[1];
        aU(22 - Color.blue(0), 126 - View.combineMeasuredStates(0, 0), TextUtils.indexOf((CharSequence) "", '0', 0, 0) + 5, true, "\u000f\u0001\u000b\ufffe\b\u0000\f\t￠\n\u0002\u0011\u0010\u0016\ufff0ￋ\u0010\fￋ\u0001\u0006\f", objArr21);
        Class<?> cls5 = Class.forName((String) objArr21[0]);
        Object[] objArr22 = new Object[1];
        aU(15 - (ViewConfiguration.getDoubleTapTimeout() >> 16), 130 - (CdmaCellLocation.convertQuartSecToDecDegrees(0) > 0.0d ? 1 : (CdmaCellLocation.convertQuartSecToDecDegrees(0) == 0.0d ? 0 : -1)), -TextUtils.lastIndexOf("", '0', 0, 0), true, "\ufffe\ufffe\u0006\u0002\r\u0005\ufffa\ufffe￫�\ufffe\f\t\ufffa\u0005", objArr22);
        long jLongValue3 = ((Long) cls5.getDeclaredMethod((String) objArr22[0], null).invoke(null, null)).longValue();
        Object objD10 = an.d(-1398649561);
        if (objD10 == null) {
            int keyRepeatTimeout = 711 - (ViewConfiguration.getKeyRepeatTimeout() >> 16);
            char doubleTapTimeout2 = (char) ((ViewConfiguration.getDoubleTapTimeout() >> 16) + i2);
            int iAxisFromString = MotionEvent.axisFromString("") + 25;
            byte b16 = (byte) 0;
            byte b17 = b16;
            Object[] objArr23 = new Object[1];
            aS(b16, b17, (byte) (b17 + 3), objArr23);
            objD10 = an.d(keyRepeatTimeout, doubleTapTimeout2, iAxisFromString, -624714116, false, (String) objArr23[0], null);
        }
        if (j2 == ((jLongValue3 - ((((Field) objD10).getLong(null) << 52) >>> 52)) >> c2)) {
            Object objD11 = an.d(-1399573082);
            if (objD11 == null) {
                int iAxisFromString2 = MotionEvent.axisFromString("") + 712;
                char bitsPerPixel2 = (char) (49307 - ImageFormat.getBitsPerPixel(0));
                int i24 = (SystemClock.currentThreadTimeMillis() > (-1L) ? 1 : (SystemClock.currentThreadTimeMillis() == (-1L) ? 0 : -1)) + 23;
                byte b18 = (byte) 0;
                Object[] objArr24 = new Object[1];
                aS(b18, b18, (byte) $$a.length, objArr24);
                objD11 = an.d(iAxisFromString2, bitsPerPixel2, i24, -621418755, false, (String) objArr24[0], null);
            }
            Object[] objArr25 = (Object[]) ((Field) objD11).get(null);
            objArr2 = new Object[4];
            objArr2[1] = new int[]{i};
            objArr2[c3] = new int[]{i};
            objArr2[c4] = new int[1];
            int i25 = ((int[]) objArr25[1])[0];
            int i26 = ((int[]) objArr25[c3])[0];
            objArr2[0] = (String[]) objArr25[0];
            int i27 = ~((~System.identityHashCode(this)) | 546547400);
            int i28 = ((((537043080 | i27) * (-374)) + 777787982) + ((i27 | 9504320) * 374)) - 1000738576;
            int i29 = (i28 << 13) ^ i28;
            int i30 = i29 ^ (i29 >>> 17);
            ((int[]) objArr2[c4])[0] = i30 ^ (i30 << 5);
        } else {
            Object[] objArr26 = new Object[1];
            aU(16 - (KeyEvent.getMaxKeyCode() >> 16), 124 - ExpandableListView.getPackedPositionChild(0L), (ViewConfiguration.getScrollBarSize() >> 8) + 2, false, "\u0003\u000b\b\uffff\u0014\uffffￌ\n\uffff\f\u0005ￌ\ufff1\u0017\u0011\u0012", objArr26);
            Class<?> cls6 = Class.forName((String) objArr26[0]);
            Object[] objArr27 = new Object[1];
            aU((ViewConfiguration.getKeyRepeatDelay() >> 16) + 16, KeyEvent.keyCodeFromString("") + 129, (ExpandableListView.getPackedPositionForChild(0, 0) > 0L ? 1 : (ExpandableListView.getPackedPositionForChild(0, 0) == 0L ? 0 : -1)) + 12, true, "\r\ufffb￢\u0013\u000e\u0003\u000e\b\uffff\ufffe\u0003\uffff\ufffe\t\uffdd\u0002", objArr27);
            int iIntValue2 = ((Integer) cls6.getMethod((String) objArr27[0], Object.class).invoke(null, this)).intValue();
            Object[] objArr28 = {955167401};
            Object objD12 = an.d(1683332522);
            if (objD12 == null) {
                objD12 = an.d(831 - (Process.getElapsedCpuTime() > 0L ? 1 : (Process.getElapsedCpuTime() == 0L ? 0 : -1)), (char) (ExpandableListView.getPackedPositionChild(0L) + 1), 24 - Gravity.getAbsoluteGravity(0, 0), 305417969, false, null, new Class[]{Integer.TYPE});
            }
            Object objNewInstance = ((Constructor) objD12).newInstance(objArr28);
            Object[] objArr29 = new Object[5];
            objArr29[4] = Boolean.FALSE;
            objArr29[c4] = objNewInstance;
            objArr29[c3] = -1000738576;
            objArr29[1] = 0;
            objArr29[0] = Integer.valueOf(iIntValue2);
            Object objD13 = an.d(1794077343);
            if (objD13 == null) {
                int scrollDefaultDelay = (ViewConfiguration.getScrollDefaultDelay() >> 16) + 711;
                char tapTimeout2 = (char) ((ViewConfiguration.getTapTimeout() >> 16) + i2);
                int iNormalizeMetaState = 24 - KeyEvent.normalizeMetaState(0);
                byte b19 = (byte) 0;
                byte b20 = b19;
                Object[] objArr30 = new Object[1];
                aS(b19, b20, (byte) (b20 + 3), objArr30);
                String str3 = (String) objArr30[0];
                Class cls7 = Integer.TYPE;
                objD13 = an.d(scrollDefaultDelay, tapTimeout2, iNormalizeMetaState, 479109572, false, str3, new Class[]{cls7, cls7, cls7, (Class) an.b(799 - TextUtils.indexOf("", "", 0, 0), (char) (TextUtils.lastIndexOf("", '0') + 1), 31 - (AudioTrack.getMinVolume() > f ? 1 : (AudioTrack.getMinVolume() == f ? 0 : -1))), Boolean.TYPE});
            }
            objArr2 = (Object[]) ((Method) objD13).invoke(null, objArr29);
            Object objD14 = an.d(-1399573082);
            if (objD14 == null) {
                int i31 = (AudioTrack.getMaxVolume() > f ? 1 : (AudioTrack.getMaxVolume() == f ? 0 : -1)) + 710;
                char c8 = (char) (49309 - (Process.getElapsedCpuTime() > 0L ? 1 : (Process.getElapsedCpuTime() == 0L ? 0 : -1)));
                int maximumFlingVelocity = (ViewConfiguration.getMaximumFlingVelocity() >> 16) + 24;
                byte b21 = (byte) 0;
                Object[] objArr31 = new Object[1];
                aS(b21, b21, (byte) $$a.length, objArr31);
                objD14 = an.d(i31, c8, maximumFlingVelocity, -621418755, false, (String) objArr31[0], null);
            }
            ((Field) objD14).set(null, objArr2);
            try {
                Object[] objArr32 = new Object[1];
                aU(22 - KeyEvent.normalizeMetaState(0), (AudioTrack.getMinVolume() > f ? 1 : (AudioTrack.getMinVolume() == f ? 0 : -1)) + 126, TextUtils.lastIndexOf("", '0', 0, 0) + 5, true, "\u000f\u0001\u000b\ufffe\b\u0000\f\t￠\n\u0002\u0011\u0010\u0016\ufff0ￋ\u0010\fￋ\u0001\u0006\f", objArr32);
                Class<?> cls8 = Class.forName((String) objArr32[0]);
                Object[] objArr33 = new Object[1];
                aU((ExpandableListView.getPackedPositionForChild(0, 0) > 0L ? 1 : (ExpandableListView.getPackedPositionForChild(0, 0) == 0L ? 0 : -1)) + 16, (ViewConfiguration.getScrollBarSize() >> 8) + 130, -((byte) KeyEvent.getModifierMetaStateMask()), true, "\ufffe\ufffe\u0006\u0002\r\u0005\ufffa\ufffe￫�\ufffe\f\t\ufffa\u0005", objArr33);
                long jLongValue4 = ((Long) cls8.getDeclaredMethod((String) objArr33[0], null).invoke(null, null)).longValue();
                Long lValueOf3 = Long.valueOf(jLongValue4);
                Object objD15 = an.d(-1398649561);
                if (objD15 == null) {
                    int minimumFlingVelocity = (ViewConfiguration.getMinimumFlingVelocity() >> 16) + 711;
                    char cGreen = (char) (i2 - Color.green(0));
                    int longPressTimeout = 24 - (ViewConfiguration.getLongPressTimeout() >> 16);
                    byte b22 = (byte) 0;
                    byte b23 = b22;
                    Object[] objArr34 = new Object[1];
                    aS(b22, b23, (byte) (b23 + 3), objArr34);
                    objD15 = an.d(minimumFlingVelocity, cGreen, longPressTimeout, -624714116, false, (String) objArr34[0], null);
                }
                ((Field) objD15).set(null, lValueOf3);
                Long lValueOf4 = Long.valueOf(jLongValue4 >> c2);
                Object objD16 = an.d(i);
                if (objD16 == null) {
                    int i32 = 712 - (SystemClock.currentThreadTimeMillis() > (-1L) ? 1 : (SystemClock.currentThreadTimeMillis() == (-1L) ? 0 : -1));
                    char cCombineMeasuredStates = (char) (i2 - View.combineMeasuredStates(0, 0));
                    int iAlpha = Color.alpha(0) + 24;
                    byte b24 = (byte) 0;
                    byte b25 = b24;
                    Object[] objArr35 = new Object[1];
                    aS(b24, b25, (byte) (b25 + 2), objArr35);
                    objD16 = an.d(i32, cCombineMeasuredStates, iAlpha, -623790093, false, (String) objArr35[0], null);
                }
                ((Field) objD16).set(null, lValueOf4);
            } catch (Exception unused2) {
                throw new RuntimeException();
            }
        }
        int i33 = ((int[]) objArr2[c3])[0];
        int i34 = ((int[]) objArr2[1])[0];
        if (i34 == i33) {
            aQ = (aN + 101) % 128;
            Object[] objArr36 = new Object[4];
            objArr36[1] = new int[]{i};
            objArr36[c3] = new int[]{i};
            objArr36[c4] = new int[1];
            int i35 = ((int[]) objArr2[c4])[0];
            int i36 = ((int[]) objArr2[1])[0];
            int i37 = ((int[]) objArr2[c3])[0];
            objArr36[0] = (String[]) objArr2[0];
            int i38 = ~System.identityHashCode(this);
            int i39 = i35 + (-1865674468) + (((~((-830260323) | i38)) | (-216527037)) * (-933)) + (((~(i38 | (-216527037))) | 209924252) * 933) + 170400421;
            int i40 = (i39 << 13) ^ i39;
            int i41 = i40 ^ (i40 >>> 17);
            ((int[]) objArr36[c4])[0] = i41 ^ (i41 << 5);
            return;
        }
        ArrayList arrayList2 = new ArrayList();
        String[] strArr3 = (String[]) objArr2[0];
        if (strArr3 != null) {
            int i42 = aQ + 37;
            aN = i42 % 128;
            for (int i43 = i42 % 2 == 0 ? 1 : 0; i43 < strArr3.length; i43++) {
                aN = (aQ + 31) % 128;
                arrayList2.add(strArr3[i43]);
            }
        }
        Toast.makeText((Context) null, i34 / (((i34 - 1) * i34) % 2), 0).show();
        Object[] objArr37 = new Object[4];
        objArr37[1] = new int[]{i};
        objArr37[c3] = new int[]{i};
        objArr37[c4] = new int[1];
        int i44 = ((int[]) objArr2[c4])[0];
        int i45 = ((int[]) objArr2[1])[0];
        int i46 = ((int[]) objArr2[c3])[0];
        objArr37[0] = (String[]) objArr2[0];
        int i47 = i44 + (((806564544 | r2) * (-658)) - 942171746) + (((~(((int) Runtime.getRuntime().freeMemory()) | 926474607)) | 201344) * 658);
        int i48 = (i47 << 13) ^ i47;
        int i49 = i48 ^ (i48 >>> 17);
        ((int[]) objArr37[c4])[0] = i49 ^ (i49 << 5);
    }

    /* JADX INFO: Access modifiers changed from: private */
    /* JADX WARN: Code restructure failed: missing block: B:10:0x0026, code lost:
    
        r0 = com.facetec.sdk.bi.aQ + 39;
        com.facetec.sdk.bi.aN = r0 % 128;
     */
    /* JADX WARN: Code restructure failed: missing block: B:11:0x0030, code lost:
    
        if ((r0 % 2) != 0) goto L26;
     */
    /* JADX WARN: Code restructure failed: missing block: B:12:0x0032, code lost:
    
        r0 = 44 / 0;
     */
    /* JADX WARN: Code restructure failed: missing block: B:13:0x0036, code lost:
    
        return;
     */
    /* JADX WARN: Code restructure failed: missing block: B:14:0x0037, code lost:
    
        r4 = r19.T;
     */
    /* JADX WARN: Code restructure failed: missing block: B:15:0x003d, code lost:
    
        if (com.facetec.sdk.bk.b() == false) goto L27;
     */
    /* JADX WARN: Code restructure failed: missing block: B:16:0x003f, code lost:
    
        com.facetec.sdk.bi.aQ = (com.facetec.sdk.bi.aN + 9) % 128;
     */
    /* JADX WARN: Code restructure failed: missing block: B:17:0x0047, code lost:
    
        r5 = com.facetec.sdk.dq.b(r4.d.get());
        r6 = com.facetec.sdk.dq.e().width;
        r8 = com.facetec.sdk.dq.e().height;
        r10 = r8 / r6;
        r12 = r5.height;
        r14 = r5.width;
        r12 = r12 / ((double) r14);
     */
    /* JADX WARN: Code restructure failed: missing block: B:18:0x0076, code lost:
    
        if (java.lang.Math.abs(r6 - ((double) r14)) <= 0.0d) goto L28;
     */
    /* JADX WARN: Code restructure failed: missing block: B:19:0x0078, code lost:
    
        r10 = r4.d.get();
        r11 = com.facetec.sdk.c.UNEXPECTED_ACTIVITY_WINDOW_SIZE;
        r14 = new java.lang.StringBuilder("AS: ");
        r14.append(r5.width);
        r14.append("x");
        r14.append(r5.height);
        r14.append(" (");
        r14.append(java.lang.String.format("%.2f", java.lang.Double.valueOf(r12)));
        r14.append(") | SS: ");
        r14.append(r6);
        r14.append("x");
        r14.append(r8);
        r14.append(" (");
        r14.append(java.lang.String.format("%.2f", java.lang.Double.valueOf(r10)));
        r14.append(")");
        com.facetec.sdk.t.d(r10, r11, r14.toString(), null);
     */
    /* JADX WARN: Code restructure failed: missing block: B:20:0x00d5, code lost:
    
        return;
     */
    /* JADX WARN: Code restructure failed: missing block: B:21:0x00d6, code lost:
    
        r0 = move-exception;
     */
    /* JADX WARN: Code restructure failed: missing block: B:22:0x00d7, code lost:
    
        com.facetec.sdk.t.d(r4.d.get(), com.facetec.sdk.c.UNEXPECTED_ACTIVITY_WINDOW_SIZE, "Error getting diagnostic data.", r0);
     */
    /* JADX WARN: Code restructure failed: missing block: B:23:0x00e6, code lost:
    
        return;
     */
    /* JADX WARN: Code restructure failed: missing block: B:26:?, code lost:
    
        return;
     */
    /* JADX WARN: Code restructure failed: missing block: B:27:?, code lost:
    
        return;
     */
    /* JADX WARN: Code restructure failed: missing block: B:28:?, code lost:
    
        return;
     */
    /* JADX WARN: Code restructure failed: missing block: B:5:0x001a, code lost:
    
        if (isFinishing() != false) goto L10;
     */
    /* JADX WARN: Code restructure failed: missing block: B:9:0x0024, code lost:
    
        if (isFinishing() != false) goto L10;
     */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public /* synthetic */ void aQ() {
        /*
            Method dump skipped, instruction units count: 231
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: com.facetec.sdk.bi.aQ():void");
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void aR() {
        int i = aN + 125;
        aQ = i % 128;
        if (i % 2 == 0) {
            ed.b(this);
        } else {
            ed.b(this);
            int i2 = 15 / 0;
        }
    }

    /* JADX WARN: Removed duplicated region for block: B:10:0x0026  */
    /* JADX WARN: Removed duplicated region for block: B:8:0x001e  */
    /* JADX WARN: Unsupported multi-entry loop pattern (BACK_EDGE: B:10:0x0026 -> B:11:0x0030). Please report as a decompilation issue!!! */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    private static void aS(byte r6, short r7, short r8, java.lang.Object[] r9) {
        /*
            int r8 = 101 - r8
            int r6 = r6 * 4
            int r0 = r6 + 1
            int r7 = r7 * 2
            int r7 = 3 - r7
            byte[] r1 = com.facetec.sdk.bi.$$a
            byte[] r0 = new byte[r0]
            r2 = 0
            if (r1 != 0) goto L16
            r8 = r7
            r3 = r1
            r4 = r2
            r1 = r6
            goto L30
        L16:
            r3 = r2
        L17:
            byte r4 = (byte) r8
            r0[r3] = r4
            int r7 = r7 + 1
            if (r3 != r6) goto L26
            java.lang.String r6 = new java.lang.String
            r6.<init>(r0, r2)
            r9[r2] = r6
            return
        L26:
            int r3 = r3 + 1
            r4 = r1[r7]
            r5 = r8
            r8 = r7
            r7 = r4
            r4 = r3
            r3 = r1
            r1 = r5
        L30:
            int r7 = r7 + r1
            r1 = r8
            r8 = r7
            r7 = r1
            r1 = r3
            r3 = r4
            goto L17
        */
        throw new UnsupportedOperationException("Method not decompiled: com.facetec.sdk.bi.aS(byte, short, short, java.lang.Object[]):void");
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void aT() {
        aQ = (aN + 125) % 128;
        if (isFinishing()) {
            return;
        }
        H();
        aN = (aQ + 75) % 128;
    }

    /* JADX WARN: Removed duplicated region for block: B:37:0x0163  */
    /* JADX WARN: Removed duplicated region for block: B:38:0x0164  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    private static void aU(int r24, int r25, int r26, boolean r27, java.lang.String r28, java.lang.Object[] r29) throws java.lang.Throwable {
        /*
            Method dump skipped, instruction units count: 366
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: com.facetec.sdk.bi.aU(int, int, int, boolean, java.lang.String, java.lang.Object[]):void");
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void aV() {
        int i = aN + 109;
        aQ = i % 128;
        int i2 = i % 2;
        R();
        if (i2 != 0) {
            int i3 = 29 / 0;
        }
    }

    /* JADX WARN: Removed duplicated region for block: B:10:0x0026  */
    /* JADX WARN: Removed duplicated region for block: B:8:0x001e  */
    /* JADX WARN: Unsupported multi-entry loop pattern (BACK_EDGE: B:10:0x0026 -> B:11:0x002d). Please report as a decompilation issue!!! */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    private static void aW(int r7, short r8, short r9, java.lang.Object[] r10) {
        /*
            int r9 = 100 - r9
            byte[] r0 = com.facetec.sdk.bi.$$d
            int r7 = r7 + 4
            int r8 = r8 * 17
            int r8 = 18 - r8
            byte[] r1 = new byte[r8]
            r2 = 0
            if (r0 != 0) goto L14
            r3 = r0
            r5 = r2
            r0 = r9
            r9 = r7
            goto L2d
        L14:
            r3 = r2
        L15:
            int r7 = r7 + 1
            byte r4 = (byte) r9
            int r5 = r3 + 1
            r1[r3] = r4
            if (r5 != r8) goto L26
            java.lang.String r7 = new java.lang.String
            r7.<init>(r1, r2)
            r10[r2] = r7
            return
        L26:
            r3 = r0[r7]
            r6 = r9
            r9 = r7
            r7 = r3
            r3 = r0
            r0 = r6
        L2d:
            int r0 = r0 + r7
            int r7 = r0 + 3
            r0 = r9
            r9 = r7
            r7 = r0
            r0 = r3
            r3 = r5
            goto L15
        */
        throw new UnsupportedOperationException("Method not decompiled: com.facetec.sdk.bi.aW(int, short, short, java.lang.Object[]):void");
    }

    private void aa() {
        int i = aN + 51;
        aQ = i % 128;
        if (i % 2 != 0) {
            isFinishing();
            throw null;
        }
        if (!isFinishing()) {
            getFragmentManager().beginTransaction().remove(this.f).commitAllowingStateLoss();
            this.f = null;
        } else {
            int i2 = aN + 1;
            aQ = i2 % 128;
            if (i2 % 2 != 0) {
                throw null;
            }
        }
    }

    private void ab() {
        aN = (aQ + 31) % 128;
        dj.a(new Runnable() { // from class: com.facetec.sdk.乐灵
            @Override // java.lang.Runnable
            public final void run() {
                this.f6847.av();
            }
        }).c(new Runnable() { // from class: com.facetec.sdk.乐雨
            @Override // java.lang.Runnable
            public final void run() {
                this.f6865.an();
            }
        });
        int i = aQ;
        int i2 = ((i | EnumC41897g.SDK_ASSET_ILLUSTRATION_CALENDAR_VALUE) << 1) - (i ^ EnumC41897g.SDK_ASSET_ILLUSTRATION_CALENDAR_VALUE);
        aN = i2 % 128;
        if (i2 % 2 == 0) {
            throw null;
        }
    }

    private void ac() {
        e(FaceTecOCRConfirmationCustomization.d(), -1899780412, 1899780426, FaceTecOCRConfirmationCustomization.d(), new Object[]{this}, FaceTecOCRConfirmationCustomization.d(), FaceTecOCRConfirmationCustomization.d());
    }

    private void ad() {
        ViewPropertyAnimator duration;
        long j;
        aN = (aQ + 59) % 128;
        ImageView imageView = this.w;
        if (imageView == null || FaceTecSDK.d.m.b != FaceTecCancelButtonCustomization.ButtonLocation.CUSTOM) {
            return;
        }
        int i = aN + 75;
        aQ = i % 128;
        if (i % 2 != 0) {
            imageView.setEnabled(true);
            duration = this.w.animate().alpha(SelfieScan.RECOGNITION_FAIL_RESULT).setDuration(300L);
            j = 1;
        } else {
            imageView.setEnabled(false);
            duration = this.w.animate().alpha(SelfieScan.RECOGNITION_FAIL_RESULT).setDuration(300L);
            j = 0;
        }
        duration.setStartDelay(j).setListener(null).withEndAction(null).start();
    }

    private boolean ae() {
        if (this.f != null && this.f.b()) {
            int i = aN;
            aQ = (i + 87) % 128;
            if (!this.t && !this.ak) {
                int i2 = i + 35;
                aQ = i2 % 128;
                return i2 % 2 == 0;
            }
        }
        int i3 = aQ + 25;
        aN = i3 % 128;
        if (i3 % 2 != 0) {
            return false;
        }
        throw null;
    }

    private void af() {
        aQ = (aN + 87) % 128;
        this.P = null;
        this.O = null;
        this.R = null;
        int i = aQ + EnumC41897g.SDK_ASSET_ILLUSTRATION_CALENDAR_VALUE;
        aN = i % 128;
        if (i % 2 == 0) {
            throw null;
        }
    }

    private boolean ag() {
        if (this.h == null) {
            return false;
        }
        aN = (aQ + 91) % 128;
        if (!this.h.b()) {
            return false;
        }
        aQ = (aN + 69) % 128;
        return true;
    }

    private boolean ah() {
        aQ = (aN + 23) % 128;
        if (this.Q != null) {
            int i = aQ + 49;
            aN = i % 128;
            if (i % 2 == 0) {
                int i2 = 39 / 0;
                if (this.Q.b()) {
                    return true;
                }
            } else if (this.Q.b()) {
                return true;
            }
        }
        return false;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void ai() {
        this.as.setVisibility(4);
        if (this.f != null) {
            int i = (aN + 1) % 128;
            aQ = i;
            if (this.A != null) {
                aN = (i + 63) % 128;
                this.f.a(true, this.ax, new Runnable() { // from class: com.facetec.sdk.书乐
                    @Override // java.lang.Runnable
                    public final void run() {
                        this.f6873.al();
                    }
                });
            }
        }
        int i2 = aN + 113;
        aQ = i2 % 128;
        if (i2 % 2 != 0) {
            throw null;
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void aj() {
        aN = (aQ + 19) % 128;
        this.f.e(new Runnable() { // from class: com.facetec.sdk.书丹
            @Override // java.lang.Runnable
            public final void run() {
                this.f6872.ak();
            }
        });
        int i = aQ + 41;
        aN = i % 128;
        if (i % 2 == 0) {
            throw null;
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void ak() {
        e(FaceTecOCRConfirmationCustomization.d(), -1239935581, 1239935583, FaceTecOCRConfirmationCustomization.d(), new Object[]{this}, FaceTecOCRConfirmationCustomization.d(), FaceTecOCRConfirmationCustomization.d());
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void al() {
        aN = (aQ + 61) % 128;
        this.s.c(false, false);
        int i = aQ + 83;
        aN = i % 128;
        if (i % 2 == 0) {
            throw null;
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    /* JADX WARN: Removed duplicated region for block: B:9:0x0023  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public /* synthetic */ void am() {
        /*
            r3 = this;
            int r0 = com.facetec.sdk.bi.aN
            int r0 = r0 + 11
            int r1 = r0 % 128
            com.facetec.sdk.bi.aQ = r1
            int r0 = r0 % 2
            if (r0 == 0) goto L18
            r0 = 0
            r3.Z = r0
            com.facetec.sdk.FaceTecIDScanResult r0 = r3.aA
            com.facetec.sdk.FaceTecIDScanStatus r0 = r0.getStatus()
            if (r0 == 0) goto L50
            goto L23
        L18:
            r0 = 1
            r3.Z = r0
            com.facetec.sdk.FaceTecIDScanResult r0 = r3.aA
            com.facetec.sdk.FaceTecIDScanStatus r0 = r0.getStatus()
            if (r0 == 0) goto L50
        L23:
            int r0 = com.facetec.sdk.bi.aQ
            int r0 = r0 + 5
            int r1 = r0 % 128
            com.facetec.sdk.bi.aN = r1
            int r0 = r0 % 2
            r1 = 0
            if (r0 == 0) goto L40
            com.facetec.sdk.c r0 = com.facetec.sdk.c.ID_SCAN_CALLBACK_CALLED
            com.facetec.sdk.FaceTecIDScanResult r2 = r3.aA
            com.facetec.sdk.FaceTecIDScanStatus r2 = r2.getStatus()
            java.lang.String r2 = r2.toString()
            com.facetec.sdk.t.d(r3, r0, r2, r1)
            goto L50
        L40:
            com.facetec.sdk.c r0 = com.facetec.sdk.c.ID_SCAN_CALLBACK_CALLED
            com.facetec.sdk.FaceTecIDScanResult r2 = r3.aA
            com.facetec.sdk.FaceTecIDScanStatus r2 = r2.getStatus()
            java.lang.String r2 = r2.toString()
            com.facetec.sdk.t.d(r3, r0, r2, r1)
            throw r1
        L50:
            com.facetec.sdk.FaceTecIDScanProcessor r0 = com.facetec.sdk.FaceTecSessionActivity.f
            com.facetec.sdk.FaceTecIDScanResult r1 = r3.aA
            com.facetec.sdk.bz r2 = new com.facetec.sdk.bz
            r2.<init>(r3)
            r0.processIDScanWhileFaceTecSDKWaits(r1, r2)
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: com.facetec.sdk.bi.am():void");
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void an() {
        e(FaceTecOCRConfirmationCustomization.d(), -1846835455, 1846835476, FaceTecOCRConfirmationCustomization.d(), new Object[]{this}, FaceTecOCRConfirmationCustomization.d(), FaceTecOCRConfirmationCustomization.d());
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void ao() {
        e(FaceTecOCRConfirmationCustomization.d(), 90024010, -90024006, FaceTecOCRConfirmationCustomization.d(), new Object[]{this}, FaceTecOCRConfirmationCustomization.d(), FaceTecOCRConfirmationCustomization.d());
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void ap() {
        e(FaceTecOCRConfirmationCustomization.d(), 1265403786, -1265403771, FaceTecOCRConfirmationCustomization.d(), new Object[]{this}, FaceTecOCRConfirmationCustomization.d(), FaceTecOCRConfirmationCustomization.d());
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void aq() {
        e(FaceTecOCRConfirmationCustomization.d(), 2037799913, -2037799895, FaceTecOCRConfirmationCustomization.d(), new Object[]{this}, FaceTecOCRConfirmationCustomization.d(), FaceTecOCRConfirmationCustomization.d());
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void ar() {
        aQ = (aN + 47) % 128;
        if (eg.d(this)) {
            this.s.c(false, true);
            Y();
            aN = (aQ + 11) % 128;
        }
        int i = aQ + 21;
        aN = i % 128;
        if (i % 2 == 0) {
            throw null;
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void as() {
        aQ = (aN + 51) % 128;
        c(this.aA.getStatus());
        int i = aQ + 97;
        aN = i % 128;
        if (i % 2 == 0) {
            int i2 = 5 / 0;
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void at() {
        FaceTecSessionActivity faceTecSessionActivity;
        aQ = (aN + 29) % 128;
        this.ac = false;
        this.i = (dd) getFragmentManager().findFragmentByTag("RetryFaceScan");
        if (this.i != null) {
            aQ = (aN + 71) % 128;
            if (this.i.o != null) {
                dc dcVar = this.i.o;
                if (dcVar.m != null || (faceTecSessionActivity = (FaceTecSessionActivity) dcVar.getActivity()) == null) {
                    return;
                }
                aN = (aQ + 65) % 128;
                dcVar.m = faceTecSessionActivity.I;
                dcVar.b.setAlpha(SelfieScan.RECOGNITION_FAIL_RESULT);
                dcVar.a();
                dcVar.b.animate().alpha(1.0f).setDuration(400L).setListener(null);
            }
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void au() throws Throwable {
        int i = aN + 83;
        aQ = i % 128;
        int i2 = i % 2;
        M();
        if (i2 != 0) {
            throw null;
        }
        aN = (aQ + 83) % 128;
    }

    /* JADX INFO: Access modifiers changed from: private */
    /* JADX WARN: Removed duplicated region for block: B:23:0x0048  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public /* synthetic */ void av() {
        /*
            r4 = this;
            com.facetec.sdk.cp r0 = r4.e
            if (r0 == 0) goto L19
            int r1 = com.facetec.sdk.bi.aQ
            int r1 = r1 + 79
            int r2 = r1 % 128
            com.facetec.sdk.bi.aN = r2
            int r1 = r1 % 2
            if (r1 == 0) goto L14
            r0.h()
            goto L19
        L14:
            r0.h()
            r0 = 0
            throw r0
        L19:
            byte[] r0 = com.facetec.sdk.cv.p()     // Catch: java.lang.Exception -> L20
            r4.R = r0     // Catch: java.lang.Exception -> L20
            goto L28
        L20:
            r0 = move-exception
            java.lang.String r0 = r0.getMessage()
            com.facetec.sdk.bh.e(r0)
        L28:
            boolean r0 = com.facetec.sdk.bk.e()
            if (r0 == 0) goto L84
            int r0 = com.facetec.sdk.bi.aQ
            int r0 = r0 + 99
            int r1 = r0 % 128
            com.facetec.sdk.bi.aN = r1
            int r0 = r0 % 2
            r1 = 0
            if (r0 != 0) goto L43
            boolean r0 = r4.X
            r2 = 25
            int r2 = r2 / r1
            if (r0 != 0) goto L48
            goto L84
        L43:
            boolean r0 = r4.X
            if (r0 != 0) goto L48
            goto L84
        L48:
            r0 = 1
            byte[][] r2 = com.facetec.sdk.cv.b(r4, r0)
            r4.P = r2
            byte[][] r2 = com.facetec.sdk.cv.a(r4, r0)
            r4.O = r2
            byte[][] r2 = r4.O
            int r2 = r2.length
            if (r2 <= 0) goto L84
            int r2 = com.facetec.sdk.bi.aQ
            int r2 = r2 + 101
            int r3 = r2 % 128
            com.facetec.sdk.bi.aN = r3
            int r2 = r2 % 2
            if (r2 != 0) goto L76
            byte[][] r2 = r4.O
            r2 = r2[r1]
            byte[][] r3 = r4.O
            r0 = r3[r0]
            int r0 = r0.length
            android.graphics.Bitmap r0 = android.graphics.BitmapFactory.decodeByteArray(r2, r1, r0)
        L73:
            r4.I = r0
            goto L84
        L76:
            byte[][] r0 = r4.O
            r0 = r0[r1]
            byte[][] r2 = r4.O
            r2 = r2[r1]
            int r2 = r2.length
            android.graphics.Bitmap r0 = android.graphics.BitmapFactory.decodeByteArray(r0, r1, r2)
            goto L73
        L84:
            boolean r0 = com.facetec.sdk.bk.b()
            if (r0 != 0) goto L8b
            goto L92
        L8b:
            com.facetec.sdk.m r0 = r4.k
            if (r0 == 0) goto L92
            r0.b()
        L92:
            com.facetec.sdk.bd r0 = r4.c
            if (r0 == 0) goto La3
            int r0 = com.facetec.sdk.bi.aN
            int r0 = r0 + 9
            int r0 = r0 % 128
            com.facetec.sdk.bi.aQ = r0
            com.facetec.sdk.bd r0 = r4.c
            r0.c()
        La3:
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: com.facetec.sdk.bi.av():void");
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void aw() {
        aQ = (aN + 57) % 128;
        aa();
        int i = aN + 23;
        aQ = i % 128;
        if (i % 2 != 0) {
            throw null;
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void ax() throws Throwable {
        int i = aQ + 37;
        aN = i % 128;
        int i2 = i % 2;
        K();
        if (i2 == 0) {
            throw null;
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void ay() {
        cx cxVar;
        Runnable runnable;
        int i = aQ + 31;
        aN = i % 128;
        if (i % 2 == 0) {
            throw null;
        }
        if (this.f != null) {
            if (bj.d) {
                Boolean bool = Boolean.TRUE;
                e(FaceTecOCRConfirmationCustomization.d(), -1344204838, 1344204855, FaceTecOCRConfirmationCustomization.d(), new Object[]{this, null, bool, bool}, FaceTecOCRConfirmationCustomization.d(), FaceTecOCRConfirmationCustomization.d());
                aN = (aQ + 53) % 128;
                return;
            }
            int i2 = aQ + 29;
            aN = i2 % 128;
            if (i2 % 2 == 0) {
                cxVar = this.f;
                runnable = new Runnable() { // from class: com.facetec.sdk.丹魂
                    @Override // java.lang.Runnable
                    public final void run() throws Throwable {
                        this.f6793.aB();
                    }
                };
            } else {
                cxVar = this.f;
                runnable = new Runnable() { // from class: com.facetec.sdk.丹魂
                    @Override // java.lang.Runnable
                    public final void run() throws Throwable {
                        this.f6793.aB();
                    }
                };
            }
            cxVar.a(false, null, runnable);
            int i3 = aN + 125;
            aQ = i3 % 128;
            if (i3 % 2 != 0) {
                throw null;
            }
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void az() {
        e(FaceTecOCRConfirmationCustomization.d(), 842956968, -842956949, FaceTecOCRConfirmationCustomization.d(), new Object[]{this}, FaceTecOCRConfirmationCustomization.d(), FaceTecOCRConfirmationCustomization.d());
    }

    private static /* synthetic */ Object b(Object[] objArr) {
        boolean z = false;
        final bi biVar = (bi) objArr[0];
        boolean zBooleanValue = ((Boolean) objArr[1]).booleanValue();
        synchronized (biVar) {
            try {
                cp cpVar = biVar.e;
                if (cpVar != null) {
                    cp.b(-1456391372, bb.d(), bb.d(), bb.d(), 1456391379, bb.d(), new Object[]{cpVar});
                    if (zBooleanValue) {
                        cp.b();
                        biVar.e = null;
                    } else {
                        z = true;
                    }
                }
            } catch (Throwable th) {
                throw th;
            }
        }
        if (z) {
            Thread thread = new Thread(new Runnable() { // from class: com.facetec.sdk.乐城
                @Override // java.lang.Runnable
                public final void run() {
                    this.f6820.az();
                }
            });
            thread.setPriority(10);
            thread.start();
        }
        return null;
    }

    private void c(String str) throws Throwable {
        Throwable th = new Throwable("FaceTec SDK has experienced an unexpected camera error.");
        c cVar = c.CAMERA_ERROR;
        String strConcat = "FaceScan: camera is null unexpectedly. From: ".concat(String.valueOf(str));
        FaceTecSessionStatus faceTecSessionStatus = FaceTecSessionStatus.UNKNOWN_INTERNAL_ERROR;
        t.d(this, th, cVar, strConcat, true, faceTecSessionStatus.ordinal());
        e(faceTecSessionStatus, (FaceTecIDScanStatus) null);
        aN = (aQ + 25) % 128;
    }

    /* JADX WARN: Removed duplicated region for block: B:33:0x0103  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public static /* synthetic */ java.lang.Object e(int r7, int r8, int r9, int r10, java.lang.Object[] r11, int r12, int r13) {
        /*
            Method dump skipped, instruction units count: 1062
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: com.facetec.sdk.bi.e(int, int, int, int, java.lang.Object[], int, int):java.lang.Object");
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ byte[] g(String str) {
        aQ = (aN + 73) % 128;
        byte[] bArrT = cv.t(str, this.D, "", bk.j(this).getBoolean(ao.ab, false));
        int i = aN + EnumC41897g.SDK_ASSET_ILLUSTRATION_DEPOSIT_SWITCH_VALUE;
        aQ = i % 128;
        if (i % 2 != 0) {
            int i2 = 19 / 0;
        }
        return bArrT;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void h(FaceTecIDScanNextStep faceTecIDScanNextStep) {
        int i = aN + 107;
        aQ = i % 128;
        if (i % 2 != 0) {
            int i2 = 85 / 0;
            if (isFinishing()) {
                return;
            }
        } else if (isFinishing()) {
            return;
        }
        e(FaceTecOCRConfirmationCustomization.d(), 1078511809, -1078511801, FaceTecOCRConfirmationCustomization.d(), new Object[]{this, faceTecIDScanNextStep, Boolean.FALSE}, FaceTecOCRConfirmationCustomization.d(), FaceTecOCRConfirmationCustomization.d());
        this.ab = false;
        this.f.a(new Runnable() { // from class: com.facetec.sdk.丹祭
            @Override // java.lang.Runnable
            public final void run() {
                this.f6780.aM();
            }
        });
        aN = (aQ + 77) % 128;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void i(final FaceTecIDScanNextStep faceTecIDScanNextStep) {
        cx cxVar = this.f;
        cx cxVar2 = this.f;
        Objects.requireNonNull(cxVar2);
        cxVar.b((Runnable) new au.c(new Runnable() { // from class: com.facetec.sdk.乐药
            @Override // java.lang.Runnable
            public final void run() {
                this.f6860.h(faceTecIDScanNextStep);
            }
        }));
        int i = aN + 95;
        aQ = i % 128;
        if (i % 2 != 0) {
            throw null;
        }
    }

    public static void init$0() {
        $$a = new byte[]{79, 7, ISO7816.INS_READ_BINARY, ISOFileInfo.FILE_IDENTIFIER};
        $$b = EnumC41897g.SDK_ASSET_ILLUSTRATION_PLAID_OVERLAY_PERSON_VALUE;
    }

    public static void init$1() {
        $$d = new byte[]{ISO7816.INS_REHABILITATE_CHV, -59, ISOFileInfo.SECURITY_ATTR_COMPACT, 119, 9, -5, -66, 53, -8, -1, -1, PassportService.SFI_DG12, -18, -5, -56, CVCAFile.CAR_TAG, -18, 4, ISO7816.INS_GET_RESPONSE, 64, -19};
        $$e = 60;
    }

    public static void init$2() {
        $$c = new byte[]{ISO7816.INS_VERIFY, PassportService.SFI_DG13, ISO7816.INS_GET_DATA, -47};
        $$f = 180;
    }

    private void j(boolean z) {
        aN = (aQ + 115) % 128;
        e(FaceTecOCRConfirmationCustomization.d(), -1776803023, 1776803023, FaceTecOCRConfirmationCustomization.d(), new Object[]{this, Boolean.valueOf(z)}, FaceTecOCRConfirmationCustomization.d(), FaceTecOCRConfirmationCustomization.d());
        cp cpVar = this.e;
        cpVar.e = true;
        cpVar.m();
        int i = aQ + 109;
        aN = i % 128;
        if (i % 2 == 0) {
            int i2 = 44 / 0;
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void k(final boolean z) {
        int i = aQ + 103;
        aN = i % 128;
        if (i % 2 == 0) {
            F();
            throw null;
        }
        if (F() || this.A == null) {
            return;
        }
        runOnUiThread(new Runnable() { // from class: com.facetec.sdk.乐道
            @Override // java.lang.Runnable
            public final void run() {
                this.f6862.o(z);
            }
        });
        aQ = (aN + 43) % 128;
    }

    private static /* synthetic */ Object l(Object[] objArr) {
        final bi biVar = (bi) objArr[0];
        final FaceTecIDScanNextStep faceTecIDScanNextStep = (FaceTecIDScanNextStep) objArr[1];
        int i = aQ + 47;
        aN = i % 128;
        if (i % 2 == 0) {
            cx cxVar = biVar.f;
            throw null;
        }
        if (biVar.f != null) {
            biVar.f.c(new Runnable() { // from class: com.facetec.sdk.丹梦
                @Override // java.lang.Runnable
                public final void run() {
                    this.f6765.i(faceTecIDScanNextStep);
                }
            });
            return null;
        }
        int i2 = aN + 19;
        aQ = i2 % 128;
        if (i2 % 2 != 0) {
            e(FaceTecOCRConfirmationCustomization.d(), 1078511809, -1078511801, FaceTecOCRConfirmationCustomization.d(), new Object[]{biVar, faceTecIDScanNextStep, Boolean.TRUE}, FaceTecOCRConfirmationCustomization.d(), FaceTecOCRConfirmationCustomization.d());
            biVar.ab = false;
            return null;
        }
        e(FaceTecOCRConfirmationCustomization.d(), 1078511809, -1078511801, FaceTecOCRConfirmationCustomization.d(), new Object[]{biVar, faceTecIDScanNextStep, Boolean.FALSE}, FaceTecOCRConfirmationCustomization.d(), FaceTecOCRConfirmationCustomization.d());
        biVar.ab = false;
        return null;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void o(boolean z) {
        aQ = (aN + 89) % 128;
        e(FaceTecOCRConfirmationCustomization.d(), 827085871, -827085847, FaceTecOCRConfirmationCustomization.d(), new Object[]{this, Boolean.valueOf(z)}, FaceTecOCRConfirmationCustomization.d(), FaceTecOCRConfirmationCustomization.d());
        e(1000);
        int i = aQ + 13;
        aN = i % 128;
        if (i % 2 == 0) {
            int i2 = 87 / 0;
        }
    }

    private static /* synthetic */ Object q(Object[] objArr) {
        final bi biVar = (bi) objArr[0];
        int i = aQ + 43;
        aN = i % 128;
        if (i % 2 == 0) {
            biVar.G();
            throw null;
        }
        if (biVar.G()) {
            return null;
        }
        biVar.ao.animate().alpha(1.0f).setDuration(500L).setListener(null).withEndAction(new Runnable() { // from class: com.facetec.sdk.丹道
            @Override // java.lang.Runnable
            public final void run() throws Throwable {
                this.f6785.aL();
            }
        }).start();
        if (!biVar.f95830g) {
            aN = (aQ + 37) % 128;
            biVar.c(0);
        }
        return null;
    }

    public final void A() {
        int i = aN + 75;
        aQ = i % 128;
        if (i % 2 == 0) {
            t.d(this, c.ID_FEEDBACK_SHOWN, null, null);
            U();
        } else {
            t.d(this, c.ID_FEEDBACK_SHOWN, null, null);
            U();
            throw null;
        }
    }

    /* JADX WARN: Removed duplicated region for block: B:11:0x0046  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public void B() {
        /*
            r9 = this;
            int r0 = com.facetec.sdk.bi.aN
            int r0 = r0 + 11
            int r0 = r0 % 128
            com.facetec.sdk.bi.aQ = r0
            com.facetec.sdk.t$b r0 = com.facetec.sdk.t.b.USER_WAS_SUCCESSFUL
            java.lang.Boolean r1 = java.lang.Boolean.FALSE
            java.lang.Object[] r6 = new java.lang.Object[]{r9, r0, r1}
            int r2 = com.facetec.sdk.FaceTecOCRConfirmationCustomization.d()
            int r5 = com.facetec.sdk.FaceTecOCRConfirmationCustomization.d()
            int r7 = com.facetec.sdk.FaceTecOCRConfirmationCustomization.d()
            int r8 = com.facetec.sdk.FaceTecOCRConfirmationCustomization.d()
            r3 = 1365199073(0x515f48e1, float:5.9937526E10)
            r4 = -1365199063(0xffffffffaea0b729, float:-7.3084934E-11)
            e(r2, r3, r4, r5, r6, r7, r8)
            boolean r0 = com.facetec.sdk.bj.d
            if (r0 != 0) goto L5e
            int r0 = com.facetec.sdk.bi.aQ
            int r0 = r0 + 117
            int r1 = r0 % 128
            com.facetec.sdk.bi.aN = r1
            int r0 = r0 % 2
            if (r0 != 0) goto L42
            com.facetec.sdk.d r0 = r9.S
            r1 = 39
            int r1 = r1 / 0
            if (r0 != 0) goto L54
            goto L46
        L42:
            com.facetec.sdk.d r0 = r9.S
            if (r0 != 0) goto L54
        L46:
            com.facetec.sdk.cx r0 = r9.f
            if (r0 != 0) goto L4b
            goto L54
        L4b:
            com.facetec.sdk.丹气 r0 = new com.facetec.sdk.丹气
            r0.<init>()
            r9.d(r0)
            return
        L54:
            com.facetec.sdk.FaceTecIDScanResult r0 = r9.aA
            com.facetec.sdk.FaceTecIDScanStatus r0 = r0.getStatus()
            r9.c(r0)
            return
        L5e:
            r0 = 0
            java.lang.Object[] r6 = new java.lang.Object[]{r9, r0, r1, r1}
            int r2 = com.facetec.sdk.FaceTecOCRConfirmationCustomization.d()
            int r5 = com.facetec.sdk.FaceTecOCRConfirmationCustomization.d()
            int r7 = com.facetec.sdk.FaceTecOCRConfirmationCustomization.d()
            int r8 = com.facetec.sdk.FaceTecOCRConfirmationCustomization.d()
            r3 = -1344204838(0xffffffffafe10fda, float:-4.0938525E-10)
            r4 = 1344204855(0x501ef037, float:1.0666171E10)
            e(r2, r3, r4, r5, r6, r7, r8)
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: com.facetec.sdk.bi.B():void");
    }

    public final void C() {
        aN = (aQ + 113) % 128;
        t.d(this, c.DEVELOPER_USED_ID_SCAN_CALLBACK, "cancel", null);
        c(this.aA.getStatus());
        int i = aN + 115;
        aQ = i % 128;
        if (i % 2 != 0) {
            int i2 = 59 / 0;
        }
    }

    public final void D() {
        Y();
        this.aD = new dl(new Runnable() { // from class: com.facetec.sdk.乐风
            @Override // java.lang.Runnable
            public final void run() {
                this.f6866.ar();
            }
        });
        Timer timer = new Timer();
        this.aG = timer;
        timer.scheduleAtFixedRate(this.aD, 250L, 500L);
        int i = aN + 39;
        aQ = i % 128;
        if (i % 2 != 0) {
            throw null;
        }
    }

    @Override // com.facetec.sdk.bm
    public final synchronized void a() {
        try {
            int i = aN + 1;
            int i2 = i % 128;
            aQ = i2;
            if (i % 2 != 0) {
                throw null;
            }
            ah ahVar = this.aj;
            if (ahVar != null) {
                aN = (i2 + 27) % 128;
                ahVar.a();
            }
            cv.j();
            if (FaceTecSessionActivity.c != null) {
                aQ = (aN + 113) % 128;
                this.f = cx.b(false, this.aK);
                if (FaceTecSDK.d.m.b == FaceTecCancelButtonCustomization.ButtonLocation.CUSTOM) {
                    ad();
                    aN = (aQ + 103) % 128;
                }
                this.c.b(new Runnable() { // from class: com.facetec.sdk.丹灵
                    @Override // java.lang.Runnable
                    public final void run() {
                        this.f6772.aF();
                    }
                }, 400L);
            }
            int i3 = aN + 97;
            aQ = i3 % 128;
            if (i3 % 2 != 0) {
                int i4 = 3 / 0;
            }
        } catch (Throwable th) {
            throw th;
        }
    }

    @Override // com.facetec.sdk.bm, android.app.Activity, android.view.ContextThemeWrapper, android.content.ContextWrapper
    public void attachBaseContext(Context context) {
        aN = (aQ + 9) % 128;
        super.attachBaseContext(context);
        aN = (aQ + 119) % 128;
    }

    @Override // com.facetec.sdk.bm
    public final synchronized void d(boolean z) {
        try {
            int i = aN;
            aQ = (i + 91) % 128;
            if (this.aw) {
                bv bvVar = this.A;
                if (bvVar != null) {
                    int i2 = i + 1;
                    aQ = i2 % 128;
                    if (i2 % 2 != 0) {
                        bvVar.h();
                        int i3 = 6 / 0;
                    } else {
                        bvVar.h();
                    }
                }
                return;
            }
            if (this.V) {
                return;
            }
            this.V = true;
            ah.c(z);
            if (this.W) {
                return;
            }
            if (!this.aw && !this.f95830g) {
                if (e() != bm.b.GRANTED) {
                    e(FaceTecSessionStatus.CONTEXT_SWITCH, (FaceTecIDScanStatus) null);
                } else if (!G()) {
                    aQ = (aN + 15) % 128;
                    e(FaceTecOCRConfirmationCustomization.d(), -1339677298, 1339677303, FaceTecOCRConfirmationCustomization.d(), new Object[]{this, Boolean.TRUE}, FaceTecOCRConfirmationCustomization.d(), FaceTecOCRConfirmationCustomization.d());
                    a(t.b.SESSION_CONTEXT_SWITCH);
                    e(FaceTecOCRConfirmationCustomization.d(), -1776803023, 1776803023, FaceTecOCRConfirmationCustomization.d(), new Object[]{this, Boolean.FALSE}, FaceTecOCRConfirmationCustomization.d(), FaceTecOCRConfirmationCustomization.d());
                }
                t.d(this, c.NON_FATAL_ERROR, FaceTecSessionStatus.CONTEXT_SWITCH.toString(), null);
                return;
            }
            t.d(this, c.NON_FATAL_ERROR, FaceTecIDScanStatus.CONTEXT_SWITCH.toString(), null);
        } catch (Throwable th) {
            throw th;
        }
    }

    @Override // com.facetec.sdk.bm
    public final void f() throws Throwable {
        int i = aN + 33;
        aQ = i % 128;
        try {
            if (i % 2 != 0) {
                ed.j();
                a(t.b.SESSION_TIMEOUT);
                af();
                j(true);
                d(10228);
                return;
            }
            ed.j();
            a(t.b.SESSION_TIMEOUT);
            af();
            j(false);
            d(400);
        } catch (Throwable th) {
            c cVar = c.SEVERE_ERROR;
            StringBuilder sb = new StringBuilder();
            FaceTecSessionStatus faceTecSessionStatus = FaceTecSessionStatus.UNKNOWN_INTERNAL_ERROR;
            sb.append(faceTecSessionStatus);
            sb.append(": ");
            sb.append(th.getMessage());
            t.d(this, th, cVar, sb.toString(), true, faceTecSessionStatus.ordinal());
            c(faceTecSessionStatus);
        }
    }

    @Override // com.facetec.sdk.bm
    public final synchronized void m() {
        try {
            int i = aQ + 87;
            aN = i % 128;
            if (i % 2 == 0) {
                a(t.b.USER_CANCELLED);
                c cVar = c.NON_FATAL_ERROR;
                FaceTecSessionStatus faceTecSessionStatus = FaceTecSessionStatus.USER_CANCELLED;
                t.d(this, cVar, faceTecSessionStatus.toString(), null);
                e(faceTecSessionStatus, (FaceTecIDScanStatus) null);
                throw null;
            }
            a(t.b.USER_CANCELLED);
            c cVar2 = c.NON_FATAL_ERROR;
            FaceTecSessionStatus faceTecSessionStatus2 = FaceTecSessionStatus.USER_CANCELLED;
            t.d(this, cVar2, faceTecSessionStatus2.toString(), null);
            e(faceTecSessionStatus2, (FaceTecIDScanStatus) null);
            int i2 = aQ + 65;
            aN = i2 % 128;
            if (i2 % 2 == 0) {
                throw null;
            }
        } catch (Throwable th) {
            throw th;
        }
    }

    @Override // com.facetec.sdk.bm
    public final void n() {
        int i = aQ + 91;
        aN = i % 128;
        if (i % 2 != 0) {
            W();
            S();
        } else {
            W();
            S();
            throw null;
        }
    }

    @Override // android.app.Activity
    public synchronized void onBackPressed() {
        try {
            int i = aQ + 107;
            aN = i % 128;
            if (i % 2 == 0) {
                R();
                int i2 = 49 / 0;
            } else {
                R();
            }
            aQ = (aN + 91) % 128;
        } catch (Throwable th) {
            throw th;
        }
    }

    /* JADX WARN: Removed duplicated region for block: B:82:0x02a6  */
    @Override // com.facetec.sdk.bm, android.app.Activity
    @android.annotation.SuppressLint({"ClickableViewAccessibility"})
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public synchronized void onCreate(android.os.Bundle r16) {
        /*
            Method dump skipped, instruction units count: 1208
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: com.facetec.sdk.bi.onCreate(android.os.Bundle):void");
    }

    @Override // com.facetec.sdk.bm, android.app.Activity
    public void onDestroy() {
        aQ = (aN + 125) % 128;
        super.onDestroy();
        if (Build.VERSION.SDK_INT >= 33) {
            int i = aQ;
            aN = (i + 79) % 128;
            if (this.aI != null) {
                aN = (i + 73) % 128;
                getOnBackInvokedDispatcher().unregisterOnBackInvokedCallback(this.aI);
            }
        }
        if (dq.c) {
            dq.d((bi) null);
        }
        ed.c();
        ed.a();
        FaceTecSDK.c = FaceTecSDK.c.NORMAL;
        e eVar = this.H;
        if (eVar == e.PRE_SESSION_STARTED) {
            cv.g(true);
        } else if (eVar == e.FACESCAN_SESSION_STARTED) {
            aN = (aQ + 19) % 128;
            cv.e(true);
        }
        this.H = e.NOT_STARTED;
        Handler handler = this.a;
        if (handler != null) {
            aN = (aQ + 57) % 128;
            handler.removeCallbacksAndMessages(null);
        }
        cc ccVar = this.M;
        if (ccVar != null) {
            aQ = (aN + 117) % 128;
            ccVar.c();
        }
        e(true);
        ed.j();
        e(FaceTecOCRConfirmationCustomization.d(), -1899780412, 1899780426, FaceTecOCRConfirmationCustomization.d(), new Object[]{this}, FaceTecOCRConfirmationCustomization.d(), FaceTecOCRConfirmationCustomization.d());
        J();
        cr crVar = this.aL;
        if (crVar != null) {
            unregisterReceiver(crVar);
        }
        aN = (aQ + 15) % 128;
    }

    @Override // android.app.Activity
    public void onNewIntent(Intent intent) {
        int i = aQ + 103;
        aN = i % 128;
        if (i % 2 == 0) {
            super.onNewIntent(intent);
            int i2 = 35 / 0;
            if (this.s == null) {
                return;
            }
        } else {
            super.onNewIntent(intent);
            if (this.s == null) {
                return;
            }
        }
        cf cfVar = this.s;
        eg egVar = cfVar.a;
        if (egVar != null) {
            this.t = true;
            if (egVar.c(intent, cfVar.c)) {
                aN = (aQ + 29) % 128;
                this.s.d();
            }
        }
    }

    @Override // com.facetec.sdk.bm, android.app.Activity
    public void onPause() {
        int i = aN + 47;
        aQ = i % 128;
        if (i % 2 != 0) {
            super.onPause();
            t.d(this, c.FACETEC_SESSION_ACTIVITY_ON_PAUSE, null, null);
            int i2 = 74 / 0;
            if (e() != bm.b.GRANTED) {
                return;
            }
        } else {
            super.onPause();
            t.d(this, c.FACETEC_SESSION_ACTIVITY_ON_PAUSE, null, null);
            if (e() != bm.b.GRANTED) {
                return;
            }
        }
        Y();
        if (this.ak) {
            int i3 = aN + 67;
            aQ = i3 % 128;
            if (i3 % 2 != 0) {
                this.aq = false;
                return;
            } else {
                this.aq = true;
                return;
            }
        }
        if (ah.c) {
            aN = (aQ + 21) % 128;
            return;
        }
        if (isFinishing()) {
            dj.a(new Runnable() { // from class: com.facetec.sdk.乐兵
                @Override // java.lang.Runnable
                public final void run() {
                    this.f6806.aN();
                }
            });
            aQ = (aN + 9) % 128;
        } else if (!d()) {
            d(false);
        }
        ed.j();
    }

    /* JADX WARN: Removed duplicated region for block: B:16:0x0047 A[Catch: all -> 0x00c2, TRY_LEAVE, TryCatch #0 {all -> 0x00c2, blocks: (B:3:0x0001, B:5:0x000a, B:16:0x0047, B:37:0x0096, B:21:0x0058, B:14:0x0034, B:23:0x005c), top: B:68:0x0001, inners: #2 }] */
    /* JADX WARN: Removed duplicated region for block: B:48:0x00c9 A[Catch: all -> 0x00bf, TryCatch #3 {all -> 0x00bf, blocks: (B:46:0x00c5, B:48:0x00c9, B:50:0x00d5, B:57:0x00ea, B:58:0x00eb, B:61:0x00fb, B:39:0x00b5, B:66:0x0115, B:52:0x00e5), top: B:74:0x0001, inners: #1 }] */
    /* JADX WARN: Removed duplicated region for block: B:61:0x00fb A[Catch: all -> 0x00bf, TRY_ENTER, TRY_LEAVE, TryCatch #3 {all -> 0x00bf, blocks: (B:46:0x00c5, B:48:0x00c9, B:50:0x00d5, B:57:0x00ea, B:58:0x00eb, B:61:0x00fb, B:39:0x00b5, B:66:0x0115, B:52:0x00e5), top: B:74:0x0001, inners: #1 }] */
    @Override // android.app.Activity
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public synchronized void onRequestPermissionsResult(int r9, @androidx.annotation.NonNull java.lang.String[] r10, @androidx.annotation.NonNull int[] r11) throws java.lang.Throwable {
        /*
            Method dump skipped, instruction units count: 279
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: com.facetec.sdk.bi.onRequestPermissionsResult(int, java.lang.String[], int[]):void");
    }

    /* JADX WARN: Removed duplicated region for block: B:23:0x0041 A[Catch: all -> 0x0039, TryCatch #3 {all -> 0x0039, blocks: (B:3:0x0001, B:8:0x001d, B:10:0x0023, B:12:0x002f, B:23:0x0041, B:25:0x004b, B:30:0x0055, B:31:0x0056, B:18:0x0038, B:21:0x003d, B:32:0x005b, B:34:0x005f, B:36:0x0065, B:37:0x0070, B:39:0x0075, B:42:0x007b, B:44:0x0087, B:47:0x008c, B:48:0x008f, B:50:0x0093, B:53:0x009a, B:55:0x009e, B:59:0x00a4, B:61:0x00aa, B:63:0x00ae, B:65:0x00b4, B:70:0x00c5, B:94:0x0108, B:102:0x011c, B:27:0x0052, B:14:0x0033, B:98:0x0116), top: B:113:0x0001, inners: #1, #2 }] */
    /* JADX WARN: Removed duplicated region for block: B:34:0x005f A[Catch: all -> 0x0039, TryCatch #3 {all -> 0x0039, blocks: (B:3:0x0001, B:8:0x001d, B:10:0x0023, B:12:0x002f, B:23:0x0041, B:25:0x004b, B:30:0x0055, B:31:0x0056, B:18:0x0038, B:21:0x003d, B:32:0x005b, B:34:0x005f, B:36:0x0065, B:37:0x0070, B:39:0x0075, B:42:0x007b, B:44:0x0087, B:47:0x008c, B:48:0x008f, B:50:0x0093, B:53:0x009a, B:55:0x009e, B:59:0x00a4, B:61:0x00aa, B:63:0x00ae, B:65:0x00b4, B:70:0x00c5, B:94:0x0108, B:102:0x011c, B:27:0x0052, B:14:0x0033, B:98:0x0116), top: B:113:0x0001, inners: #1, #2 }] */
    /* JADX WARN: Removed duplicated region for block: B:39:0x0075 A[Catch: all -> 0x0039, TryCatch #3 {all -> 0x0039, blocks: (B:3:0x0001, B:8:0x001d, B:10:0x0023, B:12:0x002f, B:23:0x0041, B:25:0x004b, B:30:0x0055, B:31:0x0056, B:18:0x0038, B:21:0x003d, B:32:0x005b, B:34:0x005f, B:36:0x0065, B:37:0x0070, B:39:0x0075, B:42:0x007b, B:44:0x0087, B:47:0x008c, B:48:0x008f, B:50:0x0093, B:53:0x009a, B:55:0x009e, B:59:0x00a4, B:61:0x00aa, B:63:0x00ae, B:65:0x00b4, B:70:0x00c5, B:94:0x0108, B:102:0x011c, B:27:0x0052, B:14:0x0033, B:98:0x0116), top: B:113:0x0001, inners: #1, #2 }] */
    /* JADX WARN: Removed duplicated region for block: B:50:0x0093 A[Catch: all -> 0x0039, TRY_LEAVE, TryCatch #3 {all -> 0x0039, blocks: (B:3:0x0001, B:8:0x001d, B:10:0x0023, B:12:0x002f, B:23:0x0041, B:25:0x004b, B:30:0x0055, B:31:0x0056, B:18:0x0038, B:21:0x003d, B:32:0x005b, B:34:0x005f, B:36:0x0065, B:37:0x0070, B:39:0x0075, B:42:0x007b, B:44:0x0087, B:47:0x008c, B:48:0x008f, B:50:0x0093, B:53:0x009a, B:55:0x009e, B:59:0x00a4, B:61:0x00aa, B:63:0x00ae, B:65:0x00b4, B:70:0x00c5, B:94:0x0108, B:102:0x011c, B:27:0x0052, B:14:0x0033, B:98:0x0116), top: B:113:0x0001, inners: #1, #2 }] */
    /* JADX WARN: Removed duplicated region for block: B:53:0x009a A[Catch: all -> 0x0039, TRY_ENTER, TryCatch #3 {all -> 0x0039, blocks: (B:3:0x0001, B:8:0x001d, B:10:0x0023, B:12:0x002f, B:23:0x0041, B:25:0x004b, B:30:0x0055, B:31:0x0056, B:18:0x0038, B:21:0x003d, B:32:0x005b, B:34:0x005f, B:36:0x0065, B:37:0x0070, B:39:0x0075, B:42:0x007b, B:44:0x0087, B:47:0x008c, B:48:0x008f, B:50:0x0093, B:53:0x009a, B:55:0x009e, B:59:0x00a4, B:61:0x00aa, B:63:0x00ae, B:65:0x00b4, B:70:0x00c5, B:94:0x0108, B:102:0x011c, B:27:0x0052, B:14:0x0033, B:98:0x0116), top: B:113:0x0001, inners: #1, #2 }] */
    @Override // com.facetec.sdk.bm, android.app.Activity
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public synchronized void onResume() throws java.lang.Throwable {
        /*
            Method dump skipped, instruction units count: 329
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: com.facetec.sdk.bi.onResume():void");
    }

    @Override // com.facetec.sdk.bm, android.app.Activity
    public void onStart() {
        aN = (aQ + 37) % 128;
        super.onStart();
        aN = (aQ + 21) % 128;
    }

    @Override // android.app.Activity
    public void onStop() {
        aQ = (aN + 77) % 128;
        super.onStop();
        if (e() == bm.b.GRANTED && !this.al) {
            cf cfVar = this.s;
            if (cfVar != null) {
                cfVar.e();
                aN = (aQ + EnumC41897g.SDK_ASSET_ILLUSTRATION_CALENDAR_VALUE) % 128;
            }
            this.G = true;
            if (ah.c) {
                return;
            }
            aN = (aQ + 119) % 128;
            if (this.ab || this.ah || this.aa) {
                return;
            }
            e(FaceTecOCRConfirmationCustomization.d(), -1339677298, 1339677303, FaceTecOCRConfirmationCustomization.d(), new Object[]{this, Boolean.TRUE}, FaceTecOCRConfirmationCustomization.d(), FaceTecOCRConfirmationCustomization.d());
            ed.j();
            ah ahVar = this.aj;
            if (ahVar != null) {
                aN = (aQ + 25) % 128;
                if (ahVar instanceof ap) {
                    return;
                }
            }
            if (this.al) {
                return;
            }
            e(true);
        }
    }

    @Override // android.app.Activity, android.view.Window.Callback
    public void onWindowFocusChanged(boolean z) {
        this.al = z;
        t.d(this, c.FACETEC_SESSION_ACTIVITY_ON_WINDOW_FOCUS_CHANGED, "Has Focus: ".concat(String.valueOf(z)), null);
        if (e() != bm.b.GRANTED) {
            return;
        }
        if (!z) {
            if (d() || isFinishing()) {
                return;
            }
            d(z);
            return;
        }
        if (G()) {
            return;
        }
        synchronized (this) {
            try {
                boolean z2 = this.ab;
                if (z2 && !this.f95830g) {
                    e(FaceTecOCRConfirmationCustomization.d(), 515625104, -515625082, FaceTecOCRConfirmationCustomization.d(), new Object[]{this, FaceTecIDScanNextStep.SELECTION_SCREEN}, FaceTecOCRConfirmationCustomization.d(), FaceTecOCRConfirmationCustomization.d());
                } else if (z2 && this.f95830g && !this.aw) {
                    w();
                } else if (this.ah || !(!this.V || this.G || this.f95830g || this.aw)) {
                    E();
                } else if (this.A != null && this.aB) {
                    U();
                } else if (this.ad) {
                    M();
                } else if (this.ag) {
                    K();
                } else if (this.ae) {
                    N();
                }
            } catch (Throwable th) {
                throw th;
            }
        }
    }

    public synchronized void p() {
        aN = (aQ + EnumC41897g.SDK_ASSET_ILLUSTRATION_CALENDAR_VALUE) % 128;
        this.A.d();
        aN = (aQ + 89) % 128;
    }

    @Override // com.facetec.sdk.bm
    public final synchronized void r() {
        if (this.aw) {
            aN = (aQ + 57) % 128;
            c(FaceTecIDScanStatus.SUCCESS);
            return;
        }
        a(FaceTecSessionStatus.SESSION_COMPLETED_SUCCESSFULLY);
        int i = aN + 43;
        aQ = i % 128;
        if (i % 2 == 0) {
        } else {
            throw null;
        }
    }

    @Override // com.facetec.sdk.bm
    public final void s() {
        aQ = (aN + 61) % 128;
        if (!this.f95830g) {
            a(FaceTecSessionStatus.CAMERA_PERMISSION_DENIED);
            return;
        }
        e(FaceTecIDScanStatus.CAMERA_PERMISSION_DENIED);
        int i = aN + 71;
        aQ = i % 128;
        if (i % 2 != 0) {
            throw null;
        }
    }

    public final boolean t() {
        int i = aN;
        boolean z = this.V;
        int i2 = i + 7;
        aQ = i2 % 128;
        if (i2 % 2 == 0) {
            return z;
        }
        throw null;
    }

    public final void u() {
        bv bvVar;
        if (isFinishing()) {
            return;
        }
        aQ = (aN + 13) % 128;
        bv bvVar2 = this.A;
        if (bvVar2 == null) {
            return;
        }
        if (bvVar2.f95839g == bv.b.FRONT) {
            this.aK = cx.d.FRONT_SIDE;
        } else {
            this.aK = cx.d.BACK_SIDE;
        }
        if (!isFinishing() && (bvVar = this.A) != null) {
            this.e.a(bvVar.o);
            getFragmentManager().beginTransaction().remove(this.A).commitAllowingStateLoss();
            this.A = null;
        }
        this.f = cx.b(true, this.aK);
        getFragmentManager().beginTransaction().add(this.an, this.f, "Results").commitAllowingStateLoss();
        if (FaceTecSDK.d.m.b == FaceTecCancelButtonCustomization.ButtonLocation.CUSTOM) {
            ad();
        }
        b(new b() { // from class: com.facetec.sdk.丹火
            @Override // com.facetec.sdk.bi.b
            public final byte[] getIdScanBytes(String str) {
                return this.f6771.g(str);
            }
        });
        aQ = (aN + 85) % 128;
    }

    public final void v() {
        e(FaceTecOCRConfirmationCustomization.d(), -302800720, 302800746, FaceTecOCRConfirmationCustomization.d(), new Object[]{this}, FaceTecOCRConfirmationCustomization.d(), FaceTecOCRConfirmationCustomization.d());
    }

    public final void w() {
        boolean z;
        int i = aN + 95;
        aQ = i % 128;
        if (i % 2 != 0) {
            e(FaceTecOCRConfirmationCustomization.d(), 1078511809, -1078511801, FaceTecOCRConfirmationCustomization.d(), new Object[]{this, this.B, Boolean.FALSE}, FaceTecOCRConfirmationCustomization.d(), FaceTecOCRConfirmationCustomization.d());
            z = false;
        } else {
            e(FaceTecOCRConfirmationCustomization.d(), 1078511809, -1078511801, FaceTecOCRConfirmationCustomization.d(), new Object[]{this, this.B, Boolean.TRUE}, FaceTecOCRConfirmationCustomization.d(), FaceTecOCRConfirmationCustomization.d());
            z = true;
        }
        this.ab = z;
    }

    public final void x() {
        int i;
        int i2 = aN;
        int i3 = i2 + 61;
        int i4 = i3 % 128;
        aQ = i4;
        if (i3 % 2 != 0) {
            throw null;
        }
        if (this.af) {
            int i5 = i2 + 41;
            aQ = i5 % 128;
            if (i5 % 2 != 0) {
                throw null;
            }
            return;
        }
        this.af = true;
        if (this.f95830g) {
            int i6 = i4 + 119;
            int i7 = i6 % 128;
            aN = i7;
            i = i6 % 2 == 0 ? 36 : 50;
            aQ = (i7 + 113) % 128;
        } else {
            i = 400;
        }
        new Handler(Looper.getMainLooper()).postDelayed(new Runnable() { // from class: com.facetec.sdk.乐凤
            @Override // java.lang.Runnable
            public final void run() {
                this.f6807.aH();
            }
        }, i);
    }

    public final void y() {
        e(FaceTecOCRConfirmationCustomization.d(), 1604057232, -1604057231, FaceTecOCRConfirmationCustomization.d(), new Object[]{this}, FaceTecOCRConfirmationCustomization.d(), FaceTecOCRConfirmationCustomization.d());
    }

    public final void z() {
        aQ = (aN + 33) % 128;
        final String strA = dm.a(ck.SKIPPED, this.ar);
        this.f.b(new Runnable() { // from class: com.facetec.sdk.乐宫
            @Override // java.lang.Runnable
            public final void run() {
                this.f6825.f(strA);
            }
        }, 500L);
        int i = aN + 37;
        aQ = i % 128;
        if (i % 2 != 0) {
            int i2 = 95 / 0;
        }
    }

    /* JADX WARN: Code restructure failed: missing block: B:23:0x009c, code lost:
    
        if (r1 == false) goto L30;
     */
    /* JADX WARN: Removed duplicated region for block: B:12:0x002a  */
    @Override // com.facetec.sdk.bm
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public final void i() throws java.lang.Throwable {
        /*
            Method dump skipped, instruction units count: 296
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: com.facetec.sdk.bi.i():void");
    }

    @Override // com.facetec.sdk.bm
    public final synchronized void c() throws Throwable {
        try {
        } catch (Throwable th) {
            th = th;
        }
        try {
            aN = (aQ + 43) % 128;
            av.b(this);
            a(t.b.USER_WAS_SUCCESSFUL);
            cv.L(ao.ae, ((PowerManager) getSystemService("power")).isPowerSaveMode());
            af();
            try {
                ce.c(this);
            } catch (Throwable th2) {
                t.d(this, c.LOG_SUCCESSFUL_ENROLLMENT_ERROR, th2.getMessage(), th2);
            }
            this.W = true;
            this.U = true;
            if (FaceTecSDK.d.vocalGuidanceCustomization.mode == FaceTecVocalGuidanceCustomization.VocalGuidanceMode.FULL_VOCAL_GUIDANCE) {
                ed.d(this, ed.d.UPLOADING);
            }
            try {
                ab();
                int i = aQ + 91;
                aN = i % 128;
                if (i % 2 == 0) {
                    int i2 = 48 / 0;
                }
            } catch (Throwable th3) {
                t.d(this, th3, c.ASYNC_FACE_SCAN_SUCCESS_TASK_ERROR, th3.getMessage(), true, FaceTecSessionStatus.UNKNOWN_INTERNAL_ERROR.ordinal());
                c(FaceTecSessionStatus.UNKNOWN_INTERNAL_ERROR);
            }
        } catch (Throwable th4) {
            th = th4;
            throw th;
        }
    }

    private static /* synthetic */ Object k(Object[] objArr) {
        final bi biVar = (bi) objArr[0];
        final boolean zBooleanValue = ((Boolean) objArr[1]).booleanValue();
        aQ = (aN + 105) % 128;
        biVar.aB = false;
        biVar.getFragmentManager().beginTransaction().replace(biVar.an, biVar.A, "IDScan").commitAllowingStateLoss();
        biVar.e.c(biVar.A.o);
        biVar.A.b(new Runnable() { // from class: com.facetec.sdk.乐神
            @Override // java.lang.Runnable
            public final void run() {
                this.f6854.l(zBooleanValue);
            }
        }, 100L);
        int i = aQ + 13;
        aN = i % 128;
        if (i % 2 != 0) {
            return null;
        }
        throw null;
    }

    /* JADX WARN: Removed duplicated region for block: B:9:0x001d  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    private static /* synthetic */ java.lang.Object o(java.lang.Object[] r3) {
        /*
            r0 = 0
            r3 = r3[r0]
            com.facetec.sdk.bi r3 = (com.facetec.sdk.bi) r3
            int r1 = com.facetec.sdk.bi.aN
            int r1 = r1 + 121
            int r2 = r1 % 128
            com.facetec.sdk.bi.aQ = r2
            int r1 = r1 % 2
            if (r1 == 0) goto L19
            com.facetec.sdk.m r1 = r3.k
            r2 = 11
            int r2 = r2 / r0
            if (r1 == 0) goto L2a
            goto L1d
        L19:
            com.facetec.sdk.m r0 = r3.k
            if (r0 == 0) goto L2a
        L1d:
            com.facetec.sdk.m r3 = r3.k
            r3.b()
            int r3 = com.facetec.sdk.bi.aN
            int r3 = r3 + 5
            int r3 = r3 % 128
            com.facetec.sdk.bi.aQ = r3
        L2a:
            int r3 = com.facetec.sdk.bi.aQ
            int r3 = r3 + 1
            int r0 = r3 % 128
            com.facetec.sdk.bi.aN = r0
            int r3 = r3 % 2
            r0 = 0
            if (r3 == 0) goto L38
            return r0
        L38:
            throw r0
        */
        throw new UnsupportedOperationException("Method not decompiled: com.facetec.sdk.bi.o(java.lang.Object[]):java.lang.Object");
    }

    @Override // com.facetec.sdk.bm
    public final void g() {
        aQ = (aN + 21) % 128;
        this.L = null;
        this.c = bd.d();
        this.X = false;
        W();
        S();
        aN = (aQ + 99) % 128;
    }

    @Override // com.facetec.sdk.bm
    public final void j() {
        Runnable runnable;
        int i = aN + 75;
        aQ = i % 128;
        if (i % 2 != 0) {
            this.X = false;
            this.aj.e();
            runnable = new Runnable() { // from class: com.facetec.sdk.丹金
                @Override // java.lang.Runnable
                public final void run() throws Throwable {
                    cb.b();
                }
            };
        } else {
            this.X = true;
            this.aj.e();
            runnable = new Runnable() { // from class: com.facetec.sdk.丹金
                @Override // java.lang.Runnable
                public final void run() throws Throwable {
                    cb.b();
                }
            };
        }
        dj.a(runnable);
    }

    private static /* synthetic */ Object n(Object[] objArr) {
        bi biVar = (bi) objArr[0];
        int i = aN + 3;
        aQ = i % 128;
        if (i % 2 == 0) {
            biVar.c(biVar.aA.getStatus());
            return null;
        }
        biVar.c(biVar.aA.getStatus());
        throw null;
    }

    @Override // com.facetec.sdk.bm
    public final synchronized void h() throws Throwable {
        try {
            try {
                aN = (aQ + 87) % 128;
                a(t.b.USER_FAILED);
                af();
                try {
                    j(true);
                    this.i = dd.r();
                    this.c.b(new Runnable() { // from class: com.facetec.sdk.乐魂
                        @Override // java.lang.Runnable
                        public final void run() throws Throwable {
                            this.f6868.aC();
                        }
                    }, 400L);
                    aQ = (aN + 35) % 128;
                } catch (Throwable th) {
                    c cVar = c.SEVERE_ERROR;
                    StringBuilder sb = new StringBuilder();
                    FaceTecSessionStatus faceTecSessionStatus = FaceTecSessionStatus.UNKNOWN_INTERNAL_ERROR;
                    sb.append(faceTecSessionStatus);
                    sb.append(": ");
                    sb.append(th.getMessage());
                    t.d(this, th, cVar, sb.toString(), true, faceTecSessionStatus.ordinal());
                    c(faceTecSessionStatus);
                }
            } catch (Throwable th2) {
                th = th2;
                throw th;
            }
        } catch (Throwable th3) {
            th = th3;
            throw th;
        }
    }

    @Override // com.facetec.sdk.bm
    public final synchronized void q() {
        e(FaceTecOCRConfirmationCustomization.d(), -1339677298, 1339677303, FaceTecOCRConfirmationCustomization.d(), new Object[]{this, Boolean.FALSE}, FaceTecOCRConfirmationCustomization.d(), FaceTecOCRConfirmationCustomization.d());
        c cVar = c.NON_FATAL_ERROR;
        FaceTecIDScanStatus faceTecIDScanStatus = FaceTecIDScanStatus.LANDSCAPE_MODE_NOT_ALLOWED;
        t.d(this, cVar, faceTecIDScanStatus.toString(), null);
        if (this.aw) {
            if (this.f95830g) {
                aN = (aQ + 115) % 128;
                e((FaceTecSessionStatus) null, faceTecIDScanStatus);
                return;
            } else {
                e(this.z.getStatus(), faceTecIDScanStatus);
                return;
            }
        }
        e(FaceTecSessionStatus.LANDSCAPE_MODE_NOT_ALLOWED, (FaceTecIDScanStatus) null);
        aQ = (aN + 83) % 128;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void l(boolean z) {
        aQ = (aN + 63) % 128;
        this.A.b(z);
        aQ = (aN + 87) % 128;
    }

    private static /* synthetic */ Object m(Object[] objArr) {
        m mVar;
        bi biVar = (bi) objArr[0];
        boolean zBooleanValue = ((Boolean) objArr[1]).booleanValue();
        if (bk.e()) {
            aQ = (aN + 95) % 128;
            biVar.P = cv.b(biVar, false);
            biVar.O = cv.a(biVar, false);
            if (biVar.O.length > 0) {
                biVar.I = BitmapFactory.decodeByteArray(biVar.O[0], 0, biVar.O[0].length);
            }
        }
        try {
            if (!(!bk.b())) {
                int i = aQ + 103;
                aN = i % 128;
                if (i % 2 == 0) {
                    throw null;
                }
                if (zBooleanValue) {
                    FaceTecSessionResult faceTecSessionResult = new FaceTecSessionResult(FaceTecSessionStatus.SESSION_UNSUCCESSFUL, biVar.P, biVar.O, cv.p());
                    faceTecSessionResult.a(cp.c);
                    m mVar2 = biVar.k;
                    if (mVar2 != null) {
                        mVar2.c(faceTecSessionResult, bk.a);
                    }
                }
            }
        } catch (Exception unused) {
        }
        if (bk.b() && (mVar = biVar.k) != null) {
            mVar.b();
            aQ = (aN + 19) % 128;
        }
        if (biVar.c != null) {
            aQ = (aN + 29) % 128;
            biVar.c.c();
        }
        return null;
    }

    @Override // com.facetec.sdk.bm
    public final synchronized void o() throws Throwable {
        try {
            try {
                int i = aN + 81;
                aQ = i % 128;
                if (i % 2 == 0) {
                    Handler handler = this.a;
                    if (handler != null) {
                        handler.removeCallbacks(null);
                    }
                    if (this.aw) {
                        e(FaceTecOCRConfirmationCustomization.d(), -1339677298, 1339677303, FaceTecOCRConfirmationCustomization.d(), new Object[]{this, Boolean.FALSE}, FaceTecOCRConfirmationCustomization.d(), FaceTecOCRConfirmationCustomization.d());
                        if (this.f95830g) {
                            e(FaceTecSessionStatus.USER_CANCELLED, FaceTecIDScanStatus.USER_CANCELED);
                            return;
                        } else {
                            if (this.X) {
                                a(t.b.USER_CANCELLED);
                                e(this.z.getStatus(), FaceTecIDScanStatus.USER_CANCELED);
                                aQ = (aN + 25) % 128;
                                return;
                            }
                            e(this.z.getStatus(), FaceTecIDScanStatus.USER_CANCELED);
                            return;
                        }
                    }
                    a(t.b.USER_CANCELLED);
                    e(FaceTecOCRConfirmationCustomization.d(), -1776803023, 1776803023, FaceTecOCRConfirmationCustomization.d(), new Object[]{this, Boolean.FALSE}, FaceTecOCRConfirmationCustomization.d(), FaceTecOCRConfirmationCustomization.d());
                    cp cpVar = this.e;
                    if (cpVar == null) {
                        t.d(this, c.PHOENIX_HANDLER_UNEXPECTED_NULL, "Coming from onUserCancelled(). Activity State Info: ", null);
                    } else {
                        cpVar.e = true;
                        cpVar.d = true;
                        e eVar = this.H;
                        if (eVar == e.PRE_SESSION_STARTED) {
                            aQ = (aN + 13) % 128;
                            cpVar.i();
                            aN = (aQ + 33) % 128;
                        } else if (eVar == e.FACESCAN_SESSION_STARTED) {
                            cpVar.a(true);
                        }
                    }
                    try {
                        d(400);
                        return;
                    } catch (Throwable th) {
                        c cVar = c.SEVERE_ERROR;
                        StringBuilder sb = new StringBuilder("Unknown error: ");
                        sb.append(th.getMessage());
                        t.d(this, th, cVar, sb.toString(), true, FaceTecSessionStatus.UNKNOWN_INTERNAL_ERROR.ordinal());
                        e(FaceTecSessionStatus.UNKNOWN_INTERNAL_ERROR, (FaceTecIDScanStatus) null);
                        return;
                    }
                }
                throw null;
            } catch (Throwable th2) {
                th = th2;
            }
        } catch (Throwable th3) {
            th = th3;
        }
        throw th;
    }

    public final void b(final FaceTecIDScanNextStep faceTecIDScanNextStep) {
        t.d(this, c.DEVELOPER_USED_FACESCAN_CALLBACK, "succeed", null);
        if (FaceTecSDK.d.vocalGuidanceCustomization.mode == FaceTecVocalGuidanceCustomization.VocalGuidanceMode.FULL_VOCAL_GUIDANCE) {
            aN = (aQ + 43) % 128;
            ed.d(this, ed.d.SUCCESS);
        } else if (!ed.e) {
            aN = (aQ + 75) % 128;
            SharedPreferences.Editor editorEdit = ed.b.edit();
            editorEdit.putBoolean("facetecMoveCloserSoundHasBeenPlayed", true);
            editorEdit.apply();
        }
        if (FaceTecSessionActivity.f != null) {
            this.ab = true;
        }
        runOnUiThread(new Runnable() { // from class: com.facetec.sdk.乐剑
            @Override // java.lang.Runnable
            public final void run() {
                this.f6808.d(faceTecIDScanNextStep);
            }
        });
    }

    @Override // com.facetec.sdk.bm
    public final synchronized void l() {
        int i = aN + 13;
        aQ = i % 128;
        if (i % 2 == 0) {
            t.d(this, c.NON_FATAL_ERROR, FaceTecSessionStatus.USER_CANCELLED.toString(), null);
            cp cpVar = this.e;
            if (cpVar == null) {
                aN = (aQ + 11) % 128;
                return;
            }
            cpVar.i();
            this.e.a(true);
            if (!this.e.b(this, false)) {
                d(ao.q);
            }
            if (this.i != null) {
                this.i.t();
            }
            return;
        }
        t.d(this, c.NON_FATAL_ERROR, FaceTecSessionStatus.USER_CANCELLED.toString(), null);
        throw null;
    }

    private static /* synthetic */ Object g(Object[] objArr) {
        final bi biVar = (bi) objArr[0];
        final FaceTecIDScanNextStep faceTecIDScanNextStep = (FaceTecIDScanNextStep) objArr[1];
        final boolean zBooleanValue = ((Boolean) objArr[2]).booleanValue();
        final boolean zBooleanValue2 = ((Boolean) objArr[3]).booleanValue();
        e(FaceTecOCRConfirmationCustomization.d(), -1899780412, 1899780426, FaceTecOCRConfirmationCustomization.d(), new Object[]{biVar}, FaceTecOCRConfirmationCustomization.d(), FaceTecOCRConfirmationCustomization.d());
        t.f95949g = 0;
        biVar.aE = new dl(new Runnable() { // from class: com.facetec.sdk.乐气
            @Override // java.lang.Runnable
            public final void run() throws Throwable {
                this.f6839.d(zBooleanValue, zBooleanValue2, faceTecIDScanNextStep);
            }
        });
        Timer timer = new Timer();
        biVar.aF = timer;
        timer.scheduleAtFixedRate(biVar.aE, 0L, 1000L);
        int i = aQ + 87;
        aN = i % 128;
        if (i % 2 != 0) {
            return null;
        }
        throw null;
    }

    @Override // com.facetec.sdk.bm
    public final void k() {
        int i = aN + 99;
        aQ = i % 128;
        if (i % 2 != 0) {
            e(FaceTecOCRConfirmationCustomization.d(), -1776803023, 1776803023, FaceTecOCRConfirmationCustomization.d(), new Object[]{this, Boolean.TRUE}, FaceTecOCRConfirmationCustomization.d(), FaceTecOCRConfirmationCustomization.d());
        } else {
            e(FaceTecOCRConfirmationCustomization.d(), -1776803023, 1776803023, FaceTecOCRConfirmationCustomization.d(), new Object[]{this, Boolean.FALSE}, FaceTecOCRConfirmationCustomization.d(), FaceTecOCRConfirmationCustomization.d());
        }
        a(t.b.USER_CANCELLED);
        c cVar = c.NON_FATAL_ERROR;
        FaceTecSessionStatus faceTecSessionStatus = FaceTecSessionStatus.USER_CANCELLED;
        t.d(this, cVar, faceTecSessionStatus.toString(), null);
        e(faceTecSessionStatus, (FaceTecIDScanStatus) null);
        aQ = (aN + 51) % 128;
    }

    private static /* synthetic */ Object j(Object[] objArr) throws Throwable {
        bi biVar = (bi) objArr[0];
        int i = aN + 105;
        aQ = i % 128;
        int i2 = i % 2;
        biVar.E();
        if (i2 == 0) {
            return null;
        }
        throw null;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void f(FaceTecIDScanNextStep faceTecIDScanNextStep) {
        int i = aQ + 111;
        aN = i % 128;
        int i2 = i % 2;
        c(faceTecIDScanNextStep);
        if (i2 == 0) {
            int i3 = 59 / 0;
        }
        int i4 = aQ + 19;
        aN = i4 % 128;
        if (i4 % 2 == 0) {
            throw null;
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ byte[] j(String str) {
        byte[] bArrQ;
        int i = aQ + 13;
        aN = i % 128;
        if (i % 2 == 0) {
            bArrQ = cv.q(str, this.D, true, false, bk.j(this).getBoolean(ao.ab, true));
        } else {
            bArrQ = cv.q(str, this.D, false, true, bk.j(this).getBoolean(ao.ab, false));
        }
        aQ = (aN + 105) % 128;
        return bArrQ;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void f(String str) {
        aN = (aQ + 125) % 128;
        this.f.a(false, true, str, new Runnable() { // from class: com.facetec.sdk.乐字
            @Override // java.lang.Runnable
            public final void run() {
                this.f6824.aj();
            }
        });
        aN = (aQ + 97) % 128;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void f(final boolean z) {
        aN = (aQ + 55) % 128;
        getFragmentManager().beginTransaction().remove(this.f).commitAllowingStateLoss();
        this.f = null;
        cx.d dVar = cx.d.NFC;
        this.aK = dVar;
        this.f = cx.b(true, dVar);
        getFragmentManager().beginTransaction().add(this.an, this.f, "Results").commitAllowingStateLoss();
        b(new b() { // from class: com.facetec.sdk.乐水
            @Override // com.facetec.sdk.bi.b
            public final byte[] getIdScanBytes(String str) {
                return this.f6843.d(z, str);
            }
        });
        aQ = (aN + 49) % 128;
    }

    public final void a(FaceTecSessionStatus faceTecSessionStatus) {
        int i = aQ + 15;
        aN = i % 128;
        if (i % 2 != 0) {
            a(faceTecSessionStatus, (FaceTecIDScanStatus) null);
            int i2 = aN + 67;
            aQ = i2 % 128;
            if (i2 % 2 != 0) {
                throw null;
            }
            return;
        }
        a(faceTecSessionStatus, (FaceTecIDScanStatus) null);
        throw null;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void h(String str) {
        if (this.f != null) {
            aN = (aQ + 59) % 128;
            this.f.b(str);
        }
        aN = (aQ + 15) % 128;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void g(boolean z) {
        e(FaceTecOCRConfirmationCustomization.d(), -1385387225, 1385387238, FaceTecOCRConfirmationCustomization.d(), new Object[]{this, Boolean.valueOf(z)}, FaceTecOCRConfirmationCustomization.d(), FaceTecOCRConfirmationCustomization.d());
    }

    /* JADX WARN: Removed duplicated region for block: B:31:0x0054 A[Catch: all -> 0x004c, TryCatch #3 {all -> 0x004c, blocks: (B:3:0x0001, B:5:0x0006, B:7:0x0013, B:10:0x0019, B:12:0x002b, B:14:0x002f, B:17:0x0035, B:19:0x0041, B:31:0x0054, B:33:0x0069, B:34:0x0078, B:51:0x00fe, B:60:0x015b, B:64:0x0169, B:65:0x0177, B:67:0x017b, B:82:0x019a, B:84:0x019e, B:87:0x01a6, B:89:0x01b2, B:92:0x01b7, B:94:0x01bb, B:96:0x01c1, B:98:0x01cb, B:100:0x01d5, B:103:0x01da, B:75:0x018f, B:80:0x0196, B:63:0x0166, B:26:0x004b, B:29:0x0050, B:35:0x0086, B:37:0x008a, B:39:0x0096, B:41:0x009a, B:43:0x00ad, B:47:0x00bc, B:49:0x00e3, B:50:0x00f2, B:44:0x00b0, B:46:0x00ba, B:70:0x0189, B:52:0x0105, B:54:0x012a, B:57:0x0135, B:59:0x0151, B:61:0x0163, B:21:0x0045, B:106:0x01df), top: B:117:0x0001, inners: #0, #1, #2, #4 }] */
    /* JADX WARN: Removed duplicated region for block: B:35:0x0086 A[Catch: all -> 0x004c, TryCatch #3 {all -> 0x004c, blocks: (B:3:0x0001, B:5:0x0006, B:7:0x0013, B:10:0x0019, B:12:0x002b, B:14:0x002f, B:17:0x0035, B:19:0x0041, B:31:0x0054, B:33:0x0069, B:34:0x0078, B:51:0x00fe, B:60:0x015b, B:64:0x0169, B:65:0x0177, B:67:0x017b, B:82:0x019a, B:84:0x019e, B:87:0x01a6, B:89:0x01b2, B:92:0x01b7, B:94:0x01bb, B:96:0x01c1, B:98:0x01cb, B:100:0x01d5, B:103:0x01da, B:75:0x018f, B:80:0x0196, B:63:0x0166, B:26:0x004b, B:29:0x0050, B:35:0x0086, B:37:0x008a, B:39:0x0096, B:41:0x009a, B:43:0x00ad, B:47:0x00bc, B:49:0x00e3, B:50:0x00f2, B:44:0x00b0, B:46:0x00ba, B:70:0x0189, B:52:0x0105, B:54:0x012a, B:57:0x0135, B:59:0x0151, B:61:0x0163, B:21:0x0045, B:106:0x01df), top: B:117:0x0001, inners: #0, #1, #2, #4 }] */
    /* JADX WARN: Removed duplicated region for block: B:81:0x0199  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    private synchronized void a(com.facetec.sdk.FaceTecSessionStatus r13, com.facetec.sdk.FaceTecIDScanStatus r14) {
        /*
            Method dump skipped, instruction units count: 484
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: com.facetec.sdk.bi.a(com.facetec.sdk.FaceTecSessionStatus, com.facetec.sdk.FaceTecIDScanStatus):void");
    }

    private synchronized void c(FaceTecSessionStatus faceTecSessionStatus) {
        try {
            int i = aN + 49;
            aQ = i % 128;
            if (i % 2 != 0) {
                e(faceTecSessionStatus, (FaceTecIDScanStatus) null);
                int i2 = 24 / 0;
            } else {
                e(faceTecSessionStatus, (FaceTecIDScanStatus) null);
            }
            int i3 = aQ + 1;
            aN = i3 % 128;
            if (i3 % 2 == 0) {
                int i4 = 28 / 0;
            }
        } catch (Throwable th) {
            throw th;
        }
    }

    /* JADX WARN: Code restructure failed: missing block: B:10:0x0025, code lost:
    
        if (com.facetec.sdk.bj.d == false) goto L11;
     */
    /* JADX WARN: Code restructure failed: missing block: B:11:0x0027, code lost:
    
        r1.f.a(true, com.facetec.sdk.FaceTecCustomization.overrideResultScreenSuccessMessage, new com.facetec.sdk.RunnableC2405(r1, r12));
     */
    /* JADX WARN: Code restructure failed: missing block: B:12:0x0033, code lost:
    
        return null;
     */
    /* JADX WARN: Code restructure failed: missing block: B:13:0x0034, code lost:
    
        e(com.facetec.sdk.FaceTecOCRConfirmationCustomization.d(), -1344204838, 1344204855, com.facetec.sdk.FaceTecOCRConfirmationCustomization.d(), new java.lang.Object[]{r1, r12, java.lang.Boolean.TRUE, java.lang.Boolean.FALSE}, com.facetec.sdk.FaceTecOCRConfirmationCustomization.d(), com.facetec.sdk.FaceTecOCRConfirmationCustomization.d());
        com.facetec.sdk.bi.aQ = (com.facetec.sdk.bi.aN + 45) % 128;
     */
    /* JADX WARN: Code restructure failed: missing block: B:7:0x0020, code lost:
    
        if (com.facetec.sdk.bj.d == false) goto L11;
     */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    private static /* synthetic */ java.lang.Object h(java.lang.Object[] r12) {
        /*
            r0 = 0
            r1 = r12[r0]
            com.facetec.sdk.bi r1 = (com.facetec.sdk.bi) r1
            r2 = 1
            r12 = r12[r2]
            com.facetec.sdk.FaceTecIDScanNextStep r12 = (com.facetec.sdk.FaceTecIDScanNextStep) r12
            com.facetec.sdk.cx r3 = r1.f
            r4 = 0
            if (r3 == 0) goto L5d
            int r3 = com.facetec.sdk.bi.aN
            int r3 = r3 + 99
            int r5 = r3 % 128
            com.facetec.sdk.bi.aQ = r5
            int r3 = r3 % 2
            if (r3 == 0) goto L23
            boolean r3 = com.facetec.sdk.bj.d
            r5 = 51
            int r5 = r5 / r0
            if (r3 != 0) goto L34
            goto L27
        L23:
            boolean r0 = com.facetec.sdk.bj.d
            if (r0 != 0) goto L34
        L27:
            com.facetec.sdk.cx r0 = r1.f
            java.lang.String r3 = com.facetec.sdk.FaceTecCustomization.overrideResultScreenSuccessMessage
            com.facetec.sdk.丹龙 r5 = new com.facetec.sdk.丹龙
            r5.<init>()
            r0.a(r2, r3, r5)
            return r4
        L34:
            java.lang.Boolean r0 = java.lang.Boolean.TRUE
            java.lang.Boolean r2 = java.lang.Boolean.FALSE
            java.lang.Object[] r9 = new java.lang.Object[]{r1, r12, r0, r2}
            int r5 = com.facetec.sdk.FaceTecOCRConfirmationCustomization.d()
            int r8 = com.facetec.sdk.FaceTecOCRConfirmationCustomization.d()
            int r10 = com.facetec.sdk.FaceTecOCRConfirmationCustomization.d()
            int r11 = com.facetec.sdk.FaceTecOCRConfirmationCustomization.d()
            r6 = -1344204838(0xffffffffafe10fda, float:-4.0938525E-10)
            r7 = 1344204855(0x501ef037, float:1.0666171E10)
            e(r5, r6, r7, r8, r9, r10, r11)
            int r12 = com.facetec.sdk.bi.aN
            int r12 = r12 + 45
            int r12 = r12 % 128
            com.facetec.sdk.bi.aQ = r12
        L5d:
            return r4
        */
        throw new UnsupportedOperationException("Method not decompiled: com.facetec.sdk.bi.h(java.lang.Object[]):java.lang.Object");
    }

    /* JADX WARN: Code restructure failed: missing block: B:85:0x0159, code lost:
    
        if (com.facetec.sdk.FaceTecSDK.d.f.disableIDFeedbackScreen == false) goto L89;
     */
    /* JADX WARN: Code restructure failed: missing block: B:88:0x016c, code lost:
    
        if (com.facetec.sdk.FaceTecSDK.d.f.disableIDFeedbackScreen == false) goto L89;
     */
    /* JADX WARN: Code restructure failed: missing block: B:89:0x016e, code lost:
    
        r11 = com.facetec.sdk.bi.aN + 117;
        com.facetec.sdk.bi.aQ = r11 % 128;
     */
    /* JADX WARN: Code restructure failed: missing block: B:90:0x0177, code lost:
    
        if ((r11 % 2) == 0) goto L93;
     */
    /* JADX WARN: Code restructure failed: missing block: B:91:0x0179, code lost:
    
        X();
     */
    /* JADX WARN: Code restructure failed: missing block: B:92:0x017c, code lost:
    
        return false;
     */
    /* JADX WARN: Code restructure failed: missing block: B:93:0x017d, code lost:
    
        X();
     */
    /* JADX WARN: Code restructure failed: missing block: B:94:0x0180, code lost:
    
        return false;
     */
    /* JADX WARN: Code restructure failed: missing block: B:95:0x0181, code lost:
    
        U();
     */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public final boolean b(java.lang.String r11) throws java.lang.Throwable {
        /*
            Method dump skipped, instruction units count: 592
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: com.facetec.sdk.bi.b(java.lang.String):boolean");
    }

    private static /* synthetic */ Object f(Object[] objArr) {
        final bi biVar = (bi) objArr[0];
        final boolean zBooleanValue = ((Boolean) objArr[1]).booleanValue();
        int i = aN + 41;
        aQ = i % 128;
        if (i % 2 != 0) {
            biVar.f.e(new Runnable() { // from class: com.facetec.sdk.乐梦
                @Override // java.lang.Runnable
                public final void run() {
                    this.f6837.f(zBooleanValue);
                }
            });
            int i2 = 12 / 0;
            return null;
        }
        biVar.f.e(new Runnable() { // from class: com.facetec.sdk.乐梦
            @Override // java.lang.Runnable
            public final void run() {
                this.f6837.f(zBooleanValue);
            }
        });
        return null;
    }

    public final void c(FaceTecIDScanStatus faceTecIDScanStatus) {
        int i = aQ + 19;
        aN = i % 128;
        if (i % 2 == 0) {
            a(FaceTecSessionStatus.SESSION_COMPLETED_SUCCESSFULLY, faceTecIDScanStatus);
            int i2 = 5 / 0;
        } else {
            a(FaceTecSessionStatus.SESSION_COMPLETED_SUCCESSFULLY, faceTecIDScanStatus);
        }
    }

    private void h(boolean z) {
        e(FaceTecOCRConfirmationCustomization.d(), -1776803023, 1776803023, FaceTecOCRConfirmationCustomization.d(), new Object[]{this, Boolean.valueOf(z)}, FaceTecOCRConfirmationCustomization.d(), FaceTecOCRConfirmationCustomization.d());
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void d(dd ddVar) {
        aN = (aQ + 75) % 128;
        if (isFinishing()) {
            aQ = (aN + 15) % 128;
        } else {
            getFragmentManager().beginTransaction().replace(this.an, ddVar, "RetryFaceScan").commitAllowingStateLoss();
            this.i = ddVar;
        }
    }

    /* JADX WARN: Code restructure failed: missing block: B:16:0x001e, code lost:
    
        if (com.facetec.sdk.FaceTecSessionActivity.f == null) goto L17;
     */
    /* JADX WARN: Code restructure failed: missing block: B:17:0x0020, code lost:
    
        a(r8.z.getStatus());
     */
    /* JADX WARN: Code restructure failed: missing block: B:19:0x002a, code lost:
    
        return;
     */
    /* JADX WARN: Code restructure failed: missing block: B:21:0x002d, code lost:
    
        if (r9 != com.facetec.sdk.FaceTecIDScanNextStep.SKIP) goto L34;
     */
    /* JADX WARN: Code restructure failed: missing block: B:22:0x002f, code lost:
    
        r9 = com.facetec.sdk.bi.aQ + com.plaid.internal.EnumC41897g.SDK_ASSET_ILLUSTRATION_DEPOSIT_SWITCH_VALUE;
        com.facetec.sdk.bi.aN = r9 % 128;
     */
    /* JADX WARN: Code restructure failed: missing block: B:23:0x0039, code lost:
    
        if ((r9 % 2) != 0) goto L31;
     */
    /* JADX WARN: Code restructure failed: missing block: B:24:0x003b, code lost:
    
        e(r8.z.getStatus(), com.facetec.sdk.FaceTecIDScanStatus.SKIPPED);
     */
    /* JADX WARN: Code restructure failed: missing block: B:26:0x0048, code lost:
    
        r9 = 11 / 0;
     */
    /* JADX WARN: Code restructure failed: missing block: B:31:0x004d, code lost:
    
        e(r8.z.getStatus(), com.facetec.sdk.FaceTecIDScanStatus.SKIPPED);
     */
    /* JADX WARN: Code restructure failed: missing block: B:33:0x0059, code lost:
    
        return;
     */
    /* JADX WARN: Code restructure failed: missing block: B:34:0x005a, code lost:
    
        r8.W = false;
     */
    /* JADX WARN: Code restructure failed: missing block: B:35:0x005e, code lost:
    
        if (r8.e == null) goto L42;
     */
    /* JADX WARN: Code restructure failed: missing block: B:37:0x0064, code lost:
    
        if (hasWindowFocus() != false) goto L39;
     */
    /* JADX WARN: Code restructure failed: missing block: B:39:0x0067, code lost:
    
        e(com.facetec.sdk.FaceTecOCRConfirmationCustomization.d(), 515625104, -515625082, com.facetec.sdk.FaceTecOCRConfirmationCustomization.d(), new java.lang.Object[]{r8, r9}, com.facetec.sdk.FaceTecOCRConfirmationCustomization.d(), com.facetec.sdk.FaceTecOCRConfirmationCustomization.d());
     */
    /* JADX WARN: Code restructure failed: missing block: B:41:0x0085, code lost:
    
        return;
     */
    /* JADX WARN: Code restructure failed: missing block: B:43:0x0087, code lost:
    
        return;
     */
    /* JADX WARN: Code restructure failed: missing block: B:8:0x0013, code lost:
    
        if (com.facetec.sdk.FaceTecSessionActivity.f == null) goto L17;
     */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    private synchronized void c(com.facetec.sdk.FaceTecIDScanNextStep r9) {
        /*
            r8 = this;
            monitor-enter(r8)
            int r0 = com.facetec.sdk.bi.aQ     // Catch: java.lang.Throwable -> L19
            int r0 = r0 + 115
            int r1 = r0 % 128
            com.facetec.sdk.bi.aN = r1     // Catch: java.lang.Throwable -> L19
            int r0 = r0 % 2
            r1 = 0
            if (r0 != 0) goto L1c
            com.facetec.sdk.FaceTecIDScanProcessor r0 = com.facetec.sdk.FaceTecSessionActivity.f     // Catch: java.lang.Throwable -> L19
            r2 = 70
            int r2 = r2 / r1
            if (r0 != 0) goto L2b
            goto L20
        L16:
            r0 = move-exception
            r9 = r0
            throw r9     // Catch: java.lang.Throwable -> L19
        L19:
            r0 = move-exception
            r9 = r0
            goto L88
        L1c:
            com.facetec.sdk.FaceTecIDScanProcessor r0 = com.facetec.sdk.FaceTecSessionActivity.f     // Catch: java.lang.Throwable -> L19
            if (r0 != 0) goto L2b
        L20:
            com.facetec.sdk.FaceTecSessionResult r9 = r8.z     // Catch: java.lang.Throwable -> L19
            com.facetec.sdk.FaceTecSessionStatus r9 = r9.getStatus()     // Catch: java.lang.Throwable -> L19
            r8.a(r9)     // Catch: java.lang.Throwable -> L19
            monitor-exit(r8)
            return
        L2b:
            com.facetec.sdk.FaceTecIDScanNextStep r0 = com.facetec.sdk.FaceTecIDScanNextStep.SKIP     // Catch: java.lang.Throwable -> L19
            if (r9 != r0) goto L5a
            int r9 = com.facetec.sdk.bi.aQ     // Catch: java.lang.Throwable -> L19
            int r9 = r9 + 121
            int r0 = r9 % 128
            com.facetec.sdk.bi.aN = r0     // Catch: java.lang.Throwable -> L19
            int r9 = r9 % 2
            if (r9 != 0) goto L4d
            com.facetec.sdk.FaceTecSessionResult r9 = r8.z     // Catch: java.lang.Throwable -> L19
            com.facetec.sdk.FaceTecSessionStatus r9 = r9.getStatus()     // Catch: java.lang.Throwable -> L19
            com.facetec.sdk.FaceTecIDScanStatus r0 = com.facetec.sdk.FaceTecIDScanStatus.SKIPPED     // Catch: java.lang.Throwable -> L19
            r8.e(r9, r0)     // Catch: java.lang.Throwable -> L19
            r9 = 11
            int r9 = r9 / r1
            goto L58
        L4a:
            r0 = move-exception
            r9 = r0
            throw r9     // Catch: java.lang.Throwable -> L19
        L4d:
            com.facetec.sdk.FaceTecSessionResult r9 = r8.z     // Catch: java.lang.Throwable -> L19
            com.facetec.sdk.FaceTecSessionStatus r9 = r9.getStatus()     // Catch: java.lang.Throwable -> L19
            com.facetec.sdk.FaceTecIDScanStatus r0 = com.facetec.sdk.FaceTecIDScanStatus.SKIPPED     // Catch: java.lang.Throwable -> L19
            r8.e(r9, r0)     // Catch: java.lang.Throwable -> L19
        L58:
            monitor-exit(r8)
            return
        L5a:
            r8.W = r1     // Catch: java.lang.Throwable -> L19
            com.facetec.sdk.cp r0 = r8.e     // Catch: java.lang.Throwable -> L19
            if (r0 == 0) goto L86
            boolean r0 = r8.hasWindowFocus()     // Catch: java.lang.Throwable -> L19
            if (r0 != 0) goto L67
            goto L86
        L67:
            java.lang.Object[] r5 = new java.lang.Object[]{r8, r9}     // Catch: java.lang.Throwable -> L19
            int r1 = com.facetec.sdk.FaceTecOCRConfirmationCustomization.d()     // Catch: java.lang.Throwable -> L19
            int r4 = com.facetec.sdk.FaceTecOCRConfirmationCustomization.d()     // Catch: java.lang.Throwable -> L19
            int r6 = com.facetec.sdk.FaceTecOCRConfirmationCustomization.d()     // Catch: java.lang.Throwable -> L19
            int r7 = com.facetec.sdk.FaceTecOCRConfirmationCustomization.d()     // Catch: java.lang.Throwable -> L19
            r2 = 515625104(0x1ebbd090, float:1.9885655E-20)
            r3 = -515625082(0xffffffffe1442f86, float:-2.2618664E20)
            e(r1, r2, r3, r4, r5, r6, r7)     // Catch: java.lang.Throwable -> L19
            monitor-exit(r8)
            return
        L86:
            monitor-exit(r8)
            return
        L88:
            monitor-exit(r8)     // Catch: java.lang.Throwable -> L19
            throw r9
        */
        throw new UnsupportedOperationException("Method not decompiled: com.facetec.sdk.bi.c(com.facetec.sdk.FaceTecIDScanNextStep):void");
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void m(boolean z) {
        e(FaceTecOCRConfirmationCustomization.d(), -1063358904, 1063358927, FaceTecOCRConfirmationCustomization.d(), new Object[]{this, Boolean.valueOf(z)}, FaceTecOCRConfirmationCustomization.d(), FaceTecOCRConfirmationCustomization.d());
    }

    private static /* synthetic */ Object i(Object[] objArr) {
        bi biVar = (bi) objArr[0];
        Timer timer = biVar.aF;
        if (timer != null) {
            aN = (aQ + 89) % 128;
            timer.cancel();
            biVar.aF = null;
        }
        TimerTask timerTask = biVar.aE;
        if (timerTask != null) {
            aN = (aQ + 19) % 128;
            timerTask.cancel();
            biVar.aE = null;
        }
        int i = aN + 115;
        aQ = i % 128;
        if (i % 2 != 0) {
            int i2 = 96 / 0;
        }
        return null;
    }

    /* JADX WARN: Code restructure failed: missing block: B:10:0x0025, code lost:
    
        return;
     */
    /* JADX WARN: Code restructure failed: missing block: B:11:0x0026, code lost:
    
        r0 = com.facetec.sdk.dd.r();
        r5.a.postDelayed(new com.facetec.sdk.RunnableC2398(r5, r0), r6);
     */
    /* JADX WARN: Code restructure failed: missing block: B:12:0x0035, code lost:
    
        return;
     */
    /* JADX WARN: Code restructure failed: missing block: B:5:0x0014, code lost:
    
        if (isFinishing() != false) goto L9;
     */
    /* JADX WARN: Code restructure failed: missing block: B:8:0x001b, code lost:
    
        if (isFinishing() != false) goto L9;
     */
    /* JADX WARN: Code restructure failed: missing block: B:9:0x001d, code lost:
    
        com.facetec.sdk.bi.aN = (com.facetec.sdk.bi.aQ + 3) % 128;
     */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    private void d(int r6) {
        /*
            r5 = this;
            int r0 = com.facetec.sdk.bi.aQ
            int r0 = r0 + 101
            int r1 = r0 % 128
            com.facetec.sdk.bi.aN = r1
            int r0 = r0 % 2
            if (r0 != 0) goto L17
            boolean r0 = r5.isFinishing()
            r1 = 66
            int r1 = r1 / 0
            if (r0 == 0) goto L26
            goto L1d
        L17:
            boolean r0 = r5.isFinishing()
            if (r0 == 0) goto L26
        L1d:
            int r6 = com.facetec.sdk.bi.aQ
            int r6 = r6 + 3
            int r6 = r6 % 128
            com.facetec.sdk.bi.aN = r6
            return
        L26:
            com.facetec.sdk.dd r0 = com.facetec.sdk.dd.r()
            android.os.Handler r1 = r5.a
            com.facetec.sdk.丹药 r2 = new com.facetec.sdk.丹药
            r2.<init>()
            long r3 = (long) r6
            r1.postDelayed(r2, r3)
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: com.facetec.sdk.bi.d(int):void");
    }

    @Override // com.facetec.sdk.bm
    public final void d(String str) throws Throwable {
        boolean z;
        c cVar = c.SEVERE_ERROR;
        StringBuilder sb = new StringBuilder();
        FaceTecSessionStatus faceTecSessionStatus = FaceTecSessionStatus.UNKNOWN_INTERNAL_ERROR;
        sb.append(faceTecSessionStatus);
        sb.append(": ");
        sb.append(str);
        String string = sb.toString();
        if (ah.c) {
            z = false;
        } else {
            aN = (aQ + 99) % 128;
            z = true;
        }
        t.d(this, null, cVar, string, z, faceTecSessionStatus.ordinal());
        e(faceTecSessionStatus, (FaceTecIDScanStatus) null);
        aN = (aQ + 125) % 128;
    }

    private void i(boolean z) {
        e(FaceTecOCRConfirmationCustomization.d(), -1339677298, 1339677303, FaceTecOCRConfirmationCustomization.d(), new Object[]{this, Boolean.valueOf(z)}, FaceTecOCRConfirmationCustomization.d(), FaceTecOCRConfirmationCustomization.d());
    }

    private void d(final Runnable runnable) {
        Runnable runnable2;
        int i = aN + 69;
        aQ = i % 128;
        final boolean z = true;
        if (i % 2 != 0) {
            t.d(this, c.DEVELOPER_USED_ID_SCAN_CALLBACK, "succeed", null);
            runnable2 = new Runnable() { // from class: com.facetec.sdk.丹玉
                @Override // java.lang.Runnable
                public final void run() {
                    this.f6773.c(z, runnable);
                }
            };
        } else {
            t.d(this, c.DEVELOPER_USED_ID_SCAN_CALLBACK, "succeed", null);
            runnable2 = new Runnable() { // from class: com.facetec.sdk.丹玉
                @Override // java.lang.Runnable
                public final void run() {
                    this.f6773.c(z, runnable);
                }
            };
        }
        runOnUiThread(runnable2);
    }

    private static /* synthetic */ Object d(Object[] objArr) {
        final bi biVar = (bi) objArr[0];
        final boolean zBooleanValue = ((Boolean) objArr[1]).booleanValue();
        int i = aN;
        int i2 = (i ^ 45) + ((i & 45) << 1);
        aQ = i2 % 128;
        if (i2 % 2 == 0) {
            if (biVar.ac) {
                aQ = (i + 91) % 128;
                return null;
            }
            biVar.ac = true;
            ed.j();
            dj.a(new Runnable() { // from class: com.facetec.sdk.乐古
                @Override // java.lang.Runnable
                public final void run() {
                    this.f6810.m(zBooleanValue);
                }
            }).c(new Runnable() { // from class: com.facetec.sdk.乐史
                @Override // java.lang.Runnable
                public final void run() {
                    this.f6812.at();
                }
            });
            int i3 = aN + 7;
            aQ = i3 % 128;
            if (i3 % 2 != 0) {
                int i4 = 58 / 0;
            }
            return null;
        }
        boolean z = biVar.ac;
        throw null;
    }

    public final void c(final float f) {
        aQ = (aN + 119) % 128;
        runOnUiThread(new Runnable() { // from class: com.facetec.sdk.丹符
            @Override // java.lang.Runnable
            public final void run() {
                this.f6781.b(f);
            }
        });
        int i = aN + 115;
        aQ = i % 128;
        if (i % 2 != 0) {
            throw null;
        }
    }

    private static /* synthetic */ Object c(Object[] objArr) {
        final bi biVar = (bi) objArr[0];
        boolean zBooleanValue = ((Boolean) objArr[1]).booleanValue();
        final Runnable runnable = (Runnable) objArr[2];
        aN = (aQ + 73) % 128;
        if (biVar.f != null) {
            int i = aN + 3;
            aQ = i % 128;
            if (i % 2 == 0) {
                biVar.f.a(zBooleanValue, biVar.ax, new Runnable() { // from class: com.facetec.sdk.乐土
                    @Override // java.lang.Runnable
                    public final void run() {
                        this.f6817.c(runnable);
                    }
                });
                aN = (aQ + 1) % 128;
            } else {
                biVar.f.a(zBooleanValue, biVar.ax, new Runnable() { // from class: com.facetec.sdk.乐土
                    @Override // java.lang.Runnable
                    public final void run() {
                        this.f6817.c(runnable);
                    }
                });
                throw null;
            }
        }
        return null;
    }

    /* JADX INFO: Access modifiers changed from: private */
    /* JADX WARN: Removed duplicated region for block: B:16:0x0033  */
    /* JADX WARN: Removed duplicated region for block: B:17:0x0035  */
    /* JADX WARN: Removed duplicated region for block: B:59:0x00fb  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public /* synthetic */ void d(boolean r12, boolean r13, final com.facetec.sdk.FaceTecIDScanNextStep r14) throws java.lang.Throwable {
        /*
            Method dump skipped, instruction units count: 295
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: com.facetec.sdk.bi.d(boolean, boolean, com.facetec.sdk.FaceTecIDScanNextStep):void");
    }

    public final void c(int i) {
        int i2 = aQ + 73;
        aN = i2 % 128;
        if (i2 % 2 != 0) {
            ImageView imageView = this.w;
            if (imageView == null || FaceTecSDK.d.m.b != FaceTecCancelButtonCustomization.ButtonLocation.CUSTOM) {
                return;
            }
            aQ = (aN + 19) % 128;
            imageView.animate().alpha(1.0f).setDuration(500L).setStartDelay(i).setListener(null).withEndAction(new Runnable() { // from class: com.facetec.sdk.乐妖
                @Override // java.lang.Runnable
                public final void run() {
                    this.f6823.ao();
                }
            }).start();
            return;
        }
        throw null;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void c(String str, b bVar) {
        this.aA.b = str;
        byte[][] bArrU = cv.u();
        byte[][] bArrX = cv.x();
        FaceTecIDScanResult faceTecIDScanResult = this.aA;
        if (bArrU != null) {
            int i = 0;
            while (i < bArrU.length) {
                int i2 = aQ + 65;
                aN = i2 % 128;
                if (i2 % 2 == 0) {
                    faceTecIDScanResult.a.add(Base64.encodeToString(bArrU[i], 4));
                    i += 37;
                } else {
                    faceTecIDScanResult.a.add(Base64.encodeToString(bArrU[i], 2));
                    i++;
                }
            }
        }
        FaceTecIDScanResult faceTecIDScanResult2 = this.aA;
        if (bArrX != null) {
            int i3 = (aN + 21) % 128;
            aQ = i3;
            aN = (i3 + 45) % 128;
            for (byte[] bArr : bArrX) {
                aQ = (aN + 63) % 128;
                faceTecIDScanResult2.e.add(Base64.encodeToString(bArr, 2));
            }
        }
        this.aA.d = bVar.getIdScanBytes(str);
    }

    /* JADX INFO: Access modifiers changed from: private */
    /* JADX WARN: Removed duplicated region for block: B:12:0x002e  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public /* synthetic */ void c(java.lang.String r4, com.facetec.sdk.t.b r5) {
        /*
            r3 = this;
            int r0 = com.facetec.sdk.bi.aN
            int r1 = r0 + 51
            int r1 = r1 % 128
            com.facetec.sdk.bi.aQ = r1
            com.facetec.sdk.cp r1 = r3.e
            if (r1 == 0) goto L31
            int r0 = r0 + 7
            int r2 = r0 % 128
            com.facetec.sdk.bi.aQ = r2
            int r0 = r0 % 2
            if (r0 == 0) goto L25
            com.facetec.sdk.ac r0 = r1.b
            boolean r0 = r0.c()
            r2 = 32
            int r2 = r2 / 0
            r2 = 1
            r0 = r0 ^ r2
            if (r0 == r2) goto L31
            goto L2e
        L25:
            com.facetec.sdk.ac r0 = r1.b
            boolean r0 = r0.c()
            if (r0 != 0) goto L2e
            goto L31
        L2e:
            r1.h()
        L31:
            com.facetec.sdk.m r0 = r3.k
            if (r0 == 0) goto L40
            r0.e(r4, r5)
            int r4 = com.facetec.sdk.bi.aN
            int r4 = r4 + 35
            int r4 = r4 % 128
            com.facetec.sdk.bi.aQ = r4
        L40:
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: com.facetec.sdk.bi.c(java.lang.String, com.facetec.sdk.t$b):void");
    }

    private void c(FaceTecIDScanNextStep faceTecIDScanNextStep, boolean z, boolean z2) {
        e(FaceTecOCRConfirmationCustomization.d(), -1344204838, 1344204855, FaceTecOCRConfirmationCustomization.d(), new Object[]{this, faceTecIDScanNextStep, Boolean.valueOf(z), Boolean.valueOf(z2)}, FaceTecOCRConfirmationCustomization.d(), FaceTecOCRConfirmationCustomization.d());
    }

    private void c(t.b bVar, boolean z) {
        e(FaceTecOCRConfirmationCustomization.d(), 1365199073, -1365199063, FaceTecOCRConfirmationCustomization.d(), new Object[]{this, bVar, Boolean.valueOf(z)}, FaceTecOCRConfirmationCustomization.d(), FaceTecOCRConfirmationCustomization.d());
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void c(boolean z, Runnable runnable) {
        e(FaceTecOCRConfirmationCustomization.d(), -804478094, 804478106, FaceTecOCRConfirmationCustomization.d(), new Object[]{this, Boolean.valueOf(z), runnable}, FaceTecOCRConfirmationCustomization.d(), FaceTecOCRConfirmationCustomization.d());
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ byte[] d(boolean z, String str) {
        SharedPreferences sharedPreferencesJ;
        String str2;
        boolean z2;
        int i = aN + 125;
        aQ = i % 128;
        if (i % 2 != 0) {
            sharedPreferencesJ = bk.j(this);
            str2 = ao.ab;
            z2 = true;
        } else {
            sharedPreferencesJ = bk.j(this);
            str2 = ao.ab;
            z2 = false;
        }
        byte[] bArrQ = cv.q(str, this.D, z, z2, sharedPreferencesJ.getBoolean(str2, z2));
        int i2 = aQ + 5;
        aN = i2 % 128;
        if (i2 % 2 != 0) {
            return bArrQ;
        }
        throw null;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void c(Runnable runnable) {
        e(FaceTecOCRConfirmationCustomization.d(), -1571926964, 1571926975, FaceTecOCRConfirmationCustomization.d(), new Object[]{this, runnable}, FaceTecOCRConfirmationCustomization.d(), FaceTecOCRConfirmationCustomization.d());
    }

    public final void a(final String str) {
        aN = (aQ + 77) % 128;
        runOnUiThread(new Runnable() { // from class: com.facetec.sdk.书书
            @Override // java.lang.Runnable
            public final void run() {
                this.f6874.h(str);
            }
        });
        int i = aQ + 33;
        aN = i % 128;
        if (i % 2 == 0) {
            throw null;
        }
    }

    /* JADX WARN: Removed duplicated region for block: B:23:0x0082 A[Catch: JSONException -> 0x00a2, TryCatch #0 {JSONException -> 0x00a2, blocks: (B:6:0x0033, B:8:0x0042, B:11:0x0050, B:14:0x0060, B:16:0x0068, B:20:0x0078, B:21:0x007a, B:24:0x0084, B:22:0x007f, B:23:0x0082), top: B:28:0x0033 }] */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public final boolean a(java.lang.String r20, com.facetec.sdk.FaceTecIDScanNextStep r21) {
        /*
            r19 = this;
            r0 = r19
            r1 = 0
            r2 = r20
            java.lang.String r2 = com.facetec.sdk.cv.U(r2, r1)
            boolean r3 = r2.isEmpty()
            if (r3 == 0) goto L33
            com.facetec.sdk.c r2 = com.facetec.sdk.c.SCAN_RESULT_BLOB_DECODE_ERROR
            r3 = 0
            com.facetec.sdk.t.d(r0, r2, r3, r3)
            java.lang.Object[] r8 = new java.lang.Object[]{r0}
            int r4 = com.facetec.sdk.FaceTecOCRConfirmationCustomization.d()
            int r7 = com.facetec.sdk.FaceTecOCRConfirmationCustomization.d()
            int r9 = com.facetec.sdk.FaceTecOCRConfirmationCustomization.d()
            int r10 = com.facetec.sdk.FaceTecOCRConfirmationCustomization.d()
            r5 = -302800720(0xffffffffedf3a0b0, float:-9.4248896E27)
            r6 = 302800746(0x120c5f6a, float:4.429382E-28)
            e(r4, r5, r6, r7, r8, r9, r10)
            return r1
        L33:
            org.json.JSONObject r3 = new org.json.JSONObject     // Catch: org.json.JSONException -> La2
            r3.<init>(r2)     // Catch: org.json.JSONException -> La2
            java.lang.String r2 = "success"
            boolean r2 = r3.optBoolean(r2, r1)     // Catch: org.json.JSONException -> La2
            r4 = 1
            r2 = r2 ^ r4
            if (r2 == r4) goto L50
            r2 = r21
            r0.b(r2)     // Catch: org.json.JSONException -> La2
            int r1 = com.facetec.sdk.bi.aQ
            int r1 = r1 + 89
            int r1 = r1 % 128
            com.facetec.sdk.bi.aN = r1
            return r4
        L50:
            java.lang.String r2 = com.facetec.sdk.db.b     // Catch: org.json.JSONException -> La2
            org.json.JSONObject r2 = r3.optJSONObject(r2)     // Catch: org.json.JSONException -> La2
            if (r2 == 0) goto L82
            int r3 = com.facetec.sdk.bi.aQ
            int r3 = r3 + 105
            int r3 = r3 % 128
            com.facetec.sdk.bi.aN = r3
            java.lang.String r3 = com.facetec.sdk.db.a     // Catch: org.json.JSONException -> La2
            int r2 = r2.optInt(r3)     // Catch: org.json.JSONException -> La2
            if (r2 != r4) goto L82
            boolean r2 = r0.aJ     // Catch: org.json.JSONException -> La2
            if (r2 != 0) goto L82
            int r2 = com.facetec.sdk.bi.aQ
            int r2 = r2 + 119
            int r3 = r2 % 128
            com.facetec.sdk.bi.aN = r3
            int r2 = r2 % 2
            if (r2 != 0) goto L7f
            com.facetec.sdk.df r2 = com.facetec.sdk.df.BLURRY_ONLY     // Catch: org.json.JSONException -> La2
        L7a:
            r0.L = r2     // Catch: org.json.JSONException -> La2
            r0.aJ = r4     // Catch: org.json.JSONException -> La2
            goto L84
        L7f:
            com.facetec.sdk.df r2 = com.facetec.sdk.df.BLURRY_ONLY     // Catch: org.json.JSONException -> La2
            goto L7a
        L82:
            r0.aJ = r1     // Catch: org.json.JSONException -> La2
        L84:
            java.lang.Object[] r9 = new java.lang.Object[]{r0}     // Catch: org.json.JSONException -> La2
            int r5 = com.facetec.sdk.FaceTecOCRConfirmationCustomization.d()     // Catch: org.json.JSONException -> La2
            int r8 = com.facetec.sdk.FaceTecOCRConfirmationCustomization.d()     // Catch: org.json.JSONException -> La2
            int r10 = com.facetec.sdk.FaceTecOCRConfirmationCustomization.d()     // Catch: org.json.JSONException -> La2
            int r11 = com.facetec.sdk.FaceTecOCRConfirmationCustomization.d()     // Catch: org.json.JSONException -> La2
            r6 = -302800720(0xffffffffedf3a0b0, float:-9.4248896E27)
            r7 = 302800746(0x120c5f6a, float:4.429382E-28)
            e(r5, r6, r7, r8, r9, r10, r11)     // Catch: org.json.JSONException -> La2
            return r1
        La2:
            java.lang.Object[] r16 = new java.lang.Object[]{r0}
            int r12 = com.facetec.sdk.FaceTecOCRConfirmationCustomization.d()
            int r15 = com.facetec.sdk.FaceTecOCRConfirmationCustomization.d()
            int r17 = com.facetec.sdk.FaceTecOCRConfirmationCustomization.d()
            int r18 = com.facetec.sdk.FaceTecOCRConfirmationCustomization.d()
            r13 = -302800720(0xffffffffedf3a0b0, float:-9.4248896E27)
            r14 = 302800746(0x120c5f6a, float:4.429382E-28)
            e(r12, r13, r14, r15, r16, r17, r18)
            return r1
        */
        throw new UnsupportedOperationException("Method not decompiled: com.facetec.sdk.bi.a(java.lang.String, com.facetec.sdk.FaceTecIDScanNextStep):boolean");
    }

    private void d(FaceTecIDScanNextStep faceTecIDScanNextStep, boolean z) {
        e(FaceTecOCRConfirmationCustomization.d(), 1078511809, -1078511801, FaceTecOCRConfirmationCustomization.d(), new Object[]{this, faceTecIDScanNextStep, Boolean.valueOf(z)}, FaceTecOCRConfirmationCustomization.d(), FaceTecOCRConfirmationCustomization.d());
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void d(FaceTecIDScanNextStep faceTecIDScanNextStep) {
        e(FaceTecOCRConfirmationCustomization.d(), -1600612289, 1600612305, FaceTecOCRConfirmationCustomization.d(), new Object[]{this, faceTecIDScanNextStep}, FaceTecOCRConfirmationCustomization.d(), FaceTecOCRConfirmationCustomization.d());
    }

    private void e(boolean z) {
        ah ahVar;
        synchronized (this.aH) {
            ahVar = this.aj;
            this.aj = null;
        }
        if (ahVar != null) {
            t.d(this, c.SESSION_CAMERA_CLEANUP_CALLED, null, null);
            ahVar.b(z);
        }
    }

    @Override // com.facetec.sdk.bm
    public final void e(String str) throws Throwable {
        int i = aQ + 31;
        aN = i % 128;
        if (i % 2 == 0) {
            throw null;
        }
        String str2 = str != null ? str : "";
        if (this.aw) {
            Throwable th = new Throwable(str2);
            c cVar = c.UNEXPECTED_EARLY_EXIT_IDSCAN;
            String strConcat = "IDScan Camera Error: ".concat(String.valueOf(str));
            FaceTecIDScanStatus faceTecIDScanStatus = FaceTecIDScanStatus.CAMERA_ERROR;
            t.d(this, th, cVar, strConcat, false, faceTecIDScanStatus.ordinal());
            c(faceTecIDScanStatus);
            return;
        }
        Throwable th2 = new Throwable(str2);
        c cVar2 = c.UNEXPECTED_EARLY_EXIT_FACESCAN;
        String strConcat2 = "FaceScan Camera Error: ".concat(String.valueOf(str));
        FaceTecSessionStatus faceTecSessionStatus = FaceTecSessionStatus.CAMERA_INITIALIZATION_ISSUE;
        t.d(this, th2, cVar2, strConcat2, true, faceTecSessionStatus.ordinal());
        e(faceTecSessionStatus, (FaceTecIDScanStatus) null);
        aQ = (aN + 77) % 128;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void a(bw bwVar) {
        final boolean z;
        aQ = (aN + 109) % 128;
        if (!F()) {
            int i = aQ + 101;
            aN = i % 128;
            if (i % 2 != 0) {
                if (this.f != null) {
                    if (bwVar.c) {
                        z = false;
                    } else {
                        aN = (aQ + 27) % 128;
                        z = true;
                    }
                    if (this.f != null) {
                        this.f.b(new Runnable() { // from class: com.facetec.sdk.乐天
                            @Override // java.lang.Runnable
                            public final void run() {
                                this.f6821.k(z);
                            }
                        });
                        return;
                    } else {
                        e(FaceTecOCRConfirmationCustomization.d(), 827085871, -827085847, FaceTecOCRConfirmationCustomization.d(), new Object[]{this, Boolean.valueOf(z)}, FaceTecOCRConfirmationCustomization.d(), FaceTecOCRConfirmationCustomization.d());
                        return;
                    }
                }
            } else {
                throw null;
            }
        }
        int i2 = aQ + 27;
        aN = i2 % 128;
        if (i2 % 2 == 0) {
            throw null;
        }
    }

    private static /* synthetic */ Object e(Object[] objArr) {
        bi biVar = (bi) objArr[0];
        int i = aN + 109;
        aQ = i % 128;
        if (i % 2 != 0) {
            biVar.as.setVisibility(1);
        } else {
            biVar.as.setVisibility(0);
        }
        biVar.as.setAlpha(1.0f);
        int i2 = aN + 71;
        aQ = i2 % 128;
        if (i2 % 2 == 0) {
            return null;
        }
        throw null;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void e(View view) {
        int i = aQ + 13;
        aN = i % 128;
        if (i % 2 != 0) {
            if (view != null) {
                view.setVisibility(4);
                aQ = (aN + 25) % 128;
            }
            this.av.setVisibility(4);
            return;
        }
        throw null;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void a(final bw bwVar, String str) {
        aN = (aQ + 115) % 128;
        if (ah()) {
            boolean z = !bwVar.c;
            if (F()) {
                return;
            }
            if (ah() && !this.Q.b) {
                this.Q.e(new Runnable() { // from class: com.facetec.sdk.乐人
                    @Override // java.lang.Runnable
                    public final void run() {
                        this.f6803.aO();
                    }
                });
                return;
            } else {
                e(FaceTecOCRConfirmationCustomization.d(), 827085871, -827085847, FaceTecOCRConfirmationCustomization.d(), new Object[]{this, Boolean.valueOf(z)}, FaceTecOCRConfirmationCustomization.d(), FaceTecOCRConfirmationCustomization.d());
                return;
            }
        }
        if (!ae()) {
            return;
        }
        int i = aN + 67;
        aQ = i % 128;
        if (i % 2 == 0) {
            this.f.a(bwVar.c, str, new Runnable() { // from class: com.facetec.sdk.乐仙
                @Override // java.lang.Runnable
                public final void run() {
                    this.f6804.a(bwVar);
                }
            });
        } else {
            this.f.a(bwVar.c, str, new Runnable() { // from class: com.facetec.sdk.乐仙
                @Override // java.lang.Runnable
                public final void run() {
                    this.f6804.a(bwVar);
                }
            });
            throw null;
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ byte[] b(JSONObject jSONObject, String str) {
        aN = (aQ + 95) % 128;
        boolean z = bk.j(this).getBoolean(ao.ab, false);
        byte[] bArrT = cv.t(str, this.D, jSONObject.toString(), z);
        aQ = (aN + 43) % 128;
        return bArrT;
    }

    private synchronized void e(FaceTecIDScanStatus faceTecIDScanStatus) {
        try {
            aQ = (aN + 35) % 128;
            this.W = true;
            this.U = false;
            cp cpVar = this.e;
            if (cpVar != null) {
                cpVar.d();
            }
            c(faceTecIDScanStatus);
            int i = aN + 13;
            aQ = i % 128;
            if (i % 2 != 0) {
                int i2 = 0 / 0;
            }
        } catch (Throwable th) {
            throw th;
        }
    }

    private void b(final b bVar) {
        final String string = UUID.randomUUID().toString();
        this.aA = new FaceTecIDScanResult(FaceTecIDScanStatus.SUCCESS);
        dj.a(new Runnable() { // from class: com.facetec.sdk.乐祭
            @Override // java.lang.Runnable
            public final void run() {
                this.f6856.c(string, bVar);
            }
        }).c(new Runnable() { // from class: com.facetec.sdk.乐符
            @Override // java.lang.Runnable
            public final void run() {
                this.f6859.am();
            }
        });
        int i = aN + 83;
        aQ = i % 128;
        if (i % 2 != 0) {
            int i2 = 37 / 0;
        }
    }

    public final synchronized void e(FaceTecSessionStatus faceTecSessionStatus, FaceTecIDScanStatus faceTecIDScanStatus) {
        try {
            aN = (aQ + 63) % 128;
            this.U = false;
            cp cpVar = this.e;
            if (cpVar != null && faceTecIDScanStatus == null) {
                cpVar.e = true;
                cpVar.d();
            }
            if (G()) {
                aQ = (aN + EnumC41897g.SDK_ASSET_ILLUSTRATION_DEPOSIT_SWITCH_VALUE) % 128;
                if (faceTecIDScanStatus != FaceTecIDScanStatus.SKIPPED) {
                    int i = aQ + 53;
                    aN = i % 128;
                    if (i % 2 == 0) {
                        this.aa = true;
                        return;
                    } else {
                        this.aa = false;
                        return;
                    }
                }
            }
            if (this.aw) {
                int i2 = aN + 87;
                aQ = i2 % 128;
                if (i2 % 2 == 0) {
                    c(faceTecIDScanStatus);
                    return;
                } else {
                    c(faceTecIDScanStatus);
                    throw null;
                }
            }
            this.W = true;
            this.U = false;
            if (faceTecIDScanStatus == FaceTecIDScanStatus.SKIPPED) {
                int i3 = aQ + 119;
                aN = i3 % 128;
                if (i3 % 2 != 0) {
                    a(faceTecSessionStatus, faceTecIDScanStatus);
                    return;
                } else {
                    a(faceTecSessionStatus, faceTecIDScanStatus);
                    throw null;
                }
            }
            a(faceTecSessionStatus);
            return;
        } catch (Throwable th) {
            throw th;
        }
        throw th;
    }

    private static /* synthetic */ Object a(Object[] objArr) {
        bi biVar = (bi) objArr[0];
        FaceTecIDScanNextStep faceTecIDScanNextStep = (FaceTecIDScanNextStep) objArr[1];
        int i = aQ + 25;
        aN = i % 128;
        int i2 = i % 2;
        biVar.c(faceTecIDScanNextStep);
        if (i2 == 0) {
            int i3 = 15 / 0;
        }
        aN = (aQ + 89) % 128;
        return null;
    }

    public final void a(final JSONObject jSONObject) {
        aQ = (aN + 33) % 128;
        e(0);
        cx.d dVar = cx.d.USER_CONFIRMED_INFO;
        this.aK = dVar;
        this.f = cx.b(true, dVar);
        getFragmentManager().beginTransaction().setCustomAnimations(R.animator.facetec_no_delay_fade_in, 0).add(this.an, this.f, "Results").commitAllowingStateLoss();
        b(new b() { // from class: com.facetec.sdk.丹海
            @Override // com.facetec.sdk.bi.b
            public final byte[] getIdScanBytes(String str) {
                return this.f6769.b(jSONObject, str);
            }
        });
        int i = aQ + 103;
        aN = i % 128;
        if (i % 2 == 0) {
            throw null;
        }
    }

    public final void b(final boolean z) {
        final String strA;
        int i = aQ + 3;
        aN = i % 128;
        if (i % 2 != 0) {
            if (z) {
                strA = dm.a(ck.FINISHED_WITH_SUCCESS, this.ar);
            } else {
                strA = dm.a(ck.FINISHED_WITH_ERROR, this.ar);
                aN = (aQ + 1) % 128;
            }
            this.f.b(new Runnable() { // from class: com.facetec.sdk.乐王
                @Override // java.lang.Runnable
                public final void run() {
                    this.f6849.e(z, strA);
                }
            }, 500L);
            return;
        }
        throw null;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void b(float f) {
        e(FaceTecOCRConfirmationCustomization.d(), -1652613210, 1652613216, FaceTecOCRConfirmationCustomization.d(), new Object[]{this, Float.valueOf(f)}, FaceTecOCRConfirmationCustomization.d(), FaceTecOCRConfirmationCustomization.d());
    }

    private void a(final t.b bVar) {
        int i = aN + 49;
        aQ = i % 128;
        if (i % 2 != 0) {
            bk.b();
            throw null;
        }
        if (bk.b()) {
            final String str = cp.c;
            dj.a(new Runnable() { // from class: com.facetec.sdk.乐名
                @Override // java.lang.Runnable
                public final void run() {
                    this.f6813.c(str, bVar);
                }
            });
            aQ = (aN + 19) % 128;
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static /* synthetic */ WindowInsetsCompat b(View view, WindowInsetsCompat windowInsetsCompat) {
        return (WindowInsetsCompat) e(FaceTecOCRConfirmationCustomization.d(), -829124670, 829124679, FaceTecOCRConfirmationCustomization.d(), new Object[]{view, windowInsetsCompat}, FaceTecOCRConfirmationCustomization.d(), FaceTecOCRConfirmationCustomization.d());
    }

    private void a(boolean z) {
        e(FaceTecOCRConfirmationCustomization.d(), 827085871, -827085847, FaceTecOCRConfirmationCustomization.d(), new Object[]{this, Boolean.valueOf(z)}, FaceTecOCRConfirmationCustomization.d(), FaceTecOCRConfirmationCustomization.d());
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void a(FaceTecIDScanNextStep faceTecIDScanNextStep) {
        e(FaceTecOCRConfirmationCustomization.d(), 852680709, -852680702, FaceTecOCRConfirmationCustomization.d(), new Object[]{this, faceTecIDScanNextStep}, FaceTecOCRConfirmationCustomization.d(), FaceTecOCRConfirmationCustomization.d());
    }

    /* JADX WARN: Removed duplicated region for block: B:12:0x0037  */
    /* JADX WARN: Removed duplicated region for block: B:9:0x0027  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    private void e(final com.facetec.sdk.bw r5, final java.lang.String r6) {
        /*
            r4 = this;
            int r0 = com.facetec.sdk.bi.aQ
            int r0 = r0 + 51
            int r1 = r0 % 128
            com.facetec.sdk.bi.aN = r1
            int r0 = r0 % 2
            java.lang.String r1 = "retry"
            r2 = 0
            r3 = 0
            if (r0 != 0) goto L1c
            com.facetec.sdk.c r0 = com.facetec.sdk.c.DEVELOPER_USED_ID_SCAN_CALLBACK
            com.facetec.sdk.t.d(r4, r0, r1, r3)
            r4.Z = r2
            boolean r0 = com.facetec.sdk.bj.f95831g
            if (r0 == 0) goto L27
            goto L37
        L1c:
            com.facetec.sdk.c r0 = com.facetec.sdk.c.DEVELOPER_USED_ID_SCAN_CALLBACK
            com.facetec.sdk.t.d(r4, r0, r1, r3)
            r4.Z = r2
            boolean r0 = com.facetec.sdk.bj.f95831g
            if (r0 != 0) goto L37
        L27:
            com.facetec.sdk.bv r0 = r4.A
            boolean r1 = r5.c
            if (r1 != 0) goto L41
            int r1 = com.facetec.sdk.bi.aN
            int r1 = r1 + 85
            int r1 = r1 % 128
            com.facetec.sdk.bi.aQ = r1
            r2 = 1
            goto L41
        L37:
            com.facetec.sdk.bv r0 = r4.A
            int r1 = com.facetec.sdk.bi.aQ
            int r1 = r1 + 25
            int r1 = r1 % 128
            com.facetec.sdk.bi.aN = r1
        L41:
            r0.m = r2
            com.facetec.sdk.bv r0 = r4.A
            com.facetec.sdk.ca r1 = r5.e
            r0.i = r1
            com.facetec.sdk.bv$b r1 = r5.b
            r0.f95839g = r1
            com.facetec.sdk.乐弓 r0 = new com.facetec.sdk.乐弓
            r0.<init>()
            r4.runOnUiThread(r0)
            int r5 = com.facetec.sdk.bi.aN
            int r5 = r5 + 11
            int r6 = r5 % 128
            com.facetec.sdk.bi.aQ = r6
            int r5 = r5 % 2
            if (r5 != 0) goto L62
            return
        L62:
            throw r3
        */
        throw new UnsupportedOperationException("Method not decompiled: com.facetec.sdk.bi.e(com.facetec.sdk.bw, java.lang.String):void");
    }

    /* JADX WARN: Removed duplicated region for block: B:16:0x0043  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    private void e(int r5) {
        /*
            r4 = this;
            com.facetec.sdk.cx r0 = r4.f
            if (r0 == 0) goto L43
            int r0 = com.facetec.sdk.bi.aQ
            int r0 = r0 + 49
            int r0 = r0 % 128
            com.facetec.sdk.bi.aN = r0
            boolean r0 = r4.isFinishing()
            if (r0 == 0) goto L13
            goto L43
        L13:
            if (r5 != 0) goto L2f
            int r5 = com.facetec.sdk.bi.aQ
            int r5 = r5 + 49
            int r5 = r5 % 128
            com.facetec.sdk.bi.aN = r5
            r4.aa()
            int r5 = com.facetec.sdk.bi.aN
            int r5 = r5 + 67
            int r0 = r5 % 128
            com.facetec.sdk.bi.aQ = r0
            int r5 = r5 % 2
            if (r5 != 0) goto L2d
            return
        L2d:
            r5 = 0
            throw r5
        L2f:
            com.facetec.sdk.cx r0 = r4.f
            com.facetec.sdk.乐金 r1 = new com.facetec.sdk.乐金
            r1.<init>()
            long r2 = (long) r5
            r0.c(r1, r2)
            int r5 = com.facetec.sdk.bi.aQ
            int r5 = r5 + 119
        L3e:
            int r5 = r5 % 128
            com.facetec.sdk.bi.aN = r5
            return
        L43:
            int r5 = com.facetec.sdk.bi.aQ
            int r5 = r5 + 85
            goto L3e
        */
        throw new UnsupportedOperationException("Method not decompiled: com.facetec.sdk.bi.e(int):void");
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void e(final boolean z, String str) {
        int i = aN + 111;
        aQ = i % 128;
        if (i % 2 == 0) {
            this.f.a(z, z, str, new Runnable() { // from class: com.facetec.sdk.乐龙
                @Override // java.lang.Runnable
                public final void run() {
                    this.f6869.g(z);
                }
            });
        } else {
            this.f.a(z, z, str, new Runnable() { // from class: com.facetec.sdk.乐龙
                @Override // java.lang.Runnable
                public final void run() {
                    this.f6869.g(z);
                }
            });
            throw null;
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void e(t.b bVar, String str, String str2, boolean z) {
        int i = aN + EnumC41897g.SDK_ASSET_ILLUSTRATION_CALENDAR_VALUE;
        aQ = i % 128;
        if (i % 2 == 0) {
            m mVar = this.k;
            if (mVar != null) {
                mVar.b(bVar, str, str2, this.f95830g, z);
            }
            aQ = (aN + 109) % 128;
            return;
        }
        throw null;
    }

    private void e(FaceTecIDScanNextStep faceTecIDScanNextStep) {
        e(FaceTecOCRConfirmationCustomization.d(), 515625104, -515625082, FaceTecOCRConfirmationCustomization.d(), new Object[]{this, faceTecIDScanNextStep}, FaceTecOCRConfirmationCustomization.d(), FaceTecOCRConfirmationCustomization.d());
    }
}