package com.facetec.sdk;

import android.app.Activity;
import android.content.Context;
import android.content.res.Configuration;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.widget.RelativeLayout;
import androidx.annotation.NonNull;
import androidx.core.app.ActivityCompat;
import java.util.concurrent.atomic.AtomicBoolean;
import kotlin.C6852;

/* JADX INFO: loaded from: classes4.dex */
abstract class bm extends Activity {
    Handler a;
    RelativeLayout b;

    @NonNull
    private final AtomicBoolean c = new AtomicBoolean(false);
    View d;
    cp e;

    public enum b {
        NOT_GRANTED,
        DENIED_ALWAYS,
        GRANTED
    }

    private synchronized void t() {
        if (!d() && !isFinishing()) {
            d(false);
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void x() {
        if (hasWindowFocus()) {
            return;
        }
        t.d(this, c.FACETEC_SDK_ACTIVITY_CONTEXT_SWITCH_TRIGGERED, null, null);
        t();
    }

    public abstract void a();

    @Override // android.app.Activity, android.view.ContextThemeWrapper, android.content.ContextWrapper
    public void attachBaseContext(Context context) {
        super.attachBaseContext(context);
    }

    public final void b() {
        ActivityCompat.m4660(this, new String[]{"android.permission.CAMERA"}, 0);
        c(true);
    }

    public abstract void c();

    public final void c(boolean z) {
        this.c.set(z);
    }

    public abstract void d(String str);

    public abstract void d(boolean z);

    public final boolean d() {
        return this.c.get();
    }

    @NonNull
    public final b e() {
        return C6852.checkSelfPermission(this, "android.permission.CAMERA") != 0 ? (!bk.j(this).getBoolean("cameraPermissionsShown", false) || ActivityCompat.m4663(this, "android.permission.CAMERA")) ? b.NOT_GRANTED : b.DENIED_ALWAYS : b.GRANTED;
    }

    public abstract void e(String str);

    public abstract void f();

    public abstract void g();

    public abstract void h();

    public abstract void i();

    public abstract void j();

    public abstract void k();

    public abstract void l();

    public abstract void m();

    public abstract void n();

    public abstract void o();

    @Override // android.app.Activity, android.content.ComponentCallbacks
    public void onConfigurationChanged(Configuration configuration) {
        super.onConfigurationChanged(configuration);
        if (bk.e(configuration)) {
            q();
        }
    }

    @Override // android.app.Activity
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
    }

    @Override // android.app.Activity
    public void onDestroy() {
        super.onDestroy();
        Handler handler = this.a;
        if (handler != null) {
            handler.removeCallbacks(null);
        }
    }

    @Override // android.app.Activity
    public void onPause() {
        super.onPause();
    }

    @Override // android.app.Activity
    public void onResume() {
        try {
            super.onResume();
            ah.c(true);
            this.a.postDelayed(new Runnable() { // from class: com.facetec.sdk.书天
                @Override // java.lang.Runnable
                public final void run() {
                    this.f6893.x();
                }
            }, 1000L);
        } catch (Throwable th) {
            t.d(this, c.ON_RESUME_ERROR, "Error detected in onResume(). Ending the session.", th);
            d(ao.y);
        }
    }

    @Override // android.app.Activity
    public void onStart() {
        super.onStart();
    }

    public abstract void q();

    public abstract void r();

    public abstract void s();
}