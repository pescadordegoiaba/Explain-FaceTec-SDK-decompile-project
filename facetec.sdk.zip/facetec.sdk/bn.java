package com.facetec.sdk;

import android.animation.Animator;
import android.animation.ValueAnimator;
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.util.AttributeSet;
import android.view.View;
import android.view.animation.DecelerateInterpolator;
import com.incode.welcome_sdk.modules.SelfieScan;
import io.sentry.HttpStatusCodeRange;
import java.util.ArrayList;

/* JADX INFO: loaded from: classes4.dex */
final class bn extends View {
    private final ArrayList<e> a;
    private final int b;
    private int c;
    private int d;
    private final int e;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    private boolean f95833g;

    public static class d {
        float b = SelfieScan.RECOGNITION_FAIL_RESULT;
        float d;
        float e;

        public d(float f, float f2) {
            this.d = f;
            this.e = f2;
        }
    }

    public class e {
        Paint a;
        d c;
        float d = SelfieScan.RECOGNITION_FAIL_RESULT;
        private int e = -1;
        ArrayList<Animator> b = new ArrayList<>();

        public e(float f, float f2) {
            this.c = new d(f, f2);
            bn.this.setLayerType(2, null);
            Paint paint = new Paint(1);
            this.a = paint;
            paint.setStyle(Paint.Style.STROKE);
            this.a.setStrokeWidth(this.d);
            this.a.setColor(this.e);
        }
    }

    public bn(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        this.b = HttpStatusCodeRange.DEFAULT_MIN;
        this.e = 5;
        this.a = new ArrayList<>();
        this.f95833g = false;
        post(new Runnable() { // from class: com.facetec.sdk.书妖
            @Override // java.lang.Runnable
            public final void run() {
                this.f6894.c();
            }
        });
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void a(e eVar, ValueAnimator valueAnimator, Animator animator) {
        eVar.a.setAlpha(0);
        e();
        eVar.b.remove(valueAnimator);
        this.a.remove(eVar);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void b(e eVar, ValueAnimator valueAnimator) {
        eVar.c.b = ((Float) valueAnimator.getAnimatedValue()).floatValue();
        float fMin = Math.min(this.c, eVar.c.b);
        eVar.d = fMin;
        Paint paint = eVar.a;
        if (paint != null) {
            paint.setStrokeWidth(fMin);
        }
        eVar.a.setAlpha(Math.round((1.0f - valueAnimator.getAnimatedFraction()) * 255.0f));
        e();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void c() {
        this.d = Math.round(bh.a(50) * dm.c() * dm.b());
        this.c = Math.round(bh.a(3) * dm.c() * dm.b());
    }

    private void e() {
        this.f95833g = true;
        postInvalidate();
    }

    public final void d(float f, float f2) {
        if (this.a.size() > 5) {
            return;
        }
        final e eVar = new e(f, f2);
        final ValueAnimator valueAnimatorOfFloat = ValueAnimator.ofFloat(eVar.c.b, this.d);
        valueAnimatorOfFloat.setDuration(500L);
        valueAnimatorOfFloat.setInterpolator(new DecelerateInterpolator());
        valueAnimatorOfFloat.addUpdateListener(new ValueAnimator.AnimatorUpdateListener() { // from class: com.facetec.sdk.书字
            @Override // android.animation.ValueAnimator.AnimatorUpdateListener
            public final void onAnimationUpdate(ValueAnimator valueAnimator) {
                this.f6895.b(eVar, valueAnimator);
            }
        });
        valueAnimatorOfFloat.addListener(new f() { // from class: com.facetec.sdk.书宫
            @Override // android.animation.Animator.AnimatorListener
            public final void onAnimationEnd(Animator animator) {
                this.f6897.a(eVar, valueAnimatorOfFloat, animator);
            }
        });
        valueAnimatorOfFloat.start();
        eVar.b.add(valueAnimatorOfFloat);
        this.a.add(eVar);
    }

    @Override // android.view.View
    public final void onDraw(Canvas canvas) {
        ArrayList<e> arrayList;
        if (!this.f95833g || (arrayList = this.a) == null || arrayList.size() <= 0) {
            return;
        }
        for (e eVar : this.a) {
            d dVar = eVar.c;
            canvas.drawCircle(dVar.d, dVar.e, dVar.b, eVar.a);
        }
        this.f95833g = false;
    }
}