package com.facetec.sdk;

import android.app.Activity;
import android.content.res.Resources;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewTreeObserver;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;
import androidx.annotation.NonNull;
import com.facetec.sdk.au;
import com.facetec.sdk.bh;
import com.facetec.sdk.pg;
import com.incode.welcome_sdk.modules.SelfieScan;
import java.util.ArrayList;
import java.util.Arrays;

/* JADX INFO: loaded from: classes4.dex */
public final class bo extends au {
    TextView a;
    LinearLayout b;
    TextView c;
    ImageView d;
    LinearLayout e;
    View f;
    GradientDrawable h;
    GradientDrawable i;
    RelativeLayout j;
    private TextView k;
    private TextView l;
    private TextView m;
    private TextView n;
    private TextView o;
    private RelativeLayout p;
    private k q;
    private RelativeLayout r;
    private TextView s;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    boolean f95835g = false;
    private final ViewTreeObserver.OnGlobalLayoutListener t = new AnonymousClass1();

    /* JADX INFO: renamed from: com.facetec.sdk.bo$1, reason: invalid class name */
    public class AnonymousClass1 implements ViewTreeObserver.OnGlobalLayoutListener {
        public AnonymousClass1() {
        }

        /* JADX INFO: Access modifiers changed from: private */
        public /* synthetic */ void b() {
            boolean z;
            boolean z2;
            int i;
            int i2;
            float fB = dm.b();
            int iRound = Math.round(((Integer) dm.e(pg.a.a(), pg.a.a(), 1933108801, new Object[0], pg.a.a(), -1933108792, pg.a.a())).intValue() * dm.c());
            int iRound2 = Math.round(bh.a(35) * dm.c() * fB);
            int iRound3 = Math.round(bh.a(5) * dm.c() * fB);
            float f = bo.this.getArguments().getFloat("bottomOval");
            float f2 = bo.this.getArguments().getFloat("topOval") - (iRound << 1);
            int i3 = iRound3 << 1;
            float f3 = i3;
            float f4 = f2 - f3;
            float measuredHeight = (bo.this.f.getMeasuredHeight() - f) - f3;
            int measuredHeight2 = bo.this.b.getMeasuredHeight() - i3;
            int iFloor = (int) Math.floor(f4);
            if (f4 < measuredHeight2) {
                iFloor = measuredHeight2 + (iRound3 << 2);
                z = true;
            } else {
                z = false;
            }
            int measuredHeight3 = bo.this.q.getMeasuredHeight() - i3;
            int iFloor2 = (int) Math.floor(measuredHeight);
            if (measuredHeight < measuredHeight3) {
                iFloor2 = measuredHeight3 + (iRound3 << 2);
                z2 = true;
            } else {
                z2 = false;
            }
            int i4 = (z && dm.bn()) ? iRound2 : 0;
            RelativeLayout.LayoutParams layoutParams = new RelativeLayout.LayoutParams(-1, iFloor);
            layoutParams.setMargins(i4, 0, i4, 0);
            layoutParams.addRule(10);
            bo.this.p.setLayoutParams(layoutParams);
            RelativeLayout.LayoutParams layoutParams2 = new RelativeLayout.LayoutParams(-1, iFloor2);
            layoutParams2.setMargins(0, 0, 0, iRound3);
            layoutParams2.addRule(12);
            bo.this.j.setLayoutParams(layoutParams2);
            if (z) {
                bo.this.b.setPadding(iRound3, iRound3, iRound3, iRound3);
                bo.this.b.setBackground(bo.this.h);
                bo.this.b.invalidate();
            }
            if (z2) {
                bo.this.q.setPadding(iRound3, iRound3, iRound3, iRound3);
                bo.this.q.setBackground(bo.this.i);
                bo.this.q.invalidate();
            }
            if (FaceTecSDK.d.c) {
                bo.this.q.setOnClickRunnable(new Runnable() { // from class: com.facetec.sdk.书山
                    @Override // java.lang.Runnable
                    public final void run() {
                        this.f6900.e();
                    }
                });
            }
            int iFloor3 = (int) Math.floor((((double) iFloor) / 2.0d) / 1.3d);
            int iFloor4 = (int) Math.floor((((double) iFloor2) / 2.0d) / 1.3d);
            int width = bo.this.p.getWidth();
            int width2 = bo.this.j.getWidth();
            if (z) {
                iFloor3 = (int) Math.floor(((double) (iFloor - i3)) / 2.0d);
                i = width - i3;
                i2 = i;
            } else {
                if (!dm.bn()) {
                    iRound2 = 0;
                }
                i = width - (iRound2 << 1);
                i2 = width;
            }
            if (z2) {
                iFloor4 = (int) Math.floor(((double) (iFloor2 - i3)) / 2.0d);
                width2 = bo.this.j.getWidth() - i3;
            }
            bh.a aVar = new bh.a(i, iFloor3);
            bh.a aVar2 = new bh.a(i2, iFloor3);
            bh.a aVar3 = new bh.a(width2, iFloor4);
            int iRound4 = Math.round(bh.d(8));
            int iRound5 = Math.round(bh.d(40));
            int iRound6 = Math.round(bh.d(5));
            int iRound7 = Math.round(bh.d(36));
            int iC = bh.c(bo.this.n, aVar, iRound4, iRound5);
            int iC2 = bh.c(bo.this.m, aVar2, iRound4, iRound5);
            int iC3 = bh.c(bo.this.k, aVar3, iRound6, iRound7);
            int iC4 = bh.c(bo.this.s, aVar3, iRound6, iRound7);
            int iMin = Math.min(iC, iC2);
            int iRound8 = (int) Math.round(((double) iMin) * 0.85d);
            if (iC3 >= iRound8) {
                iC3 = iRound8;
            }
            if (iC4 >= iC3) {
                iC4 = iC3;
            }
            float f5 = iMin;
            bo.this.n.setTextSize(0, f5);
            bo.this.m.setTextSize(0, f5);
            float f6 = iC4;
            bo.this.k.setTextSize(0, f6);
            bo.this.s.setTextSize(0, f6);
            StringBuilder sb = new StringBuilder();
            sb.append(String.valueOf(bo.this.n.getText()));
            sb.append((Object) bo.this.m.getText());
            bo.this.b.setContentDescription(sb.toString());
        }

        /* JADX INFO: Access modifiers changed from: private */
        public /* synthetic */ void e() {
            bi biVar = (bi) bo.this.getActivity();
            if (biVar != null) {
                biVar.y();
            }
        }

        @Override // android.view.ViewTreeObserver.OnGlobalLayoutListener
        public final void onGlobalLayout() {
            bo.this.d();
            bo boVar = bo.this;
            if (boVar.f95835g) {
                return;
            }
            boVar.f95835g = true;
            boVar.p.post(new au.c(new Runnable() { // from class: com.facetec.sdk.书帝
                @Override // java.lang.Runnable
                public final void run() {
                    this.f6901.b();
                }
            }));
        }
    }

    public enum e {
        GENERIC,
        READY_OVAL
    }

    @Override // com.facetec.sdk.au, android.app.Fragment
    public final void onCreate(Bundle bundle) {
        super.onCreate(bundle);
    }

    @Override // android.app.Fragment
    public final View onCreateView(LayoutInflater layoutInflater, ViewGroup viewGroup, Bundle bundle) {
        View viewInflate = layoutInflater.inflate(R.layout.facetec_guidance_center_content_fragment, viewGroup, false);
        this.f = viewInflate;
        return viewInflate;
    }

    @Override // android.app.Fragment
    public final void onDestroy() {
        super.onDestroy();
        d();
    }

    @Override // android.app.Fragment
    public final void onStart() {
        super.onStart();
        if (getArguments().getBoolean("isCameraPermissionsShowing")) {
            this.c.setImportantForAccessibility(1);
            this.c.sendAccessibilityEvent(8);
            this.c.performAccessibilityAction(64, null);
            return;
        }
        this.j.setImportantForAccessibility(1);
        RelativeLayout relativeLayout = this.j;
        StringBuilder sb = new StringBuilder();
        sb.append((Object) this.k.getText());
        sb.append(" ");
        sb.append((Object) this.s.getText());
        relativeLayout.setContentDescription(sb.toString());
        this.b.setImportantForAccessibility(1);
        this.b.setScreenReaderFocusable(true);
        this.j.setScreenReaderFocusable(true);
        this.b.sendAccessibilityEvent(8);
        this.b.performAccessibilityAction(64, null);
    }

    @Override // android.app.Fragment
    public final void onViewCreated(View view, Bundle bundle) {
        super.onViewCreated(view, bundle);
        this.e = (LinearLayout) view.findViewById(R.id.iconLayout);
        this.d = (ImageView) view.findViewById(R.id.iconImageView);
        TextView textView = (TextView) view.findViewById(R.id.genericHeaderView);
        this.c = textView;
        dm.c(textView);
        this.c.setTypeface(br.c);
        this.c.setLineSpacing(SelfieScan.RECOGNITION_FAIL_RESULT, 1.1f);
        TextView textView2 = (TextView) view.findViewById(R.id.feedbackIconsHeader);
        this.l = textView2;
        dm.c(textView2);
        this.l.setTypeface(br.c);
        this.l.setLineSpacing(SelfieScan.RECOGNITION_FAIL_RESULT, 1.1f);
        this.a = (TextView) view.findViewById(R.id.messageView1);
        this.o = (TextView) view.findViewById(R.id.messageView2);
        this.a.setTypeface(br.e);
        this.o.setTypeface(br.e);
        dm.c(this.a);
        dm.c(this.o);
        this.a.setLineSpacing(SelfieScan.RECOGNITION_FAIL_RESULT, 1.1f);
        this.o.setLineSpacing(SelfieScan.RECOGNITION_FAIL_RESULT, 1.1f);
        this.r = (RelativeLayout) view.findViewById(R.id.readyScreenContent);
        this.n = (TextView) view.findViewById(R.id.readyScreenHeader1);
        this.m = (TextView) view.findViewById(R.id.readyScreenHeader2);
        this.k = (TextView) view.findViewById(R.id.readyScreenSubtext1);
        this.s = (TextView) view.findViewById(R.id.readyScreenSubtext2);
        this.p = (RelativeLayout) view.findViewById(R.id.readyScreenHeaderOuterContainer);
        this.j = (RelativeLayout) view.findViewById(R.id.readyScreenSubtextOuterContainer);
        this.b = (LinearLayout) view.findViewById(R.id.readyScreenHeaderInnerContainer);
        this.q = (k) view.findViewById(R.id.readyScreenSubtextInnerContainer);
        this.b.setImportantForAccessibility(1);
        this.b.setAccessibilityHeading(true);
        this.j.setImportantForAccessibility(1);
        this.p.setImportantForAccessibility(2);
        this.n.setImportantForAccessibility(2);
        this.m.setImportantForAccessibility(2);
        this.k.setImportantForAccessibility(2);
        this.s.setImportantForAccessibility(2);
        this.n.setTypeface(dm.J());
        this.m.setTypeface(dm.J());
        this.k.setTypeface(dm.L());
        this.s.setTypeface(dm.L());
        this.n.setTextColor(dm.f(getActivity()));
        this.m.setTextColor(dm.f(getActivity()));
        this.k.setTextColor(dm.h(getActivity()));
        this.s.setTextColor(dm.h(getActivity()));
        this.n.setLineSpacing(SelfieScan.RECOGNITION_FAIL_RESULT, 1.1f);
        this.m.setLineSpacing(SelfieScan.RECOGNITION_FAIL_RESULT, 1.1f);
        this.k.setLineSpacing(SelfieScan.RECOGNITION_FAIL_RESULT, 1.1f);
        this.s.setLineSpacing(SelfieScan.RECOGNITION_FAIL_RESULT, 1.1f);
        float fB = dm.b() * dm.c();
        float f = 28.0f * fB;
        this.n.setTextSize(2, f);
        this.m.setTextSize(2, f);
        float f2 = 20.0f * fB;
        this.k.setTextSize(2, f2);
        this.s.setTextSize(2, f2);
        this.c.setTextSize(2, f);
        this.l.setTextSize(2, f);
        this.a.setTextSize(2, f2);
        int iA = pg.a.a();
        int iIntValue = ((Integer) dm.e(pg.a.a(), iA, 1933108801, new Object[0], pg.a.a(), -1933108792, pg.a.a())).intValue();
        view.setPadding(iIntValue, iIntValue, iIntValue, 0);
        RelativeLayout.LayoutParams layoutParams = (RelativeLayout.LayoutParams) this.p.getLayoutParams();
        layoutParams.setMarginStart(iIntValue);
        layoutParams.setMarginEnd(iIntValue);
        this.p.setLayoutParams(layoutParams);
        RelativeLayout.LayoutParams layoutParams2 = (RelativeLayout.LayoutParams) this.j.getLayoutParams();
        layoutParams2.setMarginStart(iIntValue);
        layoutParams2.setMarginEnd(iIntValue);
        this.j.setLayoutParams(layoutParams2);
        e eVar = (e) getArguments().get("screenType");
        int i = getArguments().getInt("header");
        e eVar2 = e.GENERIC;
        if (eVar == eVar2) {
            dp.e(this.c, i);
        } else {
            dp.e(this.l, i);
        }
        if (eVar == eVar2) {
            dp.e(this.a, getArguments().getInt("message"));
        } else if (eVar == e.READY_OVAL) {
            this.r.setVisibility(0);
            TextView textView3 = this.n;
            Object[] objArr = {Boolean.TRUE, Boolean.FALSE};
            dq.b(textView3, (String) dm.e(pg.a.a(), pg.a.a(), -449345628, objArr, pg.a.a(), 449345631, pg.a.a()));
            dq.b(this.m, dm.b(true, false));
            dq.b(this.k, dm.e(true, false));
            dq.b(this.s, dm.c(true, false));
            Resources resources = getResources();
            GradientDrawable gradientDrawable = (GradientDrawable) resources.getDrawable(R.drawable.facetec_ready_header_background).mutate();
            this.h = gradientDrawable;
            gradientDrawable.setCornerRadius(bh.a(dm.z()) * dm.c());
            Activity activity = getActivity();
            GradientDrawable gradientDrawable2 = this.h;
            int iA2 = pg.a.a();
            dq.d(activity, gradientDrawable2, ((Integer) dm.e(pg.a.a(), iA2, -1412338306, new Object[0], pg.a.a(), 1412338333, pg.a.a())).intValue());
            GradientDrawable gradientDrawable3 = (GradientDrawable) resources.getDrawable(R.drawable.facetec_ready_subtext_background).mutate();
            this.i = gradientDrawable3;
            gradientDrawable3.setCornerRadius(bh.a(dm.z()) * dm.c());
            Activity activity2 = getActivity();
            GradientDrawable gradientDrawable4 = this.i;
            int iA3 = pg.a.a();
            dq.d(activity2, gradientDrawable4, ((Integer) dm.e(pg.a.a(), iA3, -1412338306, new Object[0], pg.a.a(), 1412338333, pg.a.a())).intValue());
            this.p.getViewTreeObserver().addOnGlobalLayoutListener(this.t);
        }
        LinearLayout.LayoutParams layoutParams3 = (LinearLayout.LayoutParams) this.e.getLayoutParams();
        ((ViewGroup.LayoutParams) layoutParams3).height = Math.round(bh.a(78) * fB);
        ((ViewGroup.MarginLayoutParams) layoutParams3).bottomMargin = iIntValue;
        this.e.setLayoutParams(layoutParams3);
        ((ViewGroup.MarginLayoutParams) ((LinearLayout.LayoutParams) this.c.getLayoutParams())).bottomMargin = iIntValue;
    }

    @NonNull
    public static bo e(int i, int i2, e eVar, float f, float f2, int i3) {
        bo boVar = new bo();
        Bundle bundle = new Bundle();
        bundle.putInt("header", i);
        bundle.putInt("message", i2);
        bundle.putSerializable("screenType", eVar);
        bundle.putFloat("topOval", f);
        bundle.putFloat("bottomOval", f2);
        bundle.putInt("retryActionButtonId", i3);
        boVar.setArguments(bundle);
        return boVar;
    }

    public final void b(boolean z) {
        TextView textView;
        if (!b() || (textView = this.n) == null || this.m == null || this.k == null || this.s == null) {
            return;
        }
        bh.b(new ArrayList(Arrays.asList(this.n, this.m)), textView.getCurrentTextColor(), dm.f(getActivity())).start();
        bh.b(new ArrayList(Arrays.asList(this.k, this.s)), this.k.getCurrentTextColor(), dm.h(getActivity())).start();
        if (z) {
            if (this.b.getBackground() == null && this.q.getBackground() == null) {
                return;
            }
            bh.c(new ArrayList(Arrays.asList(this.h, this.i)), new ArrayList(Arrays.asList(this.b, this.q)), dq.b(getActivity(), FaceTecSDK.d.i.readyScreenTextBackgroundColor), dq.b(getActivity(), ((Integer) dm.e(pg.a.a(), pg.a.a(), -1412338306, new Object[0], pg.a.a(), 1412338333, pg.a.a())).intValue())).start();
        }
    }

    public final void d() {
        RelativeLayout relativeLayout = this.p;
        if (relativeLayout != null) {
            relativeLayout.getViewTreeObserver().removeOnGlobalLayoutListener(this.t);
        }
    }

    public final void d(int i) {
        String[] strArrSplit = dp.a(i).split("\n\n");
        if (strArrSplit.length == 2) {
            this.a.setText(strArrSplit[0]);
            this.o.setText(strArrSplit[1]);
            this.o.setVisibility(0);
        } else {
            dp.e(this.a, i);
            this.o.setVisibility(8);
        }
    }
}