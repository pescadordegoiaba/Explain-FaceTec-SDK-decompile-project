package com.facetec.sdk;

import android.os.Process;
import android.telephony.cdma.CdmaCellLocation;
import android.util.TypedValue;
import android.view.KeyEvent;
import android.view.View;
import android.view.ViewConfiguration;
import com.incode.welcome_sdk.modules.SelfieScan;
import java.lang.reflect.Method;
import java.nio.charset.StandardCharsets;
import java.security.InvalidKeyException;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import javax.crypto.Mac;
import javax.crypto.spec.SecretKeySpec;
import org.jmrtd.PassportService;

/* JADX INFO: loaded from: classes4.dex */
final class bp {
    private static final byte[] $$a = null;
    private static final int $$b = 0;
    private static final char[] a;
    private static char b;
    private static char c;
    private static char d;
    private static char e;

    /* JADX WARN: Removed duplicated region for block: B:10:0x0027  */
    /* JADX WARN: Removed duplicated region for block: B:8:0x0021  */
    /* JADX WARN: Unsupported multi-entry loop pattern (BACK_EDGE: B:10:0x0027 -> B:11:0x002b). Please report as a decompilation issue!!! */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    private static java.lang.String $$c(byte r5, int r6, byte r7) {
        /*
            int r5 = r5 * 3
            int r5 = 3 - r5
            byte[] r0 = com.facetec.sdk.bp.$$a
            int r6 = r6 * 2
            int r6 = r6 + 112
            int r7 = r7 * 2
            int r1 = 1 - r7
            byte[] r1 = new byte[r1]
            r2 = 0
            int r7 = 0 - r7
            if (r0 != 0) goto L19
            r4 = r6
            r6 = r7
            r3 = r2
            goto L2b
        L19:
            r3 = r2
        L1a:
            int r5 = r5 + 1
            byte r4 = (byte) r6
            r1[r3] = r4
            if (r3 != r7) goto L27
            java.lang.String r5 = new java.lang.String
            r5.<init>(r1, r2)
            return r5
        L27:
            int r3 = r3 + 1
            r4 = r0[r5]
        L2b:
            int r6 = r6 + r4
            goto L1a
        */
        throw new UnsupportedOperationException("Method not decompiled: com.facetec.sdk.bp.$$c(byte, int, byte):java.lang.String");
    }

    static {
        init$0();
        e();
        a = "0123456789ABCDEF".toCharArray();
    }

    public static byte[] a(String str) {
        return b(str.getBytes(StandardCharsets.UTF_8));
    }

    public static String b(String str) {
        return c(b(str.getBytes(StandardCharsets.UTF_8)));
    }

    public static String c(byte[] bArr) {
        char[] cArr = new char[bArr.length << 1];
        for (int i = 0; i < bArr.length; i++) {
            byte b2 = bArr[i];
            int i2 = i << 1;
            char[] cArr2 = a;
            cArr[i2] = cArr2[(b2 & 255) >>> 4];
            cArr[i2 + 1] = cArr2[b2 & PassportService.SFI_DG15];
        }
        return new String(cArr);
    }

    public static String d(byte[] bArr, String str) {
        return c(d(bArr, str.getBytes(StandardCharsets.UTF_8)));
    }

    public static void e() {
        d = (char) 3556;
        e = (char) 34724;
        c = (char) 42860;
        b = (char) 43273;
    }

    private static void f(String str, int i, Object[] objArr) throws Throwable {
        int i2;
        char[] charArray = str != null ? str.toCharArray() : str;
        hq hqVar = new hq();
        char[] cArr = new char[charArray.length];
        int i3 = 0;
        hqVar.d = 0;
        int i4 = 2;
        char[] cArr2 = new char[2];
        while (true) {
            int i5 = hqVar.d;
            if (i5 >= charArray.length) {
                objArr[0] = new String(cArr, 0, i);
                return;
            }
            cArr2[i3] = charArray[i5];
            char c2 = 1;
            cArr2[1] = charArray[i5 + 1];
            int i6 = 58224;
            int i7 = i3;
            while (i7 < 16) {
                char c3 = cArr2[c2];
                char c4 = cArr2[i3];
                char c5 = c2;
                int i8 = (c4 + i6) ^ ((c4 << 4) + ((char) (((long) c) ^ (-5528393735828501205L))));
                int i9 = c4 >>> 5;
                try {
                    Object[] objArr2 = new Object[4];
                    objArr2[3] = Integer.valueOf(b);
                    objArr2[i4] = Integer.valueOf(i9);
                    objArr2[c5] = Integer.valueOf(i8);
                    objArr2[i3] = Integer.valueOf(c3);
                    Object objD = an.d(681770103);
                    Class cls = Integer.TYPE;
                    if (objD == null) {
                        i2 = 681770103;
                        objD = an.d((ViewConfiguration.getTapTimeout() >> 16) + 357, (char) (ViewConfiguration.getScrollBarSize() >> 8), 24 - (Process.myPid() >> 22), 1589849900, false, "s", new Class[]{cls, cls, cls, cls});
                    } else {
                        i2 = 681770103;
                    }
                    char cCharValue = ((Character) ((Method) objD).invoke(null, objArr2)).charValue();
                    cArr2[c5] = cCharValue;
                    char c6 = cArr2[i3];
                    int i10 = i3;
                    int i11 = i4;
                    int i12 = (cCharValue + i6) ^ ((cCharValue << 4) + ((char) (((long) d) ^ (-5528393735828501205L))));
                    int i13 = cCharValue >>> 5;
                    Object[] objArr3 = new Object[4];
                    objArr3[3] = Integer.valueOf(e);
                    objArr3[i11] = Integer.valueOf(i13);
                    objArr3[c5] = Integer.valueOf(i12);
                    objArr3[i10] = Integer.valueOf(c6);
                    Object objD2 = an.d(i2);
                    if (objD2 == null) {
                        objD2 = an.d(357 - (TypedValue.complexToFloat(i10) > SelfieScan.RECOGNITION_FAIL_RESULT ? 1 : (TypedValue.complexToFloat(i10) == SelfieScan.RECOGNITION_FAIL_RESULT ? 0 : -1)), (char) (1 - (Process.getElapsedCpuTime() > 0L ? 1 : (Process.getElapsedCpuTime() == 0L ? 0 : -1))), (ViewConfiguration.getKeyRepeatDelay() >> 16) + 24, 1589849900, false, "s", new Class[]{cls, cls, cls, cls});
                    }
                    cArr2[i10] = ((Character) ((Method) objD2).invoke(null, objArr3)).charValue();
                    i6 -= 40503;
                    i7++;
                    c2 = c5;
                    i3 = i10;
                    i4 = i11;
                } catch (Throwable th) {
                    Throwable cause = th.getCause();
                    if (cause == null) {
                        throw th;
                    }
                    throw cause;
                }
            }
            int i14 = i3;
            int i15 = i4;
            char c7 = c2;
            int i16 = hqVar.d;
            cArr[i16] = cArr2[i14];
            cArr[i16 + 1] = cArr2[c7];
            Object[] objArr4 = new Object[i15];
            objArr4[c7] = hqVar;
            objArr4[i14] = hqVar;
            Object objD3 = an.d(227457195);
            if (objD3 == null) {
                byte b2 = (byte) i14;
                byte b3 = b2;
                objD3 = an.d(1827 - KeyEvent.getDeadChar(i14, i14), (char) (CdmaCellLocation.convertQuartSecToDecDegrees(i14) > 0.0d ? 1 : (CdmaCellLocation.convertQuartSecToDecDegrees(i14) == 0.0d ? 0 : -1)), (Process.myPid() >> 22) + 24, 2079288304, false, $$c(b2, b3, b3), new Class[]{Object.class, Object.class});
            }
            ((Method) objD3).invoke(null, objArr4);
            i4 = i15;
            i3 = 0;
        }
    }

    public static void init$0() {
        $$a = new byte[]{10, 80, 9, 70};
        $$b = 98;
    }

    public static byte[] b(byte[]... bArr) throws Throwable {
        return MessageDigest.getInstance("SHA-256").digest(d(bArr));
    }

    private static byte[] d(byte[] bArr, byte[]... bArr2) throws NoSuchAlgorithmException, InvalidKeyException {
        SecretKeySpec secretKeySpec = new SecretKeySpec(bArr, "HmacSHA256");
        Mac mac = Mac.getInstance("HmacSHA256");
        mac.init(secretKeySpec);
        return mac.doFinal(d(bArr2));
    }

    public static byte[] b(byte[] bArr, String str) {
        return d(bArr, str.getBytes(StandardCharsets.UTF_8));
    }

    private static byte[] d(byte[]... bArr) throws Throwable {
        int length = 0;
        for (byte[] bArr2 : bArr) {
            length += bArr2.length;
        }
        byte[] bArr3 = new byte[length];
        int length2 = 0;
        for (byte[] bArr4 : bArr) {
            try {
                Object[] objArr = {bArr4, 0, bArr3, Integer.valueOf(length2), Integer.valueOf(bArr4.length)};
                Object[] objArr2 = new Object[1];
                f("﵊䐂曓Ӈ吊ࡳۮⱹⵉ䖙슝䄹众\ue0d8́\uecd6", 16 - View.getDefaultSize(0, 0), objArr2);
                Class<?> cls = Class.forName((String) objArr2[0]);
                Object[] objArr3 = new Object[1];
                f("\ud955杧卂뙺ᛸ墔큱䓬댏쩂", 9 - (ViewConfiguration.getMaximumFlingVelocity() >> 16), objArr3);
                String str = (String) objArr3[0];
                Class cls2 = Integer.TYPE;
                cls.getMethod(str, Object.class, cls2, Object.class, cls2, cls2).invoke(null, objArr);
                length2 += bArr4.length;
            } catch (Throwable th) {
                Throwable cause = th.getCause();
                if (cause != null) {
                    throw cause;
                }
                throw th;
            }
        }
        return bArr3;
    }
}