package com.facetec.sdk;

import android.content.Context;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;

/* JADX INFO: loaded from: classes4.dex */
final class bq {
    public static byte[] a(Context context, String str) {
        FileInputStream fileInputStreamOpenFileInput = context.openFileInput(str);
        try {
            byte[] bArrE = e(fileInputStreamOpenFileInput);
            if (fileInputStreamOpenFileInput != null) {
                fileInputStreamOpenFileInput.close();
            }
            return bArrE;
        } catch (Throwable th) {
            if (fileInputStreamOpenFileInput != null) {
                try {
                    fileInputStreamOpenFileInput.close();
                } catch (Throwable th2) {
                    th.addSuppressed(th2);
                }
            }
            throw th;
        }
    }

    public static byte c(Context context, String str) {
        FileInputStream fileInputStreamOpenFileInput = context.openFileInput(str);
        try {
            byte b = (byte) fileInputStreamOpenFileInput.read();
            fileInputStreamOpenFileInput.close();
            return b;
        } catch (Throwable th) {
            if (fileInputStreamOpenFileInput != null) {
                try {
                    fileInputStreamOpenFileInput.close();
                } catch (Throwable th2) {
                    th.addSuppressed(th2);
                }
            }
            throw th;
        }
    }

    private static void d(File file, byte[] bArr) throws IOException {
        FileOutputStream fileOutputStream = new FileOutputStream(file);
        try {
            try {
                fileOutputStream.write(bArr);
            } catch (IOException e) {
                throw e;
            }
        } finally {
            fileOutputStream.close();
        }
    }

    private static byte[] e(File file) throws IOException {
        FileInputStream fileInputStream = new FileInputStream(file);
        try {
            return e(fileInputStream);
        } finally {
            fileInputStream.close();
        }
    }

    public static void c(Context context, String str, byte[] bArr, byte[] bArr2) {
        e(context, str, new ag(bArr).c(bArr2));
    }

    private static byte[] e(FileInputStream fileInputStream) throws IOException {
        ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
        byte[] bArr = new byte[(int) fileInputStream.getChannel().size()];
        while (fileInputStream.available() > 0) {
            byteArrayOutputStream.write(bArr, 0, fileInputStream.read(bArr));
        }
        return byteArrayOutputStream.toByteArray();
    }

    public static void d(File file, byte[] bArr, byte[] bArr2) {
        d(file, new ag(bArr).c(bArr2));
    }

    public static void e(Context context, String str, byte[] bArr) {
        FileOutputStream fileOutputStreamOpenFileOutput = context.openFileOutput(str, 0);
        fileOutputStreamOpenFileOutput.write(bArr);
        fileOutputStreamOpenFileOutput.close();
    }

    public static byte[] e(File file, byte[] bArr) {
        return new ag(bArr).b(e(file));
    }
}