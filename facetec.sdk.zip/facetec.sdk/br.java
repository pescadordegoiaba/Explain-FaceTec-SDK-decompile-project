package com.facetec.sdk;

import android.graphics.Typeface;

/* JADX INFO: loaded from: classes4.dex */
final class br {
    static Typeface c;
    static Typeface e;
}