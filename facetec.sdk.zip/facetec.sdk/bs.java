package com.facetec.sdk;

import android.hardware.Camera;
import android.util.Size;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

/* JADX INFO: loaded from: classes4.dex */
final class bs {
    private static final float[] a = {1.7f, 1.6f, 1.5f, 1.4f, 1.3f};

    /* JADX INFO: Access modifiers changed from: private */
    public static /* synthetic */ int a(ar arVar, ar arVar2) {
        return (arVar2.b * arVar2.e) - (arVar.b * arVar.e);
    }

    public static ar b(Size[] sizeArr) {
        ArrayList arrayList = new ArrayList();
        for (Size size : sizeArr) {
            arrayList.add(new ar(size.getWidth(), size.getHeight()));
        }
        return d(arrayList);
    }

    public static ar c(Camera camera) {
        List<Camera.Size> supportedPreviewSizes = camera.getParameters().getSupportedPreviewSizes();
        ArrayList arrayList = new ArrayList();
        for (Camera.Size size : supportedPreviewSizes) {
            arrayList.add(new ar(size.width, size.height));
        }
        return d(arrayList);
    }

    private static ar d(List<ar> list) {
        ArrayList arrayList = new ArrayList();
        Collections.sort(list, new Comparator() { // from class: com.facetec.sdk.书庙
            @Override // java.util.Comparator
            public final int compare(Object obj, Object obj2) {
                return bs.a((ar) obj, (ar) obj2);
            }
        });
        double dRandom = Math.random();
        int i = 3;
        for (float f : a) {
            for (ar arVar : list) {
                float f2 = arVar.b;
                float f3 = arVar.e;
                float f4 = f2 / f3;
                if (f4 >= f && f4 <= 1.9f) {
                    if (dRandom < 0.7d) {
                        if (f2 < 640.0f || f2 > 3840.0f) {
                            i = 1;
                        } else {
                            i = 1;
                            arrayList.add(arVar);
                        }
                    } else if (dRandom < 0.85d) {
                        if (f2 >= 640.0f && f2 <= 1920.0f && f3 <= 1080.0f) {
                            arrayList.add(arVar);
                        }
                    } else if (f2 <= 1920.0f && f3 <= 1080.0f && f2 >= 640.0f) {
                        arrayList.add(arVar);
                    }
                }
            }
            if (arrayList.size() > 0) {
                break;
            }
        }
        cv.F(i);
        return !arrayList.isEmpty() ? (ar) arrayList.get(0) : list.get(0);
    }
}