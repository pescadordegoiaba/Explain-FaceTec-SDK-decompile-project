package com.facetec.sdk;

import android.animation.Animator;
import android.animation.ValueAnimator;
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.PorterDuff;
import android.graphics.PorterDuffXfermode;
import android.graphics.RectF;
import android.util.AttributeSet;
import android.view.View;
import android.view.animation.AccelerateInterpolator;
import android.view.animation.DecelerateInterpolator;
import com.facetec.sdk.pg;
import com.incode.welcome_sdk.modules.SelfieScan;
import java.util.Random;

/* JADX INFO: loaded from: classes4.dex */
final class bt extends View {
    float a;
    c b;
    int c;
    Paint d;
    int e;
    private RectF f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    private boolean f95836g;
    private final Context h;
    private boolean i;
    float j;
    private float l;
    private Paint m;
    private float o;

    public enum c {
        DEFAULT,
        SMALL_FOR_OVERZOOMED
    }

    public bt(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        this.b = c.DEFAULT;
        this.f95836g = false;
        this.i = false;
        this.h = context;
        post(new Runnable() { // from class: com.facetec.sdk.书气
            @Override // java.lang.Runnable
            public final void run() {
                this.f6911.e();
            }
        });
    }

    private void c(float f) {
        this.a = f;
        this.o = f / 1.5f;
        this.l = getWidth() / 2.0f;
        this.j = this.a;
    }

    /* JADX INFO: renamed from: a, reason: merged with bridge method [inline-methods] */
    public final void e() {
        this.c = Math.round(bh.a(dm.N()) * dm.c());
        this.e = Math.round(bh.a(dm.y()) * dm.c());
        int iA = pg.a.a();
        c(((Integer) dm.e(pg.a.a(), iA, 1933108801, new Object[0], pg.a.a(), -1933108792, pg.a.a())).intValue());
        setLayerType(1, null);
        Paint paint = new Paint(1);
        this.m = paint;
        paint.setStyle(Paint.Style.FILL);
        this.m.setAlpha(0);
        this.m.setXfermode(new PorterDuffXfermode(PorterDuff.Mode.CLEAR));
        setLayerType(2, null);
        Paint paint2 = new Paint(1);
        this.d = paint2;
        paint2.setStyle(Paint.Style.STROKE);
        this.d.setStrokeWidth(Math.round(this.e));
        this.d.setColor(dm.d(this.h));
    }

    public final void b() {
        this.f95836g = true;
        postInvalidate();
    }

    public final RectF d() {
        if (this.f == null) {
            b(false);
        }
        return this.f;
    }

    @Override // android.view.View
    public final void onDraw(Canvas canvas) {
        RectF rectF;
        Paint paint;
        canvas.drawColor(dq.c(dm.a(this.h), 255));
        if (!this.f95836g || (rectF = this.f) == null || (paint = this.m) == null || this.d == null) {
            return;
        }
        int i = this.c;
        canvas.drawRoundRect(rectF, i, i, paint);
        RectF rectF2 = this.f;
        int i2 = this.c;
        canvas.drawRoundRect(rectF2, i2, i2, this.d);
    }

    @Override // android.view.View
    public final void onLayout(boolean z, int i, int i2, int i3, int i4) {
        super.onLayout(z, i, i2, i3, i4);
        b(true);
        b();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static /* synthetic */ void e(Runnable runnable, Animator animator) {
        if (runnable != null) {
            runnable.run();
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void e(final Runnable runnable) {
        ValueAnimator valueAnimatorOfFloat = ValueAnimator.ofFloat(this.j, this.l);
        valueAnimatorOfFloat.setDuration(400L);
        valueAnimatorOfFloat.setInterpolator(new AccelerateInterpolator());
        valueAnimatorOfFloat.addUpdateListener(new ValueAnimator.AnimatorUpdateListener() { // from class: com.facetec.sdk.书星
            @Override // android.animation.ValueAnimator.AnimatorUpdateListener
            public final void onAnimationUpdate(ValueAnimator valueAnimator) {
                this.f6906.b(valueAnimator);
            }
        });
        valueAnimatorOfFloat.addListener(new f() { // from class: com.facetec.sdk.书月
            @Override // android.animation.Animator.AnimatorListener
            public final void onAnimationEnd(Animator animator) {
                this.f6907.a(runnable, animator);
            }
        });
        valueAnimatorOfFloat.start();
    }

    public final void b(boolean z) {
        if (!this.i || z) {
            this.i = true;
            int width = getWidth();
            int height = getHeight();
            int iA = pg.a.a();
            float f = width;
            float fIntValue = (f - (((Integer) dm.e(pg.a.a(), iA, 1933108801, new Object[0], pg.a.a(), -1933108792, pg.a.a())).intValue() * 2.0f)) * c();
            float f2 = height;
            float f3 = (f2 - (0.632f * fIntValue)) / 2.0f;
            float f4 = (f - fIntValue) / 2.0f;
            c(f4);
            RectF rectF = new RectF();
            this.f = rectF;
            rectF.set(f4, f3, f - f4, f2 - f3);
            ah.i = this.f.centerX();
            ah.j = this.f.centerY();
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void d(ValueAnimator valueAnimator) {
        float fFloatValue = ((Float) valueAnimator.getAnimatedValue()).floatValue();
        this.j = fFloatValue;
        this.f = a(fFloatValue);
        b();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void c(ValueAnimator valueAnimator) {
        this.d.setStrokeWidth(((Float) valueAnimator.getAnimatedValue()).floatValue());
        b();
    }

    private float c() {
        if (this.b != c.SMALL_FOR_OVERZOOMED) {
            return 1.0f;
        }
        return 1.0f / (((new Random().nextInt(Math.round(0.050000004f) + 1) / 100.0f) + 0.1f) + 1.0f);
    }

    private RectF a(float f) {
        float width = getWidth();
        float height = getHeight();
        float f2 = (height - ((width - (f * 2.0f)) * 0.632f)) / 2.0f;
        return new RectF(f, f2, width - f, height - f2);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static /* synthetic */ void b(Runnable runnable, Animator animator) {
        if (runnable != null) {
            runnable.run();
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void b(ValueAnimator valueAnimator) {
        float fFloatValue = ((Float) valueAnimator.getAnimatedValue()).floatValue();
        this.j = fFloatValue;
        this.f = a(fFloatValue);
        this.c = Math.min(Math.round(((getWidth() - (this.j * 2.0f)) * 0.632f) / 2.0f), this.c);
        b();
    }

    public final void a(final Runnable runnable) {
        final Runnable runnable2 = new Runnable() { // from class: com.facetec.sdk.书弓
            @Override // java.lang.Runnable
            public final void run() {
                this.f6902.e(runnable);
            }
        };
        ValueAnimator valueAnimatorOfFloat = ValueAnimator.ofFloat(this.j, this.o);
        valueAnimatorOfFloat.setDuration(200L);
        valueAnimatorOfFloat.setInterpolator(new DecelerateInterpolator());
        valueAnimatorOfFloat.addUpdateListener(new ValueAnimator.AnimatorUpdateListener() { // from class: com.facetec.sdk.书战
            @Override // android.animation.ValueAnimator.AnimatorUpdateListener
            public final void onAnimationUpdate(ValueAnimator valueAnimator) {
                this.f6904.d(valueAnimator);
            }
        });
        valueAnimatorOfFloat.addListener(new f() { // from class: com.facetec.sdk.书日
            @Override // android.animation.Animator.AnimatorListener
            public final void onAnimationEnd(Animator animator) {
                bt.b(runnable2, animator);
            }
        });
        valueAnimatorOfFloat.start();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void a(final Runnable runnable, Animator animator) {
        ValueAnimator valueAnimatorOfFloat = ValueAnimator.ofFloat(this.e, SelfieScan.RECOGNITION_FAIL_RESULT);
        valueAnimatorOfFloat.setDuration(100L);
        valueAnimatorOfFloat.setInterpolator(new AccelerateInterpolator());
        valueAnimatorOfFloat.addUpdateListener(new ValueAnimator.AnimatorUpdateListener() { // from class: com.facetec.sdk.书木
            @Override // android.animation.ValueAnimator.AnimatorUpdateListener
            public final void onAnimationUpdate(ValueAnimator valueAnimator) {
                this.f6909.c(valueAnimator);
            }
        });
        valueAnimatorOfFloat.addListener(new f() { // from class: com.facetec.sdk.书梦
            @Override // android.animation.Animator.AnimatorListener
            public final void onAnimationEnd(Animator animator2) {
                bt.e(runnable, animator2);
            }
        });
        valueAnimatorOfFloat.start();
    }
}