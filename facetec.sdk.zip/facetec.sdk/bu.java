package com.facetec.sdk;

import android.animation.AnimatorInflater;
import android.animation.AnimatorSet;
import android.animation.ObjectAnimator;
import android.annotation.SuppressLint;
import android.app.Activity;
import android.graphics.PorterDuff;
import android.graphics.Typeface;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import com.facetec.sdk.au;
import com.facetec.sdk.pg;
import com.incode.welcome_sdk.modules.SelfieScan;
import kotlin.C6852;

/* JADX INFO: loaded from: classes4.dex */
public final class bu extends au {
    private View a;
    private View c;
    private FrameLayout d;
    private View e;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    private ImageView f95837g;
    private TextView h;
    private ImageView i;
    private RelativeLayout j;
    private ObjectAnimator f = null;
    private ObjectAnimator k = null;
    boolean b = false;
    private boolean m = false;
    private boolean o = false;

    /* JADX INFO: Access modifiers changed from: private */
    public void a() {
        if (this.f != null) {
            return;
        }
        if (this.j.getVisibility() == 8 && this.h.getVisibility() == 8) {
            e();
            return;
        }
        if (this.m) {
            dq.a(this.f95837g);
        } else if (this.o) {
            c(new Runnable() { // from class: com.facetec.sdk.书水
                @Override // java.lang.Runnable
                public final void run() {
                    this.f6912.c();
                }
            }, 1000L);
        }
        this.f = dq.d(this.a, 1.0f, new au.c(new Runnable() { // from class: com.facetec.sdk.书海
            @Override // java.lang.Runnable
            public final void run() {
                this.f6913.d();
            }
        }));
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void c() {
        AnimatorSet animatorSet = (AnimatorSet) AnimatorInflater.loadAnimator(getActivity(), R.animator.facetec_front_id_flip_animator);
        AnimatorSet animatorSet2 = (AnimatorSet) AnimatorInflater.loadAnimator(getActivity(), R.animator.facetec_back_id_flip_animator);
        animatorSet.setTarget(this.f95837g);
        animatorSet2.setTarget(this.i);
        animatorSet.start();
        animatorSet2.start();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void d() {
        au.e(new au.c(new Runnable() { // from class: com.facetec.sdk.书王
            @Override // java.lang.Runnable
            public final void run() {
                this.f6919.f();
            }
        }), dm.o());
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void f() {
        Activity activity = getActivity();
        if (activity == null || !activity.hasWindowFocus()) {
            return;
        }
        e(new au.c(new Runnable() { // from class: com.facetec.sdk.书火
            @Override // java.lang.Runnable
            public final void run() {
                this.f6914.e();
            }
        }));
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void i() {
        b(new Runnable() { // from class: com.facetec.sdk.书礼
            @Override // java.lang.Runnable
            public final void run() {
                this.f6920.a();
            }
        }, 700L);
    }

    public final void e(final Runnable runnable) {
        c(new Runnable() { // from class: com.facetec.sdk.书灵
            @Override // java.lang.Runnable
            public final void run() {
                this.f6915.d(runnable);
            }
        });
    }

    @Override // com.facetec.sdk.au, android.app.Fragment
    public final void onCreate(Bundle bundle) {
        super.onCreate(bundle);
    }

    @Override // android.app.Fragment
    public final View onCreateView(LayoutInflater layoutInflater, ViewGroup viewGroup, Bundle bundle) {
        View viewInflate = layoutInflater.inflate(R.layout.facetec_id_feedback_fragment, viewGroup, false);
        this.c = viewInflate;
        return viewInflate;
    }

    @Override // android.app.Fragment
    public final void onResume() {
        super.onResume();
        if (this.f != null) {
            return;
        }
        c(new Runnable() { // from class: com.facetec.sdk.书祖
            @Override // java.lang.Runnable
            public final void run() {
                this.f6921.i();
            }
        });
    }

    @Override // android.app.Fragment
    @SuppressLint({"ClickableViewAccessibility"})
    public final void onViewCreated(View view, Bundle bundle) {
        super.onViewCreated(view, bundle);
        Activity activity = getActivity();
        this.e = view.findViewById(R.id.backgroundView);
        this.a = view.findViewById(R.id.contentLayout);
        this.d = (FrameLayout) view.findViewById(R.id.iconFrameLayout);
        this.j = (RelativeLayout) view.findViewById(R.id.iconImageContainer);
        this.f95837g = (ImageView) view.findViewById(R.id.frontIconImageView);
        this.i = (ImageView) view.findViewById(R.id.backIconImageView);
        this.h = (TextView) view.findViewById(R.id.messageTextView);
        float fB = dm.b() * dm.c();
        int iIntValue = ((Integer) dm.e(pg.a.a(), pg.a.a(), 1933108801, new Object[0], pg.a.a(), -1933108792, pg.a.a())).intValue();
        int iRound = Math.round(bh.a(80) * dm.bo() * fB);
        int iRound2 = Math.round(bh.a(-55) * fB);
        int iRound3 = Math.round(fB * 24.0f);
        Typeface typeface = FaceTecSDK.d.f95813g.messageFont;
        int iB = dq.b(activity, dm.P());
        int iAZ = dm.aZ();
        int iIntValue2 = ((Integer) dm.e(pg.a.a(), pg.a.a(), -508681661, new Object[0], pg.a.a(), 508681666, pg.a.a())).intValue();
        int iBb = dm.bb();
        if (iBb != 0) {
            dq.c(this.f95837g, iBb, null, false);
            this.i.setVisibility(8);
            this.m = true;
        } else if (iAZ == 0 || iIntValue2 == 0) {
            this.j.setVisibility(8);
        } else {
            Drawable drawable = C6852.getDrawable(activity, R.drawable.facetec_internal_id_card_front);
            Drawable drawable2 = C6852.getDrawable(activity, iAZ);
            Drawable drawable3 = C6852.getDrawable(activity, iIntValue2);
            if (drawable != null && drawable2 != null && drawable3 != null && bh.d(drawable, drawable2)) {
                PorterDuff.Mode mode = PorterDuff.Mode.SRC_IN;
                drawable2.setColorFilter(iB, mode);
                drawable3.setColorFilter(iB, mode);
            }
            this.f95837g.setImageDrawable(C6852.getDrawable(activity, iAZ));
            this.i.setImageDrawable(C6852.getDrawable(activity, iIntValue2));
            this.o = true;
        }
        this.a.setTranslationY(iRound2);
        this.d.getLayoutParams().height = iRound;
        this.d.getLayoutParams().width = iRound;
        ((RelativeLayout.LayoutParams) this.d.getLayoutParams()).setMargins(0, iIntValue, 0, 0);
        if (dp.e(getActivity(), R.string.FaceTec_idscan_feedback_flip_id_to_back_message)) {
            dp.e(this.h, R.string.FaceTec_idscan_feedback_flip_id_to_back_message);
            this.h.setTextColor(iB);
            this.h.setTypeface(typeface);
            this.h.setTextSize(iRound3);
            ((RelativeLayout.LayoutParams) this.h.getLayoutParams()).setMargins(0, iIntValue, 0, iIntValue);
        } else {
            this.h.setVisibility(8);
        }
        dm.d(this.e, dm.O());
        this.e.getBackground().setAlpha(((Integer) dm.e(pg.a.a(), pg.a.a(), -298147150, new Object[0], pg.a.a(), 298147185, pg.a.a())).intValue());
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void e() {
        this.b = true;
        bi biVar = (bi) getActivity();
        if (biVar == null || !biVar.hasWindowFocus()) {
            return;
        }
        biVar.A();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void d(final Runnable runnable) {
        if (this.k != null && runnable != null) {
            runnable.run();
        } else {
            this.k = dq.d(this.a, SelfieScan.RECOGNITION_FAIL_RESULT, new au.c(new Runnable() { // from class: com.facetec.sdk.书玉
                @Override // java.lang.Runnable
                public final void run() {
                    this.f6917.a(runnable);
                }
            }));
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void a(Runnable runnable) {
        this.b = true;
        View view = this.a;
        if (view != null) {
            view.setVisibility(8);
        }
        if (runnable != null) {
            runnable.run();
        }
    }
}