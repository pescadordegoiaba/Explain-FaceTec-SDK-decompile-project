package com.facetec.sdk;

import android.animation.AnimatorSet;
import android.animation.ObjectAnimator;
import android.app.Activity;
import android.graphics.Color;
import android.graphics.ImageFormat;
import android.graphics.PorterDuff;
import android.graphics.drawable.Drawable;
import android.hardware.Camera;
import android.os.Bundle;
import android.os.Handler;
import android.os.Process;
import android.os.SystemClock;
import android.text.TextUtils;
import android.util.Property;
import android.util.TypedValue;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewConfiguration;
import android.view.ViewGroup;
import android.view.ViewTreeObserver;
import android.view.animation.DecelerateInterpolator;
import android.widget.ExpandableListView;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;
import com.facetec.sdk.FaceTecCancelButtonCustomization;
import com.facetec.sdk.au;
import com.facetec.sdk.bt;
import com.facetec.sdk.cp;
import com.facetec.sdk.dk;
import com.facetec.sdk.pg;
import com.incode.welcome_sdk.modules.SelfieScan;
import com.plaid.internal.EnumC41897g;
import io.sentry.HttpStatusCodeRange;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Locale;
import java.util.Timer;
import java.util.TimerTask;
import kotlin.C6852;
import net.sf.scuba.smartcards.ISO7816;
import org.jmrtd.PassportService;

/* JADX INFO: loaded from: classes4.dex */
public final class bv extends au {
    private static final byte[] $$a = null;
    private static final int $$b = 0;
    private static long ad;
    private static long ae;
    private static int af;
    private static int ag;
    private static int ah;

    /* JADX INFO: renamed from: ai, reason: collision with root package name */
    private static char f95838ai;
    private static final int ak = 0;
    private static final byte[] al = null;
    private RelativeLayout A;
    private RelativeLayout B;
    private LinearLayout C;
    private ImageView D;
    private RelativeLayout E;
    private RelativeLayout F;
    private RelativeLayout G;
    private LinearLayout H;
    private ImageView I;
    private LinearLayout J;
    private RelativeLayout K;
    private RelativeLayout L;
    private ImageView M;
    private RelativeLayout N;
    private RelativeLayout P;
    private Timer T;
    private ap U;
    private Handler V;
    private FrameLayout X;
    private boolean Y;
    private dk Z;
    ImageView a;
    private boolean ac;
    RelativeLayout b;
    e c;
    TextView d;
    e e;
    e f;
    View h;
    ca i;
    e j;
    bi l;
    private bn p;
    private RelativeLayout q;
    private RelativeLayout r;
    private bt s;
    private RelativeLayout t;
    private TextView u;
    private TextView v;
    private RelativeLayout w;
    private ImageView x;
    private TextView y;
    private LinearLayout z;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    b f95839g = b.FRONT;
    private boolean S = false;
    boolean n = false;
    private boolean Q = false;
    private boolean O = false;
    boolean k = false;
    boolean m = false;
    private boolean R = false;
    private boolean W = false;
    private TimerTask ab = new dl(new Runnable() { // from class: com.facetec.sdk.书祭
        @Override // java.lang.Runnable
        public final void run() throws Throwable {
            this.f6924.N();
        }
    });
    private ViewTreeObserver.OnGlobalLayoutListener aa = new ViewTreeObserver.OnGlobalLayoutListener() { // from class: com.facetec.sdk.bv.3
        @Override // android.view.ViewTreeObserver.OnGlobalLayoutListener
        public final void onGlobalLayout() {
            bv bvVar = bv.this;
            if (bvVar.n) {
                return;
            }
            bvVar.n = true;
            bvVar.i();
            float fB = dm.b();
            float fC = dm.c();
            int iA = (int) (bh.a(35) * fB * fC);
            int iA2 = (int) (bh.a(50) * fB * fC);
            int iIntValue = ((Integer) dm.e(pg.a.a(), pg.a.a(), 1933108801, new Object[0], pg.a.a(), -1933108792, pg.a.a())).intValue();
            float f = iIntValue;
            float f2 = f / 2.0f;
            int iRound = Math.round(f2);
            int iRound2 = Math.round(f2);
            int i = (int) (20.0f * fB * fC);
            int iJ = dm.j();
            int i2 = (int) (fB * 16.0f * fC);
            int iRound3 = Math.round(f2);
            bv.this.f();
            RelativeLayout.LayoutParams layoutParams = (RelativeLayout.LayoutParams) bv.this.J.getLayoutParams();
            layoutParams.setMargins(iIntValue, 0, iIntValue, iIntValue);
            bv.this.J.setLayoutParams(layoutParams);
            bv.this.J.requestLayout();
            RelativeLayout.LayoutParams layoutParams2 = (RelativeLayout.LayoutParams) bv.this.K.getLayoutParams();
            layoutParams2.setMargins(iIntValue, 0, iIntValue, iIntValue);
            ((ViewGroup.LayoutParams) layoutParams2).height = iA2;
            bv.this.K.setLayoutParams(layoutParams2);
            bv.this.K.requestLayout();
            bv.this.j.setLayoutParams(new LinearLayout.LayoutParams(-1, iA2));
            bv.this.j.requestLayout();
            new LinearLayout.LayoutParams(-1, iA2).setMargins(0, 0, 0, iIntValue);
            float fC2 = (dq.c().width * dm.c()) - (iIntValue << 1);
            int i3 = (int) fC2;
            bv.this.J.getLayoutParams().width = i3;
            bv.this.J.requestLayout();
            bv.this.e.getLayoutParams().width = i3;
            bv.this.e.requestLayout();
            float fMin = Math.min(Math.max(iA2, fC2 / 2.0f), (fC2 - f) / 2.0f);
            bv.this.h.getLayoutParams().width = (int) ((bv.this.b.getWidth() - (2.0f * fMin)) / 3.0f);
            int i4 = (int) fMin;
            bv.this.f.getLayoutParams().width = i4;
            bv.this.c.getLayoutParams().width = i4;
            ((LinearLayout.LayoutParams) bv.this.f.getLayoutParams()).weight = SelfieScan.RECOGNITION_FAIL_RESULT;
            ((LinearLayout.LayoutParams) bv.this.c.getLayoutParams()).weight = SelfieScan.RECOGNITION_FAIL_RESULT;
            bv.this.f.requestLayout();
            bv.this.c.requestLayout();
            RelativeLayout.LayoutParams layoutParams3 = (RelativeLayout.LayoutParams) bv.this.a.getLayoutParams();
            layoutParams3.setMargins(iRound, iRound, 0, iRound);
            layoutParams3.setMarginStart(iRound);
            layoutParams3.setMarginEnd(iRound);
            bv.this.a.setLayoutParams(layoutParams3);
            bv.this.a.setPadding(iRound, iRound, iRound, iRound);
            bv.this.a.getLayoutParams().height = iA;
            bv.this.a.getLayoutParams().width = iA;
            bv.this.a.requestLayout();
            RelativeLayout.LayoutParams layoutParams4 = (RelativeLayout.LayoutParams) bv.this.I.getLayoutParams();
            ((ViewGroup.LayoutParams) layoutParams4).width = -2;
            ((ViewGroup.LayoutParams) layoutParams4).height = -2;
            layoutParams4.setMargins(0, iRound, iRound, iRound);
            layoutParams4.setMarginStart(iRound);
            layoutParams4.setMarginEnd(iRound);
            bv.this.I.setLayoutParams(layoutParams4);
            bv.this.I.setPadding(iRound2, iRound2, iRound2, iRound2);
            bv.this.I.getLayoutParams().height = iA;
            bv.this.I.getLayoutParams().width = iA;
            bv.this.I.requestLayout();
            if (FaceTecSDK.d.m.b == FaceTecCancelButtonCustomization.ButtonLocation.TOP_RIGHT) {
                ((RelativeLayout.LayoutParams) bv.this.I.getLayoutParams()).addRule(20);
            } else {
                ((RelativeLayout.LayoutParams) bv.this.I.getLayoutParams()).addRule(21);
            }
            float f3 = i;
            bv.this.j.setTextSize(2, f3);
            bv.this.f.setTextSize(2, f3);
            bv.this.c.setTextSize(2, f3);
            bv.this.e.setTextSize(2, f3);
            bv.this.u.setTextSize(2, iJ);
            bv.this.y.setTextSize(2, f3);
            bv.this.v.setTextSize(2, f3);
            bv.this.y.setPadding(iRound3, iRound3, iRound3, iRound3);
            bv.this.v.setPadding(iRound3, iRound3, iRound3, iRound3);
            bv.this.d.setTextSize(2, i2);
            int iIntValue2 = ((Integer) dm.e(pg.a.a(), pg.a.a(), 1933108801, new Object[0], pg.a.a(), -1933108792, pg.a.a())).intValue();
            LinearLayout.LayoutParams layoutParams5 = (LinearLayout.LayoutParams) bv.this.u.getLayoutParams();
            layoutParams5.setMarginStart(iIntValue2);
            layoutParams5.setMarginEnd(iIntValue2);
            bv.this.u.setLayoutParams(layoutParams5);
            bv.this.u.requestLayout();
        }
    };
    final cp.d o = new cp.d() { // from class: com.facetec.sdk.书符
        @Override // com.facetec.sdk.cp.d
        public final void onIDScanProgress(co coVar, cn cnVar) throws Throwable {
            this.f6925.b(coVar, cnVar);
        }
    };

    /* JADX INFO: renamed from: com.facetec.sdk.bv$2, reason: invalid class name */
    public class AnonymousClass2 implements Camera.PictureCallback {
        private static final byte[] $$a = null;
        private static final int $$b = 0;
        private static int c;
        private static int[] e;
        private static int f;
        private static int h;
        private static final byte[] i = null;
        private static final int j = 0;
        private /* synthetic */ long a;
        private /* synthetic */ boolean b;

        /* JADX WARN: Removed duplicated region for block: B:10:0x0025  */
        /* JADX WARN: Removed duplicated region for block: B:8:0x001f  */
        /* JADX WARN: Unsupported multi-entry loop pattern (BACK_EDGE: B:10:0x0025 -> B:11:0x002a). Please report as a decompilation issue!!! */
        /*
            Code decompiled incorrectly, please refer to instructions dump.
            To view partially-correct code enable 'Show inconsistent code' option in preferences
        */
        private static java.lang.String $$c(byte r7, int r8, int r9) {
            /*
                int r7 = r7 * 2
                int r7 = 4 - r7
                int r8 = r8 * 4
                int r8 = r8 + 1
                byte[] r0 = com.facetec.sdk.bv.AnonymousClass2.$$a
                int r9 = 121 - r9
                byte[] r1 = new byte[r8]
                r2 = 0
                r3 = r9
                if (r0 != 0) goto L15
                r4 = r2
                r9 = r7
                goto L2a
            L15:
                r9 = r7
                r7 = r3
                r3 = r2
            L18:
                int r4 = r3 + 1
                byte r5 = (byte) r7
                r1[r3] = r5
                if (r4 != r8) goto L25
                java.lang.String r7 = new java.lang.String
                r7.<init>(r1, r2)
                return r7
            L25:
                r3 = r0[r9]
                r6 = r9
                r9 = r7
                r7 = r6
            L2a:
                int r7 = r7 + 1
                int r9 = r9 + r3
                r3 = r9
                r9 = r7
                r7 = r3
                r3 = r4
                goto L18
            */
            throw new UnsupportedOperationException("Method not decompiled: com.facetec.sdk.bv.AnonymousClass2.$$c(byte, int, int):java.lang.String");
        }

        static {
            init$0();
            b();
            d();
            c = 0;
            f = 1;
            e = new int[]{330221829, -450650441, 441902279, 1497213383, -1998384472, -1066065585, 2030332712, 588499143, -167137514, 972472662, -1052920479, -1081278735, 1158375832, 242640140, -640370827, 1643790248, 336975427, 280593399};
        }

        public AnonymousClass2(long j2, boolean z) {
            this.a = j2;
            this.b = z;
        }

        public static void b() {
            i = new byte[]{104, -2, 24, ISO7816.INS_READ_RECORD_STAMPED, -18, 5, -19, -2, 1, 0, 49, ISO7816.INS_READ_RECORD2, 8, -1, -23, ISO7816.INS_REHABILITATE_CHV, -34, -31, -25, 47, ISO7816.INS_GET_DATA, PassportService.SFI_DG12, -14, -11, -6, -8, 0, 7, -16, -2, -22, 16, 19, -29, -20, 14, 9, ISO7816.INS_PUT_DATA, 14, -24, 10, -18, 5, -19, -2, 1, 0, 49, ISO7816.INS_READ_BINARY_STAMPED, -4, 6, -8, 57, -43, ISO7816.INS_UPDATE_BINARY, 4, 6, -4, 9, -16, -16, -14, PassportService.SFI_DG11, -17, -3, -8, -1, 2, -24, 31, ISO7816.INS_CREATE_FILE, ISO7816.INS_CHANGE_CHV, -43, -8, 9, -24, -18, 5, -19, -2, 1, 0, 49, -78, 9, 0, -8, -3, -20, 65, ISO7816.INS_DELETE_FILE, -56, 3, 10, -18, 5, -2, -6, -15, 2, 20, -34, -15, -6, 25, -24, -1, -23, -3, -20, 31, -22, -7, -13, 1, -4, PassportService.SFI_DG15, ISO7816.INS_UPDATE_RECORD, -9, 5, -16, 6, -11, -4, 21, ISO7816.INS_UPDATE_BINARY, 4, 6, -18, 5, -19, -2, 1, 0, 49, ISO7816.INS_READ_RECORD2, 8, -1, -23, ISO7816.INS_REHABILITATE_CHV, -45, -24, -1, -23, 78, ISO7816.INS_WRITE_RECORD, -29, -1, -23, -7, -2, 8, PassportService.SFI_DG13, -34, 6, -3, -3, -20, 28, -27, -22, 16, -18, 5, -19, -2, 1, 0, 49, -75, 10, -24, -1, 65, -43, -22, -24, -1, 26, ISO7816.INS_UPDATE_RECORD, 6, -8, -12, 6, -23, -6, 38, ISO7816.INS_UPDATE_BINARY, 5, -6, -24, ISO7816.INS_CHANGE_CHV, ISO7816.INS_DELETE_FILE, 4, -26, 16, 46, -67, 6, -18, 2, ISO7816.INS_DECREASE_STAMPED, -26, ISO7816.INS_UPDATE_BINARY, 2, -22, 26, -23, -17, -9, PassportService.SFI_DG11, -14, 6, -7, -10, 5, -6, -24, ISO7816.INS_CHANGE_CHV, ISO7816.INS_DELETE_FILE, 4, -26, 16, 46, -67, 6, -18, 2, ISO7816.INS_DECREASE_STAMPED, ISO7816.INS_UPDATE_BINARY, ISO7816.INS_PUT_DATA, -3, 4, -10, 2, -2, -1, -2, -16, 4, -26, 16, 46, -67, 6, -18, 2, ISO7816.INS_DECREASE_STAMPED, ISO7816.INS_CREATE_FILE, ISO7816.INS_UPDATE_BINARY, -11, 10, -7, -3, -18, 16, -16, -14, PassportService.SFI_DG11, 17, ISO7816.INS_DELETE_FILE, -10, -11, 25, -16, -16, -14, PassportService.SFI_DG11, 4, -26, 16, 46, -67, 6, -18, 2, ISO7816.INS_DECREASE_STAMPED, -43, -25, -15, -2, -13, 17, -6, -15, 2, -3, -20, ISO7816.INS_UNBLOCK_CHV, -35, -25, -3, 9, -18, 5, -19, -2, 1, 0, 49, -70, -9, 64, ISO7816.INS_UPDATE_BINARY, -43, 1, -6, 10, -13, 37, ISO7816.INS_WRITE_RECORD, -8, 7, -13, -12, 6, -20, -8, 9, -4, PassportService.SFI_DG13, -24, -1, -16, -13, 6, -9, 3, 18, -24, -18, -6, -9, 4, -26, 16, 46, -67, 6, -18, 2, ISO7816.INS_DECREASE_STAMPED, -73, 8, -6, -11, 2, -3, -22, 65, ISO7816.INS_UPDATE_RECORD, -29, -20, 7, -12, 6, -10, -13, 2, -1, 1, 4, -26, 16, 46, -67, 6, -18, 2, ISO7816.INS_DECREASE_STAMPED, ISO7816.INS_PUT_DATA, -24, -13, 0, -3, -22, 10, -35, 4, -26, 16, 46, -67, 6, -18, 2, ISO7816.INS_DECREASE_STAMPED, ISO7816.INS_PUT_DATA, -24, -13, 0, -3, -22, ISO7816.INS_DECREASE_STAMPED, 4, -26, 16, 46, -67, 6, -18, 2, ISO7816.INS_DECREASE_STAMPED, -35, ISO7816.INS_LOAD_KEY_FILE, -4, 2, -8, -4, 2, PassportService.SFI_DG12, -16, -16, -14, PassportService.SFI_DG11, 0, 23, ISO7816.INS_PUT_DATA, -3, 4, -10, 2};
            j = 30;
        }

        /* JADX INFO: Access modifiers changed from: private */
        public /* synthetic */ void d(boolean z) throws Throwable {
            bv.this.j(z);
        }

        /* JADX WARN: Removed duplicated region for block: B:10:0x0022  */
        /* JADX WARN: Removed duplicated region for block: B:8:0x001a  */
        /* JADX WARN: Unsupported multi-entry loop pattern (BACK_EDGE: B:10:0x0022 -> B:11:0x002c). Please report as a decompilation issue!!! */
        /*
            Code decompiled incorrectly, please refer to instructions dump.
            To view partially-correct code enable 'Show inconsistent code' option in preferences
        */
        private static void g(short r6, short r7, short r8, java.lang.Object[] r9) {
            /*
                int r7 = r7 + 4
                int r0 = r8 + 5
                int r6 = 118 - r6
                byte[] r1 = com.facetec.sdk.bv.AnonymousClass2.i
                byte[] r0 = new byte[r0]
                int r8 = r8 + 4
                r2 = 0
                if (r1 != 0) goto L14
                r3 = r1
                r4 = r2
                r1 = r7
                r7 = r8
                goto L2c
            L14:
                r3 = r2
            L15:
                byte r4 = (byte) r6
                r0[r3] = r4
                if (r3 != r8) goto L22
                java.lang.String r6 = new java.lang.String
                r6.<init>(r0, r2)
                r9[r2] = r6
                return
            L22:
                int r3 = r3 + 1
                r4 = r1[r7]
                r5 = r7
                r7 = r6
                r6 = r4
                r4 = r3
                r3 = r1
                r1 = r5
            L2c:
                int r6 = -r6
                int r7 = r7 + r6
                int r6 = r7 + (-5)
                int r7 = r1 + 1
                r1 = r3
                r3 = r4
                goto L15
            */
            throw new UnsupportedOperationException("Method not decompiled: com.facetec.sdk.bv.AnonymousClass2.g(short, short, short, java.lang.Object[]):void");
        }

        public static void init$0() {
            $$a = new byte[]{ISO7816.INS_DECREASE_STAMPED, -107, 59, -11};
            $$b = EnumC41897g.SDK_ASSET_ILLUSTRATION_DEV_RAISE_INSTITUTION_CENTERED_VALUE;
        }

        /* JADX WARN: Removed duplicated region for block: B:39:0x015b  */
        /* JADX WARN: Removed duplicated region for block: B:40:0x015c  */
        /*
            Code decompiled incorrectly, please refer to instructions dump.
            To view partially-correct code enable 'Show inconsistent code' option in preferences
        */
        private static void k(java.lang.String r26, int r27, boolean r28, int r29, int r30, java.lang.Object[] r31) throws java.lang.Throwable {
            /*
                Method dump skipped, instruction units count: 360
                To view this dump change 'Code comments level' option to 'DEBUG'
            */
            throw new UnsupportedOperationException("Method not decompiled: com.facetec.sdk.bv.AnonymousClass2.k(java.lang.String, int, boolean, int, int, java.lang.Object[]):void");
        }

        private static void l(int[] iArr, int i2, Object[] objArr) throws Throwable {
            char[] cArr;
            int i3;
            int i4;
            int i5;
            int i6;
            hg hgVar = new hg();
            char[] cArr2 = new char[4];
            int i7 = 2;
            char[] cArr3 = new char[iArr.length * 2];
            int[] iArr2 = e;
            int i8 = 2027942060;
            Class cls = Integer.TYPE;
            int i9 = 16;
            int i10 = 0;
            if (iArr2 != null) {
                int length = iArr2.length;
                int[] iArr3 = new int[length];
                int i11 = 0;
                while (i11 < length) {
                    try {
                        Object[] objArr2 = {Integer.valueOf(iArr2[i11])};
                        Object objD = an.d(i8);
                        if (objD == null) {
                            i4 = i8;
                            i3 = i7;
                            byte b = (byte) i10;
                            i5 = i9;
                            byte b2 = b;
                            i6 = i10;
                            objD = an.d(617 - (ViewConfiguration.getMaximumFlingVelocity() >> 16), (char) (ViewConfiguration.getTouchSlop() >> 8), 23 - View.resolveSizeAndState(i10, i10, i10), 247342071, false, $$c(b, b2, b2), new Class[]{cls});
                        } else {
                            i3 = i7;
                            i4 = i8;
                            i5 = i9;
                            i6 = i10;
                        }
                        iArr3[i11] = ((Integer) ((Method) objD).invoke(null, objArr2)).intValue();
                        i11++;
                        i8 = i4;
                        i7 = i3;
                        i9 = i5;
                        i10 = i6;
                    } catch (Throwable th) {
                        Throwable cause = th.getCause();
                        if (cause == null) {
                            throw th;
                        }
                        throw cause;
                    }
                }
                iArr2 = iArr3;
            }
            int i12 = i7;
            int i13 = i8;
            int i14 = i9;
            int i15 = i10;
            int length2 = iArr2.length;
            int[] iArr4 = new int[length2];
            int[] iArr5 = e;
            if (iArr5 != null) {
                int length3 = iArr5.length;
                int[] iArr6 = new int[length3];
                int i16 = i15;
                while (i16 < length3) {
                    Object[] objArr3 = {Integer.valueOf(iArr5[i16])};
                    Object objD2 = an.d(i13);
                    if (objD2 == null) {
                        byte b3 = (byte) i15;
                        byte b4 = b3;
                        cArr = cArr2;
                        objD2 = an.d(617 - ExpandableListView.getPackedPositionGroup(0L), (char) ((-1) - TextUtils.lastIndexOf("", '0')), ImageFormat.getBitsPerPixel(i15) + 24, 247342071, false, $$c(b3, b4, b4), new Class[]{cls});
                    } else {
                        cArr = cArr2;
                    }
                    iArr6[i16] = ((Integer) ((Method) objD2).invoke(null, objArr3)).intValue();
                    i16++;
                    cArr2 = cArr;
                    i15 = 0;
                }
                iArr5 = iArr6;
            }
            char[] cArr4 = cArr2;
            char c2 = 0;
            System.arraycopy(iArr5, 0, iArr4, 0, length2);
            hgVar.c = 0;
            while (true) {
                int i17 = hgVar.c;
                if (i17 >= iArr.length) {
                    objArr[0] = new String(cArr3, 0, i2);
                    return;
                }
                int i18 = iArr[i17];
                char c3 = (char) (i18 >> 16);
                cArr4[c2] = c3;
                char c4 = (char) i18;
                cArr4[1] = c4;
                char c5 = (char) (iArr[i17 + 1] >> 16);
                cArr4[i12] = c5;
                char c6 = (char) iArr[i17 + 1];
                cArr4[3] = c6;
                hgVar.d = (c3 << 16) + c4;
                hgVar.a = (c5 << 16) + c6;
                hg.a(iArr4);
                int i19 = 0;
                while (i19 < i14) {
                    int i20 = hgVar.d ^ iArr4[i19];
                    hgVar.d = i20;
                    int iB = hg.b(i20);
                    Object[] objArr4 = new Object[4];
                    objArr4[3] = hgVar;
                    objArr4[i12] = hgVar;
                    objArr4[1] = Integer.valueOf(iB);
                    objArr4[0] = hgVar;
                    Object objD3 = an.d(-1264699187);
                    if (objD3 == null) {
                        byte b5 = (byte) 0;
                        byte b6 = b5;
                        objD3 = an.d(Color.red(0) + 1558, (char) (63317 - View.resolveSizeAndState(0, 0, 0)), 33 - (SystemClock.currentThreadTimeMillis() > (-1L) ? 1 : (SystemClock.currentThreadTimeMillis() == (-1L) ? 0 : -1)), -1023415402, false, $$c(b5, b6, (byte) (b6 + 2)), new Class[]{Object.class, cls, Object.class, Object.class});
                    }
                    int iIntValue = ((Integer) ((Method) objD3).invoke(null, objArr4)).intValue();
                    hgVar.d = hgVar.a;
                    hgVar.a = iIntValue;
                    i19++;
                    i14 = 16;
                }
                int i21 = hgVar.d;
                int i22 = hgVar.a;
                hgVar.d = i22;
                hgVar.a = i21;
                int i23 = i21 ^ iArr4[16];
                hgVar.a = i23;
                int i24 = i22 ^ iArr4[17];
                hgVar.d = i24;
                cArr4[0] = (char) (i24 >>> 16);
                cArr4[1] = (char) i24;
                cArr4[i12] = (char) (i23 >>> 16);
                cArr4[3] = (char) i23;
                hg.a(iArr4);
                int i25 = hgVar.c;
                cArr3[i25 * 2] = cArr4[0];
                cArr3[(i25 * 2) + 1] = cArr4[1];
                cArr3[(i25 * 2) + 2] = cArr4[i12];
                cArr3[(i25 * 2) + 3] = cArr4[3];
                int i26 = i12;
                Object[] objArr5 = new Object[i26];
                objArr5[1] = hgVar;
                objArr5[0] = hgVar;
                Object objD4 = an.d(-204410541);
                if (objD4 == null) {
                    i14 = 16;
                    objD4 = an.d((ViewConfiguration.getTapTimeout() >> 16) + EnumC41897g.SDK_ASSET_PLAID_LOGO_LOADING_INDICATOR_SUCCESS_VALUE, (char) (ViewConfiguration.getKeyRepeatTimeout() >> 16), (ViewConfiguration.getMaximumFlingVelocity() >> 16) + 23, -2051988984, false, "A", new Class[]{Object.class, Object.class});
                } else {
                    i14 = 16;
                }
                ((Method) objD4).invoke(null, objArr5);
                i12 = i26;
                c2 = 0;
            }
        }

        /* JADX WARN: Multi-variable type inference failed */
        /* JADX WARN: Removed duplicated region for block: B:230:0x09a4  */
        /* JADX WARN: Removed duplicated region for block: B:233:0x09ab  */
        @Override // android.hardware.Camera.PictureCallback
        /*
            Code decompiled incorrectly, please refer to instructions dump.
            To view partially-correct code enable 'Show inconsistent code' option in preferences
        */
        public final void onPictureTaken(byte[] r44, android.hardware.Camera r45) throws java.lang.Throwable {
            /*
                Method dump skipped, instruction units count: 2644
                To view this dump change 'Code comments level' option to 'DEBUG'
            */
            throw new UnsupportedOperationException("Method not decompiled: com.facetec.sdk.bv.AnonymousClass2.onPictureTaken(byte[], android.hardware.Camera):void");
        }

        public static void d() {
            h = 1605274593;
        }
    }

    /* JADX INFO: renamed from: com.facetec.sdk.bv$4, reason: invalid class name */
    public static /* synthetic */ class AnonymousClass4 {
        static final /* synthetic */ int[] a;
        static final /* synthetic */ int[] b;
        static final /* synthetic */ int[] c;

        static {
            int[] iArr = new int[co.values().length];
            b = iArr;
            try {
                iArr[co.KEEP_SCANNING.ordinal()] = 1;
            } catch (NoSuchFieldError unused) {
            }
            try {
                b[co.END_SCAN.ordinal()] = 2;
            } catch (NoSuchFieldError unused2) {
            }
            try {
                b[co.PRESENT_MANUAL_CAPTURE_BUTTON.ordinal()] = 3;
            } catch (NoSuchFieldError unused3) {
            }
            int[] iArr2 = new int[cn.values().length];
            a = iArr2;
            try {
                iArr2[cn.ID_IMAGE_HOLD_STEADY.ordinal()] = 1;
            } catch (NoSuchFieldError unused4) {
            }
            try {
                a[cn.ID_IMAGE_FACE_NOT_FOUND.ordinal()] = 2;
            } catch (NoSuchFieldError unused5) {
            }
            try {
                a[cn.ID_IMAGE_BLURRY.ordinal()] = 3;
            } catch (NoSuchFieldError unused6) {
            }
            int[] iArr3 = new int[FaceTecCancelButtonCustomization.ButtonLocation.values().length];
            c = iArr3;
            try {
                iArr3[FaceTecCancelButtonCustomization.ButtonLocation.TOP_LEFT.ordinal()] = 1;
            } catch (NoSuchFieldError unused7) {
            }
            try {
                c[FaceTecCancelButtonCustomization.ButtonLocation.TOP_RIGHT.ordinal()] = 2;
            } catch (NoSuchFieldError unused8) {
            }
            try {
                c[FaceTecCancelButtonCustomization.ButtonLocation.CUSTOM.ordinal()] = 3;
            } catch (NoSuchFieldError unused9) {
            }
            try {
                c[FaceTecCancelButtonCustomization.ButtonLocation.DISABLED.ordinal()] = 4;
            } catch (NoSuchFieldError unused10) {
            }
        }
    }

    public enum b {
        FRONT,
        BACK
    }

    private static String $$c(int i, byte b2, int i2) {
        int i3 = b2 + 97;
        int i4 = (i2 * 4) + 4;
        int i5 = i * 4;
        byte[] bArr = $$a;
        byte[] bArr2 = new byte[1 - i5];
        int i6 = 0 - i5;
        int i7 = -1;
        if (bArr == null) {
            i4++;
            i3 += i6;
        }
        while (true) {
            i7++;
            bArr2[i7] = (byte) i3;
            if (i7 == i6) {
                return new String(bArr2, 0);
            }
            byte b3 = bArr[i4];
            i4++;
            i3 += b3;
        }
    }

    static {
        init$0();
        n();
        j();
        ag = 0;
        ah = 1;
        ae = 2533669055587431456L;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void B() {
        this.I.setImageResource(dm.aI());
        this.q.setVisibility(0);
        this.y.setVisibility(0);
        int iIntValue = ((Integer) dm.e(pg.a.a(), pg.a.a(), 1933108801, new Object[0], pg.a.a(), -1933108792, pg.a.a())).intValue();
        RelativeLayout.LayoutParams layoutParams = (RelativeLayout.LayoutParams) this.A.getLayoutParams();
        float f = iIntValue;
        ((ViewGroup.MarginLayoutParams) layoutParams).topMargin = (int) ((this.s.d().top - this.A.getHeight()) - f);
        this.A.setLayoutParams(layoutParams);
        RelativeLayout.LayoutParams layoutParams2 = (RelativeLayout.LayoutParams) this.G.getLayoutParams();
        ((ViewGroup.MarginLayoutParams) layoutParams2).topMargin = (int) (this.s.d().bottom + f);
        this.G.setLayoutParams(layoutParams2);
        RelativeLayout.LayoutParams layoutParams3 = (RelativeLayout.LayoutParams) this.F.getLayoutParams();
        ((ViewGroup.LayoutParams) layoutParams3).height = (int) (((double) this.F.getWidth()) / 1.59d);
        this.F.setLayoutParams(layoutParams3);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void C() {
        ap apVar = this.U;
        if (apVar == null) {
            return;
        }
        apVar.d(new Runnable() { // from class: com.facetec.sdk.人书
            @Override // java.lang.Runnable
            public final void run() {
                this.f6941.H();
            }
        });
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void D() throws Throwable {
        bi biVar = this.l;
        t.d(getActivity(), this.U.m, false, this.f95839g, biVar.f95830g ? biVar.D : cp.c);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void E() {
        this.e.b(true, true);
        this.I.setEnabled(true);
        this.a.setEnabled(true);
        this.k = true;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void F() throws Throwable {
        this.X.setVisibility(8);
        getFragmentManager().beginTransaction().remove(this.Z).commitAllowingStateLoss();
        this.Z = null;
        l();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void G() throws Throwable {
        e(false);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void H() {
        RelativeLayout relativeLayout = this.w;
        if (relativeLayout == null) {
            return;
        }
        relativeLayout.animate().alpha(SelfieScan.RECOGNITION_FAIL_RESULT).setDuration(500L).setInterpolator(new DecelerateInterpolator()).setListener(null).start();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void K() throws Throwable {
        bi biVar = this.l;
        if (biVar != null) {
            biVar.x();
        }
        if (!this.ac) {
            l();
            return;
        }
        boolean z = this.W;
        dk dkVar = new dk();
        this.Z = dkVar;
        dkVar.e = (dk.a) getActivity();
        getChildFragmentManager().beginTransaction().replace(R.id.securingCameraFragmentContainer, this.Z).addToBackStack(null).commitAllowingStateLoss();
        final int i = 0;
        this.X.setVisibility(0);
        int i2 = HttpStatusCodeRange.DEFAULT_MIN;
        if (!z) {
            i = 500;
            i2 = 1;
        }
        this.X.animate().alpha(1.0f).setDuration(i2).setStartDelay(0L).setListener(null).withEndAction(new au.c(new Runnable() { // from class: com.facetec.sdk.书药
            @Override // java.lang.Runnable
            public final void run() {
                this.f6926.b(i);
            }
        }));
    }

    /* JADX WARN: Removed duplicated region for block: B:10:0x0022  */
    /* JADX WARN: Removed duplicated region for block: B:8:0x001a  */
    /* JADX WARN: Unsupported multi-entry loop pattern (BACK_EDGE: B:10:0x0022 -> B:11:0x0026). Please report as a decompilation issue!!! */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    private static void aj(byte r5, int r6, short r7, java.lang.Object[] r8) {
        /*
            byte[] r0 = com.facetec.sdk.bv.al
            int r7 = r7 + 91
            int r6 = r6 + 4
            int r1 = 30 - r5
            byte[] r1 = new byte[r1]
            int r5 = 29 - r5
            r2 = 0
            if (r0 != 0) goto L12
            r4 = r5
            r3 = r2
            goto L26
        L12:
            r3 = r2
        L13:
            byte r4 = (byte) r7
            r1[r3] = r4
            int r6 = r6 + 1
            if (r3 != r5) goto L22
            java.lang.String r5 = new java.lang.String
            r5.<init>(r1, r2)
            r8[r2] = r5
            return
        L22:
            int r3 = r3 + 1
            r4 = r0[r6]
        L26:
            int r7 = r7 + r4
            goto L13
        */
        throw new UnsupportedOperationException("Method not decompiled: com.facetec.sdk.bv.aj(byte, int, short, java.lang.Object[]):void");
    }

    private static void am(String str, String str2, char c, int i, String str3, Object[] objArr) throws Throwable {
        int i2;
        int i3;
        char c2;
        char[] charArray = str3 != null ? str3.toCharArray() : str3;
        char[] charArray2 = str2 != null ? str2.toCharArray() : str2;
        char[] charArray3 = str != null ? str.toCharArray() : str;
        hi hiVar = new hi();
        int length = charArray2.length;
        char[] cArr = new char[length];
        int length2 = charArray3.length;
        char[] cArr2 = new char[length2];
        int i4 = 0;
        System.arraycopy(charArray2, 0, cArr, 0, length);
        System.arraycopy(charArray3, 0, cArr2, 0, length2);
        cArr[0] = (char) (cArr[0] ^ c);
        int i5 = 2;
        cArr2[2] = (char) (cArr2[2] + ((char) i));
        int length3 = charArray.length;
        char[] cArr3 = new char[length3];
        hiVar.d = 0;
        while (hiVar.d < length3) {
            try {
                Object[] objArr2 = {hiVar};
                Object objD = an.d(1217746441);
                if (objD == null) {
                    objD = an.d(214 - ((byte) KeyEvent.getModifierMetaStateMask()), (char) (63338 - Color.argb(i4, i4, i4, i4)), 16777240 + Color.rgb(i4, i4, i4), 1056212306, false, "b", new Class[]{Object.class});
                }
                int iIntValue = ((Integer) ((Method) objD).invoke(null, objArr2)).intValue();
                Object[] objArr3 = {hiVar};
                Object objD2 = an.d(1379992360);
                if (objD2 == null) {
                    byte b2 = (byte) i4;
                    i2 = i5;
                    byte b3 = b2;
                    i3 = i4;
                    objD2 = an.d(TextUtils.indexOf((CharSequence) "", '0', i4) + 689, (char) (33107 - (ViewConfiguration.getJumpTapTimeout() >> 16)), 22 - Process.getGidForName(""), 606130291, false, $$c(b2, b3, b3), new Class[]{Object.class});
                } else {
                    i2 = i5;
                    i3 = i4;
                }
                int iIntValue2 = ((Integer) ((Method) objD2).invoke(null, objArr3)).intValue();
                int i6 = cArr[hiVar.d % 4] * 32718;
                Object[] objArr4 = new Object[3];
                objArr4[i2] = Integer.valueOf(cArr2[iIntValue]);
                objArr4[1] = Integer.valueOf(i6);
                objArr4[i3] = hiVar;
                Object objD3 = an.d(-1522168148);
                Class cls = Integer.TYPE;
                if (objD3 == null) {
                    c2 = 1;
                    byte b4 = (byte) i3;
                    objD3 = an.d((ViewConfiguration.getJumpTapTimeout() >> 16) + 1304, (char) (1 - (ViewConfiguration.getGlobalActionKeyTimeout() > 0L ? 1 : (ViewConfiguration.getGlobalActionKeyTimeout() == 0L ? 0 : -1))), 24 - (ViewConfiguration.getWindowTouchSlop() >> 8), -752591369, false, $$c(b4, (byte) (b4 | 7), b4), new Class[]{Object.class, cls, cls});
                } else {
                    c2 = 1;
                }
                ((Method) objD3).invoke(null, objArr4);
                int i7 = cArr[iIntValue2] * 32718;
                int i8 = i2;
                Object[] objArr5 = new Object[i8];
                objArr5[c2] = Integer.valueOf(cArr2[iIntValue]);
                objArr5[0] = Integer.valueOf(i7);
                Object objD4 = an.d(-1578548222);
                if (objD4 == null) {
                    objD4 = an.d(1970 - TextUtils.getOffsetBefore("", 0), (char) KeyEvent.keyCodeFromString(""), 24 - (TypedValue.complexToFloat(0) > SelfieScan.RECOGNITION_FAIL_RESULT ? 1 : (TypedValue.complexToFloat(0) == SelfieScan.RECOGNITION_FAIL_RESULT ? 0 : -1)), -678914215, false, "i", new Class[]{cls, cls});
                }
                cArr2[iIntValue2] = ((Character) ((Method) objD4).invoke(null, objArr5)).charValue();
                cArr[iIntValue2] = hiVar.e;
                int i9 = hiVar.d;
                cArr3[i9] = (char) (((((long) (r6 ^ charArray[i9])) ^ (ad ^ 1396024866991524551L)) ^ ((long) ((int) (((long) af) ^ 1396024866991524551L)))) ^ ((long) ((char) (((long) f95838ai) ^ 1396024866991524551L))));
                hiVar.d = i9 + 1;
                i5 = i8;
                i4 = 0;
            } catch (Throwable th) {
                Throwable cause = th.getCause();
                if (cause == null) {
                    throw th;
                }
                throw cause;
            }
        }
        objArr[0] = new String(cArr3);
    }

    /* JADX WARN: Removed duplicated region for block: B:33:0x012f  */
    /* JADX WARN: Removed duplicated region for block: B:34:0x0130  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    private static void an(java.lang.String r21, int r22, java.lang.Object[] r23) throws java.lang.Throwable {
        /*
            Method dump skipped, instruction units count: 313
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: com.facetec.sdk.bv.an(java.lang.String, int, java.lang.Object[]):void");
    }

    /* JADX WARN: Removed duplicated region for block: B:144:0x0652  */
    /* JADX WARN: Removed duplicated region for block: B:195:0x0662 A[ADDED_TO_REGION, REMOVE, SYNTHETIC] */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    private void i(boolean r38) throws java.lang.Throwable {
        /*
            Method dump skipped, instruction units count: 1706
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: com.facetec.sdk.bv.i(boolean):void");
    }

    public static void init$0() {
        $$a = new byte[]{120, ISO7816.INS_ENVELOPE, 63, 57};
        $$b = 113;
    }

    /* JADX INFO: Access modifiers changed from: private */
    /* JADX INFO: renamed from: k, reason: merged with bridge method [inline-methods] and merged with bridge method [inline-methods] */
    public void N() throws Throwable {
        ap apVar = this.U;
        if (apVar != null) {
            apVar.c(false, (ViewGroup) this.E);
        }
    }

    private void l() throws Throwable {
        final boolean z = this.l.B == FaceTecIDScanNextStep.SELECTION_SCREEN && this.f95839g != b.BACK && this.i == null;
        if (getActivity() != null) {
            getActivity().runOnUiThread(new Runnable() { // from class: com.facetec.sdk.人城
                @Override // java.lang.Runnable
                public final void run() {
                    this.f6954.l(z);
                }
            });
        }
        t.b(dh.ID_SCAN_START);
    }

    private void m() {
        if (getActivity() == null) {
            return;
        }
        getActivity().runOnUiThread(new Runnable() { // from class: com.facetec.sdk.书鬼
            @Override // java.lang.Runnable
            public final void run() {
                this.f6932.B();
            }
        });
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void n(boolean z) throws Throwable {
        if (this.i == ca.BACK) {
            this.f95839g = b.BACK;
            dp.e(this.y, R.string.FaceTec_idscan_capture_id_back_instruction_message);
        } else {
            this.f95839g = b.FRONT;
            dp.e(this.y, R.string.FaceTec_idscan_capture_id_front_instruction_message);
        }
        this.w.setAlpha(1.0f);
        this.L.setVisibility(8);
        this.t.setVisibility(4);
        this.q.setVisibility(0);
        d(false);
        ap apVar = this.U;
        if (apVar == null) {
            e(3);
            return;
        }
        apVar.d();
        p();
        cv.o(z, false);
        this.V.postDelayed(new Runnable() { // from class: com.facetec.sdk.人字
            @Override // java.lang.Runnable
            public final void run() {
                this.f6958.E();
            }
        }, 800L);
        m();
        o();
        this.P.animate().alpha(SelfieScan.RECOGNITION_FAIL_RESULT).setDuration(500L).setStartDelay(0L).setInterpolator(new DecelerateInterpolator()).setListener(null).withEndAction(new Runnable() { // from class: com.facetec.sdk.人宫
            @Override // java.lang.Runnable
            public final void run() {
                this.f6959.C();
            }
        }).start();
    }

    private void o() {
        this.e.c(new Runnable() { // from class: com.facetec.sdk.人兵
            @Override // java.lang.Runnable
            public final void run() throws Throwable {
                this.f6944.G();
            }
        });
        this.c.c(new Runnable() { // from class: com.facetec.sdk.人凤
            @Override // java.lang.Runnable
            public final void run() throws Throwable {
                this.f6945.g();
            }
        });
        this.f.c(new Runnable() { // from class: com.facetec.sdk.人剑
            @Override // java.lang.Runnable
            public final void run() {
                this.f6946.t();
            }
        });
        this.j.c(new Runnable() { // from class: com.facetec.sdk.人古
            @Override // java.lang.Runnable
            public final void run() {
                this.f6947.r();
            }
        });
        this.I.setOnClickListener(new View.OnClickListener() { // from class: com.facetec.sdk.人史
            @Override // android.view.View.OnClickListener
            public final void onClick(View view) throws Throwable {
                this.f6948.e(view);
            }
        });
    }

    private void p() {
        s();
        this.ab = new dl(new Runnable() { // from class: com.facetec.sdk.人帝
            @Override // java.lang.Runnable
            public final void run() throws Throwable {
                this.f6962.A();
            }
        });
        Timer timer = new Timer();
        this.T = timer;
        timer.scheduleAtFixedRate(this.ab, 6000L, 6000L);
    }

    private void q() {
        d(true);
        if (getActivity() == null) {
            return;
        }
        getActivity().runOnUiThread(new Runnable() { // from class: com.facetec.sdk.书风
            @Override // java.lang.Runnable
            public final void run() {
                this.f6931.y();
            }
        });
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void r() {
        cp cpVar = this.l.e;
        if (cpVar == null) {
            return;
        }
        this.j.b(false, true);
        dp.e(this.y, R.string.FaceTec_idscan_capture_id_front_instruction_message);
        m();
        p();
        this.k = true;
        boolean zA = eg.a(this.l);
        bm bmVar = (bm) getActivity();
        try {
            cpVar.d(bmVar, zA, ((bi) getActivity()).j);
            getActivity().runOnUiThread(new Runnable() { // from class: com.facetec.sdk.人地
                @Override // java.lang.Runnable
                public final void run() {
                    this.f6953.x();
                }
            });
        } catch (NullPointerException unused) {
            t.d(bmVar, c.PHOENIX_HANDLER_UNEXPECTED_NULL, "phoenixHandler is null unexpectedly. Check Activity State Info to see if session has finished", null);
        }
    }

    private void s() {
        Timer timer = this.T;
        if (timer != null) {
            timer.cancel();
            this.T = null;
        }
        TimerTask timerTask = this.ab;
        if (timerTask != null) {
            timerTask.cancel();
            this.ab = null;
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void t() {
        if (this.U == null) {
            e(8);
            return;
        }
        this.f.b(false, true);
        this.c.b(false, true);
        this.a.setEnabled(false);
        this.S = false;
        this.I.setImageResource(dm.aI());
        this.I.setEnabled(false);
        this.c.b(false, true);
        this.f.b(false, true);
        this.e.b(false, true);
        if (getActivity() != null) {
            getActivity().runOnUiThread(new Runnable() { // from class: com.facetec.sdk.人丹
                @Override // java.lang.Runnable
                public final void run() {
                    this.f6939.w();
                }
            });
        }
        this.s.a(new Runnable() { // from class: com.facetec.sdk.人国
            @Override // java.lang.Runnable
            public final void run() {
                this.f6951.z();
            }
        });
        dj.d(new Runnable() { // from class: com.facetec.sdk.人天
            @Override // java.lang.Runnable
            public final void run() throws Throwable {
                this.f6956.D();
            }
        });
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void u() {
        this.t.setVisibility(8);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void v() {
        this.e.setAlpha(SelfieScan.RECOGNITION_FAIL_RESULT);
        this.e.setVisibility(0);
        this.e.animate().alpha(1.0f).setDuration(200L).setListener(null).start();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void w() {
        float fA = bh.a(20) * dm.b() * dm.c();
        AnimatorSet animatorSet = new AnimatorSet();
        RelativeLayout relativeLayout = this.K;
        Property property = View.TRANSLATION_Y;
        animatorSet.playTogether(ObjectAnimator.ofFloat(relativeLayout, (Property<RelativeLayout, Float>) property, fA), ObjectAnimator.ofFloat(this.A, (Property<RelativeLayout, Float>) property, -fA));
        animatorSet.setDuration(500L);
        animatorSet.start();
        AnimatorSet animatorSet2 = new AnimatorSet();
        RelativeLayout relativeLayout2 = this.K;
        Property property2 = View.ALPHA;
        animatorSet2.playTogether(ObjectAnimator.ofFloat(relativeLayout2, (Property<RelativeLayout, Float>) property2, SelfieScan.RECOGNITION_FAIL_RESULT), ObjectAnimator.ofFloat(this.A, (Property<RelativeLayout, Float>) property2, SelfieScan.RECOGNITION_FAIL_RESULT), ObjectAnimator.ofFloat(this.d, (Property<TextView, Float>) property2, SelfieScan.RECOGNITION_FAIL_RESULT), ObjectAnimator.ofFloat(this.I, (Property<ImageView, Float>) property2, SelfieScan.RECOGNITION_FAIL_RESULT), ObjectAnimator.ofFloat(this.a, (Property<ImageView, Float>) property2, SelfieScan.RECOGNITION_FAIL_RESULT), ObjectAnimator.ofFloat(this.M, (Property<ImageView, Float>) property2, SelfieScan.RECOGNITION_FAIL_RESULT), ObjectAnimator.ofFloat(this.P, (Property<RelativeLayout, Float>) property2, SelfieScan.RECOGNITION_FAIL_RESULT));
        animatorSet2.setDuration(500L);
        animatorSet2.start();
        ImageView imageView = this.l.w;
        if (imageView != null) {
            imageView.animate().alpha(SelfieScan.RECOGNITION_FAIL_RESULT).setDuration(500L).start();
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void x() {
        this.t.animate().alpha(SelfieScan.RECOGNITION_FAIL_RESULT).setDuration(500L).setListener(null).withEndAction(new Runnable() { // from class: com.facetec.sdk.人土
            @Override // java.lang.Runnable
            public final void run() {
                this.f6952.u();
            }
        }).start();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void y() {
        this.f.b(true, true);
        this.c.b(true, true);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void z() {
        this.l.u();
    }

    @Override // android.app.Fragment
    public final void onAttach(Activity activity) {
        super.onAttach(activity);
        this.l = (bi) activity;
    }

    @Override // com.facetec.sdk.au, android.app.Fragment
    public final void onCreate(Bundle bundle) {
        super.onCreate(bundle);
    }

    @Override // android.app.Fragment
    public final View onCreateView(LayoutInflater layoutInflater, ViewGroup viewGroup, Bundle bundle) {
        return layoutInflater.inflate(R.layout.facetec_idscan_fragment, viewGroup, false);
    }

    @Override // android.app.Fragment
    public final void onDestroy() throws Throwable {
        super.onDestroy();
        h();
        s();
        i();
    }

    @Override // android.app.Fragment
    public final void onViewCreated(View view, Bundle bundle) throws Throwable {
        int iRound;
        boolean z;
        int iRound2;
        super.onViewCreated(view, bundle);
        this.V = new Handler();
        this.t = (RelativeLayout) view.findViewById(R.id.idTypeLayout);
        this.r = (RelativeLayout) view.findViewById(R.id.cameraLayout);
        this.s = (bt) view.findViewById(R.id.idCaptureFrameView);
        this.v = (TextView) view.findViewById(R.id.reviewInstructionsText);
        this.y = (TextView) view.findViewById(R.id.captureInstructionsText);
        this.d = (TextView) view.findViewById(R.id.tapToFocusMessageText);
        this.x = (ImageView) view.findViewById(R.id.reviewImageView);
        this.e = (e) view.findViewById(R.id.takePictureButton);
        this.c = (e) view.findViewById(R.id.retakePictureButton);
        this.f = (e) view.findViewById(R.id.acceptPictureButton);
        this.B = (RelativeLayout) view.findViewById(R.id.shutterEffectContainer);
        this.C = (LinearLayout) view.findViewById(R.id.reviewButtonsContainer);
        this.I = (ImageView) view.findViewById(R.id.flashButton);
        this.b = (RelativeLayout) view.findViewById(R.id.parentLayout);
        this.E = (RelativeLayout) view.findViewById(R.id.cameraContainer);
        this.q = (RelativeLayout) view.findViewById(R.id.parentInterfaceLayout);
        this.a = (ImageView) view.findViewById(R.id.cancelButton);
        this.j = (e) view.findViewById(R.id.continueButton);
        this.u = (TextView) view.findViewById(R.id.selectionHeader);
        this.J = (LinearLayout) view.findViewById(R.id.selectionButtonLayout);
        this.K = (RelativeLayout) view.findViewById(R.id.interfaceButtonLayout);
        this.N = (RelativeLayout) view.findViewById(R.id.idTypeLayoutBackground);
        this.L = (RelativeLayout) view.findViewById(R.id.idTypeLayoutContent);
        this.w = (RelativeLayout) view.findViewById(R.id.cameraTransitionView);
        this.z = (LinearLayout) view.findViewById(R.id.selectionDocumentImageLayout);
        this.D = (ImageView) view.findViewById(R.id.selectionDocumentImage);
        this.A = (RelativeLayout) view.findViewById(R.id.instructionsContainer);
        this.H = (LinearLayout) view.findViewById(R.id.selectionMainLayout);
        this.p = (bn) view.findViewById(R.id.focusAnimationView);
        this.h = view.findViewById(R.id.reviewButtonSeparator);
        this.G = (RelativeLayout) view.findViewById(R.id.focusMessageContainer);
        this.F = (RelativeLayout) view.findViewById(R.id.croppedFrame);
        this.X = (FrameLayout) view.findViewById(R.id.securingCameraFragmentContainer);
        this.M = (ImageView) view.findViewById(R.id.mainBrandingImageView);
        this.P = (RelativeLayout) view.findViewById(R.id.mainTransitionView);
        FaceTecIDScanCustomization faceTecIDScanCustomization = FaceTecSDK.d.f;
        int i = faceTecIDScanCustomization.selectionScreenDocumentImage;
        if (i == 0) {
            i = R.drawable.facetec_document;
        }
        int i2 = faceTecIDScanCustomization.activeTorchButtonImage;
        if (i2 == 0) {
            i2 = R.drawable.facetec_active_torch;
        }
        int i3 = faceTecIDScanCustomization.inactiveTorchButtonImage;
        if (i3 == 0) {
            i3 = R.drawable.facetec_inactive_torch;
        }
        faceTecIDScanCustomization.selectionScreenDocumentImage = i;
        faceTecIDScanCustomization.activeTorchButtonImage = i2;
        faceTecIDScanCustomization.inactiveTorchButtonImage = i3;
        boolean z2 = getArguments().getBoolean("overzoomedDocument");
        this.R = getArguments().getBoolean("isStandaloneIDScan");
        dm.j(this.b);
        dm.j(this.P);
        this.u.setTypeface(FaceTecSDK.d.f.headerFont);
        this.v.setTypeface(FaceTecSDK.d.f.subtextFont);
        this.y.setTypeface(FaceTecSDK.d.f.subtextFont);
        this.d.setTypeface(FaceTecSDK.d.f.captureScreenFocusMessageFont);
        this.u.setLineSpacing(SelfieScan.RECOGNITION_FAIL_RESULT, 1.1f);
        dp.e(this.u, R.string.FaceTec_idscan_type_selection_header);
        dp.e(this.j, R.string.FaceTec_action_continue);
        float fB = dm.b() * dm.c();
        this.M.getLayoutParams().height = Math.round(bh.a(18) * fB);
        ((ViewGroup.MarginLayoutParams) ((RelativeLayout.LayoutParams) this.M.getLayoutParams())).topMargin = ((Integer) dm.e(pg.a.a(), pg.a.a(), 1933108801, new Object[0], pg.a.a(), -1933108792, pg.a.a())).intValue();
        Drawable drawable = C6852.getDrawable(this.l, dm.c(getActivity()));
        Drawable drawable2 = C6852.getDrawable(this.l, ((Integer) dm.e(pg.a.a(), pg.a.a(), 447937035, new Object[]{getActivity()}, pg.a.a(), -447936997, pg.a.a())).intValue());
        if (this.R) {
            int iArgb = Color.argb(255, EnumC41897g.SDK_ASSET_ILLUSTRATION_ATOMIC_LOGO_VALUE, EnumC41897g.SDK_ASSET_ILLUSTRATION_ATOMIC_LOGO_VALUE, EnumC41897g.SDK_ASSET_ILLUSTRATION_ATOMIC_LOGO_VALUE);
            this.M.setImageDrawable(drawable);
            this.M.setVisibility(0);
            if (!FaceTecSDK.d.a) {
                if (dm.b(this.l, new ArrayList(Arrays.asList(Integer.valueOf(dm.a(this.l)), Integer.valueOf(iArgb))))) {
                    this.M.setColorFilter(Color.argb(255, 68, 68, 68), PorterDuff.Mode.SRC_IN);
                    bb.e(String.format(Locale.getDefault(), "FaceTec SDK Customization Alert: Your ID Scan Capture Screen background color has been detected as too similar to ID Scan watermark image tint. The ID Scan watermark image tint color will be adjusted for visibility.", new Object[0]));
                } else {
                    this.M.setColorFilter(iArgb, PorterDuff.Mode.SRC_IN);
                }
            }
        } else if (FaceTecSDK.d.f.showFaceMatchToIDBrandingImage) {
            this.M.setImageDrawable(drawable2);
            this.M.setVisibility(0);
        } else {
            this.M.setVisibility(8);
        }
        int iAK = dm.aK();
        if (!FaceTecSDK.d.f.showSelectionScreenDocumentImage || iAK == 0) {
            this.D.setVisibility(8);
            iRound = 0;
            z = false;
            iRound2 = 0;
        } else {
            iRound = Math.round(bh.a(78) * fB);
            iRound2 = Math.round(((Integer) dm.e(pg.a.a(), pg.a.a(), 1933108801, new Object[0], pg.a.a(), -1933108792, pg.a.a())).intValue());
            this.D.setImageDrawable(C6852.getDrawable(this.l, iAK));
            this.D.setVisibility(0);
            z = true;
        }
        LinearLayout.LayoutParams layoutParams = (LinearLayout.LayoutParams) this.z.getLayoutParams();
        ((ViewGroup.LayoutParams) layoutParams).height = iRound;
        ((ViewGroup.MarginLayoutParams) layoutParams).topMargin = z ? iRound2 : 0;
        ((ViewGroup.MarginLayoutParams) layoutParams).bottomMargin = iRound2;
        this.z.setLayoutParams(layoutParams);
        Drawable drawable3 = C6852.getDrawable(this.l, R.drawable.facetec_idscan_capture_instructions_background);
        dq.a(this.l, this.y, drawable3, ((Integer) dm.e(pg.a.a(), pg.a.a(), -1414859097, new Object[0], pg.a.a(), 1414859112, pg.a.a())).intValue());
        dq.a(this.l, this.y, drawable3, dq.b(this.l, dm.aJ()), (int) (bh.a(dm.w()) * dm.c()), (int) (bh.a(dm.F()) * dm.c()));
        this.y.setBackground(drawable3);
        Drawable drawable4 = C6852.getDrawable(this.l, R.drawable.facetec_idscan_review_instructions_background);
        dq.a(this.l, this.v, drawable4, dm.aG());
        dq.a(this.l, this.v, drawable4, dq.b(this.l, dm.aF()), (int) (bh.a(dm.v()) * dm.c()), (int) (bh.a(dm.I()) * dm.c()));
        this.v.setBackground(drawable4);
        dm.e(this.u);
        dm.e(pg.a.a(), pg.a.a(), -1589723565, new Object[]{this.y}, pg.a.a(), 1589723597, pg.a.a());
        dm.b(this.v);
        dm.j(this.d);
        dp.e(this.d, R.string.FaceTec_idscan_capture_tap_to_focus_message);
        dm.i(this.N);
        this.w.setBackgroundColor(dm.a(this.l));
        this.e.c();
        this.c.c();
        this.f.c();
        this.j.c();
        dp.e(this.e, R.string.FaceTec_action_take_photo);
        dp.e(this.c, R.string.FaceTec_action_retake_photo);
        dp.e(this.f, R.string.FaceTec_action_accept_photo);
        if (dm.bn()) {
            this.a.setImageDrawable(C6852.getDrawable(this.l, dm.aQ()));
            this.a.setOnClickListener(new View.OnClickListener() { // from class: com.facetec.sdk.书道
                @Override // android.view.View.OnClickListener
                public final void onClick(View view2) {
                    this.f6928.a(view2);
                }
            });
            this.a.setOnTouchListener(new View.OnTouchListener() { // from class: com.facetec.sdk.书金
                @Override // android.view.View.OnTouchListener
                public final boolean onTouch(View view2, MotionEvent motionEvent) {
                    return this.f6929.e(view2, motionEvent);
                }
            });
        }
        int i4 = AnonymousClass4.c[FaceTecSDK.d.m.b.ordinal()];
        if (i4 != 2) {
            if (i4 == 3) {
                this.l.w.setVisibility(0);
            } else if (i4 == 4) {
            }
            this.a.setVisibility(8);
        } else {
            RelativeLayout.LayoutParams layoutParams2 = (RelativeLayout.LayoutParams) this.a.getLayoutParams();
            layoutParams2.removeRule(20);
            layoutParams2.addRule(21);
            this.a.setLayoutParams(layoutParams2);
        }
        this.a.getViewTreeObserver().addOnGlobalLayoutListener(this.aa);
        f();
        if (!this.ac) {
            I();
            this.P.setAlpha(1.0f);
            this.P.setVisibility(0);
        }
        if (z2) {
            bt btVar = this.s;
            btVar.b = bt.c.SMALL_FOR_OVERZOOMED;
            btVar.e();
            btVar.d.setStrokeWidth(Math.round(btVar.e));
            btVar.c = Math.round(bh.a(dm.N()) * dm.c());
            btVar.j = btVar.a;
            btVar.b(true);
            btVar.b();
        }
        c(new Runnable() { // from class: com.facetec.sdk.书雨
            @Override // java.lang.Runnable
            public final void run() throws Throwable {
                this.f6930.K();
            }
        });
    }

    public static bv b(boolean z, boolean z2) {
        bv bvVar = new bv();
        Bundle bundle = new Bundle();
        bundle.putBoolean("overzoomedDocument", z);
        bundle.putBoolean("isStandaloneIDScan", z2);
        bvVar.setArguments(bundle);
        return bvVar;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void g(boolean z) {
        int i;
        int i2 = 0;
        if (z) {
            i = 4;
        } else {
            this.d.animate().alpha(1.0f).setDuration(100L);
            this.M.animate().alpha(1.0f).setDuration(100L);
            i = 0;
            i2 = 4;
        }
        this.C.setVisibility(i2);
        this.x.setVisibility(i2);
        this.v.setVisibility(i2);
        this.I.setVisibility(i);
        if (this.m) {
            this.e.setVisibility(i);
        } else {
            this.e.setVisibility(4);
        }
        this.y.setVisibility(i);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void j(boolean z) throws Throwable {
        if (!z) {
            this.U.a(true);
            cv.l();
        }
        this.O = false;
        if (z) {
            t();
        } else {
            q();
        }
    }

    public final void c(boolean z) {
        this.ac = z;
    }

    public final void d() {
        if (b()) {
            this.X.animate().alpha(SelfieScan.RECOGNITION_FAIL_RESULT).setDuration(500L).withEndAction(new au.c(new Runnable() { // from class: com.facetec.sdk.人人
                @Override // java.lang.Runnable
                public final void run() throws Throwable {
                    this.f6942.F();
                }
            })).start();
        }
    }

    public final ah e() {
        return this.U;
    }

    public final void f() {
        float fC = dm.c();
        int iA = pg.a.a();
        int iRound = Math.round((bh.a(((Integer) dm.e(pg.a.a(), iA, -547259901, new Object[0], pg.a.a(), 547259923, pg.a.a())).intValue()) * fC) / 2.0f);
        this.r.setPadding(iRound, iRound, iRound, iRound);
        this.x.setPadding(iRound, iRound, iRound, iRound);
    }

    public final void h() throws Throwable {
        ap apVar = this.U;
        if (apVar != null) {
            apVar.d(false);
            ImageView imageView = this.I;
            if (imageView != null) {
                imageView.setImageResource(dm.aI());
            }
        }
        this.S = false;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ boolean e(View view, MotionEvent motionEvent) {
        if (motionEvent.getAction() == 0) {
            this.a.setAlpha(0.4f);
        } else if (motionEvent.getAction() != 3 && motionEvent.getX() >= SelfieScan.RECOGNITION_FAIL_RESULT && motionEvent.getX() <= this.a.getWidth() + this.a.getLeft() + 10 && motionEvent.getY() >= SelfieScan.RECOGNITION_FAIL_RESULT && motionEvent.getY() <= this.a.getHeight() + this.a.getTop() + 10) {
            if (motionEvent.getAction() == 1) {
                this.a.performClick();
            }
        } else {
            this.a.setAlpha(1.0f);
        }
        return true;
    }

    public final void a(boolean z) {
        this.W = z;
    }

    public final void c() {
        if (b()) {
            dk dkVar = this.Z;
            if (dkVar != null) {
                dkVar.a = true;
                dkVar.a();
            }
            this.E.setOnTouchListener(new View.OnTouchListener() { // from class: com.facetec.sdk.人妖
                @Override // android.view.View.OnTouchListener
                public final boolean onTouch(View view, MotionEvent motionEvent) {
                    return this.f6957.c(view, motionEvent);
                }
            });
        }
    }

    public final void i() {
        ImageView imageView = this.a;
        if (imageView != null) {
            imageView.getViewTreeObserver().removeOnGlobalLayoutListener(this.aa);
        }
        this.aa = null;
    }

    private void d(final boolean z) {
        this.O = !z;
        dp.e(this.v, R.string.FaceTec_idscan_review_id_front_instruction_message);
        if (getActivity() == null) {
            return;
        }
        getActivity().runOnUiThread(new Runnable() { // from class: com.facetec.sdk.人山
            @Override // java.lang.Runnable
            public final void run() {
                this.f6960.g(z);
            }
        });
    }

    /* JADX INFO: renamed from: a, reason: merged with bridge method [inline-methods] */
    public final void I() throws Throwable {
        try {
            this.U = (ap) ah.a(this.E, this.l, true, true);
        } catch (ak e) {
            n.a(e);
            bi biVar = this.l;
            c cVar = c.CAMERA_ERROR;
            StringBuilder sb = new StringBuilder("IDScanCameraSetupError with message: ");
            sb.append(e.getMessage());
            String string = sb.toString();
            FaceTecIDScanStatus faceTecIDScanStatus = FaceTecIDScanStatus.CAMERA_ERROR;
            t.d(biVar, e, cVar, string, false, faceTecIDScanStatus.ordinal());
            bi biVar2 = this.l;
            biVar2.e(biVar2.z.getStatus(), faceTecIDScanStatus);
        }
        this.U.d((Runnable) new au.c(new Runnable() { // from class: com.facetec.sdk.书龙
            @Override // java.lang.Runnable
            public final void run() {
                this.f6935.c();
            }
        }));
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void l(boolean z) {
        d(false);
        int i = this.ac ? 0 : HttpStatusCodeRange.DEFAULT_MIN;
        this.t.setVisibility(0);
        float fA = bh.a(20) * dm.b() * dm.c();
        if (z) {
            this.H.setTranslationY(-fA);
            this.J.setTranslationY(fA);
            long j = i;
            this.H.animate().alpha(1.0f).translationY(SelfieScan.RECOGNITION_FAIL_RESULT).setDuration(500L).setStartDelay(j).setInterpolator(new DecelerateInterpolator()).setListener(null).start();
            this.J.animate().alpha(1.0f).translationY(SelfieScan.RECOGNITION_FAIL_RESULT).setDuration(500L).setStartDelay(j).setInterpolator(new DecelerateInterpolator()).setListener(null).start();
        }
        o();
        if (FaceTecSDK.d.m.b == FaceTecCancelButtonCustomization.ButtonLocation.CUSTOM) {
            this.l.c(i);
        } else if (FaceTecSDK.d.m.b != FaceTecCancelButtonCustomization.ButtonLocation.DISABLED) {
            this.a.animate().alpha(1.0f).setDuration(500L).setStartDelay(i).setInterpolator(new DecelerateInterpolator()).setListener(null).start();
        }
        this.P.animate().alpha(SelfieScan.RECOGNITION_FAIL_RESULT).setDuration(500L).setStartDelay(i).setInterpolator(new DecelerateInterpolator()).setListener(null).start();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void b(int i) {
        b(new Runnable() { // from class: com.facetec.sdk.人乐
            @Override // java.lang.Runnable
            public final void run() throws Throwable {
                this.f6940.I();
            }
        }, i);
        dk dkVar = this.Z;
        Handler handler = dkVar.c;
        if (handler != null) {
            handler.removeCallbacks(dkVar.d);
        }
        Handler handler2 = new Handler();
        dkVar.c = handler2;
        handler2.postDelayed(dkVar.d, i + 1000);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void f(boolean z) {
        this.B.setVisibility(4);
        if (z) {
            return;
        }
        this.d.animate().alpha(SelfieScan.RECOGNITION_FAIL_RESULT).setDuration(100L);
        this.M.animate().alpha(SelfieScan.RECOGNITION_FAIL_RESULT).setDuration(100L);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void h(final boolean z) {
        this.f.b(false, true);
        this.c.b(false, true);
        this.e.b(false, true);
        this.e.setVisibility(4);
        this.B.setVisibility(0);
        this.V.postDelayed(new Runnable() { // from class: com.facetec.sdk.书魂
            @Override // java.lang.Runnable
            public final void run() {
                this.f6933.f(z);
            }
        }, 100L);
    }

    public static void j() {
        ad = 1396024866991524551L;
        af = 1453607623;
        f95838ai = (char) 57648;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ boolean c(View view, MotionEvent motionEvent) {
        if (this.O && motionEvent.getAction() == 0 && this.s.d().contains(motionEvent.getX(), motionEvent.getY())) {
            try {
                if (this.U != null) {
                    s();
                    this.Y = true;
                    this.U.c(this.E);
                    this.p.d(motionEvent.getX(), motionEvent.getY());
                }
            } catch (Exception unused) {
            }
        }
        return true;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void a(View view) {
        this.a.setEnabled(false);
        this.f.b(false, true);
        this.c.b(false, true);
        this.e.b(false, true);
        this.l.c(FaceTecIDScanStatus.USER_CANCELED);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void e(final View view) throws Throwable {
        if (this.U == null) {
            e(6);
            return;
        }
        view.setEnabled(false);
        this.e.b(false, true);
        view.postDelayed(new Runnable() { // from class: com.facetec.sdk.人名
            @Override // java.lang.Runnable
            public final void run() {
                this.f6949.b(view);
            }
        }, 1000L);
        boolean z = this.S;
        this.S = !z;
        if (!z) {
            this.I.setImageResource(dm.aL());
        } else {
            this.I.setImageResource(dm.aI());
        }
        this.U.d(this.S);
    }

    public final void g() throws Throwable {
        if (b()) {
            if (this.U == null) {
                e(7);
                return;
            }
            cv.o(true, true);
            this.k = true;
            p();
            this.U.d();
            if (this.S) {
                this.U.d(true);
            }
            d(false);
            this.c.b(false, true);
            this.f.b(false, true);
            this.e.b(true, true);
            this.e.setVisibility(0);
            b bVar = this.f95839g;
            if (bVar == b.FRONT) {
                dp.e(this.y, R.string.FaceTec_idscan_capture_id_front_instruction_message);
            } else if (bVar == b.BACK) {
                dp.e(this.y, R.string.FaceTec_idscan_capture_id_back_instruction_message);
            }
        }
    }

    public final void b(final boolean z) {
        if (b()) {
            e eVar = this.e;
            if (eVar != null) {
                eVar.setEnabled(false);
            }
            c(new Runnable() { // from class: com.facetec.sdk.书神
                @Override // java.lang.Runnable
                public final void run() throws Throwable {
                    this.f6922.n(z);
                }
            }, 100L);
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void b(View view) {
        view.setEnabled(true);
        this.e.b(true, true);
    }

    private void e(final boolean z) throws Throwable {
        if ((!bj.h || this.U.o) && this.U.k) {
            s();
            this.k = false;
            if (getActivity() == null) {
                return;
            }
            getActivity().runOnUiThread(new Runnable() { // from class: com.facetec.sdk.人庙
                @Override // java.lang.Runnable
                public final void run() {
                    this.f6963.h(z);
                }
            });
            ap apVar = this.U;
            if (apVar == null) {
                e(9);
                return;
            }
            if (this.S) {
                apVar.d(false);
            }
            if (bj.h) {
                i(z);
            } else {
                j(z);
            }
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void b(co coVar, cn cnVar) throws Throwable {
        int i = AnonymousClass4.b[coVar.ordinal()];
        if (i == 1) {
            this.Q = false;
            if (AnonymousClass4.a[cnVar.ordinal()] == 3 && this.Y) {
                this.U.c(true, (ViewGroup) this.E);
                return;
            }
            return;
        }
        if (i != 2) {
            if (i == 3 && this.k && this.e.getVisibility() != 0) {
                this.m = true;
                c(new Runnable() { // from class: com.facetec.sdk.人仙
                    @Override // java.lang.Runnable
                    public final void run() {
                        this.f6943.v();
                    }
                });
                return;
            }
            return;
        }
        if (this.Q) {
            return;
        }
        this.Q = true;
        e(true);
    }

    public static void n() {
        al = new byte[]{81, 99, 107, 124, PassportService.SFI_DG13, -10, 14, -3, -6, -5, ISO7816.INS_GET_DATA, 70, -15, 19, -4, -70, 38, 17, 19, -4, -31, 31, -11, 3, 7, -11, 18, 1, -43, 37, -10, 1, 19, -41, 23, -9, 21, -21, -51, 62, -11, PassportService.SFI_DG13, -7, -57, 21, 37, -7, 17, -31, 18, PassportService.SFI_DG12, 4, -16, 9, -11, 2, PassportService.SFI_DG13, -10, 14, -3, -6, -5, ISO7816.INS_GET_DATA, 72, -13, -4, 18, -73, 40, 19, -4, 18, -52, ISO7816.INS_UNBLOCK_CHV, -1, -8, 3, -2, 14, -3, -17, 19, -11, 6, -1, -2, PassportService.SFI_DG15, -29, 18, 5, -10, PassportService.SFI_DG11, 8, -35, 27, 6, -18, 5, -21, 25, 3, 1, PassportService.SFI_DG13, -10, 14, -3, -6, -5, ISO7816.INS_GET_DATA, 57, PassportService.SFI_DG11, -17, PassportService.SFI_DG15, -8, 1, -6, 16, -69, 27, ISO7816.INS_CHANGE_CHV, -12, 6, -2, -31, 41, 3, -5, -12, 19, -2, PassportService.SFI_DG15, -50, 39, PassportService.SFI_DG11, -1, -35, 21, PassportService.SFI_DG13, -34, 25, PassportService.SFI_DG15, -19, 7, PassportService.SFI_DG13, -10, 14, -3, -6, -5, ISO7816.INS_GET_DATA, 65, 4, -69, ISO7816.INS_MSE, ISO7816.INS_MSE, -3, -12, 2, 14, 0, -2, PassportService.SFI_DG15, ISO7816.INS_CREATE_FILE, 20, 10, -13, -4, 3, -20, ISO7816.INS_MSE, -9, 6, 3, -9, PassportService.SFI_DG11, 5, -9, 21, -21, -51, 62, -11, PassportService.SFI_DG13, -7, -57, 37, 33, -2, -9, 5, -7, -3, -4, -3, PassportService.SFI_DG11, -9, 21, -21, -51, 62, -11, PassportService.SFI_DG13, -7, -57, 27, 37, 6, -15, 2, -2, PassportService.SFI_DG13, -21, PassportService.SFI_DG11, 9, -16, -22, 23, 5, 6, ISO7816.INS_APPEND_RECORD, PassportService.SFI_DG11, PassportService.SFI_DG11, 9, -16, -9, 21, -21, -51, 62, -11, PassportService.SFI_DG13, -7, -57, 38, 20, 10, -3, 8, -22, 1, 10, -7, -2, PassportService.SFI_DG15, -49, PassportService.SFI_COM, 20, -2, -14, PassportService.SFI_DG13, -10, 14, -3, -6, -5, ISO7816.INS_GET_DATA, 72, -13, -4, 18, -73, 40, 19, -4, 18, PassportService.SFI_DG12, -2, -11, 7, 5, -9, -24, 24, -4, 18, 2, -3, -13, -1, -17, 33, -19, 19, -15, 14, -2, PassportService.SFI_DG15, -37, 23, 0, PassportService.SFI_DG13, -14, PassportService.SFI_DG15, -50, 35, 1, 9, 3, -13, -9, 21, -21, -51, 62, -11, PassportService.SFI_DG13, -7, -57, ISO7816.INS_REHABILITATE_CHV, -13, 1, 6, -7, -2, 17, -70, 31, 24, PassportService.SFI_DG15, -12, 7, -11, 5, 8, -7, -4, -6, -9, 21, -21, -51, 62, -11, PassportService.SFI_DG13, -7, -57, 33, 19, 8, -5, -2, 17, -15, PassportService.SFI_COM, -9, 21, -21, -51, 62, -11, PassportService.SFI_DG13, -7, -57, 33, 19, 8, -5, -2, 17, -57, -9, 21, -21, -51, 62, -11, PassportService.SFI_DG13, -7, -57, PassportService.SFI_COM, 35, -1, -7, 3, -1, -7, -17, PassportService.SFI_DG11, PassportService.SFI_DG11, 9, -16};
        ak = 224;
    }

    private void e(int i) {
        n.a(new Throwable("FaceTec SDK has experienced an unexpected camera error."));
        bi biVar = this.l;
        if (biVar == null) {
            return;
        }
        FaceTecSessionResult faceTecSessionResult = biVar.z;
        if (faceTecSessionResult != null) {
            biVar.e(faceTecSessionResult.getStatus(), FaceTecIDScanStatus.CAMERA_ERROR);
            t.d(this.l, c.CAMERA_ERROR, "IDScan: FaceTecSDK Camera is null unexpectedly ".concat(String.valueOf(i)), null);
        } else {
            biVar.e(FaceTecSessionStatus.UNKNOWN_INTERNAL_ERROR, FaceTecIDScanStatus.CAMERA_ERROR);
            t.d(this.l, c.SESSION_RESULT_UNEXPECTED_NULL, "latestSessionResult is null unexpectedly. Check Activity State Info to see if session has finished", null);
        }
    }
}