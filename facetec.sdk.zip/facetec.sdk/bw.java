package com.facetec.sdk;

import com.facetec.sdk.bv;

/* JADX INFO: loaded from: classes4.dex */
public final class bw {
    private boolean a = true;
    boolean c = false;
    ca e = ca.FRONT_AND_BACK;
    bv.b b = bv.b.FRONT;

    public static bw d(boolean z, ca caVar, bv.b bVar) {
        bw bwVar = new bw();
        bwVar.a = false;
        bwVar.c = z;
        bwVar.e = caVar;
        bwVar.b = bVar;
        return bwVar;
    }
}