package com.facetec.sdk;

import android.content.Context;
import android.content.SharedPreferences;
import io.sentry.protocol.FeatureFlags;
import org.json.JSONObject;

/* JADX INFO: loaded from: classes4.dex */
final class bx {
    boolean a;
    JSONObject b;
    boolean c;
    JSONObject d;
    int e;
    boolean f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    boolean f95840g;
    boolean h;
    boolean i;
    boolean j;
    boolean k;
    boolean l;
    boolean m;
    boolean n;
    boolean o;
    final boolean p;
    private final String r = "enforceNFC";
    boolean s;

    public bx(Context context, String str, int i) throws Exception {
        this.c = false;
        this.d = null;
        this.b = null;
        this.e = 0;
        this.a = false;
        this.f = false;
        this.f95840g = false;
        this.j = false;
        this.h = false;
        this.i = false;
        this.m = false;
        this.n = false;
        this.k = false;
        this.o = false;
        this.l = false;
        this.s = false;
        JSONObject jSONObject = new JSONObject(str);
        JSONObject jSONObjectOptJSONObject = jSONObject.optJSONObject("data");
        this.d = jSONObjectOptJSONObject;
        if (jSONObjectOptJSONObject == null) {
            throw new Exception();
        }
        JSONObject jSONObjectOptJSONObject2 = jSONObjectOptJSONObject.optJSONObject(FeatureFlags.TYPE);
        this.b = jSONObjectOptJSONObject2;
        if (jSONObjectOptJSONObject2 == null) {
            throw new Exception();
        }
        this.e = jSONObjectOptJSONObject2.optInt("nextStep");
        this.a = this.b.optBoolean("isPassport", false);
        this.p = this.b.optBoolean("useNFCCompatMode", false);
        this.f = jSONObject.optBoolean("success");
        JSONObject jSONObjectOptJSONObject3 = this.d.optJSONObject("resultsFlags");
        if (jSONObjectOptJSONObject3 != null) {
            this.f95840g = jSONObjectOptJSONObject3.optBoolean("matchedHighlyEnough");
            this.j = jSONObjectOptJSONObject3.optBoolean("wasFullID");
            this.h = jSONObjectOptJSONObject3.optBoolean("idTypeNotSupported");
            this.i = jSONObjectOptJSONObject3.optBoolean("overzoomedDocument");
            this.n = jSONObjectOptJSONObject3.optBoolean("retryDueToBarcode");
            this.o = jSONObjectOptJSONObject3.optBoolean("wasLikelyRealID");
            this.l = jSONObjectOptJSONObject3.optBoolean("userScannedFront");
            SharedPreferences.Editor editorEdit = bk.j(context).edit();
            if (!FaceTecSDK.d.f.disableAdditionalReviewScreen) {
                this.m = jSONObjectOptJSONObject3.optBoolean("additionalReviewRequired");
            }
            this.c = jSONObjectOptJSONObject3.optBoolean("enforceNFC");
            boolean zOptBoolean = jSONObjectOptJSONObject3.optBoolean("unexpectedMediaEncounteredAtLeastOnce");
            this.k = zOptBoolean;
            editorEdit.putBoolean(ao.ab, zOptBoolean);
            editorEdit.apply();
        }
        this.s = i == 1 || i == 2;
    }
}