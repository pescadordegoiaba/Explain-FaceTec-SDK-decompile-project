package com.facetec.sdk;

import android.animation.Animator;
import android.animation.AnimatorSet;
import android.animation.ObjectAnimator;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.util.Property;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import androidx.annotation.NonNull;
import com.facetec.sdk.FaceTecVocalGuidanceCustomization;
import com.facetec.sdk.au;
import com.facetec.sdk.bm;
import com.facetec.sdk.bo;
import com.facetec.sdk.ed;
import com.facetec.sdk.pg;
import com.incode.welcome_sdk.modules.SelfieScan;
import com.plaid.internal.EnumC41897g;
import io.sentry.HttpStatusCodeRange;
import io.sentry.protocol.SentryStackFrame;
import kotlin.C6852;

/* JADX INFO: loaded from: classes4.dex */
public final class by extends bg {
    static boolean k = false;
    private Handler n;
    private bm.b o;
    private Handler q;
    private bo r;
    private bo s;
    private int t = 0;
    private final Runnable p = new Runnable() { // from class: com.facetec.sdk.人礼
        @Override // java.lang.Runnable
        public final void run() {
            this.f6980.E();
        }
    };

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void A() {
        this.h = true;
        if (this.a.isEnabled()) {
            return;
        }
        this.a.b(true, true);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void B() {
        dp.e(this.a, R.string.FaceTec_action_im_ready);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void C() {
        if (this.s == null || !b()) {
            return;
        }
        a(this.s);
        this.d.a();
        dp.e(this.a, R.string.FaceTec_action_im_ready);
        this.b.animate().alpha(SelfieScan.RECOGNITION_FAIL_RESULT).setDuration(500L).start();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void D() {
        be beVar = this.d;
        if (beVar != null) {
            beVar.d(1000);
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void E() {
        ed.d(j(), ed.d.GET_READY_PRESS_BUTTON_DELAYED);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void F() {
        this.a.b(false, true);
        this.c.setEnabled(false);
        e(false);
        bm bmVarJ = j();
        if (bmVarJ != null) {
            if (y()) {
                bmVarJ.s();
            } else {
                bmVarJ.f();
            }
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void H() throws Throwable {
        bi biVarF = f();
        if (biVarF != null) {
            if (y()) {
                this.c.setImportantForAccessibility(2);
                t.d(f(), c.CAMERA_PERMISSION_SHOWN, null, null);
                getActivity();
                int iA = pg.a.a();
                if (((Integer) dm.e(pg.a.a(), iA, -783523114, new Object[0], pg.a.a(), 783523156, pg.a.a())).intValue() != 0) {
                    ImageView imageView = this.r.d;
                    Activity activity = getActivity();
                    getActivity();
                    int iA2 = pg.a.a();
                    imageView.setImageDrawable(C6852.getDrawable(activity, ((Integer) dm.e(pg.a.a(), iA2, -783523114, new Object[0], pg.a.a(), 783523156, pg.a.a())).intValue()));
                    this.r.d.setVisibility(0);
                } else {
                    this.r.d.setVisibility(8);
                }
                this.r.e.setVisibility(0);
                dp.e(this.r.c, R.string.FaceTec_camera_permission_header);
                if (this.o == bm.b.NOT_GRANTED) {
                    dp.e(this.a, R.string.FaceTec_camera_permission_enable_camera);
                    this.r.d(R.string.FaceTec_camera_permission_message_enroll);
                } else {
                    dp.e(this.a, R.string.FaceTec_camera_permission_launch_settings);
                    this.r.d(R.string.FaceTec_camera_permission_message_auth);
                }
                this.r.c.setVisibility(0);
                this.r.a.setVisibility(0);
                this.a.animate().alpha(1.0f).setDuration(500L).setListener(null).start();
                this.a.setEnabled(true);
                if (!FaceTecSDK.d.m.hideForCameraPermissions) {
                    a(true, HttpStatusCodeRange.DEFAULT_MIN, 0);
                }
                bi biVarF2 = f();
                if (biVarF2 != null) {
                    biVarF2.m = true;
                    cv.N(ao.af, true);
                }
                new Handler().postDelayed(new au.c(new Runnable() { // from class: com.facetec.sdk.人梦
                    @Override // java.lang.Runnable
                    public final void run() {
                        this.f6973.z();
                    }
                }), 1000L);
                t.b(dh.CAMERA_PERMISSION);
                biVarF.x();
            } else {
                if (this.i) {
                    q();
                    r();
                    d(new Runnable() { // from class: com.facetec.sdk.人气
                        @Override // java.lang.Runnable
                        public final void run() {
                            by.u();
                        }
                    }, EnumC41897g.SDK_ASSET_TRANSFER_ICON_CIRCLE_VALUE);
                    biVarF.w();
                    return;
                }
                c(false);
                biVarF.x();
            }
            this.e.setVisibility(0);
            ObjectAnimator objectAnimatorOfFloat = ObjectAnimator.ofFloat(this.e, (Property<ViewGroup, Float>) View.ALPHA, SelfieScan.RECOGNITION_FAIL_RESULT, 1.0f);
            AnimatorSet animatorSet = new AnimatorSet();
            animatorSet.setDuration(500L);
            animatorSet.play(objectAnimatorOfFloat);
            animatorSet.start();
            t.b(dh.INITIAL_FACE_SCAN_GET_READY);
            t.d(j(), c.GET_READY_IM_READY_SHOWN_AND_READY, null, null);
        }
    }

    @NonNull
    public static by a(@NonNull bm.b bVar, boolean z) {
        by byVar = new by();
        Bundle bundle = new Bundle();
        bundle.putInt("PERMISSION_STATUS", bVar.ordinal());
        bundle.putBoolean("IDSCAN_ONLY_MODE", z);
        byVar.setArguments(bundle);
        k = false;
        return byVar;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void b(Runnable runnable) {
        d(runnable, HttpStatusCodeRange.DEFAULT_MIN);
    }

    private void c(boolean z) {
        this.s = bo.e(R.string.FaceTec_instructions_header_ready_1, R.string.FaceTec_instructions_message_ready_2, bo.e.READY_OVAL, this.d.f().top, this.d.f().bottom, 0);
        if (z) {
            e((Context) getActivity(), false);
            dq.e(this.a, FaceTecSDK.d.i.buttonTextNormalColor);
        } else {
            this.a.animate().alpha(1.0f).setDuration(500L).setListener(null).start();
            this.a.setEnabled(false);
            a(this.s);
            this.d.e.setAlpha(255);
            this.d.a();
            b(new Runnable() { // from class: com.facetec.sdk.人木
                @Override // java.lang.Runnable
                public final void run() {
                    this.f6972.D();
                }
            }, 1000L);
        }
        this.t = 2;
        d(z);
    }

    private void d(boolean z) {
        this.d.b(((Integer) dm.e(pg.a.a(), pg.a.a(), -298147150, new Object[0], pg.a.a(), 298147185, pg.a.a())).intValue(), HttpStatusCodeRange.DEFAULT_MIN, HttpStatusCodeRange.DEFAULT_MIN);
        if (z) {
            this.b.animate().alpha(1.0f).setDuration(500L).setListener(null).withEndAction(new au.c(new Runnable() { // from class: com.facetec.sdk.人玉
                @Override // java.lang.Runnable
                public final void run() {
                    this.f6978.C();
                }
            })).start();
            this.t++;
        } else {
            dp.e(this.a, R.string.FaceTec_action_im_ready);
        }
        this.c.setEnabled(true);
        e(true);
        a(true, HttpStatusCodeRange.DEFAULT_MIN, 0);
        if (ed.b()) {
            this.a.b(true, false);
        } else {
            this.a.b(false, true);
            new Handler().postDelayed(new au.c(new Runnable() { // from class: com.facetec.sdk.人王
                @Override // java.lang.Runnable
                public final void run() {
                    this.f6979.A();
                }
            }), 4500L);
        }
        if (FaceTecSDK.d.vocalGuidanceCustomization.mode == FaceTecVocalGuidanceCustomization.VocalGuidanceMode.FULL_VOCAL_GUIDANCE) {
            ed.d(j(), ed.d.GET_READY_FRAME_YOUR_FACE_AUTOMATIC);
            Handler handler = new Handler();
            this.q = handler;
            handler.postDelayed(this.p, 4500L);
        }
    }

    private void q() {
        Handler handler = this.n;
        if (handler != null) {
            handler.removeCallbacksAndMessages(null);
            this.n = null;
        }
    }

    private void r() {
        Handler handler = this.q;
        if (handler != null) {
            handler.removeCallbacksAndMessages(null);
            this.q = null;
        }
    }

    private void t() {
        if (this.n == null) {
            this.n = new Handler();
        }
        this.n.postDelayed(new au.c(new Runnable() { // from class: com.facetec.sdk.人水
            @Override // java.lang.Runnable
            public final void run() {
                this.f6974.F();
            }
        }), 600000L);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static /* synthetic */ void u() {
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void v() {
        bm bmVarJ = j();
        if (bmVarJ != null) {
            bmVarJ.n();
            t.d(bmVarJ, c.GET_READY_IM_READY_PRESSED, null, null);
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void w() {
        this.c.setEnabled(true);
        e(true);
        this.a.b(true, true);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void x() {
        this.d.b();
        bo boVar = this.s;
        if (boVar != null) {
            boVar.b(true);
        }
    }

    private boolean y() {
        return this.o != bm.b.GRANTED;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void z() {
        this.c.setImportantForAccessibility(1);
    }

    @Override // com.facetec.sdk.bg
    public final void e() {
        this.c.setImportantForAccessibility(2);
        if ((this.s != null) & b()) {
            bo boVar = this.s;
            LinearLayout linearLayout = boVar.b;
            if (linearLayout != null) {
                linearLayout.setImportantForAccessibility(2);
            }
            RelativeLayout relativeLayout = boVar.j;
            if (relativeLayout != null) {
                relativeLayout.setImportantForAccessibility(2);
            }
        }
        bm bmVarJ = j();
        if (bmVarJ == null) {
            return;
        }
        if (y()) {
            bmVarJ.b();
        } else {
            this.a.b(false, true);
            this.a.setVisibility(4);
            k = true;
            q();
            r();
            d(new au.c(new Runnable() { // from class: com.facetec.sdk.人日
                @Override // java.lang.Runnable
                public final void run() {
                    this.f6968.v();
                }
            }), EnumC41897g.SDK_ASSET_TRANSFER_ICON_CIRCLE_VALUE);
        }
        m();
    }

    @Override // com.facetec.sdk.bg
    public final boolean h() {
        return true;
    }

    @Override // com.facetec.sdk.bg
    public final void i() {
    }

    @Override // com.facetec.sdk.bg
    public final void l() {
        super.l();
        this.e.setVisibility(4);
    }

    @Override // com.facetec.sdk.bg
    public final void o() {
        bm bmVarJ = j();
        if (bmVarJ == null) {
            return;
        }
        if (!y()) {
            if (this.t < 2) {
                Handler handler = new Handler();
                int i = this.t;
                if (i == 0) {
                    this.t = i + 1;
                }
                if (this.t == 1) {
                    getFragmentManager().beginTransaction().setCustomAnimations(R.anim.facetec_slide_in_left, R.anim.facetec_slide_out_left).replace(R.id.centerContentFrameLayout, this.s, "centerContentFrameLayout").commitAllowingStateLoss();
                    this.d.d();
                    handler.postDelayed(new au.c(new Runnable() { // from class: com.facetec.sdk.人火
                        @Override // java.lang.Runnable
                        public final void run() {
                            this.f6976.B();
                        }
                    }), 900L);
                }
                handler.postDelayed(new au.c(new Runnable() { // from class: com.facetec.sdk.人灵
                    @Override // java.lang.Runnable
                    public final void run() {
                        this.f6977.w();
                    }
                }), 900L);
            } else {
                super.o();
            }
            this.t++;
        } else if (this.o == bm.b.NOT_GRANTED) {
            q();
            bmVarJ.b();
        } else {
            Intent intent = new Intent();
            intent.setAction("android.settings.APPLICATION_DETAILS_SETTINGS");
            intent.setData(Uri.fromParts(SentryStackFrame.JsonKeys.PACKAGE, bmVarJ.getPackageName(), null));
            bmVarJ.startActivity(intent);
            bmVarJ.s();
        }
        m();
    }

    @Override // com.facetec.sdk.bg, com.facetec.sdk.au, android.app.Fragment
    public final void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        this.o = bm.b.values()[getArguments().getInt("PERMISSION_STATUS")];
        this.i = getArguments().getBoolean("IDSCAN_ONLY_MODE");
        t();
        boolean z = this.o == bm.b.NOT_GRANTED;
        bo boVar = new bo();
        Bundle bundle2 = new Bundle();
        bundle2.putSerializable("screenType", bo.e.GENERIC);
        bundle2.putSerializable("isCameraPermissionsShowing", Boolean.valueOf(z));
        if (z) {
            bundle2.putInt("header", R.string.FaceTec_camera_permission_header);
        }
        boVar.setArguments(bundle2);
        this.r = boVar;
        int i = R.string.FaceTec_instructions_header_ready_1;
        int i2 = R.string.FaceTec_instructions_message_ready_2;
        bo.e eVar = bo.e.READY_OVAL;
        bo boVar2 = new bo();
        Bundle bundle3 = new Bundle();
        bundle3.putInt("header", i);
        bundle3.putInt("message", i2);
        bundle3.putSerializable("screenType", eVar);
        boVar2.setArguments(bundle3);
        this.s = boVar2;
    }

    @Override // com.facetec.sdk.bg, android.app.Fragment
    public final /* bridge */ /* synthetic */ Animator onCreateAnimator(int i, boolean z, int i2) {
        return super.onCreateAnimator(i, z, i2);
    }

    @Override // com.facetec.sdk.bg, android.app.Fragment
    public final /* bridge */ /* synthetic */ View onCreateView(LayoutInflater layoutInflater, ViewGroup viewGroup, Bundle bundle) {
        return super.onCreateView(layoutInflater, viewGroup, bundle);
    }

    @Override // com.facetec.sdk.bg, android.app.Fragment
    public final void onDestroy() {
        super.onDestroy();
        this.r = null;
        this.s = null;
    }

    @Override // com.facetec.sdk.bg, android.app.Fragment
    public final void onPause() {
        super.onPause();
        q();
        r();
    }

    @Override // com.facetec.sdk.bg, android.app.Fragment
    public final /* bridge */ /* synthetic */ void onViewCreated(View view, Bundle bundle) {
        super.onViewCreated(view, bundle);
    }

    public final void p() {
        if (b()) {
            t();
            this.o = bm.b.GRANTED;
            final bi biVarF = f();
            if (biVarF == null || !this.i) {
                c(true);
            } else {
                final au.c cVar = new au.c(new Runnable() { // from class: com.facetec.sdk.人星
                    @Override // java.lang.Runnable
                    public final void run() {
                        biVarF.w();
                    }
                });
                c(new Runnable() { // from class: com.facetec.sdk.人月
                    @Override // java.lang.Runnable
                    public final void run() {
                        this.f6970.b(cVar);
                    }
                });
            }
        }
    }

    @Override // com.facetec.sdk.bg
    public final void a() {
        t.d = ao.m;
        this.f.setVisibility(8);
        a(this.r);
        if (this.n == null) {
            this.n = new Handler();
        }
        this.n.post(new au.c(new Runnable() { // from class: com.facetec.sdk.人海
            @Override // java.lang.Runnable
            public final void run() throws Throwable {
                this.f6975.H();
            }
        }));
    }

    private void a(bo boVar) {
        getFragmentManager().beginTransaction().setCustomAnimations(R.animator.facetec_no_delay_fade_in, 0).replace(R.id.centerContentFrameLayout, boVar).commitAllowingStateLoss();
    }

    @Override // com.facetec.sdk.bg
    public final void c() {
        new Handler().post(new au.c(new Runnable() { // from class: com.facetec.sdk.人战
            @Override // java.lang.Runnable
            public final void run() {
                this.f6967.x();
            }
        }));
    }

    @Override // com.facetec.sdk.bg
    public final void d() {
        q();
        r();
        this.j = null;
        bm bmVarJ = j();
        if (bmVarJ == null) {
            return;
        }
        if (y()) {
            bmVarJ.s();
        } else {
            bmVarJ.k();
        }
    }
}