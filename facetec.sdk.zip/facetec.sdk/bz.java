package com.facetec.sdk;

import java.lang.ref.WeakReference;

/* JADX INFO: loaded from: classes4.dex */
final class bz implements FaceTecIDScanResultCallback {
    private final WeakReference<bi> b;

    public bz(bi biVar) {
        this.b = new WeakReference<>(biVar);
    }

    @Override // com.facetec.sdk.FaceTecIDScanResultCallback
    public final void cancel() {
        bi biVar = this.b.get();
        if (bh.b(biVar)) {
            this.b.clear();
            biVar.E = true;
            biVar.C();
        }
    }

    @Override // com.facetec.sdk.FaceTecIDScanResultCallback
    public final boolean proceedToNextStep(String str) {
        bi biVar = this.b.get();
        if (bh.b(biVar)) {
            return biVar.b(str);
        }
        return false;
    }

    @Override // com.facetec.sdk.FaceTecIDScanResultCallback
    public final void uploadMessageOverride(String str) {
        bi biVar = this.b.get();
        if (bh.b(biVar)) {
            biVar.a(str);
        }
    }

    @Override // com.facetec.sdk.FaceTecIDScanResultCallback
    public final void uploadProgress(float f) {
        bi biVar = this.b.get();
        if (bh.b(biVar)) {
            biVar.c(f);
        }
    }
}