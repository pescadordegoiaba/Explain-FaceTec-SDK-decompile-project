package com.facetec.sdk;

/* JADX INFO: loaded from: classes4.dex */
enum ca {
    FRONT,
    BACK,
    FRONT_AND_BACK
}