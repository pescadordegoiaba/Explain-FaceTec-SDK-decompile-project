package com.facetec.sdk;

import android.content.Context;
import android.graphics.Color;
import android.graphics.ImageFormat;
import android.graphics.PointF;
import android.media.AudioTrack;
import android.os.Build;
import android.os.Process;
import android.os.SystemClock;
import android.telephony.cdma.CdmaCellLocation;
import android.text.AndroidCharacter;
import android.text.TextUtils;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewConfiguration;
import android.widget.ExpandableListView;
import com.facetec.sdk.fw;
import com.facetec.sdk.gn;
import com.google.android.play.core.integrity.model.StandardIntegrityErrorCode;
import com.incode.welcome_sdk.modules.SelfieScan;
import com.lexisnexisrisk.threatmetrix.TMXProfilingConnectionsInterface;
import com.plaid.internal.EnumC41897g;
import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.InputStream;
import java.lang.reflect.Constructor;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.Random;
import net.sf.scuba.smartcards.ISO7816;
import net.sf.scuba.smartcards.ISOFileInfo;
import org.bouncycastle.crypto.signers.PSSSigner;
import org.bouncycastle.i18n.LocalizedMessage;
import org.jmrtd.PassportService;
import org.jmrtd.lds.CVCAFile;
import org.json.JSONArray;

/* JADX INFO: loaded from: classes4.dex */
public final class cb {
    private static final byte[] $$a = null;
    private static final int $$b = 0;
    private static final byte[] $$c = null;
    private static final byte[] $$d = null;
    private static final int $$e = 0;
    private static final int $$f = 0;
    private static int $10;
    private static int $11;
    private static int a;
    private static int b;
    private static int c;
    private static final List<String> d;
    public static boolean e;
    private static boolean f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    private static int f95843g;
    private static final String[] h;
    private static char[] i;
    private static boolean j;
    private static int k;
    private static int l;
    private static boolean m;
    private static int n;
    private static boolean o;
    private static int p;
    private static short[] q;
    private static int r;
    private static int s;
    private static byte[] t;
    private static int y;

    /* JADX INFO: renamed from: com.facetec.sdk.cb$3, reason: invalid class name */
    public class AnonymousClass3 implements Runnable {
        private static final byte[] $$a = null;
        private static final int $$b = 0;
        private static int $10;
        private static int $11;
        private static byte[] a;
        private static short[] b;
        private static int c;
        private static int d;
        private static int e;
        private static char[] f;

        /* JADX INFO: renamed from: g, reason: collision with root package name */
        private static int f95844g;
        private static int h;

        /* JADX WARN: Removed duplicated region for block: B:10:0x0024  */
        /* JADX WARN: Removed duplicated region for block: B:8:0x001e  */
        /* JADX WARN: Unsupported multi-entry loop pattern (BACK_EDGE: B:10:0x0024 -> B:11:0x0026). Please report as a decompilation issue!!! */
        /*
            Code decompiled incorrectly, please refer to instructions dump.
            To view partially-correct code enable 'Show inconsistent code' option in preferences
        */
        private static java.lang.String $$c(byte r6, short r7, byte r8) {
            /*
                byte[] r0 = com.facetec.sdk.cb.AnonymousClass3.$$a
                int r7 = r7 * 4
                int r7 = 3 - r7
                int r6 = r6 * 3
                int r6 = r6 + 1
                int r8 = 122 - r8
                byte[] r1 = new byte[r6]
                r2 = 0
                if (r0 != 0) goto L14
                r3 = r6
                r5 = r2
                goto L26
            L14:
                r3 = r2
            L15:
                int r7 = r7 + 1
                byte r4 = (byte) r8
                int r5 = r3 + 1
                r1[r3] = r4
                if (r5 != r6) goto L24
                java.lang.String r6 = new java.lang.String
                r6.<init>(r1, r2)
                return r6
            L24:
                r3 = r0[r7]
            L26:
                int r8 = r8 + r3
                r3 = r5
                goto L15
            */
            throw new UnsupportedOperationException("Method not decompiled: com.facetec.sdk.cb.AnonymousClass3.$$c(byte, short, byte):java.lang.String");
        }

        static {
            init$0();
            $10 = 0;
            $11 = 1;
            f95844g = 0;
            h = 1;
            d = 647198060;
            c = 114796653;
            e = 1400997020;
            a = new byte[]{114, ISO7816.INS_GET_RESPONSE, -34, -4, -33, 14, -61, -4, -63, ISO7816.INS_WRITE_BINARY, -8, ISO7816.INS_READ_BINARY2, ISO7816.INS_GET_DATA, -16, ISOFileInfo.AB, 9, -12, -37, -63, ISOFileInfo.A5, -86, 2, -61, -4, -63, ISO7816.INS_WRITE_BINARY, -8, ISO7816.INS_READ_BINARY2, ISO7816.INS_GET_DATA, -9, -45, 106, -56, ISOFileInfo.A1, -61, ISO7816.INS_UPDATE_BINARY, -51, -72, -89, 10, ISO7816.INS_UPDATE_BINARY, -37, -61, ISO7816.INS_UPDATE_BINARY, -51, ISO7816.INS_LOAD_KEY_FILE, ISOFileInfo.FCI_EXT, 26, -55, ISO7816.INS_GET_DATA, -49, -34, -58, -33, 96, 126, 109, 117, 96, 126, 71, -101, 109, 117, 101, 123, 113, CVCAFile.CAR_TAG, -113, 124, 109, 99, -24, -4, -59, 31, -14, -6, -22, -8, -10, -57, PassportService.SFI_DG12, -63, -14, ISO7816.INS_MANAGE_CHANNEL, 14, 61, 5, ISO7816.INS_DECREASE, 14, 23, 43, 61, 5, 53, PassportService.SFI_DG11, 1, 18, -31, CVCAFile.CAR_TAG, 62, -63, 121, 5, 10, ISO7816.INS_INCREASE, 5, 60, PassportService.SFI_DG15, -10, 73, 56, 57, 62, PassportService.SFI_DG13, 53, 14, -98, 119, ISOFileInfo.FMD_BYTE, 124, -100, ISO7816.INS_MANAGE_CHANNEL, 116, 84, -124, CVCAFile.CAR_TAG, 115, -98, ISO7816.INS_UNBLOCK_CHV, 69, 84, PassportService.SFI_DG11, ISO7816.INS_MANAGE_CHANNEL, 75, 81, PassportService.SFI_DG13, 105, 81};
            f = new char[]{18288, 18208, 18222, 18218, 18208, 18222, 18221, 18219, 18215, 18182, 18294, 18292, 18176, 18181, 18281, 18294, 18292, 18192, 18197, 18189, 18216, 18226, 18221, 18177, 18197, 18224, 18216, 18219, 18229, 18218, 18210, 18218, 18198, 18197, 18218, 18221, 18221, 18211, 18223, 18313, 18334, 18341, 18312, 18314, 18323, 18312, 18336, 18366, 18364, 18361, 18365, 18355, 18321, 18304, 18321, 18322, 18312, 18336, 18366, 18364, 18361, 18365, 18355, 18327, 18311, 18341, 18356, 18364, 18363, 18390, 18022, 18016, 18010, 18004, 18010, 18023, 18022, 18008, 18022, 18007, 18003, 18018, 18018, 18331, 18321, 18343, 18335, 18321, 18304, 18402, 18341, 18336, 18402, 18348, 18338, 18333, 18348, 18338, 18339, 18335, 18402, 18332, 18329, 18339, 18350, 18332, 18338, 18321, 18339, 18330, 18338, 18425, 18333, 18294, 18209, 18220, 18222, 18216, 18229, 18218, 18221, 18229, 18226, 18268, 18295, 18181, 18190, 18290, 18298, 18227, 18230, 18231, 18221, 18212, 18197, 18195, 18218, 18220, 18212, 18208, 18209, 18209, 18216, 18229, 18221, 18194, 18302, 18199, 18229, 18221, 18210, 18190, 18197, 18224, 18216, 18219, 18229, 18218, 18210, 18218, 18198, 18177, 18221, 18221, 18211, 18369, 18003, 18011, 18008, 18002, 18007, 18002, 18004, 17998, 18348, 18353, 18014, 18367, 18365, 18013, 18005, 18000, 18013, 18014, 18005, 18356, 18357, 18006, 18000, 18012, 18003, 18005, 18007, 18292, 18221, 18223, 18220, 18218, 18194, 18194, 18221, 18229, 18216, 18209, 18209, 18208, 18212, 18220, 18218, 18208, 18208, 18223, 18291, 18211, 18221, 18221, 18177, 18198, 18218, 18210, 18218, 18229, 18219, 18216, 18224, 18197, 18190, 18210, 18221, 18229, 18199, 18181, 18176, 18292, 18290, 18296, 18194, 18221, 18229, 18216, 18209, 18209, 18208, 18212, 18220, 18218, 18184, 18397, 18407, 18398, 18399, 18406, 18397, 18394, 18399, 18406, 18397, 18237, 18209, 18211, 18227, 18384, 18404, 18406, 18395, 18397, 18407, 18395, 18397};
        }

        public static Object[] c(Context context, int i, int i2) {
            Class<String> cls = String.class;
            if (context != null) {
                try {
                    int i3 = (AudioTrack.getMinVolume() > SelfieScan.RECOGNITION_FAIL_RESULT ? 1 : (AudioTrack.getMinVolume() == SelfieScan.RECOGNITION_FAIL_RESULT ? 0 : -1));
                    int i4 = i3 * 69;
                    int i5 = (i4 ^ (-6097)) + ((i4 & (-6097)) << 1);
                    int i6 = ~i3;
                    int i7 = (i6 & (-92)) | (i6 ^ (-92));
                    int i8 = ~i;
                    int i9 = (~((i7 & i8) | (i7 ^ i8))) | (~(i3 | 91));
                    int i10 = ~((i ^ 91) | (i & 91));
                    int i11 = ((i9 ^ i10) | (i9 & i10)) * (-68);
                    int i12 = (i5 & i11) + (i11 | i5);
                    int i13 = ~i3;
                    int i14 = (i13 ^ i8) | (i13 & i8);
                    int i15 = -(-((~((i14 & 91) | (i14 ^ 91))) * (-68)));
                    int i16 = ((i12 | i15) << 1) - (i15 ^ i12);
                    int i17 = ~(((-92) ^ i8) | ((-92) & i8));
                    int i18 = ((i13 & i17) | (i13 ^ i17)) * 68;
                    short s = (short) ((i16 & i18) + (i18 | i16));
                    int i19 = (-16) - (~(-(CdmaCellLocation.convertQuartSecToDecDegrees(0) > 0.0d ? 1 : (CdmaCellLocation.convertQuartSecToDecDegrees(0) == 0.0d ? 0 : -1))));
                    byte b2 = (byte) ((-2) - (~(-(-(SystemClock.uptimeMillis() > 0L ? 1 : (SystemClock.uptimeMillis() == 0L ? 0 : -1))))));
                    int i20 = -TextUtils.indexOf("", "");
                    int i21 = (i20 ^ (-1431710908)) + ((i20 & (-1431710908)) << 1);
                    int longPressTimeout = ViewConfiguration.getLongPressTimeout() >> 16;
                    int i22 = ((longPressTimeout | (-541383951)) << 1) - (longPressTimeout ^ (-541383951));
                    Object[] objArr = new Object[1];
                    i(s, i19, b2, i21, i22, objArr);
                    try {
                        Object[] objArr2 = {(String) objArr[0]};
                        int i23 = 16;
                        Object[] objArr3 = new Object[1];
                        j(new int[]{0, 38, 0, 0}, "\u0000\u0001\u0001\u0001\u0000\u0001\u0001\u0001\u0000\u0000\u0000\u0001\u0001\u0000\u0000\u0000\u0001\u0001\u0000\u0000\u0000\u0001\u0000\u0001\u0001\u0001\u0001\u0001\u0001\u0000\u0000\u0000\u0001\u0000\u0001\u0001\u0001\u0001", true, objArr3);
                        Object objNewInstance = Class.forName((String) objArr3[0]).getDeclaredConstructor(cls).newInstance(objArr2);
                        Object[] objArr4 = new Object[1];
                        j(new int[]{38, 31, EnumC41897g.SDK_ASSET_ICON_ALERT_ERROR_BLACK_VALUE, 0}, "\u0000\u0000\u0000\u0000\u0001\u0001\u0000\u0000\u0001\u0000\u0000\u0001\u0000\u0001\u0000\u0001\u0001\u0001\u0000\u0001\u0000\u0000\u0001\u0000\u0001\u0000\u0000\u0001\u0001\u0001\u0000", false, objArr4);
                        try {
                            Object[] objArr5 = {(String) objArr4[0]};
                            Object[] objArr6 = new Object[1];
                            j(new int[]{0, 38, 0, 0}, "\u0000\u0001\u0001\u0001\u0000\u0001\u0001\u0001\u0000\u0000\u0000\u0001\u0001\u0000\u0000\u0000\u0001\u0001\u0000\u0000\u0000\u0001\u0000\u0001\u0001\u0001\u0001\u0001\u0001\u0000\u0000\u0000\u0001\u0000\u0001\u0001\u0001\u0001", true, objArr6);
                            Object objNewInstance2 = Class.forName((String) objArr6[0]).getDeclaredConstructor(cls).newInstance(objArr5);
                            try {
                                int i24 = -(KeyEvent.getMaxKeyCode() >> 16);
                                int i25 = i24 * (-380);
                                int i26 = ~i24;
                                int i27 = (((i25 ^ 30942) + ((i25 & 30942) << 1)) - (~(-(-((((i ^ 81) | (i & 81)) | i26) * (-381)))))) - 1;
                                int i28 = -(-(((~((i8 ^ 81) | (i8 & 81))) | (~((i26 ^ (-82)) | (i26 & (-82)))) | (~((i24 & 81) | (i24 ^ 81)))) * 381));
                                short s2 = (short) ((i27 & i28) + (i28 | i27) + ((~((i26 ^ 81) | (i26 & 81))) * 381));
                                int i29 = -(ViewConfiguration.getGlobalActionKeyTimeout() > 0L ? 1 : (ViewConfiguration.getGlobalActionKeyTimeout() == 0L ? 0 : -1));
                                int i30 = i29 * EnumC41897g.SDK_ASSET_ICON_PROGRESS_VALUE;
                                int i31 = (((i30 | 3010) << 1) - (i30 ^ 3010)) + ((~((i29 ^ i) | (i29 & i))) * EnumC41897g.SDK_ASSET_ICON_PRODUCT_MONITOR_VALUE);
                                int i32 = (i29 ^ 13) | (i29 & 13);
                                int i33 = ~i;
                                int i34 = -(-(((i32 ^ i33) | (i32 & i33)) * (-216)));
                                int i35 = (i31 ^ i34) + ((i34 & i31) << 1) + (((~(i29 | i33)) | (-14)) * EnumC41897g.SDK_ASSET_ICON_PRODUCT_MONITOR_VALUE);
                                byte bGreen = (byte) Color.green(0);
                                int i36 = -TextUtils.indexOf("", "", 0, 0);
                                int i37 = (i36 ^ (-1431710878)) + ((i36 & (-1431710878)) << 1);
                                int i38 = -TextUtils.indexOf("", "", 0);
                                int iD = fw.e.d();
                                int i39 = i38 * 371;
                                int i40 = ((i39 | 1010028592) << 1) - (i39 ^ 1010028592);
                                int i41 = ~iD;
                                int i42 = ~((541383919 ^ i41) | (541383919 & i41));
                                int i43 = ~i38;
                                int i44 = ~((i43 ^ iD) | (i43 & iD));
                                int i45 = -(-(((i42 ^ i44) | (i44 & i42)) * (-370)));
                                int i46 = ~(i41 | (~i38));
                                int i47 = ~(iD | 541383919);
                                int i48 = ~((i38 ^ (-541383920)) | (i38 & (-541383920)));
                                int i49 = (i40 ^ i45) + ((i40 & i45) << 1) + (((i46 ^ i47) | (i46 & i47) | i48) * (-370));
                                int i50 = -(-(i48 * 370));
                                int i51 = (i49 ^ i50) + ((i50 & i49) << 1);
                                Object[] objArr7 = new Object[1];
                                i(s2, i35, bGreen, i37, i51, objArr7);
                                Class<?> cls2 = Class.forName((String) objArr7[0]);
                                int threadPriority = Process.getThreadPriority(0);
                                int i52 = -(-(threadPriority * EnumC41897g.SDK_ASSET_ILLUSTRATION_PLAID_OVERLAY_FIRST_DEPOSIT_VALUE));
                                int i53 = ((-4880) ^ i52) + ((i52 & (-4880)) << 1);
                                int i54 = ~threadPriority;
                                int i55 = -(-(((~((i54 ^ i33) | (i54 & i33))) | (~((i54 ^ 20) | (i54 & 20)))) * (-245)));
                                int i56 = (i53 ^ i55) + ((i55 & i53) << 1);
                                int i57 = -(-((~((i54 ^ i) | (i54 & i))) * (-245)));
                                short s3 = (short) (((((i56 ^ i57) + ((i57 & i56) << 1)) + (((~(i54 | i)) | 20) * EnumC41897g.SDK_ASSET_ILLUSTRATION_PLAID_OVERLAY_BALANCE_BEAM_02_VALUE)) >> 6) - 16);
                                int i58 = -(ViewConfiguration.getPressedStateDuration() >> 16);
                                int i59 = (i58 & (-15)) + (i58 | (-15));
                                int i60 = -ImageFormat.getBitsPerPixel(0);
                                int i61 = i60 * (-515);
                                int i62 = ((i61 | (-517)) << 1) - (i61 ^ (-517));
                                int i63 = ~i;
                                int i64 = ~((i8 ^ i60) | (i8 & i60));
                                int i65 = ((i63 ^ i64) | (i63 & i64)) * (-516);
                                int i66 = (i62 & i65) + (i65 | i62);
                                int i67 = ~i60;
                                int i68 = ~((i67 ^ i) | (i67 & i));
                                int i69 = ~i60;
                                int i70 = (i69 ^ i8) | (i69 & i8);
                                int i71 = ~((~i70) | i70);
                                int i72 = ((i71 & i68) | (i68 ^ i71)) * 516;
                                int i73 = (i66 ^ i72) + ((i72 & i66) << 1);
                                int i74 = ~((~i67) | i67);
                                int i75 = ~((~i8) | i8);
                                int i76 = -(-(((i74 & i75) | (i74 ^ i75)) * 516));
                                byte b3 = (byte) (((i73 | i76) << 1) - (i76 ^ i73));
                                int i77 = (SystemClock.currentThreadTimeMillis() > (-1L) ? 1 : (SystemClock.currentThreadTimeMillis() == (-1L) ? 0 : -1)) - 1431710873;
                                int i78 = -Color.green(0);
                                int iD2 = fw.e.d();
                                int i79 = (i78 * (-55)) - 288656737;
                                int i80 = -(-(((~(i78 | iD2)) | (-541383897)) * 56));
                                int i81 = (((i79 & i80) + (i79 | i80)) - (~(-(-((~((i78 ^ (-541383897)) | (i78 & (-541383897)))) * (-56)))))) - 1;
                                int i82 = ~iD2;
                                int i83 = ~((i82 & (-541383897)) | (i82 ^ (-541383897)));
                                int i84 = -(-(((i78 & i83) | (i78 ^ i83)) * 56));
                                int i85 = ((i81 | i84) << 1) - (i81 ^ i84);
                                Object[] objArr8 = new Object[1];
                                i(s3, i59, b3, i77, i85, objArr8);
                                Object objInvoke = cls2.getMethod((String) objArr8[0], null).invoke(context, null);
                                try {
                                    int iRgb = Color.rgb(0, 0, 0);
                                    int i86 = iRgb * (-949);
                                    int i87 = (i86 ^ 1258214331) + ((i86 & 1258214331) << 1);
                                    int i88 = ((~(((-16777298) & i33) | ((-16777298) ^ i33))) | (~((~iRgb) | i))) * 1900;
                                    int i89 = (i87 ^ i88) + ((i88 & i87) << 1);
                                    int i90 = ~((i8 ^ iRgb) | (i8 & iRgb));
                                    int i91 = ~(i | 16777297);
                                    int i92 = (i89 - (~(-(-(((i90 & i91) | (i90 ^ i91)) * (-950)))))) - 1;
                                    int i93 = ~(i8 | 16777297);
                                    int i94 = ~((iRgb & i) | (iRgb ^ i));
                                    short s4 = (short) (i92 + (((i93 & i94) | (i93 ^ i94)) * 950));
                                    int i95 = -TextUtils.indexOf("", "", 0, 0);
                                    int i96 = ((i95 | (-15)) << 1) - (i95 ^ (-15));
                                    byte b4 = (byte) (0 - (~(-(ViewConfiguration.getZoomControlsTimeout() > 0L ? 1 : (ViewConfiguration.getZoomControlsTimeout() == 0L ? 0 : -1)))));
                                    int i97 = -ExpandableListView.getPackedPositionGroup(0L);
                                    int iD3 = fw.e.d();
                                    int i98 = i97 * (-1335);
                                    int i99 = ((i98 | 1468415914) << 1) - (i98 ^ 1468415914);
                                    int i100 = (i97 ^ iD3) | (i97 & iD3);
                                    int i101 = (1431710877 | (~i100)) * (-668);
                                    int i102 = ~((1431710877 & iD3) | (1431710877 ^ iD3));
                                    int i103 = ((((i99 | i101) << 1) - (i99 ^ i101)) - (~(((i97 & i102) | (i97 ^ i102)) * 1336))) - 1;
                                    int i104 = -(-(((1431710877 & i100) | (i100 ^ 1431710877)) * 668));
                                    int i105 = (i103 & i104) + (i103 | i104);
                                    int i106 = -TextUtils.indexOf("", "");
                                    int i107 = ~((541383919 ^ i33) | (541383919 & i33));
                                    int i108 = ~(541383919 | i106);
                                    int i109 = ((i106 * (-244)) - 36458144) + (((i107 ^ i108) | (i107 & i108)) * (-245));
                                    int i110 = -(-((~(541383919 | i)) * (-245)));
                                    int i111 = (i109 ^ i110) + ((i109 & i110) << 1);
                                    int i112 = ~(541383919 | i);
                                    int i113 = i111 + (((i106 & i112) | (i106 ^ i112)) * EnumC41897g.SDK_ASSET_ILLUSTRATION_PLAID_OVERLAY_BALANCE_BEAM_02_VALUE);
                                    Object[] objArr9 = new Object[1];
                                    i(s4, i96, b4, i105, i113, objArr9);
                                    Class<?> cls3 = Class.forName((String) objArr9[0]);
                                    int i114 = -(Process.getElapsedCpuTime() > 0L ? 1 : (Process.getElapsedCpuTime() == 0L ? 0 : -1));
                                    short s5 = (short) ((i114 & 110) + (i114 | 110));
                                    int i115 = -Gravity.getAbsoluteGravity(0, 0);
                                    int i116 = i115 * 829;
                                    int i117 = (i116 & (-12435)) + (i116 | (-12435));
                                    int i118 = ~i115;
                                    int i119 = i117 + (((~((i118 & 14) | (i118 ^ 14))) | (~(i8 | i115 | (-15)))) * (-828));
                                    int i120 = (i115 ^ (-15)) | (i115 & (-15));
                                    int i121 = ((i119 - (~(((i120 & i8) | (i120 ^ i8)) * (-828)))) - 1) + ((~(i115 | (-15))) * 828);
                                    byte longPressTimeout2 = (byte) (ViewConfiguration.getLongPressTimeout() >> 16);
                                    int pressedStateDuration = (-1431710872) - (ViewConfiguration.getPressedStateDuration() >> 16);
                                    int i122 = -(Process.myTid() >> 22);
                                    int iD4 = fw.e.d();
                                    int i123 = (i122 * (-103)) - 72035208;
                                    int i124 = ~i122;
                                    int i125 = ((~((541383879 ^ iD4) | (541383879 & iD4))) | (~((i124 ^ 541383879) | (i124 & 541383879)))) * 104;
                                    int i126 = ((i123 | i125) << 1) - (i125 ^ i123);
                                    int i127 = ~iD4;
                                    int i128 = (i127 & i122) | (i127 ^ i122);
                                    int i129 = (((i126 - (~((~((i128 ^ (-541383880)) | (i128 & (-541383880)))) * (-104)))) - 1) - (~(-(-(((i122 ^ iD4) | (i122 & iD4)) * 104))))) - 1;
                                    Object[] objArr10 = new Object[1];
                                    i(s5, i121, longPressTimeout2, pressedStateDuration, i129, objArr10);
                                    try {
                                        Object[] objArr11 = {cls3.getMethod((String) objArr10[0], null).invoke(context, null), 64};
                                        short s6 = (short) ((-97) - (~(-(-Gravity.getAbsoluteGravity(0, 0)))));
                                        int maximumFlingVelocity = ViewConfiguration.getMaximumFlingVelocity() >> 16;
                                        int i130 = (maximumFlingVelocity * (-209)) + 3135;
                                        int i131 = ~maximumFlingVelocity;
                                        int i132 = -(-((~((i131 & 14) | (i131 ^ 14))) * EnumC41897g.SDK_ASSET_ICON_NEW_WINDOW_VALUE));
                                        int i133 = (i130 & i132) + (i130 | i132);
                                        int i134 = ~((14 ^ i8) | (14 & i8));
                                        int i135 = ~maximumFlingVelocity;
                                        int i136 = ~((i135 ^ i) | (i135 & i));
                                        int i137 = ((i134 & i136) | (i134 ^ i136)) * EnumC41897g.SDK_ASSET_ICON_NEW_WINDOW_VALUE;
                                        int i138 = ((i133 | i137) << 1) - (i137 ^ i133);
                                        int i139 = (i135 ^ i33) | (i135 & i33);
                                        int i140 = ~((i139 & (-15)) | (i139 ^ (-15)));
                                        int i141 = (14 & maximumFlingVelocity) | (14 ^ maximumFlingVelocity);
                                        int i142 = ~((i141 & i) | (i141 ^ i));
                                        int i143 = -(-(((i142 & i140) | (i140 ^ i142)) * EnumC41897g.SDK_ASSET_ICON_NEW_WINDOW_VALUE));
                                        int i144 = (i138 & i143) + (i143 | i138);
                                        byte b5 = (byte) ((-2) - (~(Process.getElapsedCpuTime() > 0L ? 1 : (Process.getElapsedCpuTime() == 0L ? 0 : -1))));
                                        int i145 = (ViewConfiguration.getGlobalActionKeyTimeout() > 0L ? 1 : (ViewConfiguration.getGlobalActionKeyTimeout() == 0L ? 0 : -1));
                                        int iD5 = fw.e.d();
                                        int i146 = (i145 * 960) + 105652899;
                                        int i147 = ~iD5;
                                        int i148 = ((~((i145 ^ iD5) | (i145 & iD5))) | (~((1431710878 ^ i147) | (1431710878 & i147)))) * 959;
                                        int i149 = (i146 & i148) + (i148 | i146);
                                        int i150 = ((i149 | 1378802718) << 1) - (1378802718 ^ i149);
                                        int i151 = ~((1431710878 & iD5) | (1431710878 ^ iD5));
                                        int i152 = ~((i145 & i147) | (i147 ^ i145));
                                        int i153 = -(-(((i151 & i152) | (i151 ^ i152)) * 959));
                                        int i154 = (i150 & i153) + (i153 | i150);
                                        int i155 = -View.resolveSize(0, 0);
                                        int iD6 = fw.e.d();
                                        int i156 = (((i155 * 860) + 650889060) - (~(((i155 ^ iD6) | (i155 & iD6)) * (-859)))) - 1;
                                        int i157 = ~iD6;
                                        int i158 = ~((i157 ^ i155) | (i157 & i155));
                                        int i159 = ~i155;
                                        int i160 = (i159 ^ 541383865) | (i159 & 541383865);
                                        int i161 = ~((i160 ^ iD6) | (i160 & iD6));
                                        int i162 = ((i161 & i158) | (i158 ^ i161)) * 859;
                                        int i163 = (i156 & i162) + (i162 | i156);
                                        int i164 = ~((541383865 ^ i157) | (i157 & 541383865));
                                        int i165 = ~(i155 | 541383865);
                                        int i166 = (i163 - (~(-(-(((i165 & i164) | (i164 ^ i165)) * 859))))) - 1;
                                        Object[] objArr12 = new Object[1];
                                        i(s6, i144, b5, i154, i166, objArr12);
                                        Class<?> cls4 = Class.forName((String) objArr12[0]);
                                        char c2 = 'E';
                                        Object[] objArr13 = new Object[1];
                                        j(new int[]{69, 14, EnumC41897g.SDK_ASSET_ILLUSTRATION_PLAID_ATOMIC_TEXT_VALUE, 0}, "\u0001\u0000\u0001\u0000\u0001\u0000\u0000\u0000\u0000\u0000\u0000\u0001\u0000\u0001", false, objArr13);
                                        Object objInvoke2 = cls4.getMethod((String) objArr13[0], cls, Integer.TYPE).invoke(objInvoke, objArr11);
                                        Object[] objArr14 = new Object[1];
                                        j(new int[]{83, 30, 118, 25}, null, true, objArr14);
                                        Class<?> cls5 = Class.forName((String) objArr14[0]);
                                        int i167 = 5;
                                        Object[] objArr15 = new Object[1];
                                        j(new int[]{113, 10, 0, 5}, "\u0001\u0001\u0001\u0000\u0000\u0000\u0000\u0001\u0001\u0001", true, objArr15);
                                        Object[] objArr16 = (Object[]) cls5.getField((String) objArr15[0]).get(objInvoke2);
                                        int length = objArr16.length;
                                        int i168 = 0;
                                        while (i168 < length) {
                                            Object obj = objArr16[i168];
                                            int[] iArr = {EnumC41897g.SDK_ASSET_ILLUSTRATION_CALENDAR_VALUE, i167, 0, 3};
                                            char c3 = c2;
                                            Object[] objArr17 = new Object[1];
                                            j(iArr, "\u0001\u0001\u0000\u0001\u0001", true, objArr17);
                                            try {
                                                Object[] objArr18 = {(String) objArr17[0]};
                                                Object[] objArr19 = new Object[1];
                                                j(new int[]{128, 37, 0, 0}, "\u0001\u0001\u0001\u0001\u0001\u0000\u0001\u0001\u0001\u0001\u0000\u0000\u0001\u0001\u0001\u0000\u0001\u0000\u0001\u0000\u0000\u0001\u0000\u0001\u0001\u0001\u0001\u0001\u0001\u0000\u0000\u0000\u0001\u0001\u0001\u0001\u0001", true, objArr19);
                                                Class<?> cls6 = Class.forName((String) objArr19[0]);
                                                int threadPriority2 = Process.getThreadPriority(0);
                                                int i169 = -((((threadPriority2 | 20) << 1) - (threadPriority2 ^ 20)) >> 6);
                                                int iIndexOf = TextUtils.indexOf("", "", 0, 0);
                                                int iD7 = fw.e.d();
                                                Object[] objArr20 = objArr16;
                                                int i170 = iIndexOf * 595;
                                                Class<String> cls7 = cls;
                                                int i171 = ((i170 | 17805) << 1) - (i170 ^ 17805);
                                                int i172 = ~iIndexOf;
                                                int i173 = (i172 ^ (-15)) | (i172 & (-15));
                                                int i174 = ~i173;
                                                int i175 = ~iD7;
                                                int i176 = ~(i175 | (-15));
                                                int i177 = ((i174 ^ i176) | (i174 & i176)) * (-1188);
                                                int i178 = ((i171 | i177) << 1) - (i171 ^ i177);
                                                int i179 = (~i173) | (~((14 ^ iD7) | (14 & iD7)));
                                                int i180 = ~((~iD7) | iIndexOf);
                                                int i181 = i178 + (((i179 & i180) | (i179 ^ i180)) * 594);
                                                int i182 = ~((14 ^ i175) | (14 & i175));
                                                int i183 = ~((14 ^ iIndexOf) | (14 & iIndexOf));
                                                int i184 = (i182 & i183) | (i182 ^ i183);
                                                int i185 = ~((i175 ^ iIndexOf) | (i175 & iIndexOf));
                                                int i186 = ((i184 & i185) | (i184 ^ i185)) * 594;
                                                int i187 = ((i181 | i186) << 1) - (i181 ^ i186);
                                                byte b6 = (byte) (PointF.length(SelfieScan.RECOGNITION_FAIL_RESULT, SelfieScan.RECOGNITION_FAIL_RESULT) > SelfieScan.RECOGNITION_FAIL_RESULT ? 1 : (PointF.length(SelfieScan.RECOGNITION_FAIL_RESULT, SelfieScan.RECOGNITION_FAIL_RESULT) == SelfieScan.RECOGNITION_FAIL_RESULT ? 0 : -1));
                                                int i188 = (ViewConfiguration.getGlobalActionKeyTimeout() > 0L ? 1 : (ViewConfiguration.getGlobalActionKeyTimeout() == 0L ? 0 : -1)) - 1431710873;
                                                int i189 = -View.resolveSize(0, 0);
                                                int i190 = i189 * 70;
                                                int i191 = (i190 & (-1840605020)) + (i190 | (-1840605020));
                                                int i192 = ~i189;
                                                int i193 = (i192 ^ 541383832) | (i192 & 541383832);
                                                int i194 = ~((i193 ^ i) | (i193 & i));
                                                int i195 = ~(i189 | (-541383833) | i);
                                                int i196 = (i191 - (~(((i194 ^ i195) | (i194 & i195)) * 69))) - 1;
                                                int i197 = ~((~i189) | (-541383833));
                                                int i198 = ~(i192 | i);
                                                int i199 = (i197 ^ i198) | (i197 & i198);
                                                int i200 = ~((i ^ (-541383833)) | (i & (-541383833)));
                                                int i201 = ((i199 ^ i200) | (i199 & i200)) * (-69);
                                                int i202 = (((i196 & i201) + (i196 | i201)) - (~((~((541383832 ^ i189) | (541383832 & i189))) * 69))) - 1;
                                                Object[] objArr21 = new Object[1];
                                                i((short) ((i169 ^ (-18)) + ((i169 & (-18)) << 1)), i187, b6, i188, i202, objArr21);
                                                Object objInvoke3 = cls6.getMethod((String) objArr21[0], cls7).invoke(null, objArr18);
                                                try {
                                                    Object[] objArr22 = new Object[1];
                                                    j(new int[]{165, 28, EnumC41897g.SDK_ASSET_ILLUSTRATION_INCOME_PAYROLL_URL_VALUE, 0}, "\u0001\u0001\u0001\u0001\u0001\u0001\u0001\u0000\u0000\u0001\u0001\u0001\u0000\u0000\u0000\u0001\u0001\u0000\u0001\u0000\u0001\u0000\u0001\u0000\u0001\u0000\u0000\u0001", true, objArr22);
                                                    Class<?> cls8 = Class.forName((String) objArr22[0]);
                                                    int i203 = -TextUtils.getOffsetAfter("", 0);
                                                    int i204 = -KeyEvent.getDeadChar(0, 0);
                                                    int i205 = (i204 * (-919)) + 13785;
                                                    int i206 = ~i204;
                                                    int i207 = length;
                                                    int i208 = ~((i206 ^ 14) | (i206 & 14) | i);
                                                    int i209 = (14 ^ i33) | (14 & i33);
                                                    int i210 = ~((i209 ^ i204) | (i209 & i204));
                                                    int i211 = -(-(((i208 ^ i210) | (i208 & i210)) * 920));
                                                    int i212 = ((i205 | i211) << 1) - (i211 ^ i205);
                                                    int i213 = ~i204;
                                                    int i214 = ~((i213 ^ 14) | (i213 & 14));
                                                    int i215 = ~(i206 | i8);
                                                    int i216 = ((i214 ^ i215) | (i215 & i214)) * 920;
                                                    int i217 = (i212 ^ i216) + ((i212 & i216) << 1);
                                                    int i218 = (i213 ^ 14) | (i213 & 14);
                                                    int i219 = ~((i218 ^ i8) | (i218 & i8));
                                                    int i220 = ~((i206 ^ (-15)) | (i206 & (-15)) | i);
                                                    int i221 = -(-(((i219 ^ i220) | (i219 & i220) | (~((14 & i204) | (14 ^ i204) | i))) * 920));
                                                    int i222 = (i217 ^ i221) + ((i221 & i217) << 1);
                                                    int iLastIndexOf = TextUtils.lastIndexOf("", '0', 0, 0);
                                                    int i223 = -Color.green(0);
                                                    int i224 = ((i223 | (-1431710859)) << 1) - (i223 ^ (-1431710859));
                                                    int i225 = (ExpandableListView.getPackedPositionForChild(0, 0) > 0L ? 1 : (ExpandableListView.getPackedPositionForChild(0, 0) == 0L ? 0 : -1));
                                                    int i226 = (i225 ^ (-541383821)) + ((i225 & (-541383821)) << 1);
                                                    Object[] objArr23 = new Object[1];
                                                    i((short) ((i203 ^ (-55)) + ((i203 & (-55)) << 1)), i222, (byte) (((iLastIndexOf | 1) << 1) - (iLastIndexOf ^ 1)), i224, i226, objArr23);
                                                    try {
                                                        Object[] objArr24 = {new ByteArrayInputStream((byte[]) cls8.getMethod((String) objArr23[0], null).invoke(obj, null))};
                                                        Object[] objArr25 = new Object[1];
                                                        j(new int[]{128, 37, 0, 0}, "\u0001\u0001\u0001\u0001\u0001\u0000\u0001\u0001\u0001\u0001\u0000\u0000\u0001\u0001\u0001\u0000\u0001\u0000\u0001\u0000\u0000\u0001\u0000\u0001\u0001\u0001\u0001\u0001\u0001\u0000\u0000\u0000\u0001\u0001\u0001\u0001\u0001", true, objArr25);
                                                        Class<?> cls9 = Class.forName((String) objArr25[0]);
                                                        Object[] objArr26 = new Object[1];
                                                        j(new int[]{EnumC41897g.SDK_ASSET_ILLUSTRATION_WARNING_EXIT_SPOT_2_VALUE, 19, 0, i23}, "\u0001\u0001\u0001\u0001\u0001\u0000\u0000\u0001\u0000\u0001\u0001\u0001\u0000\u0000\u0001\u0001\u0000\u0000\u0001", false, objArr26);
                                                        Object objInvoke4 = cls9.getMethod((String) objArr26[0], InputStream.class).invoke(objInvoke3, objArr24);
                                                        try {
                                                            Object[] objArr27 = new Object[1];
                                                            j(new int[]{EnumC41897g.SDK_ASSET_ICON_OVERRIDE_VALUE, 34, 0, 0}, "\u0000\u0001\u0001\u0001\u0001\u0001\u0000\u0000\u0000\u0001\u0001\u0001\u0001\u0001\u0001\u0000\u0001\u0000\u0000\u0000\u0001\u0001\u0001\u0000\u0000\u0001\u0000\u0001\u0001\u0001\u0000\u0000\u0001\u0001", false, objArr27);
                                                            Class<?> cls10 = Class.forName((String) objArr27[0]);
                                                            Object[] objArr28 = new Object[1];
                                                            j(new int[]{EnumC41897g.SDK_ASSET_ILLUSTRATION_PLAID_OVERLAY_FIRST_DEPOSIT_VALUE, 23, 53, 0}, "\u0000\u0000\u0001\u0001\u0000\u0001\u0000\u0001\u0000\u0001\u0000\u0001\u0001\u0000\u0000\u0000\u0001\u0001\u0001\u0000\u0001\u0001\u0001", false, objArr28);
                                                            if (!objNewInstance.equals(cls10.getMethod((String) objArr28[0], null).invoke(objInvoke4, null))) {
                                                                try {
                                                                    Object[] objArr29 = new Object[1];
                                                                    j(new int[]{EnumC41897g.SDK_ASSET_ICON_OVERRIDE_VALUE, 34, 0, 0}, "\u0000\u0001\u0001\u0001\u0001\u0001\u0000\u0000\u0000\u0001\u0001\u0001\u0001\u0001\u0001\u0000\u0001\u0000\u0000\u0000\u0001\u0001\u0001\u0000\u0000\u0001\u0000\u0001\u0001\u0001\u0000\u0000\u0001\u0001", false, objArr29);
                                                                    Class<?> cls11 = Class.forName((String) objArr29[0]);
                                                                    Object[] objArr30 = new Object[1];
                                                                    j(new int[]{EnumC41897g.SDK_ASSET_ILLUSTRATION_PLAID_OVERLAY_FIRST_DEPOSIT_VALUE, 23, 53, 0}, "\u0000\u0000\u0001\u0001\u0000\u0001\u0000\u0001\u0000\u0001\u0000\u0001\u0001\u0000\u0000\u0000\u0001\u0001\u0001\u0000\u0001\u0001\u0001", false, objArr30);
                                                                    if (!objNewInstance2.equals(cls11.getMethod((String) objArr30[0], null).invoke(objInvoke4, null))) {
                                                                        int i227 = i168 - 30;
                                                                        i168 = ((i227 | 31) << 1) - (i227 ^ 31);
                                                                        c2 = c3;
                                                                        objArr16 = objArr20;
                                                                        cls = cls7;
                                                                        length = i207;
                                                                        i167 = 5;
                                                                        i23 = 16;
                                                                    }
                                                                } catch (Throwable th) {
                                                                    Throwable cause = th.getCause();
                                                                    if (cause != null) {
                                                                        throw cause;
                                                                    }
                                                                    throw th;
                                                                }
                                                            }
                                                            Object[] objArr31 = {null, new int[1], new int[]{i ^ 1}, new int[]{i}};
                                                            int iNextInt = new Random().nextInt(1212447014);
                                                            int i228 = 1818969260 + (((~((~iNextInt) | (-936331990))) | (-757100496)) * (-235)) + (((~((-936331990) | iNextInt)) | (-757100496)) * (-470)) + (((~(iNextInt | (-620776134))) | (-1072656352)) * EnumC41897g.SDK_ASSET_ILLUSTRATION_INSTITUTION_LINK_CIRCLE_VALUE);
                                                            int i229 = -(-((i228 ^ 16) + ((i228 & 16) << 1)));
                                                            int i230 = ((i2 | i229) << 1) - (i2 ^ i229);
                                                            int i231 = i230 << 13;
                                                            int i232 = (i231 | i230) & (~(i230 & i231));
                                                            int i233 = i232 >>> 17;
                                                            int i234 = ((~i232) & i233) | ((~i233) & i232);
                                                            int i235 = i234 << 5;
                                                            ((int[]) objArr31[1])[0] = ((~i234) & i235) | ((~i235) & i234);
                                                            return objArr31;
                                                        } catch (Throwable th2) {
                                                            Throwable cause2 = th2.getCause();
                                                            if (cause2 != null) {
                                                                throw cause2;
                                                            }
                                                            throw th2;
                                                        }
                                                    } catch (Throwable th3) {
                                                        Throwable cause3 = th3.getCause();
                                                        if (cause3 != null) {
                                                            throw cause3;
                                                        }
                                                        throw th3;
                                                    }
                                                } catch (Throwable th4) {
                                                    Throwable cause4 = th4.getCause();
                                                    if (cause4 != null) {
                                                        throw cause4;
                                                    }
                                                    throw th4;
                                                }
                                            } catch (Throwable th5) {
                                                Throwable cause5 = th5.getCause();
                                                if (cause5 != null) {
                                                    throw cause5;
                                                }
                                                throw th5;
                                            }
                                        }
                                    } catch (Throwable th6) {
                                        Throwable cause6 = th6.getCause();
                                        if (cause6 != null) {
                                            throw cause6;
                                        }
                                        throw th6;
                                    }
                                } catch (Throwable th7) {
                                    Throwable cause7 = th7.getCause();
                                    if (cause7 != null) {
                                        throw cause7;
                                    }
                                    throw th7;
                                }
                            } catch (Throwable th8) {
                                Throwable cause8 = th8.getCause();
                                if (cause8 != null) {
                                    throw cause8;
                                }
                                throw th8;
                            }
                        } catch (Throwable th9) {
                            Throwable cause9 = th9.getCause();
                            if (cause9 != null) {
                                throw cause9;
                            }
                            throw th9;
                        }
                    } catch (Throwable th10) {
                        Throwable cause10 = th10.getCause();
                        if (cause10 != null) {
                            throw cause10;
                        }
                        throw th10;
                    }
                } catch (Throwable unused) {
                }
            }
            Object[] objArr32 = {null, new int[]{((~i) & i) | ((~i) & i)}, new int[]{i}, new int[]{i}};
            int i236 = ~i;
            int i237 = (-1749851360) + (((~((-62612886) | i236)) | (~(133920245 | i))) * (-831)) + ((~((-17301638) | i)) * (-1662)) + (((~((-116618609) | i236)) | (~(116618608 | i)) | (~(62612885 | i))) * 831);
            int i238 = (-1) - (~(i237 * (-756)));
            int i239 = -(-((~i) * (-757)));
            int i240 = ((i238 | i239) << 1) - (i238 ^ i239);
            int i241 = ~i237;
            int i242 = (i240 - (~((~((i241 ^ i) | (i241 & i))) * 1514))) - 1;
            int i243 = ~i237;
            int i244 = (~((i236 & i241) | (i241 ^ i236))) | (~(i243 | ((-1) ^ i243)));
            int i245 = ~((i & i237) | (i237 ^ i));
            int i246 = i2 + i242 + (((i245 & i244) | (i244 ^ i245)) * 757);
            int i247 = i246 << 13;
            int i248 = ((~i246) & i247) | ((~i247) & i246);
            int i249 = i248 ^ (i248 >>> 17);
            int i250 = i249 << 5;
            return objArr32;
        }

        /* JADX WARN: Removed duplicated region for block: B:51:0x0233  */
        /*
            Code decompiled incorrectly, please refer to instructions dump.
            To view partially-correct code enable 'Show inconsistent code' option in preferences
        */
        private static void i(short r29, int r30, byte r31, int r32, int r33, java.lang.Object[] r34) throws java.lang.Throwable {
            /*
                Method dump skipped, instruction units count: 665
                To view this dump change 'Code comments level' option to 'DEBUG'
            */
            throw new UnsupportedOperationException("Method not decompiled: com.facetec.sdk.cb.AnonymousClass3.i(short, int, byte, int, int, java.lang.Object[]):void");
        }

        public static void init$0() {
            $$a = new byte[]{ISO7816.INS_REHABILITATE_CHV, 4, -12, PSSSigner.TRAILER_IMPLICIT};
            $$b = 118;
        }

        private static void j(int[] iArr, String str, boolean z, Object[] objArr) throws Throwable {
            float f2;
            int i;
            long j;
            byte[] bArr;
            String str2 = str;
            Object bytes = str2;
            if (str2 != null) {
                $10 = ($11 + EnumC41897g.SDK_ASSET_ILLUSTRATION_DEPOSIT_SWITCH_VALUE) % 128;
                bytes = str2.getBytes(LocalizedMessage.DEFAULT_ENCODING);
            }
            byte[] bArr2 = (byte[]) bytes;
            hk hkVar = new hk();
            int i2 = 0;
            int i3 = iArr[0];
            int i4 = iArr[1];
            int i5 = iArr[2];
            int i6 = iArr[3];
            char[] cArr = f;
            Class cls = Integer.TYPE;
            if (cArr != null) {
                int length = cArr.length;
                char[] cArr2 = new char[length];
                int i7 = 0;
                f2 = SelfieScan.RECOGNITION_FAIL_RESULT;
                while (i7 < length) {
                    try {
                        Object[] objArr2 = {Integer.valueOf(cArr[i7])};
                        Object objD = an.d(-803102734);
                        if (objD == null) {
                            bArr = bArr2;
                            byte b2 = (byte) i2;
                            byte b3 = b2;
                            objD = an.d(1756 - (ViewConfiguration.getWindowTouchSlop() >> 8), (char) Color.argb(i2, i2, i2, i2), (ViewConfiguration.getScrollFriction() > SelfieScan.RECOGNITION_FAIL_RESULT ? 1 : (ViewConfiguration.getScrollFriction() == SelfieScan.RECOGNITION_FAIL_RESULT ? 0 : -1)) + 23, -1505735511, false, $$c(b2, b3, (byte) (b3 | 55)), new Class[]{cls});
                        } else {
                            bArr = bArr2;
                        }
                        cArr2[i7] = ((Character) ((Method) objD).invoke(null, objArr2)).charValue();
                        i7++;
                        bArr2 = bArr;
                        i2 = 0;
                    } catch (Throwable th) {
                        Throwable cause = th.getCause();
                        if (cause == null) {
                            throw th;
                        }
                        throw cause;
                    }
                }
                cArr = cArr2;
            } else {
                f2 = SelfieScan.RECOGNITION_FAIL_RESULT;
            }
            byte[] bArr3 = bArr2;
            char[] cArr3 = new char[i4];
            System.arraycopy(cArr, i3, cArr3, 0, i4);
            if (bArr3 != null) {
                char[] cArr4 = new char[i4];
                hkVar.a = 0;
                char c2 = 0;
                while (true) {
                    int i8 = hkVar.a;
                    if (i8 >= i4) {
                        break;
                    }
                    if (bArr3[i8] == 1) {
                        Object[] objArr3 = {Integer.valueOf(cArr3[i8]), Integer.valueOf(c2)};
                        Object objD2 = an.d(663167313);
                        if (objD2 == null) {
                            objD2 = an.d(KeyEvent.normalizeMetaState(0) + 2017, (char) (14310 - TextUtils.lastIndexOf("", '0', 0, 0)), 24 - Color.red(0), 1374089738, false, "D", new Class[]{cls, cls});
                        }
                        cArr4[i8] = ((Character) ((Method) objD2).invoke(null, objArr3)).charValue();
                        j = 0;
                    } else {
                        Object[] objArr4 = {Integer.valueOf(cArr3[i8]), Integer.valueOf(c2)};
                        Object objD3 = an.d(-537001977);
                        if (objD3 == null) {
                            byte b4 = (byte) 0;
                            byte b5 = b4;
                            j = 0;
                            objD3 = an.d(1139 - (SystemClock.elapsedRealtime() > 0L ? 1 : (SystemClock.elapsedRealtime() == 0L ? 0 : -1)), (char) (View.combineMeasuredStates(0, 0) + 12388), (ViewConfiguration.getDoubleTapTimeout() >> 16) + 24, -1449143460, false, $$c(b4, b5, (byte) (b5 | 56)), new Class[]{cls, cls});
                        } else {
                            j = 0;
                        }
                        cArr4[i8] = ((Character) ((Method) objD3).invoke(null, objArr4)).charValue();
                    }
                    c2 = cArr4[hkVar.a];
                    Object[] objArr5 = {hkVar, hkVar};
                    Object objD4 = an.d(693882396);
                    if (objD4 == null) {
                        byte b6 = (byte) 0;
                        byte b7 = b6;
                        objD4 = an.d((TypedValue.complexToFloat(0) > f2 ? 1 : (TypedValue.complexToFloat(0) == f2 ? 0 : -1)) + 1803, (char) (9691 - ExpandableListView.getPackedPositionChild(j)), (ViewConfiguration.getMaximumFlingVelocity() >> 16) + 24, 1597644103, false, $$c(b6, b7, b7), new Class[]{Object.class, Object.class});
                    }
                    ((Method) objD4).invoke(null, objArr5);
                }
                cArr3 = cArr4;
            }
            if (i6 > 0) {
                char[] cArr5 = new char[i4];
                i = 0;
                System.arraycopy(cArr3, 0, cArr5, 0, i4);
                int i9 = i4 - i6;
                System.arraycopy(cArr5, 0, cArr3, i9, i6);
                System.arraycopy(cArr5, i6, cArr3, 0, i9);
            } else {
                i = 0;
            }
            if (z) {
                char[] cArr6 = new char[i4];
                hkVar.a = i;
                while (true) {
                    int i10 = hkVar.a;
                    if (i10 >= i4) {
                        break;
                    }
                    $10 = ($11 + 61) % 128;
                    cArr6[i10] = cArr3[(i4 - i10) - 1];
                    hkVar.a = i10 + 1;
                }
                $11 = ($10 + 59) % 128;
                cArr3 = cArr6;
            }
            if (i5 > 0) {
                hkVar.a = 0;
                while (true) {
                    int i11 = hkVar.a;
                    if (i11 >= i4) {
                        break;
                    }
                    cArr3[i11] = (char) (cArr3[i11] - iArr[2]);
                    hkVar.a = i11 + 1;
                }
            }
            objArr[0] = new String(cArr3);
        }

        @Override // java.lang.Runnable
        public void run() {
            h = (f95844g + 1) % 128;
            cv.L(ao.aj, true);
            int i = h + 25;
            f95844g = i % 128;
            if (i % 2 != 0) {
                int i2 = 56 / 0;
            }
        }
    }

    /* JADX WARN: Failed to restore enum class, 'enum' modifier and super class removed */
    /* JADX WARN: Unknown enum class pattern. Please report as an issue! */
    public static final class a {
        private static int k = 0;
        private static int m = 1;
        final int j;
        public static final a d = new a("EmulatorAbiDetected", 0, 1);
        public static final a c = new a("DexGuardEmulatorDetected", 1, 2);
        public static final a b = new a("DexGuardRootDetected", 2, 4);
        public static final a e = new a("DexGuardHookDetected", 3, 8);
        public static final a a = new a("DexGuardVirtualEnvDetected", 4, 16);
        public static final a f = new a("DexGuardApkTamper", 5, 32);
        public static final a i = new a("DexGuardDebuggerAttached", 6, 64);

        /* JADX INFO: renamed from: g, reason: collision with root package name */
        private static a f95845g = new a("CameraFrameHashFailed", 7, 256);
        private static a h = new a("Next", 8, 512);
        private static a o = new a("DexGuardTimeoutOrError", 9, 1073741824);
        private static final /* synthetic */ a[] n = a();
        private static int l = 0;
        private static int s = (l + 7) % 128;

        private a(String str, int i2, int i3) {
            this.j = i3;
        }

        private static /* synthetic */ a[] a() {
            int i2 = m;
            a[] aVarArr = {d, c, b, e, a, f, i, f95845g, h, o};
            int i3 = (i2 & 37) + (i2 | 37);
            k = i3 % 128;
            if (i3 % 2 == 0) {
                return aVarArr;
            }
            throw null;
        }

        public static a valueOf(String str) {
            int i2 = k;
            int i3 = ((i2 | 59) << 1) - (i2 ^ 59);
            m = i3 % 128;
            if (i3 % 2 == 0) {
                Enum.valueOf(a.class, str);
                throw null;
            }
            a aVar = (a) Enum.valueOf(a.class, str);
            int i4 = m + 81;
            k = i4 % 128;
            if (i4 % 2 == 0) {
                return aVar;
            }
            throw null;
        }

        public static a[] values() {
            a[] aVarArr;
            int i2 = k + 71;
            m = i2 % 128;
            if (i2 % 2 == 0) {
                aVarArr = (a[]) n.clone();
                int i3 = 85 / 0;
            } else {
                aVarArr = (a[]) n.clone();
            }
            int i4 = k;
            m = ((i4 & 41) + (i4 | 41)) % 128;
            return aVarArr;
        }
    }

    /* JADX WARN: Failed to restore enum class, 'enum' modifier and super class removed */
    /* JADX WARN: Unknown enum class pattern. Please report as an issue! */
    public static final class b {
        private static int j = 0;
        private static int k = 1;
        private static int m = 0;
        private static int n = 1;

        /* JADX INFO: renamed from: g, reason: collision with root package name */
        final int f95846g;
        public static final b b = new b("InvalidCamera2OutputSizesDetected", 0, 1);
        public static final b d = new b("InvalidCamera1PreviewSizesDetected", 1, 2);
        public static final b e = new b("AllocationCopyToDuplicateBufferDetected", 2, 4);
        public static final b a = new b("Camera1SuspiciousFrameCallerDetected", 3, 8);
        public static final b c = new b("UnConfiguredCamera2CaptureRequestSurfaceDetected", 4, 16);
        public static final b i = new b("UnexpectedLikelyHookingExceptionDetected", 5, 32);
        public static final b f = new b("VirtualCamFilesDetected", 6, 64);
        private static final /* synthetic */ b[] h = c();

        static {
            int i2 = n + 9;
            m = i2 % 128;
            if (i2 % 2 != 0) {
                throw null;
            }
        }

        private b(String str, int i2, int i3) {
            this.f95846g = i3;
        }

        private static /* synthetic */ b[] c() {
            int i2 = j;
            int i3 = ((i2 ^ 115) + ((i2 & 115) << 1)) % 128;
            k = i3;
            b[] bVarArr = {b, d, e, a, c, i, f};
            int i4 = i3 + 107;
            j = i4 % 128;
            if (i4 % 2 == 0) {
                return bVarArr;
            }
            throw null;
        }

        public static b valueOf(String str) {
            int i2 = j + 27;
            k = i2 % 128;
            int i3 = i2 % 2;
            b bVar = (b) Enum.valueOf(b.class, str);
            if (i3 == 0) {
                int i4 = 77 / 0;
            }
            return bVar;
        }

        public static b[] values() {
            int i2 = k;
            j = ((i2 & EnumC41897g.SDK_ASSET_ILLUSTRATION_DEPOSIT_SWITCH_VALUE) + (i2 | EnumC41897g.SDK_ASSET_ILLUSTRATION_DEPOSIT_SWITCH_VALUE)) % 128;
            b[] bVarArr = (b[]) h.clone();
            int i3 = k;
            int i4 = ((i3 | 113) << 1) - (i3 ^ 113);
            j = i4 % 128;
            if (i4 % 2 == 0) {
                return bVarArr;
            }
            throw null;
        }
    }

    public static final class d {
        private static final byte[] $$a = null;
        private static final int $$b = 0;
        private static int a;
        private static Boolean b;
        private static int c;
        public static int d;
        public static int e;
        private static boolean f;

        /* JADX INFO: renamed from: g, reason: collision with root package name */
        private static char[] f95847g;
        private static final byte[] h = null;
        private static int i;
        private static boolean j;
        private static final int l = 0;

        /* JADX WARN: Removed duplicated region for block: B:10:0x0024  */
        /* JADX WARN: Removed duplicated region for block: B:8:0x001e  */
        /* JADX WARN: Unsupported multi-entry loop pattern (BACK_EDGE: B:10:0x0024 -> B:11:0x002b). Please report as a decompilation issue!!! */
        /*
            Code decompiled incorrectly, please refer to instructions dump.
            To view partially-correct code enable 'Show inconsistent code' option in preferences
        */
        private static java.lang.String $$c(short r6, short r7, int r8) {
            /*
                byte[] r0 = com.facetec.sdk.cb.d.$$a
                int r8 = 118 - r8
                int r7 = r7 * 2
                int r7 = r7 + 4
                int r6 = r6 * 2
                int r1 = r6 + 1
                byte[] r1 = new byte[r1]
                r2 = 0
                if (r0 != 0) goto L16
                r3 = r0
                r4 = r2
                r0 = r8
                r8 = r7
                goto L2b
            L16:
                r3 = r2
            L17:
                byte r4 = (byte) r8
                r1[r3] = r4
                int r4 = r3 + 1
                if (r3 != r6) goto L24
                java.lang.String r6 = new java.lang.String
                r6.<init>(r1, r2)
                return r6
            L24:
                r3 = r0[r7]
                r5 = r8
                r8 = r7
                r7 = r3
                r3 = r0
                r0 = r5
            L2b:
                int r7 = r7 + r0
                int r8 = r8 + 1
                r0 = r8
                r8 = r7
                r7 = r0
                r0 = r3
                r3 = r4
                goto L17
            */
            throw new UnsupportedOperationException("Method not decompiled: com.facetec.sdk.cb.d.$$c(short, short, int):java.lang.String");
        }

        static {
            init$0();
            a();
            b();
            a = 0;
            c = 1;
        }

        public static void a() {
            h = new byte[]{PassportService.SFI_DG15, -57, ISO7816.INS_UPDATE_BINARY, 5, -13, 10, -14, 3, 6, 5, 54, -72, PassportService.SFI_DG13, 4, -18, 73, ISO7816.INS_LOAD_KEY_FILE, -19, 4, -18, -12, 2, PassportService.SFI_DG11, -7, -5, 9, 24, -24, 4, -18, -2, 3, PassportService.SFI_DG13, 1, 17, -33, 19, -19, PassportService.SFI_DG15, -14, -13, 10, -14, 3, 6, 5, 54, -72, PassportService.SFI_DG13, 4, -18, 73, ISO7816.INS_LOAD_KEY_FILE, -19, 4, -18, ISO7816.INS_DECREASE_STAMPED, -44, 1, 8, -3, 2, -14, 3, 17, -19, PassportService.SFI_DG11, -6, 1, 2, -15, 45, -37, -3, PassportService.SFI_DG13, 1, -11, 43, -34, -17, PassportService.SFI_DG11, -6, 1, 35, -26, -20, 37, -21, -4, 8, -10, -6, 1, 9, -21, 21, 51, ISO7816.INS_ENVELOPE, PassportService.SFI_DG11, -13, 7, 57, -37, -33, 2, 9, -5, 7, 3, 4, 3, -11, 9, -21, 21, 51, ISO7816.INS_ENVELOPE, PassportService.SFI_DG11, -13, 7, 57, -27, -37, -6, PassportService.SFI_DG15, -2, 2, -13, 21, -11, -9, 16, 22, -23, -5, -6, PassportService.SFI_COM, -11, -11, -9, 16, 9, -21, 21, 51, ISO7816.INS_ENVELOPE, PassportService.SFI_DG11, -13, 7, 57, -20, -45, 0, 3, 7, 4, -13, -13, 0, 3, 7, 4, -13, 24, -11, -11, -9, 16, 2, -3, 16};
            l = 59;
        }

        public static void b() {
            f95847g = new char[]{8607, 8603, 8606, 8580, 8581, 8582, 8583, 8576, 8577, 8578, 8579, 8602};
            i = 1071522250;
            j = true;
            f = true;
        }

        public static synchronized boolean c(Context context) {
            dy dyVar;
            int i2;
            try {
                dyVar = new dy(context);
                try {
                    Object[] objArr = {0, 0};
                    byte[] bArr = h;
                    byte b2 = bArr[12];
                    Object[] objArr2 = new Object[1];
                    k(b2, b2, (short) EnumC41897g.SDK_ASSET_ILLUSTRATION_SIGNIN_HEADER_VALUE, objArr2);
                    Class<?> cls = Class.forName((String) objArr2[0]);
                    Object[] objArr3 = new Object[1];
                    k(bArr[0], bArr[25], (short) EnumC41897g.SDK_ASSET_ICON_CHECKMARK_GREEN_SQUARE_CASH_VALUE, objArr3);
                    String str = (String) objArr3[0];
                    Class cls2 = Integer.TYPE;
                    int iIntValue = ((Integer) cls.getMethod(str, cls2, cls2).invoke(null, objArr)).intValue() + 127;
                    Object[] objArr4 = new Object[1];
                    m(iIntValue, null, null, "\u0084\u0084\u0081\u0083\u0084\u0084\u0083\u0084\u0084\u0081\u0083\u0082\u0084\u0083\u0082\u0084\u0081\u0083\u008c\u0084\u0081\u0083\u008c\u0084\u0081\u0083\u008b\u0082\u0081\u0083\u008a\u0082\u0081\u0083\u0087\u0082\u0083\u0086\u0082\u0083\u0086\u0082\u0081\u0083\u0084\u0082\u0083\u008b\u0082\u0083\u008a\u0082\u0083\u0089\u0082\u0083\u0085\u0082\u0081\u0083\u0089\u0082\u0081\u0083\u0089\u0082\u0081\u0083\u0088\u0082\u0081\u0083\u0087\u0082\u0081\u0083\u0087\u0082\u0083\u0086\u0082\u0083\u0086\u0082\u0081\u0083\u0084\u0082\u0083\u0082\u0082\u0083\u0085\u0082\u0081\u0083\u0084\u0082\u0081\u0083\u008b\u0083\u0084\u0082\u0081\u0083\u008b\u0083\u0082\u0082\u0081\u0083\u008a\u0083\u0089\u0083\u008c\u0082\u0081\u0083\u0088\u0081\u0083\u008b\u0081\u0083\u0088\u0083\u008a\u0081\u0083\u0089\u0081\u0083\u0088\u0081\u0083\u0084\u0081\u0083\u0087\u0081\u0083\u0086\u0081\u0083\u0085\u0081\u0083\u0084\u0081\u0083\u0082\u0081", objArr4);
                    String str2 = (String) objArr4[0];
                    byte b3 = bArr[12];
                    byte b4 = bArr[152];
                    Object[] objArr5 = new Object[1];
                    k(b3, b4, (short) (b4 | ISOFileInfo.DATA_BYTES1), objArr5);
                    Class<?> cls3 = Class.forName((String) objArr5[0]);
                    Object[] objArr6 = new Object[1];
                    k(bArr[36], bArr[3], (short) 99, objArr6);
                    Object[] objArr7 = new Object[1];
                    m(128 - (((Long) cls3.getMethod((String) objArr6[0], null).invoke(null, null)).longValue() > 0L ? 1 : (((Long) cls3.getMethod((String) objArr6[0], null).invoke(null, null)).longValue() == 0L ? 0 : -1)), null, null, "\u0083", objArr7);
                    Object[] objArr8 = {(String) objArr7[0]};
                    char c2 = 6;
                    short s = (short) 75;
                    Object[] objArr9 = new Object[1];
                    k(bArr[132], (byte) (-bArr[6]), s, objArr9);
                    Class<?> cls4 = Class.forName((String) objArr9[0]);
                    byte b5 = (byte) (bArr[136] + 1);
                    Object[] objArr10 = new Object[1];
                    k(b5, (byte) (b5 & 121), (short) (l + 1), objArr10);
                    String str3 = (String) objArr10[0];
                    Object[] objArr11 = new Object[1];
                    k(bArr[132], (byte) (-bArr[6]), s, objArr11);
                    Object[] objArr12 = (Object[]) cls4.getMethod(str3, Class.forName((String) objArr11[0])).invoke(str2, objArr8);
                    int[] iArr = new int[objArr12.length];
                    int i3 = 0;
                    while (i3 < objArr12.length) {
                        Object[] objArr13 = {objArr12[i3]};
                        byte[] bArr2 = h;
                        byte b6 = bArr2[132];
                        byte b7 = bArr2[12];
                        int i4 = l;
                        char c3 = c2;
                        Object[] objArr14 = new Object[1];
                        k(b6, b7, (short) (i4 - 3), objArr14);
                        Class<?> cls5 = Class.forName((String) objArr14[0]);
                        Object[] objArr15 = new Object[1];
                        k((byte) (-bArr2[78]), (byte) (-bArr2[133]), (short) (-bArr2[16]), objArr15);
                        String str4 = (String) objArr15[0];
                        Object[] objArr16 = new Object[1];
                        k(bArr2[132], (byte) (-bArr2[c3]), s, objArr16);
                        Object objInvoke = cls5.getMethod(str4, Class.forName((String) objArr16[0])).invoke(null, objArr13);
                        Object[] objArr17 = new Object[1];
                        k(bArr2[132], bArr2[12], (short) (i4 - 3), objArr17);
                        Class<?> cls6 = Class.forName((String) objArr17[0]);
                        Object[] objArr18 = new Object[1];
                        k(bArr2[95], bArr2[132], (short) (-bArr2[78]), objArr18);
                        iArr[i3] = ((Integer) cls6.getMethod((String) objArr18[0], null).invoke(objInvoke, null)).intValue();
                        i3++;
                        c2 = c3;
                    }
                    char c4 = c2;
                    int i5 = 16;
                    int i6 = 0;
                    while (true) {
                        int i7 = i6 + 1;
                        switch (dyVar.b(iArr[i6])) {
                            case TMXProfilingConnectionsInterface.TMXSocketResponseCode.ResponseIOException /* -22 */:
                                i7 = 42;
                                break;
                            case TMXProfilingConnectionsInterface.TMXSocketResponseCode.ResponseUnknownHost /* -21 */:
                                i2 = i5;
                                dyVar.b(20);
                                i7 = dyVar.a != 0 ? 8 : 30;
                                i6 = i7;
                                i5 = i2;
                                break;
                            case TMXProfilingConnectionsInterface.TMXSocketResponseCode.ResponseOk /* -20 */:
                                i6 = 5;
                                break;
                            case StandardIntegrityErrorCode.INTEGRITY_TOKEN_PROVIDER_INVALID /* -19 */:
                                i7 = 41;
                                break;
                            case StandardIntegrityErrorCode.CLIENT_TRANSIENT_ERROR /* -18 */:
                                i2 = i5;
                                dyVar.b(i2);
                                if (dyVar.a == 0) {
                                    i7 = 40;
                                }
                                i6 = i7;
                                i5 = i2;
                                break;
                            case -17:
                                i7 = 18;
                                i6 = i7;
                                i5 = 16;
                                break;
                            case -16:
                                i7 = 29;
                                i6 = i7;
                                i5 = 16;
                                break;
                            case -15:
                                dyVar.b(i5);
                                if (dyVar.a == 0) {
                                    i7 = 28;
                                }
                                i6 = i7;
                                i5 = 16;
                                break;
                            case -14:
                                dyVar.b = 1;
                                dyVar.b(3);
                                dyVar.b(13);
                                a = dyVar.a;
                                break;
                            case -13:
                                dyVar.b = c;
                                dyVar.b(5);
                                break;
                            case -12:
                                dyVar.b(10);
                                break;
                            case -11:
                                i6 = 1;
                                break;
                            case -10:
                                i6 = i5;
                                break;
                            case -9:
                                dyVar.b = 1;
                                dyVar.b(3);
                                dyVar.b(4);
                                b = (Boolean) dyVar.d;
                                break;
                            case -8:
                                byte[] bArr3 = h;
                                Object[] objArr19 = new Object[1];
                                k(bArr3[132], bArr3[12], (short) (-bArr3[121]), objArr19);
                                Class<?> cls7 = Class.forName((String) objArr19[0]);
                                byte b8 = bArr3[152];
                                Object[] objArr20 = new Object[1];
                                k(b8, (byte) (-bArr3[84]), b8, objArr20);
                                dyVar.c = cls7.getField((String) objArr20[0]).get(null);
                                dyVar.b(1);
                                break;
                            case -7:
                                i6 = 20;
                                break;
                            case -6:
                                dyVar.b = 1;
                                dyVar.b(3);
                                dyVar.b(4);
                                Object obj = dyVar.d;
                                byte[] bArr4 = h;
                                Object[] objArr21 = new Object[1];
                                k(bArr4[132], bArr4[12], (short) (-bArr4[121]), objArr21);
                                Class<?> cls8 = Class.forName((String) objArr21[0]);
                                Object[] objArr22 = new Object[1];
                                k((byte) (-bArr4[c4]), (byte) (-bArr4[14]), bArr4[22], objArr22);
                                dyVar.b = ((Boolean) cls8.getMethod((String) objArr22[0], null).invoke(obj, null)).booleanValue() ? 1 : 0;
                                dyVar.b(5);
                                break;
                            case -5:
                                i6 = 43;
                                break;
                            case -4:
                                i6 = 45;
                                break;
                            case -3:
                                dyVar.b(2);
                                i6 = dyVar.a != 0 ? i7 : 4;
                                break;
                            case -2:
                                dyVar.c = b;
                                dyVar.b(1);
                                break;
                            case -1:
                                i6 = 13;
                                break;
                            default:
                                break;
                        }
                    }
                } catch (Throwable th) {
                    Throwable cause = th.getCause();
                    if (cause != null) {
                        throw cause;
                    }
                    throw th;
                }
            } catch (Throwable th2) {
                throw th2;
            }
            return dyVar.a != 0;
        }

        public static void init$0() {
            $$a = new byte[]{79, 7, ISO7816.INS_READ_BINARY, ISOFileInfo.FILE_IDENTIFIER};
            $$b = EnumC41897g.SDK_ASSET_ILLUSTRATION_INSTITUTION_CIRCLE_VALUE;
        }

        private static void k(byte b2, int i2, short s, Object[] objArr) {
            int i3 = 168 - s;
            byte[] bArr = h;
            int i4 = b2 + 84;
            byte[] bArr2 = new byte[30 - i2];
            int i5 = 29 - i2;
            int i6 = -1;
            if (bArr == null) {
                i4 += -i3;
                i3++;
                bArr = bArr;
                i6 = -1;
            }
            while (true) {
                int i7 = i6 + 1;
                bArr2[i7] = (byte) i4;
                if (i7 == i5) {
                    objArr[0] = new String(bArr2, 0);
                    return;
                }
                i4 += -bArr[i3];
                i3++;
                bArr = bArr;
                i6 = i7;
            }
        }

        private static void m(int i2, String str, int[] iArr, String str2, Object[] objArr) throws Throwable {
            int i3;
            String str3 = str2;
            Object bytes = str3;
            if (str3 != null) {
                bytes = str3.getBytes(LocalizedMessage.DEFAULT_ENCODING);
            }
            byte[] bArr = (byte[]) bytes;
            char[] charArray = str != null ? str.toCharArray() : str;
            hn hnVar = new hn();
            char[] cArr = f95847g;
            Class cls = Integer.TYPE;
            int i4 = 0;
            if (cArr != null) {
                int length = cArr.length;
                char[] cArr2 = new char[length];
                int i5 = 0;
                while (i5 < length) {
                    try {
                        Object[] objArr2 = {Integer.valueOf(cArr[i5])};
                        Object objD = an.d(-814569747);
                        if (objD == null) {
                            byte b2 = (byte) i4;
                            i3 = i4;
                            byte b3 = b2;
                            objD = an.d((AudioTrack.getMaxVolume() > SelfieScan.RECOGNITION_FAIL_RESULT ? 1 : (AudioTrack.getMaxVolume() == SelfieScan.RECOGNITION_FAIL_RESULT ? 0 : -1)) + 1802, (char) ((ViewConfiguration.getWindowTouchSlop() >> 8) + 9692), ExpandableListView.getPackedPositionGroup(0L) + 24, -1189907018, false, $$c(b2, b3, b3), new Class[]{cls});
                        } else {
                            i3 = i4;
                        }
                        cArr2[i5] = ((Character) ((Method) objD).invoke(null, objArr2)).charValue();
                        i5++;
                        i4 = i3;
                    } catch (Throwable th) {
                        Throwable cause = th.getCause();
                        if (cause == null) {
                            throw th;
                        }
                        throw cause;
                    }
                }
                cArr = cArr2;
            }
            int i6 = i4;
            Object[] objArr3 = {Integer.valueOf(i)};
            Object objD2 = an.d(-1578986303);
            if (objD2 == null) {
                byte b4 = (byte) i6;
                byte b5 = b4;
                objD2 = an.d((ExpandableListView.getPackedPositionForGroup(i6) > 0L ? 1 : (ExpandableListView.getPackedPositionForGroup(i6) == 0L ? 0 : -1)) + 2566, (char) ExpandableListView.getPackedPositionGroup(0L), (Process.getElapsedCpuTime() > 0L ? 1 : (Process.getElapsedCpuTime() == 0L ? 0 : -1)) + 22, -679262310, false, $$c(b4, b5, (byte) (b5 + 1)), new Class[]{cls});
            }
            int iIntValue = ((Integer) ((Method) objD2).invoke(null, objArr3)).intValue();
            if (f) {
                int length2 = bArr.length;
                hnVar.b = length2;
                char[] cArr3 = new char[length2];
                hnVar.c = 0;
                while (true) {
                    int i7 = hnVar.c;
                    int i8 = hnVar.b;
                    if (i7 >= i8) {
                        objArr[0] = new String(cArr3);
                        return;
                    }
                    cArr3[i7] = (char) (cArr[bArr[(i8 - 1) - i7] + i2] - iIntValue);
                    Object[] objArr4 = {hnVar, hnVar};
                    Object objD3 = an.d(717234065);
                    if (objD3 == null) {
                        objD3 = an.d(1970 - (TypedValue.complexToFloat(0) > SelfieScan.RECOGNITION_FAIL_RESULT ? 1 : (TypedValue.complexToFloat(0) == SelfieScan.RECOGNITION_FAIL_RESULT ? 0 : -1)), (char) Color.blue(0), (Process.myTid() >> 22) + 24, 1554107594, false, "x", new Class[]{Object.class, Object.class});
                    }
                    ((Method) objD3).invoke(null, objArr4);
                }
            } else if (j) {
                int length3 = charArray.length;
                hnVar.b = length3;
                char[] cArr4 = new char[length3];
                hnVar.c = 0;
                while (true) {
                    int i9 = hnVar.c;
                    int i10 = hnVar.b;
                    if (i9 >= i10) {
                        objArr[0] = new String(cArr4);
                        return;
                    }
                    cArr4[i9] = (char) (cArr[charArray[(i10 - 1) - i9] - i2] - iIntValue);
                    Object[] objArr5 = {hnVar, hnVar};
                    Object objD4 = an.d(717234065);
                    if (objD4 == null) {
                        objD4 = an.d(Color.blue(0) + 1970, (char) ((-1) - ExpandableListView.getPackedPositionChild(0L)), TextUtils.indexOf("", "") + 24, 1554107594, false, "x", new Class[]{Object.class, Object.class});
                    }
                    ((Method) objD4).invoke(null, objArr5);
                }
            } else {
                int length4 = iArr.length;
                hnVar.b = length4;
                char[] cArr5 = new char[length4];
                hnVar.c = 0;
                while (true) {
                    int i11 = hnVar.c;
                    int i12 = hnVar.b;
                    if (i11 >= i12) {
                        objArr[0] = new String(cArr5);
                        return;
                    } else {
                        cArr5[i11] = (char) (cArr[iArr[(i12 - 1) - i11] - i2] - iIntValue);
                        hnVar.c = i11 + 1;
                    }
                }
            }
        }

        public static int c() {
            int i2 = e;
            int i3 = i2 % 7735380;
            e = i2 + 1;
            if (i3 != 0) {
                return d;
            }
            int iMaxMemory = (int) Runtime.getRuntime().maxMemory();
            d = iMaxMemory;
            return iMaxMemory;
        }
    }

    /* JADX WARN: Removed duplicated region for block: B:10:0x0026  */
    /* JADX WARN: Removed duplicated region for block: B:8:0x0020  */
    /* JADX WARN: Unsupported multi-entry loop pattern (BACK_EDGE: B:10:0x0026 -> B:11:0x002d). Please report as a decompilation issue!!! */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    private static java.lang.String $$g(byte r7, byte r8, int r9) {
        /*
            int r9 = r9 + 102
            int r8 = r8 * 2
            int r8 = 3 - r8
            int r7 = r7 * 4
            int r7 = 1 - r7
            byte[] r0 = com.facetec.sdk.cb.$$c
            byte[] r1 = new byte[r7]
            r2 = 0
            if (r0 != 0) goto L16
            r3 = r0
            r4 = r2
            r0 = r9
            r9 = r8
            goto L2d
        L16:
            r3 = r2
        L17:
            int r8 = r8 + 1
            int r4 = r3 + 1
            byte r5 = (byte) r9
            r1[r3] = r5
            if (r4 != r7) goto L26
            java.lang.String r7 = new java.lang.String
            r7.<init>(r1, r2)
            return r7
        L26:
            r3 = r0[r8]
            r6 = r9
            r9 = r8
            r8 = r3
            r3 = r0
            r0 = r6
        L2d:
            int r8 = r8 + r0
            r0 = r9
            r9 = r8
            r8 = r0
            r0 = r3
            r3 = r4
            goto L17
        */
        throw new UnsupportedOperationException("Method not decompiled: com.facetec.sdk.cb.$$g(byte, byte, int):java.lang.String");
    }

    static {
        init$2();
        $10 = 0;
        $11 = 1;
        init$1();
        init$0();
        r = 0;
        y = 1;
        s = 0;
        p = 1;
        e();
        ViewConfiguration.getTouchSlop();
        c = 0;
        a = 0;
        d = new ArrayList();
        b = 0;
        f = false;
        e = false;
        j = false;
        Object[] objArr = new Object[1];
        v((short) (AndroidCharacter.getMirror('0') - 134), 496050126 - (AudioTrack.getMaxVolume() > SelfieScan.RECOGNITION_FAIL_RESULT ? 1 : (AudioTrack.getMaxVolume() == SelfieScan.RECOGNITION_FAIL_RESULT ? 0 : -1)), (ViewConfiguration.getMaximumFlingVelocity() >> 16) - 122, (-1970889069) - (ViewConfiguration.getScrollFriction() > SelfieScan.RECOGNITION_FAIL_RESULT ? 1 : (ViewConfiguration.getScrollFriction() == SelfieScan.RECOGNITION_FAIL_RESULT ? 0 : -1)), (byte) (ViewConfiguration.getLongPressTimeout() >> 16), objArr);
        String strIntern = ((String) objArr[0]).intern();
        Object[] objArr2 = new Object[1];
        v((short) (47 - (SystemClock.uptimeMillis() > 0L ? 1 : (SystemClock.uptimeMillis() == 0L ? 0 : -1))), MotionEvent.axisFromString("") + 496050126, (-122) - (ViewConfiguration.getPressedStateDuration() >> 16), (-1970889054) - (ViewConfiguration.getWindowTouchSlop() >> 8), (byte) KeyEvent.getDeadChar(0, 0), objArr2);
        String strIntern2 = ((String) objArr2[0]).intern();
        Object[] objArr3 = new Object[1];
        u(null, (TypedValue.complexToFloat(0) > SelfieScan.RECOGNITION_FAIL_RESULT ? 1 : (TypedValue.complexToFloat(0) == SelfieScan.RECOGNITION_FAIL_RESULT ? 0 : -1)) + 127, null, "\u008a\u008d\u008c\u008f\u0085\u008a\u0089\u009e\u0096\u008a\u008a\u0083\u009d\u008b\u0094", objArr3);
        h = new String[]{strIntern, strIntern2, ((String) objArr3[0]).intern()};
        int i2 = y + 91;
        r = i2 % 128;
        if (i2 % 2 != 0) {
            throw null;
        }
    }

    public static void a() {
        int i2 = p + 63;
        s = i2 % 128;
        if (i2 % 2 != 0) {
            throw null;
        }
    }

    private static /* synthetic */ Object b(Object[] objArr) {
        final Context context = (Context) objArr[0];
        final a aVar = (a) objArr[1];
        int i2 = p + 99;
        s = i2 % 128;
        if (i2 % 2 == 0) {
            dj.a(new Runnable() { // from class: com.facetec.sdk.人祖
                @Override // java.lang.Runnable
                public final void run() {
                    cb.c(aVar, context);
                }
            });
            return null;
        }
        dj.a(new Runnable() { // from class: com.facetec.sdk.人祖
            @Override // java.lang.Runnable
            public final void run() {
                cb.c(aVar, context);
            }
        });
        int i3 = 74 / 0;
        return null;
    }

    private static synchronized boolean c(b bVar) {
        if ((bVar.f95846g & c) <= 0) {
            p = (s + 61) % 128;
            return false;
        }
        int i2 = p + 19;
        s = i2 % 128;
        return i2 % 2 == 0;
    }

    public static /* synthetic */ Object d(int i2, int i3, Object[] objArr, int i4, int i5, int i6, int i7) {
        int i8 = ~i5;
        int i9 = ~i2;
        int i10 = ~i4;
        int i11 = (~(i9 | i10)) | i8;
        int i12 = ~(i9 | i5 | i4);
        int i13 = (~(i4 | i5)) | (~(i8 | i10)) | i9;
        int i14 = i5 + i2 + i7 + ((-1422066268) * i6) + ((-2108786386) * i3);
        int i15 = i14 * i14;
        int i16 = ((-1583913924) * i5) + 967573504 + (322476998 * i2) + (i11 * 1194288187) + (1194288187 * i12) + ((-1194288187) * i13) + (1516765184 * i7) + ((-1298137088) * i6) + (1722810368 * i3) + (518782976 * i15);
        int i17 = (i5 * 793895740) + 1353643607 + (i2 * 793896262) + (i11 * (-261)) + (i12 * (-261)) + (i13 * EnumC41897g.SDK_ASSET_ILLUSTRATION_SEND_DEPOSIT_AUTHORIZATION_HEADER_VALUE) + (i7 * 793896001) + (i6 * 692483748) + (i3 * (-1016611666)) + (i15 * 166461440);
        int i18 = i16 + (i17 * i17 * 1997799424);
        return i18 != 1 ? i18 != 2 ? e(objArr) : b(objArr) : c(objArr);
    }

    public static synchronized void e(b bVar, boolean z) {
        try {
            int i2 = s;
            int i3 = i2 + 113;
            p = i3 % 128;
            if (i3 % 2 == 0) {
                throw null;
            }
            if (z) {
                int i4 = i2 + 27;
                p = i4 % 128;
                if (i4 % 2 == 0) {
                    c = bVar.f95846g | c;
                    throw null;
                }
                c |= bVar.f95846g;
            }
            a = bVar.f95846g | a;
            c();
        } catch (Throwable th) {
            throw th;
        }
        throw th;
    }

    private static void f() throws Throwable {
        if (!f) {
            p = (s + 69) % 128;
            String[] strArr = Build.SUPPORTED_ABIS;
            int length = strArr.length;
            int i2 = 0;
            while (true) {
                if (i2 >= length) {
                    break;
                }
                String lowerCase = strArr[i2].toLowerCase();
                Object[] objArr = new Object[1];
                u(null, 127 - TextUtils.indexOf("", "", 0, 0), null, "\u0087\u0086\u0085", objArr);
                if (lowerCase.startsWith(((String) objArr[0]).intern())) {
                    b |= a.d.j;
                    p = (s + 21) % 128;
                    break;
                }
                i2++;
            }
            f = true;
            if ((b & a.d.j) > 0 && !cv.a(b)) {
                f = false;
            }
        }
        i();
        dj.a(new Runnable() { // from class: com.facetec.sdk.人祭
            @Override // java.lang.Runnable
            public final void run() throws Throwable {
                cb.g();
            }
        });
    }

    /* JADX INFO: Access modifiers changed from: private */
    /* JADX WARN: Removed duplicated region for block: B:362:0x17f5  */
    /* JADX WARN: Removed duplicated region for block: B:364:0x17f8  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public static /* synthetic */ void g() throws java.lang.Throwable {
        /*
            Method dump skipped, instruction units count: 7585
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: com.facetec.sdk.cb.g():void");
    }

    /* JADX WARN: Removed duplicated region for block: B:176:0x0b2c  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    private static void h() throws java.lang.Throwable {
        /*
            Method dump skipped, instruction units count: 7390
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: com.facetec.sdk.cb.h():void");
    }

    /* JADX WARN: Removed duplicated region for block: B:17:0x0024 A[Catch: all -> 0x001e, TryCatch #1 {, blocks: (B:4:0x0003, B:6:0x000f, B:8:0x0019, B:16:0x0023, B:17:0x0024, B:20:0x002b, B:14:0x0021), top: B:27:0x0003, inners: #0 }] */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    private static synchronized void i() {
        /*
            java.lang.Class<com.facetec.sdk.cb> r0 = com.facetec.sdk.cb.class
            monitor-enter(r0)
            int r1 = com.facetec.sdk.cb.p     // Catch: java.lang.Throwable -> L1e
            int r2 = r1 + 9
            int r2 = r2 % 128
            com.facetec.sdk.cb.s = r2     // Catch: java.lang.Throwable -> L1e
            int r2 = com.facetec.sdk.cb.b     // Catch: java.lang.Throwable -> L1e
            if (r2 != 0) goto L24
            int r1 = r1 + 121
            int r3 = r1 % 128
            com.facetec.sdk.cb.s = r3     // Catch: java.lang.Throwable -> L1e
            int r1 = r1 % 2
            if (r1 != 0) goto L20
            boolean r1 = com.facetec.sdk.cb.j     // Catch: java.lang.Throwable -> L1e
            if (r1 != 0) goto L36
            goto L24
        L1e:
            r1 = move-exception
            goto L38
        L20:
            r1 = 0
            throw r1     // Catch: java.lang.Throwable -> L22
        L22:
            r1 = move-exception
            throw r1     // Catch: java.lang.Throwable -> L1e
        L24:
            boolean r1 = com.facetec.sdk.cv.a(r2)     // Catch: java.lang.Throwable -> L1e
            if (r1 != 0) goto L2b
            goto L36
        L2b:
            r1 = 1
            com.facetec.sdk.cb.j = r1     // Catch: java.lang.Throwable -> L1e
            int r1 = com.facetec.sdk.cb.s     // Catch: java.lang.Throwable -> L1e
            int r1 = r1 + 61
            int r1 = r1 % 128
            com.facetec.sdk.cb.p = r1     // Catch: java.lang.Throwable -> L1e
        L36:
            monitor-exit(r0)
            return
        L38:
            monitor-exit(r0)     // Catch: java.lang.Throwable -> L1e
            throw r1
        */
        throw new UnsupportedOperationException("Method not decompiled: com.facetec.sdk.cb.i():void");
    }

    public static void init$0() {
        $$a = new byte[]{86, 117, -27, 75};
        $$b = 85;
    }

    public static void init$1() {
        $$d = new byte[]{79, 9, 94, -7, -20, -6, 55, ISO7816.INS_GET_RESPONSE, -3, -10, -10, -23, 7, -6, 45, ISO7816.INS_READ_RECORD2, 7, -15, 53, -65, -8, -20, -6, 55, ISO7816.INS_GET_RESPONSE, -3, -10, -10, -23, 7, -6, 45, ISO7816.INS_READ_RECORD2, 7, -15, 53, -73, -16, 75, -70, -20, -6, 55, ISO7816.INS_GET_RESPONSE, -3, -10, -10, -23, 7, -6, 45, ISO7816.INS_READ_RECORD2, 7, -15, 53, ISO7816.INS_GET_RESPONSE, -16, CVCAFile.CAR_TAG, -29, -20, -6, 55, ISO7816.INS_GET_RESPONSE, -3, -10, -10, -23, 7, -6, 45, ISO7816.INS_READ_RECORD2, 7, -15, 53, ISO7816.INS_READ_RECORD_STAMPED, -8, -20, -6, 55, ISO7816.INS_GET_RESPONSE, -3, -10, -10, -23, 7, -6, 45, ISO7816.INS_READ_RECORD2, 7, -15, 53, -59, -27, 72, -21, -20, -6, 55, ISO7816.INS_GET_RESPONSE, -3, -10, -10, -23, 7, -6, 45, ISO7816.INS_READ_RECORD2, 7, -15, 53, -73, 5, -20, -6, 55, ISO7816.INS_GET_RESPONSE, -3, -10, -10, -23, 7, -6, 45, ISO7816.INS_READ_RECORD2, 7, -15, 53, ISO7816.INS_GET_RESPONSE, -21, 71, -71, 55, -21, -20, -6, 55, ISO7816.INS_GET_RESPONSE, -3, -10, -10, -23, 7, -6, 45, ISO7816.INS_READ_RECORD2, 7, -15, 53, -73, -15, 74, ISO7816.INS_DELETE_FILE, -20, -6, 55, ISO7816.INS_GET_RESPONSE, -3, -10, -10, -23, 7, -6, 45, ISO7816.INS_READ_RECORD2, 7, -15, 53, -73, 6, 53, -69, -20, -6, 55, ISO7816.INS_GET_RESPONSE, -3, -10, -10, -23, 7, -6, 45, ISO7816.INS_READ_RECORD2, 7, -15, 53, -65, -15, CVCAFile.CAR_TAG, -23, -10, -20, -6, 55, ISO7816.INS_GET_RESPONSE, -3, -10, -10, -23, 7, -6, 45, ISO7816.INS_READ_RECORD2, 7, -15, 53, -59, -16, -20, -6, 55, ISO7816.INS_GET_RESPONSE, -3, -10, -10, -23, 7, -6, 45, ISO7816.INS_READ_RECORD2, 7, -15, 53, -63, -10, 59, -73, -20, -6, 55, ISO7816.INS_GET_RESPONSE, -3, -10, -10, -23, 7, -6, 45, ISO7816.INS_READ_RECORD2, 7, -15, 53, -73, -5, -20, -6, 55, ISO7816.INS_GET_RESPONSE, -3, -10, -10, -23, 7, -6, 45, ISO7816.INS_READ_RECORD2, 7, -15, 53, -63, -24, -20, -6, 55, ISO7816.INS_GET_RESPONSE, -3, -10, -10, -23, 7, -6, 45, ISO7816.INS_READ_RECORD2, 7, -15, 53, -61, -7, 54, -23, -20, -6, 55, ISO7816.INS_GET_RESPONSE, -3, -10, -10, -23, 7, -6, 45, ISO7816.INS_READ_RECORD2, 7, -15, 53, -59, ISO7816.INS_CREATE_FILE, 77, -73, -20, -6, 55, ISO7816.INS_GET_RESPONSE, -3, -10, -10, -23, 7, -6, 45, ISO7816.INS_READ_RECORD2, 7, -15, 53, -59, -8, 53, -69, -20, -6, 55, ISO7816.INS_GET_RESPONSE, -3, -10, -10, -23, 7, -6, 45, ISO7816.INS_READ_RECORD2, 7, -15, 53, ISO7816.INS_GET_RESPONSE, -21, 71, -72, -20, -6, 55, ISO7816.INS_GET_RESPONSE, -3, -10, -10, -23, 7, -6, 45, ISO7816.INS_READ_RECORD2, 7, -15, 53, -65, -15, CVCAFile.CAR_TAG, -23, -8, -20, -6, 55, ISO7816.INS_GET_RESPONSE, -3, -10, -10, -23, 7, -6, 45, ISO7816.INS_READ_RECORD2, 7, -15, 53, -72, 3, 55, -70, -20, -6, 55, ISO7816.INS_GET_RESPONSE, -3, -10, -10, -23, 7, -6, 45, ISO7816.INS_READ_RECORD2, 7, -15, 53, ISO7816.INS_READ_RECORD_STAMPED, -15, 75, -21, -20, -6, 55, ISO7816.INS_GET_RESPONSE, -3, -10, -10, -23, 7, -6, 45, ISO7816.INS_READ_RECORD2, 7, -15, 53, -65, -15, CVCAFile.CAR_TAG, -21, -13, -20, -6, 55, ISO7816.INS_GET_RESPONSE, -3, -10, -10, -23, 7, -6, 45, ISO7816.INS_READ_RECORD2, 7, -15, 53, -73, -7, -20, -6, 55, ISO7816.INS_GET_RESPONSE, -3, -10, -10, -23, 7, -6, 45, ISO7816.INS_READ_RECORD2, 7, -15, 53, -60, -14, 60, -25, -20, -6, 55, ISO7816.INS_GET_RESPONSE, -3, -10, -10, -23, 7, -6, 45, ISO7816.INS_READ_RECORD2, 7, -15, 53, -61, -29, 76, -22, -20, -6, 55, ISO7816.INS_GET_RESPONSE, -3, -10, -10, -23, 7, -6, 45, ISO7816.INS_READ_RECORD2, 7, -15, 53, -73, -9};
        $$e = 54;
    }

    public static void init$2() {
        $$c = new byte[]{73, 121, ISO7816.INS_WRITE_BINARY, -56};
        $$f = 200;
    }

    /* JADX WARN: Removed duplicated region for block: B:264:0x1183  */
    /* JADX WARN: Removed duplicated region for block: B:384:0x18e9  */
    /* JADX WARN: Removed duplicated region for block: B:385:0x18eb  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    private static void j() throws java.lang.Throwable {
        /*
            Method dump skipped, instruction units count: 7088
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: com.facetec.sdk.cb.j():void");
    }

    private static void k() {
        int iE = gn.AnonymousClass8.e();
        int iE2 = gn.AnonymousClass8.e();
        int iE3 = gn.AnonymousClass8.e();
        d(281522872, gn.AnonymousClass8.e(), new Object[0], iE, -281522871, iE3, iE2);
    }

    private static void l() {
        s = (p + 83) % 128;
        Object[] objArr = {null, (a) a.class.getField("a").get(null)};
        int iE = gn.AnonymousClass8.e();
        int iE2 = gn.AnonymousClass8.e();
        d(1199165984, gn.AnonymousClass8.e(), objArr, iE, -1199165982, gn.AnonymousClass8.e(), iE2);
        s = (p + 31) % 128;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static /* synthetic */ void m() throws Throwable {
        int i2 = s + 85;
        p = i2 % 128;
        int i3 = i2 % 2;
        f();
        if (i3 == 0) {
            throw null;
        }
    }

    private static void n() {
        int i2 = s + 119;
        p = i2 % 128;
        if (i2 % 2 == 0) {
            Object[] objArr = {null, (a) a.class.getField("b").get(null)};
            int iE = gn.AnonymousClass8.e();
            int iE2 = gn.AnonymousClass8.e();
            d(1199165984, gn.AnonymousClass8.e(), objArr, iE, -1199165982, gn.AnonymousClass8.e(), iE2);
            throw null;
        }
        Object[] objArr2 = {null, (a) a.class.getField("b").get(null)};
        int iE3 = gn.AnonymousClass8.e();
        int iE4 = gn.AnonymousClass8.e();
        d(1199165984, gn.AnonymousClass8.e(), objArr2, iE3, -1199165982, gn.AnonymousClass8.e(), iE4);
        s = (p + 19) % 128;
    }

    private static void o() throws Throwable {
        int i2 = (s + 19) % 128;
        p = i2;
        if (e) {
            return;
        }
        e = true;
        s = (i2 + EnumC41897g.SDK_ASSET_ILLUSTRATION_DEPOSIT_SWITCH_VALUE) % 128;
        try {
            int i3 = $$e;
            Object[] objArr = new Object[1];
            x((byte) (i3 & 11), (short) EnumC41897g.SDK_ASSET_ICON_LIGHTNING_WHITE_VALUE, (byte) (i3 & 11), objArr);
            Constructor<?> declaredConstructor = Class.forName((String) objArr[0]).getDeclaredConstructor(null);
            declaredConstructor.setAccessible(true);
            Object[] objArr2 = {declaredConstructor.newInstance(null)};
            Method method = dj.class.getMethod("a", Runnable.class);
            method.setAccessible(true);
            method.invoke(null, objArr2);
            s = (p + 125) % 128;
        } catch (Throwable th) {
            Throwable cause = th.getCause();
            if (cause == null) {
                throw th;
            }
            throw cause;
        }
    }

    private static void u(int[] iArr, int i2, String str, String str2, Object[] objArr) throws Throwable {
        int length;
        char[] cArr;
        int i3;
        int i4;
        String str3 = str2;
        Object bytes = str3;
        if (str3 != null) {
            bytes = str3.getBytes(LocalizedMessage.DEFAULT_ENCODING);
        }
        byte[] bArr = (byte[]) bytes;
        char[] charArray = str != null ? str.toCharArray() : str;
        hn hnVar = new hn();
        char[] cArr2 = i;
        Class cls = Integer.TYPE;
        int i5 = 2;
        int i6 = 0;
        if (cArr2 != null) {
            int i7 = $10 + 53;
            $11 = i7 % 128;
            if (i7 % 2 == 0) {
                length = cArr2.length;
                cArr = new char[length];
                i3 = 1;
            } else {
                length = cArr2.length;
                cArr = new char[length];
                i3 = 0;
            }
            while (i3 < length) {
                try {
                    Object[] objArr2 = {Integer.valueOf(cArr2[i3])};
                    Object objD = an.d(-814569747);
                    if (objD == null) {
                        i4 = i5;
                        byte b2 = (byte) i6;
                        byte b3 = b2;
                        objD = an.d((ViewConfiguration.getWindowTouchSlop() >> 8) + 1803, (char) ((KeyEvent.getMaxKeyCode() >> 16) + 9692), (ViewConfiguration.getKeyRepeatTimeout() >> 16) + 24, -1189907018, false, $$g(b2, b3, (byte) (b3 | 16)), new Class[]{cls});
                    } else {
                        i4 = i5;
                    }
                    cArr[i3] = ((Character) ((Method) objD).invoke(null, objArr2)).charValue();
                    i3++;
                    i5 = i4;
                    i6 = 0;
                } catch (Throwable th) {
                    Throwable cause = th.getCause();
                    if (cause == null) {
                        throw th;
                    }
                    throw cause;
                }
            }
            cArr2 = cArr;
        }
        int i8 = i5;
        Object[] objArr3 = {Integer.valueOf(f95843g)};
        Object objD2 = an.d(-1578986303);
        if (objD2 == null) {
            byte b4 = (byte) 0;
            byte b5 = b4;
            objD2 = an.d(Gravity.getAbsoluteGravity(0, 0) + 2566, (char) ((SystemClock.currentThreadTimeMillis() > (-1L) ? 1 : (SystemClock.currentThreadTimeMillis() == (-1L) ? 0 : -1)) - 1), 23 - ((Process.getThreadPriority(0) + 20) >> 6), -679262310, false, $$g(b4, b5, (byte) (b5 | PassportService.SFI_DG15)), new Class[]{cls});
        }
        int iIntValue = ((Integer) ((Method) objD2).invoke(null, objArr3)).intValue();
        if (o) {
            int length2 = bArr.length;
            hnVar.b = length2;
            char[] cArr3 = new char[length2];
            hnVar.c = 0;
            $11 = ($10 + 79) % 128;
            while (true) {
                int i9 = hnVar.c;
                int i10 = hnVar.b;
                if (i9 >= i10) {
                    objArr[0] = new String(cArr3);
                    return;
                }
                int i11 = $10 + 17;
                $11 = i11 % 128;
                if (i11 % 2 == 0) {
                    cArr3[i9] = (char) (cArr2[bArr[i10 / i9] >>> i2] * iIntValue);
                    Object[] objArr4 = new Object[i8];
                    objArr4[1] = hnVar;
                    objArr4[0] = hnVar;
                    Object objD3 = an.d(717234065);
                    if (objD3 == null) {
                        objD3 = an.d(1970 - (ViewConfiguration.getPressedStateDuration() >> 16), (char) (ViewConfiguration.getMaximumFlingVelocity() >> 16), (AudioTrack.getMinVolume() > SelfieScan.RECOGNITION_FAIL_RESULT ? 1 : (AudioTrack.getMinVolume() == SelfieScan.RECOGNITION_FAIL_RESULT ? 0 : -1)) + 24, 1554107594, false, "x", new Class[]{Object.class, Object.class});
                    }
                    ((Method) objD3).invoke(null, objArr4);
                } else {
                    cArr3[i9] = (char) (cArr2[bArr[(i10 - 1) - i9] + i2] - iIntValue);
                    Object[] objArr5 = {hnVar, hnVar};
                    Object objD4 = an.d(717234065);
                    if (objD4 == null) {
                        objD4 = an.d(1971 - (ViewConfiguration.getScrollFriction() > SelfieScan.RECOGNITION_FAIL_RESULT ? 1 : (ViewConfiguration.getScrollFriction() == SelfieScan.RECOGNITION_FAIL_RESULT ? 0 : -1)), (char) Color.green(0), AndroidCharacter.getMirror('0') - 24, 1554107594, false, "x", new Class[]{Object.class, Object.class});
                    }
                    ((Method) objD4).invoke(null, objArr5);
                }
                i8 = 2;
            }
        } else if (m) {
            int length3 = charArray.length;
            hnVar.b = length3;
            char[] cArr4 = new char[length3];
            hnVar.c = 0;
            while (true) {
                int i12 = hnVar.c;
                int i13 = hnVar.b;
                if (i12 >= i13) {
                    objArr[0] = new String(cArr4);
                    return;
                }
                cArr4[i12] = (char) (cArr2[charArray[(i13 - 1) - i12] - i2] - iIntValue);
                Object[] objArr6 = {hnVar, hnVar};
                Object objD5 = an.d(717234065);
                if (objD5 == null) {
                    objD5 = an.d((TypedValue.complexToFraction(0, SelfieScan.RECOGNITION_FAIL_RESULT, SelfieScan.RECOGNITION_FAIL_RESULT) > SelfieScan.RECOGNITION_FAIL_RESULT ? 1 : (TypedValue.complexToFraction(0, SelfieScan.RECOGNITION_FAIL_RESULT, SelfieScan.RECOGNITION_FAIL_RESULT) == SelfieScan.RECOGNITION_FAIL_RESULT ? 0 : -1)) + 1970, (char) (TextUtils.indexOf((CharSequence) "", '0', 0) + 1), 23 - TextUtils.lastIndexOf("", '0', 0), 1554107594, false, "x", new Class[]{Object.class, Object.class});
                }
                ((Method) objD5).invoke(null, objArr6);
            }
        } else {
            int i14 = 0;
            int length4 = iArr.length;
            hnVar.b = length4;
            char[] cArr5 = new char[length4];
            while (true) {
                hnVar.c = i14;
                i14 = hnVar.c;
                int i15 = hnVar.b;
                if (i14 >= i15) {
                    objArr[0] = new String(cArr5);
                    return;
                }
                int i16 = $11 + 87;
                $10 = i16 % 128;
                if (i16 % 2 != 0) {
                    cArr5[i14] = (char) (cArr2[iArr[i15 >> i14] % i2] + iIntValue);
                } else {
                    cArr5[i14] = (char) (cArr2[iArr[(i15 - 1) - i14] - i2] - iIntValue);
                    i14++;
                }
            }
        }
    }

    /* JADX WARN: Removed duplicated region for block: B:12:0x0073  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    private static void v(short r31, int r32, int r33, int r34, byte r35, java.lang.Object[] r36) throws java.lang.Throwable {
        /*
            Method dump skipped, instruction units count: 807
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: com.facetec.sdk.cb.v(short, int, int, int, byte, java.lang.Object[]):void");
    }

    /* JADX WARN: Removed duplicated region for block: B:10:0x0024  */
    /* JADX WARN: Removed duplicated region for block: B:8:0x001c  */
    /* JADX WARN: Unsupported multi-entry loop pattern (BACK_EDGE: B:10:0x0024 -> B:11:0x0026). Please report as a decompilation issue!!! */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    private static void w(int r6, int r7, byte r8, java.lang.Object[] r9) {
        /*
            int r7 = r7 + 97
            int r8 = r8 * 4
            int r8 = r8 + 1
            int r6 = r6 * 4
            int r6 = r6 + 4
            byte[] r0 = com.facetec.sdk.cb.$$a
            byte[] r1 = new byte[r8]
            r2 = 0
            if (r0 != 0) goto L14
            r3 = r8
            r4 = r2
            goto L26
        L14:
            r3 = r2
        L15:
            int r4 = r3 + 1
            byte r5 = (byte) r7
            r1[r3] = r5
            if (r4 != r8) goto L24
            java.lang.String r6 = new java.lang.String
            r6.<init>(r1, r2)
            r9[r2] = r6
            return
        L24:
            r3 = r0[r6]
        L26:
            int r7 = r7 + r3
            int r6 = r6 + 1
            r3 = r4
            goto L15
        */
        throw new UnsupportedOperationException("Method not decompiled: com.facetec.sdk.cb.w(int, int, byte, java.lang.Object[]):void");
    }

    /* JADX WARN: Removed duplicated region for block: B:10:0x0020  */
    /* JADX WARN: Removed duplicated region for block: B:8:0x0018  */
    /* JADX WARN: Unsupported multi-entry loop pattern (BACK_EDGE: B:10:0x0020 -> B:11:0x0024). Please report as a decompilation issue!!! */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    private static void x(short r5, short r6, byte r7, java.lang.Object[] r8) {
        /*
            int r7 = 101 - r7
            int r0 = 22 - r5
            byte[] r1 = com.facetec.sdk.cb.$$d
            int r6 = r6 + 4
            byte[] r0 = new byte[r0]
            int r5 = 21 - r5
            r2 = 0
            if (r1 != 0) goto L12
            r4 = r5
            r3 = r2
            goto L24
        L12:
            r3 = r2
        L13:
            byte r4 = (byte) r7
            r0[r3] = r4
            if (r3 != r5) goto L20
            java.lang.String r5 = new java.lang.String
            r5.<init>(r0, r2)
            r8[r2] = r5
            return
        L20:
            int r3 = r3 + 1
            r4 = r1[r6]
        L24:
            int r4 = -r4
            int r6 = r6 + 1
            int r7 = r7 + r4
            int r7 = r7 + (-8)
            goto L13
        */
        throw new UnsupportedOperationException("Method not decompiled: com.facetec.sdk.cb.x(short, short, byte, java.lang.Object[]):void");
    }

    public static synchronized void c() {
        int i2 = p + 23;
        s = i2 % 128;
        if (i2 % 2 != 0) {
            cv.b();
            throw null;
        }
        if (cv.b()) {
            cv.K(ao.ak, 2);
            cv.K(ao.f95820ai, a);
            cv.K(ao.al, c);
            cv.M(ao.am, new JSONArray((Collection) d).toString());
            cv.L(ao.aj, e);
            s = (p + 43) % 128;
        }
    }

    public static void d() {
        int iE = gn.AnonymousClass8.e();
        int iE2 = gn.AnonymousClass8.e();
        int iE3 = gn.AnonymousClass8.e();
        d(-397373399, gn.AnonymousClass8.e(), new Object[0], iE, 397373399, iE3, iE2);
    }

    private static void b(Context context) {
        if (context == null) {
            p = (s + 45) % 128;
            return;
        }
        Object[] objArr = {context, (a) a.class.getField("i").get(null)};
        int iE = gn.AnonymousClass8.e();
        int iE2 = gn.AnonymousClass8.e();
        d(1199165984, gn.AnonymousClass8.e(), objArr, iE, -1199165982, gn.AnonymousClass8.e(), iE2);
        int i2 = p + 57;
        s = i2 % 128;
        if (i2 % 2 != 0) {
            throw null;
        }
    }

    public static void b() throws Throwable {
        p = (s + 19) % 128;
        if (c(b.f)) {
            return;
        }
        boolean z = true;
        Object[] objArr = new Object[1];
        u(null, (ViewConfiguration.getWindowTouchSlop() >> 8) + 127, null, "\u0081\u0089\u0091\u0092\u0081\u0095\u0098\u0081\u0090\u0081\u0082\u0098", objArr);
        File file = new File(((String) objArr[0]).intern());
        if ((!file.exists()) || !file.isDirectory()) {
            z = false;
        } else {
            s = (p + 69) % 128;
            for (String str : h) {
                if (new File(file, str).exists()) {
                    break;
                }
            }
            z = false;
        }
        e(b.f, z);
    }

    public static void e(Context context, String str, Exception exc) {
        p = (s + 63) % 128;
        e(b.i, true);
        List<String> list = d;
        if (!list.contains(str)) {
            s = (p + 39) % 128;
            list.add(str);
        }
        t.d(context, c.UNEXPECTED_HOOK_CHECK_ERROR, str, exc);
        c();
    }

    /* JADX WARN: Removed duplicated region for block: B:40:0x0143  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public static synchronized void c(java.lang.String r17) {
        /*
            Method dump skipped, instruction units count: 435
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: com.facetec.sdk.cb.c(java.lang.String):void");
    }

    private static /* synthetic */ Object e(Object[] objArr) {
        int i2 = p + 69;
        s = i2 % 128;
        if (i2 % 2 == 0) {
            dj.a(new Runnable() { // from class: com.facetec.sdk.人神
                @Override // java.lang.Runnable
                public final void run() throws Throwable {
                    cb.m();
                }
            });
            int i3 = p + 9;
            s = i3 % 128;
            if (i3 % 2 == 0) {
                return null;
            }
            throw null;
        }
        dj.a(new Runnable() { // from class: com.facetec.sdk.人神
            @Override // java.lang.Runnable
            public final void run() throws Throwable {
                cb.m();
            }
        });
        throw null;
    }

    public static void e(Context context, a aVar) {
        int iE = gn.AnonymousClass8.e();
        int iE2 = gn.AnonymousClass8.e();
        int iE3 = gn.AnonymousClass8.e();
        d(1199165984, gn.AnonymousClass8.e(), new Object[]{context, aVar}, iE, -1199165982, iE3, iE2);
    }

    public static void e() {
        i = new char[]{8598, 8593, 8605, 8579, 8589, 8653, 8643, 8603, 8583, 8580, 8606, 8667, 8576, 8608, 8590, 8577, 8594, 8602, 8624, 8601, 8592, 8600, 8595, 8644, 8627, 8609, 8578, 8591, 8599, 8613};
        f95843g = 1071522293;
        m = true;
        o = true;
        l = 1940834760;
        k = 114796570;
        n = -457619204;
        t = new byte[]{-21, -21, -11, -43, ISOFileInfo.A1, ISO7816.INS_WRITE_BINARY, ISOFileInfo.A5, -86, -39, -78, -49, -34, -45, -94, -82, ISO7816.INS_WRITE_BINARY, -90, ISO7816.INS_ENVELOPE, -93, ISO7816.INS_PUT_DATA, -45, -92, -78, -5, ISOFileInfo.A1, ISOFileInfo.AB, -45, -87, -47, -83, PSSSigner.TRAILER_IMPLICIT, ISO7816.INS_READ_RECORD2, 24, -34, -81, -109, ISO7816.INS_DELETE_FILE, -37, -44, -39, -88, ISO7816.INS_WRITE_BINARY, -87, -6, -4, -59, -10, ISO7816.INS_WRITE_BINARY, -3, -7, -2, -1, -61, -84, 14, -59, ISO7816.INS_GET_DATA, -16, -61, -2, -47, -12, 49, -8, 122, 49, 53, 62, ISO7816.INS_CHANGE_CHV, 61, 2, 58, ISO7816.INS_UNBLOCK_CHV, 40, 4, ISO7816.INS_UNBLOCK_CHV, ISO7816.INS_DECREASE, -15, -83, 116, -81, -43, ISO7816.INS_READ_RECORD_STAMPED, ISO7816.INS_READ_BINARY_STAMPED, ISO7816.INS_READ_BINARY_STAMPED, ISO7816.INS_WRITE_BINARY, -88, -84};
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static /* synthetic */ void c(a aVar, Context context) {
        if (aVar == a.i) {
            if (context == null) {
                return;
            }
            s = (p + 37) % 128;
            if (d.c(context)) {
                return;
            }
        }
        b = aVar.j | b;
        i();
        int i2 = p + 15;
        s = i2 % 128;
        if (i2 % 2 != 0) {
            int i3 = 79 / 0;
        }
    }

    private static /* synthetic */ Object c(Object[] objArr) {
        s = (p + 39) % 128;
        Object[] objArr2 = {null, (a) a.class.getField("c").get(null)};
        int iE = gn.AnonymousClass8.e();
        int iE2 = gn.AnonymousClass8.e();
        d(1199165984, gn.AnonymousClass8.e(), objArr2, iE, -1199165982, gn.AnonymousClass8.e(), iE2);
        int i2 = s + 15;
        p = i2 % 128;
        if (i2 % 2 != 0) {
            return null;
        }
        throw null;
    }
}