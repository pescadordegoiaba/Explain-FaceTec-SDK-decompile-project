package com.facetec.sdk;

import android.animation.Animator;
import android.animation.ValueAnimator;
import android.app.Activity;
import android.graphics.drawable.GradientDrawable;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.view.WindowManager;
import android.view.animation.LinearInterpolator;
import android.widget.ImageView;
import com.facetec.sdk.FaceTecCancelButtonCustomization;
import com.facetec.sdk.FaceTecSDK;
import com.facetec.sdk.pg;
import com.google.android.gms.common.ConnectionResult;
import com.incode.welcome_sdk.modules.SelfieScan;
import java.lang.ref.WeakReference;
import java.util.ArrayList;
import java.util.Arrays;
import kotlin.C6852;

/* JADX INFO: loaded from: classes4.dex */
final class cc {
    static boolean c = false;
    private ValueAnimator f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    private Integer f95848g;
    private final WeakReference<bm> k;
    private Integer m;
    private Integer o;
    boolean e = false;
    private boolean j = false;
    boolean d = false;
    boolean a = false;
    float b = SelfieScan.RECOGNITION_FAIL_RESULT;
    private boolean h = false;
    final dg i = new dg();

    public cc(Activity activity) {
        this.k = new WeakReference<>((bm) activity);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void a(ValueAnimator valueAnimator) {
        this.m = (Integer) valueAnimator.getAnimatedValue();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void c(final FaceTecSessionActivity faceTecSessionActivity) {
        new Handler(Looper.getMainLooper()).postDelayed(new Runnable() { // from class: com.facetec.sdk.人鬼
            @Override // java.lang.Runnable
            public final void run() {
                this.f6992.d();
            }
        }, 500L);
        ValueAnimator valueAnimatorC = bh.c(faceTecSessionActivity.y, this.m.intValue(), dq.b(faceTecSessionActivity, dm.W()));
        valueAnimatorC.addUpdateListener(new ValueAnimator.AnimatorUpdateListener() { // from class: com.facetec.sdk.人魂
            @Override // android.animation.ValueAnimator.AnimatorUpdateListener
            public final void onAnimationUpdate(ValueAnimator valueAnimator) {
                this.f6993.a(valueAnimator);
            }
        });
        valueAnimatorC.start();
        ValueAnimator valueAnimatorC2 = bh.c(faceTecSessionActivity.N, this.f95848g.intValue(), dq.b(faceTecSessionActivity, dm.X()));
        valueAnimatorC2.addUpdateListener(new ValueAnimator.AnimatorUpdateListener() { // from class: com.facetec.sdk.人龙
            @Override // android.animation.ValueAnimator.AnimatorUpdateListener
            public final void onAnimationUpdate(ValueAnimator valueAnimator) {
                this.f6994.e(valueAnimator);
            }
        });
        valueAnimatorC2.start();
        ValueAnimator valueAnimatorE = bh.e(new ArrayList(Arrays.asList(faceTecSessionActivity.v, faceTecSessionActivity.u, faceTecSessionActivity.x)), (GradientDrawable) faceTecSessionActivity.v.getBackground(), (int) (bh.a(dm.l()) * dm.c()), this.o.intValue(), ((Integer) dm.e(pg.a.a(), pg.a.a(), -761605403, new Object[]{faceTecSessionActivity}, pg.a.a(), 761605409, pg.a.a())).intValue());
        valueAnimatorE.addUpdateListener(new ValueAnimator.AnimatorUpdateListener() { // from class: com.facetec.sdk.仙丹
            @Override // android.animation.ValueAnimator.AnimatorUpdateListener
            public final void onAnimationUpdate(ValueAnimator valueAnimator) {
                this.f6995.c(faceTecSessionActivity, valueAnimator);
            }
        });
        valueAnimatorE.start();
        if (faceTecSessionActivity.h != null) {
            faceTecSessionActivity.h.k();
        }
        if (faceTecSessionActivity.i != null) {
            faceTecSessionActivity.i.k();
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void e(ValueAnimator valueAnimator) {
        this.f95848g = (Integer) valueAnimator.getAnimatedValue();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void f() {
        this.e = false;
        this.d = true;
        a(a(), this.i.e(), 0);
        g();
    }

    private void g() {
        final FaceTecSessionActivity faceTecSessionActivity = (FaceTecSessionActivity) this.k.get();
        if (this.f95848g == null) {
            this.f95848g = Integer.valueOf(dq.b(faceTecSessionActivity, FaceTecSDK.d.h.backgroundColor));
        }
        if (this.m == null) {
            this.m = Integer.valueOf(dq.b(faceTecSessionActivity, FaceTecSDK.d.i.backgroundColors));
        }
        if (this.o == null) {
            this.o = Integer.valueOf(dq.b(faceTecSessionActivity, FaceTecSDK.d.o.borderColor));
        }
        faceTecSessionActivity.runOnUiThread(new Runnable() { // from class: com.facetec.sdk.人符
            @Override // java.lang.Runnable
            public final void run() {
                this.f6983.c(faceTecSessionActivity);
            }
        });
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void h() {
        ValueAnimator valueAnimator = this.f;
        if (valueAnimator != null) {
            valueAnimator.cancel();
            this.f.removeAllUpdateListeners();
        }
    }

    private float i() {
        return Settings.System.getInt(((FaceTecSessionActivity) this.k.get()).getContentResolver(), "screen_brightness") / 255.0f;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void j() {
        this.e = false;
        this.d = true;
        a(a(), this.i.c(), 0);
        g();
    }

    public final void b(Boolean bool) {
        if (FaceTecSDK.a()) {
            return;
        }
        if (this.h && bool.booleanValue()) {
            return;
        }
        if (c && bool.booleanValue()) {
            return;
        }
        if (bool.booleanValue()) {
            FaceTecSDK.c = FaceTecSDK.c.LOW_LIGHT_FROM_SENSOR;
        } else {
            if (cv.D()) {
                FaceTecSDK.c = FaceTecSDK.c.LOW_LIGHT_FROM_PHX_ENV;
            } else {
                FaceTecSDK.c = FaceTecSDK.c.LOW_LIGHT_FROM_PHX_FACE;
            }
            this.h = true;
        }
        cv.N(ao.ac, bool.booleanValue());
        cv.w();
        FaceTecSessionActivity faceTecSessionActivity = (FaceTecSessionActivity) this.k.get();
        if (faceTecSessionActivity != null) {
            faceTecSessionActivity.runOnUiThread(new Runnable() { // from class: com.facetec.sdk.人风
                @Override // java.lang.Runnable
                public final void run() {
                    this.f6991.f();
                }
            });
        }
    }

    public final void d() {
        FaceTecSessionActivity faceTecSessionActivity = (FaceTecSessionActivity) this.k.get();
        if (faceTecSessionActivity == null) {
            return;
        }
        if (FaceTecSDK.d.m.b == FaceTecCancelButtonCustomization.ButtonLocation.CUSTOM && FaceTecSDK.d.m.e != null) {
            int iAQ = dm.aQ();
            ImageView imageView = faceTecSessionActivity.w;
            if (imageView != null && iAQ != 0) {
                imageView.setImageDrawable(C6852.getDrawable(faceTecSessionActivity, iAQ));
            }
        }
        int iAH = dm.aH();
        if (FaceTecSDK.d.h.showBrandingImage && iAH != 0) {
            faceTecSessionActivity.J.setImageDrawable(C6852.getDrawable(faceTecSessionActivity, iAH));
        }
        faceTecSessionActivity.y.setBackground(dm.p(faceTecSessionActivity));
        if (faceTecSessionActivity.h != null) {
            faceTecSessionActivity.h.n();
        }
        if (faceTecSessionActivity.i != null) {
            faceTecSessionActivity.i.n();
        }
    }

    public final float a() {
        FaceTecSessionActivity faceTecSessionActivity = (FaceTecSessionActivity) this.k.get();
        if (faceTecSessionActivity == null) {
            return 0.5f;
        }
        float f = faceTecSessionActivity.getWindow().getAttributes().screenBrightness;
        if (f >= SelfieScan.RECOGNITION_FAIL_RESULT) {
            return f;
        }
        try {
            if (Settings.System.getInt(faceTecSessionActivity.getContentResolver(), "screen_brightness_mode") != 1) {
                return i();
            }
            try {
                return Settings.System.getFloat(faceTecSessionActivity.getContentResolver(), "screen_auto_brightness_adj");
            } catch (Settings.SettingNotFoundException unused) {
                return i();
            }
        } catch (Settings.SettingNotFoundException unused2) {
            return 0.5f;
        }
    }

    public final void e() {
        this.e = false;
        this.j = false;
        ValueAnimator valueAnimator = this.f;
        if (valueAnimator != null) {
            valueAnimator.cancel();
            this.f.removeAllUpdateListeners();
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static /* synthetic */ void e(FaceTecSessionActivity faceTecSessionActivity, ValueAnimator valueAnimator) {
        if (faceTecSessionActivity == null) {
            return;
        }
        WindowManager.LayoutParams attributes = faceTecSessionActivity.getWindow().getAttributes();
        attributes.screenBrightness = ((Float) valueAnimator.getAnimatedValue()).floatValue();
        faceTecSessionActivity.getWindow().setAttributes(attributes);
    }

    public final void a(final float f, final float f2, int i) {
        final FaceTecSessionActivity faceTecSessionActivity = (FaceTecSessionActivity) this.k.get();
        int i2 = this.a ? 750 : ConnectionResult.DRIVE_EXTERNAL_STORAGE_REQUIRED;
        ValueAnimator valueAnimator = this.f;
        if (valueAnimator != null) {
            valueAnimator.cancel();
            this.f.removeAllUpdateListeners();
        }
        ValueAnimator valueAnimatorOfFloat = ValueAnimator.ofFloat(f, f2);
        this.f = valueAnimatorOfFloat;
        valueAnimatorOfFloat.setDuration(i2);
        this.f.addUpdateListener(new ValueAnimator.AnimatorUpdateListener() { // from class: com.facetec.sdk.人道
            @Override // android.animation.ValueAnimator.AnimatorUpdateListener
            public final void onAnimationUpdate(ValueAnimator valueAnimator2) {
                cc.e(faceTecSessionActivity, valueAnimator2);
            }
        });
        this.f.setInterpolator(new LinearInterpolator());
        this.f.setStartDelay(i);
        this.f.addListener(new f() { // from class: com.facetec.sdk.人金
            @Override // android.animation.Animator.AnimatorListener
            public final void onAnimationEnd(Animator animator) {
                this.f6987.c(f2, f, animator);
            }
        });
        this.f.start();
    }

    public final void b() {
        FaceTecSDK.c cVar = FaceTecSDK.c;
        FaceTecSDK.c cVar2 = FaceTecSDK.c.BRIGHT_LIGHT;
        if (cVar == cVar2) {
            return;
        }
        FaceTecSDK.c = cVar2;
        this.h = true;
        cv.v();
        FaceTecSessionActivity faceTecSessionActivity = (FaceTecSessionActivity) this.k.get();
        if (faceTecSessionActivity != null) {
            faceTecSessionActivity.runOnUiThread(new Runnable() { // from class: com.facetec.sdk.人雨
                @Override // java.lang.Runnable
                public final void run() {
                    this.f6990.j();
                }
            });
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void c(FaceTecSessionActivity faceTecSessionActivity, ValueAnimator valueAnimator) {
        this.o = (Integer) valueAnimator.getAnimatedValue();
        faceTecSessionActivity.v.invalidate();
        faceTecSessionActivity.u.invalidate();
        faceTecSessionActivity.x.invalidate();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void c(float f, float f2, Animator animator) {
        if (!this.d && !this.a) {
            if (this.e && cv.i() == cu.ZOOM_CLOSE && !this.j && f == this.i.e()) {
                this.j = true;
                a(this.i.c(), this.i.b ? 0.5f : 0.8f, 1000);
                return;
            } else {
                if (this.e) {
                    a(f, f2, 1000);
                    return;
                }
                return;
            }
        }
        this.d = false;
        this.a = false;
    }

    public final void c() {
        if (this.f == null || a() == this.b) {
            return;
        }
        this.a = true;
        a(a(), this.b, 0);
        new Handler().postDelayed(new Runnable() { // from class: com.facetec.sdk.人药
            @Override // java.lang.Runnable
            public final void run() {
                this.f6985.h();
            }
        }, 800L);
    }
}