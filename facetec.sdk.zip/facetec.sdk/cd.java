package com.facetec.sdk;

import ai.luciq.library.core.eventbus.coreeventbus.IBGCoreEventBusKt;
import android.content.Context;
import android.graphics.ImageFormat;
import android.media.AudioTrack;
import android.os.Process;
import android.os.SystemClock;
import android.text.TextUtils;
import android.util.Base64;
import android.view.KeyEvent;
import android.view.View;
import android.view.ViewConfiguration;
import com.incode.welcome_sdk.modules.SelfieScan;
import java.io.IOException;
import java.io.StringReader;
import java.lang.reflect.Method;
import java.security.KeyFactory;
import java.security.PublicKey;
import java.security.Signature;
import java.security.spec.X509EncodedKeySpec;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.Date;
import java.util.Locale;
import java.util.Properties;
import java.util.concurrent.TimeUnit;

/* JADX INFO: loaded from: classes4.dex */
class cd {
    private static final byte[] $$a = null;
    private static final int $$b = 0;
    private static int $10;
    private static int $11;
    private static char a;
    private static char b;
    private static char c;
    private static /* synthetic */ boolean d;
    private static char e;
    private static int f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    private static int f95849g;
    private static int h;
    private static int i;

    public enum b {
        NOT_PRESENT,
        INVALID,
        VALIDATED
    }

    private static String $$c(int i2, int i3, int i4) {
        byte[] bArr = $$a;
        int i5 = i2 * 2;
        int i6 = (i4 * 2) + 112;
        int i7 = 3 - (i3 * 4);
        byte[] bArr2 = new byte[i5 + 1];
        int i8 = -1;
        if (bArr == null) {
            i6 = (-i6) + i5;
            bArr = bArr;
            i8 = -1;
        }
        while (true) {
            int i9 = i8 + 1;
            i7++;
            bArr2[i9] = (byte) i6;
            if (i9 == i5) {
                return new String(bArr2, 0);
            }
            i6 = (-bArr[i7]) + i6;
            bArr = bArr;
            i8 = i9;
        }
    }

    static {
        init$0();
        $10 = 0;
        $11 = 1;
        h = 0;
        f95849g = 1;
        f = 0;
        i = 1;
        e();
        ViewConfiguration.getKeyRepeatDelay();
        View.getDefaultSize(0, 0);
        int i2 = (h + 111) % 128;
        f95849g = i2;
        h = (i2 + 119) % 128;
        d = true;
    }

    private static boolean b(byte[] bArr, byte[] bArr2) throws Throwable {
        Object[] objArr = new Object[1];
        j("ՙ\ue347ﮯᝀ♰铞㪻瑃缸홻⨧䌓䈣㱚᜴傢쁈䅯摂쵲缸홻⨧䌓䈣㱚Ϳ햚쁈䅯؎땕\ue6e2Ὠéꞏ헯嶑堮荁吶㑭魪빲櫶\uf5d1鋯ꙵ틤阥\udc9b詐囆䆧䚹▩哥ᶈࢮ挎陦䝶꜒퓷峉끱魡峗娪ݿ\uf510缷腆迁官ړ饧罍\uf283扽듔ෝ⇘\ue8f4偢轭䌪᪵ⷱ헓\ue19a賶蒔鹱퇺ꖖ\uea6d갗\ue0e4㓜䠈糤氞ↄ堮荁昕\uaad7외ጶꄾ\uf1a0몭\uecdb\ud952汬烩礚뮈鬤\ue94a핌\uf608뗧\ued35䰘", TextUtils.getOffsetAfter("", 0) + 126, objArr);
        PublicKey publicKeyGeneratePublic = KeyFactory.getInstance("EC").generatePublic(new X509EncodedKeySpec(Base64.decode(((String) objArr[0]).intern(), 0)));
        Signature signature = Signature.getInstance("SHA256withECDSA");
        signature.initVerify(publicKeyGeneratePublic);
        signature.update(bArr);
        boolean zVerify = signature.verify(bArr2);
        f = (i + 15) % 128;
        return zVerify;
    }

    public static b c(Context context, String str, String str2) throws Throwable {
        Properties properties = new Properties();
        try {
            properties.load(new StringReader(str));
            String property = properties.getProperty("expiryDate", "");
            String strReplaceAll = properties.getProperty("appId", "").replaceAll("\"", "");
            String property2 = properties.getProperty("key", "");
            if (property.isEmpty() || strReplaceAll.isEmpty() || property2.isEmpty()) {
                b bVar = b.INVALID;
                int i2 = i + 11;
                f = i2 % 128;
                if (i2 % 2 == 0) {
                    return bVar;
                }
                throw null;
            }
            String property3 = properties.getProperty(IBGCoreEventBusKt.TYPE_FEATURES, "");
            if (!e(context, strReplaceAll)) {
                return b.INVALID;
            }
            try {
                Date date = new SimpleDateFormat("yyyy-MM-dd", Locale.US).parse(property);
                int i3 = (f + 95) % 128;
                i = i3;
                int i4 = i3 + 43;
                f = i4 % 128;
                if (i4 % 2 != 0) {
                    strReplaceAll.equals("*");
                    throw null;
                }
                long j = strReplaceAll.equals("*") ? 7L : 14L;
                if (!d) {
                    f = (i + 7) % 128;
                    if (date == null) {
                        throw new AssertionError();
                    }
                }
                if (new Date().after(new Date(date.getTime() + TimeUnit.DAYS.toMillis(j)))) {
                    return b.INVALID;
                }
                byte[] bArrD = d(property2);
                byte[] bArrCopyOfRange = Arrays.copyOfRange(bArrD, 1, bArrD.length);
                try {
                    StringBuilder sb = new StringBuilder();
                    sb.append(str2);
                    sb.append(strReplaceAll);
                    sb.append(property);
                    sb.append(property3);
                    String string = sb.toString();
                    Object[] objArr = new Object[1];
                    j("ꅇ쓤ꐭꉧᦺ㔥䄲〳ⰺ呉懒ࡰ鮸后톍閑\u0ee3䂓穅뗀激뒯", 22 - (SystemClock.uptimeMillis() > 0L ? 1 : (SystemClock.uptimeMillis() == 0L ? 0 : -1)), objArr);
                    boolean zB = b(bp.b(((String) objArr[0]).intern().getBytes(), string), bArrCopyOfRange);
                    if (zB && !property3.isEmpty() && Arrays.asList(property3.split(",")).contains("rlo")) {
                        ce.c = true;
                    }
                    if (!zB) {
                        return b.INVALID;
                    }
                    int i5 = i + 1;
                    f = i5 % 128;
                    if (i5 % 2 == 0) {
                        return b.VALIDATED;
                    }
                    b bVar2 = b.NOT_PRESENT;
                    throw null;
                } catch (Exception unused) {
                    return b.INVALID;
                }
            } catch (ParseException unused2) {
                return b.INVALID;
            }
        } catch (IOException unused3) {
            return b.NOT_PRESENT;
        }
    }

    private static byte[] d(String str) {
        f = (i + 37) % 128;
        int length = str.length();
        byte[] bArr = new byte[length / 2];
        for (int i2 = 0; i2 < length; i2 += 2) {
            i = (f + 57) % 128;
            bArr[i2 / 2] = (byte) ((Character.digit(str.charAt(i2), 16) << 4) + Character.digit(str.charAt(i2 + 1), 16));
        }
        i = (f + 15) % 128;
        return bArr;
    }

    private static boolean e(Context context, String str) {
        boolean zEquals;
        String[] strArrSplit = str.split(",");
        int length = strArrSplit.length;
        int i2 = 0;
        while (i2 < length) {
            String str2 = strArrSplit[i2];
            if (str2.endsWith("*")) {
                f = (i + 67) % 128;
                zEquals = context.getPackageName().startsWith(str2.substring(0, str2.length() - 1));
                i = (f + 87) % 128;
            } else {
                zEquals = str2.equals(context.getPackageName());
            }
            if (zEquals) {
                i = (f + 69) % 128;
                return true;
            }
            i2++;
            i = (f + 23) % 128;
        }
        return false;
    }

    public static void init$0() {
        $$a = new byte[]{113, 46, 90, -12};
        $$b = 60;
    }

    private static void j(String str, int i2, Object[] objArr) throws Throwable {
        char[] charArray;
        if (str != null) {
            $11 = ($10 + 51) % 128;
            charArray = str.toCharArray();
        } else {
            charArray = str;
        }
        char[] cArr = charArray;
        hq hqVar = new hq();
        char[] cArr2 = new char[cArr.length];
        hqVar.d = 0;
        int i3 = 2;
        char[] cArr3 = new char[2];
        while (true) {
            int i4 = hqVar.d;
            if (i4 >= cArr.length) {
                objArr[0] = new String(cArr2, 0, i2);
                return;
            }
            cArr3[0] = cArr[i4];
            char c2 = 1;
            cArr3[1] = cArr[i4 + 1];
            $11 = ($10 + 25) % 128;
            int i5 = 58224;
            int i6 = 0;
            while (i6 < 16) {
                char c3 = cArr3[c2];
                char c4 = cArr3[0];
                char c5 = c2;
                int i7 = i3;
                char[] cArr4 = cArr3;
                int i8 = (c4 + i5) ^ ((c4 << 4) + ((char) (((long) e) ^ (-5528393735828501205L))));
                int i9 = c4 >>> 5;
                try {
                    Object[] objArr2 = new Object[4];
                    objArr2[3] = Integer.valueOf(b);
                    objArr2[i7] = Integer.valueOf(i9);
                    objArr2[c5] = Integer.valueOf(i8);
                    objArr2[0] = Integer.valueOf(c3);
                    Object objD = an.d(681770103);
                    Class cls = Integer.TYPE;
                    if (objD == null) {
                        objD = an.d(357 - (ViewConfiguration.getEdgeSlop() >> 16), (char) (1 - (AudioTrack.getMaxVolume() > SelfieScan.RECOGNITION_FAIL_RESULT ? 1 : (AudioTrack.getMaxVolume() == SelfieScan.RECOGNITION_FAIL_RESULT ? 0 : -1))), TextUtils.getCapsMode("", 0, 0) + 24, 1589849900, false, "s", new Class[]{cls, cls, cls, cls});
                    }
                    char cCharValue = ((Character) ((Method) objD).invoke(null, objArr2)).charValue();
                    cArr4[c5] = cCharValue;
                    char c6 = cArr4[0];
                    int i10 = (cCharValue + i5) ^ ((cCharValue << 4) + ((char) (((long) a) ^ (-5528393735828501205L))));
                    int i11 = cCharValue >>> 5;
                    Object[] objArr3 = new Object[4];
                    objArr3[3] = Integer.valueOf(c);
                    objArr3[i7] = Integer.valueOf(i11);
                    objArr3[c5] = Integer.valueOf(i10);
                    objArr3[0] = Integer.valueOf(c6);
                    Object objD2 = an.d(681770103);
                    if (objD2 == null) {
                        objD2 = an.d(((byte) KeyEvent.getModifierMetaStateMask()) + 358, (char) (1 - (ViewConfiguration.getZoomControlsTimeout() > 0L ? 1 : (ViewConfiguration.getZoomControlsTimeout() == 0L ? 0 : -1))), 23 - ImageFormat.getBitsPerPixel(0), 1589849900, false, "s", new Class[]{cls, cls, cls, cls});
                    }
                    cArr4[0] = ((Character) ((Method) objD2).invoke(null, objArr3)).charValue();
                    i5 -= 40503;
                    i6++;
                    c2 = c5;
                    i3 = i7;
                    cArr3 = cArr4;
                } catch (Throwable th) {
                    Throwable cause = th.getCause();
                    if (cause == null) {
                        throw th;
                    }
                    throw cause;
                }
            }
            int i12 = i3;
            char[] cArr5 = cArr3;
            char c7 = c2;
            int i13 = hqVar.d;
            cArr2[i13] = cArr5[0];
            cArr2[i13 + 1] = cArr5[c7];
            i3 = i12;
            Object[] objArr4 = new Object[i3];
            objArr4[c7] = hqVar;
            objArr4[0] = hqVar;
            Object objD3 = an.d(227457195);
            if (objD3 == null) {
                byte b2 = (byte) 0;
                byte b3 = b2;
                objD3 = an.d(1827 - TextUtils.getCapsMode("", 0, 0), (char) (Process.myTid() >> 22), 24 - ((Process.getThreadPriority(0) + 20) >> 6), 2079288304, false, $$c(b2, b3, b3), new Class[]{Object.class, Object.class});
            }
            ((Method) objD3).invoke(null, objArr4);
            cArr3 = cArr5;
        }
    }

    public static void e() {
        a = (char) 14693;
        c = (char) 14175;
        e = (char) 4452;
        b = (char) 47229;
    }
}