package com.facetec.sdk;

import android.app.Activity;
import android.app.PendingIntent;
import android.content.Intent;
import android.graphics.drawable.Drawable;
import android.os.Handler;
import android.os.Looper;
import android.view.ViewPropertyAnimator;
import androidx.vectordrawable.graphics.drawable.Animatable2Compat$AnimationCallback;
import com.facetec.sdk.FaceTecCancelButtonCustomization;
import com.facetec.sdk.au;
import com.facetec.sdk.eg;
import com.facetec.sdk.pg;
import com.incode.welcome_sdk.modules.SelfieScan;
import io.sentry.HttpStatusCodeRange;
import java.lang.ref.WeakReference;
import java.util.Objects;
import kotlin.C6852;
import org.bouncycastle.asn1.cmp.PKIFailureInfo;

/* JADX INFO: loaded from: classes4.dex */
final class cf {
    eg a;
    private final WeakReference<bm> b;
    private final cx e;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    private final boolean f95851g;
    private final Handler d = new Handler(Looper.getMainLooper());
    private boolean i = false;
    private boolean j = false;
    final eg.b c = new eg.b() { // from class: com.facetec.sdk.cf.5
        @Override // com.facetec.sdk.eg.b
        public final void d(ej ejVar, String str) throws Throwable {
            cf.c(cf.this, ejVar, str);
        }

        @Override // com.facetec.sdk.eg.b
        public final void e(eg.e eVar) throws Throwable {
            cf.e(cf.this, eVar.d.optString("debug", ""));
        }
    };

    /* JADX INFO: renamed from: com.facetec.sdk.cf$4, reason: invalid class name */
    public class AnonymousClass4 extends Animatable2Compat$AnimationCallback {
        public AnonymousClass4() {
        }

        /* JADX INFO: Access modifiers changed from: private */
        public /* synthetic */ void e() {
            dq.a(cf.this.e.b);
        }

        @Override // androidx.vectordrawable.graphics.drawable.Animatable2Compat$AnimationCallback
        public final void onAnimationEnd(Drawable drawable) {
            cf.this.e.c(new Runnable() { // from class: com.facetec.sdk.仙庙
                @Override // java.lang.Runnable
                public final void run() {
                    this.f7020.e();
                }
            });
        }
    }

    public cf(cx cxVar, boolean z, Activity activity) {
        this.e = cxVar;
        this.f95851g = z;
        this.b = new WeakReference<>((bm) activity);
    }

    private void a() {
        this.e.c(new Runnable() { // from class: com.facetec.sdk.仙宫
            @Override // java.lang.Runnable
            public final void run() {
                this.f7017.m();
            }
        });
    }

    private void b() {
        this.e.b.setImageDrawable(null);
    }

    private void e(boolean z) {
        float f = z ? 1.0f : SelfieScan.RECOGNITION_FAIL_RESULT;
        FaceTecSessionActivity faceTecSessionActivity = (FaceTecSessionActivity) this.e.getActivity();
        if (FaceTecSDK.d.m.b != FaceTecCancelButtonCustomization.ButtonLocation.CUSTOM) {
            this.e.f.animate().alpha(f).setDuration(500L).setListener(null).start();
            this.e.f.setEnabled(z);
        } else {
            faceTecSessionActivity.w.animate().alpha(f).setDuration(500L).setListener(null).start();
            faceTecSessionActivity.w.setEnabled(z);
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void f() {
        if (this.j) {
            return;
        }
        int i = (this.e.i.getAlpha() == 1.0f && this.e.i.isEnabled()) ? 0 : 4000;
        b(false);
        Handler handler = this.d;
        cx cxVar = this.e;
        Objects.requireNonNull(cxVar);
        handler.postDelayed(new au.c(new Runnable() { // from class: com.facetec.sdk.仙兵
            @Override // java.lang.Runnable
            public final void run() {
                this.f7001.j();
            }
        }), i);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void g() {
        if (this.i) {
            return;
        }
        ViewPropertyAnimator listener = this.e.i.animate().alpha(1.0f).setDuration(this.e.i.getAlpha() == 1.0f ? 0 : HttpStatusCodeRange.DEFAULT_MIN).setListener(null);
        cx cxVar = this.e;
        Objects.requireNonNull(cxVar);
        listener.withEndAction(new au.c(new Runnable() { // from class: com.facetec.sdk.仙人
            @Override // java.lang.Runnable
            public final void run() {
                this.f6999.f();
            }
        }));
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void h(boolean z) {
        h();
        if (!z) {
            this.e.h(new Runnable() { // from class: com.facetec.sdk.仙帝
                @Override // java.lang.Runnable
                public final void run() {
                    this.f7019.y();
                }
            });
            return;
        }
        ViewPropertyAnimator listener = this.e.c.animate().alpha(SelfieScan.RECOGNITION_FAIL_RESULT).setDuration(500L).setListener(null);
        cx cxVar = this.e;
        Objects.requireNonNull(cxVar);
        listener.withEndAction(new au.c(new Runnable() { // from class: com.facetec.sdk.仙山
            @Override // java.lang.Runnable
            public final void run() {
                this.f7018.v();
            }
        })).start();
    }

    private void i() {
        Handler handler = this.d;
        if (handler != null) {
            handler.removeCallbacksAndMessages(null);
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void j(boolean z) {
        int iIntValue;
        int iBk;
        int i = 0;
        if (this.f95851g) {
            iIntValue = dm.bg();
            iBk = dm.bi();
        } else {
            iIntValue = ((Integer) dm.e(pg.a.a(), pg.a.a(), 7039404, new Object[0], pg.a.a(), -7039367, pg.a.a())).intValue();
            iBk = dm.bk();
        }
        Activity activity = this.e.getActivity();
        if (z && iBk != 0) {
            i = iBk;
        } else if (!z && iIntValue != 0) {
            i = iIntValue;
        }
        if (i != 0) {
            dq.c(this.e.b, i, new AnonymousClass4(), true);
            return;
        }
        this.e.b.getLayoutParams().width = (int) (this.e.b.getLayoutParams().height * 0.875f);
        this.e.b.requestLayout();
        Drawable drawable = C6852.getDrawable(activity, R.drawable.facetec_internal_nfc);
        if (drawable != null) {
            this.e.b.setImageDrawable(drawable);
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void k() {
        b();
        this.e.e().setVisibility(8);
        this.e.d.setVisibility(0);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void l() {
        d(true);
        e(false);
        this.e.b.animate().alpha(SelfieScan.RECOGNITION_FAIL_RESULT).setDuration(500L).setListener(null).start();
        ViewPropertyAnimator listener = this.e.c.animate().alpha(SelfieScan.RECOGNITION_FAIL_RESULT).setDuration(500L).setListener(null);
        cx cxVar = this.e;
        Objects.requireNonNull(cxVar);
        listener.withEndAction(new au.c(new Runnable() { // from class: com.facetec.sdk.仙字
            @Override // java.lang.Runnable
            public final void run() {
                this.f7016.q();
            }
        })).start();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void m() {
        d(true);
        e(false);
        ViewPropertyAnimator listener = this.e.e.animate().alpha(SelfieScan.RECOGNITION_FAIL_RESULT).setDuration(500L).setListener(null);
        cx cxVar = this.e;
        Objects.requireNonNull(cxVar);
        listener.withEndAction(new au.c(new Runnable() { // from class: com.facetec.sdk.仙古
            @Override // java.lang.Runnable
            public final void run() {
                this.f7004.k();
            }
        })).start();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void n() {
        e eVar = this.e.i;
        eVar.b(false, eVar.getAlpha() > SelfieScan.RECOGNITION_FAIL_RESULT);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void o() {
        this.e.i.animate().alpha(SelfieScan.RECOGNITION_FAIL_RESULT).setDuration(500L).setListener(null).start();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void p() {
        h();
        this.e.b.animate().alpha(SelfieScan.RECOGNITION_FAIL_RESULT).setDuration(500L).setListener(null).start();
        ViewPropertyAnimator listener = this.e.c.animate().alpha(SelfieScan.RECOGNITION_FAIL_RESULT).setDuration(500L).setListener(null);
        cx cxVar = this.e;
        Objects.requireNonNull(cxVar);
        listener.withEndAction(new au.c(new Runnable() { // from class: com.facetec.sdk.仙剑
            @Override // java.lang.Runnable
            public final void run() {
                this.f7003.r();
            }
        })).start();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void q() {
        c(dm.a(ck.SCANNING, this.f95851g));
        this.e.b.animate().alpha(1.0f).setDuration(500L).setListener(null).start();
        this.e.c.animate().alpha(1.0f).setDuration(500L).setListener(null).start();
        this.e.b(new Runnable() { // from class: com.facetec.sdk.仙凤
            @Override // java.lang.Runnable
            public final void run() {
                this.f7002.t();
            }
        }, 100L);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void r() {
        c(dm.a(ck.WEAK_CONNECTION, this.f95851g));
        this.e.b.animate().alpha(1.0f).setDuration(500L).setListener(null).start();
        this.e.c.animate().alpha(1.0f).setDuration(500L).setListener(null).start();
        e(true);
        this.e.b(new Runnable() { // from class: com.facetec.sdk.仙国
            @Override // java.lang.Runnable
            public final void run() {
                this.f7008.s();
            }
        }, 100L);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void s() {
        c(false);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void t() {
        c(true);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void u() {
        c(false);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void v() {
        c(dm.a(ck.STARTING, this.f95851g));
        this.e.c.animate().alpha(1.0f).setDuration(500L).setListener(null).start();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void y() {
        FaceTecSessionActivity faceTecSessionActivity = (FaceTecSessionActivity) this.e.getActivity();
        if (faceTecSessionActivity == null) {
            return;
        }
        FaceTecCancelButtonCustomization.ButtonLocation buttonLocation = FaceTecSDK.d.m.b;
        FaceTecCancelButtonCustomization.ButtonLocation buttonLocation2 = FaceTecCancelButtonCustomization.ButtonLocation.CUSTOM;
        if (buttonLocation != buttonLocation2 && FaceTecSDK.d.m.b != FaceTecCancelButtonCustomization.ButtonLocation.DISABLED) {
            this.e.f.setVisibility(0);
        } else if (FaceTecSDK.d.m.b == buttonLocation2) {
            faceTecSessionActivity.w.setVisibility(0);
            faceTecSessionActivity.w.setAlpha(SelfieScan.RECOGNITION_FAIL_RESULT);
        }
        if (!eg.a(this.e.getActivity()) || eg.d(faceTecSessionActivity)) {
            c(dm.a(ck.STARTING, this.f95851g));
        } else {
            d(true);
            faceTecSessionActivity.D();
            c(dm.a(ck.DISABLED, this.f95851g));
        }
        this.e.e.animate().alpha(1.0f).setDuration(500L).setListener(null).start();
        this.e.e().animate().alpha(1.0f).setDuration(500L).setListener(null).start();
        e(true);
        this.e.b(new Runnable() { // from class: com.facetec.sdk.仙仙
            @Override // java.lang.Runnable
            public final void run() {
                this.f7000.u();
            }
        }, 100L);
    }

    public final void d() {
        this.e.c(new Runnable() { // from class: com.facetec.sdk.仙名
            @Override // java.lang.Runnable
            public final void run() {
                this.f7007.l();
            }
        });
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void a(String str) {
        this.e.c.setText(str);
    }

    private void b(boolean z) {
        this.j = z;
        if (z) {
            i();
            this.e.c(new Runnable() { // from class: com.facetec.sdk.仙妖
                @Override // java.lang.Runnable
                public final void run() {
                    this.f7015.n();
                }
            });
        }
    }

    private void c(final boolean z) {
        b();
        this.e.c(new Runnable() { // from class: com.facetec.sdk.仙城
            @Override // java.lang.Runnable
            public final void run() {
                this.f7012.j(z);
            }
        });
    }

    private void d(boolean z) {
        this.i = z;
        if (z) {
            i();
            b(true);
            this.e.c(new Runnable() { // from class: com.facetec.sdk.仙土
                @Override // java.lang.Runnable
                public final void run() {
                    this.f7009.o();
                }
            });
        }
    }

    private void a(boolean z) {
        FaceTecSessionActivity faceTecSessionActivity = (FaceTecSessionActivity) this.b.get();
        a();
        faceTecSessionActivity.q = true;
        faceTecSessionActivity.b(z);
    }

    private void c(final String str) {
        if (this.e.getActivity() == null) {
            return;
        }
        this.e.c(new Runnable() { // from class: com.facetec.sdk.仙史
            @Override // java.lang.Runnable
            public final void run() {
                this.f7005.a(str);
            }
        });
    }

    private void h() {
        int i;
        if (((FaceTecSessionActivity) this.b.get()).p) {
            return;
        }
        if (this.e.i.getAlpha() == 1.0f) {
            i = 0;
        } else {
            i = bj.a ? 30000 : 6000;
        }
        i();
        d(false);
        b(false);
        Handler handler = this.d;
        cx cxVar = this.e;
        Objects.requireNonNull(cxVar);
        handler.postDelayed(new au.c(new Runnable() { // from class: com.facetec.sdk.仙书
            @Override // java.lang.Runnable
            public final void run() {
                this.f6998.g();
            }
        }), i);
    }

    public final void c(boolean z, final boolean z2) {
        FaceTecSessionActivity faceTecSessionActivity = (FaceTecSessionActivity) this.b.get();
        if (faceTecSessionActivity.q || faceTecSessionActivity.t) {
            return;
        }
        if (this.a == null) {
            this.a = eg.b(faceTecSessionActivity, faceTecSessionActivity.C, bj.j);
        }
        eg egVar = this.a;
        if (egVar == null) {
            a(false);
            return;
        }
        if (faceTecSessionActivity.G) {
            return;
        }
        try {
            String str = faceTecSessionActivity.l;
            Activity activity = egVar.c.get();
            if (activity == null) {
                t.c(faceTecSessionActivity, ej.Unknown, "did not start");
                a(false);
                return;
            }
            egVar.a = str;
            Intent intent = new Intent(activity, (Class<?>) FaceTecSessionActivity.class);
            intent.addFlags(PKIFailureInfo.duplicateCertReq);
            egVar.e.enableForegroundDispatch(activity, PendingIntent.getActivity(activity, 0, intent, eg.e()), null, new String[][]{new String[]{"android.nfc.tech.IsoDep"}});
            if (z || this.e.getActivity() == null) {
                return;
            }
            this.e.c(new Runnable() { // from class: com.facetec.sdk.仙地
                @Override // java.lang.Runnable
                public final void run() {
                    this.f7010.h(z2);
                }
            });
        } catch (Exception e) {
            e.printStackTrace();
            t.c(faceTecSessionActivity, ej.Unknown, e.getMessage());
            a(false);
        }
    }

    public final void e() {
        FaceTecSessionActivity faceTecSessionActivity = (FaceTecSessionActivity) this.b.get();
        eg egVar = this.a;
        if (egVar != null) {
            if (!faceTecSessionActivity.G) {
                try {
                    egVar.c();
                } catch (Exception unused) {
                }
            }
            this.a = null;
        }
    }

    public static /* synthetic */ void e(cf cfVar, String str) throws Throwable {
        FaceTecSessionActivity faceTecSessionActivity = (FaceTecSessionActivity) cfVar.b.get();
        faceTecSessionActivity.t = false;
        cfVar.e();
        if (!str.isEmpty()) {
            t.c(faceTecSessionActivity, ej.Unknown, str);
        }
        cfVar.a(true);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void j() {
        if (this.j || this.e.i.getAlpha() != 1.0f || this.e.i.isEnabled()) {
            return;
        }
        e eVar = this.e.i;
        eVar.b(true, eVar.getAlpha() > SelfieScan.RECOGNITION_FAIL_RESULT);
    }

    public final void c() {
        FaceTecSessionActivity faceTecSessionActivity = (FaceTecSessionActivity) this.b.get();
        e();
        a();
        faceTecSessionActivity.q = true;
        faceTecSessionActivity.F = true;
        faceTecSessionActivity.z();
    }

    /* JADX WARN: Code restructure failed: missing block: B:11:0x0030, code lost:
    
        if (r4 > 5) goto L13;
     */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public static /* synthetic */ void c(final com.facetec.sdk.cf r2, com.facetec.sdk.ej r3, java.lang.String r4) throws java.lang.Throwable {
        /*
            java.lang.ref.WeakReference<com.facetec.sdk.bm> r0 = r2.b
            java.lang.Object r0 = r0.get()
            com.facetec.sdk.FaceTecSessionActivity r0 = (com.facetec.sdk.FaceTecSessionActivity) r0
            r1 = 0
            r0.t = r1
            r2.e()
            com.facetec.sdk.t.c(r0, r3, r4)
            com.facetec.sdk.ej r4 = com.facetec.sdk.ej.ConnectionError
            if (r3 == r4) goto L19
            com.facetec.sdk.ej r4 = com.facetec.sdk.ej.UnknownRetry
            if (r3 != r4) goto L33
        L19:
            java.lang.ref.WeakReference<com.facetec.sdk.bm> r3 = r2.b
            java.lang.Object r3 = r3.get()
            com.facetec.sdk.FaceTecSessionActivity r3 = (com.facetec.sdk.FaceTecSessionActivity) r3
            boolean r4 = r3.p
            r0 = 1
            if (r4 != 0) goto L37
            int r4 = r3.r
            int r4 = r4 + r0
            r3.r = r4
            com.facetec.sdk.cx r3 = r2.e
            if (r3 == 0) goto L37
            r3 = 5
            if (r4 > r3) goto L33
            goto L37
        L33:
            r2.a(r1)
            return
        L37:
            r2.c(r0, r1)
            com.facetec.sdk.cx r3 = r2.e
            com.facetec.sdk.仙天 r4 = new com.facetec.sdk.仙天
            r4.<init>()
            r3.c(r4)
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: com.facetec.sdk.cf.c(com.facetec.sdk.cf, com.facetec.sdk.ej, java.lang.String):void");
    }
}