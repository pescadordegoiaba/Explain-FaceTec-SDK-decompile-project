package com.facetec.sdk;

import android.content.Context;
import android.graphics.Color;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.os.Handler;
import android.os.Looper;
import android.os.Process;
import android.text.TextUtils;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.ViewConfiguration;
import android.widget.ExpandableListView;
import androidx.annotation.NonNull;
import com.incode.welcome_sdk.modules.SelfieScan;
import java.lang.ref.WeakReference;
import java.lang.reflect.Field;
import java.util.Timer;

/* JADX INFO: loaded from: classes4.dex */
class cg implements SensorEventListener {
    private static /* synthetic */ boolean j = true;
    private Timer c;
    private Context d;
    private Timer e;

    @NonNull
    private WeakReference<e> a = new WeakReference<>(null);

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    @NonNull
    private WeakReference<cp> f95852g = new WeakReference<>(null);
    private boolean h = false;
    private boolean f = false;
    private int i = 0;
    private Sensor b = d().getDefaultSensor(5);

    @FunctionalInterface
    public interface e {
        void onDarkLightDetected();
    }

    private cg(Context context) {
        this.d = context.getApplicationContext();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void a(cg cgVar) {
        d().registerListener(cgVar, this.b, 0);
    }

    public static cg b(Context context) {
        if (context == null) {
            return null;
        }
        return new cg(context);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void c() {
        e eVar = this.a.get();
        if (eVar != null) {
            eVar.onDarkLightDetected();
            a();
        }
    }

    private SensorManager d() {
        return (SensorManager) this.d.getSystemService("sensor");
    }

    private void e() {
        Timer timer = this.e;
        if (timer != null) {
            timer.cancel();
            this.e = null;
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void j() throws Throwable {
        Object objF$35266171;
        this.i++;
        cp cpVar = this.f95852g.get();
        if (cpVar != null) {
            if ((!this.f || this.i > 1) && (objF$35266171 = cpVar.f$35266171()) != null) {
                Object objD = an.d(1008020084);
                if (objD == null) {
                    objD = an.d((ExpandableListView.getPackedPositionForChild(0, 0) > 0L ? 1 : (ExpandableListView.getPackedPositionForChild(0, 0) == 0L ? 0 : -1)) + 1, (char) Color.alpha(0), (Process.myTid() >> 22) + 24, 1249179951, false, "c", null);
                }
                byte[] bArr = (byte[]) ((Field) objD).get(objF$35266171);
                Object objD2 = an.d(1008943605);
                float f = SelfieScan.RECOGNITION_FAIL_RESULT;
                if (objD2 == null) {
                    objD2 = an.d(Gravity.getAbsoluteGravity(0, 0), (char) (ViewConfiguration.getScrollDefaultDelay() >> 16), 25 - (ViewConfiguration.getScrollFriction() > SelfieScan.RECOGNITION_FAIL_RESULT ? 1 : (ViewConfiguration.getScrollFriction() == SelfieScan.RECOGNITION_FAIL_RESULT ? 0 : -1)), 1245876910, false, "d", null);
                }
                int i = ((Field) objD2).getInt(objF$35266171);
                Object objD3 = an.d(1006173042);
                if (objD3 == null) {
                    objD3 = an.d(TextUtils.getCapsMode("", 0, 0), (char) ((-1) - MotionEvent.axisFromString("")), 23 - TextUtils.indexOf((CharSequence) "", '0', 0), 1301882921, false, "a", null);
                }
                int i2 = ((Field) objD3).getInt(objF$35266171);
                if (!j && Looper.myLooper() == Looper.getMainLooper()) {
                    throw new AssertionError();
                }
                int i3 = i * i2;
                int i4 = i3 / 4;
                int i5 = 0;
                for (int i6 = 1; i6 <= i3; i6 += 4) {
                    i5 += bArr[i6 - 1] & 255;
                    if (i6 % 8421504 == 0) {
                        f += i5 / i4;
                        i5 = 0;
                    }
                }
                if (((int) (f + (i5 / i4))) < 75.0f) {
                    b();
                } else {
                    e();
                }
            }
        }
    }

    @Override // android.hardware.SensorEventListener
    public void onAccuracyChanged(Sensor sensor, int i) {
    }

    @Override // android.hardware.SensorEventListener
    public void onSensorChanged(SensorEvent sensorEvent) {
        if (this.h) {
            return;
        }
        this.i = 0;
        if (sensorEvent.values[0] < 3.0f) {
            b();
        } else {
            e();
        }
    }

    private synchronized void b() {
        if (this.e == null) {
            Timer timer = new Timer();
            this.e = timer;
            try {
                timer.schedule(new dl(new Runnable() { // from class: com.facetec.sdk.仙弓
                    @Override // java.lang.Runnable
                    public final void run() {
                        this.f7021.c();
                    }
                }), 200L);
            } catch (IllegalStateException unused) {
            }
        }
    }

    public final synchronized void d(e eVar, cp cpVar) {
        try {
            this.a = new WeakReference<>(eVar);
            this.f95852g = new WeakReference<>(cpVar);
            if (this.b != null) {
                new Handler().postDelayed(new Runnable() { // from class: com.facetec.sdk.仙日
                    @Override // java.lang.Runnable
                    public final void run() {
                        this.f7024.a(this);
                    }
                }, 50L);
                this.f = true;
            }
            dl dlVar = new dl(new Runnable() { // from class: com.facetec.sdk.仙星
                @Override // java.lang.Runnable
                public final void run() throws Throwable {
                    this.f7026.j();
                }
            });
            Timer timer = new Timer();
            this.c = timer;
            try {
                timer.scheduleAtFixedRate(dlVar, 500L, 1000L);
            } catch (IllegalStateException unused) {
            }
        } catch (Throwable th) {
            throw th;
        }
    }

    public final void a() {
        this.h = true;
        final Sensor sensor = this.b;
        if (sensor != null) {
            this.b = null;
            dj.a(new Runnable() { // from class: com.facetec.sdk.仙战
                @Override // java.lang.Runnable
                public final void run() {
                    this.f7022.a(sensor);
                }
            });
        }
        e();
        Timer timer = this.c;
        if (timer != null) {
            timer.cancel();
            this.c = null;
        }
        this.a.clear();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void a(Sensor sensor) {
        d().unregisterListener(this, sensor);
    }
}