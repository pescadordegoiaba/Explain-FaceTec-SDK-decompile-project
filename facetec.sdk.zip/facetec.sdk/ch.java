package com.facetec.sdk;

import android.animation.ArgbEvaluator;
import android.animation.ValueAnimator;
import android.annotation.SuppressLint;
import android.app.Activity;
import android.graphics.PorterDuff;
import android.graphics.Rect;
import android.graphics.Typeface;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.GradientDrawable;
import android.media.AudioTrack;
import android.os.Build;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewConfiguration;
import android.view.ViewGroup;
import android.view.ViewTreeObserver;
import android.view.inputmethod.InputMethodManager;
import android.widget.EditText;
import android.widget.ExpandableListView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.vectordrawable.graphics.drawable.Animatable2Compat$AnimationCallback;
import com.facetec.sdk.au;
import com.facetec.sdk.pg;
import com.incode.welcome_sdk.modules.SelfieScan;
import com.plaid.internal.EnumC41897g;
import java.lang.reflect.Method;
import kotlin.C6852;
import net.sf.scuba.smartcards.ISO7816;
import net.sf.scuba.smartcards.ISOFileInfo;
import org.bouncycastle.i18n.LocalizedMessage;
import org.json.JSONException;
import org.json.JSONObject;

/* JADX INFO: loaded from: classes4.dex */
public final class ch extends au {
    private static final byte[] $$a = null;
    private static final int $$b = 0;
    private static char[] D;
    private EditText C;
    JSONObject a;
    e b;
    RelativeLayout c;
    LinearLayout d;
    ScrollView e;
    TextView f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    LinearLayout f95853g;
    ImageView h;
    int i;
    Drawable j;
    final float n;
    int o;
    private LinearLayout p;
    final float q;
    private View r;
    final int s;
    private View t;
    private TextView u;
    private View v;
    private RelativeLayout y;
    boolean l = false;
    boolean k = true;
    boolean m = true;
    private boolean w = true;
    private boolean x = false;
    private boolean A = false;
    private final ViewTreeObserver.OnGlobalLayoutListener B = new AnonymousClass3();
    private float z = dm.b();

    /* JADX INFO: renamed from: com.facetec.sdk.ch$1, reason: invalid class name */
    public class AnonymousClass1 extends Animatable2Compat$AnimationCallback {
        public AnonymousClass1() {
        }

        /* JADX INFO: Access modifiers changed from: private */
        public /* synthetic */ void a() {
            dq.a(ch.this.h);
        }

        @Override // androidx.vectordrawable.graphics.drawable.Animatable2Compat$AnimationCallback
        public final void onAnimationEnd(Drawable drawable) {
            ch.this.c(new Runnable() { // from class: com.facetec.sdk.仙风
                @Override // java.lang.Runnable
                public final void run() {
                    this.f7050.a();
                }
            });
        }
    }

    /* JADX WARN: Removed duplicated region for block: B:10:0x0024  */
    /* JADX WARN: Removed duplicated region for block: B:8:0x001e  */
    /* JADX WARN: Unsupported multi-entry loop pattern (BACK_EDGE: B:10:0x0024 -> B:11:0x002b). Please report as a decompilation issue!!! */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    private static java.lang.String $$c(byte r7, int r8, int r9) {
        /*
            int r9 = r9 * 2
            int r9 = r9 + 1
            int r8 = r8 + 66
            byte[] r0 = com.facetec.sdk.ch.$$a
            int r7 = r7 + 5
            byte[] r1 = new byte[r9]
            r2 = 0
            if (r0 != 0) goto L14
            r8 = r7
            r3 = r0
            r5 = r2
            r0 = r9
            goto L2b
        L14:
            r3 = r2
        L15:
            byte r4 = (byte) r8
            int r5 = r3 + 1
            r1[r3] = r4
            int r7 = r7 + 1
            if (r5 != r9) goto L24
            java.lang.String r7 = new java.lang.String
            r7.<init>(r1, r2)
            return r7
        L24:
            r3 = r0[r7]
            r6 = r8
            r8 = r7
            r7 = r3
            r3 = r0
            r0 = r6
        L2b:
            int r7 = -r7
            int r7 = r7 + r0
            r0 = r8
            r8 = r7
            r7 = r0
            r0 = r3
            r3 = r5
            goto L15
        */
        throw new UnsupportedOperationException("Method not decompiled: com.facetec.sdk.ch.$$c(byte, int, int):java.lang.String");
    }

    static {
        init$0();
        D = new char[]{18236, 18367, 18365, 18355, 18365, 18365, 18321, 18331, 18352, 18353, 18364, 18332, 18326, 18352, 17984, 17989, 18236, 18362, 17987, 18362, 17990, 17991, 18362, 17988, 17985};
    }

    public ch() {
        float fC = dm.c();
        this.n = fC;
        this.q = this.z * fC;
        int iA = pg.a.a();
        this.s = ((Integer) dm.e(pg.a.a(), iA, 1933108801, new Object[0], pg.a.a(), -1933108792, pg.a.a())).intValue();
    }

    private static void E(int[] iArr, String str, boolean z, Object[] objArr) throws Throwable {
        byte b;
        int i;
        byte[] bArr;
        int i2;
        char[] cArr;
        String str2 = str;
        Object bytes = str2;
        if (str2 != null) {
            bytes = str2.getBytes(LocalizedMessage.DEFAULT_ENCODING);
        }
        byte[] bArr2 = (byte[]) bytes;
        hk hkVar = new hk();
        int i3 = 0;
        int i4 = iArr[0];
        int i5 = iArr[1];
        int i6 = iArr[2];
        int i7 = iArr[3];
        char[] cArr2 = D;
        char c = '0';
        Class cls = Integer.TYPE;
        if (cArr2 != null) {
            int length = cArr2.length;
            char[] cArr3 = new char[length];
            b = 1;
            int i8 = 0;
            while (i8 < length) {
                try {
                    int i9 = i3;
                    Object[] objArr2 = {Integer.valueOf(cArr2[i8])};
                    Object objD = an.d(-803102734);
                    if (objD == null) {
                        int iLastIndexOf = TextUtils.lastIndexOf("", c) + 1757;
                        char cAxisFromString = (char) (MotionEvent.axisFromString("") + 1);
                        int maxKeyCode = 24 - (KeyEvent.getMaxKeyCode() >> 16);
                        bArr = bArr2;
                        byte b2 = $$a[i9];
                        i2 = i8;
                        byte b3 = (byte) (b2 - 1);
                        cArr = cArr3;
                        objD = an.d(iLastIndexOf, cAxisFromString, maxKeyCode, -1505735511, false, $$c(b3, (byte) (-b3), b2), new Class[]{cls});
                    } else {
                        bArr = bArr2;
                        i2 = i8;
                        cArr = cArr3;
                    }
                    cArr[i2] = ((Character) ((Method) objD).invoke(null, objArr2)).charValue();
                    i8 = i2 + 1;
                    i3 = i9;
                    bArr2 = bArr;
                    cArr3 = cArr;
                    c = '0';
                } catch (Throwable th) {
                    Throwable cause = th.getCause();
                    if (cause == null) {
                        throw th;
                    }
                    throw cause;
                }
            }
            cArr2 = cArr3;
        } else {
            b = 1;
        }
        byte[] bArr3 = bArr2;
        int i10 = i3;
        char[] cArr4 = new char[i5];
        System.arraycopy(cArr2, i4, cArr4, i10, i5);
        if (bArr3 != null) {
            char[] cArr5 = new char[i5];
            hkVar.a = i10;
            char c2 = 0;
            while (true) {
                int i11 = hkVar.a;
                if (i11 >= i5) {
                    break;
                }
                byte b4 = b;
                if (bArr3[i11] == b4) {
                    char c3 = cArr4[i11];
                    Object[] objArr3 = new Object[2];
                    objArr3[b4] = Integer.valueOf(c2);
                    objArr3[0] = Integer.valueOf(c3);
                    Object objD2 = an.d(663167313);
                    if (objD2 == null) {
                        objD2 = an.d((ViewConfiguration.getScrollBarSize() >> 8) + 2017, (char) (14311 - (ExpandableListView.getPackedPositionForGroup(0) > 0L ? 1 : (ExpandableListView.getPackedPositionForGroup(0) == 0L ? 0 : -1))), 24 - View.MeasureSpec.makeMeasureSpec(0, 0), 1374089738, false, "D", new Class[]{cls, cls});
                    }
                    cArr5[i11] = ((Character) ((Method) objD2).invoke(null, objArr3)).charValue();
                } else {
                    Object[] objArr4 = {Integer.valueOf(cArr4[i11]), Integer.valueOf(c2)};
                    Object objD3 = an.d(-537001977);
                    if (objD3 == null) {
                        int i12 = 1139 - (AudioTrack.getMaxVolume() > SelfieScan.RECOGNITION_FAIL_RESULT ? 1 : (AudioTrack.getMaxVolume() == SelfieScan.RECOGNITION_FAIL_RESULT ? 0 : -1));
                        char cIndexOf = (char) (12388 - TextUtils.indexOf("", "", 0));
                        int defaultSize = 24 - View.getDefaultSize(0, 0);
                        byte b5 = $$a[0];
                        byte b6 = (byte) (b5 - 1);
                        byte b7 = b5;
                        objD3 = an.d(i12, cIndexOf, defaultSize, -1449143460, false, $$c(b6, b7, b7), new Class[]{cls, cls});
                    }
                    cArr5[i11] = ((Character) ((Method) objD3).invoke(null, objArr4)).charValue();
                }
                c2 = cArr5[hkVar.a];
                Object[] objArr5 = {hkVar, hkVar};
                Object objD4 = an.d(693882396);
                if (objD4 == null) {
                    int iIndexOf = TextUtils.indexOf("", "", 0) + 1803;
                    char pressedStateDuration = (char) (9692 - (ViewConfiguration.getPressedStateDuration() >> 16));
                    int iLastIndexOf2 = TextUtils.lastIndexOf("", '0') + 25;
                    byte b8 = $$a[0];
                    byte b9 = (byte) (b8 - 1);
                    objD4 = an.d(iIndexOf, pressedStateDuration, iLastIndexOf2, 1597644103, false, $$c(b9, (byte) (b9 & 56), b8), new Class[]{Object.class, Object.class});
                }
                ((Method) objD4).invoke(null, objArr5);
                b = 1;
            }
            cArr4 = cArr5;
        }
        if (i7 > 0) {
            char[] cArr6 = new char[i5];
            i = 0;
            System.arraycopy(cArr4, 0, cArr6, 0, i5);
            int i13 = i5 - i7;
            System.arraycopy(cArr6, 0, cArr4, i13, i7);
            System.arraycopy(cArr6, i7, cArr4, 0, i13);
        } else {
            i = 0;
        }
        if (z) {
            char[] cArr7 = new char[i5];
            hkVar.a = i;
            while (true) {
                int i14 = hkVar.a;
                if (i14 >= i5) {
                    break;
                }
                cArr7[i14] = cArr4[(i5 - i14) - 1];
                hkVar.a = i14 + 1;
            }
            cArr4 = cArr7;
        }
        if (i6 > 0) {
            hkVar.a = 0;
            while (true) {
                int i15 = hkVar.a;
                if (i15 >= i5) {
                    break;
                }
                cArr4[i15] = (char) (cArr4[i15] - iArr[2]);
                hkVar.a = i15 + 1;
            }
        }
        objArr[0] = new String(cArr4);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void a(au.c cVar) {
        this.y.animate().alpha(SelfieScan.RECOGNITION_FAIL_RESULT).setDuration(500L).setStartDelay(0L).setListener(null).start();
        this.b.animate().alpha(SelfieScan.RECOGNITION_FAIL_RESULT).setDuration(500L).setStartDelay(0L).setListener(null).start();
        this.e.animate().alpha(SelfieScan.RECOGNITION_FAIL_RESULT).setDuration(500L).setStartDelay(0L).setListener(null).withEndAction(cVar).start();
    }

    /* JADX WARN: Removed duplicated region for block: B:82:0x01d1  */
    /* JADX WARN: Removed duplicated region for block: B:99:? A[RETURN, SYNTHETIC] */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    private java.lang.String b(java.lang.String r18, java.lang.String r19, java.lang.String r20, java.lang.String r21) {
        /*
            Method dump skipped, instruction units count: 467
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: com.facetec.sdk.ch.b(java.lang.String, java.lang.String, java.lang.String, java.lang.String):java.lang.String");
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ boolean c(View view, MotionEvent motionEvent) {
        EditText editText;
        if (motionEvent.getAction() == 0 && (editText = this.C) != null && editText.isFocused()) {
            Rect rect = new Rect();
            this.C.getGlobalVisibleRect(rect);
            if (!rect.contains((int) motionEvent.getRawX(), (int) motionEvent.getRawY())) {
                this.C.clearFocus();
                d(view);
            }
        }
        return false;
    }

    @NonNull
    public static ch d(JSONObject jSONObject) {
        ch chVar = new ch();
        Bundle bundle = new Bundle();
        bundle.putString("ocrDataJSONString", jSONObject.toString());
        chVar.setArguments(bundle);
        return chVar;
    }

    /* JADX INFO: Access modifiers changed from: private */
    /* JADX INFO: renamed from: e, reason: merged with bridge method [inline-methods] */
    public void i() {
        if (this.l) {
            c(new Runnable() { // from class: com.facetec.sdk.仙礼
                @Override // java.lang.Runnable
                public final void run() {
                    this.f7039.c();
                }
            });
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void f() {
        this.b.b(false, true);
        final au.c cVar = new au.c(new Runnable() { // from class: com.facetec.sdk.仙玉
            @Override // java.lang.Runnable
            public final void run() {
                this.f7036.o();
            }
        });
        c(new Runnable() { // from class: com.facetec.sdk.仙王
            @Override // java.lang.Runnable
            public final void run() {
                this.f7037.a(cVar);
            }
        });
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void g() {
        if (this.c.getVisibility() == 0) {
            this.c.animate().alpha(1.0f).setDuration(500L).setListener(null).withEndAction(new Runnable() { // from class: com.facetec.sdk.仙符
                @Override // java.lang.Runnable
                public final void run() {
                    this.f7045.h();
                }
            }).start();
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void h() {
        if (this.l) {
            return;
        }
        this.l = true;
        dq.a(this.h);
        if (this.w) {
            i();
        }
    }

    public static void init$0() {
        $$a = new byte[]{0, ISOFileInfo.DATA_BYTES1, ISO7816.INS_MSE, -14, ISO7816.INS_REHABILITATE_CHV};
        $$b = EnumC41897g.SDK_ASSET_ILLUSTRATION_INSTITUTION_LINK_CIRCLE_VALUE;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void j() {
        this.y.animate().alpha(1.0f).setDuration(500L).setStartDelay(1000L).setListener(null).start();
        this.b.animate().alpha(1.0f).setDuration(500L).setStartDelay(1000L).setListener(null).start();
        this.e.animate().alpha(1.0f).setDuration(500L).setStartDelay(1000L).setListener(null).withEndAction(new Runnable() { // from class: com.facetec.sdk.仙祭
            @Override // java.lang.Runnable
            public final void run() {
                this.f7044.g();
            }
        }).start();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void o() {
        bi biVar = (bi) getActivity();
        if (biVar != null) {
            biVar.a(this.a);
        }
    }

    @Override // com.facetec.sdk.au, android.app.Fragment
    public final void onCreate(Bundle bundle) {
        super.onCreate(bundle);
    }

    @Override // android.app.Fragment
    public final View onCreateView(LayoutInflater layoutInflater, ViewGroup viewGroup, Bundle bundle) {
        View viewInflate = layoutInflater.inflate(R.layout.facetec_ocr_confirmation_fragment, viewGroup, false);
        this.t = viewInflate;
        return viewInflate;
    }

    @Override // android.app.Fragment
    public final void onDestroy() {
        super.onDestroy();
        ScrollView scrollView = this.e;
        if (scrollView != null) {
            scrollView.getViewTreeObserver().removeOnGlobalLayoutListener(this.B);
        }
    }

    @Override // android.app.Fragment
    @SuppressLint({"ClickableViewAccessibility"})
    public final void onViewCreated(View view, Bundle bundle) {
        String string;
        super.onViewCreated(view, bundle);
        Activity activity = getActivity();
        try {
            if (getArguments() != null && (string = getArguments().getString("ocrDataJSONString")) != null) {
                this.a = new JSONObject(string);
            }
        } catch (JSONException e) {
            e.printStackTrace();
        }
        this.r = view.findViewById(R.id.backgroundView);
        this.b = (e) view.findViewById(R.id.confirmButton);
        this.e = (ScrollView) view.findViewById(R.id.mainContentScrollView);
        this.d = (LinearLayout) view.findViewById(R.id.scrollableContentLayout);
        this.p = (LinearLayout) view.findViewById(R.id.dynamicContentLayout);
        this.u = (TextView) view.findViewById(R.id.mainHeaderTextView);
        this.v = view.findViewById(R.id.mainHeaderDividerLineView);
        this.c = (RelativeLayout) view.findViewById(R.id.scrollDownIndicatorLayout);
        this.f95853g = (LinearLayout) view.findViewById(R.id.scrollDownIndicatorContentLayout);
        this.f = (TextView) view.findViewById(R.id.scrollDownIndicatorTextView);
        this.h = (ImageView) view.findViewById(R.id.scrollDownIndicatorImageView);
        this.y = (RelativeLayout) view.findViewById(R.id.outsetActionButtonLayout);
        FaceTecOCRConfirmationCustomization faceTecOCRConfirmationCustomization = FaceTecSDK.d.j;
        this.k = faceTecOCRConfirmationCustomization.enableFixedConfirmButton;
        this.w = faceTecOCRConfirmationCustomization.enableScrollIndicatorTextAnimation;
        this.m = faceTecOCRConfirmationCustomization.enableScrollIndicator;
        this.x = faceTecOCRConfirmationCustomization.customScrollIndicatorAnimation == 0;
        this.o = dq.b(getActivity(), dm.aC());
        this.i = dq.b(getActivity(), dm.aA());
        int iRound = Math.round(this.q * 20.0f);
        Typeface typeface = FaceTecSDK.d.j.mainHeaderFont;
        int iB = dq.b(activity, dm.au());
        int iRound2 = Math.round(bh.a(dm.r()));
        int iMax = Math.max(iRound2 == 0 ? 0 : 1, Math.round(iRound2 * this.n));
        int iB2 = dq.b(activity, dm.at());
        dp.e(this.u, R.string.FaceTec_idscan_ocr_confirmation_main_header);
        this.u.setTextColor(iB);
        this.u.setTypeface(typeface);
        this.u.setTextSize(iRound);
        ((LinearLayout.LayoutParams) this.u.getLayoutParams()).setMargins(0, 0, 0, this.s);
        this.v.getLayoutParams().height = iMax;
        LinearLayout.LayoutParams layoutParams = (LinearLayout.LayoutParams) this.v.getLayoutParams();
        int i = this.s;
        layoutParams.setMargins(i, 0, i, 0);
        this.v.setBackgroundColor(iB2);
        int iRound3 = Math.round(bh.a(50) * this.q);
        this.b.getLayoutParams().height = iRound3;
        if (this.k) {
            this.d.removeView(this.b);
            this.y.addView(this.b);
            this.y.setVisibility(0);
            RelativeLayout.LayoutParams layoutParams2 = (RelativeLayout.LayoutParams) this.b.getLayoutParams();
            int i2 = this.s;
            layoutParams2.setMargins(i2, 0, i2, i2);
        } else {
            LinearLayout.LayoutParams layoutParams3 = (LinearLayout.LayoutParams) this.b.getLayoutParams();
            int i3 = this.s;
            layoutParams3.setMargins(i3, i3 << 1, i3, 0);
        }
        dp.e(this.b, R.string.FaceTec_action_confirm);
        this.b.setEnabled(true);
        this.b.e();
        this.b.c(new au.c(new Runnable() { // from class: com.facetec.sdk.仙金
            @Override // java.lang.Runnable
            public final void run() {
                this.f7048.f();
            }
        }));
        if (this.k) {
            RelativeLayout.LayoutParams layoutParams4 = (RelativeLayout.LayoutParams) this.e.getLayoutParams();
            int i4 = this.s;
            layoutParams4.setMargins(0, i4, 0, (i4 << 1) + iRound3);
        } else {
            RelativeLayout.LayoutParams layoutParams5 = (RelativeLayout.LayoutParams) this.e.getLayoutParams();
            int i5 = this.s;
            layoutParams5.setMargins(0, i5, 0, i5);
        }
        dm.a(this.r);
        this.r.getBackground().setAlpha(((Integer) dm.e(pg.a.a(), pg.a.a(), -298147150, new Object[0], pg.a.a(), 298147185, pg.a.a())).intValue());
        Drawable drawable = C6852.getDrawable(activity, R.drawable.facetec_scrollbar_vertical_track);
        Drawable drawable2 = C6852.getDrawable(activity, R.drawable.facetec_scrollbar_vertical_thumb);
        int iC = dq.c(iB, 128);
        int iRound4 = Math.round(bh.a(10) * this.q);
        int iRound5 = Math.round(bh.a(5) * this.q);
        if (drawable != null) {
            GradientDrawable gradientDrawable = (GradientDrawable) drawable;
            gradientDrawable.setColor(0);
            gradientDrawable.setCornerRadius(iRound5);
        }
        if (drawable2 != null) {
            GradientDrawable gradientDrawable2 = (GradientDrawable) drawable2;
            gradientDrawable2.setColor(iC);
            gradientDrawable2.setCornerRadius(iRound5);
        }
        this.d.setScrollBarSize(iRound4);
        if (Build.VERSION.SDK_INT >= 29) {
            this.d.setVerticalScrollbarTrackDrawable(drawable);
            this.d.setVerticalScrollbarThumbDrawable(drawable2);
        }
        this.d.setOnTouchListener(new View.OnTouchListener() { // from class: com.facetec.sdk.仙雨
            @Override // android.view.View.OnTouchListener
            public final boolean onTouch(View view2, MotionEvent motionEvent) {
                return this.f7049.c(view2, motionEvent);
            }
        });
        final JSONObject jSONObject = this.a;
        final Activity activity2 = getActivity();
        c(new Runnable() { // from class: com.facetec.sdk.仙梦
            @Override // java.lang.Runnable
            public final void run() throws Throwable {
                this.f7027.d(activity2, jSONObject);
            }
        });
        c(new Runnable() { // from class: com.facetec.sdk.仙气
            @Override // java.lang.Runnable
            public final void run() {
                this.f7030.j();
            }
        });
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void e(ValueAnimator valueAnimator) {
        int iIntValue = ((Integer) valueAnimator.getAnimatedValue()).intValue();
        this.i = iIntValue;
        ((GradientDrawable) this.j).setColor(iIntValue);
        this.c.setBackground(this.j);
        this.c.postInvalidate();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void a(ValueAnimator valueAnimator) {
        int iIntValue = ((Integer) valueAnimator.getAnimatedValue()).intValue();
        this.o = iIntValue;
        this.f.setTextColor(iIntValue);
        this.f.postInvalidate();
        if (this.x) {
            this.h.setColorFilter(this.o, PorterDuff.Mode.SRC_IN);
            this.h.postInvalidate();
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    /* JADX WARN: Removed duplicated region for block: B:117:0x0488 A[LOOP:2: B:115:0x0482->B:117:0x0488, LOOP_END] */
    /* JADX WARN: Removed duplicated region for block: B:121:0x04b6 A[LOOP:3: B:119:0x04b0->B:121:0x04b6, LOOP_END] */
    /* JADX WARN: Removed duplicated region for block: B:124:0x04d1  */
    /* JADX WARN: Removed duplicated region for block: B:165:? A[RETURN, SYNTHETIC] */
    /* JADX WARN: Removed duplicated region for block: B:89:0x038f A[Catch: JSONException -> 0x0369, TryCatch #9 {JSONException -> 0x0369, blocks: (B:73:0x0345, B:103:0x03cd, B:87:0x0389, B:89:0x038f, B:90:0x0390, B:106:0x0411), top: B:144:0x0345 }] */
    /* JADX WARN: Removed duplicated region for block: B:90:0x0390 A[Catch: JSONException -> 0x0369, TryCatch #9 {JSONException -> 0x0369, blocks: (B:73:0x0345, B:103:0x03cd, B:87:0x0389, B:89:0x038f, B:90:0x0390, B:106:0x0411), top: B:144:0x0345 }] */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public /* synthetic */ void d(android.content.Context r40, org.json.JSONObject r41) throws java.lang.Throwable {
        /*
            Method dump skipped, instruction units count: 1239
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: com.facetec.sdk.ch.d(android.content.Context, org.json.JSONObject):void");
    }

    /* JADX INFO: renamed from: com.facetec.sdk.ch$3, reason: invalid class name */
    public class AnonymousClass3 implements ViewTreeObserver.OnGlobalLayoutListener {
        public AnonymousClass3() {
        }

        /* JADX INFO: Access modifiers changed from: private */
        public /* synthetic */ void a() {
            ch.this.c.setEnabled(false);
            ch.this.b.setEnabled(true);
            ch.a(ch.this);
            ch.this.e.fullScroll(130);
        }

        /* JADX INFO: Access modifiers changed from: private */
        public /* synthetic */ void c() {
            int scrollY = ch.this.e.getScrollY();
            int height = ch.this.e.getHeight() + scrollY;
            int bottom = ch.this.d.getBottom();
            if (!ch.this.b.isEnabled() && bottom <= height) {
                ch.this.b.b(true, true);
            }
            ch chVar = ch.this;
            if (!chVar.l || scrollY <= 0) {
                return;
            }
            ch.a(chVar);
        }

        /* JADX INFO: Access modifiers changed from: private */
        public /* synthetic */ boolean e(View view, MotionEvent motionEvent) {
            if (!ch.this.c.isEnabled()) {
                return true;
            }
            if (motionEvent.getAction() == 0) {
                ch.e(ch.this, true);
            } else if (motionEvent.getAction() == 3 || motionEvent.getX() < SelfieScan.RECOGNITION_FAIL_RESULT || motionEvent.getX() > ch.this.c.getWidth() || motionEvent.getY() < SelfieScan.RECOGNITION_FAIL_RESULT || motionEvent.getY() > ch.this.c.getHeight()) {
                ch.e(ch.this, false);
            } else if (motionEvent.getAction() == 1) {
                ch.this.c.performClick();
            }
            return true;
        }

        /* JADX WARN: Removed duplicated region for block: B:37:0x0218  */
        @Override // android.view.ViewTreeObserver.OnGlobalLayoutListener
        @android.annotation.SuppressLint({"ClickableViewAccessibility"})
        /*
            Code decompiled incorrectly, please refer to instructions dump.
            To view partially-correct code enable 'Show inconsistent code' option in preferences
        */
        public final void onGlobalLayout() {
            /*
                Method dump skipped, instruction units count: 589
                To view this dump change 'Code comments level' option to 'DEBUG'
            */
            throw new UnsupportedOperationException("Method not decompiled: com.facetec.sdk.ch.AnonymousClass3.onGlobalLayout():void");
        }

        /* JADX INFO: Access modifiers changed from: private */
        public /* synthetic */ void c(View view) {
            ch.this.e.post(new Runnable() { // from class: com.facetec.sdk.仙鬼
                @Override // java.lang.Runnable
                public final void run() {
                    this.f7051.a();
                }
            });
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void e(EditText editText, View view, boolean z) {
        if (editText == null) {
            return;
        }
        if (z) {
            this.C = editText;
            editText.setCursorVisible(true);
        } else {
            this.C = null;
            editText.setCursorVisible(false);
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void c(int i) {
        AnonymousClass1 anonymousClass1 = new AnonymousClass1();
        if (i != 0) {
            dq.c(this.h, i, anonymousClass1, false);
        } else {
            this.h.setColorFilter(dm.aC(), PorterDuff.Mode.SRC_IN);
            dq.c(this.h, R.drawable.facetec_animated_double_down_chevron, anonymousClass1, false);
        }
        this.h.setVisibility(0);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void a() {
        this.h.setImageDrawable(null);
        this.c.setVisibility(8);
    }

    public static /* synthetic */ void e(final ch chVar, boolean z) {
        Activity activity;
        int iAC;
        int i = chVar.i;
        int iB = dq.b(chVar.getActivity(), z ? dm.aB() : dm.aA());
        int i2 = chVar.o;
        if (z) {
            activity = chVar.getActivity();
            iAC = dm.aE();
        } else {
            activity = chVar.getActivity();
            iAC = dm.aC();
        }
        int iB2 = dq.b(activity, iAC);
        if (i != iB) {
            ValueAnimator valueAnimatorOfObject = ValueAnimator.ofObject(new ArgbEvaluator(), Integer.valueOf(i), Integer.valueOf(iB));
            valueAnimatorOfObject.setDuration(200L);
            valueAnimatorOfObject.addUpdateListener(new ValueAnimator.AnimatorUpdateListener() { // from class: com.facetec.sdk.仙海
                @Override // android.animation.ValueAnimator.AnimatorUpdateListener
                public final void onAnimationUpdate(ValueAnimator valueAnimator) {
                    this.f7032.e(valueAnimator);
                }
            });
            valueAnimatorOfObject.start();
        }
        if (i2 != iB2) {
            ValueAnimator valueAnimatorOfObject2 = ValueAnimator.ofObject(new ArgbEvaluator(), Integer.valueOf(i2), Integer.valueOf(iB2));
            valueAnimatorOfObject2.setDuration(200L);
            valueAnimatorOfObject2.addUpdateListener(new ValueAnimator.AnimatorUpdateListener() { // from class: com.facetec.sdk.仙火
                @Override // android.animation.ValueAnimator.AnimatorUpdateListener
                public final void onAnimationUpdate(ValueAnimator valueAnimator) {
                    this.f7033.a(valueAnimator);
                }
            });
            valueAnimatorOfObject2.start();
        }
    }

    public static /* synthetic */ void a(final ch chVar) {
        chVar.l = false;
        chVar.c.animate().alpha(SelfieScan.RECOGNITION_FAIL_RESULT).setDuration(300L).setListener(null).withEndAction(new Runnable() { // from class: com.facetec.sdk.仙药
            @Override // java.lang.Runnable
            public final void run() {
                this.f7046.a();
            }
        }).start();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void c() {
        this.f.animate().alpha(SelfieScan.RECOGNITION_FAIL_RESULT).setStartDelay(2000L).setDuration(300L).setListener(null).withEndAction(new Runnable() { // from class: com.facetec.sdk.仙水
            @Override // java.lang.Runnable
            public final void run() {
                this.f7031.d();
            }
        }).start();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void d() {
        this.f.animate().alpha(1.0f).setStartDelay(0L).setDuration(300L).setListener(null).withEndAction(new Runnable() { // from class: com.facetec.sdk.仙道
            @Override // java.lang.Runnable
            public final void run() {
                this.f7047.i();
            }
        }).start();
    }

    private void d(String str) {
        if (this.A) {
            return;
        }
        bb.e(str);
    }

    private static String d(JSONObject jSONObject, String str) {
        try {
            return jSONObject.getString(str);
        } catch (JSONException unused) {
            return null;
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ boolean d(EditText editText, TextView textView, int i, KeyEvent keyEvent) {
        if (editText == null) {
            return false;
        }
        editText.setCursorVisible(false);
        if (keyEvent != null && keyEvent.getKeyCode() == 66) {
            d(textView);
        }
        return false;
    }

    private void d(View view) {
        ((InputMethodManager) getActivity().getApplicationContext().getSystemService("input_method")).hideSoftInputFromWindow(view.getWindowToken(), 0);
    }

    public static /* synthetic */ void d(final ch chVar) {
        final int iAM = dm.aM();
        chVar.c(new Runnable() { // from class: com.facetec.sdk.仙灵
            @Override // java.lang.Runnable
            public final void run() {
                this.f7034.c(iAM);
            }
        });
    }
}