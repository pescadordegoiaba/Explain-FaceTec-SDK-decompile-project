package com.facetec.sdk;

import java.lang.reflect.Type;
import java.util.ArrayList;

/* JADX INFO: loaded from: classes4.dex */
public final class ci extends fg implements hp {
    private el a;
    private hr b;
    private hu d;

    public ci(el elVar, hr hrVar, hu huVar) {
        this.a = elVar;
        this.b = hrVar;
        this.d = huVar;
    }

    @Override // com.facetec.sdk.fg
    public final Object a(gs gsVar) {
        if (gsVar.j() == gw.NULL) {
            gsVar.l();
            return null;
        }
        q qVar = new q();
        el elVar = this.a;
        hr hrVar = this.b;
        gsVar.d();
        while (gsVar.b()) {
            int iA = hrVar.a(gsVar);
            boolean z = gsVar.j() != gw.NULL;
            switch (iA) {
                case 1:
                    if (z) {
                        qVar.f95947g = ((Boolean) elVar.d(Boolean.class).a(gsVar)).booleanValue();
                    }
                    break;
                case 2:
                    if (z) {
                        try {
                            qVar.h = gsVar.k();
                        } catch (NumberFormatException e) {
                            throw new fc(e);
                        }
                    }
                    break;
                case 3:
                    if (!z) {
                        qVar.c = null;
                    } else {
                        qVar.c = gsVar.j() != gw.BOOLEAN ? gsVar.h() : Boolean.toString(gsVar.f());
                    }
                    break;
                case 4:
                    if (!z) {
                        qVar.b = null;
                    } else {
                        qVar.b = gsVar.j() != gw.BOOLEAN ? gsVar.h() : Boolean.toString(gsVar.f());
                    }
                    break;
                case 5:
                case 6:
                default:
                    gsVar.l();
                    continue;
                case 7:
                    if (!z) {
                        qVar.f = null;
                    } else {
                        qVar.f = gsVar.j() != gw.BOOLEAN ? gsVar.h() : Boolean.toString(gsVar.f());
                    }
                    break;
                case 8:
                    if (!z) {
                        qVar.e = null;
                    } else {
                        qVar.e = gsVar.j() != gw.BOOLEAN ? gsVar.h() : Boolean.toString(gsVar.f());
                    }
                    break;
                case 9:
                    if (!z) {
                        qVar.j = null;
                    } else {
                        qVar.j = gsVar.j() != gw.BOOLEAN ? gsVar.h() : Boolean.toString(gsVar.f());
                    }
                    break;
                case 10:
                    if (!z) {
                        qVar.i = null;
                    } else {
                        qVar.i = gsVar.j() != gw.BOOLEAN ? gsVar.h() : Boolean.toString(gsVar.f());
                    }
                    break;
                case 11:
                    if (!z) {
                        qVar.d = null;
                    } else {
                        qVar.d = (EnumC39477r) elVar.d(EnumC39477r.class).a(gsVar);
                    }
                    break;
                case 12:
                    if (!z) {
                        qVar.a = null;
                    } else {
                        qVar.a = (ArrayList) elVar.e((gu) new p()).a(gsVar);
                    }
                    break;
            }
            gsVar.m();
        }
        gsVar.a();
        return qVar;
    }

    @Override // com.facetec.sdk.fg
    public final void e(ha haVar, Object obj) {
        if (obj == null) {
            haVar.g();
            return;
        }
        q qVar = (q) obj;
        el elVar = this.a;
        hu huVar = this.d;
        haVar.c();
        if (qVar != qVar.b) {
            huVar.a(haVar, 1);
            haVar.e(qVar.b);
        }
        if (qVar != qVar.d) {
            huVar.a(haVar, 10);
            EnumC39477r enumC39477r = qVar.d;
            Type typeA = ht.a(EnumC39477r.class, enumC39477r);
            fg fgVarE = elVar.e((gu) gu.e(typeA));
            if (EnumC39477r.class != typeA && !ht.b(fgVarE)) {
                fg fgVarD = elVar.d(EnumC39477r.class);
                if (ht.b(fgVarD)) {
                    fgVarE = fgVarD;
                }
            }
            fgVarE.e(haVar, enumC39477r);
        }
        if (qVar != qVar.a) {
            huVar.a(haVar, 6);
            p pVar = new p();
            ArrayList<String> arrayList = qVar.a;
            Type typeA2 = pVar.a();
            Type typeA3 = ht.a(typeA2, arrayList);
            fg fgVarE2 = elVar.e((gu) gu.e(typeA3));
            if (typeA2 != typeA3 && !ht.b(fgVarE2)) {
                fg fgVarE3 = elVar.e((gu) pVar);
                if (ht.b(fgVarE3)) {
                    fgVarE2 = fgVarE3;
                }
            }
            fgVarE2.e(haVar, arrayList);
        }
        if (qVar != qVar.c) {
            huVar.a(haVar, 5);
            haVar.e(qVar.c);
        }
        if (qVar != qVar.e) {
            huVar.a(haVar, 2);
            haVar.e(qVar.e);
        }
        if (qVar != qVar.i) {
            huVar.a(haVar, 11);
            haVar.e(qVar.i);
        }
        if (qVar != qVar.j) {
            huVar.a(haVar, 7);
            haVar.e(qVar.j);
        }
        if (qVar != qVar.f) {
            huVar.a(haVar, 3);
            haVar.e(qVar.f);
        }
        huVar.a(haVar, 4);
        haVar.b(qVar.f95947g);
        huVar.a(haVar, 0);
        haVar.b(Integer.valueOf(qVar.h));
        haVar.b();
    }
}