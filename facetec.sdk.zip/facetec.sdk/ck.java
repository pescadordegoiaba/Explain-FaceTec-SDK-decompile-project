package com.facetec.sdk;

/* JADX INFO: loaded from: classes4.dex */
enum ck {
    UNKNOWN,
    STARTING,
    SCANNING,
    WEAK_CONNECTION,
    FINISHED_WITH_SUCCESS,
    FINISHED_WITH_ERROR,
    SKIPPED,
    DISABLED
}