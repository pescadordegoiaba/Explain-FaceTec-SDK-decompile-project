package com.facetec.sdk;

/* JADX INFO: loaded from: classes4.dex */
public final class cl extends fg implements hp {
    private el b;
    private hu c;
    private hr d;

    public cl(el elVar, hr hrVar, hu huVar) {
        this.b = elVar;
        this.d = hrVar;
        this.c = huVar;
    }

    @Override // com.facetec.sdk.fg
    public final Object a(gs gsVar) {
        int iB = this.d.b(gsVar);
        if (iB == 0) {
            return EnumC39477r.ID_SCAN_ONLY;
        }
        if (iB == 5) {
            return EnumC39477r.ID_SCAN_MATCH;
        }
        if (iB != 6) {
            return null;
        }
        return EnumC39477r.FACE_SCAN;
    }

    @Override // com.facetec.sdk.fg
    public final void e(ha haVar, Object obj) {
        if (obj == null) {
            haVar.g();
        } else {
            this.c.e(haVar, obj == EnumC39477r.ID_SCAN_MATCH ? 12 : obj == EnumC39477r.FACE_SCAN ? 8 : obj == EnumC39477r.ID_SCAN_ONLY ? 9 : -1);
        }
    }
}