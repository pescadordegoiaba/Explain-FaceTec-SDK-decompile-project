package com.facetec.sdk;

/* JADX INFO: loaded from: classes4.dex */
enum cn {
    ID_IMAGE_HOLD_STEADY(0),
    ID_IMAGE_FACE_NOT_FOUND(1),
    ID_IMAGE_BLURRY(2);

    private final int a;

    cn(int i) {
        this.a = i;
    }
}