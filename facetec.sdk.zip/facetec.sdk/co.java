package com.facetec.sdk;

/* JADX INFO: loaded from: classes4.dex */
enum co {
    KEEP_SCANNING(0),
    END_SCAN(1),
    PRESENT_MANUAL_CAPTURE_BUTTON(2);

    private final int e;

    co(int i) {
        this.e = i;
    }
}