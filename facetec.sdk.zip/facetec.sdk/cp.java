package com.facetec.sdk;

import android.app.Activity;
import android.content.Context;
import android.graphics.Color;
import android.graphics.ImageFormat;
import android.graphics.PointF;
import android.graphics.drawable.Drawable;
import android.hardware.usb.UsbDevice;
import android.hardware.usb.UsbManager;
import android.media.AudioTrack;
import android.os.PowerManager;
import android.os.Process;
import android.os.SystemClock;
import android.telephony.cdma.CdmaCellLocation;
import android.text.AndroidCharacter;
import android.text.TextUtils;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewConfiguration;
import android.widget.ExpandableListView;
import android.widget.Toast;
import androidx.annotation.NonNull;
import com.facetec.sdk.t;
import com.incode.welcome_sdk.modules.SelfieScan;
import com.plaid.internal.EnumC41897g;
import java.lang.ref.WeakReference;
import java.lang.reflect.Constructor;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Timer;
import java.util.TimerTask;
import java.util.UUID;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Semaphore;
import java.util.concurrent.TimeUnit;
import net.sf.scuba.smartcards.ISO7816;
import org.bouncycastle.i18n.LocalizedMessage;
import org.jmrtd.PassportService;
import org.json.JSONException;
import org.json.JSONObject;

/* JADX INFO: loaded from: classes4.dex */
final class cp {
    private static final byte[] $$a = null;
    private static final int $$b = 0;
    private static final byte[] $$c = null;
    private static final int $$d = 0;
    private static int $10;
    private static int $11;
    private static char[] E;
    private static char F;
    private static /* synthetic */ boolean H;
    private static int J;
    private static boolean K;
    private static char[] L;
    private static boolean M;
    private static long N;
    private static int O;
    private static char P;
    private static char Q;
    private static char R;
    private static char S;
    private static final byte[] T = null;
    private static int U;
    private static long V;
    private static int W;
    private static int X;
    static volatile String a;
    private static final int ab = 0;
    static volatile String c;
    private static cp i;
    final ac b;
    private co k;
    private final WeakReference<Activity> l;
    private cu n;
    private cm o;
    private cn p;
    private cw q;
    private cs r;
    private ct s;
    private da t;
    private int w;
    private Object x;
    boolean e = false;
    boolean d = false;
    private a y = a.NOT_STARTED;
    private final Object v = new Object();
    private int u = 0;
    private final Timer A = new Timer();
    private TimerTask C = null;
    private Date z = null;
    private final Semaphore D = new Semaphore(1);
    private boolean I = false;
    private final Runnable[] G = {new Runnable() { // from class: com.facetec.sdk.兵剑
        @Override // java.lang.Runnable
        public final void run() throws Throwable {
            this.f7063.u();
        }
    }, new Runnable() { // from class: com.facetec.sdk.兵古
        @Override // java.lang.Runnable
        public final void run() throws Throwable {
            this.f7064.v();
        }
    }, new Runnable() { // from class: com.facetec.sdk.兵史
        @Override // java.lang.Runnable
        public final void run() throws Throwable {
            this.f7065.B();
        }
    }, new Runnable() { // from class: com.facetec.sdk.兵名
        @Override // java.lang.Runnable
        public final void run() throws Throwable {
            this.f7066.D();
        }
    }, new Runnable() { // from class: com.facetec.sdk.兵国
        @Override // java.lang.Runnable
        public final void run() throws Throwable {
            this.f7067.A();
        }
    }};

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    private final ExecutorService f95856g = Executors.newSingleThreadExecutor();
    private final ExecutorService m = Executors.newSingleThreadExecutor();
    private final ArrayList<WeakReference<b>> h = new ArrayList<>(2);
    private final ArrayList<WeakReference<e>> j = new ArrayList<>(2);
    private final ArrayList<WeakReference<d>> f = new ArrayList<>(2);
    private final boolean B = bk.b();

    /* JADX INFO: renamed from: com.facetec.sdk.cp$2, reason: invalid class name */
    public static /* synthetic */ class AnonymousClass2 {
        static final /* synthetic */ int[] c;

        static {
            int[] iArr = new int[a.values().length];
            c = iArr;
            try {
                iArr[a.NOT_STARTED.ordinal()] = 1;
            } catch (NoSuchFieldError unused) {
            }
            try {
                c[a.FINISHED.ordinal()] = 2;
            } catch (NoSuchFieldError unused2) {
            }
            try {
                c[a.WAITING_TO_FINISH.ordinal()] = 3;
            } catch (NoSuchFieldError unused3) {
            }
            try {
                c[a.PRE_SESSION.ordinal()] = 4;
            } catch (NoSuchFieldError unused4) {
            }
            try {
                c[a.PROCESSING.ordinal()] = 5;
            } catch (NoSuchFieldError unused5) {
            }
        }
    }

    public enum a {
        NOT_STARTED,
        PRE_SESSION,
        PROCESSING,
        ID_SCAN,
        WAITING_TO_FINISH,
        FINISHED
    }

    @FunctionalInterface
    public interface b {
        void onPreSessionProgress(da daVar, cw cwVar, cs csVar, ct ctVar);
    }

    @FunctionalInterface
    public interface d {
        void onIDScanProgress(co coVar, cn cnVar);
    }

    public interface e {
        void a();

        void b();

        void c(cu cuVar, cm cmVar);

        void d();

        void e();
    }

    /* JADX WARN: Removed duplicated region for block: B:10:0x0021  */
    /* JADX WARN: Removed duplicated region for block: B:8:0x001b  */
    /* JADX WARN: Unsupported multi-entry loop pattern (BACK_EDGE: B:10:0x0021 -> B:11:0x0025). Please report as a decompilation issue!!! */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    private static java.lang.String $$e(byte r5, short r6, short r7) {
        /*
            int r5 = r5 * 4
            int r5 = r5 + 4
            int r7 = r7 * 3
            int r0 = r7 + 1
            int r6 = r6 + 99
            byte[] r1 = com.facetec.sdk.cp.$$c
            byte[] r0 = new byte[r0]
            r2 = 0
            if (r1 != 0) goto L15
            r4 = r6
            r6 = r7
            r3 = r2
            goto L25
        L15:
            r3 = r2
        L16:
            byte r4 = (byte) r6
            r0[r3] = r4
            if (r3 != r7) goto L21
            java.lang.String r5 = new java.lang.String
            r5.<init>(r0, r2)
            return r5
        L21:
            int r3 = r3 + 1
            r4 = r1[r5]
        L25:
            int r5 = r5 + 1
            int r6 = r6 + r4
            goto L16
        */
        throw new UnsupportedOperationException("Method not decompiled: com.facetec.sdk.cp.$$e(byte, short, short):java.lang.String");
    }

    static {
        init$1();
        $10 = 0;
        $11 = 1;
        init$0();
        y();
        q();
        X = 0;
        W = 1;
        O = 0;
        U = 1;
        s();
        int iD = bb.d();
        int iD2 = bb.d();
        int iD3 = bb.d();
        b(1462010534, iD, bb.d(), iD2, -1462010525, iD3, new Object[0]);
        p();
        W = (X + 9) % 128;
        H = true;
        i = null;
        a = "";
        c = "";
    }

    private cp(Activity activity) {
        this.l = new WeakReference<>(activity);
        this.b = new ac(activity);
        x();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void A() throws Throwable {
        int i2;
        int i3;
        float f;
        char c2;
        char c3;
        Object[] objArr;
        Object objD = an.d(-1397726040);
        if (objD == null) {
            int i4 = (TypedValue.complexToFraction(0, SelfieScan.RECOGNITION_FAIL_RESULT, SelfieScan.RECOGNITION_FAIL_RESULT) > SelfieScan.RECOGNITION_FAIL_RESULT ? 1 : (TypedValue.complexToFraction(0, SelfieScan.RECOGNITION_FAIL_RESULT, SelfieScan.RECOGNITION_FAIL_RESULT) == SelfieScan.RECOGNITION_FAIL_RESULT ? 0 : -1)) + 711;
            char offsetAfter = (char) (49308 - TextUtils.getOffsetAfter("", 0));
            int i5 = 24 - (AudioTrack.getMinVolume() > SelfieScan.RECOGNITION_FAIL_RESULT ? 1 : (AudioTrack.getMinVolume() == SelfieScan.RECOGNITION_FAIL_RESULT ? 0 : -1));
            byte b2 = (byte) 0;
            byte b3 = b2;
            Object[] objArr2 = new Object[1];
            ad(b2, b3, (byte) (b3 + 2), objArr2);
            objD = an.d(i4, offsetAfter, i5, -623790093, false, (String) objArr2[0], null);
        }
        long j = ((Field) objD).getLong(null);
        Object[] objArr3 = new Object[1];
        ae("흗듩綁䉁斣氌鯸Ꮾ䶜༜\udeab㋘㽼ꥌ⃢\ueacb杻䘖셅뷂ਿ衛", 22 - (KeyEvent.getMaxKeyCode() >> 16), objArr3);
        Class<?> cls = Class.forName((String) objArr3[0]);
        Object[] objArr4 = new Object[1];
        ae("\ud9ee舓䷏㳳\uea89컢酭䓁ﲝ杴辨쀎\uf5a7㵋ၗ\udb16", Color.red(0) + 15, objArr4);
        long jLongValue = ((Long) cls.getDeclaredMethod((String) objArr4[0], null).invoke(null, null)).longValue();
        Object objD2 = an.d(-1398649561);
        if (objD2 == null) {
            int doubleTapTimeout = (ViewConfiguration.getDoubleTapTimeout() >> 16) + 711;
            char cBlue = (char) (49308 - Color.blue(0));
            int doubleTapTimeout2 = 24 - (ViewConfiguration.getDoubleTapTimeout() >> 16);
            byte b4 = (byte) 0;
            i2 = -1397726040;
            byte b5 = b4;
            i3 = 49308;
            f = 0.0f;
            Object[] objArr5 = new Object[1];
            ad(b4, b5, (byte) (b5 + 1), objArr5);
            objD2 = an.d(doubleTapTimeout, cBlue, doubleTapTimeout2, -624714116, false, (String) objArr5[0], null);
        } else {
            i2 = -1397726040;
            i3 = 49308;
            f = 0.0f;
        }
        if (j == ((jLongValue - ((((Field) objD2).getLong(null) << 52) >>> 52)) >> 12)) {
            O = (U + 51) % 128;
            Object objD3 = an.d(-1399573082);
            if (objD3 == null) {
                int gidForName = 710 - Process.getGidForName("");
                char scrollBarSize = (char) (i3 - (ViewConfiguration.getScrollBarSize() >> 8));
                int i6 = (ViewConfiguration.getScrollFriction() > f ? 1 : (ViewConfiguration.getScrollFriction() == f ? 0 : -1)) + 23;
                byte b6 = (byte) 0;
                byte b7 = b6;
                Object[] objArr6 = new Object[1];
                ad(b6, b7, b7, objArr6);
                objD3 = an.d(gidForName, scrollBarSize, i6, -621418755, false, (String) objArr6[0], null);
            }
            Object[] objArr7 = (Object[]) ((Field) objD3).get(null);
            objArr = new Object[]{strArr, new int[]{i}, new int[]{i}, new int[1]};
            int i7 = ((int[]) objArr7[1])[0];
            int i8 = ((int[]) objArr7[2])[0];
            String[] strArr = (String[]) objArr7[0];
            int i9 = ((((~((-18350345) | r0)) | 8586256) * 449) - 2018073098) + (((~((~System.identityHashCode(this)) | (-18350345))) | 8586256) * 449) + 304476617;
            int i10 = (i9 << 13) ^ i9;
            int i11 = i10 ^ (i10 >>> 17);
            ((int[]) objArr[3])[0] = i11 ^ (i11 << 5);
            c2 = 3;
            c3 = 2;
        } else {
            Object[] objArr8 = new Object[1];
            ae("\uf16d\ue0e7糉羃㴽ꄩ흗듩㐫◙缭\uf637育诹로돏", Gravity.getAbsoluteGravity(0, 0) + 16, objArr8);
            Class<?> cls2 = Class.forName((String) objArr8[0]);
            Object[] objArr9 = new Object[1];
            ae("ꑐ݂緞漙糄\uf38e嗴\udc2bꑇ舧쳻⤟쁯ꚿ㊗ై", (ViewConfiguration.getScrollBarFadeDuration() >> 16) + 16, objArr9);
            int iIntValue = ((Integer) cls2.getMethod((String) objArr9[0], Object.class).invoke(null, this)).intValue();
            try {
                Object[] objArr10 = {587552393};
                Object objD4 = an.d(1683332522);
                if (objD4 == null) {
                    objD4 = an.d(ImageFormat.getBitsPerPixel(0) + 831, (char) (ViewConfiguration.getLongPressTimeout() >> 16), 24 - ExpandableListView.getPackedPositionGroup(0L), 305417969, false, null, new Class[]{Integer.TYPE});
                }
                Object[] objArr11 = {Integer.valueOf(iIntValue), 0, 304476617, ((Constructor) objD4).newInstance(objArr10), Boolean.FALSE};
                Object objD5 = an.d(1794077343);
                if (objD5 == null) {
                    int keyRepeatDelay = 711 - (ViewConfiguration.getKeyRepeatDelay() >> 16);
                    char cAlpha = (char) (i3 - Color.alpha(0));
                    int i12 = (Process.getElapsedCpuTime() > 0L ? 1 : (Process.getElapsedCpuTime() == 0L ? 0 : -1)) + 23;
                    byte b8 = (byte) 0;
                    byte b9 = b8;
                    c2 = 3;
                    c3 = 2;
                    Object[] objArr12 = new Object[1];
                    ad(b8, b9, (byte) (b9 + 1), objArr12);
                    String str = (String) objArr12[0];
                    Class cls3 = Integer.TYPE;
                    objD5 = an.d(keyRepeatDelay, cAlpha, i12, 479109572, false, str, new Class[]{cls3, cls3, cls3, (Class) an.b(View.MeasureSpec.makeMeasureSpec(0, 0) + 799, (char) ((Process.getElapsedCpuTime() > 0L ? 1 : (Process.getElapsedCpuTime() == 0L ? 0 : -1)) - 1), 31 - Color.blue(0)), Boolean.TYPE});
                } else {
                    c2 = 3;
                    c3 = 2;
                }
                Object[] objArr13 = (Object[]) ((Method) objD5).invoke(null, objArr11);
                Object objD6 = an.d(-1399573082);
                if (objD6 == null) {
                    int iNormalizeMetaState = 711 - KeyEvent.normalizeMetaState(0);
                    char cIndexOf = (char) (49307 - TextUtils.indexOf((CharSequence) "", '0', 0, 0));
                    int iLastIndexOf = 23 - TextUtils.lastIndexOf("", '0', 0);
                    byte b10 = (byte) 0;
                    byte b11 = b10;
                    Object[] objArr14 = new Object[1];
                    ad(b10, b11, b11, objArr14);
                    objD6 = an.d(iNormalizeMetaState, cIndexOf, iLastIndexOf, -621418755, false, (String) objArr14[0], null);
                }
                ((Field) objD6).set(null, objArr13);
                try {
                    Object[] objArr15 = new Object[1];
                    ae("흗듩綁䉁斣氌鯸Ꮾ䶜༜\udeab㋘㽼ꥌ⃢\ueacb杻䘖셅뷂ਿ衛", 22 - View.MeasureSpec.getSize(0), objArr15);
                    Class<?> cls4 = Class.forName((String) objArr15[0]);
                    Object[] objArr16 = new Object[1];
                    ae("\ud9ee舓䷏㳳\uea89컢酭䓁ﲝ杴辨쀎\uf5a7㵋ၗ\udb16", (Process.myPid() >> 22) + 15, objArr16);
                    long jLongValue2 = ((Long) cls4.getDeclaredMethod((String) objArr16[0], null).invoke(null, null)).longValue();
                    Long lValueOf = Long.valueOf(jLongValue2);
                    Object objD7 = an.d(-1398649561);
                    if (objD7 == null) {
                        int iLastIndexOf2 = 710 - TextUtils.lastIndexOf("", '0');
                        char cIndexOf2 = (char) (49307 - TextUtils.indexOf((CharSequence) "", '0'));
                        int longPressTimeout = 24 - (ViewConfiguration.getLongPressTimeout() >> 16);
                        byte b12 = (byte) 0;
                        byte b13 = b12;
                        Object[] objArr17 = new Object[1];
                        ad(b12, b13, (byte) (b13 + 1), objArr17);
                        objD7 = an.d(iLastIndexOf2, cIndexOf2, longPressTimeout, -624714116, false, (String) objArr17[0], null);
                    }
                    ((Field) objD7).set(null, lValueOf);
                    Long lValueOf2 = Long.valueOf(jLongValue2 >> 12);
                    Object objD8 = an.d(i2);
                    if (objD8 == null) {
                        int i13 = (AudioTrack.getMaxVolume() > f ? 1 : (AudioTrack.getMaxVolume() == f ? 0 : -1)) + 710;
                        char modifierMetaStateMask = (char) (((byte) KeyEvent.getModifierMetaStateMask()) + 49309);
                        int i14 = (AudioTrack.getMinVolume() > f ? 1 : (AudioTrack.getMinVolume() == f ? 0 : -1)) + 24;
                        byte b14 = (byte) 0;
                        byte b15 = b14;
                        Object[] objArr18 = new Object[1];
                        ad(b14, b15, (byte) (b15 + 2), objArr18);
                        objD8 = an.d(i13, modifierMetaStateMask, i14, -623790093, false, (String) objArr18[0], null);
                    }
                    ((Field) objD8).set(null, lValueOf2);
                    objArr = objArr13;
                } catch (Exception unused) {
                    throw new RuntimeException();
                }
            } catch (Throwable th) {
                Throwable cause = th.getCause();
                if (cause == null) {
                    throw th;
                }
                throw cause;
            }
        }
        if (((int[]) objArr[1])[0] != ((int[]) objArr[c3])[0]) {
            ArrayList arrayList = new ArrayList();
            String[] strArr2 = (String[]) objArr[0];
            if (strArr2 == null) {
                throw null;
            }
            O = (U + 21) % 128;
            for (String str2 : strArr2) {
                arrayList.add(str2);
            }
            throw null;
        }
        Object[] objArr19 = new Object[4];
        objArr19[1] = new int[]{i};
        objArr19[c3] = new int[]{i};
        objArr19[c2] = new int[1];
        int i15 = ((int[]) objArr[c2])[0];
        int i16 = ((int[]) objArr[1])[0];
        int i17 = ((int[]) objArr[c3])[0];
        objArr19[0] = (String[]) objArr[0];
        int iUptimeMillis = (int) SystemClock.uptimeMillis();
        int i18 = i15 + (-1675663226) + (((~(1002412830 | iUptimeMillis)) | 44374528) * (-756)) + (((~iUptimeMillis) | 1002412830) * 756);
        int i19 = (i18 << 13) ^ i18;
        int i20 = i19 ^ (i19 >>> 17);
        ((int[]) objArr19[c2])[0] = i20 ^ (i20 << 5);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void B() throws Throwable {
        int i2;
        long j;
        int i3;
        char c2;
        Object[] objArr;
        char c3;
        U = (O + 113) % 128;
        Object objD = an.d(-1397726040);
        if (objD == null) {
            int trimmedLength = 711 - TextUtils.getTrimmedLength("");
            char c4 = (char) (49309 - (ViewConfiguration.getZoomControlsTimeout() > 0L ? 1 : (ViewConfiguration.getZoomControlsTimeout() == 0L ? 0 : -1)));
            int iLastIndexOf = 23 - TextUtils.lastIndexOf("", '0');
            byte b2 = (byte) 0;
            byte b3 = b2;
            Object[] objArr2 = new Object[1];
            ad(b2, b3, (byte) (b3 + 2), objArr2);
            objD = an.d(trimmedLength, c4, iLastIndexOf, -623790093, false, (String) objArr2[0], null);
        }
        long j2 = ((Field) objD).getLong(null);
        Object[] objArr3 = new Object[1];
        ae("흗듩綁䉁斣氌鯸Ꮾ䶜༜\udeab㋘㽼ꥌ⃢\ueacb杻䘖셅뷂ਿ衛", ImageFormat.getBitsPerPixel(0) + 23, objArr3);
        Class<?> cls = Class.forName((String) objArr3[0]);
        Object[] objArr4 = new Object[1];
        ae("\ud9ee舓䷏㳳\uea89컢酭䓁ﲝ杴辨쀎\uf5a7㵋ၗ\udb16", 15 - (TypedValue.complexToFloat(0) > SelfieScan.RECOGNITION_FAIL_RESULT ? 1 : (TypedValue.complexToFloat(0) == SelfieScan.RECOGNITION_FAIL_RESULT ? 0 : -1)), objArr4);
        long jLongValue = ((Long) cls.getDeclaredMethod((String) objArr4[0], null).invoke(null, null)).longValue();
        Object objD2 = an.d(-1398649561);
        if (objD2 == null) {
            int iIndexOf = TextUtils.indexOf("", "") + 711;
            char c5 = (char) ((ExpandableListView.getPackedPositionForChild(0, 0) > 0L ? 1 : (ExpandableListView.getPackedPositionForChild(0, 0) == 0L ? 0 : -1)) + 49309);
            int i4 = 25 - (ViewConfiguration.getZoomControlsTimeout() > 0L ? 1 : (ViewConfiguration.getZoomControlsTimeout() == 0L ? 0 : -1));
            byte b4 = (byte) 0;
            byte b5 = b4;
            i2 = -1397726040;
            j = 0;
            Object[] objArr5 = new Object[1];
            ad(b4, b5, (byte) (b5 + 1), objArr5);
            objD2 = an.d(iIndexOf, c5, i4, -624714116, false, (String) objArr5[0], null);
        } else {
            i2 = -1397726040;
            j = 0;
        }
        if (j2 == ((jLongValue - ((((Field) objD2).getLong(null) << 52) >>> 52)) >> 12)) {
            O = (U + 1) % 128;
            Object objD3 = an.d(-1399573082);
            if (objD3 == null) {
                int i5 = (SystemClock.elapsedRealtimeNanos() > j ? 1 : (SystemClock.elapsedRealtimeNanos() == j ? 0 : -1)) + 710;
                char longPressTimeout = (char) (49308 - (ViewConfiguration.getLongPressTimeout() >> 16));
                int i6 = (Process.getElapsedCpuTime() > j ? 1 : (Process.getElapsedCpuTime() == j ? 0 : -1)) + 23;
                byte b6 = (byte) 0;
                byte b7 = b6;
                Object[] objArr6 = new Object[1];
                ad(b6, b7, b7, objArr6);
                objD3 = an.d(i5, longPressTimeout, i6, -621418755, false, (String) objArr6[0], null);
            }
            Object[] objArr7 = (Object[]) ((Field) objD3).get(null);
            objArr = new Object[]{strArr, new int[]{i}, new int[]{i}, new int[1]};
            int i7 = ((int[]) objArr7[1])[0];
            int i8 = ((int[]) objArr7[2])[0];
            String[] strArr = (String[]) objArr7[0];
            int iUptimeMillis = (int) SystemClock.uptimeMillis();
            int i9 = ~iUptimeMillis;
            int i10 = (-956748478) + ((iUptimeMillis | 190081641) * 140) + (((~(190081641 | i9)) | 805306516) * (-280)) + (((~(iUptimeMillis | (-805306517))) | (~(856705717 | i9)) | 138682440) * 140) + 643550244;
            int i11 = (i10 << 13) ^ i10;
            int i12 = i11 ^ (i11 >>> 17);
            ((int[]) objArr[3])[0] = i12 ^ (i12 << 5);
            c2 = 3;
            c3 = 2;
        } else {
            Object[] objArr8 = new Object[1];
            ae("\uf16d\ue0e7糉羃㴽ꄩ흗듩㐫◙缭\uf637育诹로돏", 16 - KeyEvent.normalizeMetaState(0), objArr8);
            Class<?> cls2 = Class.forName((String) objArr8[0]);
            Object[] objArr9 = new Object[1];
            ae("ꑐ݂緞漙糄\uf38e嗴\udc2bꑇ舧쳻⤟쁯ꚿ㊗ై", View.MeasureSpec.getMode(0) + 16, objArr9);
            int iIntValue = ((Integer) cls2.getMethod((String) objArr9[0], Object.class).invoke(null, this)).intValue();
            try {
                Object[] objArr10 = {20246479};
                Object objD4 = an.d(1683332522);
                if (objD4 == null) {
                    objD4 = an.d(View.MeasureSpec.getSize(0) + 830, (char) (ViewConfiguration.getScrollBarFadeDuration() >> 16), ExpandableListView.getPackedPositionGroup(j) + 24, 305417969, false, null, new Class[]{Integer.TYPE});
                }
                Object[] objArr11 = {Integer.valueOf(iIntValue), 0, 643550244, ((Constructor) objD4).newInstance(objArr10), Boolean.FALSE};
                Object objD5 = an.d(1794077343);
                if (objD5 == null) {
                    int iAlpha = Color.alpha(0) + 711;
                    char c6 = (char) ((ViewConfiguration.getGlobalActionKeyTimeout() > j ? 1 : (ViewConfiguration.getGlobalActionKeyTimeout() == j ? 0 : -1)) + 49307);
                    int iCombineMeasuredStates = 24 - View.combineMeasuredStates(0, 0);
                    byte b8 = (byte) 0;
                    byte b9 = b8;
                    i3 = 49308;
                    c2 = 3;
                    Object[] objArr12 = new Object[1];
                    ad(b8, b9, (byte) (b9 + 1), objArr12);
                    String str = (String) objArr12[0];
                    Class cls3 = Integer.TYPE;
                    objD5 = an.d(iAlpha, c6, iCombineMeasuredStates, 479109572, false, str, new Class[]{cls3, cls3, cls3, (Class) an.b((SystemClock.uptimeMillis() > j ? 1 : (SystemClock.uptimeMillis() == j ? 0 : -1)) + 798, (char) ((ViewConfiguration.getGlobalActionKeyTimeout() > j ? 1 : (ViewConfiguration.getGlobalActionKeyTimeout() == j ? 0 : -1)) - 1), ((byte) KeyEvent.getModifierMetaStateMask()) + ISO7816.INS_VERIFY), Boolean.TYPE});
                } else {
                    i3 = 49308;
                    c2 = 3;
                }
                objArr = (Object[]) ((Method) objD5).invoke(null, objArr11);
                Object objD6 = an.d(-1399573082);
                if (objD6 == null) {
                    int offsetAfter = TextUtils.getOffsetAfter("", 0) + 711;
                    char cKeyCodeFromString = (char) (KeyEvent.keyCodeFromString("") + i3);
                    int iArgb = Color.argb(0, 0, 0, 0) + 24;
                    byte b10 = (byte) 0;
                    byte b11 = b10;
                    Object[] objArr13 = new Object[1];
                    ad(b10, b11, b11, objArr13);
                    objD6 = an.d(offsetAfter, cKeyCodeFromString, iArgb, -621418755, false, (String) objArr13[0], null);
                }
                ((Field) objD6).set(null, objArr);
                try {
                    Object[] objArr14 = new Object[1];
                    ae("흗듩綁䉁斣氌鯸Ꮾ䶜༜\udeab㋘㽼ꥌ⃢\ueacb杻䘖셅뷂ਿ衛", 22 - (ViewConfiguration.getScrollDefaultDelay() >> 16), objArr14);
                    Class<?> cls4 = Class.forName((String) objArr14[0]);
                    Object[] objArr15 = new Object[1];
                    ae("\ud9ee舓䷏㳳\uea89컢酭䓁ﲝ杴辨쀎\uf5a7㵋ၗ\udb16", (ExpandableListView.getPackedPositionForChild(0, 0) > j ? 1 : (ExpandableListView.getPackedPositionForChild(0, 0) == j ? 0 : -1)) + 16, objArr15);
                    long jLongValue2 = ((Long) cls4.getDeclaredMethod((String) objArr15[0], null).invoke(null, null)).longValue();
                    Long lValueOf = Long.valueOf(jLongValue2);
                    Object objD7 = an.d(-1398649561);
                    if (objD7 == null) {
                        int i13 = (CdmaCellLocation.convertQuartSecToDecDegrees(0) > 0.0d ? 1 : (CdmaCellLocation.convertQuartSecToDecDegrees(0) == 0.0d ? 0 : -1)) + 711;
                        char packedPositionType = (char) (ExpandableListView.getPackedPositionType(j) + i3);
                        int i14 = 24 - (TypedValue.complexToFloat(0) > SelfieScan.RECOGNITION_FAIL_RESULT ? 1 : (TypedValue.complexToFloat(0) == SelfieScan.RECOGNITION_FAIL_RESULT ? 0 : -1));
                        byte b12 = (byte) 0;
                        byte b13 = b12;
                        c3 = 2;
                        Object[] objArr16 = new Object[1];
                        ad(b12, b13, (byte) (b13 + 1), objArr16);
                        objD7 = an.d(i13, packedPositionType, i14, -624714116, false, (String) objArr16[0], null);
                    } else {
                        c3 = 2;
                    }
                    ((Field) objD7).set(null, lValueOf);
                    Long lValueOf2 = Long.valueOf(jLongValue2 >> 12);
                    Object objD8 = an.d(i2);
                    if (objD8 == null) {
                        int i15 = (Process.getElapsedCpuTime() > j ? 1 : (Process.getElapsedCpuTime() == j ? 0 : -1)) + 710;
                        char c7 = (char) (i3 - (TypedValue.complexToFloat(0) > SelfieScan.RECOGNITION_FAIL_RESULT ? 1 : (TypedValue.complexToFloat(0) == SelfieScan.RECOGNITION_FAIL_RESULT ? 0 : -1)));
                        int iIndexOf2 = 24 - TextUtils.indexOf("", "", 0);
                        byte b14 = (byte) 0;
                        byte b15 = b14;
                        Object[] objArr17 = new Object[1];
                        ad(b14, b15, (byte) (b15 + 2), objArr17);
                        objD8 = an.d(i15, c7, iIndexOf2, -623790093, false, (String) objArr17[0], null);
                    }
                    ((Field) objD8).set(null, lValueOf2);
                } catch (Exception unused) {
                    throw new RuntimeException();
                }
            } catch (Throwable th) {
                Throwable cause = th.getCause();
                if (cause == null) {
                    throw th;
                }
                throw cause;
            }
        }
        int i16 = ((int[]) objArr[c3])[0];
        int i17 = ((int[]) objArr[1])[0];
        if (i17 == i16) {
            Object[] objArr18 = new Object[4];
            objArr18[1] = new int[]{i};
            objArr18[c3] = new int[]{i};
            objArr18[c2] = new int[1];
            int i18 = ((int[]) objArr[c2])[0];
            int i19 = ((int[]) objArr[1])[0];
            int i20 = ((int[]) objArr[c3])[0];
            objArr18[0] = (String[]) objArr[0];
            int iIdentityHashCode = System.identityHashCode(this);
            int i21 = ~iIdentityHashCode;
            int i22 = ~(80223351 | i21);
            int i23 = i18 + 761141918 + ((957644928 | i22) * (-712)) + (((~(iIdentityHashCode | 1037868279)) | (~(i21 | (-957644929)))) * (-712)) + (((-966564008) | i22) * 712);
            int i24 = (i23 << 13) ^ i23;
            int i25 = i24 ^ (i24 >>> 17);
            ((int[]) objArr18[c2])[0] = i25 ^ (i25 << 5);
            return;
        }
        ArrayList arrayList = new ArrayList();
        String[] strArr2 = (String[]) objArr[0];
        if (strArr2 != null) {
            O = (U + 17) % 128;
            for (String str2 : strArr2) {
                arrayList.add(str2);
            }
        }
        Toast.makeText((Context) null, i17 / (((i17 - 1) * i17) % 2), 0).show();
        Object[] objArr19 = new Object[4];
        objArr19[1] = new int[]{i};
        objArr19[c3] = new int[]{i};
        objArr19[c2] = new int[1];
        int i26 = ((int[]) objArr[c2])[0];
        int i27 = ((int[]) objArr[1])[0];
        int i28 = ((int[]) objArr[c3])[0];
        objArr19[0] = (String[]) objArr[0];
        int iIdentityHashCode2 = System.identityHashCode(this);
        int i29 = (~((-262820633) | iIdentityHashCode2)) | 246039040;
        int i30 = ~((~iIdentityHashCode2) | 800748318);
        int i31 = i26 + 721019166 + ((i29 | i30) * (-470)) + (((~(iIdentityHashCode2 | (-16781593))) | i30) * 470);
        int i32 = (i31 << 13) ^ i31;
        int i33 = i32 ^ (i32 >>> 17);
        ((int[]) objArr19[c2])[0] = i33 ^ (i33 << 5);
    }

    private dl C() {
        final WeakReference weakReference = new WeakReference(this);
        dl dlVar = new dl(new Runnable() { // from class: com.facetec.sdk.兵书
            @Override // java.lang.Runnable
            public final void run() {
                cp.c(weakReference);
            }
        });
        int i2 = O + 113;
        U = i2 % 128;
        if (i2 % 2 != 0) {
            return dlVar;
        }
        throw null;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void D() throws Throwable {
        int i2;
        int i3;
        int i4;
        char c2;
        long j;
        Object[] objArr;
        Object objD = an.d(-1397726040);
        int i5 = 0;
        if (objD == null) {
            int iAxisFromString = 710 - MotionEvent.axisFromString("");
            char minimumFlingVelocity = (char) (49308 - (ViewConfiguration.getMinimumFlingVelocity() >> 16));
            int iMyPid = 24 - (Process.myPid() >> 22);
            byte b2 = (byte) 0;
            byte b3 = b2;
            Object[] objArr2 = new Object[1];
            ad(b2, b3, (byte) (b3 + 2), objArr2);
            objD = an.d(iAxisFromString, minimumFlingVelocity, iMyPid, -623790093, false, (String) objArr2[0], null);
        }
        long j2 = ((Field) objD).getLong(null);
        Object[] objArr3 = new Object[1];
        ae("흗듩綁䉁斣氌鯸Ꮾ䶜༜\udeab㋘㽼ꥌ⃢\ueacb杻䘖셅뷂ਿ衛", 22 - TextUtils.indexOf("", ""), objArr3);
        Class<?> cls = Class.forName((String) objArr3[0]);
        Object[] objArr4 = new Object[1];
        ae("\ud9ee舓䷏㳳\uea89컢酭䓁ﲝ杴辨쀎\uf5a7㵋ၗ\udb16", 15 - (Process.myTid() >> 22), objArr4);
        long jLongValue = ((Long) cls.getDeclaredMethod((String) objArr4[0], null).invoke(null, null)).longValue();
        Object objD2 = an.d(-1398649561);
        if (objD2 == null) {
            int iNormalizeMetaState = KeyEvent.normalizeMetaState(0) + 711;
            char minimumFlingVelocity2 = (char) (49308 - (ViewConfiguration.getMinimumFlingVelocity() >> 16));
            int i6 = 25 - (SystemClock.currentThreadTimeMillis() > (-1L) ? 1 : (SystemClock.currentThreadTimeMillis() == (-1L) ? 0 : -1));
            byte b4 = (byte) 0;
            i2 = -1397726040;
            byte b5 = b4;
            i3 = -1398649561;
            i4 = 49308;
            Object[] objArr5 = new Object[1];
            ad(b4, b5, (byte) (b5 + 1), objArr5);
            objD2 = an.d(iNormalizeMetaState, minimumFlingVelocity2, i6, -624714116, false, (String) objArr5[0], null);
        } else {
            i2 = -1397726040;
            i3 = -1398649561;
            i4 = 49308;
        }
        if (j2 == ((jLongValue - ((((Field) objD2).getLong(null) << 52) >>> 52)) >> 12)) {
            O = (U + 101) % 128;
            Object objD3 = an.d(-1399573082);
            if (objD3 == null) {
                int fadingEdgeLength = (ViewConfiguration.getFadingEdgeLength() >> 16) + 711;
                char c3 = (char) (i4 - (ExpandableListView.getPackedPositionForGroup(0) > 0L ? 1 : (ExpandableListView.getPackedPositionForGroup(0) == 0L ? 0 : -1)));
                int iBlue = Color.blue(0) + 24;
                byte b6 = (byte) 0;
                byte b7 = b6;
                Object[] objArr6 = new Object[1];
                ad(b6, b7, b7, objArr6);
                objD3 = an.d(fadingEdgeLength, c3, iBlue, -621418755, false, (String) objArr6[0], null);
            }
            Object[] objArr7 = (Object[]) ((Field) objD3).get(null);
            objArr = new Object[]{strArr, new int[]{i}, new int[]{i}, new int[1]};
            int i7 = ((int[]) objArr7[1])[0];
            int i8 = ((int[]) objArr7[2])[0];
            String[] strArr = (String[]) objArr7[0];
            int iIdentityHashCode = System.identityHashCode(this);
            int i9 = (-373926418) + (((~(751871879 | iIdentityHashCode)) | (-1037348760) | (~(294915479 | iIdentityHashCode))) * (-744)) + (((~iIdentityHashCode) | 9438599) * 744) + ((iIdentityHashCode | 1037348759) * 744) + 465673496;
            int i10 = (i9 << 13) ^ i9;
            int i11 = i10 ^ (i10 >>> 17);
            ((int[]) objArr[3])[0] = i11 ^ (i11 << 5);
            c2 = 3;
        } else {
            Object[] objArr8 = new Object[1];
            ae("\uf16d\ue0e7糉羃㴽ꄩ흗듩㐫◙缭\uf637育诹로돏", (ViewConfiguration.getFadingEdgeLength() >> 16) + 16, objArr8);
            Class<?> cls2 = Class.forName((String) objArr8[0]);
            Object[] objArr9 = new Object[1];
            ae("ꑐ݂緞漙糄\uf38e嗴\udc2bꑇ舧쳻⤟쁯ꚿ㊗ై", TextUtils.lastIndexOf("", '0') + 17, objArr9);
            int iIntValue = ((Integer) cls2.getMethod((String) objArr9[0], Object.class).invoke(null, this)).intValue();
            try {
                Object[] objArr10 = {154598540};
                Object objD4 = an.d(1683332522);
                if (objD4 == null) {
                    objD4 = an.d(830 - (ViewConfiguration.getWindowTouchSlop() >> 8), (char) (ViewConfiguration.getDoubleTapTimeout() >> 16), 24 - TextUtils.getOffsetBefore("", 0), 305417969, false, null, new Class[]{Integer.TYPE});
                }
                Object[] objArr11 = {Integer.valueOf(iIntValue), 0, 465673496, ((Constructor) objD4).newInstance(objArr10), Boolean.FALSE};
                Object objD5 = an.d(1794077343);
                if (objD5 == null) {
                    int i12 = 712 - (SystemClock.uptimeMillis() > 0L ? 1 : (SystemClock.uptimeMillis() == 0L ? 0 : -1));
                    char cKeyCodeFromString = (char) (KeyEvent.keyCodeFromString("") + i4);
                    int jumpTapTimeout = 24 - (ViewConfiguration.getJumpTapTimeout() >> 16);
                    byte b8 = (byte) 0;
                    byte b9 = b8;
                    c2 = 3;
                    j = 0;
                    Object[] objArr12 = new Object[1];
                    ad(b8, b9, (byte) (b9 + 1), objArr12);
                    String str = (String) objArr12[0];
                    Class cls3 = Integer.TYPE;
                    objD5 = an.d(i12, cKeyCodeFromString, jumpTapTimeout, 479109572, false, str, new Class[]{cls3, cls3, cls3, (Class) an.b((ViewConfiguration.getKeyRepeatTimeout() >> 16) + 799, (char) (ViewConfiguration.getEdgeSlop() >> 16), KeyEvent.normalizeMetaState(0) + 31), Boolean.TYPE});
                } else {
                    c2 = 3;
                    j = 0;
                }
                Object[] objArr13 = (Object[]) ((Method) objD5).invoke(null, objArr11);
                Object objD6 = an.d(-1399573082);
                if (objD6 == null) {
                    int i13 = 712 - (ViewConfiguration.getZoomControlsTimeout() > j ? 1 : (ViewConfiguration.getZoomControlsTimeout() == j ? 0 : -1));
                    char cGreen = (char) (Color.green(0) + i4);
                    int capsMode = TextUtils.getCapsMode("", 0, 0) + 24;
                    byte b10 = (byte) 0;
                    byte b11 = b10;
                    Object[] objArr14 = new Object[1];
                    ad(b10, b11, b11, objArr14);
                    objD6 = an.d(i13, cGreen, capsMode, -621418755, false, (String) objArr14[0], null);
                }
                ((Field) objD6).set(null, objArr13);
                try {
                    Object[] objArr15 = new Object[1];
                    ae("흗듩綁䉁斣氌鯸Ꮾ䶜༜\udeab㋘㽼ꥌ⃢\ueacb杻䘖셅뷂ਿ衛", (ViewConfiguration.getScrollBarFadeDuration() >> 16) + 22, objArr15);
                    Class<?> cls4 = Class.forName((String) objArr15[0]);
                    Object[] objArr16 = new Object[1];
                    ae("\ud9ee舓䷏㳳\uea89컢酭䓁ﲝ杴辨쀎\uf5a7㵋ၗ\udb16", 16 - (Process.getElapsedCpuTime() > j ? 1 : (Process.getElapsedCpuTime() == j ? 0 : -1)), objArr16);
                    long jLongValue2 = ((Long) cls4.getDeclaredMethod((String) objArr16[0], null).invoke(null, null)).longValue();
                    Long lValueOf = Long.valueOf(jLongValue2);
                    Object objD7 = an.d(i3);
                    if (objD7 == null) {
                        int i14 = (SystemClock.elapsedRealtime() > j ? 1 : (SystemClock.elapsedRealtime() == j ? 0 : -1)) + 710;
                        char threadPriority = (char) (((Process.getThreadPriority(0) + 20) >> 6) + i4);
                        int size = View.MeasureSpec.getSize(0) + 24;
                        byte b12 = (byte) 0;
                        byte b13 = b12;
                        Object[] objArr17 = new Object[1];
                        ad(b12, b13, (byte) (b13 + 1), objArr17);
                        objD7 = an.d(i14, threadPriority, size, -624714116, false, (String) objArr17[0], null);
                    }
                    ((Field) objD7).set(null, lValueOf);
                    Long lValueOf2 = Long.valueOf(jLongValue2 >> 12);
                    Object objD8 = an.d(i2);
                    if (objD8 == null) {
                        int mirror = 759 - AndroidCharacter.getMirror('0');
                        char scrollDefaultDelay = (char) (i4 - (ViewConfiguration.getScrollDefaultDelay() >> 16));
                        int threadPriority2 = ((Process.getThreadPriority(0) + 20) >> 6) + 24;
                        byte b14 = (byte) 0;
                        byte b15 = b14;
                        Object[] objArr18 = new Object[1];
                        ad(b14, b15, (byte) (b15 + 2), objArr18);
                        objD8 = an.d(mirror, scrollDefaultDelay, threadPriority2, -623790093, false, (String) objArr18[0], null);
                    }
                    ((Field) objD8).set(null, lValueOf2);
                    objArr = objArr13;
                } catch (Exception unused) {
                    throw new RuntimeException();
                }
            } catch (Throwable th) {
                Throwable cause = th.getCause();
                if (cause == null) {
                    throw th;
                }
                throw cause;
            }
        }
        int i15 = ((int[]) objArr[2])[0];
        int i16 = ((int[]) objArr[1])[0];
        if (i16 != i15) {
            ArrayList arrayList = new ArrayList();
            String[] strArr2 = (String[]) objArr[0];
            if (strArr2 != null) {
                U = (O + 35) % 128;
                while (i5 < strArr2.length) {
                    arrayList.add(strArr2[i5]);
                    i5++;
                    O = (U + 53) % 128;
                }
            }
            throw new RuntimeException(String.valueOf(i16));
        }
        U = (O + 41) % 128;
        Object[] objArr19 = new Object[4];
        objArr19[1] = new int[]{i};
        objArr19[2] = new int[]{i};
        objArr19[c2] = new int[1];
        int i17 = ((int[]) objArr[c2])[0];
        int i18 = ((int[]) objArr[1])[0];
        int i19 = ((int[]) objArr[2])[0];
        objArr19[0] = (String[]) objArr[0];
        int i20 = (int) Runtime.getRuntime().totalMemory();
        int i21 = i17 + 1280170350 + (((~((-785630917) | i20)) | 244368960) * 336) + (((~(i20 | 261156442)) | (-802418399)) * (-168)) + (((~((~i20) | 261156442)) | (-785630917)) * EnumC41897g.SDK_ASSET_ILLUSTRATION_CODE_ACCOUNT_VERIFICATION_VALUE);
        int i22 = (i21 << 13) ^ i21;
        int i23 = i22 ^ (i22 >>> 17);
        ((int[]) objArr19[c2])[0] = i23 ^ (i23 << 5);
    }

    private void E() {
        int iD = bb.d();
        int iD2 = bb.d();
        int iD3 = bb.d();
        b(-1216704366, iD, bb.d(), iD2, 1216704372, iD3, new Object[]{this});
    }

    private static void F() {
        U = (O + 105) % 128;
        o.c();
        int i2 = O + EnumC41897g.SDK_ASSET_ILLUSTRATION_DEPOSIT_SWITCH_VALUE;
        U = i2 % 128;
        if (i2 % 2 == 0) {
            int i3 = 85 / 0;
        }
    }

    private void G() {
        O = (U + 3) % 128;
        this.I = false;
        this.D.release();
        int i2 = O + 61;
        U = i2 % 128;
        if (i2 % 2 == 0) {
            int i3 = 38 / 0;
        }
    }

    private void H() {
        TimeUnit timeUnit;
        int i2 = O + 83;
        U = i2 % 128;
        try {
            if (i2 % 2 == 0) {
                int iD = bb.d();
                int iD2 = bb.d();
                int iD3 = bb.d();
                b(-1456391372, iD, bb.d(), iD2, 1456391379, iD3, new Object[]{this});
                a(false);
                ExecutorService executorService = this.f95856g;
                timeUnit = TimeUnit.SECONDS;
                executorService.awaitTermination(2L, timeUnit);
            } else {
                int iD4 = bb.d();
                int iD5 = bb.d();
                int iD6 = bb.d();
                b(-1456391372, iD4, bb.d(), iD5, 1456391379, iD6, new Object[]{this});
                a(true);
                ExecutorService executorService2 = this.f95856g;
                timeUnit = TimeUnit.SECONDS;
                executorService2.awaitTermination(2L, timeUnit);
            }
            this.m.awaitTermination(2L, timeUnit);
            U = (O + 11) % 128;
        } catch (InterruptedException unused) {
        }
        I();
    }

    private void I() {
        synchronized (this.A) {
            try {
                this.z = null;
                TimerTask timerTask = this.C;
                if (timerTask != null) {
                    timerTask.cancel();
                    this.C = null;
                }
            } catch (Throwable th) {
                throw th;
            }
        }
    }

    private synchronized void J() {
        U = (O + EnumC41897g.SDK_ASSET_ILLUSTRATION_DEPOSIT_SWITCH_VALUE) % 128;
        Activity activity = this.l.get();
        if (activity == null) {
            return;
        }
        activity.runOnUiThread(new Runnable() { // from class: com.facetec.sdk.兵乐
            @Override // java.lang.Runnable
            public final void run() {
                this.f7055.ag();
            }
        });
        int i2 = O + 45;
        U = i2 % 128;
        if (i2 % 2 == 0) {
            int i3 = 15 / 0;
        }
    }

    private synchronized void K() {
        try {
            O = (U + 33) % 128;
            Activity activity = this.l.get();
            if (activity != null) {
                activity.runOnUiThread(new Runnable() { // from class: com.facetec.sdk.兵山
                    @Override // java.lang.Runnable
                    public final void run() {
                        this.f7075.ah();
                    }
                });
                return;
            }
            int i2 = U + 69;
            O = i2 % 128;
            if (i2 % 2 == 0) {
            } else {
                throw null;
            }
        } catch (Throwable th) {
            throw th;
        }
    }

    private synchronized void L() {
        Activity activity = this.l.get();
        if (activity == null) {
            int i2 = U + 33;
            O = i2 % 128;
            if (i2 % 2 != 0) {
                int i3 = 90 / 0;
                return;
            }
            return;
        }
        cu cuVar = this.n;
        if (cuVar == cu.PROCESSING_COMPLETE_STILL_COMPUTING) {
            activity.runOnUiThread(new Runnable() { // from class: com.facetec.sdk.兵土
                @Override // java.lang.Runnable
                public final void run() {
                    this.f7068.Z();
                }
            });
            return;
        }
        if (cuVar == cu.PROCESSING_COMPLETE_TIMED_OUT) {
            U = (O + 113) % 128;
            activity.runOnUiThread(new Runnable() { // from class: com.facetec.sdk.兵地
                @Override // java.lang.Runnable
                public final void run() {
                    this.f7069.aa();
                }
            });
            return;
        }
        if (cuVar != cu.PROCESSING_COMPLETE_RETRY) {
            if (cuVar != cu.PROCESSING_COMPLETE_SUCCESS) {
                activity.runOnUiThread(new Runnable() { // from class: com.facetec.sdk.兵妖
                    @Override // java.lang.Runnable
                    public final void run() {
                        this.f7072.Y();
                    }
                });
                return;
            } else {
                U = (O + 103) % 128;
                activity.runOnUiThread(new Runnable() { // from class: com.facetec.sdk.兵天
                    @Override // java.lang.Runnable
                    public final void run() {
                        this.f7071.ab();
                    }
                });
                return;
            }
        }
        int i4 = U + 83;
        O = i4 % 128;
        if (i4 % 2 == 0) {
            activity.runOnUiThread(new Runnable() { // from class: com.facetec.sdk.兵城
                @Override // java.lang.Runnable
                public final void run() {
                    this.f7070.ac();
                }
            });
        } else {
            activity.runOnUiThread(new Runnable() { // from class: com.facetec.sdk.兵城
                @Override // java.lang.Runnable
                public final void run() {
                    this.f7070.ac();
                }
            });
            throw null;
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void M() throws Throwable {
        JSONObject jSONObjectB = this.b.d().b();
        Object[] objArr = new Object[1];
        ak((SystemClock.uptimeMillis() > 0L ? 1 : (SystemClock.uptimeMillis() == 0L ? 0 : -1)) + 2, "\u0007\t㘪", (byte) ((ViewConfiguration.getLongPressTimeout() >> 16) + 47), objArr);
        String strOptString = jSONObjectB.optString(((String) objArr[0]).intern());
        Object[] objArr2 = new Object[1];
        ak(TextUtils.getTrimmedLength("") + 3, "\r\b㙥", (byte) (TextUtils.getTrimmedLength("") + 106), objArr2);
        String strOptString2 = jSONObjectB.optString(((String) objArr2[0]).intern());
        Object[] objArr3 = new Object[1];
        ak(Color.rgb(0, 0, 0) + 16777218, "\u0005\u0007", (byte) (Color.argb(0, 0, 0, 0) + 60), objArr3);
        String strOptString3 = jSONObjectB.optString(((String) objArr3[0]).intern());
        Object[] objArr4 = new Object[1];
        ak((ViewConfiguration.getScrollDefaultDelay() >> 16) + 5, "\n\b\r\u000b㘆", (byte) (11 - View.MeasureSpec.getSize(0)), objArr4);
        String strOptString4 = jSONObjectB.optString(((String) objArr4[0]).intern());
        Object[] objArr5 = new Object[1];
        al(null, 127 - View.MeasureSpec.getSize(0), null, "\u0085\u0084\u0083\u0082\u0081", objArr5);
        String strOptString5 = jSONObjectB.optString(((String) objArr5[0]).intern());
        Object[] objArr6 = new Object[1];
        ak(5 - TextUtils.getOffsetBefore("", 0), "\u0002\u000e\n\u0005㘤", (byte) ((ViewConfiguration.getScrollFriction() > SelfieScan.RECOGNITION_FAIL_RESULT ? 1 : (ViewConfiguration.getScrollFriction() == SelfieScan.RECOGNITION_FAIL_RESULT ? 0 : -1)) + 120), objArr6);
        String strOptString6 = jSONObjectB.optString(((String) objArr6[0]).intern());
        Object[] objArr7 = new Object[1];
        ak(5 - (PointF.length(SelfieScan.RECOGNITION_FAIL_RESULT, SelfieScan.RECOGNITION_FAIL_RESULT) > SelfieScan.RECOGNITION_FAIL_RESULT ? 1 : (PointF.length(SelfieScan.RECOGNITION_FAIL_RESULT, SelfieScan.RECOGNITION_FAIL_RESULT) == SelfieScan.RECOGNITION_FAIL_RESULT ? 0 : -1)), "\u0002\u000e\n\u0005㗿", (byte) (87 - (ViewConfiguration.getDoubleTapTimeout() >> 16)), objArr7);
        String strOptString7 = jSONObjectB.optString(((String) objArr7[0]).intern());
        Object[] objArr8 = new Object[1];
        ak(ExpandableListView.getPackedPositionChild(0L) + 6, "\u0002\u000e\n\u0005㖿", (byte) (21 - TextUtils.lastIndexOf("", '0', 0)), objArr8);
        String strOptString8 = jSONObjectB.optString(((String) objArr8[0]).intern());
        Object[] objArr9 = new Object[1];
        al(null, 127 - ExpandableListView.getPackedPositionType(0L), null, "\u0086\u0082\u0083\u0082\u0084", objArr9);
        String strOptString9 = jSONObjectB.optString(((String) objArr9[0]).intern());
        Object[] objArr10 = new Object[1];
        al(null, ImageFormat.getBitsPerPixel(0) + 128, null, "\u0086\u0082\u0083\u0082\u0081", objArr10);
        String strOptString10 = jSONObjectB.optString(((String) objArr10[0]).intern());
        Object[] objArr11 = new Object[1];
        al(null, 127 - (ViewConfiguration.getKeyRepeatTimeout() >> 16), null, "\u0088\u0086\u0082\u0087\u0086", objArr11);
        String strOptString11 = jSONObjectB.optString(((String) objArr11[0]).intern());
        Object[] objArr12 = new Object[1];
        al(null, (SystemClock.elapsedRealtime() > 0L ? 1 : (SystemClock.elapsedRealtime() == 0L ? 0 : -1)) + 126, null, "\u0089\u0086\u0082\u0087\u0086", objArr12);
        String strOptString12 = jSONObjectB.optString(((String) objArr12[0]).intern());
        Object[] objArr13 = new Object[1];
        al(null, KeyEvent.keyCodeFromString("") + 127, null, "\u008a\u0086\u0082\u0087\u0086", objArr13);
        String strOptString13 = jSONObjectB.optString(((String) objArr13[0]).intern());
        Object[] objArr14 = new Object[1];
        ak(2 - MotionEvent.axisFromString(""), "\u0007\t㘪", (byte) (46 - ((byte) KeyEvent.getModifierMetaStateMask())), objArr14);
        cv.d(((String) objArr14[0]).intern(), strOptString);
        Object[] objArr15 = new Object[1];
        ak('2' - AndroidCharacter.getMirror('0'), "\u0005\u0007", (byte) (60 - TextUtils.getTrimmedLength("")), objArr15);
        cv.d(((String) objArr15[0]).intern(), strOptString3);
        Object[] objArr16 = new Object[1];
        ak(3 - Color.green(0), "\r\b㙥", (byte) (106 - ExpandableListView.getPackedPositionGroup(0L)), objArr16);
        cv.d(((String) objArr16[0]).intern(), strOptString2);
        Object[] objArr17 = new Object[1];
        ak((ViewConfiguration.getWindowTouchSlop() >> 8) + 5, "\n\b\r\u000b㘆", (byte) (11 - (ViewConfiguration.getDoubleTapTimeout() >> 16)), objArr17);
        cv.d(((String) objArr17[0]).intern(), strOptString4);
        Object[] objArr18 = new Object[1];
        al(null, (ViewConfiguration.getGlobalActionKeyTimeout() > 0L ? 1 : (ViewConfiguration.getGlobalActionKeyTimeout() == 0L ? 0 : -1)) + 126, null, "\u0085\u0084\u0083\u0082\u0081", objArr18);
        cv.d(((String) objArr18[0]).intern(), strOptString5);
        Object[] objArr19 = new Object[1];
        ak((AudioTrack.getMaxVolume() > SelfieScan.RECOGNITION_FAIL_RESULT ? 1 : (AudioTrack.getMaxVolume() == SelfieScan.RECOGNITION_FAIL_RESULT ? 0 : -1)) + 4, "\u0002\u000e\n\u0005㘤", (byte) ((ViewConfiguration.getGlobalActionKeyTimeout() > 0L ? 1 : (ViewConfiguration.getGlobalActionKeyTimeout() == 0L ? 0 : -1)) + 120), objArr19);
        cv.d(((String) objArr19[0]).intern(), strOptString6);
        Object[] objArr20 = new Object[1];
        ak(5 - (TypedValue.complexToFraction(0, SelfieScan.RECOGNITION_FAIL_RESULT, SelfieScan.RECOGNITION_FAIL_RESULT) > SelfieScan.RECOGNITION_FAIL_RESULT ? 1 : (TypedValue.complexToFraction(0, SelfieScan.RECOGNITION_FAIL_RESULT, SelfieScan.RECOGNITION_FAIL_RESULT) == SelfieScan.RECOGNITION_FAIL_RESULT ? 0 : -1)), "\u0002\u000e\n\u0005㗿", (byte) (KeyEvent.keyCodeFromString("") + 87), objArr20);
        cv.d(((String) objArr20[0]).intern(), strOptString7);
        Object[] objArr21 = new Object[1];
        ak(5 - (PointF.length(SelfieScan.RECOGNITION_FAIL_RESULT, SelfieScan.RECOGNITION_FAIL_RESULT) > SelfieScan.RECOGNITION_FAIL_RESULT ? 1 : (PointF.length(SelfieScan.RECOGNITION_FAIL_RESULT, SelfieScan.RECOGNITION_FAIL_RESULT) == SelfieScan.RECOGNITION_FAIL_RESULT ? 0 : -1)), "\u0002\u000e\n\u0005㖿", (byte) ((ExpandableListView.getPackedPositionForChild(0, 0) > 0L ? 1 : (ExpandableListView.getPackedPositionForChild(0, 0) == 0L ? 0 : -1)) + 23), objArr21);
        cv.d(((String) objArr21[0]).intern(), strOptString8);
        Object[] objArr22 = new Object[1];
        al(null, (ViewConfiguration.getScrollFriction() > SelfieScan.RECOGNITION_FAIL_RESULT ? 1 : (ViewConfiguration.getScrollFriction() == SelfieScan.RECOGNITION_FAIL_RESULT ? 0 : -1)) + 126, null, "\u0086\u0082\u0083\u0082\u0084", objArr22);
        cv.H(((String) objArr22[0]).intern(), Integer.parseInt(strOptString9));
        Object[] objArr23 = new Object[1];
        al(null, 127 - (CdmaCellLocation.convertQuartSecToDecDegrees(0) > 0.0d ? 1 : (CdmaCellLocation.convertQuartSecToDecDegrees(0) == 0.0d ? 0 : -1)), null, "\u0086\u0082\u0083\u0082\u0081", objArr23);
        cv.H(((String) objArr23[0]).intern(), Integer.parseInt(strOptString10));
        Object[] objArr24 = new Object[1];
        al(null, (SystemClock.elapsedRealtimeNanos() > 0L ? 1 : (SystemClock.elapsedRealtimeNanos() == 0L ? 0 : -1)) + 126, null, "\u0088\u0086\u0082\u0087\u0086", objArr24);
        cv.H(((String) objArr24[0]).intern(), Integer.parseInt(strOptString11));
        Object[] objArr25 = new Object[1];
        al(null, 127 - (ViewConfiguration.getKeyRepeatDelay() >> 16), null, "\u0089\u0086\u0082\u0087\u0086", objArr25);
        cv.H(((String) objArr25[0]).intern(), Integer.parseInt(strOptString12));
        Object[] objArr26 = new Object[1];
        al(null, 127 - TextUtils.indexOf("", "", 0, 0), null, "\u008a\u0086\u0082\u0087\u0086", objArr26);
        cv.H(((String) objArr26[0]).intern(), Integer.parseInt(strOptString13));
        try {
            Object[] objArr27 = new Object[1];
            ak(View.MeasureSpec.makeMeasureSpec(0, 0) + 3, "\u0007\t㘪", (byte) ((ViewConfiguration.getMaximumFlingVelocity() >> 16) + 47), objArr27);
            jSONObjectB.put(((String) objArr27[0]).intern(), new ArrayList().toString());
            Object[] objArr28 = new Object[1];
            ak(5 - Color.green(0), "\u0002\u000e\n\u0005㘤", (byte) (121 - TextUtils.indexOf("", "", 0)), objArr28);
            jSONObjectB.put(((String) objArr28[0]).intern(), new ArrayList().toString());
            Object[] objArr29 = new Object[1];
            ak((SystemClock.uptimeMillis() > 0L ? 1 : (SystemClock.uptimeMillis() == 0L ? 0 : -1)) + 4, "\u0002\u000e\n\u0005㗿", (byte) (87 - TextUtils.getOffsetAfter("", 0)), objArr29);
            jSONObjectB.put(((String) objArr29[0]).intern(), new ArrayList().toString());
            Object[] objArr30 = new Object[1];
            ak((TypedValue.complexToFloat(0) > SelfieScan.RECOGNITION_FAIL_RESULT ? 1 : (TypedValue.complexToFloat(0) == SelfieScan.RECOGNITION_FAIL_RESULT ? 0 : -1)) + 5, "\u0002\u000e\n\u0005㖿", (byte) (Gravity.getAbsoluteGravity(0, 0) + 22), objArr30);
            jSONObjectB.put(((String) objArr30[0]).intern(), new ArrayList().toString());
            U = (O + 35) % 128;
        } catch (JSONException unused) {
        }
        Object[] objArr31 = new Object[1];
        al(null, 126 - ExpandableListView.getPackedPositionChild(0L), null, "\u0083\u008b\u0083", objArr31);
        cv.M(((String) objArr31[0]).intern(), jSONObjectB.toString());
    }

    private void N() {
        synchronized (this.v) {
            a aVar = this.y;
            if (aVar == a.FINISHED || aVar == a.WAITING_TO_FINISH) {
                return;
            }
            synchronized (this.A) {
                try {
                    if (this.z == null) {
                        return;
                    }
                    long time = new Date().getTime() - this.z.getTime();
                    if (time > 615000) {
                        n.a(new Throwable("Phoenix hang was detected"));
                        a(false);
                        this.n = cu.PROCESSING_COMPLETE_TIMED_OUT;
                        L();
                    }
                } catch (Throwable th) {
                    throw th;
                }
            }
        }
    }

    @NonNull
    private synchronized List<d> O() {
        List<d> listA;
        try {
            int i2 = U + 27;
            O = i2 % 128;
            if (i2 % 2 != 0) {
                listA = a(this.f);
                int i3 = 6 / 0;
            } else {
                listA = a(this.f);
            }
            int i4 = O + 113;
            U = i4 % 128;
            if (i4 % 2 == 0) {
                throw null;
            }
        } catch (Throwable th) {
            throw th;
        }
        return listA;
    }

    @NonNull
    private synchronized List<b> P() {
        List<b> listA;
        try {
            int i2 = U + EnumC41897g.SDK_ASSET_ILLUSTRATION_CALENDAR_VALUE;
            O = i2 % 128;
            if (i2 % 2 != 0) {
                listA = a(this.h);
                int i3 = 31 / 0;
            } else {
                listA = a(this.h);
            }
        } catch (Throwable th) {
            throw th;
        }
        return listA;
    }

    @NonNull
    private synchronized List<e> Q() {
        int i2 = O + 65;
        U = i2 % 128;
        if (i2 % 2 == 0) {
            a(this.j);
            throw null;
        }
        return a(this.j);
    }

    private synchronized void R() {
        try {
            U = (O + 119) % 128;
            Iterator<e> it = Q().iterator();
            while (it.hasNext()) {
                it.next().b();
                O = (U + 37) % 128;
            }
            int i2 = O + 87;
            U = i2 % 128;
            if (i2 % 2 == 0) {
                throw null;
            }
        } catch (Throwable th) {
            throw th;
        }
    }

    private synchronized void S() {
        try {
            U = (O + 21) % 128;
            Iterator<e> it = Q().iterator();
            while (it.hasNext()) {
                int i2 = O + 47;
                U = i2 % 128;
                if (i2 % 2 == 0) {
                    it.next().d();
                    int i3 = 25 / 0;
                } else {
                    it.next().d();
                }
            }
        } catch (Throwable th) {
            throw th;
        }
    }

    private synchronized void T() {
        Iterator<b> it = P().iterator();
        while (it.hasNext()) {
            it.next().onPreSessionProgress(this.t, this.q, this.r, this.s);
            O = (U + 57) % 128;
        }
        U = (O + 21) % 128;
    }

    private synchronized void U() {
        try {
            int i2 = U + 15;
            O = i2 % 128;
            if (i2 % 2 != 0) {
                Q().iterator();
                throw null;
            }
            Iterator<e> it = Q().iterator();
            while (it.hasNext()) {
                it.next().c(this.n, this.o);
            }
            int i3 = O + 101;
            U = i3 % 128;
            if (i3 % 2 == 0) {
                throw null;
            }
        } catch (Throwable th) {
            throw th;
        }
    }

    private synchronized void V() {
        Iterator<d> it;
        try {
            int i2 = O + 41;
            U = i2 % 128;
            if (i2 % 2 == 0) {
                it = O().iterator();
                int i3 = 33 / 0;
            } else {
                it = O().iterator();
            }
            O = (U + 53) % 128;
            while (it.hasNext()) {
                U = (O + 55) % 128;
                it.next().onIDScanProgress(this.k, this.p);
            }
        } catch (Throwable th) {
            throw th;
        }
    }

    private synchronized void W() {
        try {
            Iterator<e> it = Q().iterator();
            O = (U + 61) % 128;
            while (it.hasNext()) {
                it.next().e();
                U = (O + 5) % 128;
            }
            int i2 = U + 37;
            O = i2 % 128;
            if (i2 % 2 != 0) {
                throw null;
            }
        } catch (Throwable th) {
            throw th;
        }
    }

    private synchronized void X() {
        U = (O + 67) % 128;
        Iterator<e> it = Q().iterator();
        O = (U + 119) % 128;
        while (it.hasNext()) {
            it.next().a();
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void Y() {
        U = (O + 115) % 128;
        U();
        U = (O + 3) % 128;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void Z() {
        U = (O + 79) % 128;
        R();
        int i2 = O + 1;
        U = i2 % 128;
        if (i2 % 2 == 0) {
            throw null;
        }
    }

    public static /* synthetic */ void a(cp cpVar) {
        O = (U + 15) % 128;
        cpVar.G();
        int i2 = U + 119;
        O = i2 % 128;
        if (i2 % 2 != 0) {
            int i3 = 40 / 0;
        }
    }

    public static /* synthetic */ void a$154051a7(cp cpVar, Object obj, int i2) throws Throwable {
        U = (O + 115) % 128;
        cpVar.b$27a58182(obj, i2);
        int i3 = O + 33;
        U = i3 % 128;
        if (i3 % 2 == 0) {
            throw null;
        }
    }

    private void a$27a58182(Object obj, int i2) {
        synchronized (this.v) {
            if (this.y != a.ID_SCAN) {
                return;
            }
            int i3 = this.w + 1;
            this.w = i3;
            if (i3 < 4) {
                return;
            }
            cv.k(obj, i2, false);
            this.k = (co) cv.b(pk.d(), pk.d(), pk.d(), pk.d(), -1764800824, new Object[0], 1764800824);
            this.p = cv.y();
            J();
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void aa() {
        O = (U + 15) % 128;
        S();
        O = (U + 63) % 128;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void ab() {
        O = (U + 103) % 128;
        X();
        int i2 = U + 43;
        O = i2 % 128;
        if (i2 % 2 != 0) {
            throw null;
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void ac() {
        int iD = bb.d();
        int iD2 = bb.d();
        int iD3 = bb.d();
        b(3807833, iD, bb.d(), iD2, -3807831, iD3, new Object[]{this});
    }

    private static void ad(byte b2, int i2, short s, Object[] objArr) {
        byte[] bArr = $$a;
        int i3 = (b2 * 2) + 4;
        int i4 = i2 * 3;
        int i5 = s + 97;
        byte[] bArr2 = new byte[1 - i4];
        int i6 = 0 - i4;
        int i7 = -1;
        if (bArr == null) {
            i3++;
            i5 = i3 + (-i5);
        }
        while (true) {
            int i8 = i5;
            int i9 = i3;
            i7++;
            bArr2[i7] = (byte) i8;
            if (i7 == i6) {
                objArr[0] = new String(bArr2, 0);
                return;
            } else {
                i3 = i9 + 1;
                i5 = i8 + (-bArr[i9]);
            }
        }
    }

    private static void ae(String str, int i2, Object[] objArr) throws Throwable {
        char[] charArray;
        int i3 = 2;
        if (str != null) {
            int i4 = $10 + 125;
            $11 = i4 % 128;
            if (i4 % 2 == 0) {
                str.toCharArray();
                throw null;
            }
            charArray = str.toCharArray();
        } else {
            charArray = str;
        }
        char[] cArr = charArray;
        hq hqVar = new hq();
        char[] cArr2 = new char[cArr.length];
        int i5 = 0;
        hqVar.d = 0;
        char[] cArr3 = new char[2];
        while (true) {
            int i6 = hqVar.d;
            if (i6 >= cArr.length) {
                break;
            }
            cArr3[i5] = cArr[i6];
            char c2 = 1;
            cArr3[1] = cArr[i6 + 1];
            int i7 = 58224;
            int i8 = i5;
            while (i8 < 16) {
                char c3 = cArr3[c2];
                char c4 = cArr3[i5];
                char c5 = c2;
                int i9 = (c4 + i7) ^ ((c4 << 4) + ((char) (((long) Q) ^ (-5528393735828501205L))));
                int i10 = c4 >>> 5;
                int i11 = i3;
                try {
                    Object[] objArr2 = new Object[4];
                    objArr2[3] = Integer.valueOf(S);
                    objArr2[i11] = Integer.valueOf(i10);
                    objArr2[c5] = Integer.valueOf(i9);
                    objArr2[i5] = Integer.valueOf(c3);
                    Object objD = an.d(681770103);
                    Class cls = Integer.TYPE;
                    if (objD == null) {
                        objD = an.d((Process.myPid() >> 22) + 357, (char) TextUtils.getTrimmedLength(""), 24 - TextUtils.getOffsetAfter("", i5), 1589849900, false, "s", new Class[]{cls, cls, cls, cls});
                    }
                    char cCharValue = ((Character) ((Method) objD).invoke(null, objArr2)).charValue();
                    cArr3[c5] = cCharValue;
                    char c6 = cArr3[i5];
                    int i12 = i5;
                    char[] cArr4 = cArr3;
                    int i13 = (cCharValue + i7) ^ ((cCharValue << 4) + ((char) (((long) P) ^ (-5528393735828501205L))));
                    int i14 = cCharValue >>> 5;
                    Object[] objArr3 = new Object[4];
                    objArr3[3] = Integer.valueOf(R);
                    objArr3[i11] = Integer.valueOf(i14);
                    objArr3[c5] = Integer.valueOf(i13);
                    objArr3[i12] = Integer.valueOf(c6);
                    Object objD2 = an.d(681770103);
                    if (objD2 == null) {
                        objD2 = an.d(357 - (ViewConfiguration.getMinimumFlingVelocity() >> 16), (char) (ViewConfiguration.getFadingEdgeLength() >> 16), (SystemClock.uptimeMillis() > 0L ? 1 : (SystemClock.uptimeMillis() == 0L ? 0 : -1)) + 23, 1589849900, false, "s", new Class[]{cls, cls, cls, cls});
                    }
                    cArr4[i12] = ((Character) ((Method) objD2).invoke(null, objArr3)).charValue();
                    i7 -= 40503;
                    i8++;
                    c2 = c5;
                    i3 = i11;
                    i5 = i12;
                    cArr3 = cArr4;
                } catch (Throwable th) {
                    Throwable cause = th.getCause();
                    if (cause == null) {
                        throw th;
                    }
                    throw cause;
                }
            }
            int i15 = i3;
            int i16 = i5;
            char[] cArr5 = cArr3;
            char c7 = c2;
            int i17 = hqVar.d;
            cArr2[i17] = cArr5[i16];
            cArr2[i17 + 1] = cArr5[c7];
            Object[] objArr4 = new Object[i15];
            objArr4[c7] = hqVar;
            objArr4[i16] = hqVar;
            Object objD3 = an.d(227457195);
            if (objD3 == null) {
                byte b2 = (byte) i16;
                objD3 = an.d(1827 - TextUtils.indexOf("", "", i16, i16), (char) (ExpandableListView.getPackedPositionForGroup(i16) > 0L ? 1 : (ExpandableListView.getPackedPositionForGroup(i16) == 0L ? 0 : -1)), (ViewConfiguration.getScrollBarFadeDuration() >> 16) + 24, 2079288304, false, $$e(b2, (byte) (b2 | PassportService.SFI_DG13), b2), new Class[]{Object.class, Object.class});
            }
            ((Method) objD3).invoke(null, objArr4);
            cArr3 = cArr5;
            i3 = 2;
            i5 = 0;
        }
        String str2 = new String(cArr2, 0, i2);
        int i18 = $11 + 91;
        $10 = i18 % 128;
        if (i18 % 2 != 0) {
            throw null;
        }
        objArr[0] = str2;
    }

    /* JADX WARN: Removed duplicated region for block: B:10:0x0020  */
    /* JADX WARN: Removed duplicated region for block: B:8:0x0018  */
    /* JADX WARN: Unsupported multi-entry loop pattern (BACK_EDGE: B:10:0x0020 -> B:11:0x0022). Please report as a decompilation issue!!! */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    private static void af(byte r6, int r7, byte r8, java.lang.Object[] r9) {
        /*
            int r7 = r7 + 4
            int r6 = 38 - r6
            byte[] r0 = com.facetec.sdk.cp.T
            int r8 = r8 + 97
            byte[] r1 = new byte[r6]
            r2 = 0
            if (r0 != 0) goto L10
            r3 = r6
            r4 = r2
            goto L22
        L10:
            r3 = r2
        L11:
            int r4 = r3 + 1
            byte r5 = (byte) r8
            r1[r3] = r5
            if (r4 != r6) goto L20
            java.lang.String r6 = new java.lang.String
            r6.<init>(r1, r2)
            r9[r2] = r6
            return
        L20:
            r3 = r0[r7]
        L22:
            int r7 = r7 + 1
            int r8 = r8 + r3
            r3 = r4
            goto L11
        */
        throw new UnsupportedOperationException("Method not decompiled: com.facetec.sdk.cp.af(byte, int, byte, java.lang.Object[]):void");
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void ag() {
        U = (O + 103) % 128;
        V();
        O = (U + 5) % 128;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void ah() {
        U = (O + 95) % 128;
        T();
        U = (O + 87) % 128;
    }

    /* JADX WARN: Removed duplicated region for block: B:32:0x0127  */
    /* JADX WARN: Removed duplicated region for block: B:33:0x0128  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    private static void ai(java.lang.String r20, int r21, java.lang.Object[] r22) throws java.lang.Throwable {
        /*
            Method dump skipped, instruction units count: 305
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: com.facetec.sdk.cp.ai(java.lang.String, int, java.lang.Object[]):void");
    }

    /* JADX WARN: Code restructure failed: missing block: B:27:0x00fb, code lost:
    
        r4[r7] = (char) r5[r7];
     */
    /* JADX WARN: Code restructure failed: missing block: B:28:0x0101, code lost:
    
        r0 = new java.lang.Object[]{r3, r3};
        r1 = com.facetec.sdk.an.d(-187946472);
     */
    /* JADX WARN: Code restructure failed: missing block: B:29:0x010b, code lost:
    
        if (r1 != null) goto L31;
     */
    /* JADX WARN: Code restructure failed: missing block: B:30:0x010d, code lost:
    
        r1 = (byte) 0;
        r3 = r1;
        r1 = com.facetec.sdk.an.d(1732 - android.graphics.Color.red(0), (char) (3010 - android.text.TextUtils.lastIndexOf("", '0', 0, 0)), android.text.TextUtils.lastIndexOf("", '0', 0, 0) + 25, -2102527677, false, $$e(r1, r3, r3), new java.lang.Class[]{java.lang.Object.class, java.lang.Object.class});
     */
    /* JADX WARN: Code restructure failed: missing block: B:31:0x0136, code lost:
    
        ((java.lang.reflect.Method) r1).invoke(null, r0);
     */
    /* JADX WARN: Code restructure failed: missing block: B:32:0x013b, code lost:
    
        throw null;
     */
    /* JADX WARN: Removed duplicated region for block: B:42:0x0183  */
    /* JADX WARN: Removed duplicated region for block: B:43:0x0184  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    private static void aj(java.lang.String r21, int r22, java.lang.Object[] r23) throws java.lang.Throwable {
        /*
            Method dump skipped, instruction units count: 398
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: com.facetec.sdk.cp.aj(java.lang.String, int, java.lang.Object[]):void");
    }

    private static void ak(int i2, String str, byte b2, Object[] objArr) throws Throwable {
        char[] charArray;
        int i3;
        char c2;
        char c3;
        char c4;
        char c5;
        char c6;
        int i4;
        int i5 = $11;
        int i6 = i5 + 43;
        $10 = i6 % 128;
        char c7 = 2;
        if (i6 % 2 != 0) {
            throw null;
        }
        if (str != null) {
            int i7 = i5 + EnumC41897g.SDK_ASSET_ILLUSTRATION_CALENDAR_VALUE;
            $10 = i7 % 128;
            if (i7 % 2 != 0) {
                str.toCharArray();
                throw null;
            }
            charArray = str.toCharArray();
        } else {
            charArray = str;
        }
        char[] cArr = charArray;
        ho hoVar = new ho();
        char[] cArr2 = E;
        Class cls = Integer.TYPE;
        int i8 = -1584280535;
        if (cArr2 != null) {
            int length = cArr2.length;
            char[] cArr3 = new char[length];
            int i9 = 0;
            while (i9 < length) {
                try {
                    Object[] objArr2 = {Integer.valueOf(cArr2[i9])};
                    Object objD = an.d(i8);
                    if (objD == null) {
                        c6 = c7;
                        byte b3 = (byte) 0;
                        i4 = i8;
                        objD = an.d(2158 - (ViewConfiguration.getScrollBarFadeDuration() >> 16), (char) (ViewConfiguration.getScrollBarFadeDuration() >> 16), TextUtils.indexOf("", "", 0, 0) + 23, -672129166, false, $$e(b3, (byte) (b3 | 17), b3), new Class[]{cls});
                    } else {
                        c6 = c7;
                        i4 = i8;
                    }
                    cArr3[i9] = ((Character) ((Method) objD).invoke(null, objArr2)).charValue();
                    i9++;
                    i8 = i4;
                    c7 = c6;
                } catch (Throwable th) {
                    Throwable cause = th.getCause();
                    if (cause == null) {
                        throw th;
                    }
                    throw cause;
                }
            }
            cArr2 = cArr3;
        }
        char c8 = c7;
        int i10 = i8;
        Object[] objArr3 = {Integer.valueOf(F)};
        Object objD2 = an.d(i10);
        if (objD2 == null) {
            byte b4 = (byte) 0;
            objD2 = an.d(2158 - Drawable.resolveOpacity(0, 0), (char) (Process.myPid() >> 22), Color.green(0) + 23, -672129166, false, $$e(b4, (byte) (b4 | 17), b4), new Class[]{cls});
        }
        char cCharValue = ((Character) ((Method) objD2).invoke(null, objArr3)).charValue();
        char[] cArr4 = new char[i2];
        if (i2 % 2 != 0) {
            int i11 = ($10 + 95) % 128;
            $11 = i11;
            i3 = i2 - 1;
            cArr4[i3] = (char) (cArr[i3] - b2);
            $10 = (i11 + 73) % 128;
        } else {
            i3 = i2;
        }
        char c9 = 1;
        if (i3 > 1) {
            hoVar.b = 0;
            while (true) {
                int i12 = hoVar.b;
                if (i12 >= i3) {
                    break;
                }
                char c10 = cArr[i12];
                hoVar.d = c10;
                char c11 = cArr[i12 + 1];
                hoVar.e = c11;
                if (c10 == c11) {
                    cArr4[i12] = (char) (c10 - b2);
                    cArr4[i12 + 1] = (char) (c11 - b2);
                    c2 = c9;
                } else {
                    Object[] objArr4 = new Object[13];
                    objArr4[12] = hoVar;
                    objArr4[11] = Integer.valueOf(cCharValue);
                    objArr4[10] = hoVar;
                    objArr4[9] = hoVar;
                    objArr4[8] = Integer.valueOf(cCharValue);
                    objArr4[7] = hoVar;
                    objArr4[6] = hoVar;
                    objArr4[5] = Integer.valueOf(cCharValue);
                    objArr4[4] = hoVar;
                    objArr4[3] = hoVar;
                    objArr4[c8] = Integer.valueOf(cCharValue);
                    objArr4[c9] = hoVar;
                    objArr4[0] = hoVar;
                    Object objD3 = an.d(945118461);
                    if (objD3 == null) {
                        c2 = c9;
                        int iCombineMeasuredStates = View.combineMeasuredStates(0, 0) + 2356;
                        c3 = '\n';
                        char absoluteGravity = (char) Gravity.getAbsoluteGravity(0, 0);
                        int offsetAfter = 23 - TextUtils.getOffsetAfter("", 0);
                        c4 = '\t';
                        byte b5 = (byte) 0;
                        c5 = 7;
                        String str$$e = $$e(b5, (byte) (b5 | PassportService.SFI_DG15), b5);
                        Class cls2 = Integer.TYPE;
                        objD3 = an.d(iCombineMeasuredStates, absoluteGravity, offsetAfter, 1312067494, false, str$$e, new Class[]{Object.class, Object.class, cls2, Object.class, Object.class, cls2, Object.class, Object.class, cls2, Object.class, Object.class, cls2, Object.class});
                    } else {
                        c2 = c9;
                        c3 = '\n';
                        c4 = '\t';
                        c5 = 7;
                    }
                    int iIntValue = ((Integer) ((Method) objD3).invoke(null, objArr4)).intValue();
                    int i13 = hoVar.f95903g;
                    if (iIntValue == i13) {
                        Object[] objArr5 = new Object[11];
                        objArr5[c3] = hoVar;
                        objArr5[c4] = Integer.valueOf(cCharValue);
                        objArr5[8] = hoVar;
                        objArr5[c5] = Integer.valueOf(cCharValue);
                        objArr5[6] = Integer.valueOf(cCharValue);
                        objArr5[5] = hoVar;
                        objArr5[4] = hoVar;
                        objArr5[3] = Integer.valueOf(cCharValue);
                        objArr5[c8] = Integer.valueOf(cCharValue);
                        objArr5[c2] = hoVar;
                        objArr5[0] = hoVar;
                        Object objD4 = an.d(-1909092408);
                        if (objD4 == null) {
                            int iMyPid = (Process.myPid() >> 22) + 24;
                            byte b6 = (byte) 0;
                            String str$$e2 = $$e(b6, (byte) (b6 | 14), b6);
                            Class cls3 = Integer.TYPE;
                            objD4 = an.d(((byte) KeyEvent.getModifierMetaStateMask()) + 878, (char) ((SystemClock.elapsedRealtimeNanos() > 0L ? 1 : (SystemClock.elapsedRealtimeNanos() == 0L ? 0 : -1)) - 1), iMyPid, -128689005, false, str$$e2, new Class[]{Object.class, Object.class, cls3, cls3, Object.class, Object.class, cls3, cls3, Object.class, cls3, Object.class});
                        }
                        int iIntValue2 = ((Integer) ((Method) objD4).invoke(null, objArr5)).intValue();
                        int i14 = (hoVar.a * cCharValue) + hoVar.f95903g;
                        int i15 = hoVar.b;
                        cArr4[i15] = cArr2[iIntValue2];
                        cArr4[i15 + 1] = cArr2[i14];
                    } else {
                        int i16 = hoVar.c;
                        int i17 = hoVar.a;
                        if (i16 == i17) {
                            int i18 = ((hoVar.j + cCharValue) - 1) % cCharValue;
                            hoVar.j = i18;
                            int i19 = ((i13 + cCharValue) - 1) % cCharValue;
                            hoVar.f95903g = i19;
                            int i20 = (i17 * cCharValue) + i19;
                            int i21 = hoVar.b;
                            cArr4[i21] = cArr2[(i16 * cCharValue) + i18];
                            cArr4[i21 + 1] = cArr2[i20];
                        } else {
                            int i22 = (i16 * cCharValue) + i13;
                            int i23 = (i17 * cCharValue) + hoVar.j;
                            int i24 = hoVar.b;
                            cArr4[i24] = cArr2[i22];
                            cArr4[i24 + 1] = cArr2[i23];
                        }
                    }
                }
                hoVar.b += 2;
                c9 = c2;
            }
        }
        for (int i25 = 0; i25 < i2; i25++) {
            cArr4[i25] = (char) (cArr4[i25] ^ 13722);
        }
        objArr[0] = new String(cArr4);
    }

    private static void al(int[] iArr, int i2, String str, String str2, Object[] objArr) throws Throwable {
        char[] charArray;
        int length;
        char[] cArr;
        int i3;
        int i4;
        String str3 = str2;
        Object bytes = str3;
        if (str3 != null) {
            bytes = str3.getBytes(LocalizedMessage.DEFAULT_ENCODING);
        }
        byte[] bArr = (byte[]) bytes;
        if (str != null) {
            int i5 = $10 + 109;
            $11 = i5 % 128;
            if (i5 % 2 == 0) {
                str.toCharArray();
                throw null;
            }
            charArray = str.toCharArray();
        } else {
            charArray = str;
        }
        char[] cArr2 = charArray;
        hn hnVar = new hn();
        char[] cArr3 = L;
        Class cls = Integer.TYPE;
        int i6 = 0;
        if (cArr3 != null) {
            int i7 = $11 + 119;
            $10 = i7 % 128;
            if (i7 % 2 != 0) {
                length = cArr3.length;
                cArr = new char[length];
                i3 = 1;
            } else {
                length = cArr3.length;
                cArr = new char[length];
                i3 = 0;
            }
            while (i3 < length) {
                try {
                    Object[] objArr2 = {Integer.valueOf(cArr3[i3])};
                    Object objD = an.d(-814569747);
                    if (objD == null) {
                        byte b2 = (byte) i6;
                        i4 = i6;
                        objD = an.d(ExpandableListView.getPackedPositionGroup(0L) + 1803, (char) ((SystemClock.elapsedRealtime() > 0L ? 1 : (SystemClock.elapsedRealtime() == 0L ? 0 : -1)) + 9691), 24 - TextUtils.getTrimmedLength(""), -1189907018, false, $$e(b2, (byte) (b2 | 19), b2), new Class[]{cls});
                    } else {
                        i4 = i6;
                    }
                    cArr[i3] = ((Character) ((Method) objD).invoke(null, objArr2)).charValue();
                    i3++;
                    i6 = i4;
                } catch (Throwable th) {
                    Throwable cause = th.getCause();
                    if (cause == null) {
                        throw th;
                    }
                    throw cause;
                }
            }
            cArr3 = cArr;
        }
        int i8 = i6;
        Object[] objArr3 = {Integer.valueOf(J)};
        Object objD2 = an.d(-1578986303);
        if (objD2 == null) {
            byte b3 = (byte) i8;
            objD2 = an.d(2566 - (CdmaCellLocation.convertQuartSecToDecDegrees(i8) > 0.0d ? 1 : (CdmaCellLocation.convertQuartSecToDecDegrees(i8) == 0.0d ? 0 : -1)), (char) (ViewConfiguration.getPressedStateDuration() >> 16), TextUtils.indexOf("", "") + 23, -679262310, false, $$e(b3, (byte) (b3 | 18), b3), new Class[]{cls});
        }
        int iIntValue = ((Integer) ((Method) objD2).invoke(null, objArr3)).intValue();
        if (K) {
            $11 = ($10 + 61) % 128;
            int length2 = bArr.length;
            hnVar.b = length2;
            char[] cArr4 = new char[length2];
            hnVar.c = 0;
            while (true) {
                int i9 = hnVar.c;
                int i10 = hnVar.b;
                if (i9 >= i10) {
                    objArr[0] = new String(cArr4);
                    return;
                }
                cArr4[i9] = (char) (cArr3[bArr[(i10 - 1) - i9] + i2] - iIntValue);
                Object[] objArr4 = {hnVar, hnVar};
                Object objD3 = an.d(717234065);
                if (objD3 == null) {
                    objD3 = an.d(1970 - (ViewConfiguration.getWindowTouchSlop() >> 8), (char) (ViewConfiguration.getEdgeSlop() >> 16), 25 - (ViewConfiguration.getGlobalActionKeyTimeout() > 0L ? 1 : (ViewConfiguration.getGlobalActionKeyTimeout() == 0L ? 0 : -1)), 1554107594, false, "x", new Class[]{Object.class, Object.class});
                }
                ((Method) objD3).invoke(null, objArr4);
            }
        } else if (!M) {
            int length3 = iArr.length;
            hnVar.b = length3;
            char[] cArr5 = new char[length3];
            hnVar.c = 0;
            while (true) {
                int i11 = hnVar.c;
                int i12 = hnVar.b;
                if (i11 >= i12) {
                    objArr[0] = new String(cArr5);
                    return;
                }
                int i13 = $11 + 9;
                $10 = i13 % 128;
                if (i13 % 2 != 0) {
                    cArr5[i11] = (char) (cArr3[iArr[i12 + i11] - i2] >>> iIntValue);
                } else {
                    cArr5[i11] = (char) (cArr3[iArr[(i12 - 1) - i11] - i2] - iIntValue);
                    i11++;
                }
                hnVar.c = i11;
            }
        } else {
            int length4 = cArr2.length;
            hnVar.b = length4;
            char[] cArr6 = new char[length4];
            hnVar.c = 0;
            while (true) {
                int i14 = hnVar.c;
                int i15 = hnVar.b;
                if (i14 >= i15) {
                    objArr[0] = new String(cArr6);
                    return;
                }
                $10 = ($11 + 99) % 128;
                cArr6[i14] = (char) (cArr3[cArr2[(i15 - 1) - i14] - i2] - iIntValue);
                Object[] objArr5 = {hnVar, hnVar};
                Object objD4 = an.d(717234065);
                if (objD4 == null) {
                    objD4 = an.d(1969 - ExpandableListView.getPackedPositionChild(0L), (char) (TextUtils.indexOf((CharSequence) "", '0') + 1), View.MeasureSpec.makeMeasureSpec(0, 0) + 24, 1554107594, false, "x", new Class[]{Object.class, Object.class});
                }
                ((Method) objD4).invoke(null, objArr5);
            }
        }
    }

    /* JADX WARN: Removed duplicated region for block: B:142:0x03bc A[ADDED_TO_REGION, REMOVE, SYNTHETIC] */
    /* JADX WARN: Removed duplicated region for block: B:93:0x03ad A[ADDED_TO_REGION] */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    private static /* synthetic */ java.lang.Object b(java.lang.Object[] r25) throws java.lang.Throwable {
        /*
            Method dump skipped, instruction units count: 1012
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: com.facetec.sdk.cp.b(java.lang.Object[]):java.lang.Object");
    }

    public static /* synthetic */ void b$154051a7(cp cpVar, Object obj, int i2) {
        O = (U + 37) % 128;
        Object[] objArr = {cpVar, obj, Integer.valueOf(i2)};
        b(-510309129, bb.d(), bb.d(), bb.d(), 510309137, bb.d(), objArr);
        U = (O + 21) % 128;
    }

    private void b$27a58182(Object obj, int i2) throws Throwable {
        synchronized (this.v) {
            if (this.y != a.PRE_SESSION) {
                return;
            }
            int i3 = this.w + 1;
            this.w = i3;
            if (i3 < 4) {
                return;
            }
            int iD = bb.d();
            int iD2 = bb.d();
            int iD3 = bb.d();
            b(-1216704366, iD, bb.d(), iD2, 1216704372, iD3, new Object[]{this});
            try {
                Object[] objArr = new Object[1];
                aj("䞼ᮘ\ufffe区㝄譑溭싱ꛉ穟\ude53놪ᖑ\ue9c1䴡ⅺ", (SystemClock.uptimeMillis() > 0L ? 1 : (SystemClock.uptimeMillis() == 0L ? 0 : -1)) + 23598, objArr);
                Class<?> cls = Class.forName((String) objArr[0]);
                Object[] objArr2 = new Object[1];
                aj("䞵谺킖╯槗빅舴횭᭷濚둉\uf808첓ᅿ旤ꩈ︵", 52120 - ((byte) KeyEvent.getModifierMetaStateMask()), objArr2);
                cv.i(obj, ((Long) cls.getMethod((String) objArr2[0], null).invoke(null, null)).longValue(), i2, true);
                this.t = (da) cv.b(pk.d(), pk.d(), pk.d(), pk.d(), -1417398177, new Object[0], 1417398179);
                this.q = cv.g();
                this.r = cv.m();
                this.s = cv.o();
                K();
            } catch (Throwable th) {
                Throwable cause = th.getCause();
                if (cause == null) {
                    throw th;
                }
                throw cause;
            }
        }
    }

    public static /* synthetic */ a c(cp cpVar) {
        int i2 = (O + 63) % 128;
        U = i2;
        a aVar = cpVar.y;
        int i3 = i2 + 113;
        O = i3 % 128;
        if (i3 % 2 == 0) {
            return aVar;
        }
        throw null;
    }

    public static /* synthetic */ void d$154051a7(cp cpVar, Object obj, int i2) {
        int i3 = U + 41;
        O = i3 % 128;
        int i4 = i3 % 2;
        cpVar.a$27a58182(obj, i2);
        if (i4 != 0) {
            int i5 = 28 / 0;
        }
    }

    private void e$27a58182(Object obj, int i2) {
        Object[] objArr = {this, obj, Integer.valueOf(i2)};
        b(-510309129, bb.d(), bb.d(), bb.d(), 510309137, bb.d(), objArr);
    }

    public static void g() {
        int i2 = U + 97;
        O = i2 % 128;
        if (i2 % 2 != 0) {
            a = UUID.randomUUID().toString();
            throw null;
        }
        a = UUID.randomUUID().toString();
        int i3 = O + 53;
        U = i3 % 128;
        if (i3 % 2 == 0) {
            throw null;
        }
    }

    public static void init$0() {
        $$a = new byte[]{ISO7816.INS_UNBLOCK_CHV, 39, 61, 29};
        $$b = EnumC41897g.SDK_ASSET_ILLUSTRATION_INSTITUTION_CIRCLE_VALUE;
    }

    public static void init$1() {
        $$c = new byte[]{5, 64, 127, 81};
        $$d = 73;
    }

    public static boolean l() {
        O = (U + 35) % 128;
        boolean zV = cv.V();
        O = (U + 7) % 128;
        return zV;
    }

    public static void p() {
        int i2 = O + 49;
        U = i2 % 128;
        if (i2 % 2 == 0) {
            E = new char[]{3871, 3864, 3865, 15026, 15081, 15091, 15072, 15024, 3866, 15080, 15095, 15077, 15090, 15027, 15085, 15079};
            F = (char) 3871;
            L = new char[]{8251, 8228, 8230, 8225, 8249, 8236, 8214, 8297, 8298, 8299, 8212};
            J = 1071522200;
            M = false;
        } else {
            E = new char[]{3871, 3864, 3865, 15026, 15081, 15091, 15072, 15024, 3866, 15080, 15095, 15077, 15090, 15027, 15085, 15079};
            F = (char) 3871;
            L = new char[]{8251, 8228, 8230, 8225, 8249, 8236, 8214, 8297, 8298, 8299, 8212};
            J = 1071522200;
            M = true;
        }
        K = true;
    }

    public static void q() {
        V = -3296913338528155888L;
    }

    public static void r() {
        int iD = bb.d();
        int iD2 = bb.d();
        int iD3 = bb.d();
        b(1462010534, iD, bb.d(), iD2, -1462010525, iD3, new Object[0]);
    }

    public static void s() {
        P = (char) 21639;
        R = (char) 33203;
        Q = (char) 7558;
        S = (char) 22733;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void u() throws Throwable {
        int i2;
        int i3;
        long j;
        char c2;
        char c3;
        Object[] objArr;
        U = (O + 11) % 128;
        Object objD = an.d(-1397726040);
        if (objD == null) {
            int iArgb = 711 - Color.argb(0, 0, 0, 0);
            char cIndexOf = (char) (49307 - TextUtils.indexOf((CharSequence) "", '0', 0, 0));
            int scrollBarSize = (ViewConfiguration.getScrollBarSize() >> 8) + 24;
            byte b2 = (byte) 0;
            byte b3 = b2;
            Object[] objArr2 = new Object[1];
            ad(b2, b3, (byte) (b3 + 2), objArr2);
            objD = an.d(iArgb, cIndexOf, scrollBarSize, -623790093, false, (String) objArr2[0], null);
        }
        long j2 = ((Field) objD).getLong(null);
        Object[] objArr3 = new Object[1];
        ae("흗듩綁䉁斣氌鯸Ꮾ䶜༜\udeab㋘㽼ꥌ⃢\ueacb杻䘖셅뷂ਿ衛", 22 - KeyEvent.normalizeMetaState(0), objArr3);
        Class<?> cls = Class.forName((String) objArr3[0]);
        Object[] objArr4 = new Object[1];
        ae("\ud9ee舓䷏㳳\uea89컢酭䓁ﲝ杴辨쀎\uf5a7㵋ၗ\udb16", 15 - Color.alpha(0), objArr4);
        long jLongValue = ((Long) cls.getDeclaredMethod((String) objArr4[0], null).invoke(null, null)).longValue();
        Object objD2 = an.d(-1398649561);
        if (objD2 == null) {
            int i4 = (ExpandableListView.getPackedPositionForGroup(0) > 0L ? 1 : (ExpandableListView.getPackedPositionForGroup(0) == 0L ? 0 : -1)) + 711;
            char cKeyCodeFromString = (char) (49308 - KeyEvent.keyCodeFromString(""));
            int iResolveSize = View.resolveSize(0, 0) + 24;
            i2 = -1397726040;
            byte b4 = (byte) 0;
            i3 = 49308;
            byte b5 = b4;
            j = 0;
            Object[] objArr5 = new Object[1];
            ad(b4, b5, (byte) (b5 + 1), objArr5);
            objD2 = an.d(i4, cKeyCodeFromString, iResolveSize, -624714116, false, (String) objArr5[0], null);
        } else {
            i2 = -1397726040;
            i3 = 49308;
            j = 0;
        }
        if (j2 == ((jLongValue - ((((Field) objD2).getLong(null) << 52) >>> 52)) >> 12)) {
            Object objD3 = an.d(-1399573082);
            if (objD3 == null) {
                int iRed = 711 - Color.red(0);
                char mode = (char) (View.MeasureSpec.getMode(0) + i3);
                int keyRepeatTimeout = (ViewConfiguration.getKeyRepeatTimeout() >> 16) + 24;
                byte b6 = (byte) 0;
                byte b7 = b6;
                Object[] objArr6 = new Object[1];
                ad(b6, b7, b7, objArr6);
                objD3 = an.d(iRed, mode, keyRepeatTimeout, -621418755, false, (String) objArr6[0], null);
            }
            Object[] objArr7 = (Object[]) ((Field) objD3).get(null);
            objArr = new Object[]{strArr, new int[]{i}, new int[]{i}, new int[1]};
            int i5 = ((int[]) objArr7[1])[0];
            int i6 = ((int[]) objArr7[2])[0];
            String[] strArr = (String[]) objArr7[0];
            int iElapsedRealtime = (int) SystemClock.elapsedRealtime();
            int i7 = (((((~((-176992302) | r8)) | (~((-869795058) | iElapsedRealtime))) | (~(r8 | 869795057))) * 959) - 1024705218) + (((~(iElapsedRealtime | 869795057)) | (~((~iElapsedRealtime) | (-869795058))) | (~((-176992302) | iElapsedRealtime))) * 959) + 751976526;
            int i8 = (i7 << 13) ^ i7;
            int i9 = i8 ^ (i8 >>> 17);
            ((int[]) objArr[3])[0] = i9 ^ (i9 << 5);
            c2 = 3;
            c3 = 2;
        } else {
            Object[] objArr8 = new Object[1];
            ae("\uf16d\ue0e7糉羃㴽ꄩ흗듩㐫◙缭\uf637育诹로돏", TextUtils.indexOf("", "", 0) + 16, objArr8);
            Class<?> cls2 = Class.forName((String) objArr8[0]);
            Object[] objArr9 = new Object[1];
            ae("ꑐ݂緞漙糄\uf38e嗴\udc2bꑇ舧쳻⤟쁯ꚿ㊗ై", 17 - (ViewConfiguration.getGlobalActionKeyTimeout() > j ? 1 : (ViewConfiguration.getGlobalActionKeyTimeout() == j ? 0 : -1)), objArr9);
            int iIntValue = ((Integer) cls2.getMethod((String) objArr9[0], Object.class).invoke(null, this)).intValue();
            try {
                Object[] objArr10 = {-1328796659};
                Object objD4 = an.d(1683332522);
                if (objD4 == null) {
                    objD4 = an.d(TextUtils.getOffsetAfter("", 0) + 830, (char) ((-1) - (ExpandableListView.getPackedPositionForChild(0, 0) > j ? 1 : (ExpandableListView.getPackedPositionForChild(0, 0) == j ? 0 : -1))), 24 - Color.red(0), 305417969, false, null, new Class[]{Integer.TYPE});
                }
                Object[] objArr11 = {Integer.valueOf(iIntValue), 0, 751976526, ((Constructor) objD4).newInstance(objArr10), Boolean.FALSE};
                Object objD5 = an.d(1794077343);
                if (objD5 == null) {
                    int iIndexOf = TextUtils.indexOf("", "") + 711;
                    char cArgb = (char) (Color.argb(0, 0, 0, 0) + i3);
                    int iResolveSize2 = 24 - View.resolveSize(0, 0);
                    byte b8 = (byte) 0;
                    byte b9 = b8;
                    c2 = 3;
                    Object[] objArr12 = new Object[1];
                    ad(b8, b9, (byte) (b9 + 1), objArr12);
                    String str = (String) objArr12[0];
                    Class cls3 = Integer.TYPE;
                    objD5 = an.d(iIndexOf, cArgb, iResolveSize2, 479109572, false, str, new Class[]{cls3, cls3, cls3, (Class) an.b(799 - (ViewConfiguration.getKeyRepeatDelay() >> 16), (char) TextUtils.indexOf("", "", 0, 0), (CdmaCellLocation.convertQuartSecToDecDegrees(0) > 0.0d ? 1 : (CdmaCellLocation.convertQuartSecToDecDegrees(0) == 0.0d ? 0 : -1)) + 31), Boolean.TYPE});
                } else {
                    c2 = 3;
                }
                Object[] objArr13 = (Object[]) ((Method) objD5).invoke(null, objArr11);
                Object objD6 = an.d(-1399573082);
                if (objD6 == null) {
                    int i10 = (TypedValue.complexToFraction(0, SelfieScan.RECOGNITION_FAIL_RESULT, SelfieScan.RECOGNITION_FAIL_RESULT) > SelfieScan.RECOGNITION_FAIL_RESULT ? 1 : (TypedValue.complexToFraction(0, SelfieScan.RECOGNITION_FAIL_RESULT, SelfieScan.RECOGNITION_FAIL_RESULT) == SelfieScan.RECOGNITION_FAIL_RESULT ? 0 : -1)) + 711;
                    char c4 = (char) (49309 - (SystemClock.elapsedRealtimeNanos() > j ? 1 : (SystemClock.elapsedRealtimeNanos() == j ? 0 : -1)));
                    int iAxisFromString = 23 - MotionEvent.axisFromString("");
                    byte b10 = (byte) 0;
                    byte b11 = b10;
                    Object[] objArr14 = new Object[1];
                    ad(b10, b11, b11, objArr14);
                    objD6 = an.d(i10, c4, iAxisFromString, -621418755, false, (String) objArr14[0], null);
                }
                ((Field) objD6).set(null, objArr13);
                try {
                    Object[] objArr15 = new Object[1];
                    ae("흗듩綁䉁斣氌鯸Ꮾ䶜༜\udeab㋘㽼ꥌ⃢\ueacb杻䘖셅뷂ਿ衛", 22 - (ViewConfiguration.getKeyRepeatTimeout() >> 16), objArr15);
                    Class<?> cls4 = Class.forName((String) objArr15[0]);
                    Object[] objArr16 = new Object[1];
                    ae("\ud9ee舓䷏㳳\uea89컢酭䓁ﲝ杴辨쀎\uf5a7㵋ၗ\udb16", 15 - TextUtils.getCapsMode("", 0, 0), objArr16);
                    long jLongValue2 = ((Long) cls4.getDeclaredMethod((String) objArr16[0], null).invoke(null, null)).longValue();
                    Long lValueOf = Long.valueOf(jLongValue2);
                    Object objD7 = an.d(-1398649561);
                    if (objD7 == null) {
                        int packedPositionGroup = ExpandableListView.getPackedPositionGroup(j) + 711;
                        char windowTouchSlop = (char) ((ViewConfiguration.getWindowTouchSlop() >> 8) + i3);
                        int keyRepeatDelay = 24 - (ViewConfiguration.getKeyRepeatDelay() >> 16);
                        byte b12 = (byte) 0;
                        byte b13 = b12;
                        c3 = 2;
                        Object[] objArr17 = new Object[1];
                        ad(b12, b13, (byte) (b13 + 1), objArr17);
                        objD7 = an.d(packedPositionGroup, windowTouchSlop, keyRepeatDelay, -624714116, false, (String) objArr17[0], null);
                    } else {
                        c3 = 2;
                    }
                    ((Field) objD7).set(null, lValueOf);
                    Long lValueOf2 = Long.valueOf(jLongValue2 >> 12);
                    Object objD8 = an.d(i2);
                    if (objD8 == null) {
                        int iCombineMeasuredStates = View.combineMeasuredStates(0, 0) + 711;
                        char cIndexOf2 = (char) (TextUtils.indexOf("", "", 0) + i3);
                        int iGreen = 24 - Color.green(0);
                        byte b14 = (byte) 0;
                        byte b15 = b14;
                        Object[] objArr18 = new Object[1];
                        ad(b14, b15, (byte) (b15 + 2), objArr18);
                        objD8 = an.d(iCombineMeasuredStates, cIndexOf2, iGreen, -623790093, false, (String) objArr18[0], null);
                    }
                    ((Field) objD8).set(null, lValueOf2);
                    objArr = objArr13;
                } catch (Exception unused) {
                    throw new RuntimeException();
                }
            } catch (Throwable th) {
                Throwable cause = th.getCause();
                if (cause == null) {
                    throw th;
                }
                throw cause;
            }
        }
        int i11 = ((int[]) objArr[c3])[0];
        int i12 = ((int[]) objArr[1])[0];
        if (i12 == i11) {
            Object[] objArr19 = new Object[4];
            objArr19[1] = new int[]{i};
            objArr19[c3] = new int[]{i};
            objArr19[c2] = new int[1];
            int i13 = ((int[]) objArr[c2])[0];
            int i14 = ((int[]) objArr[1])[0];
            int i15 = ((int[]) objArr[c3])[0];
            objArr19[0] = (String[]) objArr[0];
            int iIdentityHashCode = System.identityHashCode(this);
            int i16 = i13 + (((~((-2232849) | iIdentityHashCode)) | 826318990) * 449) + 1039127794 + (((~((~iIdentityHashCode) | (-2232849))) | 826318990) * 449);
            int i17 = (i16 << 13) ^ i16;
            int i18 = i17 ^ (i17 >>> 17);
            ((int[]) objArr19[c2])[0] = i18 ^ (i18 << 5);
            return;
        }
        ArrayList arrayList = new ArrayList();
        String[] strArr2 = (String[]) objArr[0];
        if (strArr2 != null) {
            for (String str2 : strArr2) {
                O = (U + 41) % 128;
                arrayList.add(str2);
            }
        }
        Toast.makeText((Context) null, i12 / (((i12 - 1) * i12) % 2), 0).show();
        Object[] objArr20 = new Object[4];
        objArr20[1] = new int[]{i};
        objArr20[c3] = new int[]{i};
        objArr20[c2] = new int[1];
        int i19 = ((int[]) objArr[c2])[0];
        int i20 = ((int[]) objArr[1])[0];
        int i21 = ((int[]) objArr[c3])[0];
        objArr20[0] = (String[]) objArr[0];
        int iIdentityHashCode2 = System.identityHashCode(this);
        int i22 = ~iIdentityHashCode2;
        int i23 = i19 + (-581485786) + ((533665539 | i22) * (-757)) + ((~((-1083417) | iIdentityHashCode2)) * 1514) + (((~(iIdentityHashCode2 | 534748955)) | (~(i22 | (-513121820))) | 512038403) * 757);
        int i24 = (i23 << 13) ^ i23;
        int i25 = i24 ^ (i24 >>> 17);
        ((int[]) objArr20[c2])[0] = i25 ^ (i25 << 5);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void v() throws Throwable {
        int i2;
        long j;
        int i3;
        int i4;
        char c2;
        char c3;
        Object[] objArr;
        U = (O + 33) % 128;
        Object objD = an.d(-1397726040);
        if (objD == null) {
            int iAlpha = 711 - Color.alpha(0);
            char c4 = (char) (49309 - (Process.getElapsedCpuTime() > 0L ? 1 : (Process.getElapsedCpuTime() == 0L ? 0 : -1)));
            int maxKeyCode = 24 - (KeyEvent.getMaxKeyCode() >> 16);
            byte b2 = (byte) 0;
            byte b3 = b2;
            Object[] objArr2 = new Object[1];
            ad(b2, b3, (byte) (b3 + 2), objArr2);
            objD = an.d(iAlpha, c4, maxKeyCode, -623790093, false, (String) objArr2[0], null);
        }
        long j2 = ((Field) objD).getLong(null);
        Object[] objArr3 = new Object[1];
        ae("흗듩綁䉁斣氌鯸Ꮾ䶜༜\udeab㋘㽼ꥌ⃢\ueacb杻䘖셅뷂ਿ衛", 22 - TextUtils.getOffsetBefore("", 0), objArr3);
        Class<?> cls = Class.forName((String) objArr3[0]);
        Object[] objArr4 = new Object[1];
        ae("\ud9ee舓䷏㳳\uea89컢酭䓁ﲝ杴辨쀎\uf5a7㵋ၗ\udb16", 15 - ExpandableListView.getPackedPositionGroup(0L), objArr4);
        long jLongValue = ((Long) cls.getDeclaredMethod((String) objArr4[0], null).invoke(null, null)).longValue();
        Object objD2 = an.d(-1398649561);
        if (objD2 == null) {
            int iIndexOf = 711 - TextUtils.indexOf("", "");
            i2 = -1397726040;
            char cNormalizeMetaState = (char) (KeyEvent.normalizeMetaState(0) + 49308);
            int i5 = 23 - (ExpandableListView.getPackedPositionForChild(0, 0) > 0L ? 1 : (ExpandableListView.getPackedPositionForChild(0, 0) == 0L ? 0 : -1));
            j = 0;
            byte b4 = (byte) 0;
            byte b5 = b4;
            i3 = -1398649561;
            i4 = 49308;
            Object[] objArr5 = new Object[1];
            ad(b4, b5, (byte) (b5 + 1), objArr5);
            objD2 = an.d(iIndexOf, cNormalizeMetaState, i5, -624714116, false, (String) objArr5[0], null);
        } else {
            i2 = -1397726040;
            j = 0;
            i3 = -1398649561;
            i4 = 49308;
        }
        if (j2 == ((jLongValue - ((((Field) objD2).getLong(null) << 52) >>> 52)) >> 12)) {
            Object objD3 = an.d(-1399573082);
            if (objD3 == null) {
                int windowTouchSlop = (ViewConfiguration.getWindowTouchSlop() >> 8) + 711;
                char packedPositionType = (char) (ExpandableListView.getPackedPositionType(j) + i4);
                int iMyTid = (Process.myTid() >> 22) + 24;
                byte b6 = (byte) 0;
                byte b7 = b6;
                Object[] objArr6 = new Object[1];
                ad(b6, b7, b7, objArr6);
                objD3 = an.d(windowTouchSlop, packedPositionType, iMyTid, -621418755, false, (String) objArr6[0], null);
            }
            Object[] objArr7 = (Object[]) ((Field) objD3).get(null);
            objArr = new Object[]{strArr, new int[]{i}, new int[]{i}, new int[1]};
            int i6 = ((int[]) objArr7[1])[0];
            int i7 = ((int[]) objArr7[2])[0];
            String[] strArr = (String[]) objArr7[0];
            int iMyTid2 = Process.myTid();
            int i8 = ~iMyTid2;
            int i9 = 1036591878 + ((iMyTid2 | 42170016) * 140) + (((~(42170016 | i8)) | 962594910) * (-280)) + (((~(iMyTid2 | (-962594911))) | (~(1004617342 | i8)) | 147584) * 140) + 15108033;
            int i10 = (i9 << 13) ^ i9;
            int i11 = i10 ^ (i10 >>> 17);
            ((int[]) objArr[3])[0] = i11 ^ (i11 << 5);
            c2 = 3;
            c3 = 2;
        } else {
            Object[] objArr8 = new Object[1];
            ae("\uf16d\ue0e7糉羃㴽ꄩ흗듩㐫◙缭\uf637育诹로돏", (ViewConfiguration.getDoubleTapTimeout() >> 16) + 16, objArr8);
            Class<?> cls2 = Class.forName((String) objArr8[0]);
            Object[] objArr9 = new Object[1];
            ae("ꑐ݂緞漙糄\uf38e嗴\udc2bꑇ舧쳻⤟쁯ꚿ㊗ై", 16 - (CdmaCellLocation.convertQuartSecToDecDegrees(0) > 0.0d ? 1 : (CdmaCellLocation.convertQuartSecToDecDegrees(0) == 0.0d ? 0 : -1)), objArr9);
            int iIntValue = ((Integer) cls2.getMethod((String) objArr9[0], Object.class).invoke(null, this)).intValue();
            try {
                Object[] objArr10 = {-1240759998};
                Object objD4 = an.d(1683332522);
                if (objD4 == null) {
                    objD4 = an.d((SystemClock.elapsedRealtimeNanos() > j ? 1 : (SystemClock.elapsedRealtimeNanos() == j ? 0 : -1)) + 829, (char) TextUtils.indexOf("", "", 0, 0), AndroidCharacter.getMirror('0') - 24, 305417969, false, null, new Class[]{Integer.TYPE});
                }
                Object[] objArr11 = {Integer.valueOf(iIntValue), 0, 15108033, ((Constructor) objD4).newInstance(objArr10), Boolean.FALSE};
                Object objD5 = an.d(1794077343);
                if (objD5 == null) {
                    int i12 = 711 - (TypedValue.complexToFloat(0) > SelfieScan.RECOGNITION_FAIL_RESULT ? 1 : (TypedValue.complexToFloat(0) == SelfieScan.RECOGNITION_FAIL_RESULT ? 0 : -1));
                    char cIndexOf = (char) (i4 - TextUtils.indexOf("", ""));
                    int iResolveSize = 24 - View.resolveSize(0, 0);
                    byte b8 = (byte) 0;
                    byte b9 = b8;
                    Object[] objArr12 = new Object[1];
                    ad(b8, b9, (byte) (b9 + 1), objArr12);
                    String str = (String) objArr12[0];
                    Class cls3 = Integer.TYPE;
                    objD5 = an.d(i12, cIndexOf, iResolveSize, 479109572, false, str, new Class[]{cls3, cls3, cls3, (Class) an.b(((byte) KeyEvent.getModifierMetaStateMask()) + ISO7816.INS_VERIFY, (char) (Process.myPid() >> 22), TextUtils.getTrimmedLength("") + 31), Boolean.TYPE});
                }
                Object[] objArr13 = (Object[]) ((Method) objD5).invoke(null, objArr11);
                Object objD6 = an.d(-1399573082);
                if (objD6 == null) {
                    int scrollBarSize = 711 - (ViewConfiguration.getScrollBarSize() >> 8);
                    char cIndexOf2 = (char) (TextUtils.indexOf("", "", 0) + i4);
                    int iRed = Color.red(0) + 24;
                    byte b10 = (byte) 0;
                    byte b11 = b10;
                    Object[] objArr14 = new Object[1];
                    ad(b10, b11, b11, objArr14);
                    objD6 = an.d(scrollBarSize, cIndexOf2, iRed, -621418755, false, (String) objArr14[0], null);
                }
                ((Field) objD6).set(null, objArr13);
                try {
                    Object[] objArr15 = new Object[1];
                    ae("흗듩綁䉁斣氌鯸Ꮾ䶜༜\udeab㋘㽼ꥌ⃢\ueacb杻䘖셅뷂ਿ衛", 22 - KeyEvent.keyCodeFromString(""), objArr15);
                    Class<?> cls4 = Class.forName((String) objArr15[0]);
                    Object[] objArr16 = new Object[1];
                    ae("\ud9ee舓䷏㳳\uea89컢酭䓁ﲝ杴辨쀎\uf5a7㵋ၗ\udb16", 15 - View.combineMeasuredStates(0, 0), objArr16);
                    long jLongValue2 = ((Long) cls4.getDeclaredMethod((String) objArr16[0], null).invoke(null, null)).longValue();
                    Long lValueOf = Long.valueOf(jLongValue2);
                    Object objD7 = an.d(i3);
                    if (objD7 == null) {
                        int iResolveSizeAndState = View.resolveSizeAndState(0, 0, 0) + 711;
                        char c5 = (char) (i4 - (TypedValue.complexToFloat(0) > SelfieScan.RECOGNITION_FAIL_RESULT ? 1 : (TypedValue.complexToFloat(0) == SelfieScan.RECOGNITION_FAIL_RESULT ? 0 : -1)));
                        int iAlpha2 = Color.alpha(0) + 24;
                        byte b12 = (byte) 0;
                        byte b13 = b12;
                        c2 = 3;
                        c3 = 2;
                        Object[] objArr17 = new Object[1];
                        ad(b12, b13, (byte) (b13 + 1), objArr17);
                        objD7 = an.d(iResolveSizeAndState, c5, iAlpha2, -624714116, false, (String) objArr17[0], null);
                    } else {
                        c2 = 3;
                        c3 = 2;
                    }
                    ((Field) objD7).set(null, lValueOf);
                    Long lValueOf2 = Long.valueOf(jLongValue2 >> 12);
                    Object objD8 = an.d(i2);
                    if (objD8 == null) {
                        int size = View.MeasureSpec.getSize(0) + 711;
                        char cIndexOf3 = (char) (49307 - TextUtils.indexOf((CharSequence) "", '0'));
                        int iMakeMeasureSpec = 24 - View.MeasureSpec.makeMeasureSpec(0, 0);
                        byte b14 = (byte) 0;
                        byte b15 = b14;
                        Object[] objArr18 = new Object[1];
                        ad(b14, b15, (byte) (b15 + 2), objArr18);
                        objD8 = an.d(size, cIndexOf3, iMakeMeasureSpec, -623790093, false, (String) objArr18[0], null);
                    }
                    ((Field) objD8).set(null, lValueOf2);
                    O = (U + 63) % 128;
                    objArr = objArr13;
                } catch (Exception unused) {
                    throw new RuntimeException();
                }
            } catch (Throwable th) {
                Throwable cause = th.getCause();
                if (cause == null) {
                    throw th;
                }
                throw cause;
            }
        }
        int i13 = ((int[]) objArr[c3])[0];
        int i14 = ((int[]) objArr[1])[0];
        if (i14 == i13) {
            Object[] objArr19 = new Object[4];
            objArr19[1] = new int[]{i};
            objArr19[c3] = new int[]{i};
            objArr19[c2] = new int[1];
            int i15 = ((int[]) objArr[c2])[0];
            int i16 = ((int[]) objArr[1])[0];
            int i17 = ((int[]) objArr[c3])[0];
            objArr19[0] = (String[]) objArr[0];
            int iMyUid = Process.myUid();
            int i18 = ~iMyUid;
            int i19 = i15 + 1811053178 + (((~((-485376800) | i18)) | (~((-561410560) | iMyUid))) * (-370)) + (((~(iMyUid | (-485376800))) | (~(i18 | (-561410560))) | (-1040086016)) * (-370)) + 1715230720;
            int i20 = (i19 << 13) ^ i19;
            int i21 = i20 ^ (i20 >>> 17);
            ((int[]) objArr19[c2])[0] = i21 ^ (i21 << 5);
            return;
        }
        ArrayList arrayList = new ArrayList();
        String[] strArr2 = (String[]) objArr[0];
        if (strArr2 != null) {
            for (String str2 : strArr2) {
                arrayList.add(str2);
            }
        }
        Toast.makeText((Context) null, i14 / (((i14 - 1) * i14) % 2), 0).show();
        Object[] objArr20 = new Object[4];
        objArr20[1] = new int[]{i};
        objArr20[c3] = new int[]{i};
        objArr20[c2] = new int[1];
        int i22 = ((int[]) objArr[c2])[0];
        int i23 = ((int[]) objArr[1])[0];
        int i24 = ((int[]) objArr[c3])[0];
        objArr20[0] = (String[]) objArr[0];
        int iIdentityHashCode = System.identityHashCode(this);
        int i25 = i22 + 1369353118 + ((~(1046473423 | iIdentityHashCode)) * (-301)) + (((~((-38783696) | iIdentityHashCode)) | (~((~iIdentityHashCode) | 1008003663))) * (-301)) + (((~(iIdentityHashCode | (-1008003664))) | (-38783696)) * EnumC41897g.SDK_ASSET_CASH_ICON_CIRCLE_VALUE);
        int i26 = (i25 << 13) ^ i25;
        int i27 = i26 ^ (i26 >>> 17);
        ((int[]) objArr20[c2])[0] = i27 ^ (i27 << 5);
    }

    /* JADX WARN: Removed duplicated region for block: B:16:0x001a  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    private boolean w() {
        /*
            r3 = this;
            java.lang.Object r0 = r3.v
            monitor-enter(r0)
            com.facetec.sdk.cp$a r1 = r3.y     // Catch: java.lang.Throwable -> L12
            com.facetec.sdk.cp$a r2 = com.facetec.sdk.cp.a.PRE_SESSION     // Catch: java.lang.Throwable -> L12
            if (r1 == r2) goto L14
            com.facetec.sdk.cp$a r2 = com.facetec.sdk.cp.a.PROCESSING     // Catch: java.lang.Throwable -> L12
            if (r1 == r2) goto L14
            com.facetec.sdk.cp$a r2 = com.facetec.sdk.cp.a.ID_SCAN     // Catch: java.lang.Throwable -> L12
            if (r1 != r2) goto L1a
            goto L14
        L12:
            r1 = move-exception
            goto L1d
        L14:
            boolean r1 = r3.I     // Catch: java.lang.Throwable -> L12
            if (r1 != 0) goto L1a
            r1 = 1
            goto L1b
        L1a:
            r1 = 0
        L1b:
            monitor-exit(r0)     // Catch: java.lang.Throwable -> L12
            return r1
        L1d:
            monitor-exit(r0)
            throw r1
        */
        throw new UnsupportedOperationException("Method not decompiled: com.facetec.sdk.cp.w():boolean");
    }

    private static synchronized void x() {
        O = (U + 31) % 128;
        c = UUID.randomUUID().toString();
        int i2 = O + 105;
        U = i2 % 128;
        if (i2 % 2 == 0) {
            throw null;
        }
    }

    public static void y() {
        T = new byte[]{62, 54, 60, ISO7816.INS_UNBLOCK_CHV, PassportService.SFI_DG13, -10, 14, -3, -6, -5, ISO7816.INS_GET_DATA, 57, PassportService.SFI_DG11, -17, PassportService.SFI_DG15, -8, 1, -6, 16, -69, 21, ISO7816.INS_UNBLOCK_CHV, -3, 3, 3, 10, 9, -16, PassportService.SFI_DG13, -10, 14, -3, -6, -5, ISO7816.INS_GET_DATA, 70, -15, 19, -4, -70, 38, 17, 19, -4, -31, 31, -11, 3, 7, 5, -10, 1, 19, -41, 23, -9, 21, -21, -51, 62, -11, PassportService.SFI_DG13, -7, -57, 21, 37, -7, 17, -31, 18, PassportService.SFI_DG12, 4, -16, 9, -11, 2, -9, 21, -21, -51, 62, -11, PassportService.SFI_DG13, -7, -57, 37, 33, -2, -9, 5, -7, -3, -4, -3, PassportService.SFI_DG11, -9, 21, -21, -51, 62, -11, PassportService.SFI_DG13, -7, -57, 27, 37, 6, -15, 2, -2, PassportService.SFI_DG13, -21, PassportService.SFI_DG11, 9, -16, -22, 23, 5, 6, ISO7816.INS_APPEND_RECORD, PassportService.SFI_DG11, PassportService.SFI_DG11, 9, -16, -9, 21, -21, -51, 71, -1, -11, 3, ISO7816.INS_ENVELOPE, 53, PassportService.SFI_DG12, -1, -11, 18, -3, 0, -13, 9, 6, -70, 38, 20, 10, -13, -4, 3, -24, 35, -12, -2, PassportService.SFI_DG11, -26, PassportService.SFI_DG15, PassportService.SFI_DG13, -10, PassportService.SFI_DG11, -2, 18, -3, 0, -13, 9, 6, -9, 19, -4, -43, 37, 6, PassportService.SFI_DG13, -10, 14, -3, -6, -5, ISO7816.INS_GET_DATA, 72, -13, -4, 18, -73, 29, 26, 20, -52, 49, -17, 9, 6, -6, 20, ISO7816.INS_GET_DATA, ISO7816.INS_UNBLOCK_CHV, -11, 1, -31, ISO7816.INS_UNBLOCK_CHV, -3, -2, -26, 33, -2, -9, 5, -7, PassportService.SFI_DG13, -10, 14, -3, -6, -5, ISO7816.INS_GET_DATA, 72, -13, -4, 18, -73, 40, 19, -4, 18, -52, ISO7816.INS_UNBLOCK_CHV, -1, -8, 3, -2, 14, -3, -17, 19, -11, 6, -1, -2, PassportService.SFI_DG15, ISO7816.INS_CREATE_FILE, PassportService.SFI_DG13, PassportService.SFI_DG15, ISO7816.INS_DELETE_FILE, 21, 4, -8, 10, 6, -1, -9, 21, -21, -51, 62, -11, PassportService.SFI_DG13, -7, -57, 23, 41, 7, -8, 3, -14, 5, 5, -13, PassportService.SFI_DG11};
        ab = 111;
    }

    private Runnable z() {
        int iD = bb.d();
        int iD2 = bb.d();
        int iD3 = bb.d();
        return (Runnable) b(1756507833, iD, bb.d(), iD2, -1756507829, iD3, new Object[]{this});
    }

    public final void d() {
        int i2 = U + 105;
        int i3 = i2 % 128;
        O = i3;
        if (i2 % 2 != 0) {
            throw null;
        }
        ac acVar = this.b;
        if (acVar != null) {
            int i4 = i3 + 45;
            U = i4 % 128;
            if (i4 % 2 == 0) {
                acVar.e();
                throw null;
            }
            if (acVar.e()) {
                this.b.c(this.d, new Runnable() { // from class: com.facetec.sdk.兵帝
                    @Override // java.lang.Runnable
                    public final void run() throws Throwable {
                        this.f7076.M();
                    }
                });
            }
        }
    }

    /* JADX WARN: Removed duplicated region for block: B:43:0x009b A[EXC_TOP_SPLITTER, SYNTHETIC] */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public final void d$27a58182(final java.lang.Object r12, final int r13) throws java.lang.Throwable {
        /*
            Method dump skipped, instruction units count: 201
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: com.facetec.sdk.cp.d$27a58182(java.lang.Object, int):void");
    }

    public final void e() {
        O = (U + 113) % 128;
        ac acVar = this.b;
        if (acVar == null || this.y == a.ID_SCAN) {
            return;
        }
        acVar.b(false);
        U = (O + 89) % 128;
    }

    public final Object f$35266171() {
        int i2 = O;
        Object obj = this.x;
        int i3 = i2 + 71;
        U = i3 % 128;
        if (i3 % 2 != 0) {
            return obj;
        }
        throw null;
    }

    public final void h() {
        O = (U + 11) % 128;
        ac acVar = this.b;
        if (acVar != null) {
            acVar.h();
        }
        U = (O + 99) % 128;
    }

    public final synchronized void i() {
        boolean z;
        dj.a((Runnable) b(1756507833, bb.d(), bb.d(), bb.d(), -1756507829, bb.d(), new Object[]{this}));
        synchronized (this.v) {
            try {
                a aVar = this.y;
                if (aVar == a.PRE_SESSION || aVar == a.PROCESSING || aVar == a.WAITING_TO_FINISH) {
                    this.y = a.FINISHED;
                    z = true;
                } else {
                    z = false;
                }
            } catch (Throwable th) {
                throw th;
            }
        }
        if (z) {
            cv.g(true);
        }
    }

    public final synchronized void j() {
        boolean z;
        dj.a((Runnable) b(1756507833, bb.d(), bb.d(), bb.d(), -1756507829, bb.d(), new Object[]{this}));
        synchronized (this.v) {
            try {
                a aVar = this.y;
                if (aVar == a.ID_SCAN || aVar == a.PRE_SESSION || aVar == a.PROCESSING || aVar == a.WAITING_TO_FINISH) {
                    this.y = a.FINISHED;
                    z = true;
                } else {
                    z = false;
                }
            } catch (Throwable th) {
                throw th;
            }
        }
        if (z) {
            cv.h(false);
        }
    }

    public final cs k() throws Throwable {
        O = (U + 13) % 128;
        cs csVarM = cv.m();
        this.r = csVarM;
        O = (U + 67) % 128;
        return csVarM;
    }

    public final synchronized void m() {
        synchronized (this.v) {
            try {
                a aVar = this.y;
                if (aVar == a.PROCESSING || aVar == a.WAITING_TO_FINISH) {
                    this.y = a.FINISHED;
                }
            } catch (Throwable th) {
                throw th;
            }
        }
        int iD = bb.d();
        int iD2 = bb.d();
        int iD3 = bb.d();
        dj.a((Runnable) b(1756507833, iD, bb.d(), iD2, -1756507829, iD3, new Object[]{this}));
        I();
        d();
        F();
        this.h.clear();
        this.j.clear();
    }

    public final void n() {
        int iD = bb.d();
        int iD2 = bb.d();
        int iD3 = bb.d();
        b(-1456391372, iD, bb.d(), iD2, 1456391379, iD3, new Object[]{this});
    }

    public final da o() {
        U = (O + EnumC41897g.SDK_ASSET_ILLUSTRATION_CALENDAR_VALUE) % 128;
        da daVar = (da) cv.b(pk.d(), pk.d(), pk.d(), pk.d(), -1417398177, new Object[0], 1417398179);
        this.t = daVar;
        U = (O + 81) % 128;
        return daVar;
    }

    public final cm t() throws Throwable {
        U = (O + 31) % 128;
        cm cmVarQ = cv.q();
        this.o = cmVarQ;
        int i2 = O + 57;
        U = i2 % 128;
        if (i2 % 2 != 0) {
            return cmVarQ;
        }
        throw null;
    }

    public static synchronized cp c(Activity activity) {
        if (i == null) {
            i = new cp(activity);
            boolean zB = cv.b((Context) activity);
            if (!H) {
                int i2 = O + 119;
                U = i2 % 128;
                if (i2 % 2 == 0) {
                    throw null;
                }
                if (!zB) {
                    throw new AssertionError();
                }
            }
        }
        cp cpVar = i;
        int i3 = U + 81;
        O = i3 % 128;
        if (i3 % 2 == 0) {
            return cpVar;
        }
        int i4 = 48 / 0;
        return cpVar;
    }

    public final synchronized void a(d dVar) {
        O = (U + 115) % 128;
        a(dVar, this.f);
        int i2 = U + 35;
        O = i2 % 128;
        if (i2 % 2 != 0) {
            throw null;
        }
    }

    /* JADX WARN: Removed duplicated region for block: B:243:0x069c  */
    /* JADX WARN: Removed duplicated region for block: B:382:0x06aa A[ADDED_TO_REGION, REMOVE, SYNTHETIC] */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public final synchronized boolean b(@androidx.annotation.NonNull android.content.Context r23, boolean r24) {
        /*
            Method dump skipped, instruction units count: 1922
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: com.facetec.sdk.cp.b(android.content.Context, boolean):boolean");
    }

    public static /* synthetic */ Object b(int i2, int i3, int i4, int i5, int i6, int i7, Object[] objArr) {
        int i8 = ~i2;
        int i9 = ~i6;
        int i10 = ~i3;
        int i11 = (~(i8 | i9 | i10)) | (~(i2 | i6));
        int i12 = ~(i3 | i6);
        int i13 = i11 | i12;
        int i14 = ~(i8 | i6);
        int i15 = i12 | i8 | (~(i9 | i10));
        int i16 = i2 + i6 + i5 + (1349231875 * i7) + (1735201104 * i4);
        int i17 = i16 * i16;
        int i18 = ((-413510627) * i2) + 1558183936 + (237349861 * i6) + (i13 * 325430244) + (325430244 * i14) + ((-325430244) * i15) + ((-88080384) * i5) + ((-1337982976) * i7) + (469762048 * i4) + (1272971264 * i17);
        int i19 = ((i2 * 236314795) - 374860141) + (i6 * 236313123) + (i13 * (-836)) + (i14 * (-836)) + (i15 * 836) + (i5 * 236313959) + (i7 * (-66979019)) + (i4 * (-1872492752)) + (i17 * (-417333248));
        switch (i18 + (i19 * i19 * 639631360)) {
            case 1:
                cp cpVar = (cp) objArr[0];
                U = (O + 59) % 128;
                ac acVar = cpVar.b;
                if (acVar == null) {
                    return null;
                }
                acVar.a();
                U = (O + 19) % 128;
                return null;
            case 2:
                return a(objArr);
            case 3:
                return d(objArr);
            case 4:
                return b(objArr);
            case 5:
                return e(objArr);
            case 6:
                cp cpVar2 = (cp) objArr[0];
                U = (O + 89) % 128;
                if (!t.c) {
                    U = (O + 49) % 128;
                    return null;
                }
                final m mVar = ((bi) cpVar2.l.get()).k;
                int i20 = t.e;
                if (i20 == 1) {
                    O = (U + 33) % 128;
                    cv.H("waypoint", 1);
                    dj.a(new Runnable() { // from class: com.facetec.sdk.兵字
                        @Override // java.lang.Runnable
                        public final void run() {
                            cp.a(mVar);
                        }
                    });
                } else if (i20 > 10) {
                    cv.H("waypoint", 2);
                    dj.a(new Runnable() { // from class: com.facetec.sdk.兵宫
                        @Override // java.lang.Runnable
                        public final void run() {
                            cp.c(mVar);
                        }
                    });
                    t.c = false;
                    U = (O + 105) % 128;
                }
                t.e++;
                return null;
            case 7:
                return c(objArr);
            case 8:
                return h(objArr);
            case 9:
                return i(objArr);
            default:
                cp cpVar3 = (cp) objArr[0];
                Context context = (Context) objArr[1];
                int i21 = (O + 27) % 128;
                U = i21;
                if (cpVar3.B) {
                    O = (i21 + 17) % 128;
                    o.e(context);
                }
                return null;
        }
    }

    private synchronized <T> void a(T t, ArrayList<WeakReference<T>> arrayList) {
        Iterator<WeakReference<T>> it = arrayList.iterator();
        U = (O + 7) % 128;
        while (it.hasNext()) {
            if (it.next().get() == t) {
                U = (O + 79) % 128;
                it.remove();
            }
        }
    }

    private static /* synthetic */ Object e(Object[] objArr) {
        final cp cpVar = (cp) objArr[0];
        final boolean zBooleanValue = ((Boolean) objArr[1]).booleanValue();
        int i2 = O;
        int i3 = i2 + 63;
        U = i3 % 128;
        if (i3 % 2 != 0) {
            if (cpVar.b != null) {
                U = (i2 + 23) % 128;
                if (cpVar.y != a.ID_SCAN) {
                    cpVar.d();
                    dj.a(new Runnable() { // from class: com.facetec.sdk.兵凤
                        @Override // java.lang.Runnable
                        public final void run() {
                            this.f7061.b(zBooleanValue);
                        }
                    });
                }
            }
            return null;
        }
        ac acVar = cpVar.b;
        throw null;
    }

    private static /* synthetic */ Object h(Object[] objArr) throws Throwable {
        a aVar;
        cp cpVar = (cp) objArr[0];
        Object obj = objArr[1];
        int iIntValue = ((Number) objArr[2]).intValue();
        synchronized (cpVar.v) {
            a aVar2 = cpVar.y;
            if (aVar2 == a.FINISHED || aVar2 == (aVar = a.WAITING_TO_FINISH)) {
                return null;
            }
            int i2 = cpVar.w + 1;
            cpVar.w = i2;
            if (i2 < 4) {
                return null;
            }
            try {
                Object[] objArr2 = new Object[1];
                aj("䞼ᮘ\ufffe区㝄譑溭싱ꛉ穟\ude53놪ᖑ\ue9c1䴡ⅺ", Process.getGidForName("") + 23600, objArr2);
                Class<?> cls = Class.forName((String) objArr2[0]);
                Object[] objArr3 = new Object[1];
                aj("䞵谺킖╯槗빅舴횭᭷濚둉\uf808첓ᅿ旤ꩈ︵", 52121 - Color.red(0), objArr3);
                cv.i(obj, ((Long) cls.getMethod((String) objArr3[0], null).invoke(null, null)).longValue(), iIntValue, false);
                cpVar.n = cv.i();
                cpVar.o = cv.q();
                cu cuVar = cpVar.n;
                if (cuVar == cu.ZOOM_CLOSE) {
                    cpVar.d = true;
                }
                cu cuVar2 = cu.PROCESSING_COMPLETE_RETRY;
                if (cuVar == cuVar2 || cuVar == cu.PROCESSING_COMPLETE_SUCCESS) {
                    cpVar.y = aVar;
                }
                if (cuVar == cu.PROCESSING_COMPLETE_TIMED_OUT || cuVar == cuVar2 || cuVar == cu.PROCESSING_COMPLETE_SUCCESS) {
                    cpVar.y = aVar;
                    cpVar.d();
                    o.c();
                }
                cpVar.L();
                return null;
            } catch (Throwable th) {
                Throwable cause = th.getCause();
                if (cause != null) {
                    throw cause;
                }
                throw th;
            }
        }
    }

    public final synchronized void d(b bVar) {
        this.h.add(new WeakReference<>(bVar));
        O = (U + 21) % 128;
    }

    public static synchronized void c() {
        int i2 = O;
        int i3 = i2 + 9;
        U = i3 % 128;
        if (i3 % 2 != 0) {
            if (i == null) {
                U = (i2 + 53) % 128;
                cv.c();
            }
        } else {
            throw null;
        }
    }

    private static /* synthetic */ Object i(Object[] objArr) {
        int i2 = (O + 5) % 128;
        U = i2;
        N = 455727328103507553L;
        int i3 = i2 + 87;
        O = i3 % 128;
        if (i3 % 2 == 0) {
            return null;
        }
        throw null;
    }

    public final synchronized void d(e eVar) {
        int i2 = U + 77;
        O = i2 % 128;
        if (i2 % 2 == 0) {
            a(eVar, this.j);
        } else {
            a(eVar, this.j);
            throw null;
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static /* synthetic */ void e(Context context) {
        int iD = bb.d();
        int iD2 = bb.d();
        int iD3 = bb.d();
        b(-1933799457, iD, bb.d(), iD2, 1933799460, iD3, new Object[]{context});
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static /* synthetic */ void a(Context context) {
        O = (U + 79) % 128;
        o.a(context);
        int i2 = U + 103;
        O = i2 % 128;
        if (i2 % 2 != 0) {
            int i3 = 54 / 0;
        }
    }

    /* JADX WARN: Removed duplicated region for block: B:19:0x0030 A[Catch: all -> 0x0027, TRY_LEAVE, TryCatch #1 {all -> 0x0027, blocks: (B:4:0x0002, B:30:0x00a6, B:31:0x00a8, B:34:0x00bc, B:39:0x00c3, B:40:0x00c4, B:13:0x001c, B:15:0x0020, B:18:0x002b, B:19:0x0030, B:23:0x0038, B:25:0x0046, B:26:0x0049, B:28:0x005e, B:29:0x0066, B:32:0x00a9, B:33:0x00bb), top: B:45:0x0002, inners: #0 }] */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public final synchronized boolean d(@androidx.annotation.NonNull final android.content.Context r10, java.lang.String r11) {
        /*
            r9 = this;
            monitor-enter(r9)
            r0 = 0
            r9.w = r0     // Catch: java.lang.Throwable -> L27
            int[] r1 = com.facetec.sdk.cp.AnonymousClass2.c     // Catch: java.lang.Throwable -> L27
            com.facetec.sdk.cp$a r2 = r9.y     // Catch: java.lang.Throwable -> L27
            int r2 = r2.ordinal()     // Catch: java.lang.Throwable -> L27
            r1 = r1[r2]     // Catch: java.lang.Throwable -> L27
            r2 = 1
            if (r1 == r2) goto L30
            r3 = 2
            if (r1 == r3) goto L30
            r3 = 3
            if (r1 == r3) goto L1c
            r3 = 4
            if (r1 == r3) goto L30
            goto La6
        L1c:
            boolean r0 = com.facetec.sdk.ah.c     // Catch: java.lang.Throwable -> L27
            if (r0 == 0) goto L2b
            com.facetec.sdk.cv.e(r2)     // Catch: java.lang.Throwable -> L27
            com.facetec.sdk.cv.b(r11)     // Catch: java.lang.Throwable -> L27
            goto L2b
        L27:
            r0 = move-exception
            r10 = r0
            goto Lc5
        L2b:
            com.facetec.sdk.cp$a r11 = com.facetec.sdk.cp.a.PROCESSING     // Catch: java.lang.Throwable -> L27
            r9.y = r11     // Catch: java.lang.Throwable -> L27
            goto La6
        L30:
            boolean r11 = com.facetec.sdk.cv.b(r11)     // Catch: java.lang.Throwable -> L27
            if (r11 != 0) goto L38
            monitor-exit(r9)
            return r0
        L38:
            com.facetec.sdk.cp$a r11 = com.facetec.sdk.cp.a.PROCESSING     // Catch: java.lang.Throwable -> L27
            r9.y = r11     // Catch: java.lang.Throwable -> L27
            r9.d(r10)     // Catch: java.lang.Throwable -> L27
            com.facetec.sdk.ed.d()     // Catch: java.lang.Throwable -> L27
            boolean r11 = r9.B     // Catch: java.lang.Throwable -> L27
            if (r11 == 0) goto L49
            com.facetec.sdk.o.e()     // Catch: java.lang.Throwable -> L27
        L49:
            com.facetec.sdk.o.a()     // Catch: java.lang.Throwable -> L27
            com.facetec.sdk.o.d()     // Catch: java.lang.Throwable -> L27
            java.lang.String r11 = com.facetec.sdk.ao.W     // Catch: java.lang.Throwable -> L27
            int r0 = com.facetec.sdk.bk.i(r10)     // Catch: java.lang.Throwable -> L27
            com.facetec.sdk.cv.H(r11, r0)     // Catch: java.lang.Throwable -> L27
            boolean r11 = com.facetec.sdk.h.c()     // Catch: java.lang.Throwable -> L27
            if (r11 == 0) goto L66
            com.facetec.sdk.兵人 r11 = new com.facetec.sdk.兵人     // Catch: java.lang.Throwable -> L27
            r11.<init>()     // Catch: java.lang.Throwable -> L27
            com.facetec.sdk.dj.a(r11)     // Catch: java.lang.Throwable -> L27
        L66:
            java.lang.String r11 = com.facetec.sdk.ao.Z     // Catch: java.lang.Throwable -> L27
            boolean r0 = com.facetec.sdk.bj.i     // Catch: java.lang.Throwable -> L27
            com.facetec.sdk.cv.N(r11, r0)     // Catch: java.lang.Throwable -> L27
            boolean r11 = com.facetec.sdk.bj.i     // Catch: java.lang.Throwable -> L27
            java.lang.String r0 = com.facetec.sdk.ao.Z     // Catch: java.lang.Throwable -> L27
            com.facetec.sdk.cv.K(r0, r11)     // Catch: java.lang.Throwable -> L27
            java.lang.String r11 = com.facetec.sdk.ao.w     // Catch: java.lang.Throwable -> L27
            int r0 = com.facetec.sdk.o.a     // Catch: java.lang.Throwable -> L27
            com.facetec.sdk.cv.K(r11, r0)     // Catch: java.lang.Throwable -> L27
            java.lang.String r11 = com.facetec.sdk.ao.x     // Catch: java.lang.Throwable -> L27
            int r0 = android.os.Build.VERSION.SDK_INT     // Catch: java.lang.Throwable -> L27
            com.facetec.sdk.cv.H(r11, r0)     // Catch: java.lang.Throwable -> L27
            java.lang.String r11 = com.facetec.sdk.ao.x     // Catch: java.lang.Throwable -> L27
            com.facetec.sdk.cv.K(r11, r0)     // Catch: java.lang.Throwable -> L27
            com.facetec.sdk.o.j()     // Catch: java.lang.Throwable -> L27
            com.facetec.sdk.兵仙 r11 = new com.facetec.sdk.兵仙     // Catch: java.lang.Throwable -> L27
            r11.<init>()     // Catch: java.lang.Throwable -> L27
            com.facetec.sdk.dj.a(r11)     // Catch: java.lang.Throwable -> L27
            com.facetec.sdk.兵兵 r11 = new com.facetec.sdk.兵兵     // Catch: java.lang.Throwable -> L27
            r11.<init>()     // Catch: java.lang.Throwable -> L27
            com.facetec.sdk.dj.d(r11)     // Catch: java.lang.Throwable -> L27
            com.facetec.sdk.o.f()     // Catch: java.lang.Throwable -> L27
            com.facetec.sdk.o.h()     // Catch: java.lang.Throwable -> L27
            com.facetec.sdk.o.b()     // Catch: java.lang.Throwable -> L27
            com.facetec.sdk.o.g()     // Catch: java.lang.Throwable -> L27
        La6:
            java.util.Timer r11 = r9.A     // Catch: java.lang.Throwable -> L27
            monitor-enter(r11)     // Catch: java.lang.Throwable -> L27
            r9.I()     // Catch: java.lang.Throwable -> Lc1
            com.facetec.sdk.dl r4 = r9.C()     // Catch: java.lang.Throwable -> Lc1
            r9.C = r4     // Catch: java.lang.Throwable -> Lc1
            java.util.Timer r3 = r9.A     // Catch: java.lang.Throwable -> Lc1
            r5 = 60
            r7 = 10000(0x2710, double:4.9407E-320)
            r3.scheduleAtFixedRate(r4, r5, r7)     // Catch: java.lang.Throwable -> Lc1
            monitor-exit(r11)     // Catch: java.lang.Throwable -> Lc1
            b(r10)     // Catch: java.lang.Throwable -> L27
            monitor-exit(r9)
            return r2
        Lc1:
            r0 = move-exception
            r10 = r0
            monitor-exit(r11)     // Catch: java.lang.Throwable -> L27
            throw r10     // Catch: java.lang.Throwable -> L27
        Lc5:
            monitor-exit(r9)     // Catch: java.lang.Throwable -> L27
            throw r10
        */
        throw new UnsupportedOperationException("Method not decompiled: com.facetec.sdk.cp.d(android.content.Context, java.lang.String):boolean");
    }

    public final synchronized void c(e eVar) {
        this.j.add(new WeakReference<>(eVar));
        U = (O + 105) % 128;
    }

    public final synchronized void a(boolean z) {
        boolean z2;
        synchronized (this.v) {
            try {
                a aVar = this.y;
                if (aVar == a.PROCESSING || aVar == a.WAITING_TO_FINISH) {
                    this.y = a.FINISHED;
                    z2 = true;
                } else {
                    z2 = false;
                }
            } catch (Throwable th) {
                throw th;
            }
        }
        int iD = bb.d();
        int iD2 = bb.d();
        int iD3 = bb.d();
        dj.a((Runnable) b(1756507833, iD, bb.d(), iD2, -1756507829, iD3, new Object[]{this}));
        I();
        d();
        F();
        if (z2) {
            cv.e(z);
        }
    }

    public final synchronized void c(d dVar) {
        this.f.add(new WeakReference<>(dVar));
        O = (U + 7) % 128;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static /* synthetic */ void c(WeakReference weakReference) {
        int i2 = O + 23;
        U = i2 % 128;
        if (i2 % 2 != 0) {
            cp cpVar = (cp) weakReference.get();
            if (cpVar != null) {
                int i3 = O + 89;
                U = i3 % 128;
                if (i3 % 2 != 0) {
                    cpVar.N();
                } else {
                    cpVar.N();
                    throw null;
                }
            }
            O = (U + 29) % 128;
            return;
        }
        throw null;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static /* synthetic */ void a(m mVar) {
        int i2 = O;
        U = (i2 + 73) % 128;
        if (mVar != null) {
            U = (i2 + 105) % 128;
            mVar.e(c, t.b.WAYPOINT_UPLOAD);
        }
        int i3 = U + 125;
        O = i3 % 128;
        if (i3 % 2 != 0) {
            throw null;
        }
    }

    public static synchronized void b() {
        int i2 = U;
        O = (i2 + 23) % 128;
        cp cpVar = i;
        if (cpVar != null) {
            O = (i2 + 67) % 128;
            cpVar.H();
            i = null;
        }
    }

    private static /* synthetic */ Object c(Object[] objArr) {
        cp cpVar = (cp) objArr[0];
        synchronized (cpVar.v) {
            try {
                a aVar = cpVar.y;
                if (aVar == a.PRE_SESSION || aVar == a.PROCESSING || aVar == a.ID_SCAN) {
                    cpVar.y = a.WAITING_TO_FINISH;
                }
            } catch (Throwable th) {
                throw th;
            }
        }
        cpVar.I();
        cpVar.h.clear();
        cpVar.j.clear();
        cpVar.f.clear();
        cpVar.f95856g.shutdown();
        cpVar.m.shutdown();
        return null;
    }

    private static /* synthetic */ Object a(Object[] objArr) {
        cp cpVar = (cp) objArr[0];
        int i2 = O + 43;
        U = i2 % 128;
        int i3 = i2 % 2;
        cpVar.W();
        if (i3 != 0) {
            return null;
        }
        int i4 = 17 / 0;
        return null;
    }

    @NonNull
    private synchronized <T> List<T> a(ArrayList<WeakReference<T>> arrayList) {
        ArrayList arrayList2;
        arrayList2 = new ArrayList(arrayList.size());
        Iterator<WeakReference<T>> it = arrayList.iterator();
        while (it.hasNext()) {
            O = (U + 35) % 128;
            T t = it.next().get();
            if (t != null) {
                U = (O + 75) % 128;
                arrayList2.add(t);
                O = (U + 111) % 128;
            }
        }
        return arrayList2;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void b(boolean z) {
        int i2 = O + 3;
        U = i2 % 128;
        int i3 = i2 % 2;
        h();
        this.b.b(z);
        this.d = false;
    }

    public final synchronized void b(b bVar) {
        U = (O + 53) % 128;
        a(bVar, this.h);
        int i2 = O + 97;
        U = i2 % 128;
        if (i2 % 2 == 0) {
            int i3 = 6 / 0;
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static /* synthetic */ void c(m mVar) {
        if (mVar != null) {
            U = (O + 5) % 128;
            mVar.e(c, t.b.WAYPOINT_UPLOAD);
            U = (O + 9) % 128;
        }
    }

    private static void b(@NonNull Context context) {
        O = (U + 55) % 128;
        cv.K(ao.ao, FaceTecSDK.b);
        cv.K(ao.ap, FaceTecSDK.i);
        cv.K(ao.ar, FaceTecSDK.h);
        cv.R(c);
        cv.Q(av.d());
        cv.S(av.e(context));
        cb.c();
        cv.L(ao.ad, ((PowerManager) context.getSystemService("power")).isPowerSaveMode());
        int i2 = U + 7;
        O = i2 % 128;
        if (i2 % 2 != 0) {
            int i3 = 41 / 0;
        }
    }

    public final void a() {
        int iD = bb.d();
        int iD2 = bb.d();
        int iD3 = bb.d();
        b(-227948411, iD, bb.d(), iD2, 227948412, iD3, new Object[]{this});
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void c(Context context) {
        int iD = bb.d();
        int iD2 = bb.d();
        int iD3 = bb.d();
        b(123960875, iD, bb.d(), iD2, -123960875, iD3, new Object[]{this, context});
    }

    public final synchronized void d(@NonNull Context context, boolean z, String str) {
        this.w = 0;
        int iD = bb.d();
        int iD2 = bb.d();
        int iD3 = bb.d();
        dj.a((Runnable) b(1756507833, iD, bb.d(), iD2, -1756507829, iD3, new Object[]{this}));
        int i2 = AnonymousClass2.c[this.y.ordinal()];
        if (i2 == 1 || i2 == 2) {
            if (!cv.f(z, str)) {
                return;
            } else {
                this.y = a.ID_SCAN;
            }
        } else {
            if (i2 == 3 || i2 == 4) {
                return;
            }
            if (i2 == 5) {
                return;
            }
        }
        synchronized (this.A) {
            I();
            dl dlVarC = C();
            this.C = dlVarC;
            this.A.scheduleAtFixedRate(dlVarC, 60L, 10000L);
        }
        b(context);
    }

    private void d(@NonNull Context context) {
        U = (O + 89) % 128;
        if (!(!cj.c(context))) {
            U = (O + 19) % 128;
            cv.z();
        }
        if (!(!this.B)) {
            O = (U + 99) % 128;
            cv.A();
        }
    }

    private static /* synthetic */ Object d(Object[] objArr) throws Throwable {
        String strTrim;
        Context context = (Context) objArr[0];
        ba.e("UMT");
        UsbManager usbManager = (UsbManager) context.getApplicationContext().getSystemService("usb");
        ba.d("UMT");
        ba.e("UDT");
        HashMap<String, UsbDevice> deviceList = usbManager.getDeviceList();
        ba.d("UDT");
        StringBuilder sb = new StringBuilder();
        StringBuilder sb2 = new StringBuilder();
        StringBuilder sb3 = new StringBuilder();
        StringBuilder sb4 = new StringBuilder();
        boolean z = false;
        for (UsbDevice usbDevice : deviceList.values()) {
            O = (U + 9) % 128;
            if (usbDevice != null) {
                int i2 = O + 77;
                U = i2 % 128;
                if (i2 % 2 != 0) {
                    String deviceName = usbDevice.getDeviceName();
                    String strValueOf = String.valueOf(usbDevice.getDeviceClass());
                    if (usbDevice.getManufacturerName() != null) {
                        int i3 = U + 95;
                        O = i3 % 128;
                        if (i3 % 2 == 0) {
                            strTrim = usbDevice.getManufacturerName().trim();
                        } else {
                            usbDevice.getManufacturerName().trim();
                            throw null;
                        }
                    } else {
                        strTrim = "FT_NULL";
                    }
                    String strTrim2 = usbDevice.getProductName() != null ? usbDevice.getProductName().trim() : "FT_NULL";
                    sb.append(deviceName);
                    Object[] objArr2 = new Object[1];
                    ai("嚋", 42131 - View.resolveSize(0, 0), objArr2);
                    sb.append((String) objArr2[0]);
                    sb2.append(strValueOf);
                    Object[] objArr3 = new Object[1];
                    ai("嚋", 42130 - ExpandableListView.getPackedPositionChild(0L), objArr3);
                    sb2.append((String) objArr3[0]);
                    sb3.append(strTrim);
                    Object[] objArr4 = new Object[1];
                    ai("嚋", (-16735085) - Color.rgb(0, 0, 0), objArr4);
                    sb3.append((String) objArr4[0]);
                    sb4.append(strTrim2);
                    Object[] objArr5 = new Object[1];
                    ai("嚋", 42131 - Color.red(0), objArr5);
                    sb4.append((String) objArr5[0]);
                    z = true;
                } else {
                    usbDevice.getDeviceName();
                    String.valueOf(usbDevice.getDeviceClass());
                    usbDevice.getManufacturerName();
                    throw null;
                }
            }
            O = (U + 47) % 128;
        }
        cv.N(ao.C, z);
        cv.I(ao.F, sb.toString());
        cv.I(ao.E, sb2.toString());
        cv.I(ao.I, sb3.toString());
        cv.I(ao.G, sb4.toString());
        cv.I(ao.J, String.valueOf(ba.c("UMT")));
        cv.I(ao.L, String.valueOf(ba.c("UDT")));
        int i4 = U + 109;
        O = i4 % 128;
        if (i4 % 2 != 0) {
            int i5 = 52 / 0;
        }
        return null;
    }

    private void d(boolean z) {
        Object[] objArr = {this, Boolean.valueOf(z)};
        b(495620445, bb.d(), bb.d(), bb.d(), -495620440, bb.d(), objArr);
    }
}