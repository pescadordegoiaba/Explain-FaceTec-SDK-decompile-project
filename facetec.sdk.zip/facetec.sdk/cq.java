package com.facetec.sdk;

import android.os.Parcel;
import androidx.annotation.NonNull;
import java.util.HashMap;
import java.util.Timer;

/* JADX INFO: loaded from: classes4.dex */
final class cq {

    @NonNull
    private static final HashMap<Integer, Object> d = new HashMap<>();
    private static Timer b = null;

    public static <T> void a(T t, @NonNull Parcel parcel) {
        if (t != null) {
            parcel.writeInt(e(t));
        } else {
            parcel.writeInt(0);
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static synchronized Object b(int i) {
        Object objRemove;
        HashMap<Integer, Object> map = d;
        objRemove = map.remove(Integer.valueOf(i));
        if (b != null && map.isEmpty()) {
            b.cancel();
            b = null;
        }
        return objRemove;
    }

    public static <T> T d(@NonNull Parcel parcel) {
        int i = parcel.readInt();
        if (i != 0) {
            return (T) b(i);
        }
        return null;
    }

    private static synchronized int e(@NonNull Object obj) {
        final int iHashCode;
        try {
            iHashCode = obj.hashCode();
            if (b == null) {
                b = new Timer();
            }
            b.schedule(new dl(new Runnable() { // from class: com.facetec.sdk.兵庙
                @Override // java.lang.Runnable
                public final void run() {
                    cq.b(iHashCode);
                }
            }), 300000L);
            d.put(Integer.valueOf(iHashCode), obj);
        } catch (Throwable th) {
            throw th;
        }
        return iHashCode;
    }
}