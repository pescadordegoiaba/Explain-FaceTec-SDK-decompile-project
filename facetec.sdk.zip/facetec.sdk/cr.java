package com.facetec.sdk;

import android.app.Activity;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import java.lang.ref.WeakReference;

/* JADX INFO: loaded from: classes4.dex */
final class cr extends BroadcastReceiver {
    private final WeakReference<bm> e;

    public cr(Activity activity) {
        this.e = new WeakReference<>((bm) activity);
    }

    @Override // android.content.BroadcastReceiver
    public final void onReceive(Context context, Intent intent) {
        if (bk.b()) {
            t.d(this.e.get(), c.POWER_BUTTON_PRESSED, null, null);
        }
    }
}