package com.facetec.sdk;

/* JADX INFO: loaded from: classes4.dex */
enum cw {
    DEFAULT,
    DARK_AS_POSSIBLE,
    BRIGHT_AS_POSSIBLE
}