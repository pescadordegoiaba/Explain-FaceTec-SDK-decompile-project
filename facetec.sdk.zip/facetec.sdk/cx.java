package com.facetec.sdk;

import android.animation.Animator;
import android.animation.ObjectAnimator;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.PorterDuff;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.LayerDrawable;
import android.graphics.drawable.ScaleDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.Process;
import android.os.SystemClock;
import android.telephony.cdma.CdmaCellLocation;
import android.text.AndroidCharacter;
import android.text.TextUtils;
import android.util.TypedValue;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewConfiguration;
import android.view.ViewGroup;
import android.view.ViewPropertyAnimator;
import android.view.ViewTreeObserver;
import android.view.animation.DecelerateInterpolator;
import android.view.animation.LinearInterpolator;
import android.view.animation.RotateAnimation;
import android.widget.ExpandableListView;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.RelativeLayout;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.vectordrawable.graphics.drawable.Animatable2Compat$AnimationCallback;
import com.facetec.sdk.FaceTecCancelButtonCustomization;
import com.facetec.sdk.au;
import com.facetec.sdk.ov;
import com.facetec.sdk.pg;
import com.google.android.gms.auth.api.proxy.AuthApiStatusCodes;
import com.incode.welcome_sdk.modules.SelfieScan;
import com.plaid.internal.EnumC41897g;
import java.lang.reflect.Method;
import kotlin.C6852;
import net.sf.scuba.smartcards.ISO7816;
import net.sf.scuba.smartcards.ISOFileInfo;
import org.bouncycastle.crypto.signers.PSSSigner;
import org.bouncycastle.i18n.LocalizedMessage;
import org.jmrtd.PassportService;

/* JADX INFO: loaded from: classes4.dex */
public final class cx extends au {
    private static final byte[] $$a = null;
    private static final int $$b = 0;
    private static long G;
    ImageView a;
    ImageView b;
    TextView c;
    RelativeLayout d;
    RelativeLayout e;
    ImageView f;
    private TextView h;
    e i;
    private View j;
    private RelativeLayout k;
    private ImageView l;
    private ProgressBar m;
    private ImageView n;
    private TextView o;
    private ObjectAnimator p;
    private LinearLayout q;
    private RelativeLayout r;
    private ImageView s;
    private TextView t;
    private Handler v;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    boolean f95859g = false;
    private boolean u = false;
    private boolean y = false;
    private boolean x = false;
    private boolean w = false;
    private long D = -1;
    private a A = a.UPLOAD_STARTED;
    private d B = d.DEFAULT;
    private final Handler C = new Handler(Looper.getMainLooper());
    private boolean z = false;
    private final au.c I = new au.c(new Runnable() { // from class: com.facetec.sdk.兵月
        @Override // java.lang.Runnable
        public final void run() {
            this.f7084.s();
        }
    });
    private ViewTreeObserver.OnGlobalLayoutListener F = new ViewTreeObserver.OnGlobalLayoutListener() { // from class: com.facetec.sdk.cx.2
        private static final byte[] $$a = null;
        private static final int $$b = 0;
        private static final byte[] $$c = null;
        private static final byte[] $$d = null;
        private static final int $$e = 0;
        private static final int $$f = 0;
        private static int $10;
        private static int $11;
        private static int a;
        private static boolean b;
        private static char[] d;
        private static boolean e;
        private static int f;

        /* JADX INFO: renamed from: g, reason: collision with root package name */
        private static int[] f95860g;
        private static int h;

        /* JADX WARN: Removed duplicated region for block: B:10:0x0020  */
        /* JADX WARN: Removed duplicated region for block: B:8:0x001a  */
        /* JADX WARN: Unsupported multi-entry loop pattern (BACK_EDGE: B:10:0x0020 -> B:11:0x002c). Please report as a decompilation issue!!! */
        /*
            Code decompiled incorrectly, please refer to instructions dump.
            To view partially-correct code enable 'Show inconsistent code' option in preferences
        */
        private static java.lang.String $$g(short r6, byte r7, byte r8) {
            /*
                byte[] r0 = com.facetec.sdk.cx.AnonymousClass2.$$c
                int r7 = r7 * 4
                int r1 = r7 + 1
                int r6 = r6 + 4
                int r8 = r8 + 117
                byte[] r1 = new byte[r1]
                r2 = 0
                if (r0 != 0) goto L14
                r3 = r0
                r4 = r2
                r0 = r8
                r8 = r6
                goto L2c
            L14:
                r3 = r2
            L15:
                byte r4 = (byte) r8
                r1[r3] = r4
                if (r3 != r7) goto L20
                java.lang.String r6 = new java.lang.String
                r6.<init>(r1, r2)
                return r6
            L20:
                int r6 = r6 + 1
                r4 = r0[r6]
                int r3 = r3 + 1
                r5 = r8
                r8 = r6
                r6 = r4
                r4 = r3
                r3 = r0
                r0 = r5
            L2c:
                int r6 = -r6
                int r6 = r6 + r0
                r0 = r8
                r8 = r6
                r6 = r0
                r0 = r3
                r3 = r4
                goto L15
            */
            throw new UnsupportedOperationException("Method not decompiled: com.facetec.sdk.cx.AnonymousClass2.$$g(short, byte, byte):java.lang.String");
        }

        static {
            init$2();
            $10 = 0;
            $11 = 1;
            init$1();
            init$0();
            f = 0;
            h = 1;
            d = new char[]{8455, 8692, 8450, 8688, 8693, 8463, 8500, 8449, 8690, 8451, 8481, 8702, 8461, 8470, 8457, 8468, 8459, 8501, 8694, 8518, 8458, 8689, 8552, 8467, 8466, 8492, 8523, 8510, 8504, 8700, 8453, 8703};
            a = 1071522150;
            b = true;
            e = true;
            f95860g = new int[]{-995965728, 1422350327, 1019924656, -1328232332, 303303001, 2083141325, 674771060, -1509124097, -1779409056, 679632324, 814008844, -1907475879, -1713545544, 1005243146, -1005308373, -95113984, -993065253, 1718921986};
        }

        /* JADX WARN: Code restructure failed: missing block: B:92:0x0942, code lost:
        
            r37.close();
         */
        /* JADX WARN: Multi-variable type inference failed */
        /* JADX WARN: Removed duplicated region for block: B:103:0x09ea A[Catch: all -> 0x09d9, Exception -> 0x0bd1, TryCatch #22 {Exception -> 0x0bd1, blocks: (B:101:0x09dc, B:103:0x09ea, B:104:0x0a2c, B:106:0x0a42, B:107:0x0a80, B:140:0x0b8f, B:145:0x0b97, B:147:0x0b9e, B:148:0x0b9f, B:155:0x0bae, B:157:0x0bb4, B:158:0x0bb5, B:160:0x0bbe, B:162:0x0bc4, B:163:0x0bc5, B:164:0x0bc6, B:166:0x0bcc, B:167:0x0bcd), top: B:300:0x09dc }] */
        /* JADX WARN: Removed duplicated region for block: B:106:0x0a42 A[Catch: all -> 0x09d9, Exception -> 0x0bd1, TryCatch #22 {Exception -> 0x0bd1, blocks: (B:101:0x09dc, B:103:0x09ea, B:104:0x0a2c, B:106:0x0a42, B:107:0x0a80, B:140:0x0b8f, B:145:0x0b97, B:147:0x0b9e, B:148:0x0b9f, B:155:0x0bae, B:157:0x0bb4, B:158:0x0bb5, B:160:0x0bbe, B:162:0x0bc4, B:163:0x0bc5, B:164:0x0bc6, B:166:0x0bcc, B:167:0x0bcd), top: B:300:0x09dc }] */
        /* JADX WARN: Removed duplicated region for block: B:110:0x0ab5 A[Catch: all -> 0x09d9, IOException -> 0x0c43, TryCatch #14 {IOException -> 0x0c43, blocks: (B:108:0x0a91, B:110:0x0ab5, B:112:0x0adf, B:114:0x0afd, B:116:0x0b18, B:118:0x0b41, B:169:0x0bd1, B:170:0x0c36), top: B:287:0x0a91 }] */
        /* JADX WARN: Removed duplicated region for block: B:157:0x0bb4 A[Catch: all -> 0x09d9, Exception -> 0x0bd1, TryCatch #22 {Exception -> 0x0bd1, blocks: (B:101:0x09dc, B:103:0x09ea, B:104:0x0a2c, B:106:0x0a42, B:107:0x0a80, B:140:0x0b8f, B:145:0x0b97, B:147:0x0b9e, B:148:0x0b9f, B:155:0x0bae, B:157:0x0bb4, B:158:0x0bb5, B:160:0x0bbe, B:162:0x0bc4, B:163:0x0bc5, B:164:0x0bc6, B:166:0x0bcc, B:167:0x0bcd), top: B:300:0x09dc }] */
        /* JADX WARN: Removed duplicated region for block: B:158:0x0bb5 A[Catch: all -> 0x09d9, Exception -> 0x0bd1, TryCatch #22 {Exception -> 0x0bd1, blocks: (B:101:0x09dc, B:103:0x09ea, B:104:0x0a2c, B:106:0x0a42, B:107:0x0a80, B:140:0x0b8f, B:145:0x0b97, B:147:0x0b9e, B:148:0x0b9f, B:155:0x0bae, B:157:0x0bb4, B:158:0x0bb5, B:160:0x0bbe, B:162:0x0bc4, B:163:0x0bc5, B:164:0x0bc6, B:166:0x0bcc, B:167:0x0bcd), top: B:300:0x09dc }] */
        /* JADX WARN: Removed duplicated region for block: B:208:0x110a A[PHI: r3
          0x110a: PHI (r3v43 java.lang.String[]) = (r3v42 java.lang.String[]), (r3v42 java.lang.String[]), (r3v50 java.lang.String[]) binds: [B:184:0x0dcd, B:186:0x0e18, B:325:0x110a] A[DONT_GENERATE, DONT_INLINE]] */
        /* JADX WARN: Removed duplicated region for block: B:24:0x03b5  */
        /* JADX WARN: Removed duplicated region for block: B:36:0x04e1 A[PHI: r4 r5
          0x04e1: PHI (r4v54 int) = (r4v53 int), (r4v70 int) binds: [B:23:0x03b3, B:310:0x04e1] A[DONT_GENERATE, DONT_INLINE]
          0x04e1: PHI (r5v61 int) = (r5v60 int), (r5v217 int) binds: [B:23:0x03b3, B:310:0x04e1] A[DONT_GENERATE, DONT_INLINE]] */
        /* JADX WARN: Removed duplicated region for block: B:39:0x05bb  */
        /*
            Code decompiled incorrectly, please refer to instructions dump.
            To view partially-correct code enable 'Show inconsistent code' option in preferences
        */
        public static java.lang.Object[] a(android.content.Context r57, int r58, int r59, int r60) throws java.lang.Throwable {
            /*
                Method dump skipped, instruction units count: 6716
                To view this dump change 'Code comments level' option to 'DEBUG'
            */
            throw new UnsupportedOperationException("Method not decompiled: com.facetec.sdk.cx.AnonymousClass2.a(android.content.Context, int, int, int):java.lang.Object[]");
        }

        private static void i(int[] iArr, String str, int i, String str2, Object[] objArr) throws Throwable {
            char[] charArray;
            int i2;
            char[] cArr;
            String str3 = str2;
            Object bytes = str3;
            if (str3 != null) {
                $11 = ($10 + 13) % 128;
                bytes = str3.getBytes(LocalizedMessage.DEFAULT_ENCODING);
            }
            byte[] bArr = (byte[]) bytes;
            if (str != null) {
                $10 = ($11 + 69) % 128;
                charArray = str.toCharArray();
            } else {
                charArray = str;
            }
            char[] cArr2 = charArray;
            hn hnVar = new hn();
            char[] cArr3 = d;
            Class cls = Integer.TYPE;
            int i3 = -1;
            int i4 = 0;
            if (cArr3 != null) {
                int length = cArr3.length;
                char[] cArr4 = new char[length];
                int i5 = 0;
                while (i5 < length) {
                    $11 = ($10 + 69) % 128;
                    try {
                        Object[] objArr2 = {Integer.valueOf(cArr3[i5])};
                        Object objD = an.d(-814569747);
                        if (objD == null) {
                            byte b2 = (byte) i3;
                            byte b3 = (byte) (b2 + 1);
                            objD = an.d(1803 - (KeyEvent.getMaxKeyCode() >> 16), (char) (Color.red(i4) + 9692), 24 - View.combineMeasuredStates(i4, i4), -1189907018, false, $$g(b2, b3, (byte) (b3 + 1)), new Class[]{cls});
                        }
                        cArr4[i5] = ((Character) ((Method) objD).invoke(null, objArr2)).charValue();
                        i5++;
                        i3 = -1;
                        i4 = 0;
                    } catch (Throwable th) {
                        Throwable cause = th.getCause();
                        if (cause == null) {
                            throw th;
                        }
                        throw cause;
                    }
                }
                cArr3 = cArr4;
            }
            Object[] objArr3 = {Integer.valueOf(a)};
            Object objD2 = an.d(-1578986303);
            if (objD2 == null) {
                byte b4 = (byte) (-1);
                byte b5 = (byte) (b4 + 1);
                objD2 = an.d(TextUtils.lastIndexOf("", '0', 0, 0) + 2567, (char) (ViewConfiguration.getWindowTouchSlop() >> 8), 23 - TextUtils.indexOf("", ""), -679262310, false, $$g(b4, b5, b5), new Class[]{cls});
            }
            int iIntValue = ((Integer) ((Method) objD2).invoke(null, objArr3)).intValue();
            int i6 = 717234065;
            if (e) {
                $10 = ($11 + 69) % 128;
                int length2 = bArr.length;
                hnVar.b = length2;
                char[] cArr5 = new char[length2];
                hnVar.c = 0;
                while (true) {
                    int i7 = hnVar.c;
                    int i8 = hnVar.b;
                    if (i7 >= i8) {
                        objArr[0] = new String(cArr5);
                        return;
                    }
                    int i9 = $10 + 91;
                    $11 = i9 % 128;
                    if (i9 % 2 == 0) {
                        cArr5[i7] = (char) (cArr3[bArr[i8 >>> i7] % i] / iIntValue);
                        Object[] objArr4 = {hnVar, hnVar};
                        Object objD3 = an.d(717234065);
                        if (objD3 == null) {
                            objD3 = an.d((ViewConfiguration.getMinimumFlingVelocity() >> 16) + 1970, (char) (1 - (Process.getElapsedCpuTime() > 0L ? 1 : (Process.getElapsedCpuTime() == 0L ? 0 : -1))), (ViewConfiguration.getFadingEdgeLength() >> 16) + 24, 1554107594, false, "x", new Class[]{Object.class, Object.class});
                        }
                        ((Method) objD3).invoke(null, objArr4);
                    } else {
                        cArr5[i7] = (char) (cArr3[bArr[(i8 - 1) - i7] + i] - iIntValue);
                        Object[] objArr5 = {hnVar, hnVar};
                        Object objD4 = an.d(717234065);
                        if (objD4 == null) {
                            objD4 = an.d(1971 - (Process.getElapsedCpuTime() > 0L ? 1 : (Process.getElapsedCpuTime() == 0L ? 0 : -1)), (char) (TypedValue.complexToFraction(0, SelfieScan.RECOGNITION_FAIL_RESULT, SelfieScan.RECOGNITION_FAIL_RESULT) > SelfieScan.RECOGNITION_FAIL_RESULT ? 1 : (TypedValue.complexToFraction(0, SelfieScan.RECOGNITION_FAIL_RESULT, SelfieScan.RECOGNITION_FAIL_RESULT) == SelfieScan.RECOGNITION_FAIL_RESULT ? 0 : -1)), 25 - (ViewConfiguration.getZoomControlsTimeout() > 0L ? 1 : (ViewConfiguration.getZoomControlsTimeout() == 0L ? 0 : -1)), 1554107594, false, "x", new Class[]{Object.class, Object.class});
                        }
                        ((Method) objD4).invoke(null, objArr5);
                    }
                }
            } else if (b) {
                int i10 = $10 + 57;
                $11 = i10 % 128;
                if (i10 % 2 == 0) {
                    int length3 = cArr2.length;
                    hnVar.b = length3;
                    cArr = new char[length3];
                    i2 = 0;
                } else {
                    i2 = 0;
                    int length4 = cArr2.length;
                    hnVar.b = length4;
                    cArr = new char[length4];
                }
                hnVar.c = i2;
                while (true) {
                    int i11 = hnVar.c;
                    int i12 = hnVar.b;
                    if (i11 >= i12) {
                        objArr[0] = new String(cArr);
                        return;
                    }
                    cArr[i11] = (char) (cArr3[cArr2[(i12 - 1) - i11] - i] - iIntValue);
                    Object[] objArr6 = {hnVar, hnVar};
                    Object objD5 = an.d(i6);
                    if (objD5 == null) {
                        objD5 = an.d(1969 - TextUtils.indexOf((CharSequence) "", '0'), (char) ExpandableListView.getPackedPositionGroup(0L), 23 - TextUtils.indexOf((CharSequence) "", '0'), 1554107594, false, "x", new Class[]{Object.class, Object.class});
                    }
                    ((Method) objD5).invoke(null, objArr6);
                    i6 = 717234065;
                }
            } else {
                int length5 = iArr.length;
                hnVar.b = length5;
                char[] cArr6 = new char[length5];
                hnVar.c = 0;
                while (true) {
                    int i13 = hnVar.c;
                    int i14 = hnVar.b;
                    if (i13 >= i14) {
                        objArr[0] = new String(cArr6);
                        return;
                    } else {
                        cArr6[i13] = (char) (cArr3[iArr[(i14 - 1) - i13] - i] - iIntValue);
                        hnVar.c = i13 + 1;
                    }
                }
            }
        }

        public static void init$0() {
            $$a = new byte[]{ISO7816.INS_INCREASE, ISO7816.INS_UNBLOCK_CHV, ISO7816.INS_GET_DATA, 25, -15, 8, -16, 1, 4, 3, ISO7816.INS_DECREASE_STAMPED, -55, -14, -1, -8, PassportService.SFI_DG13, -11, -8, ISO7816.INS_REHABILITATE_CHV, PSSSigner.TRAILER_IMPLICIT, 1, 61, -21, -49, -2, 2, 1, 4, 0, -21, 9, -8, -1, 35, -39, 6, -11, 1, -21, 17, 27, -39, -11, 7, -23, 19, 49, ISO7816.INS_GET_RESPONSE, 9, -15, 5, 55, ISO7816.INS_LOAD_KEY_FILE, -22, -12, PassportService.SFI_DG11, 2, -5, -3, 17, -19, -4, 5, 5, -2, -13, -7, 4, -7};
            $$b = 2;
        }

        public static void init$1() {
            $$d = new byte[]{7, 80, 121, 38};
            $$e = EnumC41897g.SDK_ASSET_ILLUSTRATION_NETWORK_SWITCH_DARK_APPEARANCE_VALUE;
        }

        public static void init$2() {
            $$c = new byte[]{46, ISOFileInfo.A1, PassportService.SFI_DG11, -87};
            $$f = 74;
        }

        private static void j(int[] iArr, int i, Object[] objArr) throws Throwable {
            int i2;
            long j;
            char c;
            char c2;
            char[] cArr;
            int[] iArr2;
            hg hgVar = new hg();
            char[] cArr2 = new char[4];
            int i3 = 2;
            char[] cArr3 = new char[iArr.length * 2];
            int[] iArr3 = f95860g;
            Class cls = Integer.TYPE;
            int i4 = -1;
            int i5 = 0;
            if (iArr3 != null) {
                int length = iArr3.length;
                i2 = 2027942060;
                int[] iArr4 = new int[length];
                int i6 = 0;
                j = 0;
                while (i6 < length) {
                    int i7 = $10 + 85;
                    int i8 = i3;
                    $11 = i7 % 128;
                    if (i7 % 2 == 0) {
                        try {
                            Object[] objArr2 = {Integer.valueOf(iArr3[i6])};
                            Object objD = an.d(2027942060);
                            if (objD == null) {
                                byte b2 = (byte) i4;
                                objD = an.d(KeyEvent.getDeadChar(i5, i5) + 617, (char) ((Process.getElapsedCpuTime() > 0L ? 1 : (Process.getElapsedCpuTime() == 0L ? 0 : -1)) - 1), 22 - ExpandableListView.getPackedPositionChild(0L), 247342071, false, $$g(b2, (byte) (b2 + 1), (byte) $$c.length), new Class[]{cls});
                            }
                            iArr4[i6] = ((Integer) ((Method) objD).invoke(null, objArr2)).intValue();
                            i6 >>>= 1;
                        } catch (Throwable th) {
                            Throwable cause = th.getCause();
                            if (cause == null) {
                                throw th;
                            }
                            throw cause;
                        }
                    } else {
                        Object[] objArr3 = {Integer.valueOf(iArr3[i6])};
                        Object objD2 = an.d(2027942060);
                        if (objD2 == null) {
                            byte b3 = (byte) (-1);
                            objD2 = an.d(617 - (ViewConfiguration.getScrollBarFadeDuration() >> 16), (char) View.resolveSize(0, 0), 23 - Color.red(0), 247342071, false, $$g(b3, (byte) (b3 + 1), (byte) $$c.length), new Class[]{cls});
                        }
                        iArr4[i6] = ((Integer) ((Method) objD2).invoke(null, objArr3)).intValue();
                        i6++;
                    }
                    i3 = i8;
                    i4 = -1;
                    i5 = 0;
                }
                iArr3 = iArr4;
            } else {
                i2 = 2027942060;
                j = 0;
            }
            int i9 = i3;
            int i10 = 16;
            int length2 = iArr3.length;
            int[] iArr5 = new int[length2];
            int[] iArr6 = f95860g;
            if (iArr6 != null) {
                $11 = ($10 + 27) % 128;
                int length3 = iArr6.length;
                int[] iArr7 = new int[length3];
                int i11 = 0;
                while (i11 < length3) {
                    Object[] objArr4 = {Integer.valueOf(iArr6[i11])};
                    Object objD3 = an.d(i2);
                    if (objD3 == null) {
                        cArr = cArr2;
                        byte b4 = (byte) (-1);
                        iArr2 = iArr6;
                        objD3 = an.d(Color.red(0) + 617, (char) TextUtils.indexOf("", "", 0, 0), (Process.getElapsedCpuTime() > j ? 1 : (Process.getElapsedCpuTime() == j ? 0 : -1)) + 22, 247342071, false, $$g(b4, (byte) (b4 + 1), (byte) $$c.length), new Class[]{cls});
                    } else {
                        cArr = cArr2;
                        iArr2 = iArr6;
                    }
                    iArr7[i11] = ((Integer) ((Method) objD3).invoke(null, objArr4)).intValue();
                    i11++;
                    cArr2 = cArr;
                    iArr6 = iArr2;
                }
                iArr6 = iArr7;
            }
            char[] cArr4 = cArr2;
            System.arraycopy(iArr6, 0, iArr5, 0, length2);
            hgVar.c = 0;
            while (true) {
                int i12 = hgVar.c;
                if (i12 >= iArr.length) {
                    objArr[0] = new String(cArr3, 0, i);
                    return;
                }
                $10 = ($11 + 105) % 128;
                int i13 = iArr[i12];
                char c3 = (char) (i13 >> 16);
                cArr4[0] = c3;
                char c4 = (char) i13;
                char c5 = 1;
                cArr4[1] = c4;
                char c6 = (char) (iArr[i12 + 1] >> 16);
                cArr4[i9] = c6;
                char c7 = (char) iArr[i12 + 1];
                char c8 = 3;
                cArr4[3] = c7;
                hgVar.d = (c3 << 16) + c4;
                hgVar.a = (c6 << 16) + c7;
                hg.a(iArr5);
                int i14 = 0;
                while (i14 < i10) {
                    int i15 = $11 + 119;
                    $10 = i15 % 128;
                    if (i15 % 2 != 0) {
                        int i16 = hgVar.d ^ iArr5[i14];
                        hgVar.d = i16;
                        int iB = hg.b(i16);
                        Object[] objArr5 = new Object[4];
                        objArr5[c8] = hgVar;
                        objArr5[i9] = hgVar;
                        objArr5[c5] = Integer.valueOf(iB);
                        objArr5[0] = hgVar;
                        Object objD4 = an.d(-1264699187);
                        if (objD4 == null) {
                            byte b5 = (byte) (-1);
                            byte b6 = (byte) (b5 + 1);
                            objD4 = an.d(1606 - AndroidCharacter.getMirror('0'), (char) (TextUtils.getTrimmedLength("") + 63317), 33 - (Process.getElapsedCpuTime() > j ? 1 : (Process.getElapsedCpuTime() == j ? 0 : -1)), -1023415402, false, $$g(b5, b6, (byte) (b6 + 2)), new Class[]{Object.class, cls, Object.class, Object.class});
                        }
                        int iIntValue = ((Integer) ((Method) objD4).invoke(null, objArr5)).intValue();
                        hgVar.d = hgVar.a;
                        hgVar.a = iIntValue;
                        i14 += 57;
                    } else {
                        int i17 = hgVar.d ^ iArr5[i14];
                        hgVar.d = i17;
                        int iB2 = hg.b(i17);
                        Object[] objArr6 = new Object[4];
                        objArr6[c8] = hgVar;
                        objArr6[i9] = hgVar;
                        objArr6[c5] = Integer.valueOf(iB2);
                        objArr6[0] = hgVar;
                        Object objD5 = an.d(-1264699187);
                        if (objD5 == null) {
                            byte b7 = (byte) (-1);
                            c = c5;
                            byte b8 = (byte) (b7 + 1);
                            c2 = c8;
                            objD5 = an.d(Color.blue(0) + 1558, (char) (63318 - (SystemClock.uptimeMillis() > j ? 1 : (SystemClock.uptimeMillis() == j ? 0 : -1))), 32 - (CdmaCellLocation.convertQuartSecToDecDegrees(0) > 0.0d ? 1 : (CdmaCellLocation.convertQuartSecToDecDegrees(0) == 0.0d ? 0 : -1)), -1023415402, false, $$g(b7, b8, (byte) (b8 + 2)), new Class[]{Object.class, cls, Object.class, Object.class});
                        } else {
                            c = c5;
                            c2 = c8;
                        }
                        int iIntValue2 = ((Integer) ((Method) objD5).invoke(null, objArr6)).intValue();
                        hgVar.d = hgVar.a;
                        hgVar.a = iIntValue2;
                        i14++;
                        c5 = c;
                        c8 = c2;
                    }
                    i10 = 16;
                }
                char c9 = c5;
                char c10 = c8;
                int i18 = hgVar.d;
                int i19 = hgVar.a;
                hgVar.d = i19;
                hgVar.a = i18;
                int i20 = i18 ^ iArr5[16];
                hgVar.a = i20;
                int i21 = i19 ^ iArr5[17];
                hgVar.d = i21;
                cArr4[0] = (char) (i21 >>> 16);
                cArr4[c9] = (char) i21;
                cArr4[i9] = (char) (i20 >>> 16);
                cArr4[c10] = (char) i20;
                hg.a(iArr5);
                int i22 = hgVar.c;
                cArr3[i22 * 2] = cArr4[0];
                cArr3[(i22 * 2) + 1] = cArr4[c9];
                cArr3[(i22 * 2) + 2] = cArr4[i9];
                cArr3[(i22 * 2) + 3] = cArr4[c10];
                int i23 = i9;
                Object[] objArr7 = new Object[i23];
                objArr7[c9] = hgVar;
                objArr7[0] = hgVar;
                Object objD6 = an.d(-204410541);
                if (objD6 == null) {
                    i10 = 16;
                    objD6 = an.d((ViewConfiguration.getKeyRepeatTimeout() >> 16) + EnumC41897g.SDK_ASSET_PLAID_LOGO_LOADING_INDICATOR_SUCCESS_VALUE, (char) (MotionEvent.axisFromString("") + 1), 23 - TextUtils.getOffsetBefore("", 0), -2051988984, false, "A", new Class[]{Object.class, Object.class});
                } else {
                    i10 = 16;
                }
                ((Method) objD6).invoke(null, objArr7);
                i9 = i23;
            }
        }

        /* JADX WARN: Removed duplicated region for block: B:10:0x0022  */
        /* JADX WARN: Removed duplicated region for block: B:8:0x001a  */
        /* JADX WARN: Unsupported multi-entry loop pattern (BACK_EDGE: B:10:0x0022 -> B:11:0x0026). Please report as a decompilation issue!!! */
        /*
            Code decompiled incorrectly, please refer to instructions dump.
            To view partially-correct code enable 'Show inconsistent code' option in preferences
        */
        private static void k(short r5, int r6, short r7, java.lang.Object[] r8) {
            /*
                int r7 = r7 + 4
                int r0 = 34 - r5
                byte[] r1 = com.facetec.sdk.cx.AnonymousClass2.$$a
                int r6 = r6 * 3
                int r6 = r6 + 97
                byte[] r0 = new byte[r0]
                int r5 = 33 - r5
                r2 = 0
                if (r1 != 0) goto L14
                r4 = r5
                r3 = r2
                goto L26
            L14:
                r3 = r2
            L15:
                byte r4 = (byte) r6
                r0[r3] = r4
                if (r3 != r5) goto L22
                java.lang.String r5 = new java.lang.String
                r5.<init>(r0, r2)
                r8[r2] = r5
                return
            L22:
                int r3 = r3 + 1
                r4 = r1[r7]
            L26:
                int r4 = -r4
                int r7 = r7 + 1
                int r6 = r6 + r4
                int r6 = r6 + (-2)
                goto L15
            */
            throw new UnsupportedOperationException("Method not decompiled: com.facetec.sdk.cx.AnonymousClass2.k(short, int, short, java.lang.Object[]):void");
        }

        /* JADX WARN: Removed duplicated region for block: B:10:0x0024  */
        /* JADX WARN: Removed duplicated region for block: B:8:0x001c  */
        /* JADX WARN: Unsupported multi-entry loop pattern (BACK_EDGE: B:10:0x0024 -> B:11:0x002d). Please report as a decompilation issue!!! */
        /*
            Code decompiled incorrectly, please refer to instructions dump.
            To view partially-correct code enable 'Show inconsistent code' option in preferences
        */
        private static void l(short r6, short r7, byte r8, java.lang.Object[] r9) {
            /*
                int r8 = r8 * 3
                int r8 = 4 - r8
                byte[] r0 = com.facetec.sdk.cx.AnonymousClass2.$$d
                int r6 = r6 + 97
                int r7 = r7 * 3
                int r1 = r7 + 1
                byte[] r1 = new byte[r1]
                r2 = 0
                if (r0 != 0) goto L16
                r6 = r7
                r3 = r0
                r4 = r2
                r0 = r8
                goto L2d
            L16:
                r3 = r2
            L17:
                byte r4 = (byte) r6
                r1[r3] = r4
                if (r3 != r7) goto L24
                java.lang.String r6 = new java.lang.String
                r6.<init>(r1, r2)
                r9[r2] = r6
                return
            L24:
                int r3 = r3 + 1
                r4 = r0[r8]
                r5 = r0
                r0 = r8
                r8 = r4
                r4 = r3
                r3 = r5
            L2d:
                int r6 = r6 + r8
                int r8 = r0 + 1
                r0 = r3
                r3 = r4
                goto L17
            */
            throw new UnsupportedOperationException("Method not decompiled: com.facetec.sdk.cx.AnonymousClass2.l(short, short, byte, java.lang.Object[]):void");
        }

        @Override // android.view.ViewTreeObserver.OnGlobalLayoutListener
        public void onGlobalLayout() {
            int i = f;
            int i2 = i + 125;
            h = i2 % 128;
            if (i2 % 2 == 0) {
                boolean z = cx.this.f95859g;
                throw null;
            }
            cx cxVar = cx.this;
            if (cxVar.f95859g) {
                int i3 = i + 85;
                h = i3 % 128;
                if (i3 % 2 == 0) {
                    throw null;
                }
                return;
            }
            cxVar.f95859g = true;
            cxVar.c();
            float fB = dm.b();
            float fC = dm.c();
            int iIntValue = ((Integer) dm.e(pg.a.a(), pg.a.a(), 1933108801, new Object[0], pg.a.a(), -1933108792, pg.a.a())).intValue();
            int iA = (int) (bh.a(35) * fC * fB);
            float f2 = iIntValue / 2.0f;
            int iRound = Math.round(f2);
            int iRound2 = Math.round(f2);
            RelativeLayout.LayoutParams layoutParams = (RelativeLayout.LayoutParams) cx.this.f.getLayoutParams();
            layoutParams.setMargins(iRound, iRound, 0, 0);
            layoutParams.setMarginStart(iRound);
            layoutParams.setMarginEnd(iRound);
            cx.this.f.setLayoutParams(layoutParams);
            cx.this.f.setPadding(iRound2, iRound2, iRound2, iRound2);
            cx.this.f.getLayoutParams().height = iA;
            cx.this.f.getLayoutParams().width = iA;
            cx.this.f.requestLayout();
        }
    };

    /* JADX INFO: renamed from: com.facetec.sdk.cx$4, reason: invalid class name */
    public class AnonymousClass4 extends Animatable2Compat$AnimationCallback {
        public AnonymousClass4() {
        }

        /* JADX INFO: Access modifiers changed from: private */
        public /* synthetic */ void e() {
            dq.a(cx.this.a);
        }

        @Override // androidx.vectordrawable.graphics.drawable.Animatable2Compat$AnimationCallback
        public final void onAnimationEnd(Drawable drawable) {
            cx.this.c(new Runnable() { // from class: com.facetec.sdk.凤史
                @Override // java.lang.Runnable
                public final void run() {
                    this.f7140.e();
                }
            });
        }
    }

    /* JADX INFO: renamed from: com.facetec.sdk.cx$5, reason: invalid class name */
    public static /* synthetic */ class AnonymousClass5 {
        static final /* synthetic */ int[] c;
        static final /* synthetic */ int[] d;
        static final /* synthetic */ int[] e;

        static {
            int[] iArr = new int[d.values().length];
            c = iArr;
            try {
                iArr[d.DEFAULT.ordinal()] = 1;
            } catch (NoSuchFieldError unused) {
            }
            try {
                c[d.FRONT_SIDE.ordinal()] = 2;
            } catch (NoSuchFieldError unused2) {
            }
            try {
                c[d.BACK_SIDE.ordinal()] = 3;
            } catch (NoSuchFieldError unused3) {
            }
            try {
                c[d.USER_CONFIRMED_INFO.ordinal()] = 4;
            } catch (NoSuchFieldError unused4) {
            }
            try {
                c[d.NFC.ordinal()] = 5;
            } catch (NoSuchFieldError unused5) {
            }
            try {
                c[d.SKIPPED_NFC.ordinal()] = 6;
            } catch (NoSuchFieldError unused6) {
            }
            int[] iArr2 = new int[a.values().length];
            e = iArr2;
            try {
                iArr2[a.UPLOAD_STARTED.ordinal()] = 1;
            } catch (NoSuchFieldError unused7) {
            }
            try {
                e[a.STILL_UPLOADING.ordinal()] = 2;
            } catch (NoSuchFieldError unused8) {
            }
            try {
                e[a.UPLOAD_COMPLETE_AWAITING_RESPONSE.ordinal()] = 3;
            } catch (NoSuchFieldError unused9) {
            }
            try {
                e[a.UPLOAD_COMPLETE_AWAITING_PROCESSING.ordinal()] = 4;
            } catch (NoSuchFieldError unused10) {
            }
            int[] iArr3 = new int[FaceTecCancelButtonCustomization.ButtonLocation.values().length];
            d = iArr3;
            try {
                iArr3[FaceTecCancelButtonCustomization.ButtonLocation.TOP_LEFT.ordinal()] = 1;
            } catch (NoSuchFieldError unused11) {
            }
            try {
                d[FaceTecCancelButtonCustomization.ButtonLocation.TOP_RIGHT.ordinal()] = 2;
            } catch (NoSuchFieldError unused12) {
            }
            try {
                d[FaceTecCancelButtonCustomization.ButtonLocation.CUSTOM.ordinal()] = 3;
            } catch (NoSuchFieldError unused13) {
            }
            try {
                d[FaceTecCancelButtonCustomization.ButtonLocation.DISABLED.ordinal()] = 4;
            } catch (NoSuchFieldError unused14) {
            }
        }
    }

    public enum a {
        UPLOAD_STARTED,
        STILL_UPLOADING,
        UPLOAD_COMPLETE_AWAITING_RESPONSE,
        UPLOAD_COMPLETE_AWAITING_PROCESSING
    }

    public enum d {
        DEFAULT,
        FRONT_SIDE,
        BACK_SIDE,
        USER_CONFIRMED_INFO,
        NFC,
        SKIPPED_NFC
    }

    /* JADX WARN: Removed duplicated region for block: B:10:0x0024  */
    /* JADX WARN: Removed duplicated region for block: B:8:0x001e  */
    /* JADX WARN: Unsupported multi-entry loop pattern (BACK_EDGE: B:10:0x0024 -> B:11:0x002c). Please report as a decompilation issue!!! */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    private static java.lang.String $$c(byte r6, int r7, int r8) {
        /*
            int r6 = r6 * 2
            int r6 = 1 - r6
            int r8 = r8 * 2
            int r8 = 4 - r8
            byte[] r0 = com.facetec.sdk.cx.$$a
            int r7 = 100 - r7
            byte[] r1 = new byte[r6]
            r2 = 0
            if (r0 != 0) goto L16
            r3 = r0
            r4 = r2
            r0 = r8
            r8 = r6
            goto L2c
        L16:
            r3 = r2
        L17:
            byte r4 = (byte) r7
            r1[r3] = r4
            int r3 = r3 + 1
            if (r3 != r6) goto L24
            java.lang.String r6 = new java.lang.String
            r6.<init>(r1, r2)
            return r6
        L24:
            r4 = r0[r8]
            r5 = r8
            r8 = r7
            r7 = r4
            r4 = r3
            r3 = r0
            r0 = r5
        L2c:
            int r7 = -r7
            int r7 = r7 + r8
            int r8 = r0 + 1
            r0 = r3
            r3 = r4
            goto L17
        */
        throw new UnsupportedOperationException("Method not decompiled: com.facetec.sdk.cx.$$c(byte, int, int):java.lang.String");
    }

    static {
        init$0();
        G = 6833914658491885484L;
    }

    /* JADX WARN: Removed duplicated region for block: B:32:0x0132  */
    /* JADX WARN: Removed duplicated region for block: B:33:0x0133  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    private static void E(java.lang.String r21, int r22, java.lang.Object[] r23) throws java.lang.Throwable {
        /*
            Method dump skipped, instruction units count: 316
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: com.facetec.sdk.cx.E(java.lang.String, int, java.lang.Object[]):void");
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ boolean a(View view, MotionEvent motionEvent) {
        if (motionEvent.getAction() == 0) {
            this.f.setAlpha(0.4f);
        } else if (motionEvent.getAction() == 3 || motionEvent.getX() < SelfieScan.RECOGNITION_FAIL_RESULT || motionEvent.getX() > this.f.getWidth() + this.f.getLeft() + 10 || motionEvent.getY() < SelfieScan.RECOGNITION_FAIL_RESULT || motionEvent.getY() > this.f.getHeight() + this.f.getTop() + 10) {
            this.f.setAlpha(1.0f);
        } else if (motionEvent.getAction() == 1) {
            this.f.setAlpha(1.0f);
            this.f.performClick();
        }
        return true;
    }

    @NonNull
    public static cx b(boolean z, d dVar) {
        cx cxVar = new cx();
        Bundle bundle = new Bundle();
        bundle.putBoolean("isIDScan", z);
        bundle.putSerializable("uploadType", dVar);
        cxVar.setArguments(bundle);
        return cxVar;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void d(View view) throws Throwable {
        ((FaceTecSessionActivity) getActivity()).o();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void f() {
        dq.c(this.a, R.drawable.facetec_animated_activity_indicator_vector_drawable, null, true);
        this.a.setColorFilter(dm.U(), PorterDuff.Mode.SRC_IN);
        this.a.setVisibility(0);
    }

    private void g() {
        this.v.removeCallbacks(this.I);
        this.C.removeCallbacksAndMessages(null);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void h(final au.c cVar) {
        ObjectAnimator objectAnimator = this.p;
        if (objectAnimator != null) {
            objectAnimator.end();
            this.p = null;
        }
        ProgressBar progressBar = this.m;
        ObjectAnimator objectAnimatorOfInt = ObjectAnimator.ofInt(progressBar, "progress", progressBar.getProgress(), this.m.getMax());
        objectAnimatorOfInt.setDuration(500L);
        objectAnimatorOfInt.addListener(new f() { // from class: com.facetec.sdk.兵药
            @Override // android.animation.Animator.AnimatorListener
            public final void onAnimationEnd(Animator animator) {
                cx.d(cVar, animator);
            }
        });
        objectAnimatorOfInt.start();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void i() throws Throwable {
        this.A = a.UPLOAD_COMPLETE_AWAITING_RESPONSE;
        e(new au.c(new Runnable() { // from class: com.facetec.sdk.兵神
            @Override // java.lang.Runnable
            public final void run() throws Throwable {
                this.f7097.n();
            }
        }));
    }

    public static void init$0() {
        $$a = new byte[]{126, 1, 26, -71};
        $$b = EnumC41897g.SDK_ASSET_ILLUSTRATION_PLAID_OVERLAY_PERSON_VALUE;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void j() {
        if (this.w) {
            return;
        }
        this.C.removeCallbacksAndMessages(null);
        this.C.postDelayed(new au.c(new Runnable() { // from class: com.facetec.sdk.兵符
            @Override // java.lang.Runnable
            public final void run() throws Throwable {
                this.f7102.i();
            }
        }), 500L);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void k() {
        this.h.setText(c(this.A, this.B));
        this.h.animate().alpha(1.0f).setDuration(500L).setListener(null).start();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void l() throws Throwable {
        if (this.w) {
            return;
        }
        this.C.removeCallbacksAndMessages(null);
        this.A = a.STILL_UPLOADING;
        c(true);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void m() throws Throwable {
        this.C.removeCallbacksAndMessages(null);
        if (this.w) {
            return;
        }
        this.A = a.UPLOAD_COMPLETE_AWAITING_PROCESSING;
        c(true);
        this.C.postDelayed(new au.c(new Runnable() { // from class: com.facetec.sdk.兵星
            @Override // java.lang.Runnable
            public final void run() {
                this.f7083.h();
            }
        }), 1000L);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void n() throws Throwable {
        if (this.C == null || this.w) {
            return;
        }
        c(true);
        a();
        this.C.postDelayed(new au.c(new Runnable() { // from class: com.facetec.sdk.兵雨
            @Override // java.lang.Runnable
            public final void run() throws Throwable {
                this.f7107.m();
            }
        }), 3000L);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void o(Runnable runnable) {
        a(new au.c(runnable));
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void p() {
        this.k.animate().alpha(1.0f).setDuration(500L).setStartDelay(0L).setInterpolator(new DecelerateInterpolator()).setListener(null).start();
        this.q.animate().alpha(1.0f).setDuration(500L).setStartDelay(0L).setInterpolator(new DecelerateInterpolator()).setListener(null).start();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void q() throws Throwable {
        if (this.w) {
            return;
        }
        this.C.removeCallbacksAndMessages(null);
        this.A = a.UPLOAD_STARTED;
        c(false);
        this.C.postDelayed(new au.c(new Runnable() { // from class: com.facetec.sdk.兵鬼
            @Override // java.lang.Runnable
            public final void run() throws Throwable {
                this.f7112.l();
            }
        }), this.u ? 8000L : 6000L);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void r() {
        FaceTecSessionActivity faceTecSessionActivity = (FaceTecSessionActivity) getActivity();
        if (faceTecSessionActivity != null) {
            faceTecSessionActivity.s.c();
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void s() {
        bm bmVar = (bm) getActivity();
        if (bmVar != null) {
            bmVar.r();
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void t() {
        ProgressBar progressBar = this.m;
        ObjectAnimator objectAnimatorOfInt = ObjectAnimator.ofInt(progressBar, "progress", progressBar.getProgress(), AuthApiStatusCodes.AUTH_API_INVALID_CREDENTIALS);
        this.p = objectAnimatorOfInt;
        objectAnimatorOfInt.setDuration(3000L);
        this.p.start();
    }

    public final void c() {
        ImageView imageView = this.f;
        if (imageView != null) {
            imageView.getViewTreeObserver().removeOnGlobalLayoutListener(this.F);
        }
        this.F = null;
    }

    public final RelativeLayout e() {
        return this.r;
    }

    @Override // com.facetec.sdk.au, android.app.Fragment
    public final void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        Handler handler = new Handler();
        this.v = handler;
        handler.postDelayed(this.I, 600000L);
    }

    @Override // android.app.Fragment
    public final View onCreateView(LayoutInflater layoutInflater, ViewGroup viewGroup, Bundle bundle) {
        return layoutInflater.inflate(R.layout.facetec_results_fragment, viewGroup, false);
    }

    @Override // android.app.Fragment
    public final void onDestroy() {
        super.onDestroy();
        c();
    }

    @Override // android.app.Fragment
    public final void onViewCreated(View view, Bundle bundle) throws Throwable {
        super.onViewCreated(view, bundle);
        this.u = getArguments().getBoolean("isIDScan");
        this.B = (d) getArguments().get("uploadType");
        this.A = a.UPLOAD_STARTED;
        this.a = (ImageView) view.findViewById(R.id.activityIndicatorImageView);
        this.m = (ProgressBar) view.findViewById(R.id.uploadProgressBar);
        this.h = (TextView) view.findViewById(R.id.progressTextView);
        this.o = (TextView) view.findViewById(R.id.resultTextView);
        this.j = view.findViewById(R.id.zoomResultBackground);
        this.r = (RelativeLayout) view.findViewById(R.id.progressBarLayout);
        this.d = (RelativeLayout) view.findViewById(R.id.zoomResultLayout);
        this.k = (RelativeLayout) view.findViewById(R.id.zoomResultContainer);
        this.l = (ImageView) view.findViewById(R.id.resultAnimationBackground);
        this.n = (ImageView) view.findViewById(R.id.resultAnimationForeground);
        this.q = (LinearLayout) view.findViewById(R.id.devModeTagLayout);
        this.t = (TextView) view.findViewById(R.id.devModeTagTextView);
        this.s = (ImageView) view.findViewById(R.id.devModeTagImageView);
        this.b = (ImageView) view.findViewById(R.id.nfcIcon);
        this.c = (TextView) view.findViewById(R.id.nfcStatus);
        this.e = (RelativeLayout) view.findViewById(R.id.nfcLayout);
        this.f = (ImageView) view.findViewById(R.id.nfcBackButton);
        t.e(ov.b.AnonymousClass1.e(), new Object[]{getActivity(), c.RESULT_SCREEN_SHOWN, this.B}, ov.b.AnonymousClass1.e(), ov.b.AnonymousClass1.e(), 1706766979, -1706766974, ov.b.AnonymousClass1.e());
        if (b()) {
            this.f.setEnabled(true);
            if (FaceTecSDK.d.m.b != FaceTecCancelButtonCustomization.ButtonLocation.DISABLED) {
                this.f.setImageDrawable(C6852.getDrawable(getActivity(), dm.aQ()));
            }
            int i = AnonymousClass5.d[FaceTecSDK.d.m.b.ordinal()];
            if (i == 2) {
                RelativeLayout.LayoutParams layoutParams = (RelativeLayout.LayoutParams) this.f.getLayoutParams();
                layoutParams.removeRule(20);
                layoutParams.addRule(21);
                this.f.setLayoutParams(layoutParams);
            } else if (i == 3 || i == 4) {
                this.f.setVisibility(8);
            }
            this.f.getViewTreeObserver().addOnGlobalLayoutListener(this.F);
            this.f.setOnClickListener(new View.OnClickListener() { // from class: com.facetec.sdk.兵木
                @Override // android.view.View.OnClickListener
                public final void onClick(View view2) throws Throwable {
                    this.f7085.d(view2);
                }
            });
            this.f.setOnTouchListener(new View.OnTouchListener() { // from class: com.facetec.sdk.兵梦
                @Override // android.view.View.OnTouchListener
                public final boolean onTouch(View view2, MotionEvent motionEvent) {
                    return this.f7086.a(view2, motionEvent);
                }
            });
        }
        if (bk.b() && FaceTecSDK.d.d && !getActivity().getPackageName().contains("com.facetec.zoomlogin") && !getActivity().getPackageName().contains("om.facetec.photoidmatchtester")) {
            float fB = dm.b() * dm.c();
            this.t.setTypeface(FaceTecSDK.d.f95813g.messageFont);
            this.t.setTextSize(2, 14.0f * fB);
            dm.d(this.t);
            this.s.setColorFilter(dm.S(), PorterDuff.Mode.SRC_IN);
            this.s.getLayoutParams().height = (int) (bh.a(18) * fB);
            this.s.getLayoutParams().width = (int) (bh.a(18) * fB);
            RelativeLayout.LayoutParams layoutParams2 = (RelativeLayout.LayoutParams) this.q.getLayoutParams();
            ((ViewGroup.MarginLayoutParams) layoutParams2).bottomMargin = ((Integer) dm.e(pg.a.a(), pg.a.a(), 1933108801, new Object[0], pg.a.a(), -1933108792, pg.a.a())).intValue();
            ((ViewGroup.LayoutParams) layoutParams2).height = (int) (bh.a(26) * fB);
            this.q.setLayoutParams(layoutParams2);
            this.q.requestLayout();
            this.q.setOnClickListener(new View.OnClickListener() { // from class: com.facetec.sdk.兵气
                @Override // android.view.View.OnClickListener
                public final void onClick(View view2) {
                    this.f7087.c(view2);
                }
            });
            this.q.setOnTouchListener(new View.OnTouchListener() { // from class: com.facetec.sdk.兵水
                @Override // android.view.View.OnTouchListener
                public final boolean onTouch(View view2, MotionEvent motionEvent) {
                    return this.f7088.e(view2, motionEvent);
                }
            });
            this.q.setVisibility(0);
        }
        dm.j(this.j);
        if (!this.u) {
            this.j.getBackground().setAlpha(((Integer) dm.e(pg.a.a(), pg.a.a(), -298147150, new Object[0], pg.a.a(), 298147185, pg.a.a())).intValue());
        }
        float fB2 = dm.b() * dm.c();
        float fBo = dm.bo();
        int iIntValue = ((Integer) dm.e(pg.a.a(), pg.a.a(), 1933108801, new Object[0], pg.a.a(), -1933108792, pg.a.a())).intValue();
        int iRound = Math.round(bh.a(80) * fBo * fB2);
        int iRound2 = Math.round(bh.a(130) * fB2);
        int iRound3 = Math.round(bh.a(-55) * fB2);
        int iRound4 = Math.round(bh.a(6) * fB2);
        int iRound5 = Math.round(bh.a(50) * fB2);
        e eVar = (e) view.findViewById(R.id.nfcSkipButton);
        this.i = eVar;
        eVar.c();
        this.i.setText(dp.a(R.string.FaceTec_action_skip_nfc));
        this.i.setEnabled(false);
        this.i.c(new au.c(new Runnable() { // from class: com.facetec.sdk.兵海
            @Override // java.lang.Runnable
            public final void run() {
                this.f7089.r();
            }
        }));
        RelativeLayout.LayoutParams layoutParams3 = (RelativeLayout.LayoutParams) this.i.getLayoutParams();
        ((ViewGroup.LayoutParams) layoutParams3).height = iRound5;
        layoutParams3.setMargins(iIntValue, 0, iIntValue, iIntValue);
        this.i.setLayoutParams(layoutParams3);
        this.k.setTranslationY(iRound3);
        FrameLayout frameLayout = (FrameLayout) view.findViewById(R.id.resultFrame);
        frameLayout.getLayoutParams().height = iRound;
        frameLayout.getLayoutParams().width = iRound;
        this.b.getLayoutParams().height = iRound2;
        LayerDrawable layerDrawable = (LayerDrawable) getResources().getDrawable(R.drawable.facetec_progress_bar);
        layerDrawable.mutate();
        Drawable drawable = layerDrawable.getDrawable(0);
        LayerDrawable layerDrawable2 = (LayerDrawable) ((ScaleDrawable) layerDrawable.getDrawable(1)).getDrawable();
        Drawable drawableFindDrawableByLayerId = layerDrawable2.findDrawableByLayerId(R.id.progressFill);
        Drawable drawableFindDrawableByLayerId2 = layerDrawable2.findDrawableByLayerId(R.id.progressGlow);
        float f = iRound4 / 2.0f;
        ((GradientDrawable) drawable).setCornerRadius(f);
        ((GradientDrawable) drawableFindDrawableByLayerId).setCornerRadius(f);
        ((GradientDrawable) drawableFindDrawableByLayerId2).setCornerRadius(f);
        dm.c(this.m, drawable);
        dm.c(this.m, drawableFindDrawableByLayerId, drawableFindDrawableByLayerId2);
        this.m.setProgressDrawable(layerDrawable);
        LinearLayout.LayoutParams layoutParams4 = (LinearLayout.LayoutParams) this.m.getLayoutParams();
        ((ViewGroup.LayoutParams) layoutParams4).height = iRound4;
        ((ViewGroup.MarginLayoutParams) layoutParams4).topMargin = iIntValue;
        this.m.setLayoutParams(layoutParams4);
        this.m.setVisibility(0);
        dm.d(this.h);
        dm.d(this.o);
        dm.d(this.c);
        this.h.setTypeface(FaceTecSDK.d.f95813g.messageFont);
        this.o.setTypeface(FaceTecSDK.d.f95813g.messageFont);
        this.c.setTypeface(FaceTecSDK.d.f95813g.messageFont);
        if (this.u) {
            this.h.setText(c(this.A, this.B));
        } else {
            dp.e(this.h, R.string.FaceTec_result_facescan_upload_message);
            this.o.setImportantForAccessibility(1);
            this.h.setImportantForAccessibility(1);
            TextView textView = this.h;
            textView.setContentDescription(textView.getText().toString());
            this.h.performAccessibilityAction(64, null);
            this.h.sendAccessibilityEvent(8);
        }
        float f2 = fB2 * 24.0f;
        this.h.setTextSize(2, f2);
        this.c.setTextSize(2, f2);
        this.o.setTextSize(2, f2);
        LinearLayout.LayoutParams layoutParams5 = (LinearLayout.LayoutParams) this.h.getLayoutParams();
        ((ViewGroup.MarginLayoutParams) layoutParams5).topMargin = iIntValue;
        ((ViewGroup.MarginLayoutParams) layoutParams5).leftMargin = iIntValue;
        ((ViewGroup.MarginLayoutParams) layoutParams5).rightMargin = iIntValue;
        this.h.setLayoutParams(layoutParams5);
        LinearLayout.LayoutParams layoutParams6 = (LinearLayout.LayoutParams) this.o.getLayoutParams();
        ((ViewGroup.MarginLayoutParams) layoutParams6).topMargin = iIntValue;
        ((ViewGroup.MarginLayoutParams) layoutParams6).leftMargin = iIntValue;
        ((ViewGroup.MarginLayoutParams) layoutParams6).rightMargin = iIntValue;
        this.o.setLayoutParams(layoutParams6);
        RelativeLayout.LayoutParams layoutParams7 = (RelativeLayout.LayoutParams) this.c.getLayoutParams();
        ((ViewGroup.MarginLayoutParams) layoutParams7).topMargin = iIntValue;
        ((ViewGroup.MarginLayoutParams) layoutParams7).leftMargin = iIntValue;
        ((ViewGroup.MarginLayoutParams) layoutParams7).rightMargin = iIntValue;
        this.c.setLayoutParams(layoutParams7);
        ViewGroup.LayoutParams layoutParams8 = this.a.getLayoutParams();
        layoutParams8.height = iRound;
        layoutParams8.width = iRound;
        this.a.setLayoutParams(layoutParams8);
        int iAP = dm.aP();
        final int iIntValue2 = ((Integer) dm.e(pg.a.a(), pg.a.a(), -1084716935, new Object[0], pg.a.a(), 1084716963, pg.a.a())).intValue();
        if (iIntValue2 != 0) {
            c(new Runnable() { // from class: com.facetec.sdk.兵火
                @Override // java.lang.Runnable
                public final void run() {
                    this.f7090.a(iIntValue2);
                }
            });
            this.a.setVisibility(0);
        } else if (iAP != 0) {
            this.a.setImageResource(iAP);
            this.a.clearAnimation();
            this.a.setVisibility(0);
            RotateAnimation rotateAnimation = new RotateAnimation(SelfieScan.RECOGNITION_FAIL_RESULT, 360.0f, 1, 0.5f, 1, 0.5f);
            rotateAnimation.setInterpolator(new LinearInterpolator());
            rotateAnimation.setDuration(FaceTecSDK.d.f95813g.customActivityIndicatorRotationInterval);
            rotateAnimation.setRepeatCount(-1);
            this.a.startAnimation(rotateAnimation);
        } else {
            c(new Runnable() { // from class: com.facetec.sdk.兵灵
                @Override // java.lang.Runnable
                public final void run() {
                    this.f7092.f();
                }
            });
        }
        boolean z = this.u && FaceTecCustomization.p != null;
        this.y = z;
        if (z) {
            this.C.post(new au.c(new Runnable() { // from class: com.facetec.sdk.兵王
                @Override // java.lang.Runnable
                public final void run() throws Throwable {
                    this.f7094.q();
                }
            }));
        }
        if (FaceTecSDK.d.f95813g.showUploadProgressBar) {
            this.m.setVisibility(0);
            c(new Runnable() { // from class: com.facetec.sdk.兵礼
                @Override // java.lang.Runnable
                public final void run() {
                    this.f7095.t();
                }
            });
        } else {
            this.m.setVisibility(4);
        }
        c(new Runnable() { // from class: com.facetec.sdk.兵祖
            @Override // java.lang.Runnable
            public final void run() {
                this.f7096.p();
            }
        });
        t.b(dh.RESULT_UPLOAD);
        this.z = ((FaceTecSessionActivity) getActivity()).p;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ boolean e(View view, MotionEvent motionEvent) {
        if (motionEvent.getAction() == 0) {
            this.q.setAlpha(0.4f);
        } else if (motionEvent.getAction() == 3 || motionEvent.getX() < SelfieScan.RECOGNITION_FAIL_RESULT || motionEvent.getX() > this.q.getWidth() + this.q.getLeft() + 10 || motionEvent.getY() < SelfieScan.RECOGNITION_FAIL_RESULT || motionEvent.getY() > this.q.getHeight() + 10) {
            this.q.setAlpha(1.0f);
        } else if (motionEvent.getAction() == 1) {
            this.q.performClick();
        }
        return true;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void o() {
        if (this.w) {
            return;
        }
        this.C.removeCallbacksAndMessages(null);
        a(new au.c(new Runnable() { // from class: com.facetec.sdk.兵魂
            @Override // java.lang.Runnable
            public final void run() {
                this.f7113.j();
            }
        }));
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void g(Runnable runnable) {
        this.j.animate().alpha(SelfieScan.RECOGNITION_FAIL_RESULT).setDuration(500L).setStartDelay(0L).setListener(null).withEndAction(runnable).start();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void i(final Runnable runnable) {
        this.q.animate().alpha(SelfieScan.RECOGNITION_FAIL_RESULT).setDuration(500L).setStartDelay(0L).setInterpolator(new DecelerateInterpolator()).setListener(null).start();
        dq.d(this.k, SelfieScan.RECOGNITION_FAIL_RESULT, new Runnable() { // from class: com.facetec.sdk.凤古
            @Override // java.lang.Runnable
            public final void run() {
                this.f7138.j(runnable);
            }
        });
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void k(Runnable runnable) {
        RelativeLayout relativeLayout = this.k;
        if (relativeLayout != null) {
            relativeLayout.setVisibility(8);
        }
        if (runnable != null) {
            runnable.run();
        }
    }

    public final void d(float f) {
        if (b()) {
            float progress = this.m.getProgress() / this.m.getMax();
            if (f > 1.0f || progress >= f) {
                return;
            }
            if (f == 1.0f && !this.x) {
                this.x = true;
                if (this.y) {
                    this.C.post(new au.c(new Runnable() { // from class: com.facetec.sdk.兵道
                        @Override // java.lang.Runnable
                        public final void run() {
                            this.f7104.o();
                        }
                    }));
                }
            }
            float f2 = (f * 10000.0f) - 1000.0f;
            if (f2 > this.m.getProgress()) {
                ObjectAnimator objectAnimator = this.p;
                if (objectAnimator != null) {
                    objectAnimator.end();
                    this.p = null;
                }
                this.m.setProgress(Math.round(f2), true);
            }
            this.v.removeCallbacks(this.I);
            this.v.postDelayed(this.I, 600000L);
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void f(Runnable runnable) {
        this.q.setVisibility(8);
        this.d.setVisibility(8);
        this.h.setVisibility(8);
        this.a.setVisibility(4);
        this.e.setAlpha(SelfieScan.RECOGNITION_FAIL_RESULT);
        this.r.setAlpha(SelfieScan.RECOGNITION_FAIL_RESULT);
        this.r.setVisibility(0);
        this.e.setVisibility(0);
        if (!this.z) {
            this.i.setVisibility(0);
        }
        runnable.run();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void j(final Runnable runnable) {
        c(new Runnable() { // from class: com.facetec.sdk.兵龙
            @Override // java.lang.Runnable
            public final void run() {
                this.f7114.k(runnable);
            }
        });
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void c(View view) {
        this.q.setEnabled(false);
        this.q.setClickable(false);
        startActivity(new Intent("android.intent.action.VIEW", Uri.parse("https://dev.facetec.com/removing-development-mode-watermark")));
    }

    public final void b(final String str) {
        if (!b() || this.y) {
            return;
        }
        e(new au.c(new Runnable() { // from class: com.facetec.sdk.凤剑
            @Override // java.lang.Runnable
            public final void run() throws Throwable {
                this.f7136.a(str);
            }
        }));
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void a(String str) throws Throwable {
        if (this.w) {
            return;
        }
        if (this.m == null || r0.getProgress() / this.m.getMax() < 0.9d) {
            this.h.setText(str);
            try {
                Object[] objArr = new Object[1];
                E("ٱꔫ䃏\uef89譱㛢햜煂᳴믬杢șꆤ䵲\ue810韉", View.combineMeasuredStates(0, 0) + 41809, objArr);
                Class<?> cls = Class.forName((String) objArr[0]);
                Object[] objArr2 = new Object[1];
                E("ٵ矯\ue55f勋쀛㆛꼈ᵭ", 29077 - Color.alpha(0), objArr2);
                this.D = ((Long) cls.getMethod((String) objArr2[0], null).invoke(null, null)).longValue() / 1000000;
            } catch (Throwable th) {
                Throwable cause = th.getCause();
                if (cause == null) {
                    throw th;
                }
                throw cause;
            }
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void b(au.c cVar) {
        ViewPropertyAnimator viewPropertyAnimatorAlpha = this.o.animate().alpha(1.0f);
        int iA = pg.a.a();
        viewPropertyAnimatorAlpha.setDuration(((Integer) dm.e(pg.a.a(), iA, 1178154252, new Object[0], pg.a.a(), -1178154250, pg.a.a())).intValue()).setStartDelay(0L).setListener(null).start();
        int iA2 = pg.a.a();
        au.e(cVar, ((Integer) dm.e(pg.a.a(), iA2, 1178154252, new Object[0], pg.a.a(), -1178154250, pg.a.a())).intValue());
    }

    private void e(au.c cVar) throws Throwable {
        this.C.postDelayed(cVar, d());
    }

    public final void h(final Runnable runnable) {
        if (b()) {
            this.q.animate().alpha(SelfieScan.RECOGNITION_FAIL_RESULT).setDuration(500L).setListener(null).start();
            this.d.animate().alpha(SelfieScan.RECOGNITION_FAIL_RESULT).setDuration(500L).setListener(null).start();
            this.h.animate().alpha(SelfieScan.RECOGNITION_FAIL_RESULT).setDuration(500L).setListener(null).start();
            this.a.animate().alpha(SelfieScan.RECOGNITION_FAIL_RESULT).setDuration(500L).setListener(null).withEndAction(new au.c(new Runnable() { // from class: com.facetec.sdk.凤人
                @Override // java.lang.Runnable
                public final void run() {
                    this.f7123.f(runnable);
                }
            })).start();
        }
    }

    private void c(final boolean z) throws Throwable {
        this.C.removeCallbacksAndMessages(null);
        e(new au.c(new Runnable() { // from class: com.facetec.sdk.凤丹
            @Override // java.lang.Runnable
            public final void run() throws Throwable {
                this.f7117.d(z);
            }
        }));
    }

    private void b(final boolean z, @NonNull final au.c cVar) {
        int iAT;
        int iBp;
        if (getActivity() == null || !b()) {
            return;
        }
        if (z) {
            iAT = ((Integer) dm.e(pg.a.a(), pg.a.a(), -1271089769, new Object[0], pg.a.a(), 1271089769, pg.a.a())).intValue();
        } else {
            iAT = dm.aT();
        }
        final int i = iAT;
        final boolean z2 = i != 0;
        if (z) {
            iBp = ((Integer) dm.e(pg.a.a(), pg.a.a(), 733738620, new Object[0], pg.a.a(), -733738576, pg.a.a())).intValue();
        } else {
            iBp = dm.bp();
        }
        final int i2 = iBp;
        final boolean z3 = i2 != 0;
        c(new Runnable() { // from class: com.facetec.sdk.凤仙
            @Override // java.lang.Runnable
            public final void run() {
                this.f7125.d(z2, z3, i2, i, z, cVar);
            }
        });
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void e(int i, int i2, final au.c cVar) {
        this.d.setVisibility(0);
        this.l.setImageDrawable(null);
        this.l.clearColorFilter();
        this.l.invalidate();
        this.n.clearColorFilter();
        this.n.invalidate();
        if (i != 0) {
            dq.c(this.n, i, null, true);
        } else {
            Drawable drawable = C6852.getDrawable(getActivity(), i2);
            this.n.setColorFilter(dq.b(getActivity(), dm.S()), PorterDuff.Mode.SRC_IN);
            this.n.setImageDrawable(drawable);
        }
        dq.d(this.r, SelfieScan.RECOGNITION_FAIL_RESULT, (Runnable) null);
        dq.d(this.d, 1.0f, new Runnable() { // from class: com.facetec.sdk.凤书
            @Override // java.lang.Runnable
            public final void run() {
                this.f7121.b(cVar);
            }
        });
    }

    private String c(a aVar, d dVar) {
        if (!this.u) {
            return dp.a(R.string.FaceTec_result_facescan_upload_message);
        }
        if (FaceTecCustomization.p == null) {
            return dp.a(R.string.FaceTec_result_idscan_upload_message);
        }
        dr drVar = dr.UNKNOWN;
        int i = AnonymousClass5.c[dVar.ordinal()];
        if (i == 2) {
            int i2 = AnonymousClass5.e[aVar.ordinal()];
            if (i2 == 1) {
                drVar = dr.IDSCAN_FRONT_SIDE_UPLOAD_STARTED;
            } else if (i2 == 2) {
                drVar = dr.IDSCAN_FRONT_SIDE_STILL_UPLOADING;
            } else if (i2 == 3) {
                drVar = dr.IDSCAN_FRONT_SIDE_UPLOAD_COMPLETE_AWAITING_RESPONSE;
            } else if (i2 == 4) {
                drVar = dr.IDSCAN_FRONT_SIDE_UPLOAD_COMPLETE_AWAITING_PROCESSING;
            }
        } else if (i == 3) {
            int i3 = AnonymousClass5.e[aVar.ordinal()];
            if (i3 == 1) {
                drVar = dr.IDSCAN_BACK_SIDE_UPLOAD_STARTED;
            } else if (i3 == 2) {
                drVar = dr.IDSCAN_BACK_SIDE_STILL_UPLOADING;
            } else if (i3 == 3) {
                drVar = dr.IDSCAN_BACK_SIDE_UPLOAD_COMPLETE_AWAITING_RESPONSE;
            } else if (i3 == 4) {
                drVar = dr.IDSCAN_BACK_SIDE_UPLOAD_COMPLETE_AWAITING_PROCESSING;
            }
        } else if (i == 4) {
            int i4 = AnonymousClass5.e[aVar.ordinal()];
            if (i4 == 1) {
                drVar = dr.IDSCAN_USER_CONFIRMED_INFO_UPLOAD_STARTED;
            } else if (i4 == 2) {
                drVar = dr.IDSCAN_USER_CONFIRMED_INFO_STILL_UPLOADING;
            } else if (i4 == 3) {
                drVar = dr.IDSCAN_USER_CONFIRMED_INFO_UPLOAD_COMPLETE_AWAITING_RESPONSE;
            } else if (i4 == 4) {
                drVar = dr.IDSCAN_USER_CONFIRMED_INFO_UPLOAD_COMPLETE_AWAITING_PROCESSING;
            }
        } else if (i == 5) {
            int i5 = AnonymousClass5.e[aVar.ordinal()];
            if (i5 == 1) {
                drVar = dr.NFC_UPLOAD_STARTED;
            } else if (i5 == 2) {
                drVar = dr.NFC_STILL_UPLOADING;
            } else if (i5 == 3) {
                drVar = dr.NFC_UPLOAD_COMPLETE_AWAITING_RESPONSE;
            } else if (i5 == 4) {
                drVar = dr.NFC_UPLOAD_COMPLETE_AWAITING_PROCESSING;
            }
        } else if (i == 6) {
            int i6 = AnonymousClass5.e[aVar.ordinal()];
            if (i6 == 1) {
                drVar = dr.SKIPPED_NFC_UPLOAD_STARTED;
            } else if (i6 == 2) {
                drVar = dr.SKIPPED_NFC_STILL_UPLOADING;
            } else if (i6 == 3) {
                drVar = dr.SKIPPED_NFC_UPLOAD_COMPLETE_AWAITING_RESPONSE;
            } else if (i6 == 4) {
                drVar = dr.SKIPPED_NFC_UPLOAD_COMPLETE_AWAITING_PROCESSING;
            }
        }
        int iA = pg.a.a();
        String str = (String) dm.e(pg.a.a(), iA, 1436383320, new Object[]{drVar}, pg.a.a(), -1436383290, pg.a.a());
        if (str != null) {
            return str;
        }
        if (aVar == a.UPLOAD_COMPLETE_AWAITING_PROCESSING) {
            return c(a.UPLOAD_COMPLETE_AWAITING_RESPONSE, dVar);
        }
        if (aVar != a.UPLOAD_COMPLETE_AWAITING_RESPONSE && aVar != a.STILL_UPLOADING) {
            if (this.u) {
                if (dVar == d.NFC) {
                    return dp.a(R.string.FaceTec_result_nfc_upload_message);
                }
                return dp.a(R.string.FaceTec_result_idscan_upload_message);
            }
            return dp.a(R.string.FaceTec_result_facescan_upload_message);
        }
        return c(a.UPLOAD_STARTED, dVar);
    }

    private void a(final au.c cVar) {
        if (b() && this.m.getProgress() != this.m.getMax() && FaceTecSDK.d.f95813g.showUploadProgressBar) {
            c(new Runnable() { // from class: com.facetec.sdk.兵战
                @Override // java.lang.Runnable
                public final void run() {
                    this.f7079.h(cVar);
                }
            });
        } else {
            cVar.run();
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void h() {
        this.C.removeCallbacksAndMessages(null);
        this.w = true;
    }

    public final void b(final Runnable runnable) {
        if (getActivity() == null) {
            return;
        }
        c(new Runnable() { // from class: com.facetec.sdk.凤兵
            @Override // java.lang.Runnable
            public final void run() {
                this.f7132.i(runnable);
            }
        });
    }

    private void a() {
        if (b() && FaceTecSDK.d.f95813g.showUploadProgressBar) {
            final au.c cVar = null;
            c(new Runnable() { // from class: com.facetec.sdk.凤凤
                @Override // java.lang.Runnable
                public final void run() {
                    this.f7134.c(cVar);
                }
            });
        }
    }

    private long d() throws Throwable {
        if (this.D == -1) {
            return 0L;
        }
        try {
            Object[] objArr = new Object[1];
            E("ٱꔫ䃏\uef89譱㛢햜煂᳴믬杢șꆤ䵲\ue810韉", 41809 - (TypedValue.complexToFraction(0, SelfieScan.RECOGNITION_FAIL_RESULT, SelfieScan.RECOGNITION_FAIL_RESULT) > SelfieScan.RECOGNITION_FAIL_RESULT ? 1 : (TypedValue.complexToFraction(0, SelfieScan.RECOGNITION_FAIL_RESULT, SelfieScan.RECOGNITION_FAIL_RESULT) == SelfieScan.RECOGNITION_FAIL_RESULT ? 0 : -1)), objArr);
            Class<?> cls = Class.forName((String) objArr[0]);
            Object[] objArr2 = new Object[1];
            E("ٵ矯\ue55f勋쀛㆛꼈ᵭ", 29077 - ((Process.getThreadPriority(0) + 20) >> 6), objArr2);
            long jLongValue = (((Long) cls.getMethod((String) objArr2[0], null).invoke(null, null)).longValue() / 1000000) - this.D;
            if (jLongValue < 1000) {
                return 1000 - jLongValue;
            }
            return 0L;
        } catch (Throwable th) {
            Throwable cause = th.getCause();
            if (cause != null) {
                throw cause;
            }
            throw th;
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void d(boolean z) throws Throwable {
        if (this.h != null) {
            String strC = c(this.A, this.B);
            if (strC.equals(this.h.getText().toString())) {
                return;
            }
            try {
                if (!z) {
                    this.h.setText(strC);
                    Object[] objArr = new Object[1];
                    E("ٱꔫ䃏\uef89譱㛢햜煂᳴믬杢șꆤ䵲\ue810韉", Color.alpha(0) + 41809, objArr);
                    Class<?> cls = Class.forName((String) objArr[0]);
                    Object[] objArr2 = new Object[1];
                    E("ٵ矯\ue55f勋쀛㆛꼈ᵭ", 29077 - KeyEvent.getDeadChar(0, 0), objArr2);
                    this.D = ((Long) cls.getMethod((String) objArr2[0], null).invoke(null, null)).longValue() / 1000000;
                    return;
                }
                Object[] objArr3 = new Object[1];
                E("ٱꔫ䃏\uef89譱㛢햜煂᳴믬杢șꆤ䵲\ue810韉", 41809 - (ViewConfiguration.getScrollBarFadeDuration() >> 16), objArr3);
                Class<?> cls2 = Class.forName((String) objArr3[0]);
                Object[] objArr4 = new Object[1];
                E("ٵ矯\ue55f勋쀛㆛꼈ᵭ", 29077 - (ViewConfiguration.getScrollDefaultDelay() >> 16), objArr4);
                this.D = (((Long) cls2.getMethod((String) objArr4[0], null).invoke(null, null)).longValue() / 1000000) + 1000;
                this.h.animate().alpha(SelfieScan.RECOGNITION_FAIL_RESULT).setDuration(500L).setListener(null).withEndAction(new au.c(new Runnable() { // from class: com.facetec.sdk.兵玉
                    @Override // java.lang.Runnable
                    public final void run() {
                        this.f7093.k();
                    }
                })).start();
            } catch (Throwable th) {
                Throwable cause = th.getCause();
                if (cause == null) {
                    throw th;
                }
                throw cause;
            }
        }
    }

    public final void a(boolean z, String str, @NonNull Runnable runnable) {
        a(z, false, str, runnable);
    }

    public final void a(final boolean z, final boolean z2, String str, @NonNull final Runnable runnable) {
        if (getActivity() == null || !b()) {
            return;
        }
        TextView textView = this.h;
        if (textView != null) {
            textView.setImportantForAccessibility(2);
        }
        g();
        if (!this.u) {
            if (str == null) {
                str = dp.a(R.string.FaceTec_result_success_message);
            }
            this.o.setText(str);
            if (z) {
                this.o.setContentDescription(str);
                this.o.performAccessibilityAction(64, null);
                this.o.sendAccessibilityEvent(8);
                this.o.announceForAccessibility(str);
            }
        } else if (z) {
            if (str == null) {
                str = dp.a(R.string.FaceTec_result_success_message);
            }
            this.o.setText(str);
        } else {
            if (str == null) {
                str = dp.a(R.string.FaceTec_result_idscan_unsuccess_message);
            }
            this.o.setText(str);
        }
        this.w = true;
        d((Runnable) new au.c(new Runnable() { // from class: com.facetec.sdk.兵祭
            @Override // java.lang.Runnable
            public final void run() {
                this.f7098.c(z, runnable, z2);
            }
        }));
    }

    public final void e(Runnable runnable) {
        if (b()) {
            this.d.animate().alpha(SelfieScan.RECOGNITION_FAIL_RESULT).setDuration(500L).setStartDelay(0L).setListener(null).withEndAction(new au.c(runnable)).start();
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static /* synthetic */ void d(au.c cVar, Animator animator) {
        if (cVar != null) {
            cVar.run();
        }
    }

    public final void d(final Runnable runnable) {
        if (b()) {
            g();
            this.w = true;
            e(new au.c(new Runnable() { // from class: com.facetec.sdk.兵金
                @Override // java.lang.Runnable
                public final void run() {
                    this.f7105.o(runnable);
                }
            }));
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void d(boolean z, boolean z2, int i, int i2, boolean z3, final au.c cVar) {
        this.d.setVisibility(0);
        if (z || z2) {
            this.l.setImageDrawable(null);
            this.l.clearColorFilter();
            this.l.invalidate();
        }
        this.n.clearColorFilter();
        this.n.invalidate();
        if (z2) {
            dq.c(this.n, i, null, false);
        } else {
            if (z) {
                this.l.setImageResource(i2);
                this.l.animate().alpha(SelfieScan.RECOGNITION_FAIL_RESULT).scaleX(1.0f).scaleY(1.0f).setDuration(0L).setStartDelay(0L).setListener(null).start();
                this.l.animate().alpha(1.0f).scaleX(1.0f).scaleY(1.0f).setDuration(500L).setStartDelay(0L).setInterpolator(new DecelerateInterpolator()).setListener(null).start();
            } else {
                this.l.setColorFilter(dm.o(getActivity()), PorterDuff.Mode.SRC_IN);
                dq.c(this.l, R.drawable.facetec_animated_result_background, null, true);
            }
            int i3 = z3 ? R.drawable.facetec_animated_success_foreground : R.drawable.facetec_animated_unsuccess_foreground;
            this.n.setColorFilter(dm.n(getActivity()), PorterDuff.Mode.SRC_IN);
            dq.c(this.n, i3, null, false);
        }
        dq.a(this.n);
        dq.d(this.r, SelfieScan.RECOGNITION_FAIL_RESULT, (Runnable) null);
        dq.d(this.d, 1.0f, new Runnable() { // from class: com.facetec.sdk.兵日
            @Override // java.lang.Runnable
            public final void run() {
                this.f7081.d(cVar);
            }
        });
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void a(int i) {
        dq.c(this.a, i, new AnonymousClass4(), true);
    }

    public final void a(final Runnable runnable) {
        if (b()) {
            au.e(new au.c(new Runnable() { // from class: com.facetec.sdk.凤乐
                @Override // java.lang.Runnable
                public final void run() {
                    this.f7119.g(runnable);
                }
            }), 500L);
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void d(au.c cVar) {
        this.a.setImageDrawable(null);
        this.o.animate().alpha(1.0f).setDuration(500L).setStartDelay(0L).setListener(null).start();
        au.e(cVar, dm.i());
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void c(au.c cVar) {
        this.m.animate().alpha(SelfieScan.RECOGNITION_FAIL_RESULT).setDuration(500L).setListener(null).withEndAction(cVar).start();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void c(boolean z, Runnable runnable, boolean z2) {
        a();
        if (z) {
            b(true, new au.c(runnable));
            return;
        }
        if (z2) {
            final au.c cVar = new au.c(runnable);
            if (getActivity() == null || !b()) {
                return;
            }
            final int iBj = dm.bj();
            final int i = R.drawable.facetec_internal_warning;
            c(new Runnable() { // from class: com.facetec.sdk.兵风
                @Override // java.lang.Runnable
                public final void run() {
                    this.f7108.e(iBj, i, cVar);
                }
            });
            return;
        }
        if (this.u) {
            b(false, new au.c(runnable));
        } else {
            b((Runnable) new au.c(runnable));
        }
    }
}