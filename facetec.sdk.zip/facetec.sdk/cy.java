package com.facetec.sdk;

import android.animation.Animator;
import android.content.Context;
import android.os.Handler;
import android.util.AttributeSet;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.ScaleAnimation;
import android.widget.LinearLayout;
import android.widget.TextView;
import com.facetec.sdk.FaceTecVocalGuidanceCustomization;
import com.facetec.sdk.ed;
import com.incode.welcome_sdk.modules.SelfieScan;
import io.sentry.HttpStatusCodeRange;

/* JADX INFO: loaded from: classes4.dex */
class cy extends LinearLayout {
    cm a;
    View b;
    int c;
    cs d;
    TextView e;
    boolean f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    Handler f95862g;
    final f h;
    Animator i;
    Animator j;
    private final int k;
    private Animation l;

    /* JADX INFO: renamed from: com.facetec.sdk.cy$1, reason: invalid class name */
    public static /* synthetic */ class AnonymousClass1 {
        static final /* synthetic */ int[] a;
        static final /* synthetic */ int[] b;

        static {
            int[] iArr = new int[cm.values().length];
            a = iArr;
            try {
                iArr[cm.HOLD_STEADY.ordinal()] = 1;
            } catch (NoSuchFieldError unused) {
            }
            try {
                a[cm.FACE_NOT_FOUND.ordinal()] = 2;
            } catch (NoSuchFieldError unused2) {
            }
            try {
                a[cm.MOVE_FACE_CLOSER.ordinal()] = 3;
            } catch (NoSuchFieldError unused3) {
            }
            try {
                a[cm.MOVE_FACE_EVEN_CLOSER.ordinal()] = 4;
            } catch (NoSuchFieldError unused4) {
            }
            try {
                a[cm.MOVE_FACE_FURTHER_AWAY.ordinal()] = 5;
            } catch (NoSuchFieldError unused5) {
            }
            try {
                a[cm.MOVE_FACE_AWAY_A_LITTLE.ordinal()] = 6;
            } catch (NoSuchFieldError unused6) {
            }
            try {
                a[cm.FACE_CENTERED_TOO_FAR_TOP.ordinal()] = 7;
            } catch (NoSuchFieldError unused7) {
            }
            try {
                a[cm.FACE_CENTERED_TOO_FAR_BOTTOM.ordinal()] = 8;
            } catch (NoSuchFieldError unused8) {
            }
            try {
                a[cm.FACE_CENTERED_TOO_FAR_LEFT.ordinal()] = 9;
            } catch (NoSuchFieldError unused9) {
            }
            try {
                a[cm.FACE_CENTERED_TOO_FAR_RIGHT.ordinal()] = 10;
            } catch (NoSuchFieldError unused10) {
            }
            try {
                a[cm.FACE_ROTATED_TOO_FAR_LEFT.ordinal()] = 11;
            } catch (NoSuchFieldError unused11) {
            }
            try {
                a[cm.FACE_ROTATED_TOO_FAR_RIGHT.ordinal()] = 12;
            } catch (NoSuchFieldError unused12) {
            }
            try {
                a[cm.MOVE_PHONE_TO_EYE_LEVEL.ordinal()] = 13;
            } catch (NoSuchFieldError unused13) {
            }
            try {
                a[cm.FACE_LOOKING_TOO_FAR_LEFT.ordinal()] = 14;
            } catch (NoSuchFieldError unused14) {
            }
            try {
                a[cm.FACE_LOOKING_TOO_FAR_RIGHT.ordinal()] = 15;
            } catch (NoSuchFieldError unused15) {
            }
            try {
                a[cm.FACE_NOT_LOOKING_STRAIGHT_AHEAD.ordinal()] = 16;
            } catch (NoSuchFieldError unused16) {
            }
            try {
                a[cm.USE_EVEN_LIGHTING.ordinal()] = 17;
            } catch (NoSuchFieldError unused17) {
            }
            int[] iArr2 = new int[cs.values().length];
            b = iArr2;
            try {
                iArr2[cs.NONE.ordinal()] = 1;
            } catch (NoSuchFieldError unused18) {
            }
            try {
                b[cs.FRAME_YOUR_FACE.ordinal()] = 2;
            } catch (NoSuchFieldError unused19) {
            }
            try {
                b[cs.WEARING_SUNGLASSES.ordinal()] = 3;
            } catch (NoSuchFieldError unused20) {
            }
            try {
                b[cs.BAD_POSE.ordinal()] = 4;
            } catch (NoSuchFieldError unused21) {
            }
            try {
                b[cs.TOO_BRIGHT.ordinal()] = 5;
            } catch (NoSuchFieldError unused22) {
            }
            try {
                b[cs.TOO_DARK.ordinal()] = 6;
            } catch (NoSuchFieldError unused23) {
            }
            try {
                b[cs.MAKING_FACE.ordinal()] = 7;
            } catch (NoSuchFieldError unused24) {
            }
            try {
                b[cs.HOLD_STEADY_3.ordinal()] = 8;
            } catch (NoSuchFieldError unused25) {
            }
            try {
                b[cs.HOLD_STEADY_2.ordinal()] = 9;
            } catch (NoSuchFieldError unused26) {
            }
            try {
                b[cs.HOLD_STEADY_1.ordinal()] = 10;
            } catch (NoSuchFieldError unused27) {
            }
            try {
                b[cs.MOVE_CLOSER.ordinal()] = 11;
            } catch (NoSuchFieldError unused28) {
            }
            try {
                b[cs.MOVE_AWAY.ordinal()] = 12;
            } catch (NoSuchFieldError unused29) {
            }
        }
    }

    public cy(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        this.k = HttpStatusCodeRange.DEFAULT_MIN;
        this.a = cm.FACE_NOT_FOUND;
        this.d = cs.FRAME_YOUR_FACE;
        this.c = 0;
        this.f = false;
        this.h = new f() { // from class: com.facetec.sdk.凤名
            @Override // android.animation.Animator.AnimatorListener
            public final void onAnimationEnd(Animator animator) {
                this.f7141.a(animator);
            }
        };
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void a(Animator animator) {
        dp.e(this.e, this.c);
        Animation animation = this.l;
        if (animation != null) {
            animation.cancel();
            this.l = null;
            this.e.setScaleX(1.0f);
            this.e.setScaleY(1.0f);
        }
        this.i.start();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void b() {
        this.f = false;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void c(int i) {
        float y = getY();
        setVisibility(0);
        setAlpha(SelfieScan.RECOGNITION_FAIL_RESULT);
        setY(y - (this.b.getHeight() / 2));
        animate().setDuration(i).alpha(1.0f).y(y).setListener(null).start();
    }

    public final void d() {
        final int i = HttpStatusCodeRange.DEFAULT_MIN;
        postDelayed(new Runnable() { // from class: com.facetec.sdk.凤土
            @Override // java.lang.Runnable
            public final void run() {
                this.f7143.c(i);
            }
        }, 50L);
    }

    public final void e() {
        if (this.c == R.string.FaceTec_feedback_move_phone_closer) {
            ScaleAnimation scaleAnimation = new ScaleAnimation(1.0f, 1.15f, 1.0f, 1.15f, 1, 0.5f, 1, 0.5f);
            this.l = scaleAnimation;
            scaleAnimation.setDuration(1000L);
            this.l.setRepeatMode(2);
            this.l.setRepeatCount(-1);
            this.e.startAnimation(this.l);
            if (FaceTecSDK.d.vocalGuidanceCustomization.mode == FaceTecVocalGuidanceCustomization.VocalGuidanceMode.FULL_VOCAL_GUIDANCE || FaceTecSDK.d.vocalGuidanceCustomization.mode == FaceTecVocalGuidanceCustomization.VocalGuidanceMode.NO_VOCAL_GUIDANCE) {
                return;
            }
            Handler handler = new Handler();
            this.f95862g = handler;
            handler.postDelayed(new Runnable() { // from class: com.facetec.sdk.凤地
                @Override // java.lang.Runnable
                public final void run() {
                    this.f7145.c();
                }
            }, 1000L);
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void c() {
        if (ed.e || this.c != R.string.FaceTec_feedback_move_phone_closer) {
            return;
        }
        ed.d(getContext(), ed.d.FACE_CAPTURE_MOVE_CLOSER_DELAYED);
    }

    public static int a(cs csVar) {
        int i = R.string.FaceTec_presession_frame_your_face;
        switch (AnonymousClass1.b[csVar.ordinal()]) {
            case 1:
                return R.string.FaceTec_presession_frame_your_face;
            case 2:
                return R.string.FaceTec_presession_frame_your_face;
            case 3:
                return R.string.FaceTec_presession_remove_dark_glasses;
            case 4:
                return R.string.FaceTec_presession_position_face_straight_in_oval;
            case 5:
                return R.string.FaceTec_presession_conditions_too_bright;
            case 6:
                return R.string.FaceTec_presession_brighten_your_environment;
            case 7:
                return R.string.FaceTec_presession_neutral_expression;
            case 8:
                return R.string.FaceTec_presession_hold_steady_3;
            case 9:
                return R.string.FaceTec_presession_hold_steady_2;
            case 10:
                return R.string.FaceTec_presession_hold_steady_1;
            case 11:
                return R.string.FaceTec_feedback_move_phone_closer;
            case 12:
                return R.string.FaceTec_feedback_move_phone_away;
            default:
                return i;
        }
    }

    public static int c(cm cmVar) {
        boolean zB = ed.b();
        int i = R.string.FaceTec_feedback_face_not_found;
        switch (AnonymousClass1.a[cmVar.ordinal()]) {
            case 1:
                return R.string.FaceTec_feedback_hold_steady;
            case 2:
                return zB ? R.string.FaceTec_accessibility_feedback_face_not_on_camera : R.string.FaceTec_feedback_face_not_found;
            case 3:
                return zB ? R.string.FaceTec_accessibility_feedback_move_phone_closer : R.string.FaceTec_feedback_move_phone_closer;
            case 4:
                return zB ? R.string.FaceTec_accessibility_feedback_move_phone_closer : R.string.FaceTec_feedback_move_phone_closer;
            case 5:
                return zB ? R.string.FaceTec_accessibility_feedback_move_phone_away : R.string.FaceTec_feedback_move_phone_away;
            case 6:
                return zB ? R.string.FaceTec_accessibility_feedback_move_phone_away : R.string.FaceTec_feedback_move_phone_away;
            case 7:
                return zB ? R.string.FaceTec_accessibility_feedback_face_too_high : R.string.FaceTec_feedback_center_face;
            case 8:
                return zB ? R.string.FaceTec_accessibility_feedback_face_too_low : R.string.FaceTec_feedback_center_face;
            case 9:
                return zB ? R.string.FaceTec_accessibility_feedback_face_too_far_left : R.string.FaceTec_feedback_center_face;
            case 10:
                return zB ? R.string.FaceTec_accessibility_feedback_face_too_far_right : R.string.FaceTec_feedback_center_face;
            case 11:
                return zB ? R.string.FaceTec_accessibility_feedback_face_rotated_too_far_left : R.string.FaceTec_feedback_face_not_upright;
            case 12:
                return zB ? R.string.FaceTec_accessibility_feedback_face_rotated_too_far_right : R.string.FaceTec_feedback_face_not_upright;
            case 13:
                return zB ? R.string.FaceTec_accessibility_feedback_hold_device_to_eye_level : R.string.FaceTec_feedback_move_phone_to_eye_level;
            case 14:
                return zB ? R.string.FaceTec_accessibility_feedback_face_pointing_too_far_left : R.string.FaceTec_feedback_face_not_looking_straight_ahead;
            case 15:
                return zB ? R.string.FaceTec_accessibility_feedback_face_pointing_too_far_right : R.string.FaceTec_feedback_face_not_looking_straight_ahead;
            case 16:
                return R.string.FaceTec_feedback_face_not_looking_straight_ahead;
            case 17:
                return R.string.FaceTec_feedback_use_even_lighting;
            default:
                return i;
        }
    }

    public final void e(int i) {
        if (this.f || i == this.c) {
            return;
        }
        this.c = i;
        this.f = true;
        ed.b(i);
        this.j.start();
        postDelayed(new Runnable() { // from class: com.facetec.sdk.凤国
            @Override // java.lang.Runnable
            public final void run() {
                this.f7142.b();
            }
        }, 1000L);
    }
}