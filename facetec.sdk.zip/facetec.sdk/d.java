package com.facetec.sdk;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.graphics.Typeface;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import com.facetec.sdk.au;
import com.facetec.sdk.pg;
import com.incode.welcome_sdk.modules.SelfieScan;
import kotlin.C6852;

/* JADX INFO: loaded from: classes4.dex */
public final class d extends au {
    private FrameLayout a;
    private ImageView b;
    private View c;
    private View d;
    private View e;
    private TextView i;

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void a() {
        b(new Runnable() { // from class: com.facetec.sdk.凤字
            @Override // java.lang.Runnable
            public final void run() {
                this.f7149.c();
            }
        }, dm.n());
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void c() {
        this.d.animate().alpha(SelfieScan.RECOGNITION_FAIL_RESULT).setDuration(500L).setListener(null).withEndAction(new au.c(new Runnable() { // from class: com.facetec.sdk.凤天
            @Override // java.lang.Runnable
            public final void run() {
                this.f7147.i();
            }
        })).start();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void d() {
        dq.a(this.b);
        this.d.animate().alpha(1.0f).setDuration(500L).setListener(null).withEndAction(new au.c(new Runnable() { // from class: com.facetec.sdk.凤城
            @Override // java.lang.Runnable
            public final void run() {
                this.f7146.a();
            }
        })).start();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void e() {
        b(new Runnable() { // from class: com.facetec.sdk.凤宫
            @Override // java.lang.Runnable
            public final void run() {
                this.f7150.d();
            }
        }, 1000L);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void i() {
        bi biVar = (bi) getActivity();
        if (biVar != null) {
            t.d(biVar, c.ADDITIONAL_REVIEW_BUTTON_PRESSED, null, null);
            biVar.B();
        }
    }

    @Override // com.facetec.sdk.au, android.app.Fragment
    public final void onCreate(Bundle bundle) {
        super.onCreate(bundle);
    }

    @Override // android.app.Fragment
    public final View onCreateView(LayoutInflater layoutInflater, ViewGroup viewGroup, Bundle bundle) {
        View viewInflate = layoutInflater.inflate(R.layout.facetec_additional_review_fragment, viewGroup, false);
        this.c = viewInflate;
        return viewInflate;
    }

    @Override // android.app.Fragment
    @SuppressLint({"ClickableViewAccessibility"})
    public final void onViewCreated(View view, Bundle bundle) {
        super.onViewCreated(view, bundle);
        Activity activity = getActivity();
        this.e = view.findViewById(R.id.backgroundView);
        this.d = view.findViewById(R.id.contentLayout);
        this.a = (FrameLayout) view.findViewById(R.id.iconFrameLayout);
        this.b = (ImageView) view.findViewById(R.id.iconImageView);
        this.i = (TextView) view.findViewById(R.id.messageTextView);
        float fB = dm.b() * dm.c();
        int iIntValue = ((Integer) dm.e(pg.a.a(), pg.a.a(), 1933108801, new Object[0], pg.a.a(), -1933108792, pg.a.a())).intValue();
        int iRound = Math.round(bh.a(80) * dm.bo() * fB);
        int iRound2 = Math.round(bh.a(-55) * fB);
        int iRound3 = Math.round(fB * 24.0f);
        Typeface typeface = FaceTecSDK.d.f95813g.messageFont;
        int iB = dq.b(activity, ((Integer) dm.e(pg.a.a(), pg.a.a(), 2009312697, new Object[0], pg.a.a(), -2009312677, pg.a.a())).intValue());
        getActivity();
        int iBa = dm.ba();
        int iIntValue2 = ((Integer) dm.e(pg.a.a(), pg.a.a(), -714835323, new Object[0], pg.a.a(), 714835348, pg.a.a())).intValue();
        if (iIntValue2 != 0) {
            dq.c(this.b, iIntValue2, null, false);
        } else if (iBa != 0) {
            this.b.setImageDrawable(C6852.getDrawable(activity, iBa));
        } else {
            this.b.setVisibility(8);
        }
        this.d.setTranslationY(iRound2);
        this.a.getLayoutParams().height = iRound;
        this.a.getLayoutParams().width = iRound;
        ((RelativeLayout.LayoutParams) this.a.getLayoutParams()).setMargins(0, iIntValue, 0, 0);
        dp.e(this.i, R.string.FaceTec_idscan_additional_review_message);
        this.i.setTextColor(iB);
        this.i.setTypeface(typeface);
        this.i.setTextSize(iRound3);
        ((RelativeLayout.LayoutParams) this.i.getLayoutParams()).setMargins(0, iIntValue, 0, iIntValue);
        dm.d(this.e);
        this.e.getBackground().setAlpha(((Integer) dm.e(pg.a.a(), pg.a.a(), -298147150, new Object[0], pg.a.a(), 298147185, pg.a.a())).intValue());
        c(new Runnable() { // from class: com.facetec.sdk.凤妖
            @Override // java.lang.Runnable
            public final void run() {
                this.f7148.e();
            }
        });
    }
}