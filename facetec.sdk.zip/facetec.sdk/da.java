package com.facetec.sdk;

/* JADX INFO: loaded from: classes4.dex */
enum da {
    DETECTING_LIGHT_MODE,
    DETECTING_FACE_FEEDBACK,
    TIMEOUT_GO_TO_RETRY,
    READY_TO_START_FACESCAN_SESSION
}