package com.facetec.sdk;

/* JADX INFO: loaded from: classes4.dex */
final class db {
    static String a = "fcd";
    static String b = "data";
}