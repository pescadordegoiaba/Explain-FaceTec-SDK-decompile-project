package com.facetec.sdk;

import android.content.res.Resources;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.PorterDuff;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewOutlineProvider;
import android.view.ViewPropertyAnimator;
import android.view.ViewTreeObserver;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import androidx.core.graphics.drawable.C1189;
import androidx.core.graphics.drawable.RoundedBitmapDrawable;
import com.facetec.sdk.au;
import com.facetec.sdk.bh;
import com.facetec.sdk.pg;
import com.incode.welcome_sdk.modules.SelfieScan;
import com.plaid.internal.EnumC41897g;
import io.sentry.HttpStatusCodeRange;
import java.util.Locale;
import org.json.JSONObject;

/* JADX INFO: loaded from: classes4.dex */
public final class dc extends au {
    ImageView a;
    ImageView b;
    ImageView c;
    ImageView d;
    LinearLayout e;
    TextView f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    TextView f95864g;
    TextView h;
    LinearLayout i;
    TextView j;
    TextView k;
    GradientDrawable l;
    Bitmap m;
    TextView n;
    dn o;
    private ImageView p;
    private LinearLayout q;
    private LinearLayout s;
    private LinearLayout t;
    private RoundedBitmapDrawable u;
    private TextView y;
    boolean r = false;
    private final ViewTreeObserver.OnGlobalLayoutListener w = new ViewTreeObserver.OnGlobalLayoutListener() { // from class: com.facetec.sdk.dc.2
        @Override // android.view.ViewTreeObserver.OnGlobalLayoutListener
        public final void onGlobalLayout() {
            dc.this.e();
            dc dcVar = dc.this;
            if (dcVar.r) {
                return;
            }
            dcVar.r = true;
            dcVar.d();
        }
    };

    /* JADX INFO: renamed from: com.facetec.sdk.dc$3, reason: invalid class name */
    public static /* synthetic */ class AnonymousClass3 {
        static final /* synthetic */ int[] a;

        static {
            int[] iArr = new int[df.values().length];
            a = iArr;
            try {
                iArr[df.LIGHTING_AND_NEUTRAL_EXPRESSION.ordinal()] = 1;
            } catch (NoSuchFieldError unused) {
            }
            try {
                a[df.LIGHTING_ONLY.ordinal()] = 2;
            } catch (NoSuchFieldError unused2) {
            }
            try {
                a[df.NEUTRAL_EXPRESSION_ONLY.ordinal()] = 3;
            } catch (NoSuchFieldError unused3) {
            }
            try {
                a[df.BLURRY_ONLY.ordinal()] = 4;
            } catch (NoSuchFieldError unused4) {
            }
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void j() {
        d();
        this.f.getViewTreeObserver().addOnGlobalLayoutListener(this.w);
    }

    public final void a() {
        Resources resources;
        int identifier;
        if (this.m != null) {
            float height = r0.getHeight() / this.m.getWidth();
            if (height <= 1.776f) {
                float height2 = this.m.getHeight() / 1.776f;
                if (this.m.getWidth() - height2 > SelfieScan.RECOGNITION_FAIL_RESULT) {
                    this.m = Bitmap.createBitmap(this.m, (int) ((r1.getWidth() - height2) / 2.0f), 0, (int) height2, this.m.getHeight());
                }
            } else if (height > 1.776f) {
                float width = this.m.getWidth() * 1.776f;
                if (this.m.getHeight() - width > SelfieScan.RECOGNITION_FAIL_RESULT) {
                    this.m = Bitmap.createBitmap(this.m, 0, (int) ((r1.getHeight() - width) / 2.0f), this.m.getWidth(), (int) width);
                }
            }
            int width2 = (int) (((double) this.m.getWidth()) * 0.75d);
            int height3 = (int) (((double) this.m.getHeight()) * 0.75d);
            Bitmap bitmap = this.m;
            this.m = Bitmap.createBitmap(bitmap, (bitmap.getWidth() - width2) / 2, (this.m.getHeight() - height3) / 2, width2, height3);
            this.u = C1189.m4797(getResources(), this.m);
        }
        if (e(du.YOUR_ZOOM_IMAGE_OVERRIDE) && (identifier = (resources = getResources()).getIdentifier("zoom_your_zoom_image_override", "drawable", getActivity().getPackageName())) != 0) {
            Bitmap bitmapDecodeResource = BitmapFactory.decodeResource(resources, identifier);
            this.m = bitmapDecodeResource;
            this.u = C1189.m4797(resources, bitmapDecodeResource);
        }
        if (!bj.i) {
            this.b.setScaleX(-1.0f);
        }
        this.b.setImageDrawable(this.u);
    }

    public final TextView c() {
        return this.f;
    }

    public final void d() {
        float f;
        float f2;
        double d;
        float fC = dm.c() * dm.b();
        int iA = pg.a.a();
        int iRound = Math.round(((Integer) dm.e(pg.a.a(), iA, 1933108801, new Object[0], pg.a.a(), -1933108792, pg.a.a())).intValue() * dm.c());
        int measuredHeight = this.q.getMeasuredHeight();
        if (Locale.getDefault().getLanguage().equals("ar")) {
            f = 0.08f;
            f2 = 0.09f;
        } else {
            f = 0.06f;
            f2 = 0.07f;
        }
        float f3 = measuredHeight;
        int iRound2 = Math.round(f * f3);
        if (dm.a() < 1.4d && dq.b().heightPixels < 900) {
            iRound2 = Math.round(f3 * f2);
        }
        int iRound3 = (int) Math.round(((double) iRound2) * 0.85d);
        int iRound4 = (int) Math.round(((double) iRound3) * 0.85d);
        int height = this.p.getHeight() + iRound4 + ((ViewGroup.MarginLayoutParams) ((LinearLayout.LayoutParams) this.k.getLayoutParams())).topMargin;
        this.s.setLayoutParams(new LinearLayout.LayoutParams(-1, -2));
        LinearLayout.LayoutParams layoutParams = (LinearLayout.LayoutParams) this.t.getLayoutParams();
        ((ViewGroup.LayoutParams) layoutParams).height = height;
        layoutParams.weight = SelfieScan.RECOGNITION_FAIL_RESULT;
        this.t.setLayoutParams(layoutParams);
        LinearLayout.LayoutParams layoutParams2 = (LinearLayout.LayoutParams) this.f.getLayoutParams();
        ((ViewGroup.LayoutParams) layoutParams2).height = iRound2;
        layoutParams2.weight = SelfieScan.RECOGNITION_FAIL_RESULT;
        this.f.setLayoutParams(layoutParams2);
        LinearLayout.LayoutParams layoutParams3 = (LinearLayout.LayoutParams) this.j.getLayoutParams();
        ((ViewGroup.LayoutParams) layoutParams3).height = iRound3;
        layoutParams3.weight = SelfieScan.RECOGNITION_FAIL_RESULT;
        this.j.setLayoutParams(layoutParams3);
        this.h.setLayoutParams(layoutParams3);
        this.f95864g.setLayoutParams(layoutParams3);
        LinearLayout.LayoutParams layoutParams4 = (LinearLayout.LayoutParams) this.k.getLayoutParams();
        ((ViewGroup.LayoutParams) layoutParams4).height = iRound4;
        this.k.setLayoutParams(layoutParams4);
        this.n.setLayoutParams(layoutParams4);
        int width = this.f.getWidth();
        if (dm.bn()) {
            int iRound5 = Math.round(bh.a(35) * fC);
            int[] iArr = new int[2];
            this.y.getLocationInWindow(iArr);
            d = 0.85d;
            int iRound6 = (int) (((long) (iArr[1] + iRound5)) - Math.round(((double) iRound) / 2.0d));
            int[] iArr2 = new int[2];
            this.f.getLocationInWindow(iArr2);
            if (iArr2[1] < iRound6) {
                width -= iRound5 << 1;
            }
        } else {
            d = 0.85d;
        }
        bh.a aVar = new bh.a(width, iRound2);
        bh.a aVar2 = new bh.a(this.j.getWidth(), iRound3);
        bh.a aVar3 = new bh.a(this.h.getWidth(), iRound3);
        bh.a aVar4 = new bh.a(this.f95864g.getWidth(), iRound3);
        bh.a aVar5 = new bh.a(this.k.getWidth(), iRound4);
        bh.a aVar6 = new bh.a(this.n.getWidth(), iRound4);
        int iRound7 = Math.round(bh.d(8));
        int iRound8 = Math.round(bh.d(40));
        int iRound9 = Math.round(bh.d(5));
        int iRound10 = Math.round(bh.d(36));
        int iC = bh.c(this.f, aVar, iRound7, iRound8);
        int iC2 = bh.c(this.j, aVar2, iRound9, iRound10);
        int iC3 = bh.c(this.h, aVar3, iRound9, iRound10);
        int iC4 = bh.c(this.f95864g, aVar4, iRound9, iRound10);
        int iC5 = bh.c(this.k, aVar5, iRound9, iRound10);
        int iC6 = bh.c(this.n, aVar6, iRound9, iRound10);
        int iRound11 = (int) Math.round(((double) iC) * d);
        if (iC2 >= iRound11) {
            iC2 = iRound11;
        }
        if (FaceTecSDK.d.enableOfficialIDPhoto) {
            iC4 = iC2;
        } else {
            if (this.h.getText().toString().isEmpty() || iC3 >= iC2) {
                iC3 = iC2;
            }
            if (this.f95864g.getText().toString().isEmpty() || iC4 >= iC3) {
                iC4 = iC3;
            }
        }
        int iRound12 = (int) Math.round(((double) iC4) * d);
        if (iC5 >= iRound12) {
            iC5 = iRound12;
        }
        if (iC6 >= iC5) {
            iC6 = iC5;
        }
        this.f.setTextSize(0, iC);
        float f4 = iC4;
        this.j.setTextSize(0, f4);
        this.h.setTextSize(0, f4);
        this.f95864g.setTextSize(0, f4);
        float f5 = iC6;
        this.k.setTextSize(0, f5);
        this.n.setTextSize(0, f5);
        this.f.getLayoutParams().height = -2;
        this.j.getLayoutParams().height = -2;
        this.h.getLayoutParams().height = -2;
        this.f95864g.getLayoutParams().height = -2;
        this.k.getLayoutParams().height = -2;
        this.n.getLayoutParams().height = -2;
        this.t.getLayoutParams().height = -2;
    }

    public final void e() {
        TextView textView = this.f;
        if (textView != null) {
            textView.getViewTreeObserver().removeOnGlobalLayoutListener(this.w);
        }
    }

    @Override // com.facetec.sdk.au, android.app.Fragment
    public final void onCreate(Bundle bundle) {
        super.onCreate(bundle);
    }

    @Override // android.app.Fragment
    public final View onCreateView(LayoutInflater layoutInflater, ViewGroup viewGroup, Bundle bundle) {
        return layoutInflater.inflate(R.layout.facetec_retry_screen_center_content_fragment, viewGroup, false);
    }

    @Override // android.app.Fragment
    public final void onDestroy() {
        super.onDestroy();
        e();
    }

    @Override // android.app.Fragment
    public final void onStart() {
        super.onStart();
        b(new Runnable() { // from class: com.facetec.sdk.凤弓
            @Override // java.lang.Runnable
            public final void run() {
                this.f7163.j();
            }
        }, 100L);
    }

    @Override // android.app.Fragment
    public final void onViewCreated(View view, Bundle bundle) throws Throwable {
        df dfVarK;
        super.onViewCreated(view, bundle);
        this.q = (LinearLayout) view.findViewById(R.id.contentLayout);
        this.f = (TextView) view.findViewById(R.id.headerTextView);
        this.j = (TextView) view.findViewById(R.id.messageTextView);
        this.h = (TextView) view.findViewById(R.id.instructionMessage1TextView);
        this.f95864g = (TextView) view.findViewById(R.id.instructionMessage2TextView);
        this.n = (TextView) view.findViewById(R.id.yourZoomSubimageTextView);
        this.k = (TextView) view.findViewById(R.id.idealZoomSubimageTextView);
        this.b = (ImageView) view.findViewById(R.id.yourZoomImage);
        this.p = (ImageView) view.findViewById(R.id.idealZoomImage);
        this.c = (ImageView) view.findViewById(R.id.idealZoomImageBorder);
        this.a = (ImageView) view.findViewById(R.id.yourZoomImageBorder);
        this.d = (ImageView) view.findViewById(R.id.idealOval);
        this.o = (dn) view.findViewById(R.id.idealImageSlideshowView);
        this.y = (TextView) view.findViewById(R.id.cancelButtonSpacer);
        this.e = (LinearLayout) view.findViewById(R.id.idealZoomLayout);
        this.i = (LinearLayout) view.findViewById(R.id.yourZoomLayout);
        this.t = (LinearLayout) view.findViewById(R.id.sideBySideLayout);
        this.s = (LinearLayout) view.findViewById(R.id.headerAndSubheaderLayout);
        this.j.setImportantForAccessibility(1);
        this.h.setImportantForAccessibility(1);
        this.f95864g.setImportantForAccessibility(1);
        if (((int[]) dm.e(pg.a.a(), pg.a.a(), -1644736691, new Object[0], pg.a.a(), 1644736699, pg.a.a())).length != 0) {
            this.p.setVisibility(4);
        }
        dq.b(this.f, dm.a(true, false));
        TextView textView = this.j;
        Boolean bool = Boolean.TRUE;
        dq.b(textView, (String) dm.e(pg.a.a(), pg.a.a(), 1429122379, new Object[]{bool, Boolean.FALSE}, pg.a.a(), -1429122365, pg.a.a()));
        String strA = dm.a(true);
        String strE = dm.e(true);
        FaceTecSessionActivity faceTecSessionActivity = (FaceTecSessionActivity) getActivity();
        if (faceTecSessionActivity == null || (dfVarK = faceTecSessionActivity.L) == null) {
            dfVarK = cv.k();
        }
        String str = "";
        if (FaceTecSDK.d.enableOfficialIDPhoto) {
            strA = dm.be();
            this.j.setText(dm.aW());
            dq.b(this.j, dm.aW());
            this.n.setText(dm.bd());
            this.k.setText(dm.bc());
            this.h.setMaxLines(3);
            this.d.setVisibility(8);
            this.f95864g.setVisibility(8);
        } else {
            int i = AnonymousClass3.a[dfVarK.ordinal()];
            if (i != 2) {
                if (i == 3) {
                    this.f95864g.setVisibility(8);
                } else if (i == 4) {
                    strA = (String) dm.e(pg.a.a(), pg.a.a(), -842338935, new Object[]{bool}, pg.a.a(), 842338966, pg.a.a());
                    this.f95864g.setVisibility(8);
                }
                strE = "";
            } else {
                this.h.setVisibility(8);
                strA = "";
            }
            this.n.setText(dm.d(true));
            this.k.setText(dm.c(true));
            str = strE;
        }
        this.h.setText(strA);
        this.f95864g.setText(str);
        this.n.setImportantForAccessibility(2);
        this.k.setImportantForAccessibility(2);
        this.i.setImportantForAccessibility(1);
        this.i.setContentDescription(this.n.getText());
        this.e.setImportantForAccessibility(1);
        this.e.setContentDescription(this.k.getText());
        this.f.setTypeface((Typeface) dm.e(pg.a.a(), pg.a.a(), -757228659, new Object[0], pg.a.a(), 757228698, pg.a.a()));
        this.j.setTypeface(dm.L());
        this.h.setTypeface(dm.R());
        this.f95864g.setTypeface(dm.R());
        this.n.setTypeface(dm.R());
        this.k.setTypeface(dm.R());
        if (!FaceTecSDK.d.enableOfficialIDPhoto) {
            this.f.setLineSpacing(SelfieScan.RECOGNITION_FAIL_RESULT, 1.1f);
            this.j.setLineSpacing(SelfieScan.RECOGNITION_FAIL_RESULT, 1.1f);
            this.h.setLineSpacing(SelfieScan.RECOGNITION_FAIL_RESULT, 1.1f);
            this.f95864g.setLineSpacing(SelfieScan.RECOGNITION_FAIL_RESULT, 1.1f);
        }
        this.f.setTextColor(dm.j(getActivity()));
        this.j.setTextColor(((Integer) dm.e(pg.a.a(), pg.a.a(), 877608522, new Object[]{getActivity()}, pg.a.a(), -877608482, pg.a.a())).intValue());
        this.h.setTextColor(((Integer) dm.e(pg.a.a(), pg.a.a(), 877608522, new Object[]{getActivity()}, pg.a.a(), -877608482, pg.a.a())).intValue());
        this.f95864g.setTextColor(((Integer) dm.e(pg.a.a(), pg.a.a(), 877608522, new Object[]{getActivity()}, pg.a.a(), -877608482, pg.a.a())).intValue());
        this.n.setTextColor(((Integer) dm.e(pg.a.a(), pg.a.a(), 877608522, new Object[]{getActivity()}, pg.a.a(), -877608482, pg.a.a())).intValue());
        this.k.setTextColor(((Integer) dm.e(pg.a.a(), pg.a.a(), 877608522, new Object[]{getActivity()}, pg.a.a(), -877608482, pg.a.a())).intValue());
        float fB = dm.b() * dm.c();
        float f = 28.0f * fB;
        float f2 = fB * 20.0f;
        this.f.setTextSize(2, f);
        this.j.setTextSize(2, f2);
        this.h.setTextSize(2, f2);
        this.f95864g.setTextSize(2, f2);
        this.n.setTextSize(2, f2);
        this.k.setTextSize(2, f2);
        this.m = null;
        this.u = null;
        if (faceTecSessionActivity == null) {
            return;
        }
        Bitmap bitmap = faceTecSessionActivity.I;
        if (bitmap != null) {
            this.m = bitmap;
        }
        Resources resources = getResources();
        getActivity();
        Bitmap bitmapDecodeResource = BitmapFactory.decodeResource(resources, dm.aR());
        a();
        this.p.setImageDrawable(C1189.m4797(resources, bitmapDecodeResource));
        GradientDrawable gradientDrawable = new GradientDrawable();
        this.l = gradientDrawable;
        gradientDrawable.setCornerRadius(bh.a((int) (dm.C() * dm.c())));
        this.l.setStroke((int) bh.a(Math.max(dm.k() == 0 ? 0 : 1, (int) (dm.k() * dm.c()))), ((Integer) dm.e(pg.a.a(), pg.a.a(), 1009688708, new Object[]{getActivity()}, pg.a.a(), -1009688672, pg.a.a())).intValue());
        this.l.setColor(0);
        RoundedBitmapDrawable roundedBitmapDrawableM4797 = C1189.m4797(resources, bitmapDecodeResource);
        roundedBitmapDrawableM4797.setAlpha(0);
        this.c.setImageDrawable(roundedBitmapDrawableM4797);
        this.c.setBackground(this.l);
        this.a.setImageDrawable(roundedBitmapDrawableM4797);
        this.a.setBackground(this.l);
        this.b.setBackground(this.l);
        this.p.setBackground(this.l);
        this.b.setClipToOutline(true);
        this.p.setClipToOutline(true);
        ImageView imageView = this.b;
        ViewOutlineProvider viewOutlineProvider = ViewOutlineProvider.BACKGROUND;
        imageView.setOutlineProvider(viewOutlineProvider);
        this.p.setOutlineProvider(viewOutlineProvider);
        this.d.setColorFilter(dm.q(getActivity()), PorterDuff.Mode.SRC_IN);
        float fB2 = dm.b() * dm.c();
        int iIntValue = ((Integer) dm.e(pg.a.a(), pg.a.a(), 1933108801, new Object[0], pg.a.a(), -1933108792, pg.a.a())).intValue();
        int iRound = Math.round(iIntValue / 2.0f);
        int iRound2 = (int) Math.round(((double) faceTecSessionActivity.n) * 0.45d);
        if (this.m != null) {
            float height = r10.getHeight() / this.m.getWidth();
            if (dm.a() >= height) {
                iRound2 = Math.round((Math.round(Math.round(faceTecSessionActivity.o) - (r5 * 3.0f)) / 2.0f) * height);
            }
        }
        ((ViewGroup.MarginLayoutParams) ((LinearLayout.LayoutParams) this.f.getLayoutParams())).bottomMargin = Math.round(bh.a(5) * fB2);
        int iRound3 = Math.round(bh.a(5) * fB2);
        ((ViewGroup.MarginLayoutParams) ((LinearLayout.LayoutParams) this.k.getLayoutParams())).topMargin = iRound3;
        ((ViewGroup.MarginLayoutParams) ((LinearLayout.LayoutParams) this.n.getLayoutParams())).topMargin = iRound3;
        ((ViewGroup.MarginLayoutParams) ((LinearLayout.LayoutParams) this.t.getLayoutParams())).topMargin = Math.round(bh.a(5) * fB2);
        ((FrameLayout) view.findViewById(R.id.idealZoomImageContainer)).getLayoutParams().height = iRound2;
        ((FrameLayout) view.findViewById(R.id.yourZoomImageContainer)).getLayoutParams().height = iRound2;
        ((LinearLayout.LayoutParams) this.i.getLayoutParams()).setMarginEnd(iRound);
        ((LinearLayout.LayoutParams) this.e.getLayoutParams()).setMarginStart(iRound);
        view.setPadding(iIntValue, iIntValue, iIntValue, 0);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void c(final int i, final int i2, final Runnable runnable) {
        this.e.animate().alpha(1.0f).setDuration(i).setStartDelay(i2).setListener(null).withEndAction(new au.c(new Runnable() { // from class: com.facetec.sdk.凤帝
            @Override // java.lang.Runnable
            public final void run() {
                this.f7155.a(i, i2, runnable);
            }
        })).start();
    }

    private static boolean e(du duVar) {
        for (int i = 0; i < ds.b.length(); i++) {
            try {
                JSONObject jSONObject = ds.b.getJSONObject(i);
                String string = jSONObject.getString("overrideKey");
                du duVar2 = (du) jSONObject.get("type");
                if (FaceTecSDK.d.r.get(string) != null && FaceTecSDK.d.r.get(string).equals(jSONObject.getString("overrideValue")) && duVar2 == duVar) {
                    return true;
                }
            } catch (Exception unused) {
            }
        }
        return false;
    }

    public final void e(final Runnable runnable) {
        if (ed.b()) {
            this.j.setAlpha(1.0f);
            this.f.setAlpha(1.0f);
            this.i.setAlpha(1.0f);
            this.e.setAlpha(1.0f);
            this.f95864g.setAlpha(1.0f);
            this.h.setAlpha(1.0f);
            new au.c(runnable).run();
            return;
        }
        this.j.animate().alpha(1.0f).setDuration(500L).setListener(null).start();
        ViewPropertyAnimator listener = this.f.animate().alpha(1.0f).setDuration(500L).setListener(null);
        final int i = HttpStatusCodeRange.DEFAULT_MIN;
        final int i2 = EnumC41897g.SDK_ASSET_TRANSFER_ICON_CIRCLE_VALUE;
        listener.withEndAction(new au.c(new Runnable() { // from class: com.facetec.sdk.凤山
            @Override // java.lang.Runnable
            public final void run() {
                this.f7151.e(i, i2, runnable);
            }
        })).start();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void e(final int i, final int i2, final Runnable runnable) {
        this.i.animate().alpha(1.0f).setDuration(i).setStartDelay(i2).setListener(null).withEndAction(new au.c(new Runnable() { // from class: com.facetec.sdk.凤庙
            @Override // java.lang.Runnable
            public final void run() {
                this.f7159.c(i, i2, runnable);
            }
        })).start();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void a(int i, int i2, Runnable runnable) {
        long j = i;
        long j2 = i2;
        this.f95864g.animate().alpha(1.0f).setDuration(j).setStartDelay(j2).setListener(null).start();
        this.h.animate().alpha(1.0f).setDuration(j).setStartDelay(j2).setListener(null).withEndAction(new au.c(runnable));
    }
}