package com.facetec.sdk;

import android.animation.Animator;
import android.graphics.RectF;
import android.os.Bundle;
import android.os.Handler;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import androidx.annotation.NonNull;
import com.facetec.sdk.FaceTecVocalGuidanceCustomization;
import com.facetec.sdk.au;
import com.facetec.sdk.bo;
import com.facetec.sdk.ed;
import com.facetec.sdk.pg;
import com.incode.welcome_sdk.modules.SelfieScan;
import com.plaid.internal.EnumC41897g;
import io.sentry.HttpStatusCodeRange;
import java.util.ArrayList;
import java.util.Arrays;

/* JADX INFO: loaded from: classes4.dex */
public final class dd extends bg {
    static boolean n = false;
    dc o;
    private bo q;
    private Handler r;
    int k = 0;
    private int t = HttpStatusCodeRange.DEFAULT_MIN;
    private int s = EnumC41897g.SDK_ASSET_TRANSFER_ICON_CIRCLE_VALUE;

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void A() {
        bm bmVarJ = j();
        if (bmVarJ != null) {
            bmVarJ.g();
            t.d(bmVarJ, c.GET_READY_IM_READY_PRESSED_RETRY, null, null);
        }
        m();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void B() {
        bm bmVarJ = j();
        if (bmVarJ != null) {
            bmVarJ.l();
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void C() {
        m();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void E() {
        dp.e(this.a, R.string.FaceTec_action_im_ready);
        this.a.animate().alpha(1.0f).setDuration(500L).setStartDelay(0L).setListener(null).start();
        a(true, HttpStatusCodeRange.DEFAULT_MIN, 0);
        c(new Runnable() { // from class: com.facetec.sdk.凤日
            @Override // java.lang.Runnable
            public final void run() {
                this.f7165.I();
            }
        }, 500L);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void F() {
        bi biVarF = f();
        if (biVarF != null) {
            biVarF.x();
        }
        RectF rectFF = this.d.f();
        this.q = bo.e(R.string.FaceTec_instructions_header_ready_1, R.string.FaceTec_instructions_message_ready_2, bo.e.READY_OVAL, rectFF.top, rectFF.bottom, this.a.getId());
        if (this.k != 1) {
            if (this.o == null) {
                return;
            }
            dp.e(this.a, R.string.FaceTec_action_try_again);
            this.o.e(new au.c(new Runnable() { // from class: com.facetec.sdk.凤礼
                @Override // java.lang.Runnable
                public final void run() {
                    this.f7177.G();
                }
            }));
            return;
        }
        getFragmentManager().beginTransaction().setCustomAnimations(R.animator.facetec_no_delay_fade_in, 0).replace(R.id.centerContentFrameLayout, this.q).commitAllowingStateLoss();
        dp.e(this.a, R.string.FaceTec_action_im_ready);
        this.d.e.setAlpha(255);
        this.d.a();
        b(new Runnable() { // from class: com.facetec.sdk.凤玉
            @Override // java.lang.Runnable
            public final void run() {
                this.f7175.K();
            }
        }, 500L);
        this.a.setAlpha(SelfieScan.RECOGNITION_FAIL_RESULT);
        this.a.setVisibility(0);
        this.a.animate().alpha(1.0f).setDuration(500L).setStartDelay(300L).setListener(null).withEndAction(new au.c(new Runnable() { // from class: com.facetec.sdk.凤王
            @Override // java.lang.Runnable
            public final void run() {
                this.f7176.M();
            }
        })).start();
        a(true, HttpStatusCodeRange.DEFAULT_MIN, EnumC41897g.SDK_ASSET_TRANSFER_ICON_CIRCLE_VALUE);
        if (ed.b()) {
            this.a.setEnabled(true);
        } else {
            x();
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void G() {
        this.o.c().setImportantForAccessibility(1);
        this.o.c().setAccessibilityHeading(true);
        this.a.setImportantForAccessibility(1);
        this.c.setImportantForAccessibility(1);
        this.o.c().setScreenReaderFocusable(true);
        this.o.c().sendAccessibilityEvent(8);
        this.a.setAlpha(SelfieScan.RECOGNITION_FAIL_RESULT);
        this.a.setVisibility(0);
        this.a.animate().alpha(1.0f).setDuration(500L).setStartDelay(300L).setListener(null).withEndAction(new au.c(new Runnable() { // from class: com.facetec.sdk.凤符
            @Override // java.lang.Runnable
            public final void run() {
                this.f7181.H();
            }
        })).start();
        a(true, HttpStatusCodeRange.DEFAULT_MIN, EnumC41897g.SDK_ASSET_TRANSFER_ICON_CIRCLE_VALUE);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void H() {
        int iA = pg.a.a();
        if (((int[]) dm.e(pg.a.a(), iA, -1644736691, new Object[0], pg.a.a(), 1644736699, pg.a.a())).length != 0) {
            c(new Runnable() { // from class: com.facetec.sdk.凤祖
                @Override // java.lang.Runnable
                public final void run() {
                    this.f7178.J();
                }
            }, 10L);
        }
        c(new Runnable() { // from class: com.facetec.sdk.凤神
            @Override // java.lang.Runnable
            public final void run() {
                this.f7179.L();
            }
        }, 300L);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void I() {
        this.c.setEnabled(true);
        e(true);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void J() {
        dn dnVar = this.o.o;
        if (dnVar.d.length != 0) {
            dnVar.c = 0;
            dnVar.b = true;
            dnVar.b();
            dnVar.i();
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void K() {
        this.d.d(HttpStatusCodeRange.DEFAULT_MIN);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void L() {
        if (f() != null) {
            this.a.b(true, true);
            this.c.setEnabled(true);
            e(true);
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void M() {
        c(new Runnable() { // from class: com.facetec.sdk.凤水
            @Override // java.lang.Runnable
            public final void run() {
                this.f7171.N();
            }
        }, 300L);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void N() {
        if (f() != null) {
            D();
            this.c.setEnabled(true);
            e(true);
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void Q() {
        bm bmVarJ = j();
        if (bmVarJ != null) {
            bmVarJ.l();
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void R() {
        bm bmVarJ = j();
        if (bmVarJ != null) {
            bmVarJ.l();
        }
    }

    private void b(bo boVar) {
        if (boVar == null) {
            return;
        }
        getFragmentManager().beginTransaction().setCustomAnimations(R.anim.facetec_slide_in_left, R.anim.facetec_slide_out_left).replace(R.id.centerContentFrameLayout, boVar, "centerContentFrameLayout").commitAllowingStateLoss();
    }

    /* JADX INFO: Access modifiers changed from: private */
    /* JADX INFO: renamed from: p, reason: merged with bridge method [inline-methods] */
    public void D() {
        this.a.setImportantForAccessibility(1);
        this.c.setImportantForAccessibility(1);
    }

    @NonNull
    public static dd r() {
        dd ddVar = new dd();
        ddVar.setArguments(new Bundle());
        n = false;
        ddVar.m = true;
        return ddVar;
    }

    private void u() {
        Handler handler = this.r;
        if (handler != null) {
            handler.removeCallbacksAndMessages(null);
            this.r = null;
        }
    }

    private void v() {
        dn dnVar;
        dc dcVar = this.o;
        if (dcVar == null || (dnVar = dcVar.o) == null) {
            return;
        }
        dnVar.c();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void w() {
        dc dcVar = this.o;
        if (dcVar == null) {
            bo boVar = this.q;
            if (boVar != null) {
                boVar.b(false);
                return;
            }
            return;
        }
        if (dcVar.b()) {
            bh.b(new ArrayList(Arrays.asList(dcVar.f)), dcVar.f.getCurrentTextColor(), dm.j(dcVar.getActivity())).start();
            int currentTextColor = dcVar.j.getCurrentTextColor();
            Object[] objArr = {dcVar.getActivity()};
            bh.b(new ArrayList(Arrays.asList(dcVar.j, dcVar.h, dcVar.f95864g, dcVar.k, dcVar.n)), currentTextColor, ((Integer) dm.e(pg.a.a(), pg.a.a(), 877608522, objArr, pg.a.a(), -877608482, pg.a.a())).intValue()).start();
            int iB = dq.b(dcVar.getActivity(), FaceTecSDK.d.i.retryScreenImageBorderColor);
            Object[] objArr2 = {dcVar.getActivity()};
            bh.e(new ArrayList(Arrays.asList(dcVar.a, dcVar.c)), dcVar.l, dm.k(), iB, ((Integer) dm.e(pg.a.a(), pg.a.a(), 1009688708, objArr2, pg.a.a(), -1009688672, pg.a.a())).intValue()).start();
            bh.b(dcVar.d, dq.b(dcVar.getActivity(), FaceTecSDK.d.i.retryScreenOvalStrokeColor), dm.q(dcVar.getActivity())).start();
        }
    }

    private void x() {
        new Handler().postDelayed(new au.c(new Runnable() { // from class: com.facetec.sdk.凤海
            @Override // java.lang.Runnable
            public final void run() {
                this.f7172.z();
            }
        }), 4500L);
    }

    private void y() throws Throwable {
        if (ed.b()) {
            this.a.b(true, false);
        } else {
            x();
        }
        a(false, HttpStatusCodeRange.DEFAULT_MIN, 0);
        this.a.animate().alpha(SelfieScan.RECOGNITION_FAIL_RESULT).setDuration(500L).setStartDelay(0L).setListener(null).start();
        c(new Runnable() { // from class: com.facetec.sdk.凤星
            @Override // java.lang.Runnable
            public final void run() {
                this.f7166.E();
            }
        }, 800L);
        t.d = ao.m;
        b(this.q);
        b(new Runnable() { // from class: com.facetec.sdk.凤月
            @Override // java.lang.Runnable
            public final void run() {
                this.f7167.D();
            }
        }, 1000L);
        this.d.d();
        t.d(j(), c.GET_READY_IM_READY_SHOWN_AND_READY_RETRY, null, null);
        t.b(dh.RETRY_GET_READY);
        bg.s();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void z() {
        this.h = true;
        if (this.a.isEnabled()) {
            return;
        }
        this.a.b(true, true);
    }

    @Override // com.facetec.sdk.bg
    public final void a() {
        bm bmVarJ = j();
        if (bmVarJ != null && FaceTecSDK.d.vocalGuidanceCustomization.mode == FaceTecVocalGuidanceCustomization.VocalGuidanceMode.FULL_VOCAL_GUIDANCE) {
            ed.d(bmVarJ, ed.d.RETRY);
        }
        dc dcVar = this.o;
        if (dcVar != null) {
            dcVar.f.setAlpha(SelfieScan.RECOGNITION_FAIL_RESULT);
            dcVar.j.setAlpha(SelfieScan.RECOGNITION_FAIL_RESULT);
            dcVar.i.setAlpha(SelfieScan.RECOGNITION_FAIL_RESULT);
            dcVar.e.setAlpha(SelfieScan.RECOGNITION_FAIL_RESULT);
            dcVar.h.setAlpha(SelfieScan.RECOGNITION_FAIL_RESULT);
            dcVar.f95864g.setAlpha(SelfieScan.RECOGNITION_FAIL_RESULT);
            this.a.setVisibility(4);
            this.a.setAlpha(SelfieScan.RECOGNITION_FAIL_RESULT);
        }
        this.f.setVisibility(8);
        this.a.setEnabled(false);
        this.c.setEnabled(false);
        e(false);
        be beVar = this.d;
        int iA = pg.a.a();
        beVar.b(((Integer) dm.e(pg.a.a(), iA, -298147150, new Object[0], pg.a.a(), 298147185, pg.a.a())).intValue(), 0, 0);
        if (this.r == null) {
            Handler handler = new Handler();
            this.r = handler;
            handler.postDelayed(new au.c(new Runnable() { // from class: com.facetec.sdk.凤火
                @Override // java.lang.Runnable
                public final void run() {
                    this.f7173.Q();
                }
            }), 600000L);
        }
        c(new Runnable() { // from class: com.facetec.sdk.凤灵
            @Override // java.lang.Runnable
            public final void run() {
                this.f7174.F();
            }
        });
    }

    @Override // com.facetec.sdk.bg
    public final void c() {
        c(new Runnable() { // from class: com.facetec.sdk.凤气
            @Override // java.lang.Runnable
            public final void run() {
                this.f7170.w();
            }
        });
        this.d.b();
    }

    @Override // com.facetec.sdk.bg
    public final void d() throws Throwable {
        if (this.k == 0) {
            y();
            cv.W();
            this.k++;
        } else {
            bm bmVarJ = j();
            if (bmVarJ != null) {
                bmVarJ.m();
            }
            u();
            v();
        }
    }

    @Override // com.facetec.sdk.bg
    public final void e() throws Throwable {
        v();
        if (this.k == 0) {
            y();
            cv.W();
            if (FaceTecSDK.d.vocalGuidanceCustomization.mode == FaceTecVocalGuidanceCustomization.VocalGuidanceMode.FULL_VOCAL_GUIDANCE) {
                ed.d(j(), ed.d.GET_READY_FRAME_YOUR_FACE_AUTOMATIC);
            }
            c(new Runnable() { // from class: com.facetec.sdk.凤木
                @Override // java.lang.Runnable
                public final void run() {
                    this.f7168.C();
                }
            }, 1000L);
        } else {
            n = true;
            u();
            d(new au.c(new Runnable() { // from class: com.facetec.sdk.凤梦
                @Override // java.lang.Runnable
                public final void run() {
                    this.f7169.A();
                }
            }), HttpStatusCodeRange.DEFAULT_MIN);
        }
        this.k++;
    }

    @Override // com.facetec.sdk.bg
    public final boolean h() {
        return this.k == 1;
    }

    @Override // com.facetec.sdk.bg
    public final void i() throws Throwable {
        ImageView imageViewG = g();
        if (imageViewG == null || !imageViewG.isEnabled() || n) {
            return;
        }
        d();
    }

    @Override // com.facetec.sdk.bg, com.facetec.sdk.au, android.app.Fragment
    public final void onCreate(Bundle bundle) throws Throwable {
        super.onCreate(bundle);
        Handler handler = new Handler();
        this.r = handler;
        handler.postDelayed(new au.c(new Runnable() { // from class: com.facetec.sdk.凤战
            @Override // java.lang.Runnable
            public final void run() {
                this.f7164.R();
            }
        }), 600000L);
        if (cv.a(j(), false).length == 0) {
            t.d = ao.m;
            this.k = 1;
            t.b(dh.RETRY_GET_READY);
            bg.s();
            return;
        }
        t.d = ao.l;
        this.o = new dc();
        getFragmentManager().beginTransaction().setCustomAnimations(R.animator.facetec_no_delay_fade_in, 0).add(R.id.centerContentFrameLayout, this.o).commitAllowingStateLoss();
        t.b(dh.RETRY_SIDE_BY_SIDE);
        cc.c = true;
        cv.C(true);
    }

    @Override // com.facetec.sdk.bg, android.app.Fragment
    public final /* bridge */ /* synthetic */ Animator onCreateAnimator(int i, boolean z, int i2) {
        return super.onCreateAnimator(i, z, i2);
    }

    @Override // com.facetec.sdk.bg, android.app.Fragment
    public final /* bridge */ /* synthetic */ View onCreateView(LayoutInflater layoutInflater, ViewGroup viewGroup, Bundle bundle) {
        return super.onCreateView(layoutInflater, viewGroup, bundle);
    }

    @Override // com.facetec.sdk.bg, android.app.Fragment
    public final /* bridge */ /* synthetic */ void onDestroy() {
        super.onDestroy();
    }

    @Override // com.facetec.sdk.bg, android.app.Fragment
    public final void onPause() {
        super.onPause();
        u();
        v();
    }

    @Override // com.facetec.sdk.bg, android.app.Fragment
    public final /* bridge */ /* synthetic */ void onViewCreated(View view, Bundle bundle) {
        super.onViewCreated(view, bundle);
    }

    public final boolean q() {
        return this.k == 1;
    }

    public final void t() {
        if (this.r == null) {
            this.r = new Handler();
        }
        this.r.postDelayed(new au.c(new Runnable() { // from class: com.facetec.sdk.凤祭
            @Override // java.lang.Runnable
            public final void run() {
                this.f7180.B();
            }
        }), 600000L);
    }
}