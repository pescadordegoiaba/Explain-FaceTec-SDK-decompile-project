package com.facetec.sdk;

import android.animation.Animator;
import android.animation.AnimatorSet;
import android.animation.ObjectAnimator;
import android.animation.TimeInterpolator;
import android.animation.ValueAnimator;
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.PorterDuff;
import android.graphics.PorterDuffXfermode;
import android.graphics.RectF;
import android.os.Build;
import android.os.Handler;
import android.os.SystemClock;
import android.util.AttributeSet;
import android.util.Property;
import android.view.View;
import android.view.ViewConfiguration;
import android.view.animation.AccelerateDecelerateInterpolator;
import android.view.animation.DecelerateInterpolator;
import android.view.animation.OvershootInterpolator;
import com.facetec.sdk.pg;
import com.incode.welcome_sdk.modules.SelfieScan;
import io.sentry.protocol.ViewHierarchyNode;

/* JADX INFO: loaded from: classes4.dex */
class de extends View {
    private static final int s = (int) bh.a(10);
    protected Paint a;
    protected RectF b;
    RectF c;
    protected Paint d;
    private boolean e;
    protected RectF f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    protected final float f95865g;
    protected final float h;
    protected RectF i;
    AnimatorSet j;
    private Paint k;
    AnimatorSet l;
    private d m;
    AnimatorSet n;
    private AnimatorSet o;
    private boolean p;
    private final Handler q;
    private Animator r;

    /* JADX INFO: renamed from: com.facetec.sdk.de$5, reason: invalid class name */
    public static /* synthetic */ class AnonymousClass5 {
        static final /* synthetic */ int[] a;

        static {
            int[] iArr = new int[FaceTecExitAnimationStyle.values().length];
            a = iArr;
            try {
                iArr[FaceTecExitAnimationStyle.NONE.ordinal()] = 1;
            } catch (NoSuchFieldError unused) {
            }
            try {
                a[FaceTecExitAnimationStyle.RIPPLE_IN.ordinal()] = 2;
            } catch (NoSuchFieldError unused2) {
            }
            try {
                a[FaceTecExitAnimationStyle.RIPPLE_OUT.ordinal()] = 3;
            } catch (NoSuchFieldError unused3) {
            }
            try {
                a[FaceTecExitAnimationStyle.CIRCLE_FADE.ordinal()] = 4;
            } catch (NoSuchFieldError unused4) {
            }
        }
    }

    public de(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        this.r = null;
        this.p = false;
        this.q = new Handler();
        int iA = pg.a.a();
        this.h = bh.a(((Integer) dm.e(pg.a.a(), iA, -443713383, new Object[0], pg.a.a(), 443713384, pg.a.a())).intValue()) * dm.c();
        this.f95865g = bh.a(dm.D()) * dm.c();
        post(new Runnable() { // from class: com.facetec.sdk.凤金
            @Override // java.lang.Runnable
            public final void run() {
                this.f7186.b();
            }
        });
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void b() {
        d(false);
        d();
        float fWidth = this.c.width() / this.b.width();
        float fHeight = this.c.height() / this.b.height();
        Property property = View.SCALE_X;
        ObjectAnimator objectAnimatorOfFloat = ObjectAnimator.ofFloat(this, (Property<de, Float>) property, 1.0f, fWidth);
        Property property2 = View.SCALE_Y;
        ObjectAnimator objectAnimatorOfFloat2 = ObjectAnimator.ofFloat(this, (Property<de, Float>) property2, 1.0f, fHeight);
        AnimatorSet animatorSet = new AnimatorSet();
        this.j = animatorSet;
        animatorSet.setInterpolator(new OvershootInterpolator(0.8f));
        this.j.setDuration(1600L);
        this.j.playTogether(objectAnimatorOfFloat, objectAnimatorOfFloat2);
        AnimatorSet animatorSet2 = new AnimatorSet();
        this.o = animatorSet2;
        animatorSet2.setDuration(0L);
        this.o.playTogether(objectAnimatorOfFloat, objectAnimatorOfFloat2);
        ObjectAnimator objectAnimatorOfFloat3 = ObjectAnimator.ofFloat(this, (Property<de, Float>) property, 1.0f, fWidth);
        ObjectAnimator objectAnimatorOfFloat4 = ObjectAnimator.ofFloat(this, (Property<de, Float>) property2, 1.0f, fHeight);
        AnimatorSet animatorSet3 = new AnimatorSet();
        this.n = animatorSet3;
        animatorSet3.setInterpolator(new OvershootInterpolator(1.5f));
        this.n.setDuration(1200L);
        this.n.playTogether(objectAnimatorOfFloat3, objectAnimatorOfFloat4);
        ObjectAnimator objectAnimatorOfFloat5 = ObjectAnimator.ofFloat(this, (Property<de, Float>) property, fWidth, 1.0f);
        ObjectAnimator objectAnimatorOfFloat6 = ObjectAnimator.ofFloat(this, (Property<de, Float>) property2, fHeight, 1.0f);
        AnimatorSet animatorSet4 = new AnimatorSet();
        this.l = animatorSet4;
        animatorSet4.setDuration(700L);
        this.l.playTogether(objectAnimatorOfFloat5, objectAnimatorOfFloat6);
    }

    private void d() {
        setLayerType(1, null);
        Paint paint = new Paint(1);
        this.a = paint;
        paint.setStyle(Paint.Style.FILL);
        this.a.setAlpha(0);
        this.a.setXfermode(new PorterDuffXfermode(PorterDuff.Mode.CLEAR));
        setLayerType(2, null);
        Paint paint2 = new Paint(1);
        this.d = paint2;
        paint2.setStyle(Paint.Style.STROKE);
        this.d.setStrokeWidth(this.h);
        String[] strArr = {"Nokia 2.2", "Nokia_2_2", "G5", "G5_Plus", "LM-X320", "LM-X420", "LM-X520", "LM-X525", "JAT-L29", "Infinix X650B", "moto e(6) plus", "Multilaser_G_Max"};
        for (int i = 0; i < 12; i++) {
            if (Build.MODEL.equals(strArr[i])) {
                this.d.setAntiAlias(false);
            }
        }
        Paint paint3 = new Paint(1);
        this.k = paint3;
        paint3.setStyle(Paint.Style.FILL);
        a();
    }

    public final void a(final AnimatorSet animatorSet) {
        this.r = animatorSet;
        this.q.post(new Runnable() { // from class: com.facetec.sdk.凤药
            @Override // java.lang.Runnable
            public final void run() {
                this.f7182.e(animatorSet);
            }
        });
    }

    public final void c() {
        d dVar = this.m;
        if (dVar != null) {
            dVar.b();
        }
    }

    public final void e() {
        a();
        invalidate();
    }

    public final RectF f() {
        d(false);
        return this.b;
    }

    public final int g() {
        return (int) this.b.bottom;
    }

    public final boolean h() {
        return this.e;
    }

    public final void j() {
        setOvalHasExpanded(false);
        a(this.l);
    }

    @Override // android.view.View
    public void onDraw(Canvas canvas) {
        Canvas canvas2;
        super.onDraw(canvas);
        if (this.b != null) {
            canvas.drawRect(-400.0f, -400.0f, getWidth() + 800, getHeight() + 800, this.k);
            canvas2 = canvas;
            canvas2.drawOval(this.b, this.a);
            canvas2.drawOval(this.i, this.d);
        } else {
            canvas2 = canvas;
        }
        d dVar = this.m;
        if (dVar == null || dVar.d == null) {
            return;
        }
        float f = dVar.c;
        float f2 = -(f - dVar.i);
        canvas2.drawArc(dVar.e, f, f2, false, dVar.a);
        canvas2.drawArc(dVar.e, (dVar.c + 180.0f) % 360.0f, f2, false, dVar.b);
    }

    public void setOvalHasExpanded(boolean z) {
        this.e = z;
    }

    public void setOvalStrokeWidth(int i) {
        if (this.d == null) {
            d();
            a();
        }
        this.d.setStrokeWidth(i);
        invalidate();
    }

    public void setTransparentBackground() {
        if (this.k == null) {
            d();
            a();
        }
        this.k.setColor(0);
        invalidate();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void c(Runnable runnable, Animator animator) {
        setVisibility(4);
        if (runnable != null) {
            runnable.run();
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void e(AnimatorSet animatorSet) {
        if (animatorSet != null) {
            animatorSet.start();
        } else {
            t.d(getContext(), c.NON_FATAL_ERROR, "animatorSet is null unexpectedly.", null);
        }
    }

    public final void a(final Runnable runnable, boolean z) {
        float f;
        e();
        FaceTecExitAnimationStyle faceTecExitAnimationStyle = z ? FaceTecSDK.d.q : FaceTecSDK.d.s;
        int i = AnonymousClass5.a[faceTecExitAnimationStyle.ordinal()];
        float f2 = 1.0f;
        int i2 = 800;
        if (i != 2) {
            f = 2.1f;
            if (i != 3) {
                if (i == 4) {
                    this.d.setColor(dm.k(getContext()));
                    i2 = 1000;
                }
                f = 1.0f;
            }
            f2 = 1.8f;
        } else {
            f = 1.0f;
        }
        if (faceTecExitAnimationStyle != FaceTecExitAnimationStyle.NONE) {
            ObjectAnimator objectAnimatorOfFloat = ObjectAnimator.ofFloat(this, (Property<de, Float>) View.SCALE_X, getScaleX(), f2);
            ObjectAnimator objectAnimatorOfFloat2 = ObjectAnimator.ofFloat(this, (Property<de, Float>) View.SCALE_Y, getScaleY(), f);
            AnimatorSet animatorSet = new AnimatorSet();
            animatorSet.setDuration(i2);
            animatorSet.setInterpolator(new DecelerateInterpolator());
            animatorSet.playTogether(objectAnimatorOfFloat, objectAnimatorOfFloat2);
            animatorSet.addListener(new f() { // from class: com.facetec.sdk.凤道
                @Override // android.animation.Animator.AnimatorListener
                public final void onAnimationEnd(Animator animator) {
                    this.f7184.c(runnable, animator);
                }
            });
            animatorSet.addListener(new Animator.AnimatorListener() { // from class: com.facetec.sdk.de.2
                private static final byte[] $$a = null;
                private static final int $$b = 0;
                private static long d;

                /* JADX WARN: Removed duplicated region for block: B:10:0x0028  */
                /* JADX WARN: Removed duplicated region for block: B:8:0x0022  */
                /* JADX WARN: Unsupported multi-entry loop pattern (BACK_EDGE: B:10:0x0028 -> B:11:0x002f). Please report as a decompilation issue!!! */
                /*
                    Code decompiled incorrectly, please refer to instructions dump.
                    To view partially-correct code enable 'Show inconsistent code' option in preferences
                */
                private static java.lang.String $$c(byte r6, byte r7, byte r8) {
                    /*
                        int r8 = 100 - r8
                        byte[] r0 = com.facetec.sdk.de.AnonymousClass2.$$a
                        int r7 = r7 * 4
                        int r7 = 3 - r7
                        int r6 = r6 * 2
                        int r1 = 1 - r6
                        byte[] r1 = new byte[r1]
                        r2 = 0
                        int r6 = 0 - r6
                        if (r0 != 0) goto L18
                        r8 = r7
                        r3 = r0
                        r4 = r2
                        r0 = r6
                        goto L2f
                    L18:
                        r3 = r2
                    L19:
                        byte r4 = (byte) r8
                        r1[r3] = r4
                        int r4 = r3 + 1
                        int r7 = r7 + 1
                        if (r3 != r6) goto L28
                        java.lang.String r6 = new java.lang.String
                        r6.<init>(r1, r2)
                        return r6
                    L28:
                        r3 = r0[r7]
                        r5 = r8
                        r8 = r7
                        r7 = r3
                        r3 = r0
                        r0 = r5
                    L2f:
                        int r7 = r7 + r0
                        r0 = r8
                        r8 = r7
                        r7 = r0
                        r0 = r3
                        r3 = r4
                        goto L19
                    */
                    throw new UnsupportedOperationException("Method not decompiled: com.facetec.sdk.de.AnonymousClass2.$$c(byte, byte, byte):java.lang.String");
                }

                static {
                    init$0();
                    d = 4627931221306447422L;
                }

                /* JADX WARN: Removed duplicated region for block: B:32:0x0128  */
                /* JADX WARN: Removed duplicated region for block: B:33:0x0129  */
                /*
                    Code decompiled incorrectly, please refer to instructions dump.
                    To view partially-correct code enable 'Show inconsistent code' option in preferences
                */
                private static void b(java.lang.String r20, int r21, java.lang.Object[] r22) throws java.lang.Throwable {
                    /*
                        Method dump skipped, instruction units count: 306
                        To view this dump change 'Code comments level' option to 'DEBUG'
                    */
                    throw new UnsupportedOperationException("Method not decompiled: com.facetec.sdk.de.AnonymousClass2.b(java.lang.String, int, java.lang.Object[]):void");
                }

                public static void init$0() {
                    $$a = new byte[]{4, 8, -22, -73};
                    $$b = 43;
                }

                @Override // android.animation.Animator.AnimatorListener
                public final void onAnimationCancel(Animator animator) {
                }

                @Override // android.animation.Animator.AnimatorListener
                public final void onAnimationEnd(Animator animator) throws Throwable {
                    try {
                        Object[] objArr = new Object[1];
                        b("矣䐃ဩ\uec29렋瑲䁪\u1c8a\ue8b6ꓤ烴䳩\u18fe픒ꄶ紡", (SystemClock.uptimeMillis() > 0L ? 1 : (SystemClock.uptimeMillis() == 0L ? 0 : -1)) + 13290, objArr);
                        Class<?> cls = Class.forName((String) objArr[0]);
                        b("矪煡竁搬涘囶偓妖䌈䱡㗎㽻㢼∜⭳ᓓḪ", 1693 - View.MeasureSpec.makeMeasureSpec(0, 0), new Object[1]);
                        cv.J("brets", ((Long) cls.getMethod((String) r1[0], null).invoke(null, null)).longValue());
                    } catch (Throwable th) {
                        Throwable cause = th.getCause();
                        if (cause == null) {
                            throw th;
                        }
                        throw cause;
                    }
                }

                @Override // android.animation.Animator.AnimatorListener
                public final void onAnimationRepeat(Animator animator) {
                }

                @Override // android.animation.Animator.AnimatorListener
                public final void onAnimationStart(Animator animator) throws Throwable {
                    try {
                        Object[] objArr = new Object[1];
                        b("矣䐃ဩ\uec29렋瑲䁪\u1c8a\ue8b6ꓤ烴䳩\u18fe픒ꄶ紡", 13291 - (ViewConfiguration.getScrollBarFadeDuration() >> 16), objArr);
                        Class<?> cls = Class.forName((String) objArr[0]);
                        b("矪煡竁搬涘囶偓妖䌈䱡㗎㽻㢼∜⭳ᓓḪ", (SystemClock.uptimeMillis() > 0L ? 1 : (SystemClock.uptimeMillis() == 0L ? 0 : -1)) + 1692, new Object[1]);
                        cv.J("brsts", ((Long) cls.getMethod((String) r1[0], null).invoke(null, null)).longValue());
                    } catch (Throwable th) {
                        Throwable cause = th.getCause();
                        if (cause == null) {
                            throw th;
                        }
                        throw cause;
                    }
                }
            });
            a(animatorSet);
        }
    }

    public class d {
        final Paint a;
        final Paint b;
        private final TimeInterpolator f;
        private final int h;
        private final int j;
        AnimatorSet d = null;
        RectF e = null;
        float c = SelfieScan.RECOGNITION_FAIL_RESULT;
        float i = SelfieScan.RECOGNITION_FAIL_RESULT;

        /* JADX INFO: renamed from: g, reason: collision with root package name */
        private final ValueAnimator.AnimatorUpdateListener f95866g = new ValueAnimator.AnimatorUpdateListener() { // from class: com.facetec.sdk.凤雨
            @Override // android.animation.ValueAnimator.AnimatorUpdateListener
            public final void onAnimationUpdate(ValueAnimator valueAnimator) {
                this.f7187.a(valueAnimator);
            }
        };

        public d(Context context) {
            int iB = dq.b(context, FaceTecSDK.d.n.progressColor1);
            int iB2 = dq.b(context, FaceTecSDK.d.n.progressColor2);
            this.b = a(iB);
            this.a = a(iB2);
            this.h = dm.d(context, FaceTecSDK.d.n.progressColor1);
            this.j = dm.d(context, FaceTecSDK.d.n.progressColor2);
            this.f = new AccelerateDecelerateInterpolator();
        }

        private Paint a(int i) {
            Paint paint = new Paint(1);
            paint.setStyle(Paint.Style.STROKE);
            paint.setStrokeWidth(de.this.f95865g);
            paint.setStrokeJoin(Paint.Join.ROUND);
            paint.setStrokeCap(Paint.Cap.ROUND);
            paint.setColor(i);
            return paint;
        }

        private ObjectAnimator e(Paint paint, int i) {
            paint.setAlpha(Math.max(0, i - 50));
            double d = i;
            ObjectAnimator objectAnimatorOfInt = ObjectAnimator.ofInt(paint, ViewHierarchyNode.JsonKeys.ALPHA, (int) (0.8d * d), (int) (d * 0.24d));
            objectAnimatorOfInt.setDuration(500L);
            objectAnimatorOfInt.setInterpolator(new DecelerateInterpolator());
            objectAnimatorOfInt.setStartDelay(de.this.h() ? 600L : 400L);
            return objectAnimatorOfInt;
        }

        public final void b() {
            float fA;
            AnimatorSet animatorSet = this.d;
            if (animatorSet == null || !animatorSet.isStarted()) {
                if (this.e == null) {
                    int i = FaceTecSDK.d.n.progressRadialOffset;
                    if (i == 0) {
                        de deVar = de.this;
                        fA = deVar.f95865g + deVar.h;
                    } else {
                        fA = bh.a((int) (i * dm.c()));
                    }
                    RectF rectF = de.this.i;
                    this.e = new RectF(rectF.left + fA, rectF.top + fA, rectF.right - fA, rectF.bottom - fA);
                }
                ObjectAnimator objectAnimatorE = e(this.b, this.h);
                ObjectAnimator objectAnimatorE2 = e(this.a, this.j);
                ObjectAnimator objectAnimatorOfFloat = ObjectAnimator.ofFloat(this, "startStrokePosition", SelfieScan.RECOGNITION_FAIL_RESULT, 360.0f);
                boolean zH = de.this.h();
                objectAnimatorOfFloat.addUpdateListener(this.f95866g);
                objectAnimatorOfFloat.setInterpolator(this.f);
                objectAnimatorOfFloat.setDuration(zH ? 1000L : 800L);
                this.i = SelfieScan.RECOGNITION_FAIL_RESULT;
                ObjectAnimator objectAnimatorOfFloat2 = ObjectAnimator.ofFloat(this, "endStrokePosition", SelfieScan.RECOGNITION_FAIL_RESULT, 360.0f);
                objectAnimatorOfFloat2.setDuration(zH ? 1000L : 800L);
                objectAnimatorOfFloat2.addUpdateListener(this.f95866g);
                objectAnimatorOfFloat2.setInterpolator(this.f);
                objectAnimatorOfFloat2.setStartDelay(zH ? 200L : 100L);
                AnimatorSet animatorSet2 = new AnimatorSet();
                this.d = animatorSet2;
                animatorSet2.playTogether(objectAnimatorOfFloat, objectAnimatorOfFloat2, objectAnimatorE, objectAnimatorE2);
                this.d.start();
            }
        }

        public final void setEndStrokePosition(float f) {
            this.i = f;
        }

        public final void setStartStrokePosition(float f) {
            this.c = f;
        }

        /* JADX INFO: Access modifiers changed from: private */
        public /* synthetic */ void a(ValueAnimator valueAnimator) {
            de.this.invalidate();
        }
    }

    public final synchronized void d(boolean z) {
        try {
            if (!this.p || z) {
                this.p = true;
                int width = getWidth();
                int height = dm.c() < 1.0f ? dq.b().heightPixels : getHeight();
                float f = width;
                float f2 = 0.65f * f;
                float f3 = (f - f2) / 2.0f;
                float height2 = (getHeight() - (f2 * 1.48f)) / 2.0f;
                RectF rectF = new RectF();
                this.b = rectF;
                rectF.set(f3, height2, f - f3, getHeight() - height2);
                RectF rectF2 = new RectF();
                this.i = rectF2;
                RectF rectF3 = this.b;
                float f4 = rectF3.left;
                float f5 = this.h;
                rectF2.set(f4 + (f5 / 2.0f), rectF3.top + (f5 / 2.0f), rectF3.right - (f5 / 2.0f), rectF3.bottom - (f5 / 2.0f));
                RectF rectF4 = new RectF();
                this.f = rectF4;
                RectF rectF5 = this.b;
                float f6 = rectF5.left;
                float f7 = this.h;
                rectF4.set(f6 + f7, rectF5.top + f7, rectF5.right - f7, rectF5.bottom - f7);
                float f8 = 0.98f * f;
                float f9 = (f - f8) / 2.0f;
                float f10 = f8 * 1.7f;
                float f11 = height - (s << 1);
                if (f11 <= f10) {
                    f10 = f11;
                }
                float height3 = (getHeight() - f10) / 2.0f;
                RectF rectF6 = new RectF();
                this.c = rectF6;
                rectF6.set(f9, height3, f - f9, getHeight() - height3);
                this.m = new d(getContext());
            }
        } catch (Throwable th) {
            throw th;
        }
    }

    private void a() {
        if (this.k != null) {
            Context context = getContext();
            this.d.setColor(dm.l(context));
            this.k.setColor(dm.k(context));
        }
    }
}