package com.facetec.sdk;

/* JADX INFO: loaded from: classes4.dex */
enum df {
    LIGHTING_AND_NEUTRAL_EXPRESSION,
    LIGHTING_ONLY,
    NEUTRAL_EXPRESSION_ONLY,
    BLURRY_ONLY
}