package com.facetec.sdk;

import android.os.Build;

/* JADX INFO: loaded from: classes4.dex */
final class dg {
    final boolean b;
    private final String[] e;
    private final float a = 0.8f;
    private final float c = 1.0f;
    private final float d = 0.5f;
    private final float j = 0.8f;
    private final float h = 0.55f;
    private final float f = 0.6f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    private final float f95867g = 0.45f;
    private final float i = 0.5f;

    public dg() {
        String[] strArr = {"2109119DG", "M2010J19CG", "Pixel 6a"};
        this.e = strArr;
        int length = strArr.length;
        boolean z = false;
        int i = 0;
        while (true) {
            if (i >= length) {
                break;
            }
            if (Build.MODEL.contains(strArr[i])) {
                z = true;
                break;
            }
            i++;
        }
        this.b = z;
    }

    public final float c() {
        return this.b ? 0.45f : 0.5f;
    }

    public final float e() {
        return this.b ? 0.6f : 1.0f;
    }
}