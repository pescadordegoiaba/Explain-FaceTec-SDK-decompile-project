package com.facetec.sdk;

import android.app.Activity;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import com.facetec.sdk.FaceTecCancelButtonCustomization;
import com.incode.welcome_sdk.modules.SelfieScan;
import java.lang.ref.WeakReference;
import kotlin.C6852;

/* JADX INFO: loaded from: classes4.dex */
final class di {
    final WeakReference<bm> d;

    public di(Activity activity) {
        this.d = new WeakReference<>((bm) activity);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static /* synthetic */ boolean b(FaceTecSessionActivity faceTecSessionActivity, View view, MotionEvent motionEvent) {
        if (motionEvent.getAction() == 0) {
            faceTecSessionActivity.w.setAlpha(0.4f);
        } else if (motionEvent.getAction() == 3 || motionEvent.getX() < SelfieScan.RECOGNITION_FAIL_RESULT || motionEvent.getX() > faceTecSessionActivity.w.getWidth() + faceTecSessionActivity.w.getLeft() + 10 || motionEvent.getY() < SelfieScan.RECOGNITION_FAIL_RESULT || motionEvent.getY() > faceTecSessionActivity.w.getHeight() + faceTecSessionActivity.w.getTop() + 10) {
            faceTecSessionActivity.w.setAlpha(1.0f);
        } else if (motionEvent.getAction() == 1) {
            faceTecSessionActivity.w.performClick();
        }
        return true;
    }

    public final void a() {
        final FaceTecSessionActivity faceTecSessionActivity = (FaceTecSessionActivity) this.d.get();
        ImageView imageView = (ImageView) faceTecSessionActivity.findViewById(R.id.customLocationBackButton);
        faceTecSessionActivity.w = imageView;
        if (FaceTecSDK.d.m.b != FaceTecCancelButtonCustomization.ButtonLocation.CUSTOM || FaceTecSDK.d.m.e == null) {
            return;
        }
        imageView.setAlpha(SelfieScan.RECOGNITION_FAIL_RESULT);
        faceTecSessionActivity.w.setVisibility(0);
        RelativeLayout.LayoutParams layoutParams = new RelativeLayout.LayoutParams(-2, -2);
        layoutParams.setMarginStart((int) bh.a(FaceTecSDK.d.m.e.left));
        ((ViewGroup.MarginLayoutParams) layoutParams).topMargin = (int) bh.a(FaceTecSDK.d.m.e.top);
        ((ViewGroup.LayoutParams) layoutParams).width = (int) bh.a(FaceTecSDK.d.m.e.right);
        ((ViewGroup.LayoutParams) layoutParams).height = (int) bh.a(FaceTecSDK.d.m.e.bottom);
        faceTecSessionActivity.w.setLayoutParams(layoutParams);
        if (FaceTecSDK.d.m.customImage != 0) {
            faceTecSessionActivity.w.setImageDrawable(C6852.getDrawable(faceTecSessionActivity, dm.aQ()));
        }
        faceTecSessionActivity.w.setOnClickListener(new View.OnClickListener() { // from class: com.facetec.sdk.凤风
            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                di.a(faceTecSessionActivity, view);
            }
        });
        faceTecSessionActivity.w.setOnTouchListener(new View.OnTouchListener() { // from class: com.facetec.sdk.凤鬼
            @Override // android.view.View.OnTouchListener
            public final boolean onTouch(View view, MotionEvent motionEvent) {
                return di.b(faceTecSessionActivity, view, motionEvent);
            }
        });
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static /* synthetic */ void a(FaceTecSessionActivity faceTecSessionActivity, View view) {
        faceTecSessionActivity.w.setAlpha(1.0f);
        faceTecSessionActivity.onBackPressed();
        faceTecSessionActivity.w.setEnabled(false);
    }
}