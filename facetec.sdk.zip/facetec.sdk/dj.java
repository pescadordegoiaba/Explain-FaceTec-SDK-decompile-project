package com.facetec.sdk;

import android.os.AsyncTask;
import androidx.annotation.NonNull;
import java.util.concurrent.Executor;
import java.util.concurrent.Executors;

/* JADX INFO: loaded from: classes4.dex */
public final class dj extends AsyncTask<Void, Void, Void> {
    private static Executor a;
    private static Executor e;
    private Runnable b = null;
    private final Runnable c;

    private dj(Runnable runnable) {
        this.c = runnable;
    }

    public static dj a(@NonNull Runnable runnable) {
        dj djVar = new dj(runnable);
        djVar.executeOnExecutor(c(), new Void[0]);
        return djVar;
    }

    private static synchronized Executor c() {
        try {
            if (e == null) {
                e = Executors.newCachedThreadPool();
            }
        } catch (Throwable th) {
            throw th;
        }
        return e;
    }

    public static dj d(@NonNull Runnable runnable) {
        dj djVar = new dj(runnable);
        djVar.executeOnExecutor(e(), new Void[0]);
        return djVar;
    }

    private static synchronized Executor e() {
        try {
            if (a == null) {
                a = Executors.newSingleThreadExecutor();
            }
        } catch (Throwable th) {
            throw th;
        }
        return a;
    }

    @Override // android.os.AsyncTask
    public final /* synthetic */ Void doInBackground(Void[] voidArr) {
        this.c.run();
        return null;
    }

    @Override // android.os.AsyncTask
    public final /* bridge */ /* synthetic */ void onPostExecute(Void r1) {
        super.onPostExecute(r1);
        Runnable runnable = this.b;
        if (runnable != null) {
            runnable.run();
        }
    }

    public final dj c(Runnable runnable) {
        this.b = runnable;
        return this;
    }
}