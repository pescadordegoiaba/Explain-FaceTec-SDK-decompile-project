package com.facetec.sdk;

import android.graphics.PorterDuff;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.os.Handler;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.LinearInterpolator;
import android.view.animation.RotateAnimation;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;
import androidx.vectordrawable.graphics.drawable.Animatable2Compat$AnimationCallback;
import com.facetec.sdk.au;
import com.facetec.sdk.pg;
import com.incode.welcome_sdk.modules.SelfieScan;
import kotlin.C6852;

/* JADX INFO: loaded from: classes4.dex */
public final class dk extends au {
    ImageView b;
    Handler c;
    a e;
    private Animatable2Compat$AnimationCallback f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    private ImageView f95869g;
    private View h;
    private RelativeLayout i;
    private TextView j;
    boolean a = false;
    private boolean l = false;
    final au.c d = new au.c(new Runnable() { // from class: com.facetec.sdk.剑丹
        @Override // java.lang.Runnable
        public final void run() {
            this.f7194.c();
        }
    });

    /* JADX INFO: renamed from: com.facetec.sdk.dk$2, reason: invalid class name */
    public class AnonymousClass2 extends Animatable2Compat$AnimationCallback {
        public AnonymousClass2() {
        }

        /* JADX INFO: Access modifiers changed from: private */
        public /* synthetic */ void e() {
            dq.a(dk.this.b);
        }

        @Override // androidx.vectordrawable.graphics.drawable.Animatable2Compat$AnimationCallback
        public final void onAnimationEnd(Drawable drawable) {
            dk.this.c(new Runnable() { // from class: com.facetec.sdk.剑仙
                @Override // java.lang.Runnable
                public final void run() {
                    this.f7200.e();
                }
            });
        }
    }

    public interface a {
        void p();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void b(int i) {
        AnonymousClass2 anonymousClass2 = new AnonymousClass2();
        this.f = anonymousClass2;
        dq.c(this.b, i, anonymousClass2, true);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void c() {
        this.l = true;
        a();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void d(au.c cVar) {
        RelativeLayout relativeLayout = this.i;
        if (relativeLayout != null) {
            relativeLayout.setVisibility(8);
        }
        if (cVar != null) {
            cVar.run();
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void e() {
        a aVar = this.e;
        if (aVar != null) {
            aVar.p();
        }
    }

    public final void a() {
        if (this.a && this.l) {
            final au.c cVar = new au.c(new Runnable() { // from class: com.facetec.sdk.剑书
                @Override // java.lang.Runnable
                public final void run() {
                    this.f7197.e();
                }
            });
            c(new Runnable() { // from class: com.facetec.sdk.剑人
                @Override // java.lang.Runnable
                public final void run() {
                    this.f7198.b(cVar);
                }
            });
        }
    }

    @Override // com.facetec.sdk.au, android.app.Fragment
    public final void onCreate(Bundle bundle) {
        super.onCreate(bundle);
    }

    @Override // android.app.Fragment
    public final View onCreateView(LayoutInflater layoutInflater, ViewGroup viewGroup, Bundle bundle) {
        return layoutInflater.inflate(R.layout.facetec_securing_camera_fragment, viewGroup, false);
    }

    @Override // android.app.Fragment
    public final void onViewCreated(View view, Bundle bundle) throws Throwable {
        super.onViewCreated(view, bundle);
        this.i = (RelativeLayout) view.findViewById(R.id.mainContainer);
        this.h = view.findViewById(R.id.mainBackgroundView);
        this.j = (TextView) view.findViewById(R.id.messageTextView);
        this.f95869g = (ImageView) view.findViewById(R.id.animationBackgroundImageView);
        this.b = (ImageView) view.findViewById(R.id.animationForegroundImageView);
        dm.j(this.h);
        this.h.getBackground().setAlpha(((Integer) dm.e(pg.a.a(), pg.a.a(), -298147150, new Object[0], pg.a.a(), 298147185, pg.a.a())).intValue());
        float fB = dm.b() * dm.c();
        float fBo = dm.bo();
        int iIntValue = ((Integer) dm.e(pg.a.a(), pg.a.a(), 1933108801, new Object[0], pg.a.a(), -1933108792, pg.a.a())).intValue();
        int iRound = Math.round(bh.a(40) * fBo * fB);
        this.i.setTranslationY(Math.round(bh.a(-55) * fB));
        FrameLayout frameLayout = (FrameLayout) view.findViewById(R.id.animationFrameLayout);
        frameLayout.getLayoutParams().height = iRound;
        frameLayout.getLayoutParams().width = iRound;
        int iAO = dm.aO();
        final int iIntValue2 = ((Integer) dm.e(pg.a.a(), pg.a.a(), 128970064, new Object[0], pg.a.a(), -128970048, pg.a.a())).intValue();
        Drawable drawable = iAO != 0 ? C6852.getDrawable(getActivity(), iAO) : null;
        if (iIntValue2 != 0) {
            this.f95869g.setVisibility(8);
            c(new Runnable() { // from class: com.facetec.sdk.剑乐
                @Override // java.lang.Runnable
                public final void run() {
                    this.f7195.b(iIntValue2);
                }
            });
        } else if (iAO != 0) {
            this.f95869g.setVisibility(8);
            this.b.setImageDrawable(drawable);
            RotateAnimation rotateAnimation = new RotateAnimation(SelfieScan.RECOGNITION_FAIL_RESULT, 360.0f, 1, 0.5f, 1, 0.5f);
            rotateAnimation.setInterpolator(new LinearInterpolator());
            rotateAnimation.setDuration(FaceTecSDK.d.k.customAnimationImageRotationInterval);
            rotateAnimation.setRepeatCount(-1);
            this.b.startAnimation(rotateAnimation);
        } else {
            ImageView imageView = this.f95869g;
            int iR = dm.r(getActivity());
            PorterDuff.Mode mode = PorterDuff.Mode.SRC_IN;
            imageView.setColorFilter(iR, mode);
            this.b.setColorFilter(dm.s(getActivity()), mode);
            RotateAnimation rotateAnimation2 = new RotateAnimation(SelfieScan.RECOGNITION_FAIL_RESULT, 360.0f, 1, 0.5f, 1, 0.5f);
            rotateAnimation2.setDuration(1000L);
            rotateAnimation2.setInterpolator(new LinearInterpolator());
            rotateAnimation2.setRepeatCount(-1);
            this.b.startAnimation(rotateAnimation2);
        }
        dq.c(this.j, dm.s(getActivity()));
        this.j.setTypeface(FaceTecSDK.d.k.messageFont);
        dp.e(this.j, R.string.FaceTec_initializing_camera);
        this.j.setTextSize(2, fB * 16.0f);
        LinearLayout.LayoutParams layoutParams = (LinearLayout.LayoutParams) this.j.getLayoutParams();
        ((ViewGroup.MarginLayoutParams) layoutParams).topMargin = iIntValue;
        ((ViewGroup.MarginLayoutParams) layoutParams).leftMargin = iIntValue;
        ((ViewGroup.MarginLayoutParams) layoutParams).rightMargin = iIntValue;
        this.j.setLayoutParams(layoutParams);
        t.b(dh.SECURING_CAMERA);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void b(final au.c cVar) {
        this.i.animate().alpha(SelfieScan.RECOGNITION_FAIL_RESULT).setDuration(500L).setStartDelay(0L).setListener(null).withEndAction(new au.c(new Runnable() { // from class: com.facetec.sdk.凤龙
            @Override // java.lang.Runnable
            public final void run() {
                this.f7192.a(cVar);
            }
        })).start();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void a(final au.c cVar) {
        c(new Runnable() { // from class: com.facetec.sdk.凤魂
            @Override // java.lang.Runnable
            public final void run() {
                this.f7190.d(cVar);
            }
        });
    }
}