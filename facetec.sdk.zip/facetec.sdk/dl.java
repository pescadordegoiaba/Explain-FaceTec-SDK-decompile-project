package com.facetec.sdk;

import java.util.TimerTask;

/* JADX INFO: loaded from: classes4.dex */
final class dl extends TimerTask {
    private final Runnable b;

    public dl(Runnable runnable) {
        this.b = runnable;
    }

    @Override // java.util.TimerTask, java.lang.Runnable
    public final void run() {
        this.b.run();
    }
}