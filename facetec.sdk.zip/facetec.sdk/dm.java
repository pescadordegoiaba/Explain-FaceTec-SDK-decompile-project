package com.facetec.sdk;

import android.content.Context;
import android.content.res.Resources;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.ShapeDrawable;
import android.os.SystemClock;
import android.text.TextUtils;
import android.util.DisplayMetrics;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewConfiguration;
import android.widget.ExpandableListView;
import android.widget.ProgressBar;
import android.widget.TextView;
import androidx.annotation.NonNull;
import com.facetec.sdk.FaceTecSDK;
import com.facetec.sdk.dq;
import com.facetec.sdk.l;
import com.facetec.sdk.pg;
import com.plaid.internal.EnumC41897g;
import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import kotlin.C6852;
import net.sf.scuba.smartcards.ISO7816;

/* JADX INFO: loaded from: classes4.dex */
final class dm {
    private static final byte[] $$a = null;
    private static final int $$b = 0;
    private static int $10;
    private static int $11;
    private static final l<Float> a;
    private static int b;
    private static final l<Float> c;
    private static int d;
    private static final l<Float> e;
    private static int f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    private static byte[] f95870g;
    private static short[] h;
    private static int i;
    private static int j;
    private static int m;
    private static int n;

    /* JADX INFO: renamed from: com.facetec.sdk.dm$3, reason: invalid class name */
    public static /* synthetic */ class AnonymousClass3 {
        static final /* synthetic */ int[] b;
        static final /* synthetic */ int[] d;
        static final /* synthetic */ int[] e;

        static {
            int[] iArr = new int[ck.values().length];
            e = iArr;
            try {
                iArr[ck.UNKNOWN.ordinal()] = 1;
            } catch (NoSuchFieldError unused) {
            }
            try {
                e[ck.STARTING.ordinal()] = 2;
            } catch (NoSuchFieldError unused2) {
            }
            try {
                e[ck.SCANNING.ordinal()] = 3;
            } catch (NoSuchFieldError unused3) {
            }
            try {
                e[ck.WEAK_CONNECTION.ordinal()] = 4;
            } catch (NoSuchFieldError unused4) {
            }
            try {
                e[ck.FINISHED_WITH_SUCCESS.ordinal()] = 5;
            } catch (NoSuchFieldError unused5) {
            }
            try {
                e[ck.FINISHED_WITH_ERROR.ordinal()] = 6;
            } catch (NoSuchFieldError unused6) {
            }
            try {
                e[ck.SKIPPED.ordinal()] = 7;
            } catch (NoSuchFieldError unused7) {
            }
            try {
                e[ck.DISABLED.ordinal()] = 8;
            } catch (NoSuchFieldError unused8) {
            }
            int[] iArr2 = new int[cz.values().length];
            b = iArr2;
            try {
                iArr2[cz.UNKNOWN.ordinal()] = 1;
            } catch (NoSuchFieldError unused9) {
            }
            try {
                b[cz.IDSCAN_RETRY_FACE_DID_NOT_MATCH.ordinal()] = 2;
            } catch (NoSuchFieldError unused10) {
            }
            try {
                b[cz.IDSCAN_RETRY_ID_NOT_FULLY_VISIBLE.ordinal()] = 3;
            } catch (NoSuchFieldError unused11) {
            }
            try {
                b[cz.IDSCAN_RETRY_OCR_RESULTS_NOT_GOOD_ENOUGH.ordinal()] = 4;
            } catch (NoSuchFieldError unused12) {
            }
            try {
                b[cz.IDSCAN_RETRY_ID_TYPE_NOT_SUPPORTED.ordinal()] = 5;
            } catch (NoSuchFieldError unused13) {
            }
            try {
                b[cz.IDSCAN_RETRY_BARCODE_NOT_READ.ordinal()] = 6;
            } catch (NoSuchFieldError unused14) {
            }
            try {
                b[cz.IDSCAN_RETRY_USER_CONFIRMATION.ordinal()] = 7;
            } catch (NoSuchFieldError unused15) {
            }
            try {
                b[cz.IDSCAN_SKIP_OR_ERROR_NFC.ordinal()] = 8;
            } catch (NoSuchFieldError unused16) {
            }
            try {
                b[cz.IDSCAN_SUCCESS_FRONT_SIDE.ordinal()] = 9;
            } catch (NoSuchFieldError unused17) {
            }
            try {
                b[cz.IDSCAN_SUCCESS_FRONT_SIDE_BACK_NEXT.ordinal()] = 10;
            } catch (NoSuchFieldError unused18) {
            }
            try {
                b[cz.IDSCAN_SUCCESS_FRONT_SIDE_NFC_NEXT.ordinal()] = 11;
            } catch (NoSuchFieldError unused19) {
            }
            try {
                b[cz.IDSCAN_SUCCESS_BACK_SIDE.ordinal()] = 12;
            } catch (NoSuchFieldError unused20) {
            }
            try {
                b[cz.IDSCAN_SUCCESS_BACK_SIDE_NFC_NEXT.ordinal()] = 13;
            } catch (NoSuchFieldError unused21) {
            }
            try {
                b[cz.IDSCAN_SUCCESS_PASSPORT.ordinal()] = 14;
            } catch (NoSuchFieldError unused22) {
            }
            try {
                b[cz.IDSCAN_SUCCESS_PASSPORT_NFC_NEXT.ordinal()] = 15;
            } catch (NoSuchFieldError unused23) {
            }
            try {
                b[cz.IDSCAN_SUCCESS_USER_CONFIRMATION.ordinal()] = 16;
            } catch (NoSuchFieldError unused24) {
            }
            try {
                b[cz.IDSCAN_SUCCESS_NFC.ordinal()] = 17;
            } catch (NoSuchFieldError unused25) {
            }
            try {
                b[cz.IDSCAN_SUCCESS_ADDITIONAL_REVIEW.ordinal()] = 18;
            } catch (NoSuchFieldError unused26) {
            }
            int[] iArr3 = new int[dq.d.values().length];
            d = iArr3;
            try {
                iArr3[dq.d.RESOURCE.ordinal()] = 1;
            } catch (NoSuchFieldError unused27) {
            }
            try {
                d[dq.d.COLOR.ordinal()] = 2;
            } catch (NoSuchFieldError unused28) {
            }
        }
    }

    /* JADX WARN: Removed duplicated region for block: B:10:0x0024  */
    /* JADX WARN: Removed duplicated region for block: B:8:0x001e  */
    /* JADX WARN: Unsupported multi-entry loop pattern (BACK_EDGE: B:10:0x0024 -> B:11:0x002e). Please report as a decompilation issue!!! */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    private static java.lang.String $$c(short r6, short r7, int r8) {
        /*
            int r6 = r6 * 3
            int r6 = r6 + 1
            int r8 = r8 + 4
            byte[] r0 = com.facetec.sdk.dm.$$a
            int r7 = 106 - r7
            byte[] r1 = new byte[r6]
            r2 = 0
            if (r0 != 0) goto L13
            r3 = r0
            r4 = r2
            r0 = r8
            goto L2e
        L13:
            r3 = r8
            r8 = r7
            r7 = r3
            r3 = r2
        L17:
            byte r4 = (byte) r8
            r1[r3] = r4
            int r3 = r3 + 1
            if (r3 != r6) goto L24
            java.lang.String r6 = new java.lang.String
            r6.<init>(r1, r2)
            return r6
        L24:
            int r7 = r7 + 1
            r4 = r0[r7]
            r5 = r8
            r8 = r7
            r7 = r4
            r4 = r3
            r3 = r0
            r0 = r5
        L2e:
            int r7 = -r7
            int r7 = r7 + r0
            r0 = r8
            r8 = r7
            r7 = r0
            r0 = r3
            r3 = r4
            goto L17
        */
        throw new UnsupportedOperationException("Method not decompiled: com.facetec.sdk.dm.$$c(short, short, int):java.lang.String");
    }

    static {
        init$0();
        $10 = 0;
        $11 = 1;
        m = 0;
        n = 1;
        j = 0;
        f = 1;
        bq();
        c = new l<>();
        e = new l<>();
        a = new l<>();
        int i2 = m + 105;
        n = i2 % 128;
        if (i2 % 2 == 0) {
            throw null;
        }
    }

    private static /* synthetic */ Object A(Object[] objArr) {
        Context context = (Context) objArr[0];
        int i2 = j + 51;
        f = i2 % 128;
        if (i2 % 2 == 0) {
            c(dq.b(context, bD()), u(context));
            throw null;
        }
        int iC = c(dq.b(context, bD()), u(context));
        int i3 = f + 105;
        j = i3 % 128;
        if (i3 % 2 == 0) {
            return Integer.valueOf(iC);
        }
        throw null;
    }

    private static /* synthetic */ Object B(Object[] objArr) {
        int i2;
        int i3 = f + 113;
        j = i3 % 128;
        if (i3 % 2 != 0) {
            i2 = bu().i.buttonBorderColor;
            int i4 = 96 / 0;
        } else {
            i2 = bu().i.buttonBorderColor;
        }
        int i5 = f + 13;
        j = i5 % 128;
        if (i5 % 2 == 0) {
            return Integer.valueOf(i2);
        }
        throw null;
    }

    public static int C() {
        Object objE;
        int i2 = j + 125;
        f = i2 % 128;
        if (i2 % 2 == 0) {
            Object[] objArr = {Integer.valueOf(FaceTecSDK.d.i.retryScreenImageCornerRadius), 75};
            objE = e(pg.a.a(), pg.a.a(), -1179194194, objArr, pg.a.a(), 1179194206, pg.a.a());
        } else {
            Object[] objArr2 = {Integer.valueOf(FaceTecSDK.d.i.retryScreenImageCornerRadius), 10};
            objE = e(pg.a.a(), pg.a.a(), -1179194194, objArr2, pg.a.a(), 1179194206, pg.a.a());
        }
        return ((Integer) objE).intValue();
    }

    public static int D() {
        Object objE;
        int i2 = j + 107;
        f = i2 % 128;
        if (i2 % 2 == 0) {
            Object[] objArr = {Integer.valueOf(FaceTecSDK.d.n.progressStrokeWidth), 68};
            objE = e(pg.a.a(), pg.a.a(), -1179194194, objArr, pg.a.a(), 1179194206, pg.a.a());
        } else {
            Object[] objArr2 = {Integer.valueOf(FaceTecSDK.d.n.progressStrokeWidth), 6};
            objE = e(pg.a.a(), pg.a.a(), -1179194194, objArr2, pg.a.a(), 1179194206, pg.a.a());
        }
        return ((Integer) objE).intValue();
    }

    public static int E() {
        Object objE;
        int i2 = f + 103;
        j = i2 % 128;
        if (i2 % 2 != 0) {
            Object[] objArr = {Integer.valueOf(FaceTecSDK.d.j.buttonCornerRadius), 90};
            objE = e(pg.a.a(), pg.a.a(), -1179194194, objArr, pg.a.a(), 1179194206, pg.a.a());
        } else {
            Object[] objArr2 = {Integer.valueOf(FaceTecSDK.d.j.buttonCornerRadius), 8};
            objE = e(pg.a.a(), pg.a.a(), -1179194194, objArr2, pg.a.a(), 1179194206, pg.a.a());
        }
        return ((Integer) objE).intValue();
    }

    public static int F() {
        f = (j + 53) % 128;
        Object[] objArr = {Integer.valueOf(FaceTecSDK.d.f.captureScreenTextBackgroundCornerRadius), 6};
        int iIntValue = ((Integer) e(pg.a.a(), pg.a.a(), -1179194194, objArr, pg.a.a(), 1179194206, pg.a.a())).intValue();
        int i2 = j + 7;
        f = i2 % 128;
        if (i2 % 2 != 0) {
            return iIntValue;
        }
        throw null;
    }

    public static int G() {
        j = (f + 83) % 128;
        Object[] objArr = {Integer.valueOf(FaceTecSDK.d.i.buttonCornerRadius), 8};
        int iIntValue = ((Integer) e(pg.a.a(), pg.a.a(), -1179194194, objArr, pg.a.a(), 1179194206, pg.a.a())).intValue();
        int i2 = f + 9;
        j = i2 % 128;
        if (i2 % 2 == 0) {
            return iIntValue;
        }
        throw null;
    }

    public static int H() {
        int iA = pg.a.a();
        return ((Integer) e(pg.a.a(), iA, -858435705, new Object[0], pg.a.a(), 858435734, pg.a.a())).intValue();
    }

    public static int I() {
        f = (j + 55) % 128;
        Object[] objArr = {Integer.valueOf(FaceTecSDK.d.f.reviewScreenTextBackgroundCornerRadius), 6};
        int iIntValue = ((Integer) e(pg.a.a(), pg.a.a(), -1179194194, objArr, pg.a.a(), 1179194206, pg.a.a())).intValue();
        j = (f + 19) % 128;
        return iIntValue;
    }

    public static Typeface J() {
        int i2 = f + 35;
        j = i2 % 128;
        if (i2 % 2 != 0) {
            FaceTecGuidanceCustomization faceTecGuidanceCustomization = FaceTecSDK.d.i;
            throw null;
        }
        FaceTecGuidanceCustomization faceTecGuidanceCustomization2 = FaceTecSDK.d.i;
        Typeface typeface = (Typeface) e(faceTecGuidanceCustomization2.readyScreenHeaderFont, faceTecGuidanceCustomization2.headerFont);
        j = (f + 119) % 128;
        return typeface;
    }

    public static int K() {
        int iA = pg.a.a();
        return ((Integer) e(pg.a.a(), iA, -1035099184, new Object[0], pg.a.a(), 1035099208, pg.a.a())).intValue();
    }

    public static Typeface L() {
        int i2 = f + 55;
        j = i2 % 128;
        if (i2 % 2 == 0) {
            FaceTecGuidanceCustomization faceTecGuidanceCustomization = FaceTecSDK.d.i;
            return (Typeface) e(faceTecGuidanceCustomization.readyScreenSubtextFont, faceTecGuidanceCustomization.subtextFont);
        }
        FaceTecGuidanceCustomization faceTecGuidanceCustomization2 = FaceTecSDK.d.i;
        throw null;
    }

    public static Typeface M() {
        int iA = pg.a.a();
        return (Typeface) e(pg.a.a(), iA, -757228659, new Object[0], pg.a.a(), 757228698, pg.a.a());
    }

    public static int N() {
        Object objE;
        int i2 = f + 77;
        j = i2 % 128;
        if (i2 % 2 != 0) {
            Object[] objArr = {Integer.valueOf(FaceTecSDK.d.f.captureFrameCornerRadius), 126};
            objE = e(pg.a.a(), pg.a.a(), -1179194194, objArr, pg.a.a(), 1179194206, pg.a.a());
        } else {
            Object[] objArr2 = {Integer.valueOf(FaceTecSDK.d.f.captureFrameCornerRadius), 12};
            objE = e(pg.a.a(), pg.a.a(), -1179194194, objArr2, pg.a.a(), 1179194206, pg.a.a());
        }
        return ((Integer) objE).intValue();
    }

    public static int O() {
        j = (f + 45) % 128;
        int iA = pg.a.a();
        if (!((Boolean) e(pg.a.a(), iA, 732370085, new Object[0], pg.a.a(), -732370051, pg.a.a())).booleanValue()) {
            return a(FaceTecSDK.d.f.idFeedbackScreenBackgroundColors);
        }
        int i2 = f + 31;
        j = i2 % 128;
        if (i2 % 2 == 0) {
            return a(FaceTecSDK.d.f95813g.backgroundColors);
        }
        a(FaceTecSDK.d.f95813g.backgroundColors);
        throw null;
    }

    public static int P() {
        j = (f + 21) % 128;
        int iA = pg.a.a();
        if (((Boolean) e(pg.a.a(), iA, 732370085, new Object[0], pg.a.a(), -732370051, pg.a.a())).booleanValue()) {
            j = (f + 107) % 128;
            return bu().f95813g.foregroundColor;
        }
        int i2 = bu().f.idFeedbackScreenForegroundColor;
        f = (j + 101) % 128;
        return i2;
    }

    public static int Q() {
        int iA = pg.a.a();
        return ((Integer) e(pg.a.a(), iA, 2009312697, new Object[0], pg.a.a(), -2009312677, pg.a.a())).intValue();
    }

    public static Typeface R() {
        int i2 = j + 21;
        f = i2 % 128;
        if (i2 % 2 != 0) {
            FaceTecGuidanceCustomization faceTecGuidanceCustomization = FaceTecSDK.d.i;
            return (Typeface) e(faceTecGuidanceCustomization.retryScreenSubtextFont, faceTecGuidanceCustomization.subtextFont);
        }
        FaceTecGuidanceCustomization faceTecGuidanceCustomization2 = FaceTecSDK.d.i;
        throw null;
    }

    public static int S() {
        j = (f + 69) % 128;
        int i2 = bu().f95813g.foregroundColor;
        int i3 = j + 85;
        f = i3 % 128;
        if (i3 % 2 != 0) {
            return i2;
        }
        throw null;
    }

    public static int T() {
        f = (j + 93) % 128;
        int i2 = bu().i.buttonTextNormalColor;
        j = (f + 63) % 128;
        return i2;
    }

    public static int U() {
        int i2 = f + 107;
        j = i2 % 128;
        if (i2 % 2 != 0) {
            int i3 = bu().f95813g.activityIndicatorColor;
            throw null;
        }
        int i4 = bu().f95813g.activityIndicatorColor;
        f = (j + 107) % 128;
        return i4;
    }

    public static int V() {
        int iA = pg.a.a();
        return ((Integer) e(pg.a.a(), iA, -1412338306, new Object[0], pg.a.a(), 1412338333, pg.a.a())).intValue();
    }

    public static int W() {
        f = (j + 81) % 128;
        int iA = a(FaceTecSDK.d.i.backgroundColors);
        f = (j + 59) % 128;
        return iA;
    }

    public static int X() {
        j = (f + 53) % 128;
        int iA = a(FaceTecSDK.d.h.backgroundColor);
        int i2 = j + 61;
        f = i2 % 128;
        if (i2 % 2 == 0) {
            int i3 = 72 / 0;
        }
        return iA;
    }

    public static int Y() {
        j = (f + 29) % 128;
        int i2 = bu().i.buttonBackgroundNormalColor;
        f = (j + 3) % 128;
        return i2;
    }

    public static int Z() {
        f = (j + 95) % 128;
        int i2 = bu().i.buttonTextHighlightColor;
        int i3 = f + 105;
        j = i3 % 128;
        if (i3 % 2 == 0) {
            return i2;
        }
        throw null;
    }

    public static synchronized float a() {
        f = (j + 47) % 128;
        float fFloatValue = e.c(new l.a() { // from class: com.facetec.sdk.剑剑
            @Override // com.facetec.sdk.l.a
            public final Object create() {
                return Float.valueOf(dm.bt());
            }
        }).floatValue();
        int i2 = j + 27;
        f = i2 % 128;
        if (i2 % 2 != 0) {
            return fFloatValue;
        }
        int i3 = 47 / 0;
        return fFloatValue;
    }

    public static int aA() {
        int i2 = f + 15;
        j = i2 % 128;
        if (i2 % 2 == 0) {
            return bu().j.scrollIndicatorBackgroundNormalColor;
        }
        int i3 = bu().j.scrollIndicatorBackgroundNormalColor;
        throw null;
    }

    public static int aB() {
        int i2 = f + 49;
        j = i2 % 128;
        if (i2 % 2 == 0) {
            return bu().j.scrollIndicatorBackgroundHighlightColor;
        }
        int i3 = 71 / 0;
        return bu().j.scrollIndicatorBackgroundHighlightColor;
    }

    public static int aC() {
        int i2 = j + 119;
        f = i2 % 128;
        if (i2 % 2 == 0) {
            int i3 = bu().j.scrollIndicatorForegroundNormalColor;
            throw null;
        }
        int i4 = bu().j.scrollIndicatorForegroundNormalColor;
        j = (f + 113) % 128;
        return i4;
    }

    public static int aD() {
        int iA = pg.a.a();
        return ((Integer) e(pg.a.a(), iA, -1414859097, new Object[0], pg.a.a(), 1414859112, pg.a.a())).intValue();
    }

    public static int aE() {
        int i2 = j + 63;
        f = i2 % 128;
        if (i2 % 2 != 0) {
            return bu().j.scrollIndicatorForegroundHighlightColor;
        }
        int i3 = bu().j.scrollIndicatorForegroundHighlightColor;
        throw null;
    }

    public static int aF() {
        int i2 = f + 71;
        j = i2 % 128;
        if (i2 % 2 == 0) {
            return bu().f.reviewScreenTextBackgroundBorderColor;
        }
        int i3 = bu().f.reviewScreenTextBackgroundBorderColor;
        throw null;
    }

    public static int aG() {
        int i2 = j + 25;
        f = i2 % 128;
        if (i2 % 2 != 0) {
            return bu().f.reviewScreenTextBackgroundColor;
        }
        int i3 = bu().f.reviewScreenTextBackgroundColor;
        throw null;
    }

    public static int aH() {
        j = (f + 51) % 128;
        int iC = c(bu().h.brandingImage, FaceTecSDK.d.h.brandingImage);
        int i2 = j + 103;
        f = i2 % 128;
        if (i2 % 2 != 0) {
            return iC;
        }
        throw null;
    }

    public static int aI() {
        int iC;
        int i2 = j + 69;
        f = i2 % 128;
        if (i2 % 2 == 0) {
            iC = c(bu().f.inactiveTorchButtonImage, FaceTecSDK.d.f.inactiveTorchButtonImage);
            int i3 = 65 / 0;
        } else {
            iC = c(bu().f.inactiveTorchButtonImage, FaceTecSDK.d.f.inactiveTorchButtonImage);
        }
        int i4 = j + 75;
        f = i4 % 128;
        if (i4 % 2 != 0) {
            return iC;
        }
        throw null;
    }

    public static int aJ() {
        f = (j + 115) % 128;
        int i2 = bu().f.captureScreenTextBackgroundBorderColor;
        j = (f + 105) % 128;
        return i2;
    }

    public static int aK() {
        j = (f + 3) % 128;
        int iC = c(bu().f.selectionScreenDocumentImage, FaceTecSDK.d.f.selectionScreenDocumentImage);
        j = (f + 95) % 128;
        return iC;
    }

    public static int aL() {
        f = (j + EnumC41897g.SDK_ASSET_ILLUSTRATION_CALENDAR_VALUE) % 128;
        int iC = c(bu().f.activeTorchButtonImage, FaceTecSDK.d.f.activeTorchButtonImage);
        f = (j + 49) % 128;
        return iC;
    }

    public static int aM() {
        int i2 = f + 13;
        j = i2 % 128;
        if (i2 % 2 != 0) {
            c(bu().j.customScrollIndicatorAnimation, FaceTecSDK.d.j.customScrollIndicatorAnimation);
            throw null;
        }
        int iC = c(bu().j.customScrollIndicatorAnimation, FaceTecSDK.d.j.customScrollIndicatorAnimation);
        j = (f + 59) % 128;
        return iC;
    }

    public static int aN() {
        int iA = pg.a.a();
        return ((Integer) e(pg.a.a(), iA, 128970064, new Object[0], pg.a.a(), -128970048, pg.a.a())).intValue();
    }

    public static int aO() {
        f = (j + 35) % 128;
        int iE = e(bu().k.customAnimationImage, FaceTecSDK.d.k.customAnimationImage);
        int i2 = j + 77;
        f = i2 % 128;
        if (i2 % 2 == 0) {
            int i3 = 93 / 0;
        }
        return iE;
    }

    public static int aP() {
        j = (f + 37) % 128;
        int iC = c(bu().f95813g.customActivityIndicatorImage, FaceTecSDK.d.f95813g.customActivityIndicatorImage);
        j = (f + 5) % 128;
        return iC;
    }

    public static int aQ() {
        int i2 = f + 63;
        j = i2 % 128;
        if (i2 % 2 != 0) {
            c(bu().m.customImage, FaceTecSDK.d.m.customImage);
            throw null;
        }
        int iC = c(bu().m.customImage, FaceTecSDK.d.m.customImage);
        j = (f + 109) % 128;
        return iC;
    }

    public static int aR() {
        int iC = c(bu().i.retryScreenIdealImage, FaceTecSDK.d.i.retryScreenIdealImage);
        if (iC != 0) {
            return iC;
        }
        int i2 = (f + 59) % 128;
        j = i2;
        int i3 = R.drawable.facetec_ideal_pose_image;
        f = (i2 + 117) % 128;
        return i3;
    }

    public static int[] aS() {
        int iA = pg.a.a();
        return (int[]) e(pg.a.a(), iA, -1644736691, new Object[0], pg.a.a(), 1644736699, pg.a.a());
    }

    public static int aT() {
        int i2 = f + 59;
        j = i2 % 128;
        if (i2 % 2 != 0) {
            c(bu().f95813g.resultAnimationUnsuccessBackgroundImage, FaceTecSDK.d.f95813g.resultAnimationUnsuccessBackgroundImage);
            throw null;
        }
        int iC = c(bu().f95813g.resultAnimationUnsuccessBackgroundImage, FaceTecSDK.d.f95813g.resultAnimationUnsuccessBackgroundImage);
        f = (j + 11) % 128;
        return iC;
    }

    public static int aU() {
        int iA = pg.a.a();
        return ((Integer) e(pg.a.a(), iA, -783523114, new Object[0], pg.a.a(), 783523156, pg.a.a())).intValue();
    }

    public static int aV() {
        int iA = pg.a.a();
        return ((Integer) e(pg.a.a(), iA, -1271089769, new Object[0], pg.a.a(), 1271089769, pg.a.a())).intValue();
    }

    public static String aW() {
        j = (f + EnumC41897g.SDK_ASSET_ILLUSTRATION_CALENDAR_VALUE) % 128;
        String strA = dp.a(R.string.FaceTec_retry_official_id_photo_subheader_message);
        if (FaceTecSDK.d.b || strA.length() <= 40) {
            f = (j + 37) % 128;
            return strA;
        }
        int i2 = f + 11;
        j = i2 % 128;
        return i2 % 2 != 0 ? strA.substring(0, 72) : strA.substring(0, 40);
    }

    public static int aX() {
        int iA = pg.a.a();
        return ((Integer) e(pg.a.a(), iA, -508681661, new Object[0], pg.a.a(), 508681666, pg.a.a())).intValue();
    }

    public static int aY() {
        int iA = pg.a.a();
        return ((Integer) e(pg.a.a(), iA, -298147150, new Object[0], pg.a.a(), 298147185, pg.a.a())).intValue();
    }

    public static int aZ() {
        int i2 = f + 45;
        j = i2 % 128;
        if (i2 % 2 == 0) {
            return c(bu().f.idFeedbackScreenFlipIDFrontImage, R.drawable.facetec_internal_id_card_front);
        }
        c(bu().f.idFeedbackScreenFlipIDFrontImage, R.drawable.facetec_internal_id_card_front);
        throw null;
    }

    public static int aa() {
        int i2 = f + 89;
        j = i2 % 128;
        if (i2 % 2 != 0) {
            int i3 = bu().i.buttonBackgroundHighlightColor;
            throw null;
        }
        int i4 = bu().i.buttonBackgroundHighlightColor;
        int i5 = f + 117;
        j = i5 % 128;
        if (i5 % 2 == 0) {
            return i4;
        }
        throw null;
    }

    public static int ab() {
        int iA = pg.a.a();
        return ((Integer) e(pg.a.a(), iA, -1410973603, new Object[0], pg.a.a(), 1410973621, pg.a.a())).intValue();
    }

    public static int ac() {
        int i2 = f + 87;
        j = i2 % 128;
        if (i2 % 2 != 0) {
            int i3 = bu().i.buttonTextDisabledColor;
            throw null;
        }
        int i4 = bu().i.buttonTextDisabledColor;
        j = (f + 47) % 128;
        return i4;
    }

    public static int ad() {
        int iA = pg.a.a();
        return ((Integer) e(pg.a.a(), iA, -1731246276, new Object[0], pg.a.a(), 1731246302, pg.a.a())).intValue();
    }

    public static int ae() {
        int iA = pg.a.a();
        return ((Integer) e(pg.a.a(), iA, -742420334, new Object[0], pg.a.a(), 742420377, pg.a.a())).intValue();
    }

    public static int af() {
        int iA = pg.a.a();
        return ((Integer) e(pg.a.a(), iA, -1006289847, new Object[0], pg.a.a(), 1006289864, pg.a.a())).intValue();
    }

    public static int ag() {
        int i2 = j + 85;
        f = i2 % 128;
        if (i2 % 2 != 0) {
            return bu().f.buttonTextDisabledColor;
        }
        int i3 = bu().f.buttonTextDisabledColor;
        throw null;
    }

    public static int ah() {
        int iA = pg.a.a();
        return ((Integer) e(pg.a.a(), iA, -1313229122, new Object[0], pg.a.a(), 1313229135, pg.a.a())).intValue();
    }

    public static int ai() {
        f = (j + 61) % 128;
        int i2 = bu().f.buttonBorderColor;
        int i3 = j + 65;
        f = i3 % 128;
        if (i3 % 2 != 0) {
            return i2;
        }
        throw null;
    }

    public static int aj() {
        int i2 = f + 125;
        j = i2 % 128;
        if (i2 % 2 == 0) {
            return bu().f.buttonBackgroundHighlightColor;
        }
        int i3 = bu().f.buttonBackgroundHighlightColor;
        throw null;
    }

    public static int ak() {
        j = (f + 79) % 128;
        int i2 = bu().f.buttonBackgroundDisabledColor;
        j = (f + 107) % 128;
        return i2;
    }

    public static int al() {
        int i2 = j + 93;
        f = i2 % 128;
        if (i2 % 2 != 0) {
            return bu().j.buttonTextHighlightColor;
        }
        int i3 = 93 / 0;
        return bu().j.buttonTextHighlightColor;
    }

    public static int am() {
        f = (j + 93) % 128;
        int i2 = bu().j.buttonTextNormalColor;
        j = (f + 31) % 128;
        return i2;
    }

    public static int an() {
        f = (j + 23) % 128;
        int i2 = bu().j.buttonBackgroundDisabledColor;
        j = (f + 27) % 128;
        return i2;
    }

    public static int ao() {
        j = (f + 89) % 128;
        int i2 = bu().j.buttonTextDisabledColor;
        int i3 = f + 119;
        j = i3 % 128;
        if (i3 % 2 != 0) {
            int i4 = 99 / 0;
        }
        return i2;
    }

    public static int ap() {
        int i2 = j + 11;
        f = i2 % 128;
        if (i2 % 2 == 0) {
            int i3 = bu().j.buttonBackgroundHighlightColor;
            throw null;
        }
        int i4 = bu().j.buttonBackgroundHighlightColor;
        j = (f + 29) % 128;
        return i4;
    }

    public static int aq() {
        int i2 = j + 29;
        f = i2 % 128;
        if (i2 % 2 != 0) {
            return bu().j.buttonBackgroundNormalColor;
        }
        int i3 = 52 / 0;
        return bu().j.buttonBackgroundNormalColor;
    }

    public static int ar() {
        f = (j + 79) % 128;
        int i2 = bu().j.buttonBorderColor;
        int i3 = j + 35;
        f = i3 % 128;
        if (i3 % 2 != 0) {
            return i2;
        }
        throw null;
    }

    public static int as() {
        int i2 = f + 39;
        j = i2 % 128;
        if (i2 % 2 == 0) {
            return c(bu().j.inputFieldTextColor, bX());
        }
        c(bu().j.inputFieldTextColor, bX());
        throw null;
    }

    public static int at() {
        f = (j + 63) % 128;
        int i2 = bu().j.mainHeaderDividerLineColor;
        int i3 = f + 67;
        j = i3 % 128;
        if (i3 % 2 == 0) {
            return i2;
        }
        throw null;
    }

    public static int au() {
        int i2 = j + 29;
        f = i2 % 128;
        if (i2 % 2 == 0) {
            int i3 = bu().j.mainHeaderTextColor;
            throw null;
        }
        int i4 = bu().j.mainHeaderTextColor;
        j = (f + 103) % 128;
        return i4;
    }

    public static int av() {
        f = (j + 61) % 128;
        int i2 = bu().j.fieldLabelTextColor;
        int i3 = j + 15;
        f = i3 % 128;
        if (i3 % 2 == 0) {
            int i4 = 51 / 0;
        }
        return i2;
    }

    public static int aw() {
        j = (f + 85) % 128;
        int i2 = bu().j.sectionHeaderTextColor;
        j = (f + 69) % 128;
        return i2;
    }

    public static int ax() {
        int i2 = j + 113;
        f = i2 % 128;
        if (i2 % 2 == 0) {
            int i3 = bu().j.inputFieldBackgroundColor;
            throw null;
        }
        int i4 = bu().j.inputFieldBackgroundColor;
        int i5 = f + 35;
        j = i5 % 128;
        if (i5 % 2 == 0) {
            return i4;
        }
        throw null;
    }

    public static int ay() {
        f = (j + 19) % 128;
        int i2 = bu().j.inputFieldBorderColor;
        f = (j + 109) % 128;
        return i2;
    }

    public static int az() {
        int i2 = j + 77;
        f = i2 % 128;
        if (i2 % 2 == 0) {
            int i3 = bu().j.scrollIndicatorBorderColor;
            throw null;
        }
        int i4 = bu().j.scrollIndicatorBorderColor;
        int i5 = j + 43;
        f = i5 % 128;
        if (i5 % 2 != 0) {
            return i4;
        }
        throw null;
    }

    public static synchronized float b() {
        float fFloatValue;
        j = (f + 71) % 128;
        fFloatValue = a.c(new l.a() { // from class: com.facetec.sdk.剑兵
            @Override // com.facetec.sdk.l.a
            public final Object create() {
                return Float.valueOf(dm.bs());
            }
        }).floatValue();
        int i2 = j + 85;
        f = i2 % 128;
        if (i2 % 2 == 0) {
            throw null;
        }
        return fFloatValue;
    }

    private static int bA() {
        int i2;
        int i3 = f + 3;
        j = i3 % 128;
        if (i3 % 2 != 0) {
            i2 = bu().i.retryScreenHeaderTextColor;
            int i4 = 21 / 0;
        } else {
            i2 = bu().i.retryScreenHeaderTextColor;
        }
        int i5 = j + 105;
        f = i5 % 128;
        if (i5 % 2 != 0) {
            return i2;
        }
        throw null;
    }

    private static int bB() {
        int i2 = j + 41;
        f = i2 % 128;
        if (i2 % 2 != 0) {
            return bu().i.foregroundColor;
        }
        int i3 = 63 / 0;
        return bu().i.foregroundColor;
    }

    private static int bC() {
        j = (f + 105) % 128;
        int i2 = bu().i.readyScreenSubtextTextColor;
        int i3 = j + 73;
        f = i3 % 128;
        if (i3 % 2 != 0) {
            return i2;
        }
        throw null;
    }

    private static int bD() {
        int i2 = j + 53;
        f = i2 % 128;
        if (i2 % 2 != 0) {
            return bu().i.retryScreenSubtextTextColor;
        }
        int i3 = 65 / 0;
        return bu().i.retryScreenSubtextTextColor;
    }

    private static int bE() {
        int i2 = f + 71;
        j = i2 % 128;
        if (i2 % 2 == 0) {
            return bu().i.readyScreenHeaderTextColor;
        }
        int i3 = bu().i.readyScreenHeaderTextColor;
        throw null;
    }

    private static int bF() {
        j = (f + 81) % 128;
        int i2 = bu().i.readyScreenOvalFillColor;
        int i3 = f + 113;
        j = i3 % 128;
        if (i3 % 2 == 0) {
            return i2;
        }
        throw null;
    }

    private static int bG() {
        int i2;
        int i3 = j + 119;
        f = i3 % 128;
        if (i3 % 2 == 0) {
            i2 = bu().o.borderColor;
            int i4 = 23 / 0;
        } else {
            i2 = bu().o.borderColor;
        }
        int i5 = f + 57;
        j = i5 % 128;
        if (i5 % 2 == 0) {
            return i2;
        }
        throw null;
    }

    private static int bH() {
        j = (f + 75) % 128;
        int i2 = bu().k.defaultAnimationBackgroundColor;
        int i3 = j + 105;
        f = i3 % 128;
        if (i3 % 2 != 0) {
            return i2;
        }
        throw null;
    }

    private static int bI() {
        int i2 = j + 115;
        f = i2 % 128;
        if (i2 % 2 == 0) {
            a(FaceTecSDK.d.o.backgroundColor);
            throw null;
        }
        int iA = a(FaceTecSDK.d.o.backgroundColor);
        int i3 = f + 19;
        j = i3 % 128;
        if (i3 % 2 != 0) {
            int i4 = 85 / 0;
        }
        return iA;
    }

    private static int bJ() {
        j = (f + 59) % 128;
        int i2 = bu().n.strokeColor;
        f = (j + 29) % 128;
        return i2;
    }

    private static int bK() {
        int i2 = f + EnumC41897g.SDK_ASSET_ILLUSTRATION_DEPOSIT_SWITCH_VALUE;
        j = i2 % 128;
        if (i2 % 2 != 0) {
            int i3 = bu().f95813g.uploadProgressFillColor;
            throw null;
        }
        int i4 = bu().f95813g.uploadProgressFillColor;
        f = (j + 23) % 128;
        return i4;
    }

    private static int bL() {
        f = (j + 79) % 128;
        int i2 = bu().k.defaultAnimationForegroundColor;
        j = (f + 81) % 128;
        return i2;
    }

    private static int bM() {
        f = (j + 101) % 128;
        int i2 = bu().f95813g.resultAnimationForegroundColor;
        f = (j + 67) % 128;
        return i2;
    }

    private static int bN() {
        j = (f + 15) % 128;
        int i2 = bu().f95813g.uploadProgressTrackColor;
        j = (f + 93) % 128;
        return i2;
    }

    private static int bO() {
        int i2 = j + 87;
        f = i2 % 128;
        if (i2 % 2 != 0) {
            return bu().f95813g.resultAnimationBackgroundColor;
        }
        int i3 = 79 / 0;
        return bu().f95813g.resultAnimationBackgroundColor;
    }

    private static int bP() {
        j = (f + 49) % 128;
        int iA = a(FaceTecSDK.d.j.backgroundColors);
        int i2 = f + 105;
        j = i2 % 128;
        if (i2 % 2 != 0) {
            int i3 = 9 / 0;
        }
        return iA;
    }

    private static int bQ() {
        f = (j + 33) % 128;
        int i2 = bu().i.retryScreenImageBorderColor;
        int i3 = f + 7;
        j = i3 % 128;
        if (i3 % 2 == 0) {
            return i2;
        }
        throw null;
    }

    private static int bR() {
        int i2;
        int i3 = j + 115;
        f = i3 % 128;
        if (i3 % 2 == 0) {
            i2 = bu().l.textColor;
            int i4 = 39 / 0;
        } else {
            i2 = bu().l.textColor;
        }
        f = (j + 75) % 128;
        return i2;
    }

    private static int bS() {
        f = (j + 67) % 128;
        int i2 = bu().i.retryScreenOvalStrokeColor;
        int i3 = f + 81;
        j = i3 % 128;
        if (i3 % 2 != 0) {
            int i4 = 47 / 0;
        }
        return i2;
    }

    private static int bT() {
        f = (j + 15) % 128;
        int i2 = bu().l.backgroundColors;
        int i3 = j + 125;
        f = i3 % 128;
        if (i3 % 2 == 0) {
            int i4 = 8 / 0;
        }
        return i2;
    }

    private static int bU() {
        int i2 = f + 5;
        j = i2 % 128;
        if (i2 % 2 != 0) {
            int i3 = bu().f.reviewScreenForegroundColor;
            throw null;
        }
        int i4 = bu().f.reviewScreenForegroundColor;
        int i5 = j + 35;
        f = i5 % 128;
        if (i5 % 2 != 0) {
            return i4;
        }
        throw null;
    }

    private static int bV() {
        j = (f + 71) % 128;
        int iA = a(FaceTecSDK.d.f.selectionScreenBackgroundColors);
        j = (f + 61) % 128;
        return iA;
    }

    private static int bW() {
        int i2;
        int i3 = f + EnumC41897g.SDK_ASSET_ILLUSTRATION_CALENDAR_VALUE;
        j = i3 % 128;
        if (i3 % 2 != 0) {
            i2 = bu().f.selectionScreenForegroundColor;
            int i4 = 85 / 0;
        } else {
            i2 = bu().f.selectionScreenForegroundColor;
        }
        f = (j + 61) % 128;
        return i2;
    }

    private static int bX() {
        int i2;
        int i3 = j + 27;
        f = i3 % 128;
        if (i3 % 2 == 0) {
            i2 = bu().j.fieldValueTextColor;
            int i4 = 83 / 0;
        } else {
            i2 = bu().j.fieldValueTextColor;
        }
        j = (f + 125) % 128;
        return i2;
    }

    private static int bY() {
        int iA = pg.a.a();
        return ((Integer) e(pg.a.a(), iA, 1589589333, new Object[0], pg.a.a(), -1589589310, pg.a.a())).intValue();
    }

    private static void bZ() {
        int iA = pg.a.a();
        e(pg.a.a(), iA, -648212982, new Object[0], pg.a.a(), 648213015, pg.a.a());
    }

    public static int ba() {
        j = (f + 93) % 128;
        int iC = c(bu().f.additionalReviewScreenImage, R.drawable.facetec_review);
        int i2 = j + 71;
        f = i2 % 128;
        if (i2 % 2 != 0) {
            return iC;
        }
        throw null;
    }

    public static int bb() {
        j = (f + 97) % 128;
        int i2 = bu().f.idFeedbackScreenFlipIDToBackAnimation;
        int i3 = j + 69;
        f = i3 % 128;
        if (i3 % 2 != 0) {
            return i2;
        }
        throw null;
    }

    public static String bc() {
        f = (j + 53) % 128;
        String strA = dp.a(R.string.FaceTec_retry_official_id_photo_ideal_image_label);
        if (FaceTecSDK.d.b) {
            return strA;
        }
        j = (f + 93) % 128;
        return strA.length() > 21 ? strA.substring(0, 21) : strA;
    }

    public static String bd() {
        String strA = dp.a(R.string.FaceTec_retry_official_id_photo_your_image_label);
        if (!FaceTecSDK.d.b) {
            int i2 = f + 53;
            j = i2 % 128;
            if (i2 % 2 == 0 ? strA.length() > 21 : strA.length() > 2) {
                strA = strA.substring(0, 21);
            }
        }
        f = (j + 19) % 128;
        return strA;
    }

    public static String be() {
        String strA;
        int i2 = j + 93;
        f = i2 % 128;
        if (i2 % 2 == 0) {
            strA = dp.a(R.string.FaceTec_retry_official_id_photo_instruction_message);
            int i3 = 13 / 0;
        } else {
            strA = dp.a(R.string.FaceTec_retry_official_id_photo_instruction_message);
        }
        int i4 = f + 63;
        j = i4 % 128;
        if (i4 % 2 == 0) {
            return strA;
        }
        throw null;
    }

    public static int bf() {
        int iA = pg.a.a();
        return ((Integer) e(pg.a.a(), iA, -714835323, new Object[0], pg.a.a(), 714835348, pg.a.a())).intValue();
    }

    public static int bg() {
        int i2 = f + EnumC41897g.SDK_ASSET_ILLUSTRATION_DEPOSIT_SWITCH_VALUE;
        j = i2 % 128;
        if (i2 % 2 == 0) {
            return bu().f.customNFCCardStartingAnimation;
        }
        int i3 = 89 / 0;
        return bu().f.customNFCCardStartingAnimation;
    }

    public static int bh() {
        int iA = pg.a.a();
        return ((Integer) e(pg.a.a(), iA, 7039404, new Object[0], pg.a.a(), -7039367, pg.a.a())).intValue();
    }

    public static int bi() {
        f = (j + 101) % 128;
        int i2 = bu().f.customNFCCardScanningAnimation;
        f = (j + 19) % 128;
        return i2;
    }

    public static int bj() {
        int i2 = j + 19;
        f = i2 % 128;
        if (i2 % 2 != 0) {
            return bu().f.customNFCSkipOrErrorAnimation;
        }
        int i3 = bu().f.customNFCSkipOrErrorAnimation;
        throw null;
    }

    public static int bk() {
        int i2 = j + 65;
        f = i2 % 128;
        if (i2 % 2 != 0) {
            return bu().f.customNFCScanningAnimation;
        }
        int i3 = bu().f.customNFCScanningAnimation;
        throw null;
    }

    public static int bl() {
        int iA = pg.a.a();
        return ((Integer) e(pg.a.a(), iA, 733738620, new Object[0], pg.a.a(), -733738576, pg.a.a())).intValue();
    }

    public static int bm() {
        int iA = pg.a.a();
        return ((Integer) e(pg.a.a(), iA, -1084716935, new Object[0], pg.a.a(), 1084716963, pg.a.a())).intValue();
    }

    /* JADX WARN: Removed duplicated region for block: B:9:0x0025  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public static boolean bn() {
        /*
            int r0 = com.facetec.sdk.dm.f
            int r0 = r0 + 67
            int r1 = r0 % 128
            com.facetec.sdk.dm.j = r1
            int r0 = r0 % 2
            r1 = 0
            if (r0 == 0) goto L1b
            com.facetec.sdk.FaceTecCustomization r0 = com.facetec.sdk.FaceTecSDK.d
            com.facetec.sdk.FaceTecCancelButtonCustomization r0 = r0.m
            com.facetec.sdk.FaceTecCancelButtonCustomization$ButtonLocation r0 = r0.b
            com.facetec.sdk.FaceTecCancelButtonCustomization$ButtonLocation r2 = com.facetec.sdk.FaceTecCancelButtonCustomization.ButtonLocation.DISABLED
            r3 = 28
            int r3 = r3 / r1
            if (r0 == r2) goto L39
            goto L25
        L1b:
            com.facetec.sdk.FaceTecCustomization r0 = com.facetec.sdk.FaceTecSDK.d
            com.facetec.sdk.FaceTecCancelButtonCustomization r0 = r0.m
            com.facetec.sdk.FaceTecCancelButtonCustomization$ButtonLocation r0 = r0.b
            com.facetec.sdk.FaceTecCancelButtonCustomization$ButtonLocation r2 = com.facetec.sdk.FaceTecCancelButtonCustomization.ButtonLocation.DISABLED
            if (r0 == r2) goto L39
        L25:
            com.facetec.sdk.FaceTecCustomization r0 = com.facetec.sdk.FaceTecSDK.d
            com.facetec.sdk.FaceTecCancelButtonCustomization r0 = r0.m
            com.facetec.sdk.FaceTecCancelButtonCustomization$ButtonLocation r0 = r0.b
            com.facetec.sdk.FaceTecCancelButtonCustomization$ButtonLocation r2 = com.facetec.sdk.FaceTecCancelButtonCustomization.ButtonLocation.CUSTOM
            if (r0 == r2) goto L39
            int r0 = com.facetec.sdk.dm.f
            int r0 = r0 + 111
            int r0 = r0 % 128
            com.facetec.sdk.dm.j = r0
            r0 = 1
            return r0
        L39:
            int r0 = com.facetec.sdk.dm.j
            int r0 = r0 + 29
            int r0 = r0 % 128
            com.facetec.sdk.dm.f = r0
            return r1
        */
        throw new UnsupportedOperationException("Method not decompiled: com.facetec.sdk.dm.bn():boolean");
    }

    public static float bo() {
        j = (f + 15) % 128;
        float fMin = Math.min(Math.max(FaceTecSDK.d.f95813g.animationRelativeScale, 0.5f), 2.0f);
        int i2 = j + 21;
        f = i2 % 128;
        if (i2 % 2 == 0) {
            int i3 = 39 / 0;
        }
        return fMin;
    }

    public static int bp() {
        int i2;
        int i3 = j + 13;
        f = i3 % 128;
        if (i3 % 2 == 0) {
            i2 = bu().f95813g.customResultAnimationUnsuccess;
            int i4 = 63 / 0;
        } else {
            i2 = bu().f95813g.customResultAnimationUnsuccess;
        }
        int i5 = j + 91;
        f = i5 % 128;
        if (i5 % 2 == 0) {
            int i6 = 8 / 0;
        }
        return i2;
    }

    public static void bq() {
        d = 1999123682;
        b = 114796556;
        i = 1562783089;
        f95870g = new byte[]{-90, -89, -92, -69, -93, ISO7816.INS_READ_BINARY_STAMPED, 99};
    }

    public static void br() {
        int iA = pg.a.a();
        e(pg.a.a(), iA, 1226479079, new Object[0], pg.a.a(), -1226479075, pg.a.a());
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static float bs() {
        float fA;
        int i2 = f + 69;
        j = i2 % 128;
        if (i2 % 2 != 0) {
            fA = (dq.c().width * bh.a(29687)) + (a() / 1.7777778f);
        } else {
            fA = (dq.c().width / bh.a(340)) * (a() / 1.7777778f);
        }
        f = (j + 69) % 128;
        return fA;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static float bt() {
        j = (f + 21) % 128;
        if (ah.f() == null) {
            f = (j + 13) % 128;
            return 1.7777778f;
        }
        float f2 = r0.b / r0.e;
        f = (j + 13) % 128;
        return f2;
    }

    private static FaceTecCustomization bu() {
        int i2 = j + 65;
        f = i2 % 128;
        if (i2 % 2 == 0) {
            FaceTecSDK.b();
            throw null;
        }
        if (FaceTecSDK.b()) {
            return FaceTecSDK.e;
        }
        if (!FaceTecSDK.e()) {
            return FaceTecSDK.d;
        }
        FaceTecCustomization faceTecCustomization = FaceTecSDK.a;
        int i3 = j + 29;
        f = i3 % 128;
        if (i3 % 2 != 0) {
            return faceTecCustomization;
        }
        throw null;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static float bv() throws Throwable {
        float f2;
        int dimensionPixelSize;
        int i2 = j + 103;
        f = i2 % 128;
        if (i2 % 2 == 0) {
            dq.b();
            int i3 = dq.c().width;
            int i4 = dq.c().height;
            a();
            throw null;
        }
        DisplayMetrics displayMetricsB = dq.b();
        float f3 = dq.c().width;
        float f4 = dq.c().height;
        if (a() < 1.4d) {
            f = (j + 25) % 128;
            f2 = 0.94f;
        } else {
            f2 = 0.88f;
        }
        float f5 = f3 * f2;
        float f6 = displayMetricsB.density * 340.0f;
        if (f5 > f6) {
            int i5 = j + 21;
            f = i5 % 128;
            f2 = i5 % 2 == 0 ? f6 + f3 : f6 / f3;
            f5 = f6;
        }
        Resources resourcesD = dq.d();
        Object[] objArr = new Object[1];
        ce((short) (54 - Color.blue(0)), (-1542554801) - ExpandableListView.getPackedPositionType(0L), KeyEvent.normalizeMetaState(0) - 104, TextUtils.indexOf((CharSequence) "", '0', 0, 0) - 1912577152, (byte) View.getDefaultSize(0, 0), objArr);
        int identifier = resourcesD.getIdentifier("status_bar_height", "dimen", ((String) objArr[0]).intern());
        if (identifier > 0) {
            j = (f + 67) % 128;
            dimensionPixelSize = Resources.getSystem().getDimensionPixelSize(identifier);
        } else {
            dimensionPixelSize = 0;
        }
        Resources resourcesD2 = dq.d();
        Object[] objArr2 = new Object[1];
        ce((short) (54 - ExpandableListView.getPackedPositionGroup(0L)), (-1542554801) - (ViewConfiguration.getPressedStateDuration() >> 16), (ViewConfiguration.getWindowTouchSlop() >> 8) - 104, (-1912577152) - (SystemClock.currentThreadTimeMillis() > (-1L) ? 1 : (SystemClock.currentThreadTimeMillis() == (-1L) ? 0 : -1)), (byte) TextUtils.getCapsMode("", 0, 0), objArr2);
        int identifier2 = resourcesD2.getIdentifier("navigation_bar_height", "dimen", ((String) objArr2[0]).intern());
        int dimensionPixelSize2 = identifier2 > 0 ? dq.d().getDimensionPixelSize(identifier2) : 0;
        float fA = a() * f5;
        float f7 = (((f4 - ((displayMetricsB.density * 10.0f) * 3.0f)) - 10.0f) - dimensionPixelSize2) - dimensionPixelSize;
        return fA > f7 ? f7 / (a() * f3) : f2;
    }

    private static int bw() {
        f = (j + 25) % 128;
        Object[] objArr = {Integer.valueOf(FaceTecSDK.d.l.cornerRadius), 3};
        int iIntValue = ((Integer) e(pg.a.a(), pg.a.a(), -1179194194, objArr, pg.a.a(), 1179194206, pg.a.a())).intValue();
        f = (j + 45) % 128;
        return iIntValue;
    }

    private static int bx() {
        int i2 = f + 81;
        j = i2 % 128;
        if (i2 % 2 == 0) {
            return a(FaceTecSDK.d.f95813g.backgroundColors);
        }
        a(FaceTecSDK.d.f95813g.backgroundColors);
        throw null;
    }

    private static int by() {
        int i2 = j + 3;
        f = i2 % 128;
        if (i2 % 2 == 0) {
            a(FaceTecSDK.d.f.additionalReviewScreenBackgroundColors);
            throw null;
        }
        int iA = a(FaceTecSDK.d.f.additionalReviewScreenBackgroundColors);
        int i3 = f + 107;
        j = i3 % 128;
        if (i3 % 2 == 0) {
            return iA;
        }
        throw null;
    }

    private static int bz() {
        int iIntValue;
        int i2 = f + 71;
        j = i2 % 128;
        if (i2 % 2 != 0) {
            int iA = pg.a.a();
            iIntValue = ((Integer) e(pg.a.a(), iA, -443713383, new Object[0], pg.a.a(), 443713384, pg.a.a())).intValue() / D();
        } else {
            int iA2 = pg.a.a();
            iIntValue = ((Integer) e(pg.a.a(), iA2, -443713383, new Object[0], pg.a.a(), 443713384, pg.a.a())).intValue() + D();
        }
        f = (j + 81) % 128;
        return iIntValue;
    }

    public static synchronized float c() {
        int i2 = j + 49;
        f = i2 % 128;
        if (i2 % 2 == 0) {
            c.c(new l.a() { // from class: com.facetec.sdk.剑凤
                @Override // com.facetec.sdk.l.a
                public final Object create() {
                    return Float.valueOf(dm.bv());
                }
            }).floatValue();
            throw null;
        }
        return c.c(new l.a() { // from class: com.facetec.sdk.剑凤
            @Override // com.facetec.sdk.l.a
            public final Object create() {
                return Float.valueOf(dm.bv());
            }
        }).floatValue();
    }

    private static int ca() {
        int i2 = f + 77;
        j = i2 % 128;
        if (i2 % 2 == 0) {
            return bu().f.captureScreenFocusMessageTextColor;
        }
        int i3 = bu().f.captureScreenFocusMessageTextColor;
        throw null;
    }

    private static int cb() {
        j = (f + 11) % 128;
        int iA = a(FaceTecSDK.d.f.captureScreenBackgroundColor);
        j = (f + 85) % 128;
        return iA;
    }

    private static int cc() {
        int iA = pg.a.a();
        return ((Integer) e(pg.a.a(), iA, 1565486859, new Object[0], pg.a.a(), -1565486852, pg.a.a())).intValue();
    }

    private static void cd() {
        String strD = d(false);
        String strC = c(false);
        if (strD != null && strD.length() > 21) {
            f = (j + 113) % 128;
            d("Retry Screen Your Image Label");
        }
        if (strC == null || strC.length() <= 21) {
            return;
        }
        d("Retry Screen Ideal Image Label");
        f = (j + 117) % 128;
    }

    private static void ce(short s, int i2, int i3, int i4, byte b2, Object[] objArr) throws Throwable {
        int i5;
        long j2;
        int i6;
        int i7;
        int i8;
        char c2;
        int i9;
        int i10;
        int i11;
        hh hhVar = new hh();
        StringBuilder sb = new StringBuilder();
        try {
            int i12 = 1;
            Object[] objArr2 = {Integer.valueOf(i3), Integer.valueOf(b)};
            int i13 = 0;
            Object objD = an.d(962055330);
            Class cls = Integer.TYPE;
            if (objD == null) {
                byte b3 = (byte) 0;
                byte b4 = b3;
                objD = an.d((SystemClock.currentThreadTimeMillis() > (-1L) ? 1 : (SystemClock.currentThreadTimeMillis() == (-1L) ? 0 : -1)) + 2401, (char) View.resolveSize(0, 0), (KeyEvent.getMaxKeyCode() >> 16) + 24, 1328947193, false, $$c(b3, b4, (byte) (b4 - 1)), new Class[]{cls, cls});
            }
            int iIntValue = ((Integer) ((Method) objD).invoke(null, objArr2)).intValue();
            boolean z = iIntValue == -1;
            if (z) {
                byte[] bArr = f95870g;
                if (bArr != null) {
                    int length = bArr.length;
                    byte[] bArr2 = new byte[length];
                    i9 = 962055330;
                    int i14 = 0;
                    while (i14 < length) {
                        Object[] objArr3 = {Integer.valueOf(bArr[i14])};
                        Object objD2 = an.d(399840230);
                        if (objD2 == null) {
                            i10 = i12;
                            byte b5 = (byte) i13;
                            i11 = i13;
                            byte b6 = (byte) (b5 + 3);
                            objD2 = an.d((ViewConfiguration.getScrollBarSize() >> 8) + 2064, (char) ((ViewConfiguration.getMaximumFlingVelocity() >> 16) + 14866), 24 - (ViewConfiguration.getWindowTouchSlop() >> 8), 1639235773, false, $$c(b5, b6, (byte) (b6 - 4)), new Class[]{cls});
                        } else {
                            i10 = i12;
                            i11 = i13;
                        }
                        bArr2[i14] = ((Byte) ((Method) objD2).invoke(null, objArr3)).byteValue();
                        i14++;
                        i12 = i10;
                        i13 = i11;
                    }
                    bArr = bArr2;
                } else {
                    i9 = 962055330;
                }
                i5 = i12;
                int i15 = i13;
                j2 = -7666492657327691677L;
                if (bArr != null) {
                    byte[] bArr3 = f95870g;
                    Object[] objArr4 = new Object[2];
                    objArr4[i5] = Integer.valueOf(d);
                    objArr4[i15] = Integer.valueOf(i4);
                    Object objD3 = an.d(i9);
                    if (objD3 == null) {
                        byte b7 = (byte) i15;
                        byte b8 = b7;
                        objD3 = an.d(2402 - View.resolveSizeAndState(i15, i15, i15), (char) View.resolveSizeAndState(i15, i15, i15), TextUtils.lastIndexOf("", '0') + 25, 1328947193, false, $$c(b7, b8, (byte) (b8 - 1)), new Class[]{cls, cls});
                    }
                    iIntValue = (byte) (((byte) (((long) bArr3[((Integer) ((Method) objD3).invoke(null, objArr4)).intValue()]) ^ (-7666492657327691677L))) + ((int) (((long) b) ^ (-7666492657327691677L))));
                } else {
                    iIntValue = (short) (((short) (((long) h[i4 + ((int) (((long) d) ^ (-7666492657327691677L)))]) ^ (-7666492657327691677L))) + ((int) (((long) b) ^ (-7666492657327691677L))));
                }
            } else {
                i5 = 1;
                j2 = -7666492657327691677L;
            }
            if (iIntValue > 0) {
                int i16 = ((i4 + iIntValue) - 2) + ((int) (((long) d) ^ j2));
                if (z) {
                    $10 = ($11 + 73) % 128;
                    i6 = i5;
                } else {
                    i6 = 0;
                }
                hhVar.d = i16 + i6;
                int i17 = i;
                Object[] objArr5 = new Object[4];
                objArr5[3] = sb;
                objArr5[2] = Integer.valueOf(i17);
                objArr5[i5] = Integer.valueOf(i2);
                objArr5[0] = hhVar;
                Object objD4 = an.d(-1066327576);
                if (objD4 == null) {
                    int iRed = 1803 - Color.red(0);
                    char cKeyCodeFromString = (char) (KeyEvent.keyCodeFromString("") + 9692);
                    int iAxisFromString = 23 - MotionEvent.axisFromString("");
                    byte length2 = (byte) $$a.length;
                    objD4 = an.d(iRed, cKeyCodeFromString, iAxisFromString, -1240403277, false, $$c((byte) 0, length2, (byte) (length2 - 5)), new Class[]{Object.class, cls, cls, Object.class});
                }
                ((StringBuilder) ((Method) objD4).invoke(null, objArr5)).append(hhVar.e);
                hhVar.c = hhVar.e;
                byte[] bArr4 = f95870g;
                if (bArr4 != null) {
                    int length3 = bArr4.length;
                    byte[] bArr5 = new byte[length3];
                    for (int i18 = 0; i18 < length3; i18++) {
                        bArr5[i18] = (byte) (((long) bArr4[i18]) ^ j2);
                    }
                    bArr4 = bArr5;
                }
                if (bArr4 != null) {
                    i8 = i5;
                    i7 = i8;
                } else {
                    i7 = i5;
                    i8 = 0;
                }
                while (true) {
                    hhVar.b = i7;
                    if (hhVar.b >= iIntValue) {
                        break;
                    }
                    if (i8 != 0) {
                        int i19 = $10 + 17;
                        $11 = i19 % 128;
                        if (i19 % 2 == 0) {
                            byte[] bArr6 = f95870g;
                            hhVar.d = hhVar.d % 0;
                            c2 = (char) (hhVar.c >>> (((byte) (((byte) (((long) bArr6[r4]) + j2)) / s)) ^ b2));
                        } else {
                            byte[] bArr7 = f95870g;
                            hhVar.d = hhVar.d - 1;
                            c2 = (char) (hhVar.c + (((byte) (((byte) (((long) bArr7[r4]) ^ j2)) + s)) ^ b2));
                        }
                        hhVar.e = c2;
                    } else {
                        short[] sArr = h;
                        hhVar.d = hhVar.d - 1;
                        hhVar.e = (char) (hhVar.c + (((short) (((short) (((long) sArr[r4]) ^ j2)) + s)) ^ b2));
                    }
                    sb.append(hhVar.e);
                    hhVar.c = hhVar.e;
                    i7 = hhVar.b + 1;
                }
            }
            String string = sb.toString();
            int i20 = $10 + 73;
            $11 = i20 % 128;
            if (i20 % 2 == 0) {
                throw null;
            }
            objArr[0] = string;
        } catch (Throwable th) {
            Throwable cause = th.getCause();
            if (cause == null) {
                throw th;
            }
            throw cause;
        }
    }

    private static boolean ci() {
        int iA = pg.a.a();
        return ((Boolean) e(pg.a.a(), iA, 732370085, new Object[0], pg.a.a(), -732370051, pg.a.a())).booleanValue();
    }

    private static /* synthetic */ Object d(Object[] objArr) {
        int iC;
        int i2 = j + 21;
        f = i2 % 128;
        if (i2 % 2 == 0) {
            iC = c(bu().f.idFeedbackScreenFlipIDBackImage, R.drawable.facetec_internal_id_card_back);
            int i3 = 57 / 0;
        } else {
            iC = c(bu().f.idFeedbackScreenFlipIDBackImage, R.drawable.facetec_internal_id_card_back);
        }
        return Integer.valueOf(iC);
    }

    public static void e() {
        f = (j + 41) % 128;
        FaceTecCustomization faceTecCustomization = FaceTecSDK.d;
        FaceTecOvalCustomization faceTecOvalCustomization = faceTecCustomization.n;
        if (faceTecOvalCustomization.progressRadialOffset == -1) {
            int i2 = f + 55;
            j = i2 % 128;
            if (i2 % 2 != 0) {
                faceTecOvalCustomization.progressRadialOffset = bz();
                throw null;
            }
            faceTecOvalCustomization.progressRadialOffset = bz();
        }
        FaceTecSDK.d = faceTecCustomization;
    }

    public static int f() {
        int i2 = (f + 55) % 128;
        j = i2;
        f = (i2 + 101) % 128;
        return -1;
    }

    public static int g() {
        int i2 = f + 97;
        j = i2 % 128;
        return i2 % 2 != 0 ? 82 : 10;
    }

    private static /* synthetic */ Object h(Object[] objArr) {
        Context context = (Context) objArr[0];
        j = (f + 25) % 128;
        int iB = dq.b(context, bG());
        int i2 = f + 41;
        j = i2 % 128;
        if (i2 % 2 == 0) {
            return Integer.valueOf(iB);
        }
        throw null;
    }

    public static int i() {
        j = (f + 45) % 128;
        int iMin = (int) (Math.min(Math.max(FaceTecSDK.d.f95813g.resultAnimationDisplayTime, 1.5d), 3.0d) * 1000.0d);
        int i2 = f + 51;
        j = i2 % 128;
        if (i2 % 2 == 0) {
            return iMin;
        }
        throw null;
    }

    public static void init$0() {
        $$a = new byte[]{74, 75, -50, -9};
        $$b = EnumC41897g.SDK_ASSET_ILLUSTRATION_PINWHEEL_LOGO_VALUE;
    }

    private static /* synthetic */ Object j(Object[] objArr) {
        float fA;
        int i2 = j + 59;
        f = i2 % 128;
        if (i2 % 2 == 0) {
            fA = bh.a(120) - (b() - c());
        } else {
            fA = bh.a(15) * b() * c();
        }
        int iRound = Math.round(fA);
        int i3 = j + 43;
        f = i3 % 128;
        if (i3 % 2 != 0) {
            return Integer.valueOf(iRound);
        }
        throw null;
    }

    public static int k() {
        Object objE;
        int i2 = f + 75;
        j = i2 % 128;
        if (i2 % 2 != 0) {
            Object[] objArr = {Integer.valueOf(FaceTecSDK.d.i.retryScreenImageBorderWidth), 0};
            objE = e(pg.a.a(), pg.a.a(), -1179194194, objArr, pg.a.a(), 1179194206, pg.a.a());
        } else {
            Object[] objArr2 = {Integer.valueOf(FaceTecSDK.d.i.retryScreenImageBorderWidth), 1};
            objE = e(pg.a.a(), pg.a.a(), -1179194194, objArr2, pg.a.a(), 1179194206, pg.a.a());
        }
        int iIntValue = ((Integer) objE).intValue();
        int i3 = f + 15;
        j = i3 % 128;
        if (i3 % 2 == 0) {
            return iIntValue;
        }
        throw null;
    }

    public static int l() {
        j = (f + 107) % 128;
        Object[] objArr = {Integer.valueOf(FaceTecSDK.d.o.borderWidth), 2};
        int iIntValue = ((Integer) e(pg.a.a(), pg.a.a(), -1179194194, objArr, pg.a.a(), 1179194206, pg.a.a())).intValue();
        int i2 = j + 7;
        f = i2 % 128;
        if (i2 % 2 == 0) {
            int i3 = 33 / 0;
        }
        return iIntValue;
    }

    private static /* synthetic */ Object m(Object[] objArr) {
        j = (f + 69) % 128;
        int iE = e(bu().k.customAnimation, FaceTecSDK.d.k.customAnimation);
        int i2 = j + 61;
        f = i2 % 128;
        if (i2 % 2 != 0) {
            return Integer.valueOf(iE);
        }
        throw null;
    }

    public static int n() {
        int i2 = j + 23;
        f = i2 % 128;
        int i3 = i2 % 2;
        return (int) (Math.min(Math.max(FaceTecSDK.d.f.additionalReviewScreenAnimationDisplayTime, 1.5d), 3.0d) * 1000.0d);
    }

    public static int o() {
        f = (j + 53) % 128;
        int iMin = (int) (Math.min(Math.max(FaceTecSDK.d.f.idFeedbackScreenAnimationDisplayTime, 1.5d), 3.0d) * 1000.0d);
        int i2 = j + 79;
        f = i2 % 128;
        if (i2 % 2 == 0) {
            int i3 = 17 / 0;
        }
        return iMin;
    }

    public static int p() {
        f = (j + 55) % 128;
        Object[] objArr = {Integer.valueOf(FaceTecSDK.d.f.buttonBorderWidth), 0};
        int iIntValue = ((Integer) e(pg.a.a(), pg.a.a(), -1179194194, objArr, pg.a.a(), 1179194206, pg.a.a())).intValue();
        int i2 = j + 125;
        f = i2 % 128;
        if (i2 % 2 != 0) {
            return iIntValue;
        }
        throw null;
    }

    private static /* synthetic */ Object q(Object[] objArr) {
        Object objE;
        int i2 = f + 23;
        j = i2 % 128;
        if (i2 % 2 != 0) {
            Object[] objArr2 = {Integer.valueOf(FaceTecSDK.d.o.cornerRadius), 57};
            objE = e(pg.a.a(), pg.a.a(), -1179194194, objArr2, pg.a.a(), 1179194206, pg.a.a());
        } else {
            Object[] objArr3 = {Integer.valueOf(FaceTecSDK.d.o.cornerRadius), 20};
            objE = e(pg.a.a(), pg.a.a(), -1179194194, objArr3, pg.a.a(), 1179194206, pg.a.a());
        }
        int iIntValue = ((Integer) objE).intValue();
        int i3 = j + 11;
        f = i3 % 128;
        if (i3 % 2 != 0) {
            return Integer.valueOf(iIntValue);
        }
        throw null;
    }

    public static int r() {
        f = (j + 119) % 128;
        Object[] objArr = {Integer.valueOf(FaceTecSDK.d.j.mainHeaderDividerLineWidth), 2};
        int iIntValue = ((Integer) e(pg.a.a(), pg.a.a(), -1179194194, objArr, pg.a.a(), 1179194206, pg.a.a())).intValue();
        j = (f + 11) % 128;
        return iIntValue;
    }

    private static /* synthetic */ Object s(Object[] objArr) {
        int i2;
        int i3 = j + 65;
        f = i3 % 128;
        if (i3 % 2 == 0) {
            i2 = bu().f.captureScreenForegroundColor;
            int i4 = 66 / 0;
        } else {
            i2 = bu().f.captureScreenForegroundColor;
        }
        return Integer.valueOf(i2);
    }

    public static int t() {
        Object objE;
        int i2 = j + 105;
        f = i2 % 128;
        if (i2 % 2 == 0) {
            Object[] objArr = {Integer.valueOf(FaceTecSDK.d.j.inputFieldBorderWidth), 0};
            objE = e(pg.a.a(), pg.a.a(), -1179194194, objArr, pg.a.a(), 1179194206, pg.a.a());
        } else {
            Object[] objArr2 = {Integer.valueOf(FaceTecSDK.d.j.inputFieldBorderWidth), 1};
            objE = e(pg.a.a(), pg.a.a(), -1179194194, objArr2, pg.a.a(), 1179194206, pg.a.a());
        }
        return ((Integer) objE).intValue();
    }

    public static int u() {
        f = (j + 105) % 128;
        Object[] objArr = {Integer.valueOf(FaceTecSDK.d.j.scrollIndicatorBorderWidth), 0};
        int iIntValue = ((Integer) e(pg.a.a(), pg.a.a(), -1179194194, objArr, pg.a.a(), 1179194206, pg.a.a())).intValue();
        int i2 = j + 69;
        f = i2 % 128;
        if (i2 % 2 != 0) {
            return iIntValue;
        }
        throw null;
    }

    public static int v() {
        j = (f + 3) % 128;
        Object[] objArr = {Integer.valueOf(FaceTecSDK.d.f.reviewScreenTextBackgroundBorderWidth), 0};
        int iIntValue = ((Integer) e(pg.a.a(), pg.a.a(), -1179194194, objArr, pg.a.a(), 1179194206, pg.a.a())).intValue();
        f = (j + 71) % 128;
        return iIntValue;
    }

    public static int w() {
        f = (j + 105) % 128;
        Object[] objArr = {Integer.valueOf(FaceTecSDK.d.f.captureScreenTextBackgroundBorderWidth), 0};
        int iIntValue = ((Integer) e(pg.a.a(), pg.a.a(), -1179194194, objArr, pg.a.a(), 1179194206, pg.a.a())).intValue();
        f = (j + EnumC41897g.SDK_ASSET_ILLUSTRATION_CALENDAR_VALUE) % 128;
        return iIntValue;
    }

    public static int x() {
        int i2 = FaceTecSDK.d.j.scrollIndicatorCornerRadius;
        if (i2 == -1) {
            f = (j + EnumC41897g.SDK_ASSET_ILLUSTRATION_DEPOSIT_SWITCH_VALUE) % 128;
            i2 = -1;
        }
        if (i2 != -1) {
            return Math.round(i2 * b());
        }
        f = (j + 87) % 128;
        return i2;
    }

    public static int y() {
        f = (j + 61) % 128;
        Object[] objArr = {Integer.valueOf(FaceTecSDK.d.f.captureFrameStrokeWidth), 2};
        int iIntValue = ((Integer) e(pg.a.a(), pg.a.a(), -1179194194, objArr, pg.a.a(), 1179194206, pg.a.a())).intValue();
        int i2 = j + 115;
        f = i2 % 128;
        if (i2 % 2 == 0) {
            int i3 = 2 / 0;
        }
        return iIntValue;
    }

    public static int z() {
        f = (j + 59) % 128;
        Object[] objArr = {Integer.valueOf(FaceTecSDK.d.i.readyScreenTextBackgroundCornerRadius), 6};
        int iIntValue = ((Integer) e(pg.a.a(), pg.a.a(), -1179194194, objArr, pg.a.a(), 1179194206, pg.a.a())).intValue();
        f = (j + 65) % 128;
        return iIntValue;
    }

    public static int A() {
        int iA = pg.a.a();
        return ((Integer) e(pg.a.a(), iA, -443713383, new Object[0], pg.a.a(), 443713384, pg.a.a())).intValue();
    }

    public static int B() {
        int iA = pg.a.a();
        return ((Integer) e(pg.a.a(), iA, -547259901, new Object[0], pg.a.a(), 547259923, pg.a.a())).intValue();
    }

    private static /* synthetic */ Object C(Object[] objArr) {
        int iC;
        int i2 = j + 31;
        f = i2 % 128;
        if (i2 % 2 == 0) {
            iC = c(FaceTecSDK.d.i.cameraPermissionsScreenImage, R.drawable.facetec_camera);
            int i3 = 11 / 0;
        } else {
            iC = c(FaceTecSDK.d.i.cameraPermissionsScreenImage, R.drawable.facetec_camera);
        }
        return Integer.valueOf(iC);
    }

    private static /* synthetic */ Object D(Object[] objArr) {
        int i2 = f + EnumC41897g.SDK_ASSET_ILLUSTRATION_DEPOSIT_SWITCH_VALUE;
        j = i2 % 128;
        if (i2 % 2 != 0) {
            FaceTecGuidanceCustomization faceTecGuidanceCustomization = FaceTecSDK.d.i;
            throw null;
        }
        FaceTecGuidanceCustomization faceTecGuidanceCustomization2 = FaceTecSDK.d.i;
        Typeface typeface = (Typeface) e(faceTecGuidanceCustomization2.retryScreenHeaderFont, faceTecGuidanceCustomization2.headerFont);
        j = (f + 69) % 128;
        return typeface;
    }

    private static int a(int i2) {
        f = (j + 119) % 128;
        if (!FaceTecSDK.a()) {
            if (FaceTecSDK.c == FaceTecSDK.c.BRIGHT_LIGHT) {
                return -16777216;
            }
            return i2;
        }
        int i3 = j + 41;
        f = i3 % 128;
        if (i3 % 2 == 0) {
            int i4 = 18 / 0;
        }
        return -1;
    }

    public static int b(Context context) {
        int i2 = j + 107;
        f = i2 % 128;
        int i3 = i2 % 2;
        int iC = c(bu().j.inputFieldPlaceholderTextColor, dq.c(dq.b(context, as()), 102));
        f = (j + EnumC41897g.SDK_ASSET_ILLUSTRATION_DEPOSIT_SWITCH_VALUE) % 128;
        return iC;
    }

    private static /* synthetic */ Object c(Object[] objArr) {
        Object objE;
        int i2 = f + 43;
        j = i2 % 128;
        if (i2 % 2 != 0) {
            Object[] objArr2 = {Integer.valueOf(FaceTecSDK.d.n.strokeWidth), 50};
            objE = e(pg.a.a(), pg.a.a(), -1179194194, objArr2, pg.a.a(), 1179194206, pg.a.a());
        } else {
            Object[] objArr3 = {Integer.valueOf(FaceTecSDK.d.n.strokeWidth), 6};
            objE = e(pg.a.a(), pg.a.a(), -1179194194, objArr3, pg.a.a(), 1179194206, pg.a.a());
        }
        int iIntValue = ((Integer) objE).intValue();
        int i3 = j + 125;
        f = i3 % 128;
        if (i3 % 2 != 0) {
            return Integer.valueOf(iIntValue);
        }
        throw null;
    }

    public static int d(Context context) {
        int i2 = f + 77;
        j = i2 % 128;
        if (i2 % 2 == 0) {
            int iA = pg.a.a();
            return dq.b(context, ((Integer) e(pg.a.a(), iA, 1565486859, new Object[0], pg.a.a(), -1565486852, pg.a.a())).intValue());
        }
        int iA2 = pg.a.a();
        dq.b(context, ((Integer) e(pg.a.a(), iA2, 1565486859, new Object[0], pg.a.a(), -1565486852, pg.a.a())).intValue());
        throw null;
    }

    public static int f(@NonNull Context context) {
        f = (j + 59) % 128;
        int iC = c(dq.b(context, bE()), u(context));
        int i2 = f + 79;
        j = i2 % 128;
        if (i2 % 2 == 0) {
            return iC;
        }
        throw null;
    }

    private static /* synthetic */ Object g(Object[] objArr) {
        f = (j + 1) % 128;
        int i2 = bu().f.captureFrameStrokeColor;
        int i3 = f + 15;
        j = i3 % 128;
        if (i3 % 2 == 0) {
            return Integer.valueOf(i2);
        }
        throw null;
    }

    public static int h(@NonNull Context context) {
        int i2 = f + EnumC41897g.SDK_ASSET_ILLUSTRATION_DEPOSIT_SWITCH_VALUE;
        j = i2 % 128;
        if (i2 % 2 == 0) {
            return c(dq.b(context, bC()), u(context));
        }
        c(dq.b(context, bC()), u(context));
        throw null;
    }

    private static /* synthetic */ Object i(Object[] objArr) {
        FaceTecCustomization faceTecCustomization = (FaceTecCustomization) objArr[0];
        Typeface typeface = Typeface.DEFAULT_BOLD;
        Typeface typeface2 = Typeface.DEFAULT;
        FaceTecFeedbackCustomization faceTecFeedbackCustomization = faceTecCustomization.l;
        if (faceTecFeedbackCustomization.textFont == null) {
            faceTecFeedbackCustomization.textFont = typeface2;
        }
        FaceTecGuidanceCustomization faceTecGuidanceCustomization = faceTecCustomization.i;
        if (faceTecGuidanceCustomization.headerFont == null) {
            faceTecGuidanceCustomization.headerFont = typeface;
        }
        if (faceTecGuidanceCustomization.subtextFont == null) {
            faceTecGuidanceCustomization.subtextFont = typeface2;
        }
        if (faceTecGuidanceCustomization.buttonFont == null) {
            faceTecGuidanceCustomization.buttonFont = typeface2;
        }
        FaceTecResultScreenCustomization faceTecResultScreenCustomization = faceTecCustomization.f95813g;
        if (faceTecResultScreenCustomization.messageFont == null) {
            faceTecResultScreenCustomization.messageFont = typeface2;
        }
        FaceTecIDScanCustomization faceTecIDScanCustomization = faceTecCustomization.f;
        if (faceTecIDScanCustomization.headerFont == null) {
            faceTecIDScanCustomization.headerFont = typeface;
        }
        if (faceTecIDScanCustomization.subtextFont == null) {
            faceTecIDScanCustomization.subtextFont = typeface2;
        }
        if (faceTecIDScanCustomization.buttonFont == null) {
            faceTecIDScanCustomization.buttonFont = typeface2;
        }
        if (faceTecIDScanCustomization.captureScreenFocusMessageFont == null) {
            faceTecIDScanCustomization.captureScreenFocusMessageFont = typeface2;
        }
        FaceTecOCRConfirmationCustomization faceTecOCRConfirmationCustomization = faceTecCustomization.j;
        if (faceTecOCRConfirmationCustomization.buttonFont == null) {
            faceTecOCRConfirmationCustomization.buttonFont = typeface2;
            f = (j + 1) % 128;
        }
        if (faceTecOCRConfirmationCustomization.mainHeaderFont == null) {
            faceTecOCRConfirmationCustomization.mainHeaderFont = typeface;
            f = (j + 57) % 128;
        }
        if (faceTecOCRConfirmationCustomization.sectionHeaderFont == null) {
            faceTecOCRConfirmationCustomization.sectionHeaderFont = typeface;
        }
        if (faceTecOCRConfirmationCustomization.fieldLabelFont == null) {
            faceTecOCRConfirmationCustomization.fieldLabelFont = typeface2;
        }
        if (faceTecOCRConfirmationCustomization.fieldValueFont == null) {
            faceTecOCRConfirmationCustomization.fieldValueFont = typeface2;
        }
        if (faceTecOCRConfirmationCustomization.inputFieldFont == null) {
            faceTecOCRConfirmationCustomization.inputFieldFont = faceTecOCRConfirmationCustomization.fieldValueFont;
        }
        if (faceTecOCRConfirmationCustomization.inputFieldPlaceholderFont == null) {
            faceTecOCRConfirmationCustomization.inputFieldPlaceholderFont = faceTecOCRConfirmationCustomization.inputFieldFont;
        }
        if (faceTecOCRConfirmationCustomization.scrollIndicatorFont != null) {
            return faceTecCustomization;
        }
        int i2 = j + 95;
        f = i2 % 128;
        if (i2 % 2 != 0) {
            faceTecOCRConfirmationCustomization.scrollIndicatorFont = typeface2;
            return faceTecCustomization;
        }
        faceTecOCRConfirmationCustomization.scrollIndicatorFont = typeface2;
        throw null;
    }

    public static int k(@NonNull Context context) {
        f = (j + 27) % 128;
        int iC = dq.c(dq.b(context, bI()), 255);
        f = (j + 13) % 128;
        return iC;
    }

    private static /* synthetic */ Object l(Object[] objArr) {
        int i2 = f + 7;
        j = i2 % 128;
        if (i2 % 2 == 0) {
            return Integer.valueOf(bu().f.captureScreenTextBackgroundColor);
        }
        int i3 = bu().f.captureScreenTextBackgroundColor;
        throw null;
    }

    public static int m(@NonNull Context context) {
        int i2 = f + 39;
        j = i2 % 128;
        if (i2 % 2 != 0) {
            dq.b(context, bF());
            throw null;
        }
        int iB = dq.b(context, bF());
        int i3 = j + 53;
        f = i3 % 128;
        if (i3 % 2 == 0) {
            int i4 = 3 / 0;
        }
        return iB;
    }

    public static int n(@NonNull Context context) {
        int iB;
        int i2 = j + 59;
        f = i2 % 128;
        if (i2 % 2 == 0) {
            iB = dq.b(context, bM());
            int i3 = 67 / 0;
        } else {
            iB = dq.b(context, bM());
        }
        j = (f + 125) % 128;
        return iB;
    }

    private static /* synthetic */ Object o(Object[] objArr) {
        f = (j + 59) % 128;
        int i2 = bu().f.buttonTextNormalColor;
        int i3 = j + 19;
        f = i3 % 128;
        if (i3 % 2 != 0) {
            return Integer.valueOf(i2);
        }
        throw null;
    }

    private static /* synthetic */ Object p(Object[] objArr) {
        int i2 = f + 9;
        j = i2 % 128;
        if (i2 % 2 != 0) {
            int i3 = bu().f.additionalReviewScreenForegroundColor;
            throw null;
        }
        int i4 = bu().f.additionalReviewScreenForegroundColor;
        int i5 = j + EnumC41897g.SDK_ASSET_ILLUSTRATION_CALENDAR_VALUE;
        f = i5 % 128;
        if (i5 % 2 != 0) {
            return Integer.valueOf(i4);
        }
        throw null;
    }

    public static int q(@NonNull Context context) {
        int i2 = f + EnumC41897g.SDK_ASSET_ILLUSTRATION_DEPOSIT_SWITCH_VALUE;
        j = i2 % 128;
        if (i2 % 2 == 0) {
            return dq.b(context, bS());
        }
        int i3 = 1 / 0;
        return dq.b(context, bS());
    }

    private static /* synthetic */ Object r(Object[] objArr) {
        f = (j + 85) % 128;
        Object[] objArr2 = {Integer.valueOf(FaceTecSDK.d.j.inputFieldCornerRadius), 3};
        int iIntValue = ((Integer) e(pg.a.a(), pg.a.a(), -1179194194, objArr2, pg.a.a(), 1179194206, pg.a.a())).intValue();
        int i2 = j + 57;
        f = i2 % 128;
        if (i2 % 2 != 0) {
            return Integer.valueOf(iIntValue);
        }
        int i3 = 73 / 0;
        return Integer.valueOf(iIntValue);
    }

    public static int s(@NonNull Context context) {
        f = (j + 55) % 128;
        int iB = dq.b(context, bL());
        int i2 = f + 31;
        j = i2 % 128;
        if (i2 % 2 == 0) {
            return iB;
        }
        throw null;
    }

    private static /* synthetic */ Object t(Object[] objArr) {
        int i2 = j + 55;
        f = i2 % 128;
        if (i2 % 2 != 0) {
            return Integer.valueOf(bu().i.buttonBackgroundDisabledColor);
        }
        int i3 = bu().i.buttonBackgroundDisabledColor;
        throw null;
    }

    private static int u(@NonNull Context context) {
        int i2 = j + 23;
        f = i2 % 128;
        if (i2 % 2 == 0) {
            dq.b(context, bB());
            throw null;
        }
        int iB = dq.b(context, bB());
        j = (f + 105) % 128;
        return iB;
    }

    private static /* synthetic */ Object v(Object[] objArr) {
        Context context = (Context) objArr[0];
        j = (f + 21) % 128;
        int iB = dq.b(context, bQ());
        int i2 = j + 25;
        f = i2 % 128;
        if (i2 % 2 != 0) {
            return Integer.valueOf(iB);
        }
        throw null;
    }

    private static /* synthetic */ Object w(Object[] objArr) {
        j = (f + 21) % 128;
        int i2 = bu().i.readyScreenTextBackgroundColor;
        int i3 = f + 87;
        j = i3 % 128;
        if (i3 % 2 == 0) {
            return Integer.valueOf(i2);
        }
        int i4 = 10 / 0;
        return Integer.valueOf(i2);
    }

    private static /* synthetic */ Object y(Object[] objArr) {
        boolean z;
        boolean zBooleanValue = ((Boolean) objArr[0]).booleanValue();
        int i2 = j + 13;
        f = i2 % 128;
        if (i2 % 2 == 0) {
            dp.a(R.string.FaceTec_retry_instruction_message_3);
            throw null;
        }
        String strA = dp.a(R.string.FaceTec_retry_instruction_message_3);
        if (!zBooleanValue || FaceTecSDK.d.b || strA.length() <= 40) {
            z = false;
        } else {
            j = (f + 7) % 128;
            z = true;
        }
        if (!z) {
            return strA;
        }
        int i3 = j + 61;
        f = i3 % 128;
        return i3 % 2 == 0 ? strA.substring(0, 4) : strA.substring(0, 40);
    }

    private static /* synthetic */ Object z(Object[] objArr) {
        f = (j + 115) % 128;
        int i2 = bu().f.customNFCStartingAnimation;
        int i3 = j + 3;
        f = i3 % 128;
        if (i3 % 2 != 0) {
            return Integer.valueOf(i2);
        }
        int i4 = 18 / 0;
        return Integer.valueOf(i2);
    }

    public static void b(@NonNull View view) {
        int iBI = bI();
        int i2 = AnonymousClass3.d[dq.e(view.getContext(), iBI).ordinal()];
        if (i2 == 1) {
            view.setBackgroundResource(iBI);
            return;
        }
        if (i2 == 2) {
            view.setBackgroundColor(iBI);
            f = (j + 13) % 128;
        }
        int i3 = j + 105;
        f = i3 % 128;
        if (i3 % 2 == 0) {
            throw null;
        }
    }

    public static int c(Context context) {
        int identifier;
        if (!FaceTecSDK.d.a) {
            identifier = 0;
        } else {
            int iC = c(bu().f.standaloneIDScanWatermark, FaceTecSDK.d.f.standaloneIDScanWatermark);
            if (iC == 0) {
                identifier = dq.a(context).getIdentifier("facetec_standalone_id_scan_watermark", "drawable", context.getPackageName());
                f = (j + 15) % 128;
            } else {
                identifier = iC;
            }
        }
        if (identifier != 0) {
            return identifier;
        }
        j = (f + 95) % 128;
        return R.drawable.facetec_internal_id_scan_watermark;
    }

    public static void d(@NonNull View view) {
        f = (j + 61) % 128;
        int iBy = by();
        int i2 = AnonymousClass3.d[dq.e(view.getContext(), iBy).ordinal()];
        if (i2 == 1) {
            view.setBackgroundResource(iBy);
            j = (f + 27) % 128;
        } else if (i2 != 2) {
            view.setBackgroundColor(0);
        } else {
            view.setBackgroundColor(iBy);
        }
    }

    private static /* synthetic */ Object f(Object[] objArr) {
        boolean zBooleanValue = ((Boolean) objArr[0]).booleanValue();
        f = (j + 77) % 128;
        String strE = e(false, zBooleanValue);
        String strC = c(false, zBooleanValue);
        if (strE.length() > 50) {
            int i2 = f + 109;
            j = i2 % 128;
            if (i2 % 2 != 0) {
                d("Ready Screen Subtext Line 1");
                int i3 = 53 / 0;
            } else {
                d("Ready Screen Subtext Line 1");
            }
        }
        if (strC.length() <= 50) {
            return null;
        }
        j = (f + 19) % 128;
        d("Ready Screen Subtext Line 2");
        return null;
    }

    public static void g(boolean z) {
        f = (j + 91) % 128;
        String strA = a(false, z);
        if (strA.length() > 30) {
            d("Retry Screen Header");
            return;
        }
        if (strA.length() > 20) {
            int i2 = f + 41;
            j = i2 % 128;
            if (i2 % 2 == 0) {
                e("Retry Screen Header");
            } else {
                e("Retry Screen Header");
                throw null;
            }
        }
    }

    @NonNull
    public static FaceTecSize h() {
        int iA = pg.a.a();
        return (FaceTecSize) e(pg.a.a(), iA, -1527441011, new Object[0], pg.a.a(), 1527441052, pg.a.a());
    }

    public static int l(@NonNull Context context) {
        int iB;
        int i2;
        int i3 = j + 73;
        f = i3 % 128;
        if (i3 % 2 == 0) {
            iB = dq.b(context, bJ());
            i2 = 23198;
        } else {
            iB = dq.b(context, bJ());
            i2 = 255;
        }
        int iC = dq.c(iB, i2);
        int i4 = j + 29;
        f = i4 % 128;
        if (i4 % 2 != 0) {
            return iC;
        }
        throw null;
    }

    public static int m() {
        int iA = pg.a.a();
        return ((Integer) e(pg.a.a(), iA, 1178154252, new Object[0], pg.a.a(), -1178154250, pg.a.a())).intValue();
    }

    private static /* synthetic */ Object n(Object[] objArr) {
        int i2 = 0;
        int iIntValue = ((Number) objArr[0]).intValue();
        int iIntValue2 = ((Number) objArr[1]).intValue();
        int i3 = f + 117;
        int i4 = i3 % 128;
        j = i4;
        if (i3 % 2 == 0) {
            if (iIntValue == -1) {
                f = (i4 + 57) % 128;
                iIntValue = iIntValue2;
            }
            if (iIntValue == 0) {
                f = (i4 + 63) % 128;
            } else {
                f = (i4 + 9) % 128;
                i2 = 1;
            }
            return Integer.valueOf(Math.max(i2, Math.round(iIntValue * b())));
        }
        throw null;
    }

    public static int o(@NonNull Context context) {
        int i2 = j + 59;
        f = i2 % 128;
        if (i2 % 2 == 0) {
            dq.b(context, bO());
            throw null;
        }
        int iB = dq.b(context, bO());
        int i3 = j + 11;
        f = i3 % 128;
        if (i3 % 2 == 0) {
            int i4 = 73 / 0;
        }
        return iB;
    }

    @NonNull
    public static Drawable p(@NonNull Context context) {
        int iW = W();
        if (AnonymousClass3.d[dq.e(context, iW).ordinal()] == 1) {
            if (C6852.getDrawable(context, iW) != null) {
                Drawable drawableMutate = C6852.getDrawable(context, iW).mutate();
                if (drawableMutate instanceof ShapeDrawable) {
                    ((ShapeDrawable) drawableMutate).getPaint().setAlpha(255);
                    return drawableMutate;
                }
                if (drawableMutate instanceof GradientDrawable) {
                    return c(context, (GradientDrawable) drawableMutate);
                }
                if (drawableMutate instanceof ColorDrawable) {
                    f = (j + 13) % 128;
                    drawableMutate.setAlpha(255);
                    f = (j + 97) % 128;
                    return drawableMutate;
                }
            } else {
                GradientDrawable gradientDrawable = new GradientDrawable();
                gradientDrawable.setColor(dq.c(C6852.getColor(context, iW), 255));
                return gradientDrawable;
            }
        }
        GradientDrawable gradientDrawable2 = new GradientDrawable();
        gradientDrawable2.setColor(dq.c(iW, 255));
        return gradientDrawable2;
    }

    public static int q() {
        int iA = pg.a.a();
        return ((Integer) e(pg.a.a(), iA, 1496912795, new Object[0], pg.a.a(), -1496912776, pg.a.a())).intValue();
    }

    public static int r(@NonNull Context context) {
        int i2 = j + EnumC41897g.SDK_ASSET_ILLUSTRATION_DEPOSIT_SWITCH_VALUE;
        f = i2 % 128;
        if (i2 % 2 == 0) {
            dq.b(context, bH());
            throw null;
        }
        int iB = dq.b(context, bH());
        int i3 = j + 13;
        f = i3 % 128;
        if (i3 % 2 != 0) {
            return iB;
        }
        throw null;
    }

    public static int s() {
        int iA = pg.a.a();
        return ((Integer) e(pg.a.a(), iA, -1375711728, new Object[0], pg.a.a(), 1375711749, pg.a.a())).intValue();
    }

    public static int t(@NonNull Context context) {
        int iA = pg.a.a();
        return ((Integer) e(pg.a.a(), iA, 1009688708, new Object[]{context}, pg.a.a(), -1009688672, pg.a.a())).intValue();
    }

    private static /* synthetic */ Object u(Object[] objArr) {
        int i2;
        int i3 = f + 33;
        j = i3 % 128;
        if (i3 % 2 != 0) {
            i2 = bu().f.additionalReviewScreenAnimation;
            int i4 = 81 / 0;
        } else {
            i2 = bu().f.additionalReviewScreenAnimation;
        }
        return Integer.valueOf(i2);
    }

    public static GradientDrawable v(@NonNull Context context) {
        GradientDrawable gradientDrawable = new GradientDrawable();
        int iBT = bT();
        int i2 = AnonymousClass3.d[dq.e(context, iBT).ordinal()];
        if (i2 != 1) {
            if (i2 == 2) {
                gradientDrawable.setColor(iBT);
                f = (j + 113) % 128;
            }
        } else if (C6852.getDrawable(context, iBT) instanceof GradientDrawable) {
            int i3 = f + 69;
            j = i3 % 128;
            if (i3 % 2 != 0) {
                throw null;
            }
            gradientDrawable = (GradientDrawable) C6852.getDrawable(context, iBT);
        } else {
            gradientDrawable.setColor(C6852.getColor(context, iBT));
        }
        if (gradientDrawable != null) {
            int i4 = f + 7;
            j = i4 % 128;
            gradientDrawable.setCornerRadius(bh.a((int) (i4 % 2 != 0 ? bw() % c() : bw() * c())));
        }
        return gradientDrawable;
    }

    private static /* synthetic */ Object x(Object[] objArr) {
        dr drVar = (dr) objArr[0];
        int i2 = j + 111;
        f = i2 % 128;
        if (i2 % 2 != 0) {
            HashMap<dr, String> map = FaceTecCustomization.p;
            String str = map != null ? map.get(drVar) : null;
            j = (f + 73) % 128;
            return str;
        }
        String str2 = FaceTecCustomization.overrideResultScreenSuccessMessage;
        throw null;
    }

    /* JADX WARN: Removed duplicated region for block: B:16:0x004d  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    private static /* synthetic */ java.lang.Object k(java.lang.Object[] r4) {
        /*
            r0 = 0
            r1 = r4[r0]
            java.lang.Boolean r1 = (java.lang.Boolean) r1
            boolean r1 = r1.booleanValue()
            r2 = 1
            r4 = r4[r2]
            java.lang.Boolean r4 = (java.lang.Boolean) r4
            boolean r4 = r4.booleanValue()
            int r3 = com.facetec.sdk.dm.f
            int r3 = r3 + 29
            int r3 = r3 % 128
            com.facetec.sdk.dm.j = r3
            com.facetec.sdk.FaceTecCustomization r3 = com.facetec.sdk.FaceTecSDK.d
            com.facetec.sdk.FaceTecGuidanceCustomization r3 = r3.i
            java.lang.String r3 = r3.retryScreenSubtextAttributedString
            if (r4 != 0) goto L2e
            boolean r4 = r3.isEmpty()
            if (r4 == 0) goto L2e
            int r4 = com.facetec.sdk.R.string.FaceTec_retry_subheader_message
            java.lang.String r3 = com.facetec.sdk.dp.a(r4)
        L2e:
            if (r1 == r2) goto L31
            goto L76
        L31:
            int r4 = com.facetec.sdk.dm.j
            int r4 = r4 + 3
            int r1 = r4 % 128
            com.facetec.sdk.dm.f = r1
            int r4 = r4 % 2
            if (r4 != 0) goto L47
            com.facetec.sdk.FaceTecCustomization r4 = com.facetec.sdk.FaceTecSDK.d
            boolean r4 = r4.b
            r1 = 15
            int r1 = r1 / r0
            if (r4 != 0) goto L76
            goto L4d
        L47:
            com.facetec.sdk.FaceTecCustomization r4 = com.facetec.sdk.FaceTecSDK.d
            boolean r4 = r4.b
            if (r4 != 0) goto L76
        L4d:
            int r4 = r3.length()
            r1 = 40
            if (r4 <= r1) goto L76
            int r4 = com.facetec.sdk.dm.f
            int r4 = r4 + 89
            int r2 = r4 % 128
            com.facetec.sdk.dm.j = r2
            int r4 = r4 % 2
            if (r4 == 0) goto L69
            r4 = 73
            java.lang.String r4 = r3.substring(r0, r4)
        L67:
            r3 = r4
            goto L6e
        L69:
            java.lang.String r4 = r3.substring(r0, r1)
            goto L67
        L6e:
            int r4 = com.facetec.sdk.dm.j
            int r4 = r4 + 105
            int r4 = r4 % 128
            com.facetec.sdk.dm.f = r4
        L76:
            int r4 = com.facetec.sdk.dm.f
            int r4 = r4 + 59
            int r0 = r4 % 128
            com.facetec.sdk.dm.j = r0
            int r4 = r4 % 2
            if (r4 != 0) goto L83
            return r3
        L83:
            r4 = 0
            throw r4
        */
        throw new UnsupportedOperationException("Method not decompiled: com.facetec.sdk.dm.k(java.lang.Object[]):java.lang.Object");
    }

    public static int a(Context context) {
        j = (f + 101) % 128;
        int iB = dq.b(context, cb());
        int i2 = f + 43;
        j = i2 % 128;
        if (i2 % 2 == 0) {
            return iB;
        }
        throw null;
    }

    public static void a(@NonNull View view) {
        int iBP = bP();
        int i2 = AnonymousClass3.d[dq.e(view.getContext(), iBP).ordinal()];
        if (i2 != 1) {
            if (i2 != 2) {
                view.setBackgroundColor(0);
                return;
            } else {
                view.setBackgroundColor(iBP);
                j = (f + 21) % 128;
                return;
            }
        }
        view.setBackgroundResource(iBP);
        int i3 = j + 5;
        f = i3 % 128;
        if (i3 % 2 == 0) {
            throw null;
        }
    }

    private static int e(int i2, int i3) {
        if (i2 == 0) {
            return i3;
        }
        int i4 = j + 47;
        int i5 = i4 % 128;
        f = i5;
        if (i4 % 2 == 0) {
            throw null;
        }
        j = (i5 + 83) % 128;
        return i2;
    }

    public static int j() {
        int i2;
        j = (f + 93) % 128;
        float fB = b() * c();
        if (dp.a(R.string.FaceTec_idscan_type_selection_header).length() > 36) {
            int i3 = f + 81;
            j = i3 % 128;
            i2 = i3 % 2 != 0 ? 127 : -4;
        } else {
            i2 = 0;
        }
        return Math.round((i2 + 28) * fB);
    }

    public static void b(@NonNull TextView textView) {
        int i2 = j + 23;
        f = i2 % 128;
        if (i2 % 2 != 0) {
            dq.c(textView, bU());
        } else {
            dq.c(textView, bU());
            throw null;
        }
    }

    public static void c(@NonNull TextView textView) {
        int i2 = j + 29;
        f = i2 % 128;
        if (i2 % 2 != 0) {
            textView.getContext();
            dq.c(textView, bB());
            f = (j + 113) % 128;
        } else {
            textView.getContext();
            dq.c(textView, bB());
            throw null;
        }
    }

    private static /* synthetic */ Object e(Object[] objArr) {
        int iC;
        int i2 = f + 79;
        j = i2 % 128;
        if (i2 % 2 != 0) {
            iC = c(bu().f95813g.resultAnimationSuccessBackgroundImage, FaceTecSDK.d.f95813g.resultAnimationSuccessBackgroundImage);
            int i3 = 12 / 0;
        } else {
            iC = c(bu().f95813g.resultAnimationSuccessBackgroundImage, FaceTecSDK.d.f95813g.resultAnimationSuccessBackgroundImage);
        }
        return Integer.valueOf(iC);
    }

    public static void d(@NonNull TextView textView) {
        f = (j + 71) % 128;
        dq.c(textView, S());
        int i2 = f + 27;
        j = i2 % 128;
        if (i2 % 2 != 0) {
            throw null;
        }
    }

    /* JADX WARN: Code restructure failed: missing block: B:10:0x0040, code lost:
    
        if (r4 != 2) goto L11;
     */
    /* JADX WARN: Code restructure failed: missing block: B:11:0x0042, code lost:
    
        r6.setBackgroundColor(0);
        r6 = com.facetec.sdk.dm.j + 57;
        com.facetec.sdk.dm.f = r6 % 128;
     */
    /* JADX WARN: Code restructure failed: missing block: B:12:0x004e, code lost:
    
        if ((r6 % 2) == 0) goto L14;
     */
    /* JADX WARN: Code restructure failed: missing block: B:13:0x0050, code lost:
    
        return;
     */
    /* JADX WARN: Code restructure failed: missing block: B:15:0x0052, code lost:
    
        throw null;
     */
    /* JADX WARN: Code restructure failed: missing block: B:16:0x0053, code lost:
    
        r6.setBackgroundColor(r0);
     */
    /* JADX WARN: Code restructure failed: missing block: B:17:0x0056, code lost:
    
        return;
     */
    /* JADX WARN: Code restructure failed: missing block: B:6:0x0027, code lost:
    
        if (r4 != 2) goto L11;
     */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public static void e(@androidx.annotation.NonNull android.view.View r6) {
        /*
            int r0 = com.facetec.sdk.dm.j
            int r0 = r0 + 9
            int r1 = r0 % 128
            com.facetec.sdk.dm.f = r1
            r1 = 2
            int r0 = r0 % r1
            r2 = 0
            r3 = 1
            if (r0 != 0) goto L2a
            int r0 = W()
            int[] r4 = com.facetec.sdk.dm.AnonymousClass3.d
            android.content.Context r5 = r6.getContext()
            com.facetec.sdk.dq$d r5 = com.facetec.sdk.dq.e(r5, r0)
            int r5 = r5.ordinal()
            r4 = r4[r5]
            r5 = 77
            int r5 = r5 / r2
            if (r4 == r3) goto L57
            if (r4 == r1) goto L53
            goto L42
        L2a:
            int r0 = W()
            int[] r4 = com.facetec.sdk.dm.AnonymousClass3.d
            android.content.Context r5 = r6.getContext()
            com.facetec.sdk.dq$d r5 = com.facetec.sdk.dq.e(r5, r0)
            int r5 = r5.ordinal()
            r4 = r4[r5]
            if (r4 == r3) goto L57
            if (r4 == r1) goto L53
        L42:
            r6.setBackgroundColor(r2)
            int r6 = com.facetec.sdk.dm.j
            int r6 = r6 + 57
            int r0 = r6 % 128
            com.facetec.sdk.dm.f = r0
            int r6 = r6 % r1
            if (r6 == 0) goto L51
            return
        L51:
            r6 = 0
            throw r6
        L53:
            r6.setBackgroundColor(r0)
            return
        L57:
            r6.setBackgroundResource(r0)
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: com.facetec.sdk.dm.e(android.view.View):void");
    }

    public static int g(@NonNull Context context) {
        int iA = pg.a.a();
        return ((Integer) e(pg.a.a(), iA, -761605403, new Object[]{context}, pg.a.a(), 761605409, pg.a.a())).intValue();
    }

    public static int j(@NonNull Context context) {
        f = (j + 107) % 128;
        int iC = c(dq.b(context, bA()), u(context));
        f = (j + 67) % 128;
        return iC;
    }

    public static void j(@NonNull View view) {
        j = (f + 59) % 128;
        d(view, bx());
        int i2 = f + 119;
        j = i2 % 128;
        if (i2 % 2 != 0) {
            throw null;
        }
    }

    public static void a(@NonNull TextView textView) {
        int i2 = f + 69;
        j = i2 % 128;
        if (i2 % 2 == 0) {
            dq.c(textView, bR());
        } else {
            dq.c(textView, bR());
            throw null;
        }
    }

    /* JADX WARN: Removed duplicated region for block: B:21:0x0062  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public static java.lang.String b(boolean r3, boolean r4) {
        /*
            com.facetec.sdk.FaceTecCustomization r0 = com.facetec.sdk.FaceTecSDK.d
            com.facetec.sdk.FaceTecGuidanceCustomization r0 = r0.i
            java.lang.String r0 = r0.readyScreenHeaderAttributedString
            boolean r1 = r0.isEmpty()
            java.lang.String r2 = "\n"
            if (r1 != 0) goto L26
            boolean r1 = r0.contains(r2)
            if (r1 == 0) goto L26
            int r1 = com.facetec.sdk.dm.j
            int r1 = r1 + 43
            int r1 = r1 % 128
            com.facetec.sdk.dm.f = r1
            int r1 = r0.indexOf(r2)
            int r1 = r1 + 1
            java.lang.String r0 = r0.substring(r1)
        L26:
            if (r4 != 0) goto L44
            boolean r4 = r0.isEmpty()
            if (r4 == 0) goto L44
            int r4 = com.facetec.sdk.R.string.FaceTec_instructions_header_ready_2
            java.lang.String r0 = com.facetec.sdk.dp.a(r4)
            boolean r4 = r0.contains(r2)
            if (r4 == 0) goto L44
            int r4 = r0.indexOf(r2)
            int r4 = r4 + 1
            java.lang.String r0 = r0.substring(r4)
        L44:
            if (r3 == 0) goto L7f
            int r3 = com.facetec.sdk.dm.f
            int r3 = r3 + 13
            int r4 = r3 % 128
            com.facetec.sdk.dm.j = r4
            int r3 = r3 % 2
            r4 = 0
            if (r3 == 0) goto L5c
            com.facetec.sdk.FaceTecCustomization r3 = com.facetec.sdk.FaceTecSDK.d
            boolean r3 = r3.b
            r1 = 5
            int r1 = r1 / r4
            if (r3 != 0) goto L7f
            goto L62
        L5c:
            com.facetec.sdk.FaceTecCustomization r3 = com.facetec.sdk.FaceTecSDK.d
            boolean r3 = r3.b
            if (r3 != 0) goto L7f
        L62:
            int r3 = r0.length()
            r1 = 30
            if (r3 <= r1) goto L7f
            int r3 = com.facetec.sdk.dm.j
            int r3 = r3 + 49
            int r3 = r3 % 128
            com.facetec.sdk.dm.f = r3
            java.lang.String r3 = r0.substring(r4, r1)
            int r4 = com.facetec.sdk.dm.f
            int r4 = r4 + 95
            int r4 = r4 % 128
            com.facetec.sdk.dm.j = r4
            return r3
        L7f:
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: com.facetec.sdk.dm.b(boolean, boolean):java.lang.String");
    }

    public static String d(boolean z) {
        f = (j + 15) % 128;
        String strA = dp.a(R.string.FaceTec_retry_your_image_label);
        if (z) {
            f = (j + 125) % 128;
            if (!FaceTecSDK.d.b) {
                f = (j + 85) % 128;
                if (strA.length() > 21) {
                    int i2 = (j + 91) % 128;
                    f = i2;
                    int i3 = i2 + 21;
                    j = i3 % 128;
                    return i3 % 2 != 0 ? strA.substring(1, 77) : strA.substring(0, 21);
                }
            }
        }
        return strA;
    }

    public static void f(boolean z) {
        Object[] objArr = {Boolean.valueOf(z)};
        e(pg.a.a(), pg.a.a(), -1480234844, objArr, pg.a.a(), 1480234855, pg.a.a());
    }

    public static void j(@NonNull TextView textView) {
        j = (f + 49) % 128;
        dq.c(textView, ca());
        j = (f + 53) % 128;
    }

    public static void c(@NonNull View view) {
        int i2 = f + 21;
        j = i2 % 128;
        if (i2 % 2 == 0) {
            int iX = X();
            int i3 = AnonymousClass3.d[dq.e(view.getContext(), iX).ordinal()];
            if (i3 == 1) {
                view.setBackgroundColor(C6852.getColor(view.getContext(), iX));
                return;
            } else if (i3 != 2) {
                view.setBackgroundColor(0);
                j = (f + 1) % 128;
                return;
            } else {
                view.setBackgroundColor(iX);
                return;
            }
        }
        int i4 = AnonymousClass3.d[dq.e(view.getContext(), X()).ordinal()];
        throw null;
    }

    public static void e(@NonNull TextView textView) {
        f = (j + 19) % 128;
        dq.c(textView, bW());
        j = (f + 37) % 128;
    }

    private static /* synthetic */ Object a(Object[] objArr) {
        boolean zBooleanValue = ((Boolean) objArr[0]).booleanValue();
        boolean zBooleanValue2 = ((Boolean) objArr[1]).booleanValue();
        int i2 = j + 101;
        f = i2 % 128;
        if (i2 % 2 != 0) {
            String strA = FaceTecSDK.d.i.readyScreenHeaderAttributedString;
            if (!strA.isEmpty() && strA.contains("\n")) {
                int i3 = f + 55;
                j = i3 % 128;
                int i4 = i3 % 2;
                strA = strA.substring(0, strA.indexOf("\n"));
            }
            if (!zBooleanValue2 && strA.isEmpty()) {
                j = (f + 61) % 128;
                strA = dp.a(R.string.FaceTec_instructions_header_ready_1);
                if (strA.contains("\n")) {
                    strA = strA.substring(0, strA.indexOf("\n"));
                }
            }
            if (zBooleanValue) {
                f = (j + 89) % 128;
                if (!FaceTecSDK.d.b) {
                    int i5 = j + 13;
                    f = i5 % 128;
                    if (i5 % 2 != 0 ? strA.length() > 30 : strA.length() > 36) {
                        int i6 = (j + 47) % 128;
                        f = i6;
                        j = (i6 + 13) % 128;
                        return strA.substring(0, 30);
                    }
                }
            }
            return strA;
        }
        FaceTecSDK.d.i.readyScreenHeaderAttributedString.isEmpty();
        throw null;
    }

    public static void j(boolean z) {
        Object[] objArr = {Boolean.FALSE, Boolean.valueOf(z)};
        String str = (String) e(pg.a.a(), pg.a.a(), -449345628, objArr, pg.a.a(), 449345631, pg.a.a());
        String strB = b(false, z);
        if (str.length() > 30) {
            int i2 = j + 89;
            f = i2 % 128;
            if (i2 % 2 != 0) {
                d("Ready Screen Header Line 1");
                j = (f + 117) % 128;
            } else {
                d("Ready Screen Header Line 1");
                throw null;
            }
        }
        if (strB.length() > 30) {
            int i3 = j + 29;
            f = i3 % 128;
            if (i3 % 2 == 0) {
                d("Ready Screen Header Line 2");
                int i4 = 35 / 0;
            } else {
                d("Ready Screen Header Line 2");
            }
        }
    }

    private static void d(String str) {
        String str2;
        int i2 = f + 51;
        j = i2 % 128;
        if (i2 % 2 != 0) {
            Locale locale = Locale.getDefault();
            Object[] objArr = new Object[0];
            objArr[1] = str;
            str2 = String.format(locale, "FaceTec SDK Text Customization Alert: Your text is too long for the %s text element to render correctly on a significant portion of supported devices. Please update this text string to short, concise text, based on our default text element for optimal User Experience and Success Rates. If you continue with too many characters, the FaceTec SDK will not show the excess characters, and this will likely impact User Experience and Success Rates. These character limitations must be in place to ensure compatibility with the 1,000,000+ Device/Model/Platform/Version/Screen Size/Camera Res combinations that FaceTec supports.", objArr);
        } else {
            str2 = String.format(Locale.getDefault(), "FaceTec SDK Text Customization Alert: Your text is too long for the %s text element to render correctly on a significant portion of supported devices. Please update this text string to short, concise text, based on our default text element for optimal User Experience and Success Rates. If you continue with too many characters, the FaceTec SDK will not show the excess characters, and this will likely impact User Experience and Success Rates. These character limitations must be in place to ensure compatibility with the 1,000,000+ Device/Model/Platform/Version/Screen Size/Camera Res combinations that FaceTec supports.", str);
        }
        bb.e(str2);
        j = (f + 47) % 128;
    }

    public static String e(boolean z, boolean z2) {
        String strA = FaceTecSDK.d.i.readyScreenSubtextAttributedString;
        if (!strA.isEmpty() && strA.contains("\n")) {
            strA = strA.substring(0, strA.indexOf("\n"));
        }
        if (!z2) {
            j = (f + 57) % 128;
            if (strA.isEmpty()) {
                strA = dp.a(R.string.FaceTec_instructions_message_ready_1);
                if (strA.contains("\n")) {
                    f = (j + 81) % 128;
                    strA = strA.substring(0, strA.indexOf("\n"));
                }
            }
        }
        if (z && !FaceTecSDK.d.b && strA.length() > 50) {
            j = (f + 39) % 128;
            return strA.substring(0, 50);
        }
        j = (f + 13) % 128;
        return strA;
    }

    public static void d(@NonNull View view, int i2) {
        f = (j + 67) % 128;
        dq.d(view, i2, k(view.getContext()));
        int i3 = j + 67;
        f = i3 % 128;
        if (i3 % 2 == 0) {
            throw null;
        }
    }

    public static void c(@NonNull ProgressBar progressBar, @NonNull Drawable drawable) {
        int i2 = f + 77;
        j = i2 % 128;
        if (i2 % 2 == 0) {
            int iBN = bN();
            int i3 = AnonymousClass3.d[dq.e(progressBar.getContext(), iBN).ordinal()];
            if (i3 != 1) {
                if (i3 == 2) {
                    ((GradientDrawable) drawable).setColor(iBN);
                }
                f = (j + 67) % 128;
                return;
            }
            ((GradientDrawable) drawable).setColor(C6852.getColor(progressBar.getContext(), iBN));
            return;
        }
        int i4 = AnonymousClass3.d[dq.e(progressBar.getContext(), bN()).ordinal()];
        throw null;
    }

    private static /* synthetic */ Object b(Object[] objArr) {
        j = (f + 49) % 128;
        j(false);
        e(pg.a.a(), pg.a.a(), -1480234844, new Object[]{Boolean.FALSE}, pg.a.a(), 1480234855, pg.a.a());
        g(false);
        i(false);
        if (!FaceTecSDK.d.enableOfficialIDPhoto) {
            int i2 = j + 89;
            f = i2 % 128;
            if (i2 % 2 != 0) {
                e(pg.a.a(), pg.a.a(), -648212982, new Object[0], pg.a.a(), 648213015, pg.a.a());
            } else {
                e(pg.a.a(), pg.a.a(), -648212982, new Object[0], pg.a.a(), 648213015, pg.a.a());
                throw null;
            }
        }
        cd();
        f = (j + 21) % 128;
        return null;
    }

    public static int d(@NonNull Context context, int i2) {
        f = (j + 113) % 128;
        int iA = dq.a(context, i2, k(context));
        int i3 = f + 31;
        j = i3 % 128;
        if (i3 % 2 != 0) {
            int i4 = 19 / 0;
        }
        return iA;
    }

    public static int d() {
        int iA = pg.a.a();
        return ((Integer) e(pg.a.a(), iA, 1933108801, new Object[0], pg.a.a(), -1933108792, pg.a.a())).intValue();
    }

    public static String d(boolean z, boolean z2) {
        Object[] objArr = {Boolean.valueOf(z), Boolean.valueOf(z2)};
        return (String) e(pg.a.a(), pg.a.a(), -449345628, objArr, pg.a.a(), 449345631, pg.a.a());
    }

    private static int d(int i2, int i3) {
        Object[] objArr = {Integer.valueOf(i2), Integer.valueOf(i3)};
        return ((Integer) e(pg.a.a(), pg.a.a(), -1179194194, objArr, pg.a.a(), 1179194206, pg.a.a())).intValue();
    }

    public static String j(boolean z, boolean z2) {
        Object[] objArr = {Boolean.valueOf(z), Boolean.valueOf(z2)};
        return (String) e(pg.a.a(), pg.a.a(), 1429122379, objArr, pg.a.a(), -1429122365, pg.a.a());
    }

    public static void c(@NonNull ProgressBar progressBar, @NonNull Drawable drawable, @NonNull Drawable drawable2) {
        int i2 = j + 9;
        f = i2 % 128;
        if (i2 % 2 != 0) {
            int iBK = bK();
            int i3 = AnonymousClass3.d[dq.e(progressBar.getContext(), iBK).ordinal()];
            if (i3 == 1) {
                ((GradientDrawable) drawable).setColor(C6852.getColor(progressBar.getContext(), iBK));
                ((GradientDrawable) drawable2).setColor(dq.e(C6852.getColor(progressBar.getContext(), iBK)));
                return;
            } else {
                if (i3 != 2) {
                    return;
                }
                ((GradientDrawable) drawable).setColor(iBK);
                ((GradientDrawable) drawable2).setColor(dq.e(iBK));
                f = (j + 15) % 128;
                return;
            }
        }
        int i4 = AnonymousClass3.d[dq.e(progressBar.getContext(), bK()).ordinal()];
        throw null;
    }

    /* JADX WARN: Removed duplicated region for block: B:19:0x004d A[PHI: r0
      0x004d: PHI (r0v7 java.lang.String) = 
      (r0v4 java.lang.String)
      (r0v5 java.lang.String)
      (r0v5 java.lang.String)
      (r0v5 java.lang.String)
      (r0v9 java.lang.String)
     binds: [B:8:0x0020, B:10:0x0027, B:17:0x0042, B:14:0x003b, B:5:0x0017] A[DONT_GENERATE, DONT_INLINE]] */
    /* JADX WARN: Removed duplicated region for block: B:9:0x0022 A[PHI: r0
      0x0022: PHI (r0v5 java.lang.String) = (r0v4 java.lang.String), (r0v9 java.lang.String) binds: [B:8:0x0020, B:5:0x0017] A[DONT_GENERATE, DONT_INLINE]] */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public static java.lang.String e(boolean r5) {
        /*
            int r0 = com.facetec.sdk.dm.j
            int r0 = r0 + 49
            int r1 = r0 % 128
            com.facetec.sdk.dm.f = r1
            int r0 = r0 % 2
            r1 = 40
            r2 = 0
            if (r0 != 0) goto L1a
            int r0 = com.facetec.sdk.R.string.FaceTec_retry_instruction_message_2
            java.lang.String r0 = com.facetec.sdk.dp.a(r0)
            r3 = 3
            int r3 = r3 / r2
            if (r5 == 0) goto L4d
            goto L22
        L1a:
            int r0 = com.facetec.sdk.R.string.FaceTec_retry_instruction_message_2
            java.lang.String r0 = com.facetec.sdk.dp.a(r0)
            if (r5 == 0) goto L4d
        L22:
            com.facetec.sdk.FaceTecCustomization r5 = com.facetec.sdk.FaceTecSDK.d
            boolean r5 = r5.b
            r3 = 1
            if (r5 == r3) goto L4d
            int r5 = com.facetec.sdk.dm.j
            int r5 = r5 + 13
            int r4 = r5 % 128
            com.facetec.sdk.dm.f = r4
            int r5 = r5 % 2
            if (r5 != 0) goto L3e
            int r5 = r0.length()
            r4 = 47
            if (r5 <= r4) goto L4d
            goto L44
        L3e:
            int r5 = r0.length()
            if (r5 <= r1) goto L4d
        L44:
            int r5 = com.facetec.sdk.dm.f
            int r5 = r5 + 105
            int r5 = r5 % 128
            com.facetec.sdk.dm.j = r5
            goto L4e
        L4d:
            r3 = r2
        L4e:
            if (r3 == 0) goto L5d
            int r5 = com.facetec.sdk.dm.j
            int r5 = r5 + 107
            int r5 = r5 % 128
            com.facetec.sdk.dm.f = r5
            java.lang.String r5 = r0.substring(r2, r1)
            return r5
        L5d:
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: com.facetec.sdk.dm.e(boolean):java.lang.String");
    }

    public static String a(boolean z, boolean z2) {
        j = (f + 103) % 128;
        String strA = FaceTecSDK.d.i.retryScreenHeaderAttributedString;
        if (!z2 && strA.isEmpty()) {
            strA = dp.a(R.string.FaceTec_retry_header);
        }
        if (!z || FaceTecSDK.d.b || strA.length() <= 30) {
            return strA;
        }
        int i2 = (j + 115) % 128;
        f = i2;
        j = (i2 + 31) % 128;
        int i3 = i2 + 103;
        j = i3 % 128;
        String strSubstring = i3 % 2 != 0 ? strA.substring(0, 10) : strA.substring(0, 30);
        f = (j + 85) % 128;
        return strSubstring;
    }

    public static boolean b(Context context, List<Integer> list) {
        f = (j + 19) % 128;
        if (list.size() < 2) {
            return false;
        }
        for (int i2 = 1; i2 < list.size(); i2++) {
            int iB = dq.b(context, list.get(i2 - 1).intValue());
            int iB2 = dq.b(context, list.get(i2).intValue());
            if (Math.abs(Color.red(iB) - Color.red(iB2)) + Math.abs(Color.green(iB) - Color.green(iB2)) + Math.abs(Color.blue(iB) - Color.blue(iB2)) > 30) {
                j = (f + 45) % 128;
                return false;
            }
        }
        return true;
    }

    public static void i(@NonNull View view) {
        j = (f + 81) % 128;
        d(view, bV());
        f = (j + 97) % 128;
    }

    public static void i(boolean z) {
        int i2 = j + 93;
        f = i2 % 128;
        if (i2 % 2 == 0) {
            Object[] objArr = {Boolean.FALSE, Boolean.valueOf(z)};
            if (((String) e(pg.a.a(), pg.a.a(), 1429122379, objArr, pg.a.a(), -1429122365, pg.a.a())).length() <= 118) {
                return;
            }
        } else {
            Object[] objArr2 = {Boolean.FALSE, Boolean.valueOf(z)};
            if (((String) e(pg.a.a(), pg.a.a(), 1429122379, objArr2, pg.a.a(), -1429122365, pg.a.a())).length() <= 40) {
                return;
            }
        }
        int i3 = f + 21;
        j = i3 % 128;
        if (i3 % 2 == 0) {
            d("Retry Screen Sub-Header Message");
        } else {
            d("Retry Screen Sub-Header Message");
            throw null;
        }
    }

    /* JADX WARN: Removed duplicated region for block: B:15:0x0036  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public static java.lang.String a(boolean r5) {
        /*
            int r0 = com.facetec.sdk.R.string.FaceTec_retry_instruction_message_1
            java.lang.String r0 = com.facetec.sdk.dp.a(r0)
            r1 = 0
            r2 = 40
            r3 = 1
            if (r5 == r3) goto Ld
            goto L36
        Ld:
            com.facetec.sdk.FaceTecCustomization r5 = com.facetec.sdk.FaceTecSDK.d
            boolean r5 = r5.b
            if (r5 != 0) goto L36
            int r5 = com.facetec.sdk.dm.f
            int r5 = r5 + 121
            int r4 = r5 % 128
            com.facetec.sdk.dm.j = r4
            int r5 = r5 % 2
            if (r5 == 0) goto L27
            int r5 = r0.length()
            r4 = 6
            if (r5 <= r4) goto L36
            goto L2d
        L27:
            int r5 = r0.length()
            if (r5 <= r2) goto L36
        L2d:
            int r5 = com.facetec.sdk.dm.f
            int r5 = r5 + 113
            int r5 = r5 % 128
            com.facetec.sdk.dm.j = r5
            goto L3f
        L36:
            int r5 = com.facetec.sdk.dm.f
            int r5 = r5 + 13
            int r5 = r5 % 128
            com.facetec.sdk.dm.j = r5
            r3 = r1
        L3f:
            if (r3 == 0) goto L46
            java.lang.String r5 = r0.substring(r1, r2)
            return r5
        L46:
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: com.facetec.sdk.dm.a(boolean):java.lang.String");
    }

    public static String b(boolean z) {
        Object[] objArr = {Boolean.valueOf(z)};
        return (String) e(pg.a.a(), pg.a.a(), -842338935, objArr, pg.a.a(), 842338966, pg.a.a());
    }

    public static String c(boolean z, boolean z2) {
        String strA = FaceTecSDK.d.i.readyScreenSubtextAttributedString;
        if (!strA.isEmpty() && strA.contains("\n")) {
            int i2 = j + 5;
            f = i2 % 128;
            strA = strA.substring(i2 % 2 == 0 ? strA.indexOf("\n") << 1 : strA.indexOf("\n") + 1);
        }
        if (!z2 && strA.isEmpty()) {
            strA = dp.a(R.string.FaceTec_instructions_message_ready_2);
            if (strA.contains("\n")) {
                j = (f + 51) % 128;
                strA = strA.substring(strA.indexOf("\n") + 1);
            }
        }
        if (z && !FaceTecSDK.d.b && strA.length() > 50) {
            f = (j + 125) % 128;
            return strA.substring(0, 50);
        }
        j = (f + 75) % 128;
        return strA;
    }

    public static String b(dr drVar) {
        int iA = pg.a.a();
        return (String) e(pg.a.a(), iA, 1436383320, new Object[]{drVar}, pg.a.a(), -1436383290, pg.a.a());
    }

    private static void e(String str) {
        String str2;
        int i2 = j + 5;
        f = i2 % 128;
        if (i2 % 2 != 0) {
            str2 = String.format(Locale.getDefault(), "Your %s text has been configured to use more than %d characters.  %d or less characters is recommended for this text in order to render well on all devices and OS versions.", str, 20, 20);
        } else {
            Locale locale = Locale.getDefault();
            Object[] objArr = new Object[2];
            objArr[0] = str;
            objArr[1] = 109;
            objArr[5] = 110;
            str2 = String.format(locale, "Your %s text has been configured to use more than %d characters.  %d or less characters is recommended for this text in order to render well on all devices and OS versions.", objArr);
        }
        bb.e(str2);
        f = (j + 19) % 128;
    }

    private static <T> T e(T t, T t2) {
        int i2 = f;
        j = (i2 + 117) % 128;
        if (t != null) {
            return t;
        }
        int i3 = i2 + 31;
        j = i3 % 128;
        if (i3 % 2 == 0) {
            return t2;
        }
        throw null;
    }

    public static String a(ck ckVar, boolean z) {
        switch (AnonymousClass3.e[ckVar.ordinal()]) {
            case 1:
                f = (j + 67) % 128;
                return "";
            case 2:
                if (z) {
                    f = (j + 53) % 128;
                    return dp.a(R.string.FaceTec_idscan_nfc_card_status_starting_message);
                }
                return dp.a(R.string.FaceTec_idscan_nfc_status_starting_message);
            case 3:
                return dp.a(R.string.FaceTec_idscan_nfc_status_scanning_message);
            case 4:
                return dp.a(R.string.FaceTec_idscan_nfc_status_weak_connection_message);
            case 5:
                String strA = dp.a(R.string.FaceTec_idscan_nfc_status_finished_with_success_message);
                f = (j + 47) % 128;
                return strA;
            case 6:
                if (z) {
                    return dp.a(R.string.FaceTec_idscan_nfc_card_status_finished_with_error_message);
                }
                return dp.a(R.string.FaceTec_idscan_nfc_status_finished_with_error_message);
            case 7:
                return dp.a(R.string.FaceTec_idscan_nfc_status_skipped_message);
            case 8:
                return dp.a(R.string.FaceTec_idscan_nfc_status_disabled_message);
            default:
                return null;
        }
    }

    /* JADX WARN: Removed duplicated region for block: B:44:0x01be A[PHI: r10 r11 r13
      0x01be: PHI (r10v40 java.lang.String) = (r10v39 java.lang.String), (r10v46 java.lang.String) binds: [B:43:0x01bc, B:40:0x018f] A[DONT_GENERATE, DONT_INLINE]
      0x01be: PHI (r11v12 java.lang.String) = (r11v11 java.lang.String), (r11v18 java.lang.String) binds: [B:43:0x01bc, B:40:0x018f] A[DONT_GENERATE, DONT_INLINE]
      0x01be: PHI (r13v5 java.lang.String) = (r13v4 java.lang.String), (r13v9 java.lang.String) binds: [B:43:0x01bc, B:40:0x018f] A[DONT_GENERATE, DONT_INLINE]] */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public static /* synthetic */ java.lang.Object e(int r9, int r10, int r11, java.lang.Object[] r12, int r13, int r14, int r15) {
        /*
            Method dump skipped, instruction units count: 1198
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: com.facetec.sdk.dm.e(int, int, int, java.lang.Object[], int, int, int):java.lang.Object");
    }

    public static int i(@NonNull Context context) {
        int iA = pg.a.a();
        return ((Integer) e(pg.a.a(), iA, 877608522, new Object[]{context}, pg.a.a(), -877608482, pg.a.a())).intValue();
    }

    public static void i(@NonNull TextView textView) {
        int iA = pg.a.a();
        e(pg.a.a(), iA, -1589723565, new Object[]{textView}, pg.a.a(), 1589723597, pg.a.a());
    }

    /* JADX WARN: Removed duplicated region for block: B:14:0x0041 A[PHI: r0
      0x0041: PHI (r0v7 java.lang.String) = (r0v4 java.lang.String), (r0v5 java.lang.String), (r0v5 java.lang.String), (r0v9 java.lang.String) binds: [B:8:0x0021, B:10:0x0027, B:12:0x0035, B:5:0x0018] A[DONT_GENERATE, DONT_INLINE]] */
    /* JADX WARN: Removed duplicated region for block: B:9:0x0023 A[PHI: r0
      0x0023: PHI (r0v5 java.lang.String) = (r0v4 java.lang.String), (r0v9 java.lang.String) binds: [B:8:0x0021, B:5:0x0018] A[DONT_GENERATE, DONT_INLINE]] */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public static java.lang.String c(boolean r4) {
        /*
            int r0 = com.facetec.sdk.dm.j
            int r0 = r0 + 11
            int r1 = r0 % 128
            com.facetec.sdk.dm.f = r1
            int r0 = r0 % 2
            r1 = 21
            r2 = 0
            if (r0 != 0) goto L1b
            int r0 = com.facetec.sdk.R.string.FaceTec_retry_ideal_image_label
            java.lang.String r0 = com.facetec.sdk.dp.a(r0)
            r3 = 69
            int r3 = r3 / r2
            if (r4 == 0) goto L41
            goto L23
        L1b:
            int r0 = com.facetec.sdk.R.string.FaceTec_retry_ideal_image_label
            java.lang.String r0 = com.facetec.sdk.dp.a(r0)
            if (r4 == 0) goto L41
        L23:
            com.facetec.sdk.FaceTecCustomization r4 = com.facetec.sdk.FaceTecSDK.d
            boolean r4 = r4.b
            if (r4 != 0) goto L41
            int r4 = com.facetec.sdk.dm.f
            int r4 = r4 + 53
            int r4 = r4 % 128
            com.facetec.sdk.dm.j = r4
            int r4 = r0.length()
            if (r4 <= r1) goto L41
            int r4 = com.facetec.sdk.dm.j
            int r4 = r4 + 75
            int r4 = r4 % 128
            com.facetec.sdk.dm.f = r4
            r4 = 1
            goto L42
        L41:
            r4 = r2
        L42:
            if (r4 == 0) goto L51
            int r4 = com.facetec.sdk.dm.f
            int r4 = r4 + 65
            int r4 = r4 % 128
            com.facetec.sdk.dm.j = r4
            java.lang.String r4 = r0.substring(r2, r1)
            return r4
        L51:
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: com.facetec.sdk.dm.c(boolean):java.lang.String");
    }

    /* JADX WARN: Removed duplicated region for block: B:9:0x0018 A[PHI: r0
      0x0018: PHI (r0v4 java.util.HashMap<com.facetec.sdk.cz, java.lang.String>) = 
      (r0v3 java.util.HashMap<com.facetec.sdk.cz, java.lang.String>)
      (r0v16 java.util.HashMap<com.facetec.sdk.cz, java.lang.String>)
     binds: [B:8:0x0016, B:5:0x0011] A[DONT_GENERATE, DONT_INLINE]] */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public static java.lang.String c(com.facetec.sdk.cz r3) {
        /*
            Method dump skipped, instruction units count: 230
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: com.facetec.sdk.dm.c(com.facetec.sdk.cz):java.lang.String");
    }

    private static GradientDrawable c(@NonNull Context context, @NonNull GradientDrawable gradientDrawable) {
        j = (f + 37) % 128;
        GradientDrawable gradientDrawableE = dq.e(context, gradientDrawable, k(context));
        j = (f + 97) % 128;
        return gradientDrawableE;
    }

    private static int c(int i2, int i3) {
        if (i2 != 0) {
            return i2;
        }
        int i4 = j + 27;
        f = i4 % 128;
        if (i4 % 2 != 0) {
            return i3;
        }
        throw null;
    }

    public static FaceTecCustomization e(FaceTecCustomization faceTecCustomization) {
        int iA = pg.a.a();
        return (FaceTecCustomization) e(pg.a.a(), iA, -985259665, new Object[]{faceTecCustomization}, pg.a.a(), 985259675, pg.a.a());
    }

    public static int e(Context context) {
        int iA = pg.a.a();
        return ((Integer) e(pg.a.a(), iA, 447937035, new Object[]{context}, pg.a.a(), -447936997, pg.a.a())).intValue();
    }
}