package com.facetec.sdk;

import android.content.Context;
import android.content.res.Resources;
import android.graphics.BitmapFactory;
import android.graphics.drawable.GradientDrawable;
import android.os.Handler;
import android.os.Looper;
import android.util.AttributeSet;
import android.view.ViewOutlineProvider;
import android.widget.FrameLayout;
import android.widget.ImageView;
import androidx.core.graphics.drawable.C1189;
import androidx.core.graphics.drawable.RoundedBitmapDrawable;
import com.facetec.sdk.pg;
import com.incode.welcome_sdk.modules.SelfieScan;
import io.sentry.HttpStatusCodeRange;
import java.util.Random;

/* JADX INFO: loaded from: classes4.dex */
class dn extends FrameLayout {
    private ImageView a;
    boolean b;
    int c;
    int[] d;
    private ImageView e;
    private Handler f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    private RoundedBitmapDrawable[] f95871g;
    private boolean j;

    public dn(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        int i = 0;
        this.f95871g = new RoundedBitmapDrawable[0];
        this.d = new int[0];
        this.c = 0;
        this.b = true;
        if (((int[]) dm.e(pg.a.a(), pg.a.a(), -1644736691, new Object[0], pg.a.a(), 1644736699, pg.a.a())).length == 0) {
            return;
        }
        this.f = new Handler(Looper.getMainLooper());
        this.a = new ImageView(context);
        this.e = new ImageView(context);
        this.a.setAlpha(1.0f);
        this.e.setAlpha(SelfieScan.RECOGNITION_FAIL_RESULT);
        ImageView imageView = this.a;
        ImageView.ScaleType scaleType = ImageView.ScaleType.CENTER_CROP;
        imageView.setScaleType(scaleType);
        this.a.setAdjustViewBounds(true);
        this.e.setScaleType(scaleType);
        this.e.setAdjustViewBounds(true);
        this.j = true;
        addView(this.a);
        addView(this.e);
        GradientDrawable gradientDrawable = new GradientDrawable();
        gradientDrawable.setCornerRadius(bh.a((int) (dm.C() * dm.c())));
        gradientDrawable.setStroke((int) bh.a(Math.max(dm.k() == 0 ? 0 : 1, (int) (dm.k() * dm.c()))), ((Integer) dm.e(pg.a.a(), pg.a.a(), 1009688708, new Object[]{context}, pg.a.a(), -1009688672, pg.a.a())).intValue());
        gradientDrawable.setColor(0);
        setBackground(gradientDrawable);
        setClipToOutline(true);
        setOutlineProvider(ViewOutlineProvider.BACKGROUND);
        if (FaceTecSDK.d.i.enableRetryScreenSlideshowShuffle) {
            int[] iArr = (int[]) dm.e(pg.a.a(), pg.a.a(), -1644736691, new Object[0], pg.a.a(), 1644736699, pg.a.a());
            Random random = new Random();
            for (int i2 = 0; i2 < iArr.length; i2++) {
                int iNextInt = random.nextInt(iArr.length);
                int i3 = iArr[iNextInt];
                iArr[iNextInt] = iArr[i2];
                iArr[i2] = i3;
            }
            this.d = iArr;
        } else {
            this.d = (int[]) dm.e(pg.a.a(), pg.a.a(), -1644736691, new Object[0], pg.a.a(), 1644736699, pg.a.a());
        }
        Resources resources = getResources();
        this.f95871g = new RoundedBitmapDrawable[this.d.length];
        while (true) {
            int[] iArr2 = this.d;
            if (i >= iArr2.length) {
                this.a.setImageDrawable(this.f95871g[this.c]);
                return;
            } else {
                this.f95871g[i] = C1189.m4797(resources, BitmapFactory.decodeResource(resources, iArr2[i]));
                i++;
            }
        }
    }

    private int a() {
        int i = this.c;
        if (i == this.f95871g.length - 1) {
            return 0;
        }
        return i + 1;
    }

    public final void c() {
        Handler handler = this.f;
        if (handler != null) {
            handler.removeCallbacksAndMessages(null);
            this.f = null;
        }
    }

    /* JADX INFO: renamed from: d, reason: merged with bridge method [inline-methods] */
    public final void i() {
        int iA = a();
        this.c = iA;
        RoundedBitmapDrawable roundedBitmapDrawable = this.f95871g[iA];
        if (this.j) {
            this.e.setImageDrawable(roundedBitmapDrawable);
        } else {
            this.a.setImageDrawable(roundedBitmapDrawable);
        }
    }

    /* JADX INFO: renamed from: e, reason: merged with bridge method [inline-methods] */
    public final void b() {
        Handler handler;
        if (!this.b) {
            if (this.j) {
                this.e.animate().alpha(1.0f).setDuration(800L).setListener(null).start();
                this.a.animate().alpha(SelfieScan.RECOGNITION_FAIL_RESULT).setDuration(800L).setListener(null).start();
            } else {
                this.e.animate().alpha(SelfieScan.RECOGNITION_FAIL_RESULT).setDuration(800L).setListener(null).start();
                this.a.animate().alpha(1.0f).setDuration(800L).setListener(null).start();
            }
            this.j = !this.j;
            Handler handler2 = this.f;
            if (handler2 != null) {
                handler2.postDelayed(new Runnable() { // from class: com.facetec.sdk.剑古
                    @Override // java.lang.Runnable
                    public final void run() {
                        this.f7201.i();
                    }
                }, 800L);
            }
        }
        int i = FaceTecSDK.d.i.retryScreenSlideshowInterval;
        if (this.b) {
            i /= 2;
            this.b = false;
        }
        int iMax = Math.max(HttpStatusCodeRange.DEFAULT_MIN, i);
        if (this.d.length <= 1 || (handler = this.f) == null) {
            return;
        }
        handler.postDelayed(new Runnable() { // from class: com.facetec.sdk.剑史
            @Override // java.lang.Runnable
            public final void run() {
                this.f7202.b();
            }
        }, iMax);
    }
}