package com.facetec.sdk;

import android.app.Activity;
import android.content.Context;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.widget.TextView;
import androidx.annotation.NonNull;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;
import java.util.Objects;

/* JADX INFO: loaded from: classes4.dex */
final class dp {
    private static Resources b;
    private static HashMap<Integer, String> d;

    @NonNull
    public static String a(int i) {
        if (i == 0) {
            return "";
        }
        HashMap<Integer, String> map = d;
        String str = map != null ? map.get(Integer.valueOf(i)) : null;
        return str != null ? str : b.getString(i);
    }

    private static String b(Activity activity, int i, String str) {
        Configuration configuration = new Configuration(dq.a((Context) activity).getConfiguration());
        configuration.setLocale(new Locale(str));
        return activity.createConfigurationContext(configuration).getResources().getString(i);
    }

    public static void d(Activity activity) {
        if (b == null) {
            b = dq.a(activity.getApplicationContext());
        }
    }

    public static void e(TextView textView, int i) {
        if (textView == null) {
            return;
        }
        textView.setText(a(i));
    }

    public static synchronized void e(Map<Integer, String> map) {
        d = new HashMap<>(map);
    }

    public static boolean e(Activity activity, int i) {
        if (b.getConfiguration().locale != Locale.ENGLISH && !Locale.getDefault().getLanguage().equals("en")) {
            HashMap<Integer, String> map = d;
            String strB = null;
            if ((map != null ? map.get(Integer.valueOf(i)) : null) == null) {
                try {
                    if (!Objects.equals(b(activity, i, "en"), b(activity, i, Locale.getDefault().getLanguage()))) {
                        strB = b(activity, i, Locale.getDefault().getLanguage());
                    }
                } catch (Exception unused) {
                }
                return strB != null;
            }
        }
        return true;
    }
}