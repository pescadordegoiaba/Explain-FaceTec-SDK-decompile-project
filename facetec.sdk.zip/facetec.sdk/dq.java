package com.facetec.sdk;

import android.animation.Animator;
import android.animation.ObjectAnimator;
import android.app.Activity;
import android.content.Context;
import android.content.res.Resources;
import android.graphics.Color;
import android.graphics.drawable.Animatable;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.ShapeDrawable;
import android.text.Html;
import android.util.DisplayMetrics;
import android.util.TypedValue;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.vectordrawable.graphics.drawable.Animatable2Compat$AnimationCallback;
import androidx.vectordrawable.graphics.drawable.AnimatedVectorDrawableCompat;
import com.facetec.sdk.l;
import io.sentry.protocol.ViewHierarchyNode;
import java.lang.ref.WeakReference;
import java.util.Objects;
import kotlin.C6852;
import org.bouncycastle.asn1.cmc.BodyPartID;

/* JADX INFO: loaded from: classes4.dex */
final class dq {
    private static final l<Resources> d = new l<>();
    private static final l<Resources> e = new l<>();
    private static final l<DisplayMetrics> b = new l<>();
    private static final l<FaceTecSize> a = new l<>();
    private static WeakReference<Activity> f = null;
    static final boolean c = bh.c(new String[]{"Surface Duo 2", "HZ1-00006", "SM-F90"});

    /* JADX INFO: renamed from: com.facetec.sdk.dq$3, reason: invalid class name */
    public static /* synthetic */ class AnonymousClass3 {
        static final /* synthetic */ int[] d;

        static {
            int[] iArr = new int[d.values().length];
            d = iArr;
            try {
                iArr[d.RESOURCE.ordinal()] = 1;
            } catch (NoSuchFieldError unused) {
            }
            try {
                d[d.COLOR.ordinal()] = 2;
            } catch (NoSuchFieldError unused2) {
            }
        }
    }

    public enum d {
        COLOR,
        RESOURCE
    }

    public static Resources a(final Context context) {
        l<Resources> lVar = e;
        Objects.requireNonNull(context);
        return lVar.c(new l.a() { // from class: com.facetec.sdk.剑国
            @Override // com.facetec.sdk.l.a
            public final Object create() {
                return context.getResources();
            }
        });
    }

    public static FaceTecSize b(Activity activity) {
        return d(activity);
    }

    public static FaceTecSize c() {
        if (!c) {
            return e();
        }
        WeakReference<Activity> weakReference = f;
        final Activity activity = weakReference == null ? null : weakReference.get();
        if (activity == null) {
            return e();
        }
        l<FaceTecSize> lVar = a;
        if (lVar.d() != null && (lVar.d().height == 0 || lVar.d().width == 0)) {
            lVar.a();
        }
        return lVar.c(new l.a() { // from class: com.facetec.sdk.剑地
            @Override // com.facetec.sdk.l.a
            public final Object create() {
                return dq.d(activity);
            }
        });
    }

    public static Resources d() {
        return d.c(new l.a() { // from class: com.facetec.sdk.剑土
            @Override // com.facetec.sdk.l.a
            public final Object create() {
                return Resources.getSystem();
            }
        });
    }

    public static FaceTecSize e() {
        DisplayMetrics displayMetricsB = b();
        return new FaceTecSize(displayMetricsB.widthPixels, displayMetricsB.heightPixels);
    }

    public static DisplayMetrics b() {
        return b.c(new l.a() { // from class: com.facetec.sdk.剑城
            @Override // com.facetec.sdk.l.a
            public final Object create() {
                return dq.a();
            }
        });
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static FaceTecSize d(Activity activity) {
        float fJ;
        try {
            fJ = ah.j();
        } catch (ak unused) {
            fJ = 1.77f;
        }
        int measuredWidth = activity.getWindow().getDecorView().getMeasuredWidth();
        return new FaceTecSize(measuredWidth, (int) (((double) measuredWidth) * ((double) fJ)));
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static /* synthetic */ Object a() {
        return d().getDisplayMetrics();
    }

    public static int b(@NonNull Context context, int i) {
        if (AnonymousClass3.d[e(context, i).ordinal()] != 1) {
            return i;
        }
        try {
            return C6852.getColor(context, i);
        } catch (Throwable unused) {
            return i;
        }
    }

    @NonNull
    public static d e(@NonNull Context context, int i) {
        long j = ((long) i) & BodyPartID.bodyIdMax;
        if (j != 0 && j <= 16777215) {
            try {
                a(context).getValue(i, new TypedValue(), true);
                return d.RESOURCE;
            } catch (Exception unused) {
                return d.COLOR;
            }
        }
        return d.COLOR;
    }

    public static int a(@NonNull Context context, int i, int i2) {
        int i3 = AnonymousClass3.d[e(context, i).ordinal()];
        if (i3 != 1) {
            if (i3 != 2) {
                return 255;
            }
            return (i >> 24) & 255;
        }
        Drawable drawable = C6852.getDrawable(context, i);
        if (drawable != null) {
            if (drawable instanceof ShapeDrawable) {
                return ((ShapeDrawable) drawable).getPaint().getAlpha();
            }
            if (drawable instanceof GradientDrawable) {
                int[] colors = ((GradientDrawable) drawable).getColors();
                if (colors == null) {
                    return 255;
                }
                int i4 = 0;
                for (int color : colors) {
                    int i5 = AnonymousClass3.d[e(context, color).ordinal()];
                    if (i5 != 1) {
                        if (i5 != 2) {
                        }
                    } else {
                        color = C6852.getColor(context, color);
                    }
                    i4 += (color >> 24) & 255;
                }
                return i4 / colors.length;
            }
            if (drawable instanceof ColorDrawable) {
                return drawable.getAlpha();
            }
            return 255;
        }
        return (C6852.getColor(context, i) >> 24) & 255;
    }

    public static void b(TextView textView, String str) {
        textView.setText(Html.fromHtml(str.replace("\n", "<br/>"), 63));
    }

    public static void d(@NonNull View view, int i, int i2) {
        int i3 = AnonymousClass3.d[e(view.getContext(), i).ordinal()];
        if (i3 != 1) {
            if (i3 != 2) {
                return;
            }
            view.setBackgroundColor(c(i, 255));
        } else {
            if (C6852.getDrawable(view.getContext(), i) != null) {
                Drawable drawableMutate = C6852.getDrawable(view.getContext(), i).mutate();
                if (drawableMutate instanceof ShapeDrawable) {
                    ((ShapeDrawable) drawableMutate).getPaint().setAlpha(255);
                } else if (drawableMutate instanceof GradientDrawable) {
                    drawableMutate = e(view.getContext(), (GradientDrawable) drawableMutate, i2);
                } else if (drawableMutate instanceof ColorDrawable) {
                    drawableMutate.setAlpha(255);
                }
                view.setBackground(drawableMutate);
                return;
            }
            view.setBackgroundColor(c(C6852.getColor(view.getContext(), i), 255));
        }
    }

    public static void b(Drawable drawable, int i, int i2, double d2) {
        if (drawable instanceof GradientDrawable) {
            GradientDrawable gradientDrawable = (GradientDrawable) drawable;
            gradientDrawable.setStroke(i2, i);
            gradientDrawable.setCornerRadius((float) d2);
        }
    }

    public static int e(int i) {
        return Color.argb(Math.round(Color.alpha(i) * 0.5f), Color.red(i), Color.green(i), Color.blue(i));
    }

    public static int c(int i, int i2) {
        return Color.argb(i2, Color.red(i), Color.green(i), Color.blue(i));
    }

    public static void c(Drawable drawable, int i) {
        if (drawable instanceof ShapeDrawable) {
            ((ShapeDrawable) drawable).getPaint().setColor(i);
        } else if (drawable instanceof GradientDrawable) {
            ((GradientDrawable) drawable).setColor(i);
        } else if (drawable instanceof ColorDrawable) {
            ((ColorDrawable) drawable).setColor(i);
        }
    }

    @NonNull
    public static GradientDrawable e(@NonNull Context context, @NonNull GradientDrawable gradientDrawable, int i) {
        int[] colors = gradientDrawable.getColors();
        if (colors != null) {
            for (int i2 = 0; i2 < colors.length; i2++) {
                int i3 = AnonymousClass3.d[e(context, colors[i2]).ordinal()];
                if (i3 == 1) {
                    colors[i2] = c(b(context, colors[i2]), 255);
                } else if (i3 == 2) {
                    colors[i2] = c(colors[i2], 255);
                }
            }
        }
        gradientDrawable.setColors(colors);
        return gradientDrawable;
    }

    public static void a(@NonNull Context context, @NonNull TextView textView, Drawable drawable, int i) {
        int i2 = AnonymousClass3.d[e(textView.getContext(), i).ordinal()];
        if (i2 == 1) {
            if (drawable instanceof ShapeDrawable) {
                ((ShapeDrawable) drawable).getPaint().setColor(C6852.getColor(context, i));
                return;
            } else if (drawable instanceof GradientDrawable) {
                ((GradientDrawable) drawable).setColor(C6852.getColor(context, i));
                return;
            } else {
                if (drawable instanceof ColorDrawable) {
                    ((ColorDrawable) drawable).setColor(C6852.getColor(context, i));
                    return;
                }
                return;
            }
        }
        if (i2 != 2) {
            return;
        }
        if (drawable instanceof ShapeDrawable) {
            ((ShapeDrawable) drawable).getPaint().setColor(i);
        } else if (drawable instanceof GradientDrawable) {
            ((GradientDrawable) drawable).setColor(i);
        } else if (drawable instanceof ColorDrawable) {
            ((ColorDrawable) drawable).setColor(i);
        }
    }

    public static void d(@NonNull Context context, Drawable drawable, int i) {
        int i2 = AnonymousClass3.d[e(context, i).ordinal()];
        if (i2 != 1) {
            if (i2 == 2 && (drawable instanceof GradientDrawable)) {
                ((GradientDrawable) drawable).setColor(i);
                return;
            }
            return;
        }
        if (drawable instanceof GradientDrawable) {
            ((GradientDrawable) drawable).setColor(C6852.getColor(context, i));
        }
    }

    public static void c(@NonNull TextView textView, int i) {
        int i2 = AnonymousClass3.d[e(textView.getContext(), i).ordinal()];
        if (i2 == 1) {
            textView.setTextColor(C6852.getColor(textView.getContext(), i));
        } else {
            if (i2 != 2) {
                return;
            }
            textView.setTextColor(i);
        }
    }

    public static void e(@NonNull Button button, int i) {
        button.setTextColor(i);
    }

    public static void c(ImageView imageView, int i, Animatable2Compat$AnimationCallback animatable2Compat$AnimationCallback, boolean z) {
        Drawable drawable;
        AnimatedVectorDrawableCompat animatedVectorDrawableCompatA;
        if (imageView == null || (drawable = C6852.getDrawable(imageView.getContext(), i)) == null) {
            return;
        }
        if ((drawable instanceof Animatable) && (animatedVectorDrawableCompatA = bh.a(imageView.getContext(), i)) != null) {
            imageView.setImageDrawable(animatedVectorDrawableCompatA);
            if (animatable2Compat$AnimationCallback != null) {
                animatedVectorDrawableCompatA.m7656(animatable2Compat$AnimationCallback);
            }
            if (z) {
                a(imageView);
                return;
            }
            return;
        }
        imageView.setImageDrawable(drawable);
    }

    public static void d(Drawable drawable, int i) {
        if (drawable instanceof GradientDrawable) {
            ((GradientDrawable) drawable).setColor(i);
        } else if (drawable instanceof ColorDrawable) {
            ((ColorDrawable) drawable).setColor(i);
        } else if (drawable instanceof ShapeDrawable) {
            ((ShapeDrawable) drawable).getPaint().setColor(i);
        }
    }

    public static ObjectAnimator d(View view, float f2, final Runnable runnable) {
        if (view == null) {
            return null;
        }
        ObjectAnimator objectAnimatorOfFloat = ObjectAnimator.ofFloat(view, ViewHierarchyNode.JsonKeys.ALPHA, view.getAlpha(), f2);
        objectAnimatorOfFloat.setDuration(500L);
        objectAnimatorOfFloat.addListener(new f() { // from class: com.facetec.sdk.剑名
            @Override // android.animation.Animator.AnimatorListener
            public final void onAnimationEnd(Animator animator) {
                dq.d(runnable, animator);
            }
        });
        objectAnimatorOfFloat.start();
        return objectAnimatorOfFloat;
    }

    public static void a(@NonNull Context context, @NonNull TextView textView, Drawable drawable, int i, int i2, double d2) {
        int i3 = AnonymousClass3.d[e(textView.getContext(), i).ordinal()];
        if (i3 != 1) {
            if (i3 == 2 && (drawable instanceof GradientDrawable)) {
                GradientDrawable gradientDrawable = (GradientDrawable) drawable;
                gradientDrawable.setStroke(i2, i);
                gradientDrawable.setCornerRadius((float) d2);
                return;
            }
            return;
        }
        if (drawable instanceof GradientDrawable) {
            GradientDrawable gradientDrawable2 = (GradientDrawable) drawable;
            gradientDrawable2.setStroke(i2, C6852.getColor(context, i));
            gradientDrawable2.setCornerRadius((float) d2);
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static /* synthetic */ void d(Runnable runnable, Animator animator) {
        if (runnable != null) {
            runnable.run();
        }
    }

    public static void d(bi biVar) {
        a.a();
        f = new WeakReference<>(biVar);
    }

    public static void a(ImageView imageView) {
        Object drawable;
        if (imageView == null || (drawable = imageView.getDrawable()) == null || !(drawable instanceof Animatable)) {
            return;
        }
        try {
            ((Animatable) drawable).start();
        } catch (Exception unused) {
        }
    }
}