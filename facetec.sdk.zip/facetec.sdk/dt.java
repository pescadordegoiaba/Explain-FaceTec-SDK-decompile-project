package com.facetec.sdk;

/* JADX INFO: loaded from: classes4.dex */
public class dt {
    public float a;
    public Object b;
    public int c;
    public int d;
    public Object e;
    private int f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    private final float[] f95873g;
    private final int[] h;
    private final long[] i;
    private int j;
    private final Object[] l;
    private final double[] n;

    public dt(Object obj, Object obj2) {
        this.h = new int[17];
        this.i = new long[17];
        this.f95873g = new float[17];
        this.n = new double[17];
        Object[] objArr = new Object[17];
        this.l = objArr;
        objArr[5] = obj;
        objArr[6] = obj2;
        this.f = 0;
        this.j = -1;
    }

    public int e(int i) {
        switch (i) {
            case 1:
                int i2 = this.f - this.c;
                this.f = i2;
                this.j = i2;
                return 0;
            case 2:
                Object[] objArr = this.l;
                int i3 = this.j;
                this.j = i3 + 1;
                Object obj = objArr[i3];
                objArr[i3] = null;
                this.e = obj;
                return 0;
            case 3:
                int[] iArr = this.h;
                int i4 = this.f;
                this.f = i4 + 1;
                iArr[i4] = this.c;
                return 0;
            case 4:
                Object[] objArr2 = this.l;
                int i5 = this.f;
                this.f = i5 + 1;
                objArr2[i5] = objArr2[5];
                return 0;
            case 5:
                int i6 = this.f - 1;
                this.f = i6;
                this.d = this.h[i6] == 0 ? 0 : 1;
                return 0;
            case 6:
                Object[] objArr3 = this.l;
                int i7 = this.f;
                this.f = i7 + 1;
                objArr3[i7] = this.b;
                return 0;
            case 7:
                int[] iArr2 = this.h;
                int i8 = this.f;
                this.f = i8 + 1;
                iArr2[i8] = 1;
                return 0;
            case 8:
                int[] iArr3 = this.h;
                int i9 = this.j;
                this.j = i9 + 1;
                this.d = iArr3[i9];
                return 0;
            case 9:
                Object[] objArr4 = this.l;
                int i10 = this.f;
                this.f = i10 + 1;
                objArr4[i10] = objArr4[i10 - 1];
                this.f = i10;
                Object obj2 = objArr4[i10];
                objArr4[i10] = null;
                objArr4[7] = obj2;
                return 0;
            case 10:
                int i11 = this.f - 1;
                this.f = i11;
                Object[] objArr5 = this.l;
                Object obj3 = objArr5[i11];
                objArr5[i11] = null;
                this.d = obj3 != null ? 0 : 1;
                return 0;
            case 11:
                Object[] objArr6 = this.l;
                int i12 = this.f;
                this.f = i12 + 1;
                objArr6[i12] = objArr6[7];
                return 0;
            case 12:
                Object[] objArr7 = this.l;
                int i13 = this.f;
                this.f = i13 + 1;
                objArr7[i13] = objArr7[i13 - 1];
                return 0;
            case 13:
                int i14 = this.f - 1;
                this.f = i14;
                Object[] objArr8 = this.l;
                Object obj4 = objArr8[i14];
                objArr8[i14] = null;
                objArr8[7] = obj4;
                return 0;
            case 14:
                Object[] objArr9 = this.l;
                int i15 = this.f;
                int i16 = i15 + 1;
                this.f = i16;
                objArr9[i15] = objArr9[7];
                this.f = i15 + 2;
                objArr9[i16] = objArr9[6];
                return 0;
            case 15:
                Object[] objArr10 = this.l;
                int i17 = this.f;
                int i18 = i17 + 1;
                this.f = i18;
                objArr10[i17] = objArr10[5];
                int[] iArr4 = this.h;
                this.f = i17 + 2;
                iArr4[i18] = 0;
                return 0;
            case 16:
                int[] iArr5 = this.h;
                int i19 = this.f;
                this.f = i19 + 1;
                iArr5[i19] = 2;
                return 0;
            case 17:
                int[] iArr6 = this.h;
                int i20 = this.f;
                this.f = i20 + 1;
                iArr6[i20] = 2;
                this.f = i20;
                iArr6[i20 - 1] = iArr6[i20 - 1] % iArr6[i20];
                return 0;
            case 18:
                int i21 = this.f - 1;
                this.f = i21;
                this.l[i21] = null;
                return 0;
            case 20:
                int[] iArr7 = this.h;
                int i22 = this.f;
                this.f = i22 + 1;
                iArr7[i22] = 3;
                this.f = i22;
                iArr7[i22 - 1] = iArr7[i22 - 1] + iArr7[i22];
                this.f = i22 + 1;
                iArr7[i22] = iArr7[i22 - 1];
            case 19:
                return 0;
            case 21:
                int[] iArr8 = this.h;
                int i23 = this.f;
                this.f = i23 + 1;
                iArr8[i23] = 128;
                this.f = i23;
                iArr8[i23 - 1] = iArr8[i23 - 1] % iArr8[i23];
                return 0;
            case 22:
                int i24 = this.f;
                int i25 = i24 - 1;
                this.f = i25;
                int[] iArr9 = this.h;
                iArr9[i24 - 2] = iArr9[i24 - 2] % iArr9[i25];
                return 0;
            case 23:
                Object[] objArr11 = this.l;
                int i26 = this.f;
                Object obj5 = objArr11[i26 - 1];
                objArr11[i26 - 1] = null;
                this.e = obj5;
                return 0;
            case 24:
                int[] iArr10 = this.h;
                int i27 = this.f;
                int i28 = i27 + 1;
                this.f = i28;
                iArr10[i27] = 60;
                this.f = i27 + 2;
                iArr10[i28] = 0;
                return 0;
            case 25:
                int i29 = this.f;
                int i30 = i29 - 1;
                this.f = i30;
                int[] iArr11 = this.h;
                iArr11[i29 - 2] = iArr11[i29 - 2] / iArr11[i30];
                return 0;
            case 26:
                int[] iArr12 = this.h;
                int i31 = this.f;
                this.f = i31 + 1;
                iArr12[i31] = 47;
                this.f = i31;
                iArr12[i31 - 1] = iArr12[i31 - 1] + iArr12[i31];
                return 0;
            case 27:
                int[] iArr13 = this.h;
                int i32 = this.f;
                int i33 = i32 + 1;
                this.f = i33;
                iArr13[i32] = iArr13[i32 - 1];
                this.f = i32 + 2;
                iArr13[i33] = 128;
                int i34 = i32 + 1;
                this.f = i34;
                iArr13[i32] = iArr13[i32] % iArr13[i34];
                return 0;
            case 28:
                int i35 = this.f - 1;
                this.f = i35;
                this.d = this.h[i35] != 0 ? 0 : 1;
                return 0;
            case 29:
                int[] iArr14 = this.h;
                int i36 = this.f;
                this.f = i36 + 1;
                iArr14[i36] = 93;
                return 0;
            case 30:
                int i37 = this.f;
                int i38 = i37 - 1;
                this.f = i38;
                int[] iArr15 = this.h;
                iArr15[i37 - 2] = iArr15[i37 - 2] + iArr15[i38];
                return 0;
            case 31:
                Object[] objArr12 = this.l;
                int i39 = this.f;
                this.f = i39 + 1;
                objArr12[i39] = null;
                return 0;
            case 32:
                int[] iArr16 = this.h;
                int i40 = this.f - 1;
                this.f = i40;
                this.d = iArr16[i40];
                return 0;
            case 33:
                int[] iArr17 = this.h;
                int i41 = this.f;
                this.f = i41 + 1;
                iArr17[i41] = 4;
                return 0;
            case 34:
                int[] iArr18 = this.h;
                int i42 = this.f;
                this.f = i42 + 1;
                iArr18[i42] = 79;
                return 0;
            case 35:
                int[] iArr19 = this.h;
                int i43 = this.f;
                this.f = i43 + 1;
                iArr19[i43] = 0;
                return 0;
            case 36:
                for (int i44 = this.f - 1; i44 >= 0; i44--) {
                    this.l[i44] = null;
                }
                Object[] objArr13 = this.l;
                this.f = 1;
                objArr13[0] = this.b;
                return 0;
            case 37:
                Object[] objArr14 = this.l;
                int i45 = this.f;
                int i46 = i45 + 1;
                this.f = i46;
                objArr14[i45] = objArr14[5];
                int[] iArr20 = this.h;
                this.f = i45 + 2;
                iArr20[i46] = 1;
                return 0;
            case 38:
                int i47 = this.f - 1;
                this.f = i47;
                Object[] objArr15 = this.l;
                Object obj6 = objArr15[i47];
                objArr15[i47] = null;
                this.d = obj6 == null ? 0 : 1;
                return 0;
            case 39:
                int i48 = this.f;
                int i49 = i48 - 1;
                this.f = i49;
                int[] iArr21 = this.h;
                iArr21[i48 - 2] = iArr21[i48 - 2] % iArr21[i49];
                int i50 = i48 - 2;
                this.f = i50;
                this.l[i50] = null;
                return 0;
            case 40:
                int[] iArr22 = this.h;
                int i51 = this.f;
                int i52 = i51 + 1;
                this.f = i52;
                iArr22[i51] = 2;
                this.f = i51 + 2;
                iArr22[i52] = 2;
                return 0;
            case 41:
                int[] iArr23 = this.h;
                int i53 = this.f;
                this.f = i53 + 1;
                iArr23[i53] = 89;
                this.f = i53;
                iArr23[i53 - 1] = iArr23[i53 - 1] + iArr23[i53];
                this.f = i53 + 1;
                iArr23[i53] = iArr23[i53 - 1];
                return 0;
            case 42:
                int[] iArr24 = this.h;
                int i54 = this.f;
                int i55 = i54 + 1;
                this.f = i55;
                iArr24[i54] = 5;
                this.f = i54 + 2;
                iArr24[i55] = 5;
                return 0;
            case 43:
                int[] iArr25 = this.h;
                int i56 = this.f;
                this.f = i56 + 1;
                iArr25[i56] = 81;
                return 0;
            case 44:
                int[] iArr26 = this.h;
                int i57 = this.f;
                this.f = i57 + 1;
                iArr26[i57] = iArr26[i57 - 1];
                return 0;
            case 45:
                int[] iArr27 = this.h;
                int i58 = this.f;
                this.f = i58 + 1;
                iArr27[i58] = 22;
                return 0;
            case 46:
                int[] iArr28 = this.h;
                int i59 = this.f;
                this.f = i59 + 1;
                iArr28[i59] = 31;
                return 0;
            case 47:
                int[] iArr29 = this.h;
                int i60 = this.f;
                this.f = i60 + 1;
                iArr29[i60] = 28;
                return 0;
            case 48:
                int[] iArr30 = this.h;
                int i61 = this.f;
                this.f = i61 + 1;
                iArr30[i61] = 32;
                return 0;
            case 49:
                int[] iArr31 = this.h;
                int i62 = this.f;
                Object[] objArr16 = this.l;
                Object obj7 = objArr16[i62 - 1];
                objArr16[i62 - 1] = null;
                iArr31[i62 - 1] = ((Object[]) obj7).length;
                return 0;
            case 50:
                Object[] objArr17 = this.l;
                int i63 = this.f;
                this.f = i63 + 1;
                objArr17[i63] = objArr17[7];
                this.f = i63;
                Object obj8 = objArr17[i63];
                objArr17[i63] = null;
                objArr17[8] = obj8;
                return 0;
            case 51:
                int i64 = this.f;
                int i65 = i64 - 1;
                this.f = i65;
                Object[] objArr18 = this.l;
                Object obj9 = objArr18[i65];
                objArr18[i65] = null;
                objArr18[9] = obj9;
                int[] iArr32 = this.h;
                this.f = i64;
                iArr32[i65] = 0;
                return 0;
            case 52:
                int i66 = this.f - 1;
                this.f = i66;
                int[] iArr33 = this.h;
                iArr33[10] = iArr33[i66];
                return 0;
            case 53:
                int i67 = this.f - 1;
                this.f = i67;
                int[] iArr34 = this.h;
                iArr34[11] = iArr34[i67];
                return 0;
            case 54:
                int[] iArr35 = this.h;
                int i68 = this.f;
                this.f = i68 + 1;
                iArr35[i68] = iArr35[11];
                return 0;
            case 55:
                int i69 = this.f;
                int i70 = i69 - 2;
                this.f = i70;
                int[] iArr36 = this.h;
                this.d = iArr36[i70] >= iArr36[i69 - 1] ? 0 : 1;
                return 0;
            case 56:
                Object[] objArr19 = this.l;
                int i71 = this.f;
                this.f = i71 + 1;
                objArr19[i71] = objArr19[8];
                int[] iArr37 = this.h;
                Object obj10 = objArr19[i71];
                objArr19[i71] = null;
                iArr37[i71] = ((Object[]) obj10).length;
                return 0;
            case 57:
                Object[] objArr20 = this.l;
                int i72 = this.f;
                this.f = i72 + 1;
                objArr20[i72] = objArr20[8];
                return 0;
            case 58:
                int i73 = this.f;
                int i74 = i73 - 1;
                this.f = i74;
                Object[] objArr21 = this.l;
                Object obj11 = objArr21[i73 - 2];
                objArr21[i73 - 2] = null;
                objArr21[i73 - 2] = ((Object[]) obj11)[this.h[i74]];
                return 0;
            case 59:
                Object[] objArr22 = this.l;
                int i75 = this.f;
                int i76 = i75 + 1;
                this.f = i76;
                objArr22[i75] = objArr22[8];
                int[] iArr38 = this.h;
                this.f = i75 + 2;
                iArr38[i76] = iArr38[11];
                return 0;
            case 60:
                int i77 = this.f - 1;
                this.f = i77;
                Object[] objArr23 = this.l;
                Object obj12 = objArr23[i77];
                objArr23[i77] = null;
                objArr23[12] = obj12;
                return 0;
            case 61:
                Object[] objArr24 = this.l;
                int i78 = this.f;
                int i79 = i78 + 1;
                this.f = i79;
                objArr24[i78] = objArr24[9];
                this.f = i78 + 2;
                objArr24[i79] = objArr24[12];
                return 0;
            case 62:
                Object[] objArr25 = this.l;
                int i80 = this.f;
                this.f = i80 + 1;
                objArr25[i80] = objArr25[i80 - 1];
                this.f = i80;
                Object obj13 = objArr25[i80];
                objArr25[i80] = null;
                objArr25[13] = obj13;
                return 0;
            case 63:
                Object[] objArr26 = this.l;
                int i81 = this.f;
                this.f = i81 + 1;
                objArr26[i81] = objArr26[13];
                return 0;
            case 64:
                int[] iArr39 = this.h;
                int i82 = this.f;
                this.f = i82 + 1;
                iArr39[i82] = 1;
                this.f = i82;
                iArr39[i82 - 1] = iArr39[i82 - 1] + iArr39[i82];
                return 0;
            case 65:
                int i83 = this.f - 1;
                this.f = i83;
                int[] iArr40 = this.h;
                iArr40[14] = iArr40[i83];
                return 0;
            case 66:
                Object[] objArr27 = this.l;
                int i84 = this.f;
                this.f = i84 + 1;
                objArr27[i84] = objArr27[9];
                return 0;
            case 67:
                Object[] objArr28 = this.l;
                int i85 = this.f;
                int i86 = i85 + 1;
                this.f = i86;
                objArr28[i85] = objArr28[12];
                int[] iArr41 = this.h;
                this.f = i85 + 2;
                iArr41[i86] = iArr41[14];
                return 0;
            case 68:
                int i87 = this.f;
                int i88 = i87 - 1;
                this.f = i88;
                this.l[i88] = null;
                int[] iArr42 = this.h;
                this.f = i87;
                iArr42[i88] = iArr42[14];
                return 0;
            case 69:
                int i89 = this.f;
                int i90 = i89 - 2;
                this.f = i90;
                int[] iArr43 = this.h;
                this.d = iArr43[i90] <= iArr43[i89 - 1] ? 0 : 1;
                return 0;
            case 70:
                int[] iArr44 = this.h;
                iArr44[11] = iArr44[11] + 1;
                return 0;
            case 71:
                int i91 = this.f;
                int i92 = i91 - 2;
                this.f = i92;
                int[] iArr45 = this.h;
                this.d = iArr45[i92] < iArr45[i91 - 1] ? 0 : 1;
                return 0;
            case 72:
                int[] iArr46 = this.h;
                int i93 = this.f;
                this.f = i93 + 1;
                iArr46[i93] = iArr46[10];
                return 0;
            case 73:
                Object[] objArr29 = this.l;
                int i94 = this.f;
                int i95 = i94 + 1;
                this.f = i95;
                objArr29[i94] = objArr29[5];
                this.f = i94 + 2;
                objArr29[i95] = objArr29[7];
                return 0;
            case 74:
                int i96 = this.f;
                int i97 = i96 - 1;
                this.f = i97;
                Object[] objArr30 = this.l;
                Object obj14 = objArr30[i97];
                objArr30[i97] = null;
                objArr30[9] = obj14;
                int i98 = i96 - 2;
                this.f = i98;
                Object obj15 = objArr30[i98];
                objArr30[i98] = null;
                objArr30[8] = obj15;
                this.f = i96 - 1;
                objArr30[i98] = objArr30[9];
                return 0;
            case 75:
                int[] iArr47 = this.h;
                int i99 = this.f;
                int i100 = i99 + 1;
                this.f = i100;
                iArr47[i99] = 640;
                this.f = i99 + 2;
                iArr47[i100] = 360;
                return 0;
            case 76:
                int i101 = this.f;
                int i102 = i101 - 1;
                this.f = i102;
                Object[] objArr31 = this.l;
                Object obj16 = objArr31[i102];
                objArr31[i102] = null;
                objArr31[10] = obj16;
                this.f = i101;
                objArr31[i102] = objArr31[8];
                return 0;
            case 77:
                float[] fArr = this.f95873g;
                int i103 = this.f;
                fArr[i103 - 1] = this.h[i103 - 1];
                Object[] objArr32 = this.l;
                this.f = i103 + 1;
                objArr32[i103] = objArr32[8];
                return 0;
            case 78:
                this.f95873g[this.f - 1] = this.h[r3 - 1];
                return 0;
            case 79:
                int i104 = this.f;
                int i105 = i104 - 1;
                this.f = i105;
                float[] fArr2 = this.f95873g;
                fArr2[i104 - 2] = fArr2[i104 - 2] / fArr2[i105];
                int i106 = i104 - 2;
                this.f = i106;
                fArr2[11] = fArr2[i106];
                Object[] objArr33 = this.l;
                this.f = i104 - 1;
                objArr33[i106] = objArr33[10];
                return 0;
            case 80:
                Object[] objArr34 = this.l;
                int i107 = this.f;
                this.f = i107 + 1;
                objArr34[i107] = objArr34[10];
                return 0;
            case 81:
                int i108 = this.f;
                int i109 = i108 - 1;
                this.f = i109;
                int[] iArr48 = this.h;
                iArr48[i108 - 2] = iArr48[i108 - 2] * iArr48[i109];
                this.f = i108;
                iArr48[i109] = iArr48[i108 - 2];
                return 0;
            case 82:
                int i110 = this.f - 1;
                this.f = i110;
                int[] iArr49 = this.h;
                iArr49[13] = iArr49[i110];
                return 0;
            case 83:
                int i111 = this.f;
                int i112 = i111 - 1;
                this.f = i112;
                int[] iArr50 = this.h;
                iArr50[i111 - 2] = iArr50[i111 - 2] << iArr50[i112];
                int i113 = i111 - 2;
                this.f = i113;
                iArr50[14] = iArr50[i113];
                return 0;
            case 84:
                Object[] objArr35 = this.l;
                int i114 = this.f;
                this.f = i114 + 1;
                objArr35[i114] = null;
                this.f = i114;
                Object obj17 = objArr35[i114];
                objArr35[i114] = null;
                objArr35[7] = obj17;
                return 0;
            case 85:
                int i115 = this.f;
                int i116 = i115 - 1;
                this.f = i116;
                Object[] objArr36 = this.l;
                Object obj18 = objArr36[i116];
                objArr36[i116] = null;
                objArr36[8] = obj18;
                int[] iArr51 = this.h;
                Object obj19 = objArr36[i115 - 2];
                objArr36[i115 - 2] = null;
                iArr51[i115 - 2] = ((Object[]) obj19).length;
                int i117 = i115 - 2;
                this.f = i117;
                iArr51[9] = iArr51[i117];
                return 0;
            case 86:
                int i118 = this.f - 1;
                this.f = i118;
                int[] iArr52 = this.h;
                iArr52[12] = iArr52[i118];
                return 0;
            case 87:
                int[] iArr53 = this.h;
                int i119 = this.f;
                this.f = i119 + 1;
                iArr53[i119] = iArr53[12];
                return 0;
            case 88:
                int[] iArr54 = this.h;
                int i120 = this.f;
                this.f = i120 + 1;
                iArr54[i120] = iArr54[9];
                return 0;
            case 89:
                Object[] objArr37 = this.l;
                int i121 = this.f;
                int i122 = i121 + 1;
                this.f = i122;
                objArr37[i121] = objArr37[8];
                int[] iArr55 = this.h;
                this.f = i121 + 2;
                iArr55[i122] = iArr55[12];
                int i123 = i121 + 1;
                this.f = i123;
                Object obj20 = objArr37[i121];
                objArr37[i121] = null;
                objArr37[i121] = ((Object[]) obj20)[iArr55[i123]];
                return 0;
            case 90:
                int i124 = this.f - 1;
                this.f = i124;
                Object[] objArr38 = this.l;
                Object obj21 = objArr38[i124];
                objArr38[i124] = null;
                objArr38[15] = obj21;
                return 0;
            case 91:
                Object[] objArr39 = this.l;
                int i125 = this.f;
                this.f = i125 + 1;
                objArr39[i125] = objArr39[15];
                return 0;
            case 92:
                int i126 = this.f;
                int i127 = i126 - 1;
                this.f = i127;
                int[] iArr56 = this.h;
                iArr56[i126 - 2] = iArr56[i126 - 2] * iArr56[i127];
                return 0;
            case 93:
                int i128 = this.f;
                int i129 = i128 - 1;
                this.f = i129;
                int[] iArr57 = this.h;
                iArr57[16] = iArr57[i129];
                this.f = i128;
                iArr57[i129] = iArr57[13];
                return 0;
            case 94:
                int i130 = this.f;
                int i131 = i130 - 2;
                this.f = i131;
                int[] iArr58 = this.h;
                this.d = iArr58[i131] > iArr58[i130 - 1] ? 0 : 1;
                return 0;
            case 95:
                int[] iArr59 = this.h;
                int i132 = this.f;
                int i133 = i132 + 1;
                this.f = i133;
                iArr59[i132] = iArr59[16];
                this.f = i132 + 2;
                iArr59[i133] = iArr59[14];
                return 0;
            case 96:
                int i134 = this.f;
                int i135 = i134 - 1;
                this.f = i135;
                float[] fArr3 = this.f95873g;
                fArr3[i134 - 2] = fArr3[i134 - 2] / fArr3[i135];
                return 0;
            case 97:
                float[] fArr4 = this.f95873g;
                int i136 = this.f;
                this.f = i136 + 1;
                fArr4[i136] = fArr4[i136 - 1];
                return 0;
            case 98:
                float[] fArr5 = this.f95873g;
                int i137 = this.f;
                this.f = i137 + 1;
                fArr5[i137] = this.a;
                return 0;
            case 99:
                int i138 = this.f - 1;
                this.f = i138;
                float[] fArr6 = this.f95873g;
                fArr6[16] = fArr6[i138];
                return 0;
            case 100:
                int i139 = this.f - 1;
                this.f = i139;
                this.d = this.h[i139] > 0 ? 0 : 1;
                return 0;
            case 101:
                int i140 = this.f;
                int i141 = i140 - 1;
                this.f = i141;
                float[] fArr7 = this.f95873g;
                this.h[i140 - 2] = (fArr7[i140 - 2] > fArr7[i141] ? 1 : (fArr7[i140 - 2] == fArr7[i141] ? 0 : -1));
                return 0;
            case 102:
                int i142 = this.f;
                int i143 = i142 - 1;
                this.f = i143;
                Object[] objArr40 = this.l;
                Object obj22 = objArr40[i143];
                objArr40[i143] = null;
                objArr40[7] = obj22;
                float[] fArr8 = this.f95873g;
                this.f = i142;
                fArr8[i143] = fArr8[16];
                this.f = i142 + 1;
                fArr8[i142] = fArr8[11];
                return 0;
            case 103:
                int[] iArr60 = this.h;
                iArr60[12] = iArr60[12] + 1;
                return 0;
            case 104:
                Object[] objArr41 = this.l;
                int i144 = this.f;
                this.f = i144 + 1;
                objArr41[i144] = objArr41[10];
                this.f = i144;
                Object obj23 = objArr41[i144];
                objArr41[i144] = null;
                objArr41[7] = obj23;
                return 0;
            case 105:
                int i145 = this.f;
                int i146 = i145 - 1;
                this.f = i146;
                Object[] objArr42 = this.l;
                Object obj24 = objArr42[i146];
                objArr42[i146] = null;
                objArr42[7] = obj24;
                this.f = i145;
                objArr42[i146] = obj24;
                return 0;
            case 106:
                Object[] objArr43 = this.l;
                int i147 = this.f;
                int i148 = i147 + 1;
                this.f = i148;
                objArr43[i147] = objArr43[5];
                this.f = i147 + 2;
                objArr43[i148] = objArr43[6];
                return 0;
            case 107:
                int i149 = this.f;
                int i150 = i149 - 1;
                this.f = i150;
                Object[] objArr44 = this.l;
                objArr44[i150] = null;
                this.f = i149;
                objArr44[i150] = objArr44[7];
                return 0;
            case 108:
                int[] iArr61 = this.h;
                int i151 = this.f;
                this.f = i151 + 1;
                iArr61[i151] = 37;
                this.f = i151;
                iArr61[i151 - 1] = iArr61[i151 - 1] + iArr61[i151];
                return 0;
            case 109:
                int[] iArr62 = this.h;
                int i152 = this.f;
                this.f = i152 + 1;
                iArr62[i152] = 7;
                this.f = i152;
                iArr62[i152 - 1] = iArr62[i152 - 1] + iArr62[i152];
                this.f = i152 + 1;
                iArr62[i152] = iArr62[i152 - 1];
                return 0;
            case 110:
                int[] iArr63 = this.h;
                int i153 = this.f;
                this.f = i153 + 1;
                iArr63[i153] = 128;
                return 0;
            case 111:
                int[] iArr64 = this.h;
                int i154 = this.f;
                int i155 = i154 + 1;
                this.f = i155;
                iArr64[i154] = 86;
                this.f = i154 + 2;
                iArr64[i155] = 0;
                int i156 = i154 + 1;
                this.f = i156;
                iArr64[i154] = iArr64[i154] / iArr64[i156];
                return 0;
            case 112:
                int[] iArr65 = this.h;
                int i157 = this.f;
                this.f = i157 + 1;
                iArr65[i157] = 57;
                return 0;
            case 113:
                int[] iArr66 = this.h;
                int i158 = this.f;
                int i159 = i158 + 1;
                this.f = i159;
                iArr66[i158] = iArr66[i158 - 1];
                this.f = i158 + 2;
                iArr66[i159] = 128;
                return 0;
            case 114:
                int[] iArr67 = this.h;
                int i160 = this.f;
                this.f = i160 + 1;
                iArr67[i160] = 3;
                return 0;
            default:
                return i;
        }
    }

    public dt(Object obj) {
        this.h = new int[17];
        this.i = new long[17];
        this.f95873g = new float[17];
        this.n = new double[17];
        Object[] objArr = new Object[17];
        this.l = objArr;
        objArr[5] = obj;
        this.f = 0;
        this.j = -1;
    }

    public dt(Object obj, Object obj2, Object obj3) {
        this.h = new int[17];
        this.i = new long[17];
        this.f95873g = new float[17];
        this.n = new double[17];
        Object[] objArr = new Object[17];
        this.l = objArr;
        objArr[5] = obj;
        objArr[6] = obj2;
        objArr[7] = obj3;
        this.f = 0;
        this.j = -1;
    }
}