package com.facetec.sdk;

/* JADX INFO: loaded from: classes4.dex */
public class dv {
    public int a;
    public Object b;
    public Object c;
    private int d;
    public int e;
    private final float[] f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    private final long[] f95874g;
    private int h;
    private final int[] i;
    private final double[] j;
    private final Object[] m;

    public dv(Object obj, int i) {
        int[] iArr = new int[9];
        this.i = iArr;
        this.f95874g = new long[9];
        this.f = new float[9];
        this.j = new double[9];
        Object[] objArr = new Object[9];
        this.m = objArr;
        objArr[5] = obj;
        iArr[6] = i;
        this.d = 0;
        this.h = -1;
    }

    public int e(int i) {
        switch (i) {
            case 1:
                int i2 = this.d - this.a;
                this.d = i2;
                this.h = i2;
                return 0;
            case 2:
                Object[] objArr = this.m;
                int i3 = this.h;
                this.h = i3 + 1;
                Object obj = objArr[i3];
                objArr[i3] = null;
                this.b = obj;
                return 0;
            case 3:
                Object[] objArr2 = this.m;
                int i4 = this.d;
                this.d = i4 + 1;
                objArr2[i4] = this.c;
                return 0;
            case 4:
                Object[] objArr3 = this.m;
                int i5 = this.d;
                this.d = i5 + 1;
                objArr3[i5] = objArr3[5];
                return 0;
            case 5:
                int i6 = this.d - 1;
                this.d = i6;
                Object[] objArr4 = this.m;
                Object obj2 = objArr4[i6];
                objArr4[i6] = null;
                this.e = obj2 == null ? 0 : 1;
                return 0;
            case 6:
                int[] iArr = this.i;
                int i7 = this.d;
                this.d = i7 + 1;
                iArr[i7] = this.a;
                return 0;
            case 7:
                int[] iArr2 = this.i;
                int i8 = this.d;
                this.d = i8 + 1;
                iArr2[i8] = iArr2[6];
                return 0;
            case 8:
                int i9 = this.d - 1;
                this.d = i9;
                this.e = this.i[i9] != 0 ? 0 : 1;
                return 0;
            case 9:
                int[] iArr3 = this.i;
                int i10 = this.d;
                this.d = i10 + 1;
                iArr3[i10] = 1;
                return 0;
            case 10:
                int[] iArr4 = this.i;
                int i11 = this.d;
                this.d = i11 + 1;
                iArr4[i11] = 0;
                return 0;
            case 11:
                int i12 = this.d;
                int i13 = i12 - 2;
                this.d = i13;
                int[] iArr5 = this.i;
                this.e = iArr5[i13] != iArr5[i12 - 1] ? 0 : 1;
                return 0;
            case 12:
                int i14 = this.d - 1;
                this.d = i14;
                this.e = this.i[i14] == 0 ? 0 : 1;
                return 0;
            case 13:
                int[] iArr6 = this.i;
                int i15 = this.h;
                this.h = i15 + 1;
                this.e = iArr6[i15];
                return 0;
            case 14:
                Object[] objArr5 = this.m;
                int i16 = this.d;
                int i17 = i16 + 1;
                this.d = i17;
                objArr5[i16] = objArr5[5];
                int[] iArr7 = this.i;
                this.d = i16 + 2;
                iArr7[i17] = 1;
                return 0;
            case 15:
                int i18 = this.d - 1;
                this.d = i18;
                Object[] objArr6 = this.m;
                Object obj3 = objArr6[i18];
                objArr6[i18] = null;
                objArr6[6] = obj3;
                return 0;
            case 16:
                Object[] objArr7 = this.m;
                int i19 = this.d;
                this.d = i19 + 1;
                objArr7[i19] = objArr7[6];
                return 0;
            case 17:
                Object[] objArr8 = this.m;
                int i20 = this.d;
                this.d = i20 + 1;
                objArr8[i20] = null;
                return 0;
            case 18:
                int[] iArr8 = this.i;
                int i21 = this.d;
                int i22 = i21 + 1;
                this.d = i22;
                iArr8[i21] = 2;
                this.d = i21 + 2;
                iArr8[i22] = 2;
                int i23 = i21 + 1;
                this.d = i23;
                iArr8[i21] = iArr8[i21] % iArr8[i23];
                return 0;
            case 19:
                int i24 = this.d - 1;
                this.d = i24;
                this.m[i24] = null;
                return 0;
            case 21:
                int[] iArr9 = this.i;
                int i25 = this.d;
                this.d = i25 + 1;
                iArr9[i25] = 81;
                this.d = i25;
                iArr9[i25 - 1] = iArr9[i25 - 1] + iArr9[i25];
                this.d = i25 + 1;
                iArr9[i25] = iArr9[i25 - 1];
            case 20:
                return 0;
            case 22:
                int[] iArr10 = this.i;
                int i26 = this.d;
                this.d = i26 + 1;
                iArr10[i26] = 128;
                this.d = i26;
                iArr10[i26 - 1] = iArr10[i26 - 1] % iArr10[i26];
                return 0;
            case 23:
                int[] iArr11 = this.i;
                int i27 = this.d;
                this.d = i27 + 1;
                iArr11[i27] = 2;
                this.d = i27;
                iArr11[i27 - 1] = iArr11[i27 - 1] % iArr11[i27];
                return 0;
            case 24:
                Object[] objArr9 = this.m;
                int i28 = this.d;
                int i29 = i28 + 1;
                this.d = i29;
                objArr9[i28] = objArr9[5];
                int[] iArr12 = this.i;
                this.d = i28 + 2;
                iArr12[i29] = 0;
                return 0;
            case 25:
                int[] iArr13 = this.i;
                int i30 = this.d;
                this.d = i30 + 1;
                iArr13[i30] = 119;
                this.d = i30;
                iArr13[i30 - 1] = iArr13[i30 - 1] + iArr13[i30];
                this.d = i30 + 1;
                iArr13[i30] = iArr13[i30 - 1];
                return 0;
            case 26:
                Object[] objArr10 = this.m;
                int i31 = this.d;
                Object obj4 = objArr10[i31 - 1];
                objArr10[i31 - 1] = null;
                this.b = obj4;
                return 0;
            case 27:
                int[] iArr14 = this.i;
                int i32 = this.d;
                this.d = i32 + 1;
                iArr14[i32] = 47;
                return 0;
            case 28:
                int i33 = this.d;
                int i34 = i33 - 1;
                this.d = i34;
                int[] iArr15 = this.i;
                iArr15[i33 - 2] = iArr15[i33 - 2] + iArr15[i34];
                return 0;
            case 29:
                int[] iArr16 = this.i;
                int i35 = this.d;
                this.d = i35 + 1;
                iArr16[i35] = iArr16[i35 - 1];
                return 0;
            case 30:
                int[] iArr17 = this.i;
                int i36 = this.d - 1;
                this.d = i36;
                this.e = iArr17[i36];
                return 0;
            case 31:
                int[] iArr18 = this.i;
                int i37 = this.d;
                this.d = i37 + 1;
                iArr18[i37] = 55;
                return 0;
            case 32:
                int[] iArr19 = this.i;
                int i38 = this.d;
                this.d = i38 + 1;
                iArr19[i38] = 34;
                return 0;
            case 33:
                int[] iArr20 = this.i;
                int i39 = this.d;
                this.d = i39 + 1;
                iArr20[i39] = 68;
                return 0;
            case 34:
                int[] iArr21 = this.i;
                int i40 = this.d;
                this.d = i40 + 1;
                iArr21[i40] = 65;
                return 0;
            case 35:
                for (int i41 = this.d - 1; i41 >= 0; i41--) {
                    this.m[i41] = null;
                }
                Object[] objArr11 = this.m;
                this.d = 1;
                objArr11[0] = this.c;
                return 0;
            case 36:
                Object[] objArr12 = this.m;
                int i42 = this.d;
                this.d = i42 + 1;
                objArr12[i42] = objArr12[i42 - 1];
                return 0;
            case 37:
                int i43 = this.d - 1;
                this.d = i43;
                Object[] objArr13 = this.m;
                Object obj5 = objArr13[i43];
                objArr13[i43] = null;
                this.e = obj5 != null ? 0 : 1;
                return 0;
            case 38:
                int i44 = this.d - 1;
                this.d = i44;
                Object[] objArr14 = this.m;
                Object obj6 = objArr14[i44];
                objArr14[i44] = null;
                objArr14[7] = obj6;
                return 0;
            case 39:
                Object[] objArr15 = this.m;
                int i45 = this.d;
                this.d = i45 + 1;
                objArr15[i45] = objArr15[7];
                return 0;
            case 40:
                int i46 = this.d - 1;
                this.d = i46;
                Object[] objArr16 = this.m;
                Object obj7 = objArr16[i46];
                objArr16[i46] = null;
                objArr16[8] = obj7;
                return 0;
            case 41:
                Object[] objArr17 = this.m;
                int i47 = this.d;
                int i48 = i47 + 1;
                this.d = i48;
                objArr17[i47] = objArr17[5];
                this.d = i47 + 2;
                objArr17[i48] = objArr17[8];
                return 0;
            case 42:
                int[] iArr22 = this.i;
                int i49 = this.d;
                this.d = i49 + 1;
                iArr22[i49] = 2;
                return 0;
            case 43:
                int[] iArr23 = this.i;
                int i50 = this.d;
                this.d = i50 + 1;
                iArr23[i50] = 79;
                this.d = i50;
                iArr23[i50 - 1] = iArr23[i50 - 1] + iArr23[i50];
                this.d = i50 + 1;
                iArr23[i50] = iArr23[i50 - 1];
                return 0;
            case 44:
                int[] iArr24 = this.i;
                int i51 = this.d;
                this.d = i51 + 1;
                iArr24[i51] = 5;
                this.d = i51;
                iArr24[i51 - 1] = iArr24[i51 - 1] + iArr24[i51];
                return 0;
            case 45:
                int i52 = this.d;
                int i53 = i52 - 1;
                this.d = i53;
                int[] iArr25 = this.i;
                iArr25[i52 - 2] = iArr25[i52 - 2] % iArr25[i53];
                return 0;
            case 46:
                int[] iArr26 = this.i;
                int i54 = this.d;
                this.d = i54 + 1;
                iArr26[i54] = 30;
                return 0;
            case 47:
                int[] iArr27 = this.i;
                int i55 = this.d;
                this.d = i55 + 1;
                iArr27[i55] = 13;
                return 0;
            case 48:
                int[] iArr28 = this.i;
                int i56 = this.d;
                this.d = i56 + 1;
                iArr28[i56] = 61;
                return 0;
            case 49:
                int[] iArr29 = this.i;
                int i57 = this.d;
                this.d = i57 + 1;
                iArr29[i57] = 45;
                return 0;
            case 50:
                int[] iArr30 = this.i;
                int i58 = this.d;
                this.d = i58 + 1;
                iArr30[i58] = 76;
                return 0;
            case 51:
                int[] iArr31 = this.i;
                int i59 = this.d;
                this.d = i59 + 1;
                iArr31[i59] = 88;
                return 0;
            default:
                return i;
        }
    }

    public dv(Object obj, Object obj2) {
        this.i = new int[9];
        this.f95874g = new long[9];
        this.f = new float[9];
        this.j = new double[9];
        Object[] objArr = new Object[9];
        this.m = objArr;
        objArr[5] = obj;
        objArr[6] = obj2;
        this.d = 0;
        this.h = -1;
    }
}