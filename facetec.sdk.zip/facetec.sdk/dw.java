package com.facetec.sdk;

/* JADX INFO: loaded from: classes4.dex */
public class dw {
    public Object a;
    public long b;
    public int c;
    public long d;
    public int e;
    private int f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    private int f95875g;
    public Object h;
    private final Object[] k;
    private final int[] j = new int[12];
    private final long[] i = new long[12];
    private final float[] l = new float[12];
    private final double[] o = new double[12];

    public dw(Object obj, Object obj2, Object obj3) {
        Object[] objArr = new Object[12];
        this.k = objArr;
        objArr[7] = obj;
        objArr[8] = obj2;
        objArr[9] = obj3;
        this.f = 0;
        this.f95875g = -1;
    }

    public int e(int i) {
        switch (i) {
            case 1:
                Object[] objArr = this.k;
                int i2 = this.f;
                this.f = i2 + 1;
                objArr[i2] = this.a;
                return 0;
            case 2:
                Object[] objArr2 = this.k;
                int i3 = this.f;
                this.f = i3 + 1;
                objArr2[i3] = objArr2[8];
                return 0;
            case 3:
                int i4 = this.f - this.e;
                this.f = i4;
                this.f95875g = i4;
                return 0;
            case 4:
                Object[] objArr3 = this.k;
                int i5 = this.f95875g;
                this.f95875g = i5 + 1;
                Object obj = objArr3[i5];
                objArr3[i5] = null;
                this.h = obj;
                return 0;
            case 5:
                int[] iArr = this.j;
                int i6 = this.f;
                this.f = i6 + 1;
                iArr[i6] = this.e;
                return 0;
            case 6:
                int[] iArr2 = this.j;
                int i7 = this.f;
                this.f = i7 + 1;
                iArr2[i7] = 0;
                return 0;
            case 7:
                int[] iArr3 = this.j;
                int i8 = this.f95875g;
                this.f95875g = i8 + 1;
                this.c = iArr3[i8];
                return 0;
            case 8:
                int[] iArr4 = this.j;
                int i9 = this.f;
                this.f = i9 + 1;
                iArr4[i9] = 1;
                return 0;
            case 9:
                Object[] objArr4 = this.k;
                int i10 = this.f;
                this.f = i10 + 1;
                objArr4[i10] = objArr4[i10 - 1];
                return 0;
            case 10:
                int i11 = this.f - 1;
                this.f = i11;
                Object[] objArr5 = this.k;
                Object obj2 = objArr5[i11];
                objArr5[i11] = null;
                this.c = obj2 == null ? 0 : 1;
                return 0;
            case 11:
                Object[] objArr6 = this.k;
                int i12 = this.f;
                Object obj3 = objArr6[i12 - 1];
                objArr6[i12 - 1] = null;
                Object obj4 = objArr6[i12 - 2];
                objArr6[i12 - 2] = null;
                objArr6[i12 - 1] = obj4;
                objArr6[i12 - 2] = obj3;
                int i13 = i12 - 1;
                this.f = i13;
                objArr6[i13] = null;
                return 0;
            case 12:
                Object[] objArr7 = this.k;
                int i14 = this.f;
                Object obj5 = objArr7[i14 - 1];
                objArr7[i14 - 1] = null;
                this.h = obj5;
                return 0;
            case 13:
                int i15 = this.f - 1;
                this.f = i15;
                this.k[i15] = null;
                return 0;
            case 14:
                int[] iArr5 = this.j;
                int i16 = this.f;
                this.f = i16 + 1;
                iArr5[i16] = 16;
                return 0;
            case 15:
                int i17 = this.f;
                int i18 = i17 - 1;
                this.f = i18;
                int[] iArr6 = this.j;
                iArr6[i17 - 2] = iArr6[i17 - 2] + iArr6[i18];
                return 0;
            case 16:
                long[] jArr = this.i;
                int i19 = this.f;
                this.f = i19 + 1;
                jArr[i19] = this.d;
                return 0;
            case 17:
                long[] jArr2 = this.i;
                int i20 = this.f;
                this.f = i20 + 1;
                jArr2[i20] = 0;
                this.f = i20;
                this.j[i20 - 1] = (jArr2[i20 - 1] > jArr2[i20] ? 1 : (jArr2[i20 - 1] == jArr2[i20] ? 0 : -1));
                return 0;
            case 18:
                Object[] objArr8 = this.k;
                int i21 = this.f;
                this.f = i21 + 1;
                objArr8[i21] = null;
                return 0;
            case 19:
                Object[] objArr9 = this.k;
                int i22 = this.f;
                this.f = i22 + 1;
                objArr9[i22] = objArr9[7];
                return 0;
            case 20:
                int i23 = this.f;
                int i24 = i23 - 1;
                this.f = i24;
                long[] jArr3 = this.i;
                jArr3[i23 - 2] = jArr3[i23 - 2] - jArr3[i24];
                return 0;
            case 21:
                int i25 = this.f - 1;
                this.f = i25;
                long[] jArr4 = this.i;
                jArr4[10] = jArr4[i25];
                return 0;
            case 22:
                long[] jArr5 = this.i;
                int i26 = this.f95875g;
                this.f95875g = i26 + 1;
                this.b = jArr5[i26];
                return 0;
            case 23:
                long[] jArr6 = this.i;
                int i27 = this.f;
                this.f = i27 + 1;
                jArr6[i27] = jArr6[10];
                return 0;
            case 24:
                int[] iArr7 = this.j;
                int i28 = this.f;
                this.f = i28 + 1;
                iArr7[i28] = 2;
                return 0;
            case 25:
                int[] iArr8 = this.j;
                int i29 = this.f;
                this.f = i29 + 1;
                iArr8[i29] = 2;
                this.f = i29;
                iArr8[i29 - 1] = iArr8[i29 - 1] % iArr8[i29];
                int i30 = i29 - 1;
                this.f = i30;
                this.k[i30] = null;
                return 0;
            case 27:
                int[] iArr9 = this.j;
                int i31 = this.f;
                this.f = i31 + 1;
                iArr9[i31] = 67;
            case 26:
                return 0;
            case 28:
                int i32 = this.f;
                int i33 = i32 - 1;
                this.f = i33;
                int[] iArr10 = this.j;
                iArr10[i32 - 2] = iArr10[i32 - 2] + iArr10[i33];
                this.f = i32;
                iArr10[i33] = iArr10[i32 - 2];
                this.f = i32 + 1;
                iArr10[i32] = 128;
                return 0;
            case 29:
                int i34 = this.f;
                int i35 = i34 - 1;
                this.f = i35;
                int[] iArr11 = this.j;
                iArr11[i34 - 2] = iArr11[i34 - 2] % iArr11[i35];
                return 0;
            case 30:
                int i36 = this.f - 1;
                this.f = i36;
                this.c = this.j[i36] == 0 ? 0 : 1;
                return 0;
            case 31:
                int[] iArr12 = this.j;
                int i37 = this.f;
                this.f = i37 + 1;
                iArr12[i37] = 52;
                return 0;
            case 32:
                int[] iArr13 = this.j;
                int i38 = this.f;
                this.f = i38 + 1;
                iArr13[i38] = 0;
                this.f = i38;
                iArr13[i38 - 1] = iArr13[i38 - 1] / iArr13[i38];
                int i39 = i38 - 1;
                this.f = i39;
                this.k[i39] = null;
                return 0;
            case 33:
                int[] iArr14 = this.j;
                int i40 = this.f;
                this.f = i40 + 1;
                iArr14[i40] = 73;
                return 0;
            case 34:
                int i41 = this.f;
                int i42 = i41 - 1;
                this.f = i42;
                int[] iArr15 = this.j;
                iArr15[i41 - 2] = iArr15[i41 - 2] + iArr15[i42];
                this.f = i41;
                iArr15[i42] = iArr15[i41 - 2];
                return 0;
            case 35:
                int[] iArr16 = this.j;
                int i43 = this.f;
                this.f = i43 + 1;
                iArr16[i43] = 128;
                this.f = i43;
                iArr16[i43 - 1] = iArr16[i43 - 1] % iArr16[i43];
                return 0;
            case 36:
                int i44 = this.f - 1;
                this.f = i44;
                this.c = this.j[i44] != 0 ? 0 : 1;
                return 0;
            case 37:
                int[] iArr17 = this.j;
                int i45 = this.f;
                this.f = i45 + 1;
                iArr17[i45] = 2;
                this.f = i45;
                iArr17[i45 - 1] = iArr17[i45 - 1] % iArr17[i45];
                return 0;
            case 38:
                int[] iArr18 = this.j;
                int i46 = this.f - 1;
                this.f = i46;
                this.c = iArr18[i46];
                return 0;
            case 39:
                for (int i47 = this.f - 1; i47 >= 0; i47--) {
                    this.k[i47] = null;
                }
                Object[] objArr10 = this.k;
                this.f = 1;
                objArr10[0] = this.a;
                return 0;
            default:
                return i;
        }
    }
}