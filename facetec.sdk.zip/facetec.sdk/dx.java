package com.facetec.sdk;

/* JADX INFO: loaded from: classes4.dex */
public class dx {
    public Object a;
    public int b;
    public int c;
    public long d;
    public long e;
    public Object f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    private int f95876g;
    private int i;
    private final int[] j;
    private final Object[] n;
    private final long[] h = new long[10];
    private final float[] m = new float[10];
    private final double[] o = new double[10];

    public dx(Object obj, int i) {
        int[] iArr = new int[10];
        this.j = iArr;
        Object[] objArr = new Object[10];
        this.n = objArr;
        objArr[6] = obj;
        iArr[7] = i;
        this.f95876g = 0;
        this.i = -1;
    }

    public int a(int i) {
        switch (i) {
            case 1:
                int i2 = this.f95876g - this.b;
                this.f95876g = i2;
                this.i = i2;
                return 0;
            case 2:
                Object[] objArr = this.n;
                int i3 = this.i;
                this.i = i3 + 1;
                Object obj = objArr[i3];
                objArr[i3] = null;
                this.f = obj;
                return 0;
            case 3:
                Object[] objArr2 = this.n;
                int i4 = this.f95876g;
                this.f95876g = i4 + 1;
                objArr2[i4] = this.a;
                return 0;
            case 4:
                Object[] objArr3 = this.n;
                int i5 = this.f95876g;
                this.f95876g = i5 + 1;
                objArr3[i5] = objArr3[i5 - 1];
                return 0;
            case 5:
                int i6 = this.f95876g - 1;
                this.f95876g = i6;
                Object[] objArr4 = this.n;
                Object obj2 = objArr4[i6];
                objArr4[i6] = null;
                this.c = obj2 == null ? 0 : 1;
                return 0;
            case 6:
                Object[] objArr5 = this.n;
                int i7 = this.f95876g;
                Object obj3 = objArr5[i7 - 1];
                objArr5[i7 - 1] = null;
                Object obj4 = objArr5[i7 - 2];
                objArr5[i7 - 2] = null;
                objArr5[i7 - 1] = obj4;
                objArr5[i7 - 2] = obj3;
                return 0;
            case 7:
                Object[] objArr6 = this.n;
                int i8 = this.f95876g;
                Object obj5 = objArr6[i8 - 1];
                objArr6[i8 - 1] = null;
                this.f = obj5;
                return 0;
            case 8:
                int i9 = this.f95876g - 1;
                this.f95876g = i9;
                this.n[i9] = null;
                return 0;
            case 9:
                int[] iArr = this.j;
                int i10 = this.f95876g;
                this.f95876g = i10 + 1;
                iArr[i10] = 17783;
                return 0;
            case 10:
                int[] iArr2 = this.j;
                int i11 = this.f95876g;
                int i12 = i11 + 1;
                this.f95876g = i12;
                iArr2[i11] = 0;
                this.f95876g = i11 + 2;
                iArr2[i12] = 0;
                return 0;
            case 11:
                int[] iArr3 = this.j;
                int i13 = this.i;
                this.i = i13 + 1;
                this.c = iArr3[i13];
                return 0;
            case 12:
                int[] iArr4 = this.j;
                int i14 = this.f95876g;
                this.f95876g = i14 + 1;
                iArr4[i14] = this.b;
                return 0;
            case 13:
                int i15 = this.f95876g;
                int i16 = i15 - 1;
                this.f95876g = i16;
                int[] iArr5 = this.j;
                iArr5[i15 - 2] = iArr5[i15 - 2] - iArr5[i16];
                return 0;
            case 14:
                int[] iArr6 = this.j;
                int i17 = this.f95876g;
                this.f95876g = i17 + 1;
                iArr6[i17] = 30269;
                return 0;
            case 15:
                int[] iArr7 = this.j;
                int i18 = this.f95876g;
                this.f95876g = i18 + 1;
                iArr7[i18] = 0;
                return 0;
            case 16:
                Object[] objArr7 = this.n;
                int i19 = this.f95876g;
                this.f95876g = i19 + 1;
                objArr7[i19] = null;
                return 0;
            case 17:
                Object[] objArr8 = this.n;
                int i20 = this.f95876g;
                int i21 = i20 + 1;
                this.f95876g = i21;
                objArr8[i20] = null;
                this.f95876g = i20 + 2;
                objArr8[i21] = null;
                return 0;
            case 18:
                long[] jArr = this.h;
                int i22 = this.f95876g;
                this.f95876g = i22 + 1;
                jArr[i22] = this.e;
                return 0;
            case 19:
                int i23 = this.f95876g - 1;
                this.f95876g = i23;
                long[] jArr2 = this.h;
                jArr2[8] = jArr2[i23];
                return 0;
            case 20:
                Object[] objArr9 = this.n;
                int i24 = this.f95876g;
                int i25 = i24 + 1;
                this.f95876g = i25;
                objArr9[i24] = objArr9[6];
                long[] jArr3 = this.h;
                this.f95876g = i24 + 2;
                jArr3[i25] = jArr3[8];
                return 0;
            case 21:
                int[] iArr8 = this.j;
                int i26 = this.f95876g;
                this.f95876g = i26 + 1;
                iArr8[i26] = iArr8[7];
                return 0;
            case 22:
                long[] jArr4 = this.h;
                int i27 = this.i;
                this.i = i27 + 1;
                this.d = jArr4[i27];
                return 0;
            case 23:
                int i28 = this.f95876g;
                int i29 = i28 - 1;
                this.f95876g = i29;
                Object[] objArr10 = this.n;
                Object obj6 = objArr10[i29];
                objArr10[i29] = null;
                objArr10[7] = obj6;
                this.f95876g = i28;
                objArr10[i29] = objArr10[6];
                return 0;
            case 24:
                Object[] objArr11 = this.n;
                int i30 = this.f95876g;
                this.f95876g = i30 + 1;
                objArr11[i30] = objArr11[7];
                return 0;
            case 25:
                int[] iArr9 = this.j;
                int i31 = this.f95876g;
                this.f95876g = i31 + 1;
                iArr9[i31] = 2;
                return 0;
            case 26:
                int[] iArr10 = this.j;
                int i32 = this.f95876g;
                this.f95876g = i32 + 1;
                iArr10[i32] = 2;
                this.f95876g = i32;
                iArr10[i32 - 1] = iArr10[i32 - 1] % iArr10[i32];
                return 0;
            case 28:
                int[] iArr11 = this.j;
                int i33 = this.f95876g;
                this.f95876g = i33 + 1;
                iArr11[i33] = 57;
                this.f95876g = i33;
                iArr11[i33 - 1] = iArr11[i33 - 1] + iArr11[i33];
            case 27:
                return 0;
            case 29:
                int[] iArr12 = this.j;
                int i34 = this.f95876g;
                this.f95876g = i34 + 1;
                iArr12[i34] = iArr12[i34 - 1];
                return 0;
            case 30:
                int[] iArr13 = this.j;
                int i35 = this.f95876g;
                this.f95876g = i35 + 1;
                iArr13[i35] = 128;
                return 0;
            case 31:
                int i36 = this.f95876g;
                int i37 = i36 - 1;
                this.f95876g = i37;
                int[] iArr14 = this.j;
                iArr14[i36 - 2] = iArr14[i36 - 2] % iArr14[i37];
                return 0;
            case 32:
                int i38 = this.f95876g - 1;
                this.f95876g = i38;
                this.c = this.j[i38] != 0 ? 0 : 1;
                return 0;
            case 33:
                for (int i39 = this.f95876g - 1; i39 >= 0; i39--) {
                    this.n[i39] = null;
                }
                Object[] objArr12 = this.n;
                this.f95876g = 1;
                objArr12[0] = this.a;
                return 0;
            default:
                return i;
        }
    }
}