package com.facetec.sdk;

/* JADX INFO: loaded from: classes4.dex */
public class dy {
    public int a;
    public int b;
    public Object c;
    public Object d;
    private int e;
    private int i;
    private final Object[] m;
    private final int[] h = new int[5];
    private final long[] j = new long[5];
    private final float[] f = new float[5];

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    private final double[] f95877g = new double[5];

    public dy(Object obj) {
        Object[] objArr = new Object[5];
        this.m = objArr;
        objArr[4] = obj;
        this.e = 0;
        this.i = -1;
    }

    public int b(int i) {
        switch (i) {
            case 1:
                Object[] objArr = this.m;
                int i2 = this.e;
                this.e = i2 + 1;
                objArr[i2] = this.c;
                return 0;
            case 2:
                int i3 = this.e - 1;
                this.e = i3;
                Object[] objArr2 = this.m;
                Object obj = objArr2[i3];
                objArr2[i3] = null;
                this.a = obj == null ? 0 : 1;
                return 0;
            case 3:
                int i4 = this.e - this.b;
                this.e = i4;
                this.i = i4;
                return 0;
            case 4:
                Object[] objArr3 = this.m;
                int i5 = this.i;
                this.i = i5 + 1;
                Object obj2 = objArr3[i5];
                objArr3[i5] = null;
                this.d = obj2;
                return 0;
            case 5:
                int[] iArr = this.h;
                int i6 = this.e;
                this.e = i6 + 1;
                iArr[i6] = this.b;
                return 0;
            case 6:
                Object[] objArr4 = this.m;
                int i7 = this.e;
                this.e = i7 + 1;
                objArr4[i7] = objArr4[i7 - 1];
                return 0;
            case 7:
                int[] iArr2 = this.h;
                int i8 = this.e;
                int i9 = i8 + 1;
                this.e = i9;
                iArr2[i8] = 2;
                this.e = i8 + 2;
                iArr2[i9] = 2;
                int i10 = i8 + 1;
                this.e = i10;
                iArr2[i8] = iArr2[i8] % iArr2[i10];
                return 0;
            case 8:
                int i11 = this.e - 1;
                this.e = i11;
                this.m[i11] = null;
                return 0;
            case 10:
                this.a = this.h[this.e - 1];
            case 9:
                return 0;
            case 11:
                int[] iArr3 = this.h;
                int i12 = this.e;
                this.e = i12 + 1;
                iArr3[i12] = 103;
                this.e = i12;
                iArr3[i12 - 1] = iArr3[i12 - 1] + iArr3[i12];
                this.e = i12 + 1;
                iArr3[i12] = iArr3[i12 - 1];
                return 0;
            case 12:
                int[] iArr4 = this.h;
                int i13 = this.e;
                this.e = i13 + 1;
                iArr4[i13] = 128;
                this.e = i13;
                iArr4[i13 - 1] = iArr4[i13 - 1] % iArr4[i13];
                return 0;
            case 13:
                int[] iArr5 = this.h;
                int i14 = this.i;
                this.i = i14 + 1;
                this.a = iArr5[i14];
                return 0;
            case 14:
                int[] iArr6 = this.h;
                int i15 = this.e;
                this.e = i15 + 1;
                iArr6[i15] = 2;
                return 0;
            case 15:
                int i16 = this.e;
                int i17 = i16 - 1;
                this.e = i17;
                int[] iArr7 = this.h;
                iArr7[i16 - 2] = iArr7[i16 - 2] % iArr7[i17];
                return 0;
            case 16:
                int i18 = this.e - 1;
                this.e = i18;
                this.a = this.h[i18] == 0 ? 0 : 1;
                return 0;
            case 17:
                int[] iArr8 = this.h;
                int i19 = this.e;
                this.e = i19 + 1;
                iArr8[i19] = 7;
                return 0;
            case 18:
                int i20 = this.e;
                int i21 = i20 - 1;
                this.e = i21;
                int[] iArr9 = this.h;
                iArr9[i20 - 2] = iArr9[i20 - 2] + iArr9[i21];
                return 0;
            case 19:
                int[] iArr10 = this.h;
                int i22 = this.e;
                this.e = i22 + 1;
                iArr10[i22] = iArr10[i22 - 1];
                return 0;
            case 20:
                int[] iArr11 = this.h;
                int i23 = this.e - 1;
                this.e = i23;
                this.a = iArr11[i23];
                return 0;
            case 21:
                int[] iArr12 = this.h;
                int i24 = this.e;
                this.e = i24 + 1;
                iArr12[i24] = 1;
                return 0;
            case 22:
                int[] iArr13 = this.h;
                int i25 = this.e;
                this.e = i25 + 1;
                iArr13[i25] = 0;
                return 0;
            default:
                return i;
        }
    }
}