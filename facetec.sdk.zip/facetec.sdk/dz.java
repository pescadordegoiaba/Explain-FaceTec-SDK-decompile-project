package com.facetec.sdk;

/* JADX INFO: loaded from: classes4.dex */
public class dz {
    public int a;
    private int b;
    public Object c;
    public Object d;
    public int e;
    private final int[] f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    private final double[] f95878g;
    private final float[] h;
    private final long[] i;
    private int j;
    private final Object[] k;

    public dz(Object obj, Object obj2, Object obj3, Object obj4, Object obj5) {
        this.f = new int[10];
        this.i = new long[10];
        this.h = new float[10];
        this.f95878g = new double[10];
        Object[] objArr = new Object[10];
        this.k = objArr;
        objArr[5] = obj;
        objArr[6] = obj2;
        objArr[7] = obj3;
        objArr[8] = obj4;
        objArr[9] = obj5;
        this.b = 0;
        this.j = -1;
    }

    public int d(int i) {
        switch (i) {
            case 1:
                int i2 = this.b - this.a;
                this.b = i2;
                this.j = i2;
                return 0;
            case 2:
                int[] iArr = this.f;
                int i3 = this.j;
                this.j = i3 + 1;
                this.e = iArr[i3];
                return 0;
            case 3:
                int[] iArr2 = this.f;
                int i4 = this.b;
                this.b = i4 + 1;
                iArr2[i4] = 1;
                return 0;
            case 4:
                int[] iArr3 = this.f;
                int i5 = this.b;
                this.b = i5 + 1;
                iArr3[i5] = this.a;
                return 0;
            case 5:
                int i6 = this.b - 1;
                this.b = i6;
                this.e = this.f[i6] == 0 ? 0 : 1;
                return 0;
            case 6:
                Object[] objArr = this.k;
                int i7 = this.b;
                this.b = i7 + 1;
                objArr[i7] = this.d;
                return 0;
            case 7:
                Object[] objArr2 = this.k;
                int i8 = this.j;
                this.j = i8 + 1;
                Object obj = objArr2[i8];
                objArr2[i8] = null;
                this.c = obj;
                return 0;
            case 8:
                Object[] objArr3 = this.k;
                int i9 = this.b;
                Object obj2 = objArr3[i9 - 1];
                objArr3[i9 - 1] = null;
                this.c = obj2;
                return 0;
            case 9:
                Object[] objArr4 = this.k;
                int i10 = this.b;
                this.b = i10 + 1;
                objArr4[i10] = objArr4[5];
                return 0;
            case 10:
                Object[] objArr5 = this.k;
                int i11 = this.b;
                this.b = i11 + 1;
                objArr5[i11] = null;
                return 0;
            case 11:
                int i12 = this.b;
                int i13 = i12 - 2;
                this.b = i13;
                Object[] objArr6 = this.k;
                Object obj3 = objArr6[i13];
                objArr6[i13] = null;
                Object obj4 = objArr6[i12 - 1];
                objArr6[i12 - 1] = null;
                this.e = obj3 != obj4 ? 0 : 1;
                return 0;
            case 12:
                Object[] objArr7 = this.k;
                int i14 = this.b;
                int i15 = i14 + 1;
                this.b = i15;
                objArr7[i14] = null;
                this.b = i14 + 2;
                objArr7[i15] = null;
                return 0;
            case 13:
                Object[] objArr8 = this.k;
                int i16 = this.b;
                int i17 = i16 + 1;
                this.b = i17;
                objArr8[i16] = objArr8[5];
                int i18 = i16 + 2;
                this.b = i18;
                objArr8[i17] = objArr8[9];
                int[] iArr4 = this.f;
                this.b = i16 + 3;
                iArr4[i18] = 1;
                return 0;
            case 14:
                Object[] objArr9 = this.k;
                int i19 = this.b;
                this.b = i19 + 1;
                objArr9[i19] = objArr9[6];
                return 0;
            case 15:
                int i20 = this.b - 1;
                this.b = i20;
                Object[] objArr10 = this.k;
                Object obj5 = objArr10[i20];
                objArr10[i20] = null;
                this.e = obj5 != null ? 0 : 1;
                return 0;
            case 16:
                Object[] objArr11 = this.k;
                int i21 = this.b;
                int i22 = i21 + 1;
                this.b = i22;
                objArr11[i21] = objArr11[5];
                int i23 = i21 + 2;
                this.b = i23;
                objArr11[i22] = objArr11[9];
                int[] iArr5 = this.f;
                this.b = i21 + 3;
                iArr5[i23] = 0;
                return 0;
            case 17:
                Object[] objArr12 = this.k;
                int i24 = this.b;
                this.b = i24 + 1;
                objArr12[i24] = objArr12[7];
                return 0;
            case 18:
                Object[] objArr13 = this.k;
                int i25 = this.b;
                this.b = i25 + 1;
                objArr13[i25] = objArr13[9];
                return 0;
            case 19:
                int i26 = this.b - 1;
                this.b = i26;
                this.k[i26] = null;
                return 0;
            case 20:
                Object[] objArr14 = this.k;
                int i27 = this.b;
                int i28 = i27 + 1;
                this.b = i28;
                objArr14[i27] = objArr14[5];
                this.b = i27 + 2;
                objArr14[i28] = objArr14[9];
                return 0;
            case 21:
                int[] iArr6 = this.f;
                int i29 = this.b;
                this.b = i29 + 1;
                iArr6[i29] = 0;
                return 0;
            case 22:
                int[] iArr7 = this.f;
                int i30 = this.b;
                this.b = i30 + 1;
                iArr7[i30] = 2;
                return 0;
            case 23:
                int[] iArr8 = this.f;
                int i31 = this.b;
                this.b = i31 + 1;
                iArr8[i31] = 2;
                this.b = i31;
                iArr8[i31 - 1] = iArr8[i31 - 1] % iArr8[i31];
                return 0;
            case 25:
                int i32 = this.b;
                int i33 = i32 - 1;
                this.b = i33;
                int[] iArr9 = this.f;
                iArr9[i32 - 2] = iArr9[i32 - 2] % iArr9[i33];
                int i34 = i32 - 2;
                this.b = i34;
                this.k[i34] = null;
            case 24:
                return 0;
            case 26:
                int[] iArr10 = this.f;
                int i35 = this.b;
                this.b = i35 + 1;
                iArr10[i35] = 121;
                this.b = i35;
                iArr10[i35 - 1] = iArr10[i35 - 1] + iArr10[i35];
                return 0;
            case 27:
                int[] iArr11 = this.f;
                int i36 = this.b;
                this.b = i36 + 1;
                iArr11[i36] = iArr11[i36 - 1];
                return 0;
            case 28:
                int[] iArr12 = this.f;
                int i37 = this.b;
                this.b = i37 + 1;
                iArr12[i37] = 128;
                this.b = i37;
                iArr12[i37 - 1] = iArr12[i37 - 1] % iArr12[i37];
                return 0;
            case 29:
                int i38 = this.b - 1;
                this.b = i38;
                this.e = this.f[i38] != 0 ? 0 : 1;
                return 0;
            case 30:
                int[] iArr13 = this.f;
                int i39 = this.b;
                Object[] objArr15 = this.k;
                Object obj6 = objArr15[i39 - 1];
                objArr15[i39 - 1] = null;
                iArr13[i39 - 1] = ((int[]) obj6).length;
                int i40 = i39 - 1;
                this.b = i40;
                objArr15[i40] = null;
                return 0;
            case 31:
                int[] iArr14 = this.f;
                int i41 = this.b;
                this.b = i41 + 1;
                iArr14[i41] = 117;
                this.b = i41;
                iArr14[i41 - 1] = iArr14[i41 - 1] + iArr14[i41];
                return 0;
            case 32:
                int[] iArr15 = this.f;
                int i42 = this.b;
                this.b = i42 + 1;
                iArr15[i42] = 128;
                return 0;
            case 33:
                int i43 = this.b;
                int i44 = i43 - 1;
                this.b = i44;
                int[] iArr16 = this.f;
                iArr16[i43 - 2] = iArr16[i43 - 2] % iArr16[i44];
                return 0;
            case 34:
                int[] iArr17 = this.f;
                int i45 = this.b;
                this.b = i45 + 1;
                iArr17[i45] = 21;
                return 0;
            case 35:
                int i46 = this.b;
                int i47 = i46 - 1;
                this.b = i47;
                int[] iArr18 = this.f;
                iArr18[i46 - 2] = iArr18[i46 - 2] + iArr18[i47];
                this.b = i46;
                iArr18[i47] = iArr18[i46 - 2];
                return 0;
            case 36:
                int[] iArr19 = this.f;
                int i48 = this.b;
                this.b = i48 + 1;
                iArr19[i48] = 89;
                return 0;
            case 37:
                int i49 = this.b;
                int i50 = i49 - 1;
                this.b = i50;
                int[] iArr20 = this.f;
                iArr20[i49 - 2] = iArr20[i49 - 2] + iArr20[i50];
                return 0;
            case 38:
                int[] iArr21 = this.f;
                int i51 = this.b - 1;
                this.b = i51;
                this.e = iArr21[i51];
                return 0;
            case 39:
                int[] iArr22 = this.f;
                int i52 = this.b;
                this.b = i52 + 1;
                iArr22[i52] = 76;
                return 0;
            case 40:
                int[] iArr23 = this.f;
                int i53 = this.b;
                this.b = i53 + 1;
                iArr23[i53] = 71;
                return 0;
            case 41:
                int[] iArr24 = this.f;
                int i54 = this.b;
                this.b = i54 + 1;
                iArr24[i54] = 26;
                return 0;
            case 42:
                int[] iArr25 = this.f;
                int i55 = this.b;
                this.b = i55 + 1;
                iArr25[i55] = 69;
                return 0;
            case 43:
                for (int i56 = this.b - 1; i56 >= 0; i56--) {
                    this.k[i56] = null;
                }
                Object[] objArr16 = this.k;
                this.b = 1;
                objArr16[0] = this.d;
                return 0;
            case 44:
                Object[] objArr17 = this.k;
                int i57 = this.b;
                this.b = i57 + 1;
                objArr17[i57] = objArr17[8];
                return 0;
            case 45:
                Object[] objArr18 = this.k;
                int i58 = this.b;
                int i59 = i58 + 1;
                this.b = i59;
                objArr18[i58] = objArr18[5];
                int[] iArr26 = this.f;
                this.b = i58 + 2;
                iArr26[i59] = 1;
                return 0;
            case 46:
                Object[] objArr19 = this.k;
                int i60 = this.b;
                int i61 = i60 + 1;
                this.b = i61;
                objArr19[i60] = objArr19[8];
                int i62 = i60 + 2;
                this.b = i62;
                objArr19[i61] = objArr19[5];
                this.b = i60 + 3;
                objArr19[i62] = objArr19[9];
                return 0;
            case 47:
                Object[] objArr20 = this.k;
                int i63 = this.b;
                int i64 = i63 + 1;
                this.b = i64;
                objArr20[i63] = objArr20[6];
                this.b = i63 + 2;
                objArr20[i64] = objArr20[7];
                return 0;
            case 48:
                int[] iArr27 = this.f;
                int i65 = this.b;
                int i66 = i65 + 1;
                this.b = i66;
                iArr27[i65] = 2;
                this.b = i65 + 2;
                iArr27[i66] = 2;
                int i67 = i65 + 1;
                this.b = i67;
                iArr27[i65] = iArr27[i65] % iArr27[i67];
                return 0;
            case 49:
                int[] iArr28 = this.f;
                int i68 = this.b;
                int i69 = i68 + 1;
                this.b = i69;
                iArr28[i68] = 2;
                this.b = i68 + 2;
                iArr28[i69] = 2;
                return 0;
            case 50:
                int[] iArr29 = this.f;
                int i70 = this.b;
                this.b = i70 + 1;
                iArr29[i70] = 87;
                return 0;
            case 51:
                int[] iArr30 = this.f;
                int i71 = this.b;
                this.b = i71 + 1;
                iArr30[i71] = 43;
                return 0;
            case 52:
                int[] iArr31 = this.f;
                int i72 = this.b;
                int i73 = i72 + 1;
                this.b = i73;
                iArr31[i72] = 76;
                this.b = i72 + 2;
                iArr31[i73] = 0;
                int i74 = i72 + 1;
                this.b = i74;
                iArr31[i72] = iArr31[i72] / iArr31[i74];
                return 0;
            case 53:
                Object[] objArr21 = this.k;
                int i75 = this.b;
                int i76 = i75 + 1;
                this.b = i76;
                objArr21[i75] = objArr21[5];
                int i77 = i75 + 2;
                this.b = i77;
                objArr21[i76] = objArr21[i75];
                this.b = i75 + 3;
                objArr21[i77] = objArr21[6];
                return 0;
            case 54:
                int[] iArr32 = this.f;
                int i78 = this.b;
                this.b = i78 + 1;
                iArr32[i78] = 13;
                return 0;
            case 55:
                int[] iArr33 = this.f;
                int i79 = this.b;
                int i80 = i79 + 1;
                this.b = i80;
                iArr33[i79] = iArr33[i79 - 1];
                this.b = i79 + 2;
                iArr33[i80] = 128;
                int i81 = i79 + 1;
                this.b = i81;
                iArr33[i79] = iArr33[i79] % iArr33[i81];
                return 0;
            case 56:
                int[] iArr34 = this.f;
                int i82 = this.b;
                int i83 = i82 + 1;
                this.b = i83;
                iArr34[i82] = 73;
                this.b = i82 + 2;
                iArr34[i83] = 0;
                int i84 = i82 + 1;
                this.b = i84;
                iArr34[i82] = iArr34[i82] / iArr34[i84];
                return 0;
            case 57:
                int[] iArr35 = this.f;
                int i85 = this.b;
                this.b = i85 + 1;
                iArr35[i85] = 17;
                return 0;
            case 58:
                int[] iArr36 = this.f;
                int i86 = this.b;
                this.b = i86 + 1;
                iArr36[i86] = 45;
                return 0;
            case 59:
                int[] iArr37 = this.f;
                int i87 = this.b;
                this.b = i87 + 1;
                iArr37[i87] = 97;
                return 0;
            case 60:
                Object[] objArr22 = this.k;
                int i88 = this.b;
                this.b = i88 + 1;
                objArr22[i88] = objArr22[i88 - 1];
                this.b = i88;
                Object obj7 = objArr22[i88];
                objArr22[i88] = null;
                objArr22[6] = obj7;
                return 0;
            case 61:
                Object[] objArr23 = this.k;
                int i89 = this.b;
                int i90 = i89 + 1;
                this.b = i90;
                objArr23[i89] = objArr23[5];
                this.b = i89 + 2;
                objArr23[i90] = objArr23[6];
                return 0;
            case 62:
                Object[] objArr24 = this.k;
                int i91 = this.b;
                int i92 = i91 + 1;
                this.b = i92;
                objArr24[i91] = objArr24[8];
                int[] iArr38 = this.f;
                this.b = i91 + 2;
                iArr38[i92] = 1;
                return 0;
            case 63:
                Object[] objArr25 = this.k;
                int i93 = this.b;
                int i94 = i93 + 1;
                this.b = i94;
                objArr25[i93] = objArr25[5];
                this.b = i93 + 2;
                objArr25[i94] = objArr25[8];
                return 0;
            case 64:
                int[] iArr39 = this.f;
                int i95 = this.b;
                this.b = i95 + 1;
                iArr39[i95] = 35;
                return 0;
            case 65:
                int i96 = this.b;
                int i97 = i96 - 1;
                this.b = i97;
                int[] iArr40 = this.f;
                iArr40[i96 - 2] = iArr40[i96 - 2] + iArr40[i97];
                this.b = i96;
                iArr40[i97] = iArr40[i96 - 2];
                this.b = i96 + 1;
                iArr40[i96] = 128;
                return 0;
            case 66:
                int[] iArr41 = this.f;
                int i98 = this.b;
                this.b = i98 + 1;
                iArr41[i98] = 51;
                this.b = i98;
                iArr41[i98 - 1] = iArr41[i98 - 1] + iArr41[i98];
                return 0;
            case 67:
                int[] iArr42 = this.f;
                int i99 = this.b;
                int i100 = i99 + 1;
                this.b = i100;
                iArr42[i99] = 4;
                this.b = i99 + 2;
                iArr42[i100] = 0;
                return 0;
            case 68:
                int i101 = this.b;
                int i102 = i101 - 1;
                this.b = i102;
                int[] iArr43 = this.f;
                iArr43[i101 - 2] = iArr43[i101 - 2] / iArr43[i102];
                int i103 = i101 - 2;
                this.b = i103;
                this.k[i103] = null;
                return 0;
            case 69:
                int[] iArr44 = this.f;
                int i104 = this.b;
                this.b = i104 + 1;
                iArr44[i104] = 34;
                return 0;
            case 70:
                int[] iArr45 = this.f;
                int i105 = this.b;
                this.b = i105 + 1;
                iArr45[i105] = 38;
                return 0;
            case 71:
                Object[] objArr26 = this.k;
                int i106 = this.b;
                int i107 = i106 + 1;
                this.b = i107;
                objArr26[i106] = objArr26[5];
                int[] iArr46 = this.f;
                this.b = i106 + 2;
                iArr46[i107] = 0;
                return 0;
            case 72:
                int i108 = this.b;
                int i109 = i108 - 1;
                this.b = i109;
                Object[] objArr27 = this.k;
                objArr27[i109] = null;
                this.b = i108;
                objArr27[i109] = objArr27[5];
                return 0;
            case 73:
                int[] iArr47 = this.f;
                int i110 = this.b;
                this.b = i110 + 1;
                iArr47[i110] = 33;
                this.b = i110;
                iArr47[i110 - 1] = iArr47[i110 - 1] + iArr47[i110];
                this.b = i110 + 1;
                iArr47[i110] = iArr47[i110 - 1];
                return 0;
            case 74:
                int[] iArr48 = this.f;
                int i111 = this.b;
                this.b = i111 + 1;
                iArr48[i111] = 23;
                return 0;
            case 75:
                int[] iArr49 = this.f;
                int i112 = this.b;
                this.b = i112 + 1;
                iArr49[i112] = 7;
                this.b = i112;
                iArr49[i112 - 1] = iArr49[i112 - 1] + iArr49[i112];
                this.b = i112 + 1;
                iArr49[i112] = iArr49[i112 - 1];
                return 0;
            case 76:
                int[] iArr50 = this.f;
                int i113 = this.b;
                int i114 = i113 + 1;
                this.b = i114;
                iArr50[i113] = 33;
                this.b = i113 + 2;
                iArr50[i114] = 0;
                int i115 = i113 + 1;
                this.b = i115;
                iArr50[i113] = iArr50[i113] / iArr50[i115];
                return 0;
            case 77:
                int[] iArr51 = this.f;
                int i116 = this.b;
                this.b = i116 + 1;
                iArr51[i116] = 105;
                this.b = i116;
                iArr51[i116 - 1] = iArr51[i116 - 1] + iArr51[i116];
                this.b = i116 + 1;
                iArr51[i116] = iArr51[i116 - 1];
                return 0;
            case 78:
                int[] iArr52 = this.f;
                int i117 = this.b;
                this.b = i117 + 1;
                iArr52[i117] = 82;
                return 0;
            case 79:
                int[] iArr53 = this.f;
                int i118 = this.b;
                this.b = i118 + 1;
                iArr53[i118] = 55;
                return 0;
            default:
                return i;
        }
    }

    public dz(Object obj, Object obj2) {
        this.f = new int[10];
        this.i = new long[10];
        this.h = new float[10];
        this.f95878g = new double[10];
        Object[] objArr = new Object[10];
        this.k = objArr;
        objArr[5] = obj;
        objArr[6] = obj2;
        this.b = 0;
        this.j = -1;
    }

    public dz(Object obj, Object obj2, Object obj3, Object obj4) {
        this.f = new int[10];
        this.i = new long[10];
        this.h = new float[10];
        this.f95878g = new double[10];
        Object[] objArr = new Object[10];
        this.k = objArr;
        objArr[5] = obj;
        objArr[6] = obj2;
        objArr[7] = obj3;
        objArr[8] = obj4;
        this.b = 0;
        this.j = -1;
    }

    public dz(Object obj) {
        this.f = new int[10];
        this.i = new long[10];
        this.h = new float[10];
        this.f95878g = new double[10];
        Object[] objArr = new Object[10];
        this.k = objArr;
        objArr[5] = obj;
        this.b = 0;
        this.j = -1;
    }

    public dz() {
        this.f = new int[10];
        this.i = new long[10];
        this.h = new float[10];
        this.f95878g = new double[10];
        this.k = new Object[10];
        this.b = 0;
        this.j = -1;
    }
}