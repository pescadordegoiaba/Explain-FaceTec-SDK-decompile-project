package com.facetec.sdk;

import android.animation.Animator;
import android.animation.ArgbEvaluator;
import android.animation.ValueAnimator;
import android.annotation.SuppressLint;
import android.content.Context;
import android.graphics.Typeface;
import android.graphics.drawable.Drawable;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.view.View;
import androidx.annotation.NonNull;
import androidx.appcompat.widget.AppCompatButton;
import com.facetec.sdk.FaceTecSDK;
import com.facetec.sdk.pg;
import com.incode.welcome_sdk.modules.SelfieScan;
import kotlin.C6852;

/* JADX INFO: loaded from: classes4.dex */
class e extends AppCompatButton {
    boolean a;
    private int b;
    private Drawable c;
    private Typeface d;
    private int e;
    private int f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    private int f95879g;
    private int h;
    private int i;
    private int j;
    private ValueAnimator k;
    private boolean l;
    private boolean m;
    private FaceTecSDK.c n;
    private a o;
    private ValueAnimator p;
    private ValueAnimator t;

    /* JADX INFO: renamed from: com.facetec.sdk.e$4, reason: invalid class name */
    public static /* synthetic */ class AnonymousClass4 {
        static final /* synthetic */ int[] e;

        static {
            int[] iArr = new int[a.values().length];
            e = iArr;
            try {
                iArr[a.Guidance.ordinal()] = 1;
            } catch (NoSuchFieldError unused) {
            }
            try {
                e[a.IDScan.ordinal()] = 2;
            } catch (NoSuchFieldError unused2) {
            }
            try {
                e[a.OCRConfirmation.ordinal()] = 3;
            } catch (NoSuchFieldError unused3) {
            }
        }
    }

    public enum a {
        Guidance,
        IDScan,
        OCRConfirmation
    }

    public e(@NonNull Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        this.i = 200;
        this.a = false;
        this.l = false;
        this.m = false;
        this.o = a.Guidance;
        this.n = FaceTecSDK.c.NORMAL;
        this.k = new ValueAnimator();
        this.p = new ValueAnimator();
        this.t = new ValueAnimator();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void b(ValueAnimator valueAnimator) {
        this.e = ((Integer) valueAnimator.getAnimatedValue()).intValue();
        dq.c(this.c, ((Integer) valueAnimator.getAnimatedValue()).intValue());
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ boolean d(View view, MotionEvent motionEvent) {
        if (!isEnabled()) {
            return true;
        }
        if (motionEvent.getAction() == 0) {
            d(true, false);
        } else if (motionEvent.getAction() == 3 || motionEvent.getX() < SelfieScan.RECOGNITION_FAIL_RESULT || motionEvent.getX() > getWidth() || motionEvent.getY() < SelfieScan.RECOGNITION_FAIL_RESULT || motionEvent.getY() > getHeight()) {
            d(false, true);
        } else if (motionEvent.getAction() == 1) {
            performClick();
        }
        return true;
    }

    @SuppressLint({"ClickableViewAccessibility"})
    public final void a() {
        int iIntValue;
        int iAk;
        int iAg;
        if (this.m) {
            return;
        }
        bh.d(this);
        this.m = true;
        Context context = getContext();
        this.c = C6852.getDrawable(context, R.drawable.facetec_button_background);
        int i = AnonymousClass4.e[this.o.ordinal()];
        if (i == 1) {
            if (isEnabled()) {
                iIntValue = dm.Y();
            } else {
                iIntValue = ((Integer) dm.e(pg.a.a(), pg.a.a(), -1410973603, new Object[0], pg.a.a(), 1410973621, pg.a.a())).intValue();
            }
            this.e = dq.b(context, iIntValue);
            this.b = dq.b(context, isEnabled() ? dm.T() : dm.ac());
            this.j = dq.b(context, ((Integer) dm.e(pg.a.a(), pg.a.a(), -742420334, new Object[0], pg.a.a(), 742420377, pg.a.a())).intValue());
            this.h = ((Integer) dm.e(pg.a.a(), pg.a.a(), -1375711728, new Object[0], pg.a.a(), 1375711749, pg.a.a())).intValue();
            this.f95879g = dm.G();
            this.f = 20;
            this.d = FaceTecSDK.d.i.buttonFont;
        } else if (i == 2) {
            if (isEnabled()) {
                iAk = ((Integer) dm.e(pg.a.a(), pg.a.a(), -1731246276, new Object[0], pg.a.a(), 1731246302, pg.a.a())).intValue();
            } else {
                iAk = dm.ak();
            }
            this.e = dq.b(context, iAk);
            if (isEnabled()) {
                iAg = ((Integer) dm.e(pg.a.a(), pg.a.a(), -1313229122, new Object[0], pg.a.a(), 1313229135, pg.a.a())).intValue();
            } else {
                iAg = dm.ag();
            }
            this.b = dq.b(context, iAg);
            this.j = dq.b(context, dm.ai());
            this.h = dm.p();
            this.f95879g = ((Integer) dm.e(pg.a.a(), pg.a.a(), -858435705, new Object[0], pg.a.a(), 858435734, pg.a.a())).intValue();
            this.f = 20;
            this.d = FaceTecSDK.d.f.buttonFont;
        } else if (i == 3) {
            this.e = dq.b(context, isEnabled() ? dm.aq() : dm.an());
            this.b = dq.b(context, isEnabled() ? dm.am() : dm.ao());
            this.j = dq.b(context, dm.ar());
            this.h = ((Integer) dm.e(pg.a.a(), pg.a.a(), 1496912795, new Object[0], pg.a.a(), -1496912776, pg.a.a())).intValue();
            this.f95879g = dm.E();
            this.f = 20;
            this.d = FaceTecSDK.d.j.buttonFont;
        }
        setTextSize(2, this.f * dm.b() * dm.c());
        setTypeface(this.d);
        setMaxLines(1);
        d(false);
        setOnTouchListener(new View.OnTouchListener() { // from class: com.facetec.sdk.剑天
            @Override // android.view.View.OnTouchListener
            public final boolean onTouch(View view, MotionEvent motionEvent) {
                return this.f7206.d(view, motionEvent);
            }
        });
    }

    public final void c(final Runnable runnable) {
        setOnClickListener(new View.OnClickListener() { // from class: com.facetec.sdk.剑妖
            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                this.f7207.c(runnable, view);
            }
        });
    }

    public final void e() {
        this.o = a.OCRConfirmation;
        this.m = false;
        a();
    }

    @Override // android.widget.TextView, android.view.View
    public void setEnabled(boolean z) {
        super.setEnabled(z);
        d(false);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void c(Runnable runnable, View view) {
        d(false, true);
        if (runnable != null) {
            runnable.run();
        }
    }

    public final void b(boolean z, boolean z2) {
        if (isEnabled() == z) {
            if (this.a) {
                return;
            }
            d(false);
        } else {
            super.setEnabled(z);
            this.i = 200;
            d(z2);
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void e(Animator animator) {
        this.a = false;
    }

    public final void c() {
        this.o = a.IDScan;
        this.m = false;
        a();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void c(float f, ValueAnimator valueAnimator) {
        this.j = ((Integer) valueAnimator.getAnimatedValue()).intValue();
        dq.b(this.c, ((Integer) valueAnimator.getAnimatedValue()).intValue(), Math.round(bh.a(this.h) * f), bh.a(this.f95879g) * f);
        setBackground(this.c);
        postInvalidate();
    }

    private void d(boolean z) {
        int iB;
        int iB2;
        int iB3;
        int iB4;
        int iB5;
        if (this.a) {
            b();
        }
        this.a = true;
        Context context = getContext();
        final float fC = dm.c();
        int iB6 = 0;
        int i = z ? this.i : 0;
        int i2 = this.e;
        int i3 = this.j;
        int i4 = this.b;
        int i5 = AnonymousClass4.e[this.o.ordinal()];
        if (i5 == 1) {
            iB = dq.b(context, ((Integer) dm.e(pg.a.a(), pg.a.a(), -742420334, new Object[0], pg.a.a(), 742420377, pg.a.a())).intValue());
            if (!isEnabled()) {
                iB6 = dq.b(context, ((Integer) dm.e(pg.a.a(), pg.a.a(), -1410973603, new Object[0], pg.a.a(), 1410973621, pg.a.a())).intValue());
                iB2 = dq.b(context, dm.ac());
            } else if (this.l) {
                iB6 = dq.b(context, dm.aa());
                iB2 = dq.b(context, dm.Z());
            } else {
                iB6 = dq.b(context, dm.Y());
                iB2 = dq.b(context, dm.T());
            }
        } else if (i5 == 2) {
            iB = dq.b(context, dm.ai());
            if (!isEnabled()) {
                iB6 = dq.b(context, dm.ak());
                iB2 = dq.b(context, dm.ag());
            } else {
                if (this.l) {
                    iB3 = dq.b(context, dm.aj());
                    iB4 = dq.b(context, ((Integer) dm.e(pg.a.a(), pg.a.a(), -1006289847, new Object[0], pg.a.a(), 1006289864, pg.a.a())).intValue());
                } else {
                    iB3 = dq.b(context, ((Integer) dm.e(pg.a.a(), pg.a.a(), -1731246276, new Object[0], pg.a.a(), 1731246302, pg.a.a())).intValue());
                    iB4 = dq.b(context, ((Integer) dm.e(pg.a.a(), pg.a.a(), -1313229122, new Object[0], pg.a.a(), 1313229135, pg.a.a())).intValue());
                }
                iB2 = iB4;
                iB6 = iB3;
            }
        } else if (i5 != 3) {
            iB = 0;
            iB2 = 0;
        } else {
            int iB7 = dq.b(context, dm.ar());
            if (!isEnabled()) {
                iB5 = dq.b(context, dm.an());
                iB2 = dq.b(context, dm.ao());
            } else if (this.l) {
                iB5 = dq.b(context, dm.ap());
                iB2 = dq.b(context, dm.al());
            } else {
                iB5 = dq.b(context, dm.aq());
                iB2 = dq.b(context, dm.am());
            }
            iB6 = iB5;
            iB = iB7;
        }
        ValueAnimator valueAnimatorOfObject = ValueAnimator.ofObject(new ArgbEvaluator(), Integer.valueOf(i2), Integer.valueOf(iB6));
        this.k = valueAnimatorOfObject;
        long j = i;
        valueAnimatorOfObject.setDuration(j);
        this.k.addUpdateListener(new ValueAnimator.AnimatorUpdateListener() { // from class: com.facetec.sdk.剑字
            @Override // android.animation.ValueAnimator.AnimatorUpdateListener
            public final void onAnimationUpdate(ValueAnimator valueAnimator) {
                this.f7209.b(valueAnimator);
            }
        });
        this.k.start();
        ValueAnimator valueAnimatorOfObject2 = ValueAnimator.ofObject(new ArgbEvaluator(), Integer.valueOf(i3), Integer.valueOf(iB));
        this.p = valueAnimatorOfObject2;
        valueAnimatorOfObject2.setDuration(j);
        this.p.addUpdateListener(new ValueAnimator.AnimatorUpdateListener() { // from class: com.facetec.sdk.剑宫
            @Override // android.animation.ValueAnimator.AnimatorUpdateListener
            public final void onAnimationUpdate(ValueAnimator valueAnimator) {
                this.f7210.c(fC, valueAnimator);
            }
        });
        this.p.start();
        ValueAnimator valueAnimatorOfObject3 = ValueAnimator.ofObject(new ArgbEvaluator(), Integer.valueOf(i4), Integer.valueOf(iB2));
        this.t = valueAnimatorOfObject3;
        valueAnimatorOfObject3.setDuration(j);
        this.t.addUpdateListener(new ValueAnimator.AnimatorUpdateListener() { // from class: com.facetec.sdk.剑山
            @Override // android.animation.ValueAnimator.AnimatorUpdateListener
            public final void onAnimationUpdate(ValueAnimator valueAnimator) {
                this.f7212.d(valueAnimator);
            }
        });
        this.t.addListener(new f() { // from class: com.facetec.sdk.剑帝
            @Override // android.animation.Animator.AnimatorListener
            public final void onAnimationEnd(Animator animator) {
                this.f7213.e(animator);
            }
        });
        this.t.start();
    }

    private void b() {
        this.k.cancel();
        this.p.cancel();
        this.t.cancel();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void d(ValueAnimator valueAnimator) {
        this.b = ((Integer) valueAnimator.getAnimatedValue()).intValue();
        setTextColor(((Integer) valueAnimator.getAnimatedValue()).intValue());
    }

    private void d(boolean z, boolean z2) {
        if (this.l == z || !isEnabled()) {
            return;
        }
        this.l = z;
        d(z2);
    }

    public final void d() {
        FaceTecSDK.c cVar = this.n;
        FaceTecSDK.c cVar2 = FaceTecSDK.c;
        if (cVar == cVar2) {
            return;
        }
        this.n = cVar2;
        this.i = 1000;
        d(true);
    }
}