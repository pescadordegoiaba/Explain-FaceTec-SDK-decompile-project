package com.facetec.sdk;

/* JADX INFO: loaded from: classes4.dex */
public class ec {
    private int a;
    public int b;
    public Object c;
    public int d;
    public Object e;
    private final long[] f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    private final double[] f95881g;
    private int h;
    private final float[] i;
    private final int[] j;
    private final Object[] m;

    public ec(Object obj) {
        this.j = new int[11];
        this.f = new long[11];
        this.i = new float[11];
        this.f95881g = new double[11];
        Object[] objArr = new Object[11];
        this.m = objArr;
        objArr[6] = obj;
        this.a = 0;
        this.h = -1;
    }

    public int a(int i) {
        switch (i) {
            case 1:
                Object[] objArr = this.m;
                int i2 = this.a;
                this.a = i2 + 1;
                objArr[i2] = this.c;
                return 0;
            case 2:
                int i3 = this.a - this.d;
                this.a = i3;
                this.h = i3;
                return 0;
            case 3:
                Object[] objArr2 = this.m;
                int i4 = this.h;
                this.h = i4 + 1;
                Object obj = objArr2[i4];
                objArr2[i4] = null;
                this.e = obj;
                return 0;
            case 4:
                int[] iArr = this.j;
                int i5 = this.a;
                int i6 = i5 + 1;
                this.a = i6;
                iArr[i5] = 0;
                Object[] objArr3 = this.m;
                this.a = i5 + 2;
                objArr3[i6] = objArr3[6];
                return 0;
            case 5:
                int[] iArr2 = this.j;
                int i7 = this.a;
                Object[] objArr4 = this.m;
                Object obj2 = objArr4[i7 - 1];
                objArr4[i7 - 1] = null;
                iArr2[i7 - 1] = ((Object[]) obj2).length;
                return 0;
            case 6:
                int[] iArr3 = this.j;
                int i8 = this.h;
                this.h = i8 + 1;
                this.b = iArr3[i8];
                return 0;
            case 7:
                int[] iArr4 = this.j;
                int i9 = this.a;
                this.a = i9 + 1;
                iArr4[i9] = this.d;
                return 0;
            case 8:
                int i10 = this.a - 1;
                this.a = i10;
                int[] iArr5 = this.j;
                iArr5[7] = iArr5[i10];
                return 0;
            case 9:
                Object[] objArr5 = this.m;
                int i11 = this.a;
                this.a = i11 + 1;
                objArr5[i11] = objArr5[6];
                return 0;
            case 10:
                int[] iArr6 = this.j;
                int i12 = this.a;
                this.a = i12 + 1;
                iArr6[i12] = iArr6[7];
                this.a = i12;
                Object[] objArr6 = this.m;
                Object obj3 = objArr6[i12 - 1];
                objArr6[i12 - 1] = null;
                objArr6[i12 - 1] = ((Object[]) obj3)[iArr6[i12]];
                return 0;
            case 11:
                int[] iArr7 = this.j;
                int i13 = this.a;
                int i14 = i13 + 1;
                this.a = i14;
                iArr7[i13] = 2;
                this.a = i13 + 2;
                iArr7[i14] = 2;
                int i15 = i13 + 1;
                this.a = i15;
                iArr7[i13] = iArr7[i13] % iArr7[i15];
                return 0;
            case 12:
                int i16 = this.a - 1;
                this.a = i16;
                this.m[i16] = null;
                return 0;
            case 14:
                Object[] objArr7 = this.m;
                int i17 = this.a;
                Object obj4 = objArr7[i17 - 1];
                objArr7[i17 - 1] = null;
                this.e = obj4;
            case 13:
                return 0;
            case 15:
                int[] iArr8 = this.j;
                int i18 = this.a;
                this.a = i18 + 1;
                iArr8[i18] = 3;
                this.a = i18;
                iArr8[i18 - 1] = iArr8[i18 - 1] + iArr8[i18];
                return 0;
            case 16:
                int[] iArr9 = this.j;
                int i19 = this.a;
                int i20 = i19 + 1;
                this.a = i20;
                iArr9[i19] = iArr9[i19 - 1];
                this.a = i19 + 2;
                iArr9[i20] = 128;
                int i21 = i19 + 1;
                this.a = i21;
                iArr9[i19] = iArr9[i19] % iArr9[i21];
                return 0;
            case 17:
                int i22 = this.a - 1;
                this.a = i22;
                this.b = this.j[i22] == 0 ? 0 : 1;
                return 0;
            case 18:
                int[] iArr10 = this.j;
                int i23 = this.a;
                this.a = i23 + 1;
                iArr10[i23] = 2;
                this.a = i23;
                iArr10[i23 - 1] = iArr10[i23 - 1] % iArr10[i23];
                return 0;
            case 19:
                Object[] objArr8 = this.m;
                int i24 = this.a;
                this.a = i24 + 1;
                objArr8[i24] = null;
                return 0;
            case 20:
                int[] iArr11 = this.j;
                int i25 = this.a;
                this.a = i25 + 1;
                iArr11[i25] = 35;
                this.a = i25;
                iArr11[i25 - 1] = iArr11[i25 - 1] + iArr11[i25];
                return 0;
            case 21:
                int[] iArr12 = this.j;
                int i26 = this.a;
                int i27 = i26 + 1;
                this.a = i27;
                iArr12[i26] = iArr12[i26 - 1];
                this.a = i26 + 2;
                iArr12[i27] = 128;
                return 0;
            case 22:
                int i28 = this.a;
                int i29 = i28 - 1;
                this.a = i29;
                int[] iArr13 = this.j;
                iArr13[i28 - 2] = iArr13[i28 - 2] % iArr13[i29];
                return 0;
            case 23:
                int[] iArr14 = this.j;
                int i30 = this.a;
                this.a = i30 + 1;
                iArr14[i30] = 2;
                return 0;
            case 24:
                int[] iArr15 = this.j;
                int i31 = this.a;
                this.a = i31 + 1;
                iArr15[i31] = 1;
                return 0;
            case 25:
                int[] iArr16 = this.j;
                int i32 = this.a;
                this.a = i32 + 1;
                iArr16[i32] = iArr16[7];
                return 0;
            case 26:
                int i33 = this.a;
                int i34 = i33 - 1;
                this.a = i34;
                Object[] objArr9 = this.m;
                Object obj5 = objArr9[i33 - 2];
                objArr9[i33 - 2] = null;
                objArr9[i33 - 2] = ((Object[]) obj5)[this.j[i34]];
                return 0;
            case 27:
                int[] iArr17 = this.j;
                int i35 = this.a - 1;
                this.a = i35;
                this.b = iArr17[i35];
                return 0;
            case 28:
                int[] iArr18 = this.j;
                int i36 = this.a;
                this.a = i36 + 1;
                iArr18[i36] = 0;
                return 0;
            case 29:
                for (int i37 = this.a - 1; i37 >= 0; i37--) {
                    this.m[i37] = null;
                }
                Object[] objArr10 = this.m;
                this.a = 1;
                objArr10[0] = this.c;
                return 0;
            case 30:
                int i38 = this.a;
                int i39 = i38 - 2;
                this.a = i39;
                Object[] objArr11 = this.m;
                Object obj6 = objArr11[i39];
                objArr11[i39] = null;
                Object obj7 = objArr11[i38 - 1];
                objArr11[i38 - 1] = null;
                this.b = obj6 != obj7 ? 0 : 1;
                return 0;
            case 31:
                int i40 = this.a - 1;
                this.a = i40;
                Object[] objArr12 = this.m;
                Object obj8 = objArr12[i40];
                objArr12[i40] = null;
                this.b = obj8 == null ? 0 : 1;
                return 0;
            case 32:
                int i41 = this.a - 1;
                this.a = i41;
                this.b = this.j[i41] != 0 ? 0 : 1;
                return 0;
            case 33:
                Object[] objArr13 = this.m;
                int i42 = this.a;
                int i43 = i42 + 1;
                this.a = i43;
                objArr13[i42] = objArr13[6];
                this.a = i42 + 2;
                objArr13[i43] = objArr13[i42];
                return 0;
            case 34:
                this.b = this.j[this.a - 1];
                return 0;
            case 35:
                int[] iArr19 = this.j;
                int i44 = this.a;
                this.a = i44 + 1;
                iArr19[i44] = iArr19[i44 - 1];
                this.a = i44;
                iArr19[9] = iArr19[i44];
                return 0;
            case 36:
                int i45 = this.a - 1;
                this.a = i45;
                int[] iArr20 = this.j;
                iArr20[10] = iArr20[i45];
                return 0;
            case 37:
                int[] iArr21 = this.j;
                int i46 = this.a;
                this.a = i46 + 1;
                iArr21[i46] = iArr21[9];
                return 0;
            case 38:
                int[] iArr22 = this.j;
                int i47 = this.a;
                this.a = i47 + 1;
                iArr22[i47] = iArr22[10];
                return 0;
            case 39:
                Object[] objArr14 = this.m;
                int i48 = this.a;
                int i49 = i48 + 1;
                this.a = i49;
                objArr14[i48] = objArr14[6];
                int[] iArr23 = this.j;
                this.a = i48 + 2;
                iArr23[i49] = iArr23[9];
                return 0;
            case 40:
                Object[] objArr15 = this.m;
                int i50 = this.a;
                this.a = i50 + 1;
                objArr15[i50] = objArr15[i50 - 1];
                return 0;
            case 41:
                int[] iArr24 = this.j;
                int i51 = this.a;
                this.a = i51 + 1;
                iArr24[i51] = 1;
                this.a = i51;
                iArr24[i51 - 1] = iArr24[i51 - 1] + iArr24[i51];
                return 0;
            case 42:
                Object[] objArr16 = this.m;
                int i52 = this.a;
                int i53 = i52 + 1;
                this.a = i53;
                objArr16[i52] = objArr16[6];
                int[] iArr25 = this.j;
                this.a = i52 + 2;
                iArr25[i53] = 0;
                return 0;
            case 43:
                int i54 = this.a;
                int i55 = i54 - 1;
                this.a = i55;
                Object[] objArr17 = this.m;
                Object obj9 = objArr17[i55];
                objArr17[i55] = null;
                objArr17[9] = obj9;
                this.a = i54;
                objArr17[i55] = objArr17[6];
                return 0;
            case 44:
                int i56 = this.a;
                int i57 = i56 - 1;
                this.a = i57;
                int[] iArr26 = this.j;
                Object[] objArr18 = this.m;
                Object obj10 = objArr18[i56 - 2];
                objArr18[i56 - 2] = null;
                iArr26[i56 - 2] = ((int[]) obj10)[iArr26[i57]];
                return 0;
            case 45:
                int[] iArr27 = this.j;
                int i58 = this.a;
                this.a = i58 + 1;
                iArr27[i58] = iArr27[8];
                return 0;
            case 46:
                int i59 = this.a;
                int i60 = i59 - 1;
                this.a = i60;
                Object[] objArr19 = this.m;
                objArr19[i60] = null;
                this.a = i59;
                objArr19[i60] = objArr19[6];
                return 0;
            case 47:
                Object[] objArr20 = this.m;
                int i61 = this.a;
                int i62 = i61 + 1;
                this.a = i62;
                objArr20[i61] = objArr20[6];
                this.a = i61 + 2;
                objArr20[i62] = objArr20[7];
                return 0;
            case 48:
                Object[] objArr21 = this.m;
                int i63 = this.a;
                this.a = i63 + 1;
                objArr21[i63] = objArr21[7];
                return 0;
            case 49:
                Object[] objArr22 = this.m;
                int i64 = this.a;
                int i65 = i64 + 1;
                this.a = i65;
                objArr22[i64] = objArr22[9];
                this.a = i64 + 2;
                objArr22[i65] = null;
                return 0;
            case 50:
                int i66 = this.a;
                int i67 = i66 - 1;
                this.a = i67;
                int[] iArr28 = this.j;
                iArr28[i66 - 2] = iArr28[i66 - 2] % iArr28[i67];
                int i68 = i66 - 2;
                this.a = i68;
                this.m[i68] = null;
                return 0;
            case 51:
                int[] iArr29 = this.j;
                int i69 = this.a;
                this.a = i69 + 1;
                iArr29[i69] = 13;
                return 0;
            case 52:
                int i70 = this.a;
                int i71 = i70 - 1;
                this.a = i71;
                int[] iArr30 = this.j;
                iArr30[i70 - 2] = iArr30[i70 - 2] + iArr30[i71];
                return 0;
            case 53:
                int[] iArr31 = this.j;
                int i72 = this.a;
                this.a = i72 + 1;
                iArr31[i72] = 25;
                this.a = i72;
                iArr31[i72 - 1] = iArr31[i72 - 1] + iArr31[i72];
                return 0;
            case 54:
                int[] iArr32 = this.j;
                int i73 = this.a;
                int i74 = i73 + 1;
                this.a = i74;
                iArr32[i73] = 2;
                this.a = i73 + 2;
                iArr32[i74] = 5;
                return 0;
            case 55:
                int i75 = this.a;
                int i76 = i75 - 1;
                this.a = i76;
                int[] iArr33 = this.j;
                iArr33[i75 - 2] = iArr33[i75 - 2] / iArr33[i76];
                int i77 = i75 - 2;
                this.a = i77;
                this.m[i77] = null;
                return 0;
            case 56:
                int[] iArr34 = this.j;
                int i78 = this.a;
                this.a = i78 + 1;
                iArr34[i78] = 69;
                return 0;
            case 57:
                Object[] objArr23 = this.m;
                int i79 = this.a;
                this.a = i79 + 1;
                objArr23[i79] = null;
                int[] iArr35 = this.j;
                Object obj11 = objArr23[i79];
                objArr23[i79] = null;
                iArr35[i79] = ((int[]) obj11).length;
                this.a = i79;
                objArr23[i79] = null;
                return 0;
            case 58:
                int[] iArr36 = this.j;
                int i80 = this.a;
                this.a = i80 + 1;
                iArr36[i80] = 53;
                return 0;
            case 59:
                int i81 = this.a;
                int i82 = i81 - 1;
                this.a = i82;
                int[] iArr37 = this.j;
                iArr37[i81 - 2] = iArr37[i81 - 2] + iArr37[i82];
                this.a = i81;
                iArr37[i82] = iArr37[i81 - 2];
                this.a = i81 + 1;
                iArr37[i81] = 128;
                return 0;
            case 60:
                int[] iArr38 = this.j;
                int i83 = this.a;
                this.a = i83 + 1;
                iArr38[i83] = 3;
                this.a = i83;
                iArr38[i83 - 1] = iArr38[i83 - 1] - iArr38[i83];
                int i84 = i83 - 1;
                this.a = i84;
                this.m[i84] = null;
                return 0;
            case 61:
                int[] iArr39 = this.j;
                int i85 = this.a;
                this.a = i85 + 1;
                iArr39[i85] = 76;
                return 0;
            case 62:
                int[] iArr40 = this.j;
                int i86 = this.a;
                this.a = i86 + 1;
                iArr40[i86] = 47;
                return 0;
            case 63:
                int[] iArr41 = this.j;
                int i87 = this.a;
                this.a = i87 + 1;
                iArr41[i87] = 49;
                return 0;
            case 64:
                int[] iArr42 = this.j;
                int i88 = this.a;
                this.a = i88 + 1;
                iArr42[i88] = 58;
                return 0;
            case 65:
                int[] iArr43 = this.j;
                int i89 = this.a;
                this.a = i89 + 1;
                iArr43[i89] = 26;
                return 0;
            case 66:
                int[] iArr44 = this.j;
                int i90 = this.a;
                this.a = i90 + 1;
                iArr44[i90] = 36;
                return 0;
            case 67:
                int[] iArr45 = this.j;
                int i91 = this.a;
                this.a = i91 + 1;
                iArr45[i91] = 78;
                return 0;
            case 68:
                int[] iArr46 = this.j;
                int i92 = this.a;
                this.a = i92 + 1;
                iArr46[i92] = 9;
                return 0;
            case 69:
                int[] iArr47 = this.j;
                int i93 = this.a;
                this.a = i93 + 1;
                iArr47[i93] = 46;
                return 0;
            case 70:
                int[] iArr48 = this.j;
                int i94 = this.a;
                this.a = i94 + 1;
                iArr48[i94] = 33;
                return 0;
            default:
                return i;
        }
    }

    public ec(Object obj, Object obj2, int i) {
        int[] iArr = new int[11];
        this.j = iArr;
        this.f = new long[11];
        this.i = new float[11];
        this.f95881g = new double[11];
        Object[] objArr = new Object[11];
        this.m = objArr;
        objArr[6] = obj;
        objArr[7] = obj2;
        iArr[8] = i;
        this.a = 0;
        this.h = -1;
    }
}