package com.facetec.sdk;

import android.accessibilityservice.AccessibilityServiceInfo;
import android.content.Context;
import android.content.SharedPreferences;
import android.media.MediaPlayer;
import android.os.Handler;
import android.speech.tts.TextToSpeech;
import android.util.Log;
import android.view.MotionEvent;
import android.view.View;
import android.view.accessibility.AccessibilityManager;
import com.facetec.sdk.FaceTecVocalGuidanceCustomization;
import com.facetec.sdk.bi;
import java.util.Iterator;

/* JADX INFO: loaded from: classes4.dex */
final class ed {
    private static Object a = new Object();
    static SharedPreferences b = null;
    private static MediaPlayer c = null;
    private static Handler d = null;
    static boolean e = false;
    private static MediaPlayer f = null;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    private static MediaPlayer f95882g = null;
    private static MediaPlayer h = null;
    private static MediaPlayer i = null;
    private static MediaPlayer j = null;
    private static boolean k = false;
    private static boolean l = false;
    private static TextToSpeech m = null;
    private static boolean n = false;
    private static int o = 0;
    private static String t = "";

    /* JADX INFO: renamed from: com.facetec.sdk.ed$5, reason: invalid class name */
    public static /* synthetic */ class AnonymousClass5 {
        static final /* synthetic */ int[] d;

        static {
            int[] iArr = new int[d.values().length];
            d = iArr;
            try {
                iArr[d.GET_READY_PRESS_BUTTON_TAPPING.ordinal()] = 1;
            } catch (NoSuchFieldError unused) {
            }
            try {
                d[d.GET_READY_PRESS_BUTTON_DELAYED.ordinal()] = 2;
            } catch (NoSuchFieldError unused2) {
            }
            try {
                d[d.RETRY_PRESS_BUTTON_TAPPING.ordinal()] = 3;
            } catch (NoSuchFieldError unused3) {
            }
            try {
                d[d.GET_READY_FRAME_YOUR_FACE_TAPPING.ordinal()] = 4;
            } catch (NoSuchFieldError unused4) {
            }
            try {
                d[d.GET_READY_FRAME_YOUR_FACE_AUTOMATIC.ordinal()] = 5;
            } catch (NoSuchFieldError unused5) {
            }
            try {
                d[d.FACE_CAPTURE_UNZOOMED_FRAME_YOUR_FACE_TAPPING.ordinal()] = 6;
            } catch (NoSuchFieldError unused6) {
            }
            try {
                d[d.FACE_CAPTURE_FRAME_YOUR_FACE_DELAYED.ordinal()] = 7;
            } catch (NoSuchFieldError unused7) {
            }
            try {
                d[d.FACE_CAPTURE_ZOOMED_PLEASE_FRAME_YOUR_FACE_TAPPING.ordinal()] = 8;
            } catch (NoSuchFieldError unused8) {
            }
            try {
                d[d.FACE_CAPTURE_ZOOMED_MOVE_CLOSER_TAPPING.ordinal()] = 9;
            } catch (NoSuchFieldError unused9) {
            }
            try {
                d[d.FACE_CAPTURE_MOVE_CLOSER_AUTOMATIC.ordinal()] = 10;
            } catch (NoSuchFieldError unused10) {
            }
            try {
                d[d.FACE_CAPTURE_MOVE_CLOSER_DELAYED.ordinal()] = 11;
            } catch (NoSuchFieldError unused11) {
            }
            try {
                d[d.SUCCESS.ordinal()] = 12;
            } catch (NoSuchFieldError unused12) {
            }
            try {
                d[d.UPLOADING.ordinal()] = 13;
            } catch (NoSuchFieldError unused13) {
            }
            try {
                d[d.RETRY.ordinal()] = 14;
            } catch (NoSuchFieldError unused14) {
            }
            try {
                d[d.BLIND_USER_ASSIST_TAP_PROMPT.ordinal()] = 15;
            } catch (NoSuchFieldError unused15) {
            }
            try {
                d[d.BLIND_USER_ASSIST_FACESCAN_FEEDBACK.ordinal()] = 16;
            } catch (NoSuchFieldError unused16) {
            }
        }
    }

    public enum d {
        GET_READY_PRESS_BUTTON_TAPPING("GET_READY_PRESS_BUTTON_TAPPING"),
        GET_READY_FRAME_YOUR_FACE_TAPPING("GET_READY_FRAME_YOUR_FACE_TAPPING"),
        GET_READY_PRESS_BUTTON_DELAYED("GET_READY_PRESS_BUTTON_DELAYED"),
        GET_READY_FRAME_YOUR_FACE_AUTOMATIC("GET_READY_FRAME_YOUR_FACE_AUTOMATIC"),
        RETRY_PRESS_BUTTON_TAPPING("RETRY_PRESS_BUTTON_TAPPING"),
        FACE_CAPTURE_UNZOOMED_FRAME_YOUR_FACE_TAPPING("FACE_CAPTURE_UNZOOMED_FRAME_YOUR_FACE_TAPPING"),
        FACE_CAPTURE_FRAME_YOUR_FACE_DELAYED("FACE_CAPTURE_FRAME_YOUR_FACE_DELAYED"),
        FACE_CAPTURE_ZOOMED_MOVE_CLOSER_TAPPING("FACE_CAPTURE_ZOOMED_MOVE_CLOSER_TAPPING"),
        FACE_CAPTURE_ZOOMED_PLEASE_FRAME_YOUR_FACE_TAPPING("FACE_CAPTURE_ZOOMED_PLEASE_FRAME_YOUR_FACE_TAPPING"),
        FACE_CAPTURE_MOVE_CLOSER_AUTOMATIC("FACE_CAPTURE_MOVE_CLOSER_AUTOMATIC"),
        FACE_CAPTURE_MOVE_CLOSER_DELAYED("FACE_CAPTURE_MOVE_CLOSER_DELAYED"),
        BLIND_USER_ASSIST_TAP_PROMPT("BLIND_USER_ASSIST_TAP_PROMPT"),
        BLIND_USER_ASSIST_FACESCAN_FEEDBACK("BLIND_USER_ASSIST_FACESCAN_FEEDBACK"),
        SUCCESS("SUCCESS"),
        UPLOADING("UPLOADING"),
        RETRY("RETRY");

        final String s;

        d(String str) {
            this.s = str;
        }
    }

    private static synchronized void a(Context context) {
        try {
            AccessibilityManager accessibilityManager = (AccessibilityManager) context.getApplicationContext().getSystemService("accessibility");
            if (accessibilityManager != null && accessibilityManager.isEnabled()) {
                Iterator<AccessibilityServiceInfo> it = accessibilityManager.getEnabledAccessibilityServiceList(1).iterator();
                while (it.hasNext()) {
                    if (it.next().getId().contains("TalkBackService")) {
                        n = true;
                    }
                }
            }
            if (n) {
                cv.P();
                if (m == null) {
                    m = new TextToSpeech(context, new TextToSpeech.OnInitListener() { // from class: com.facetec.sdk.剑战
                        @Override // android.speech.tts.TextToSpeech.OnInitListener
                        public final void onInit(int i2) {
                            ed.e(i2);
                        }
                    });
                }
            }
        } catch (Throwable th) {
            throw th;
        }
    }

    public static boolean b() {
        return n;
    }

    public static void c() {
        MediaPlayer mediaPlayer = c;
        if (mediaPlayer != null) {
            mediaPlayer.release();
            c = null;
        }
        MediaPlayer mediaPlayer2 = i;
        if (mediaPlayer2 != null) {
            mediaPlayer2.release();
            i = null;
        }
        MediaPlayer mediaPlayer3 = f;
        if (mediaPlayer3 != null) {
            mediaPlayer3.release();
            f = null;
        }
        MediaPlayer mediaPlayer4 = f95882g;
        if (mediaPlayer4 != null) {
            mediaPlayer4.release();
            f95882g = null;
        }
        MediaPlayer mediaPlayer5 = h;
        if (mediaPlayer5 != null) {
            mediaPlayer5.release();
            h = null;
        }
        MediaPlayer mediaPlayer6 = j;
        if (mediaPlayer6 != null) {
            mediaPlayer6.release();
            j = null;
        }
        if (b != null) {
            j = null;
        }
    }

    public static void d() {
        cv.N("acced", k);
        cv.I("accen", t);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static /* synthetic */ void e(int i2) {
    }

    private static boolean f() {
        return c == null || i == null || f == null || h == null || j == null || f95882g == null;
    }

    public static void j() {
        synchronized (a) {
            try {
                Handler handler = d;
                if (handler != null) {
                    handler.removeCallbacksAndMessages(null);
                    d = null;
                }
            } catch (Throwable th) {
                throw th;
            }
        }
    }

    public static void b(int i2) {
        o = i2;
    }

    public static void e(String str) {
        if (k || !l) {
            return;
        }
        k = true;
        t = str;
        d();
    }

    public static void b(Context context) {
        Context applicationContext = context.getApplicationContext();
        FaceTecVocalGuidanceCustomization faceTecVocalGuidanceCustomization = FaceTecSDK.d.vocalGuidanceCustomization;
        a(applicationContext);
        c = e(applicationContext, faceTecVocalGuidanceCustomization.pleaseFrameYourFaceInTheOvalSoundFile);
        i = e(applicationContext, faceTecVocalGuidanceCustomization.pleaseMoveCloserSoundFile);
        f = e(applicationContext, faceTecVocalGuidanceCustomization.pleaseRetrySoundFile);
        h = e(applicationContext, faceTecVocalGuidanceCustomization.uploadingSoundFile);
        j = e(applicationContext, faceTecVocalGuidanceCustomization.facescanSuccessfulSoundFile);
        f95882g = e(applicationContext, faceTecVocalGuidanceCustomization.pleasePressTheButtonToStartSoundFile);
        if (f()) {
            Log.i("FaceTecSDK", "WARNING: Vocal Guidance files were not provided.\nThese files can be set using FaceTecVocalGuidanceCustomization.\nDocumentation: https://dev.facetec.com/ui-customization#vocal-guidance\n");
            FaceTecSDK.d.vocalGuidanceCustomization.mode = FaceTecVocalGuidanceCustomization.VocalGuidanceMode.NO_VOCAL_GUIDANCE;
        }
        SharedPreferences sharedPreferencesJ = bk.j(applicationContext);
        b = sharedPreferencesJ;
        e = sharedPreferencesJ.getBoolean("facetecMoveCloserSoundHasBeenPlayed", false);
        l = true;
    }

    public static void d(Context context, d dVar) {
        if (n || !(ah.c || f() || c.isPlaying() || i.isPlaying() || f.isPlaying() || h.isPlaying() || j.isPlaying() || f95882g.isPlaying() || FaceTecSDK.d.vocalGuidanceCustomization.mode == FaceTecVocalGuidanceCustomization.VocalGuidanceMode.NO_VOCAL_GUIDANCE)) {
            switch (AnonymousClass5.d[dVar.ordinal()]) {
                case 1:
                case 2:
                case 3:
                    b(context, f95882g);
                    break;
                case 4:
                case 5:
                case 6:
                case 7:
                case 8:
                    b(context, c);
                    break;
                case 9:
                case 10:
                case 11:
                    b(context, i);
                    break;
                case 12:
                    b(context, j);
                    break;
                case 13:
                    b(context, h);
                    break;
                case 14:
                    b(context, f);
                    break;
                case 15:
                    a(context, context.getString(R.string.FaceTec_accessibility_tap_guidance));
                    break;
                case 16:
                    a(context, context.getString(o));
                    break;
            }
            t.d(context, dVar);
        }
    }

    public static void e() {
        TextToSpeech textToSpeech = m;
        if (textToSpeech == null || !textToSpeech.isSpeaking()) {
            return;
        }
        m.stop();
    }

    private static MediaPlayer e(Context context, int i2) {
        if (i2 == -1) {
            return null;
        }
        return MediaPlayer.create(context, i2);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static /* synthetic */ void e(Context context) {
        if (cv.i() == cu.ZOOM_FAR) {
            d(context, d.FACE_CAPTURE_FRAME_YOUR_FACE_DELAYED);
        }
    }

    public static void a() {
        TextToSpeech textToSpeech = m;
        if (textToSpeech != null) {
            textToSpeech.shutdown();
            m = null;
        }
    }

    public static void a(Context context, String str) {
        try {
            TextToSpeech textToSpeech = m;
            if (textToSpeech != null) {
                textToSpeech.speak(str, 0, null);
            }
        } catch (Throwable th) {
            t.d(context, c.VG_PLAY_SOUND_ERROR, th.getMessage(), th);
        }
    }

    private static void b(Context context, MediaPlayer mediaPlayer) {
        if (b()) {
            return;
        }
        try {
            mediaPlayer.start();
        } catch (Throwable th) {
            t.d(context, c.VG_PLAY_SOUND_ERROR, th.getMessage(), th);
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static /* synthetic */ boolean b(bi biVar, Context context, View view, MotionEvent motionEvent) {
        if (motionEvent.getAction() == 1) {
            if (biVar.getFragmentManager().findFragmentByTag("PreEnroll") != null) {
                e eVar = ((bg) biVar.getFragmentManager().findFragmentByTag("PreEnroll")).a;
                if (eVar == null || by.k) {
                    return true;
                }
                if (eVar.isEnabled()) {
                    d(context, d.GET_READY_PRESS_BUTTON_TAPPING);
                } else {
                    d(context, d.FACE_CAPTURE_UNZOOMED_FRAME_YOUR_FACE_TAPPING);
                }
            } else if (biVar.getFragmentManager().findFragmentByTag("RetryFaceScan") != null) {
                bg bgVar = (bg) biVar.getFragmentManager().findFragmentByTag("RetryFaceScan");
                e eVar2 = bgVar.a;
                if (eVar2 == null || dd.n) {
                    return true;
                }
                if (eVar2.isEnabled()) {
                    d(context, d.GET_READY_PRESS_BUTTON_TAPPING);
                } else if (((dd) bgVar).k == 1) {
                    d(context, d.FACE_CAPTURE_UNZOOMED_FRAME_YOUR_FACE_TAPPING);
                }
            } else if (biVar.getFragmentManager().findFragmentByTag("FaceScan") != null) {
                if (biVar.H != bi.e.FACESCAN_SESSION_STARTED) {
                    if (((bd) biVar.getFragmentManager().findFragmentByTag("FaceScan")).d == cs.FRAME_YOUR_FACE) {
                        d(context, d.FACE_CAPTURE_ZOOMED_PLEASE_FRAME_YOUR_FACE_TAPPING);
                    }
                } else if (cv.i() == cu.ZOOM_CLOSE) {
                    if (cv.q() == cm.MOVE_FACE_CLOSER) {
                        d(context, d.FACE_CAPTURE_ZOOMED_MOVE_CLOSER_TAPPING);
                    } else if (cv.q() != cm.HOLD_STEADY) {
                        d(context, d.FACE_CAPTURE_ZOOMED_PLEASE_FRAME_YOUR_FACE_TAPPING);
                    }
                } else if (cv.i() == cu.ZOOM_FAR && cv.q() != cm.HOLD_STEADY) {
                    d(context, d.FACE_CAPTURE_UNZOOMED_FRAME_YOUR_FACE_TAPPING);
                }
            }
        }
        return true;
    }

    public static void c(final bi biVar) {
        if (FaceTecSDK.d.vocalGuidanceCustomization.mode != FaceTecVocalGuidanceCustomization.VocalGuidanceMode.NO_VOCAL_GUIDANCE) {
            biVar.N.setOnTouchListener(new View.OnTouchListener() { // from class: com.facetec.sdk.剑弓
                @Override // android.view.View.OnTouchListener
                public final boolean onTouch(View view, MotionEvent motionEvent) {
                    return ed.b(biVar, biVar, view, motionEvent);
                }
            });
        }
    }

    public static void d(final Context context) {
        d = new Handler();
        Runnable runnable = new Runnable() { // from class: com.facetec.sdk.剑庙
            @Override // java.lang.Runnable
            public final void run() {
                ed.e(context);
            }
        };
        if (FaceTecSDK.d.vocalGuidanceCustomization.mode == FaceTecVocalGuidanceCustomization.VocalGuidanceMode.FULL_VOCAL_GUIDANCE) {
            d.postDelayed(runnable, 4500L);
        } else if (FaceTecSDK.d.vocalGuidanceCustomization.mode == FaceTecVocalGuidanceCustomization.VocalGuidanceMode.MINIMAL_VOCAL_GUIDANCE) {
            d.postDelayed(runnable, 15000L);
        }
    }
}