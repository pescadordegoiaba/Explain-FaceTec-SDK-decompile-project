package com.facetec.sdk;

/* JADX INFO: loaded from: classes4.dex */
public class ee {
    public long a;
    public Object b;
    public Object c;
    public int d;
    public int e;
    private final int[] f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    private final float[] f95884g;
    private final long[] h;
    private int i;
    private int j;
    private final double[] m;
    private final Object[] o;

    public ee(long j, Object obj, Object obj2) {
        this.f = new int[10];
        long[] jArr = new long[10];
        this.h = jArr;
        this.f95884g = new float[10];
        this.m = new double[10];
        Object[] objArr = new Object[10];
        this.o = objArr;
        jArr[4] = j;
        objArr[6] = obj;
        objArr[7] = obj2;
        this.i = 0;
        this.j = -1;
    }

    public int e(int i) {
        switch (i) {
            case 1:
                long[] jArr = this.h;
                int i2 = this.i;
                this.i = i2 + 1;
                jArr[i2] = jArr[4];
                return 0;
            case 2:
                Object[] objArr = this.o;
                int i3 = this.i;
                this.i = i3 + 1;
                objArr[i3] = objArr[6];
                return 0;
            case 3:
                int i4 = this.i - this.e;
                this.i = i4;
                this.j = i4;
                return 0;
            case 4:
                long[] jArr2 = this.h;
                int i5 = this.j;
                this.j = i5 + 1;
                this.a = jArr2[i5];
                return 0;
            case 5:
                Object[] objArr2 = this.o;
                int i6 = this.j;
                this.j = i6 + 1;
                Object obj = objArr2[i6];
                objArr2[i6] = null;
                this.b = obj;
                return 0;
            case 6:
                Object[] objArr3 = this.o;
                int i7 = this.i;
                this.i = i7 + 1;
                objArr3[i7] = objArr3[7];
                return 0;
            case 7:
                int[] iArr = this.f;
                int i8 = this.i;
                int i9 = i8 + 1;
                this.i = i9;
                iArr[i8] = 2;
                this.i = i8 + 2;
                iArr[i9] = 2;
                int i10 = i8 + 1;
                this.i = i10;
                iArr[i8] = iArr[i8] % iArr[i10];
                return 0;
            case 8:
                int i11 = this.i - 1;
                this.i = i11;
                this.o[i11] = null;
                return 0;
            case 10:
                int[] iArr2 = this.f;
                int i12 = this.i;
                this.i = i12 + 1;
                iArr2[i12] = this.e;
            case 9:
                return 0;
            case 11:
                int[] iArr3 = this.f;
                int i13 = this.i;
                this.i = i13 + 1;
                iArr3[i13] = 53;
                return 0;
            case 12:
                int i14 = this.i;
                int i15 = i14 - 1;
                this.i = i15;
                int[] iArr4 = this.f;
                iArr4[i14 - 2] = iArr4[i14 - 2] + iArr4[i15];
                return 0;
            case 13:
                int[] iArr5 = this.f;
                int i16 = this.i;
                this.i = i16 + 1;
                iArr5[i16] = iArr5[i16 - 1];
                return 0;
            case 14:
                int[] iArr6 = this.f;
                int i17 = this.j;
                this.j = i17 + 1;
                this.d = iArr6[i17];
                return 0;
            case 15:
                int[] iArr7 = this.f;
                int i18 = this.i;
                this.i = i18 + 1;
                iArr7[i18] = 128;
                this.i = i18;
                iArr7[i18 - 1] = iArr7[i18 - 1] % iArr7[i18];
                return 0;
            case 16:
                int[] iArr8 = this.f;
                int i19 = this.i;
                this.i = i19 + 1;
                iArr8[i19] = 2;
                this.i = i19;
                iArr8[i19 - 1] = iArr8[i19 - 1] % iArr8[i19];
                return 0;
            case 17:
                int i20 = this.i - 1;
                this.i = i20;
                this.d = this.f[i20] == 0 ? 0 : 1;
                return 0;
            case 18:
                Object[] objArr4 = this.o;
                int i21 = this.i;
                Object obj2 = objArr4[i21 - 1];
                objArr4[i21 - 1] = null;
                this.b = obj2;
                return 0;
            case 19:
                int[] iArr9 = this.f;
                int i22 = this.i;
                int i23 = i22 + 1;
                this.i = i23;
                iArr9[i22] = 67;
                this.i = i22 + 2;
                iArr9[i23] = 0;
                return 0;
            case 20:
                int i24 = this.i;
                int i25 = i24 - 1;
                this.i = i25;
                int[] iArr10 = this.f;
                iArr10[i24 - 2] = iArr10[i24 - 2] / iArr10[i25];
                return 0;
            case 21:
                int[] iArr11 = this.f;
                int i26 = this.i;
                this.i = i26 + 1;
                iArr11[i26] = 91;
                return 0;
            case 22:
                int i27 = this.i;
                int i28 = i27 - 1;
                this.i = i28;
                int[] iArr12 = this.f;
                iArr12[i27 - 2] = iArr12[i27 - 2] + iArr12[i28];
                this.i = i27;
                iArr12[i28] = iArr12[i27 - 2];
                this.i = i27 + 1;
                iArr12[i27] = 128;
                return 0;
            case 23:
                int i29 = this.i;
                int i30 = i29 - 1;
                this.i = i30;
                int[] iArr13 = this.f;
                iArr13[i29 - 2] = iArr13[i29 - 2] % iArr13[i30];
                return 0;
            case 24:
                int[] iArr14 = this.f;
                int i31 = this.i;
                this.i = i31 + 1;
                iArr14[i31] = 2;
                return 0;
            case 25:
                int i32 = this.i - 1;
                this.i = i32;
                this.d = this.f[i32] != 0 ? 0 : 1;
                return 0;
            case 26:
                int[] iArr15 = this.f;
                int i33 = this.i - 1;
                this.i = i33;
                this.d = iArr15[i33];
                return 0;
            case 27:
                int[] iArr16 = this.f;
                int i34 = this.i;
                this.i = i34 + 1;
                iArr16[i34] = 57;
                return 0;
            case 28:
                int[] iArr17 = this.f;
                int i35 = this.i;
                this.i = i35 + 1;
                iArr17[i35] = 38;
                return 0;
            case 29:
                for (int i36 = this.i - 1; i36 >= 0; i36--) {
                    this.o[i36] = null;
                }
                Object[] objArr5 = this.o;
                this.i = 1;
                objArr5[0] = this.c;
                return 0;
            case 30:
                Object[] objArr6 = this.o;
                int i37 = this.i;
                this.i = i37 + 1;
                objArr6[i37] = objArr6[4];
                return 0;
            case 31:
                Object[] objArr7 = this.o;
                int i38 = this.i;
                this.i = i38 + 1;
                objArr7[i38] = objArr7[5];
                return 0;
            case 32:
                int[] iArr18 = this.f;
                int i39 = this.i;
                this.i = i39 + 1;
                iArr18[i39] = 39;
                this.i = i39;
                iArr18[i39 - 1] = iArr18[i39 - 1] + iArr18[i39];
                this.i = i39 + 1;
                iArr18[i39] = iArr18[i39 - 1];
                return 0;
            case 33:
                int[] iArr19 = this.f;
                int i40 = this.i;
                this.i = i40 + 1;
                iArr19[i40] = 128;
                return 0;
            case 34:
                int[] iArr20 = this.f;
                int i41 = this.i;
                this.i = i41 + 1;
                iArr20[i41] = 61;
                return 0;
            case 35:
                int[] iArr21 = this.f;
                int i42 = this.i;
                this.i = i42 + 1;
                iArr21[i42] = 0;
                this.i = i42;
                iArr21[i42 - 1] = iArr21[i42 - 1] / iArr21[i42];
                return 0;
            case 36:
                int[] iArr22 = this.f;
                int i43 = this.i;
                this.i = i43 + 1;
                iArr22[i43] = 45;
                return 0;
            case 37:
                int[] iArr23 = this.f;
                int i44 = this.i;
                int i45 = i44 + 1;
                this.i = i45;
                iArr23[i44] = iArr23[i44 - 1];
                this.i = i44 + 2;
                iArr23[i45] = 128;
                return 0;
            case 38:
                Object[] objArr8 = this.o;
                int i46 = this.i;
                int i47 = i46 + 1;
                this.i = i47;
                objArr8[i46] = objArr8[4];
                this.i = i46 + 2;
                objArr8[i47] = objArr8[5];
                return 0;
            case 39:
                Object[] objArr9 = this.o;
                int i48 = this.i;
                this.i = i48 + 1;
                objArr9[i48] = null;
                return 0;
            case 40:
                int[] iArr24 = this.f;
                int i49 = this.i;
                this.i = i49 + 1;
                iArr24[i49] = 16;
                return 0;
            case 41:
                int[] iArr25 = this.f;
                int i50 = this.i;
                this.i = i50 + 1;
                iArr25[i50] = 27;
                return 0;
            case 42:
                int[] iArr26 = this.f;
                int i51 = this.i;
                this.i = i51 + 1;
                iArr26[i51] = 18;
                return 0;
            case 43:
                int[] iArr27 = this.f;
                int i52 = this.i;
                this.i = i52 + 1;
                iArr27[i52] = 5;
                return 0;
            case 44:
                Object[] objArr10 = this.o;
                int i53 = this.i;
                this.i = i53 + 1;
                objArr10[i53] = this.c;
                return 0;
            case 45:
                int i54 = this.i - 1;
                this.i = i54;
                Object[] objArr11 = this.o;
                Object obj3 = objArr11[i54];
                objArr11[i54] = null;
                objArr11[7] = obj3;
                return 0;
            case 46:
                long[] jArr3 = this.h;
                int i55 = this.i;
                int i56 = i55 + 1;
                this.i = i56;
                jArr3[i55] = jArr3[4];
                Object[] objArr12 = this.o;
                this.i = i55 + 2;
                objArr12[i56] = objArr12[6];
                return 0;
            case 47:
                int[] iArr28 = this.f;
                int i57 = this.i;
                this.i = i57 + 1;
                iArr28[i57] = 23;
                this.i = i57;
                iArr28[i57 - 1] = iArr28[i57 - 1] + iArr28[i57];
                return 0;
            case 48:
                int[] iArr29 = this.f;
                int i58 = this.i;
                this.i = i58 + 1;
                iArr29[i58] = 31;
                this.i = i58;
                iArr29[i58 - 1] = iArr29[i58 - 1] + iArr29[i58];
                this.i = i58 + 1;
                iArr29[i58] = iArr29[i58 - 1];
                return 0;
            case 49:
                int i59 = this.i - 1;
                this.i = i59;
                Object[] objArr13 = this.o;
                Object obj4 = objArr13[i59];
                objArr13[i59] = null;
                objArr13[5] = obj4;
                return 0;
            case 50:
                Object[] objArr14 = this.o;
                int i60 = this.i;
                this.i = i60 + 1;
                objArr14[i60] = objArr14[i60 - 1];
                this.i = i60;
                Object obj5 = objArr14[i60];
                objArr14[i60] = null;
                objArr14[6] = obj5;
                Object obj6 = objArr14[i60 - 1];
                objArr14[i60 - 1] = null;
                this.f[i60 - 1] = ((Object[]) obj6).length;
                return 0;
            case 51:
                int i61 = this.i;
                int i62 = i61 - 1;
                this.i = i62;
                int[] iArr30 = this.f;
                iArr30[7] = iArr30[i62];
                this.i = i61;
                iArr30[i62] = 0;
                return 0;
            case 52:
                int i63 = this.i - 1;
                this.i = i63;
                int[] iArr31 = this.f;
                iArr31[8] = iArr31[i63];
                return 0;
            case 53:
                int[] iArr32 = this.f;
                int i64 = this.i;
                this.i = i64 + 1;
                iArr32[i64] = iArr32[8];
                return 0;
            case 54:
                int i65 = this.i;
                int i66 = i65 - 2;
                this.i = i66;
                int[] iArr33 = this.f;
                this.d = iArr33[i66] >= iArr33[i65 - 1] ? 0 : 1;
                return 0;
            case 55:
                int[] iArr34 = this.f;
                int i67 = this.i;
                this.i = i67 + 1;
                iArr34[i67] = iArr34[7];
                return 0;
            case 56:
                Object[] objArr15 = this.o;
                int i68 = this.i;
                int i69 = i68 + 1;
                this.i = i69;
                objArr15[i68] = objArr15[6];
                int[] iArr35 = this.f;
                this.i = i68 + 2;
                iArr35[i69] = iArr35[8];
                return 0;
            case 57:
                int i70 = this.i;
                int i71 = i70 - 1;
                this.i = i71;
                Object[] objArr16 = this.o;
                Object obj7 = objArr16[i70 - 2];
                objArr16[i70 - 2] = null;
                objArr16[i70 - 2] = ((Object[]) obj7)[this.f[i71]];
                int i72 = i70 - 2;
                this.i = i72;
                Object obj8 = objArr16[i72];
                objArr16[i72] = null;
                objArr16[9] = obj8;
                return 0;
            case 58:
                Object[] objArr17 = this.o;
                int i73 = this.i;
                this.i = i73 + 1;
                objArr17[i73] = objArr17[9];
                return 0;
            case 59:
                int[] iArr36 = this.f;
                iArr36[8] = iArr36[8] + 1;
                return 0;
            case 60:
                int[] iArr37 = this.f;
                int i74 = this.i;
                this.i = i74 + 1;
                iArr37[i74] = 41;
                return 0;
            case 61:
                int i75 = this.i;
                int i76 = i75 - 1;
                this.i = i76;
                Object[] objArr18 = this.o;
                objArr18[i76] = null;
                this.i = i75;
                objArr18[i76] = objArr18[5];
                return 0;
            case 62:
                int[] iArr38 = this.f;
                int i77 = this.i;
                this.i = i77 + 1;
                iArr38[i77] = 29;
                this.i = i77;
                iArr38[i77 - 1] = iArr38[i77 - 1] + iArr38[i77];
                return 0;
            case 63:
                int[] iArr39 = this.f;
                int i78 = this.i;
                int i79 = i78 + 1;
                this.i = i79;
                iArr39[i78] = 96;
                this.i = i78 + 2;
                iArr39[i79] = 0;
                return 0;
            case 64:
                int[] iArr40 = this.f;
                int i80 = this.i;
                this.i = i80 + 1;
                iArr40[i80] = 44;
                return 0;
            case 65:
                int[] iArr41 = this.f;
                int i81 = this.i;
                this.i = i81 + 1;
                iArr41[i81] = 78;
                return 0;
            case 66:
                int[] iArr42 = this.f;
                int i82 = this.i;
                this.i = i82 + 1;
                iArr42[i82] = 1;
                return 0;
            case 67:
                int[] iArr43 = this.f;
                int i83 = this.i;
                this.i = i83 + 1;
                iArr43[i83] = 0;
                return 0;
            case 68:
                int i84 = this.i - 1;
                this.i = i84;
                Object[] objArr19 = this.o;
                Object obj9 = objArr19[i84];
                objArr19[i84] = null;
                objArr19[4] = obj9;
                return 0;
            case 69:
                int[] iArr44 = this.f;
                int i85 = this.i;
                this.i = i85 + 1;
                iArr44[i85] = 46;
                return 0;
            case 70:
                int[] iArr45 = this.f;
                int i86 = this.i;
                this.i = i86 + 1;
                iArr45[i86] = 47;
                return 0;
            case 71:
                int[] iArr46 = this.f;
                int i87 = this.i;
                this.i = i87 + 1;
                iArr46[i87] = 59;
                return 0;
            case 72:
                int[] iArr47 = this.f;
                int i88 = this.i;
                this.i = i88 + 1;
                iArr47[i88] = 2;
                this.i = i88;
                iArr47[i88 - 1] = iArr47[i88 - 1] % iArr47[i88];
                int i89 = i88 - 1;
                this.i = i89;
                this.o[i89] = null;
                return 0;
            case 73:
                int[] iArr48 = this.f;
                int i90 = this.i;
                this.i = i90 + 1;
                iArr48[i90] = 121;
                this.i = i90;
                iArr48[i90 - 1] = iArr48[i90 - 1] + iArr48[i90];
                return 0;
            case 74:
                int[] iArr49 = this.f;
                int i91 = this.i;
                this.i = i91 + 1;
                iArr49[i91] = 55;
                return 0;
            case 75:
                int i92 = this.i;
                int i93 = i92 - 1;
                this.i = i93;
                int[] iArr50 = this.f;
                iArr50[i92 - 2] = iArr50[i92 - 2] + iArr50[i93];
                this.i = i92;
                iArr50[i93] = iArr50[i92 - 2];
                return 0;
            case 76:
                int[] iArr51 = this.f;
                int i94 = this.i;
                this.i = i94 + 1;
                iArr51[i94] = 85;
                return 0;
            case 77:
                int[] iArr52 = this.f;
                int i95 = this.i;
                this.i = i95 + 1;
                iArr52[i95] = 0;
                return 0;
            case 78:
                int[] iArr53 = this.f;
                int i96 = this.i;
                this.i = i96 + 1;
                iArr53[i96] = 13;
                return 0;
            case 79:
                int[] iArr54 = this.f;
                int i97 = this.i;
                int i98 = i97 + 1;
                this.i = i98;
                iArr54[i97] = iArr54[i97 - 1];
                this.i = i97 + 2;
                iArr54[i98] = 128;
                int i99 = i97 + 1;
                this.i = i99;
                iArr54[i97] = iArr54[i97] % iArr54[i99];
                return 0;
            case 80:
                int[] iArr55 = this.f;
                int i100 = this.i;
                this.i = i100 + 1;
                iArr55[i100] = 75;
                return 0;
            case 81:
                int[] iArr56 = this.f;
                int i101 = this.i;
                this.i = i101 + 1;
                iArr56[i101] = 29;
                return 0;
            case 82:
                int[] iArr57 = this.f;
                int i102 = this.i;
                this.i = i102 + 1;
                iArr57[i102] = 1;
                return 0;
            default:
                return i;
        }
    }

    public ee(Object obj, Object obj2) {
        this.f = new int[10];
        this.h = new long[10];
        this.f95884g = new float[10];
        this.m = new double[10];
        Object[] objArr = new Object[10];
        this.o = objArr;
        objArr[4] = obj;
        objArr[5] = obj2;
        this.i = 0;
        this.j = -1;
    }

    public ee(long j, Object obj) {
        this.f = new int[10];
        long[] jArr = new long[10];
        this.h = jArr;
        this.f95884g = new float[10];
        this.m = new double[10];
        Object[] objArr = new Object[10];
        this.o = objArr;
        jArr[4] = j;
        objArr[6] = obj;
        this.i = 0;
        this.j = -1;
    }

    public ee(Object obj) {
        this.f = new int[10];
        this.h = new long[10];
        this.f95884g = new float[10];
        this.m = new double[10];
        Object[] objArr = new Object[10];
        this.o = objArr;
        objArr[4] = obj;
        this.i = 0;
        this.j = -1;
    }
}