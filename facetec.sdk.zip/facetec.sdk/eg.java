package com.facetec.sdk;

import android.app.Activity;
import android.content.Intent;
import android.nfc.NfcAdapter;
import android.nfc.NfcManager;
import android.nfc.Tag;
import android.nfc.tech.IsoDep;
import android.os.Build;
import com.facetec.sdk.ej;
import com.plaid.internal.EnumC41897g;
import java.io.IOException;
import java.lang.ref.WeakReference;
import java.nio.ByteBuffer;
import kotlin.C6852;
import net.sf.scuba.smartcards.ISO7816;
import org.bouncycastle.i18n.LocalizedMessage;
import org.json.JSONObject;

/* JADX INFO: loaded from: classes4.dex */
public final class eg {
    private static /* synthetic */ boolean m = true;
    private static int n = 10000;
    public String a;
    public final WeakReference<Activity> c;
    private IsoDep d;
    public final NfcAdapter e;
    private a f;
    private String h;
    private final boolean i;
    private Exception b = null;
    private ej j = null;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    private String f95885g = "";

    public static class a {
        public final String a;
        public final String d;
        public final String e;
    }

    public interface b {
        void d(ej ejVar, String str);

        void e(e eVar);
    }

    public static final class e {
        private static final byte[] $$a = null;
        private static final int $$b = 0;
        private static final byte[] $$c = null;
        private static final int $$d = 0;
        private static int $10;
        private static int $11;
        private static long a;
        private static int b;
        private static int c;
        private static char[] e;
        public final JSONObject d;

        private static String $$e(short s, short s2, short s3) {
            byte[] bArr = $$c;
            int i = s3 * 3;
            int i2 = 111 - s2;
            int i3 = (s * 3) + 4;
            byte[] bArr2 = new byte[i + 1];
            int i4 = -1;
            if (bArr == null) {
                i2 = i3 + i;
                i3++;
                bArr = bArr;
                i4 = -1;
            }
            while (true) {
                int i5 = i4 + 1;
                bArr2[i5] = (byte) i2;
                if (i5 == i) {
                    return new String(bArr2, 0);
                }
                int i6 = i2;
                byte[] bArr3 = bArr;
                i2 = bArr[i3] + i6;
                i3++;
                bArr = bArr3;
                i4 = i5;
            }
        }

        static {
            init$1();
            $10 = 0;
            $11 = 1;
            init$0();
            c = 0;
            b = 1;
            char[] cArr = new char[2156];
            ByteBuffer.wrap("ây¨íw\u008d\u0002½É\u0005\u0094j#\u0003î#´ÊCç\u000e\u0089Õ°`J/Zú\u0005\u0081#OÂ\u001aë¡\u009dl¨;IÆB\u008d\u000fX/æß\u00adòx\u0095þá´uk\u0015\u001e%Õ\u009d\u0088ò?\u009bò»¨R_\u007f\u0012\u0011É(|Ò3Âæ\u008c\u009d¶SN\u0006d½?p''ÒÚ÷\u0091\u0087D³úBây¨íw\u008d\u0002½É\u0005\u0094j#\u0003î#´ÊCç\u000e\u0089Õ°`J/Zú\u0017\u0081>OÈ\u001aúây¨úw\u0091\u0002¸É\u0005\u0094`#\u0003î+´ÛCí\u000e\u0085Õì`E/jú\b\u0081#OÀ\u001að¡\u008bl³;eÆ\u007f\u008d\u001dX+æÊ\u00adôx\u0082\u0007ª\u00023H¦\u0097Öââ)Ot#ÃA\u000e+T\u0094£¹îÅ5ùÌè\u0086}Y\r,9ç\u0094ºï\r\u0094À³\u009a\u0011m` \u0003û=NÃÁ¨\u008b+T]!yê\u009a·®\u0000ÙÍ±\u0097-`\u0016-|ö}C\u0085\f±Ùñ¢÷l\u00039)WÒ\u001dFÂ\"·\u0014|à!\u0089\u0096é[\u0087\u0001uö_»\"`\u0006Õï\u009aÁò\r¸Ïgï\u0012\u0080Ùl\u0084K31þH¤õSÍ\u001e\u00adÅ\u0098pd?Eê)\u00911_á\nÕ±¥|\u00ad+wÖZ\u009d&HG\u0083sÉ±\u0016\u0091cþ¨\u0012õ5BO\u008f6Õ\u008b\"³oÓ´æ\u0001\u001aN;\u009bWàO.\u009f{«ÀÛ\rÓZ\t§$ìX9:ÎÓ\u0084P[;.\u0012åô¸Â\u000f«ÂÊ\u0098hoB\"(ùFLä\u0003ÆÖ¬\u00ad\u0083cn6\u001d\u008d!@\u001eDÿ\u000e+ÑD¤no\u008e2¾Ãw\u0089µjÄ Gÿ,\u008a\u0005Aã\u001cÕ«¼fÝ<qËU\u00863]Qèñ§Ýr´\t\u008fÇM\u0092i)hä\b³âNÍ\u0005´ÐÏn`%Cð#\u008f\u001aZý\u0011Ç¬¥O5\u0005¶ÚÝ¯ôd\u00129$\u008eMC,\u0019\u0080î¤£Âx Í\u0000\u0082,WE,~â¼·\u0098\f\u0099Áç\u0096\u0004k> @\u0084CÎÀ\u0011«d\u0082¯dòRE;\u0088ZÒø%Òh¸³Ö\u0006tIV\u009c<ç\u0013)ù|ÎÇ·\n·]M Wë4>\n\u0080ôË\u0085\u001e¹a\u0086 AjÕµµÀ\u0085\u000b=V[á1,\u001avã\u0081ÞÌ\u00ad\u0017\u009e¢iíIâ$¨æwÆ\u0002©É_\u0094d#\u0000î+´\u0080Cé\u000e\u008fÕ°`Vâ8¨ìw\u0089\u0002¸ÉO\u0094##\u0002î*´Úây¨ùw\u009a\u0002¤ÉI\u0094\"#\nî&´ÂCä\u000e\u0093Õº`Q/qú\u0001\u0081*OÕâ8¨ìw\u0085\u0002¾ÉY\u0094kYG\u0013\u0085Ì¥¹Ør;/\u0001\u0098kUY\u000f®ø\u0096µ\u00adnÍÛ \u0094\bAr:Bô¤¡\u0099\u001aï×Í\u0080+}\u001b6m\u0013\u008eYS\u00869ó\râ&¨ìw\u009a\u0002¸ÉC\u0094~#\u0018îa´ÝCø\u000e\u0093Õí`@/aúJ\u0081#OÃ\u001aû¡\u008dl¼;\u0014Æz\u008d\fX*æ\u0090\u00ad÷x\u0091\u0007¸ÒW\u0099J$\u0013ó'¹ÃD¶\u0013ºÞNed0\tÿ)\u0085ÝPë\u001f\u0093â&¨ìw\u009a\u0002¸ÉC\u0094~#\u0018îa´ÝCø\u000e\u0093Õí`@/aúJ\u0081#OÃ\u001aû¡\u008dl¼;\u0014Æz\u008d\fX*æ\u0090\u00ad÷x\u0091\u0007¸ÒW\u0099J$\u0013ó'¹ÃD¶\u0013¾ÞNed0\tÿ#\u0085Ý\u000e\"Dè\u009b\u009eî¼%GxzÏ\u001c\u0002eXÙ¯üâ\u00979é\u008cDÃe\u0016Nm'£ÇöÿM\u0089\u0080¸×\u0010*ka\u0017´u\nÙAä\u0094\u009dâ&¨ìw\u009a\u0002¸ÉC\u0094~#\u0018îa´ÝCø\u000e\u0093Õí`@/aúJ\u0081#OÃ\u001aû¡\u008dl¼;\u0014Æo\u008d\u0013XqæÒ\u00adðx\u0093±hû¢$ÔQö\u009a\rÇ0pV½/ç\u0093\u0010¶]Ý\u0086£3\u000e|/©\u0004Òm\u001c\u008dIµòÃ?òhZ\u0095!Þ]\u000b?µ\u009dþ¼+ÝÇ\u008c\u008dFR0'\u0012ìé±Ô\u0006²ËË\u0091wfR+9ðGEê\nËßà¤\u0089ji?Q\u0084'I\u0016\u001e¾ãÅ¨¹}ÛÃy\u0088U]9â ¨ëw\u0087\u0002³ÉY\u0094kù\u0014³\u0094l÷\u0019ÉÒ$\u008fO8lõM¯§X\u0099\u0015áÎË{<Ê\u0016\u0080Ý_±*\u0085á{¼N\u000b?Æ\n\u009cì#ziù¶\u0092Ã»\b]Ukâ\u0002/cuË\u0082ðÏ\u0082\u0014\u00ad¡Dîq;\b@6\u008eÎÛµ`\u008c\u00ad±úW\u0007zL\u0010\u0099+'Îl¿¹\u0080Æ©\u0013BXbå\u001229xê\u0085\u0099Ò®\u001fZ¤\u007fñ\u000b>=D\u0082\u0091çÞ\u0083k±\t_CÙ\u009c«é\u0083\"h\u007fDÈ8\u0005F_ä¨Îå¤>Ó\u008b0Ä\f\u0011*j\u0016¤¯ñÞJ«\u0087\u0099Ðu-Tft³\t\rêFÞ\u0093»ì\u00949frJÏ|\u0018\u0006Rù¯¡ø\u008a5b\u008e[Û8\u0014Dnú»Çây¨ÿw\u008d\u0002¥ÉN\u0094b#\u001eî`´ÂCè\u000e\u0082Õõ`\u0016/*ú\f\u00810O\u0089\u001añ¡\u008fl¸;UÆp\u008d\fX0æÍ\u00adôx\u0082\u0007ýÒE\u0099|$\u001aó3¹ÙD\u009e\u0013»Þ\u0005ey0\u0002ây¨úw\u0091\u0002¸É^\u0094h#\u0001î`´ÂCè\u000e\u0082Õõ`\u0016/*ú\u0007\u0081+OÉ\u001aì¡\u009cl\u0084;[Æt\u008d\u0018X3æá\u00adøx\u009e\u0007§ÒW\u0099g$\u0012ó6¹ÕD\u008c\u0013åÞHez0\u001dÿb\u0085ÜPá×¢\u009d7BG7süÞ¡¿\u0016ÙÛý\u0081\u0001vu;RàvU\u0090\u001aªÏ\u0091´ÿz\u0011/-\u0094VYd\u000e\u0092ó£¸ÕmòÓ\f\u0098)MN2&ç\u009b¬\u00adâ\u0011¨ìw\u0086\u0002²ÉG\u0094b#\u0018î&´ÁCïâ#¨çw\u0083\u0002¥ÉE\u0094z#\u0002â5¨áw\u009a\u0002¤ÉG\u0094d#\u0019î\"â$¨æwÆ\u0002»ÉX\u0094b#\bî:´ÍCõ\u000eÎÕ§`G/sú\r\u0081$OÃâ ¨ëw\u0087\u0002³É\u0012\u0094;#\u001c\u001b\u0091QL\u008e&û\u000e0ømÄÚ¯¹\u000eóÓ,¹Y\u0091\u0092gÏ[x0µ/ïé\u0018\u0086Uéâ1¨ìw\u0086\u0002®ÉX\u0094d#\u000fî\u0010´ÖC¹\u000eÖÕ\u009c`\u0014/1â$¨æwÆ\u0002»ÉX\u0094b#\bî:´ÍCõ\u000eÎÕ®`M/aú\u0001\u0081+â%¨íw\u0083ï±¥fz\u001f\u000f%ÄÉ\u0099û.\u0081ã¿\u0090ÐÚ>\u0005_p,»¿æ¿QÅ\u009cüÆ\u00001+|B§$\u0012\u0083]\u00ad\u0088Ñó =\"h6ÓM\u001esI\u0090´¿\u009a¨ÐX\u000f3z\u0006±úìÛ[·\u0096ÐÌB;zv\u0014\u00ad\\\u0018ÿWÏ\u0082²ù\u00947mb\u0006Ù!\u0014\u000bC÷¾\u0082õ» Ø\u009e7â\u0017¨çw\u008c\u0002¹ÉE\u0094d#\bîo´ýCÅ\u000e«Õã`@/pú\r\u0081+OÒ\u001a¹¡\u009el´;HÆ=\u008d\u0004Xgæ\u0088\u00adÎxÆ\u0007çq\u008b;Iäi\u0091\fZä\u0007Ð°§}\u0097'`Ð\\\u009d*â1¨æw\u0084\u0002¯ÉL\u0094d#\u001fî'\u0091¡Ûj\u0004\u0006q2º\u0093çº\u0012\u008dXA\u0087/ò\u00019ëdÑâ$¨æwÆ\u0002»ÉX\u0094b#\bî:´ÍCõ\u000eÎÕ¡`P/dú\n\u0081#â$¨æwÆ\u0002 ÉO\u0094\u007f#\u0002î*´ÂC¯\u000e\u0091Õ¦`O/pâgâ$¨æwÆ\u0002¸ÉO\u0094n#\u0019î=´Ë\u000fqâ$¨æwÆ\u0002©É_\u0094d#\u0000î+´\u0080Cñ\u000e\u0092Õ¬`F/pú\u0007\u00813â0¨üw\u0084\u0002§Éu\u0094u#Tîyâ$¨æwÆ\u0002©É_\u0094d#\u0000î+´\u0080Cç\u000e\u0089Õ\u00ad`E/`ú\u0016\u00817OÔ\u001að¡\u0096l¯jä 9ÿS\u008a{A\u008d\u001c±«Úfµ<\bË0\u0086^]9è\u0090§µrß\t÷Ç\u0001\u0092%)Nâ1¨ìw\u0086\u0002®ÉX\u0094d#\u000fî\u0010´ÖC¹\u000eÖÕì`Q/aú\u000f\u0081\u0018OÞ\u001a¡¡Îlô;]Æx\u008d\u0012X:æÌ\u00adøx\u0093\u0007\u008cÒJ\u0099-$Bâ1¨ìw\u0086\u0002®ÉX\u0094d#\u000fî`´ÉCî\u000e\u008fÕ¤`N/`ú;\u00814OÂ\u001aò¡×l¼;_Æs\u008d\u0019X-æ×\u00adòâ1¨ìw\u0086\u0002®ÉX\u0094d#\u000fî`´ØCã\u000e\u008fÕ»`\u001a/3ú\u0014\u0081hOÐ\u001aû¡\u0097l£;\u0002Æ+\u008d\fâ1¨æw\u0087\u0002¬ÉF\u0094h#Cî<´ÊCê\u000e¿Õ¤`R/mú\u000b\u0081)OÃ\u001aÆ¡\u0080lã;\fÆ2\u008d\u001bX:æÐ\u00adôx\u0082\u0007ºÒQ\u0099J$\fóo¹\u0080\u001c\u0011VÓ\u0089óü\u009c7pjWÝ-\u0010\u0016Jô½Õð±+\u0093\u009eeâ$¨æwÆ\u0002©ÉE\u0094b#\u0018î&´ÃCà\u000e\u0087Õ¦`\f/gú\u0011\u0081.OÊ\u001aý¡Öl½;SÆs\u008d\u001bX:æÌ\u00adáx\u0082\u0007ºÒ\\\u0099aâ\u0017¨çw\u008c\u0002¹ÉE\u0094d#\bîb´ÖC¹\u000eÖeÏ/\rð-\u0085BN´\u0013\u008f¤ëiÀ3kÄ\u000e\u0089bR[ç¹¨\u0082}î\u0006ÕÈc\u009d\u001b&wÖ\u0098\u009cVC!6\u0005ý½â?¨çw\u0081\u0002¿É\u0004\u0094~#\u001aî,´\u0080Cð\u000e\u0085Õ®`W/(ú\u0014\u00815OÉ\u001aé¡\u008bÀ\u0018\u008aÓUº \u0081ë;¶Z\u0001$Ì^\u0096üaß,¶÷\u0092Bv\r_Ø\"£\u000bÍ\u0012\u0087ÙX°-\u008bæ1»K\f?ÁT\u009býlÕ!¾ú\u0093OH\u0000SÕ0®\u001f`ö5Þ\u008e¬í2§ùx\u0090\r«Æ\u0011\u009bk,\u001fát»×L÷\u0001\u0091Ú\u0089oS uõ\u001f\u008e!@Ú\u0015ø®\u0094â$¨æwÆ\u0002 ÉO\u0094\u007f#\u0002î*´ÂC¯\u000e\u0081Õ\u00ad`F/wú\u000b\u0081.OÂ\u001a·¡\u0089l¾;WÆh\u008d\u0018\u008b\u0096ÁT\u001etk\u001b ÷ýÐJª\u0087ÓÝm*Vg?¼\u0004\t¾FÖ\u0093 è\u0091&KsEÈ+\u0005\u0004Rí2`x¢§\u0082Òà\u0019\nD$ó\u0006>id\u009f\u0093¬ÞÈ\u0005ã°Hÿ'*IQm\u009f\u0085Ê¸qÎ¼ïë\f\u00160]V\u0088oâ$¨æwÆ\u0002»ÉX\u0094b#\bî:´ÍCõ\u000eÎÕ¡`W/lú\b\u0081#O\u0088\u001aÿ¡\u0091lµ;]Æx\u008d\u000eX/æÌ\u00adøx\u009e\u0007§\u0095qß³\u0000\u0093uí¾\u0006ã+TM\u0099\u007fÃ\u00964úy×¢ã\u0017\u001eX<\u008dUö<8\u0095m¥ÖÃ\u001béL\n±:úY/x\u0091\u0082Úª\u000fÑâ$¨æwÆ\u0002¸ÉS\u0094~#\u0018î*´ÃCÞ\u000e\u0085Õ»`V/+ú\u0006\u00812OÏ\u001aõ¡\u009clõ;\\Æt\u008d\u0012X8æÛ\u00adãx\u0080\u0007¡Ò[\u0099{$\u0000\nÅ@\u0007\u009f'ê\\!®|\u0082Ëé\u0006Á\\=«Næc=W\u0088ªÇ\u0088\u0012ái\u0088§!ò\u0011Iw\u0084]Ó¾.\u008eeí°Ì\u000e6E\u001e\u0090eâ$¨æwÆ\u0002½ÉO\u0094c#\bî ´ÜCÞ\u000e\u0084Õ¯`I/húJ\u0081%OÓ\u001að¡\u0094l¿;\u0014Æ{\u008d\u0015X1æÙ\u00adôx\u0082\u0007£Ò@\u0099|$\u001aó#û«%\u0089oZâl4åây¨íw\u008d\u0002½É\u0005\u0094|#\tî\"´ÛCÞ\u000e\u0090Õª`R/`ây¨íw\u008d\u0002½É\u0005\u0094~#\u0003î,´ÅCä\u000e\u0094Õì`@/dú\u0017\u0081\"OÄ\u001aø¡\u0096l¿;eÆz\u008d\u0019X1æÇ\u00adõÐÎ\u009aZE:0\nû²¦É\u0011´Ü\u009b\u0086rqS<#ç[Rò\u001d×È½³\u0089}uå4¯ pÀ\u0005ðÎH\u00933$Néa³\u0088D©\tÙÒ¡g\u001e(-ýD\u0086\u007fH\u008f\u0013qYò\u0086\u0099ó°8\retÒ\u0001\u001f*EÓ²Öÿ\u009c$¹\u0091KÞn\u000b\tây¨úw\u0091\u0002¸É^\u0094h#\u0001î`´ÂCè\u000e\u0082Õì`N/lú\u0006\u0081$Où\u001aô¡\u0099l·;VÆr\u008d\u001fX\u0000æÚ\u00adôx\u0092\u0007¦ÒU\u0099J$\u0005ó2¹ÛD\u009c\u0013æÞXeeây¨íw\u008d\u0002½É\u0005\u0094o#\u001fî;´ñCæ\u000e\u0090Õ°Ü\"\u0096¶IÖ<æ÷^ª4\u001dDÐ`\u008aª}®0Òëõ^\u001cây¨íw\u008d\u0002½É\u0005\u0094~#\u0003î,´ÅCä\u000e\u0094Õì`@/vú\u0010\u0081!OÉ\u001aõ¡\u009cl¾;HÆyây¨úw\u0091\u0002¸É^\u0094h#\u0001î`´ÂCè\u000e\u0082Õì`N/lú\u0006\u0081%OÕ\u001aí¡\u009el´;VÆy\u008d\u0019X-æá\u00adûx\u009e\u0007ºÒ\u001c\u0099f$\u001b!ÅkQ´1Á\u0001\n¹WÓà£-\u0087ws\u0080^Í?\u0016\u001aÒ©\u0098=G]2mùÕ¤¿\u0013ÏÞë\u0084\u0019s(>Bå|ây¨íw\u008d\u0002½É\u0005\u0094o#\u001fî;´ÃCä\u000e\u0087Õ\u00adq\u0084;\u0010äp\u0091@Zø\u0007\u0092°â}Æ'<Ð\u000e\u009dtF[ây¨íw\u008d\u0002½É\u0005\u0094o#\u001fî;´ØCì\u000e\u0093Õ¤\u0092RØÆ\u0007¦r\u0096¹.äDS4\u009e\u0010Äõ3Í~ª¥\u0081\u0010y_M\u000e\u0011D\u0085\u009båîÕ%mx\u0007Ïw\u0002SX\u0099¯\u0080âå9Î6õ|a£\u0005Ö3\u001dÇ@®÷\u0084:¬`U\u0097cÚ\u0000\u0001 ´Ïûí.\u009bUä\u009b\u0004Îmu\u0016¸xïÔ\u0012âY\u0084\u008c¸¢ è½7ßBæ\u0089\\Ô#c\\®xô\u0093\u0003·NÎ\u0095é To\u001eºNÁj\u000f¬Z¨áÀ,ð{\u0006\u0086 Íc\u0018i¦\u008bí¬8ÌGøäR®Òq±\u0004\u008fÏb\u0092\t%.è\u000b²õEÅ\b¹Ó\u009cfzâf¨ïw\u008e\u0002ëÉ\u0010+<a¼¾ßËá\u0000\f]gêZ'o}\u0087\u008a¢Ç\u008a\u001cë©\u0006æ03Râ1¨ûw\u0089\u0002§ÉF\u0094b#\u000fîa´ÉCî\u000e\u008cÕ§`D/lú\u0017\u0081/O\u0088\u001aê¡\u0097$\u001dnÇ±\u00adÄ«\u000fARoå\u0018(7rë\u0085ÕÈ³\u0013Ê¦véMây¨ìw\u009c\u0002¨É\u0005\u0094`#\tî+´ÇCà\u000e¿Õ `M/aú\u0001\u0081$OÕ\u001a·¡\u0080l¶;Vâ4¨åw\u009d\u0002®ÉY\u0094y#\rî,´ÅCòåÐ¯Ep5\u0005\u0001Î¬\u0093É$ªé\u0093³iD\\\t:\u0099öÓb\f\u0006y0²Äï\u00adX\u0087\u0095¯ÏV8`u\u0003®#\u001bÌTî\u0081\u0098úç4\u0007arÚ\u0007\u0017{@Ô½âö\u0083#£\u009d\u001fÖf\u0003\u0012|0ây¨ùw\u009a\u0002¤ÉI\u0094\"#\u000fî?´ÛCè\u000e\u008eÕ¥`Mèã¢\u0014}v\b]Ã¾\u009e\u0096)íäÕây¨íw\u0089\u0002¿ÉK\u0094\"#\u0001î&´ÝCâ\u000eÏÕ³`P/jú\u0002\u0081.OÊ\u001aü¡\u008blô;YÆh\u008d\u000eXpæ\u008e\u00ad¾x\u0093\u0007¼Ò_\u0099;$\u0019ó>¹ÕD\u009b\u0013§Þ]ec0\u001fÿ8\u0085\u0081Pã\u001f\u0084ª\u00adqV<kË\b\u0096!".getBytes(LocalizedMessage.DEFAULT_ENCODING)).asCharBuffer().get(cArr, 0, 2156);
            e = cArr;
            a = 871103049592973449L;
        }

        public e(JSONObject jSONObject) {
            this.d = jSONObject;
        }

        /* JADX WARN: Code restructure failed: missing block: B:346:0x3388, code lost:
        
            r4 = com.facetec.sdk.eg.e.c;
            r5 = (r4 & 41) + (r4 | 41);
            com.facetec.sdk.eg.e.b = r5 % 128;
         */
        /* JADX WARN: Code restructure failed: missing block: B:347:0x3397, code lost:
        
            if ((r5 % 2) == 0) goto L349;
         */
        /* JADX WARN: Code restructure failed: missing block: B:350:0x339c, code lost:
        
            throw null;
         */
        /* JADX WARN: Removed duplicated region for block: B:116:0x0c54  */
        /* JADX WARN: Removed duplicated region for block: B:227:0x19db A[PHI: r73
          0x19db: PHI (r73v7 int) = (r73v5 int), (r73v21 int) binds: [B:226:0x19d9, B:218:0x18dd] A[DONT_GENERATE, DONT_INLINE]] */
        /* JADX WARN: Removed duplicated region for block: B:228:0x19e2 A[PHI: r73
          0x19e2: PHI (r73v20 int) = (r73v5 int), (r73v21 int) binds: [B:226:0x19d9, B:218:0x18dd] A[DONT_GENERATE, DONT_INLINE]] */
        /* JADX WARN: Removed duplicated region for block: B:243:0x1b77  */
        /* JADX WARN: Removed duplicated region for block: B:271:0x282e  */
        /* JADX WARN: Removed duplicated region for block: B:276:0x2893  */
        /* JADX WARN: Removed duplicated region for block: B:331:0x3193  */
        /* JADX WARN: Removed duplicated region for block: B:399:0x3a76 A[Catch: all -> 0x3be3, TryCatch #2 {all -> 0x3be3, blocks: (B:6:0x00df, B:8:0x00ec, B:10:0x012f, B:23:0x02c1, B:25:0x02ce, B:27:0x0315, B:34:0x042c, B:36:0x0439, B:37:0x046f, B:63:0x0687, B:65:0x068d, B:66:0x06c8, B:88:0x0976, B:90:0x0983, B:92:0x09cd, B:107:0x0bca, B:109:0x0bd7, B:110:0x0c0e, B:118:0x0cb3, B:120:0x0cc2, B:121:0x0d00, B:127:0x0de1, B:129:0x0dee, B:130:0x0e2c, B:141:0x0fad, B:143:0x0fba, B:145:0x0ff9, B:153:0x108d, B:155:0x109c, B:156:0x10d9, B:177:0x13c9, B:179:0x13d6, B:181:0x1418, B:194:0x15a5, B:196:0x15b2, B:198:0x15fb, B:205:0x16ef, B:207:0x16f5, B:208:0x1731, B:213:0x17de, B:215:0x17eb, B:216:0x182a, B:230:0x1a21, B:232:0x1a2e, B:233:0x1a65, B:236:0x1a7e, B:238:0x1a96, B:239:0x1ad6, B:287:0x296f, B:289:0x297c, B:290:0x29b0, B:311:0x2f48, B:313:0x2f55, B:314:0x2f8d, B:333:0x31a4, B:335:0x31b1, B:336:0x31e8, B:340:0x328e, B:342:0x329b, B:343:0x32d6, B:321:0x3047, B:323:0x3054, B:324:0x308e, B:363:0x377d, B:365:0x378d, B:367:0x37d6, B:397:0x3a69, B:399:0x3a76, B:400:0x3ab2, B:293:0x29bc, B:295:0x29d5, B:296:0x2a11, B:246:0x2762, B:248:0x276f, B:250:0x27b5, B:220:0x18e1, B:222:0x18ee, B:224:0x1932, B:164:0x1203, B:166:0x1212, B:167:0x1249, B:97:0x0a80, B:99:0x0a8d, B:100:0x0ad0, B:42:0x0564, B:44:0x0571, B:46:0x05b8, B:53:0x0613, B:55:0x0620, B:56:0x065e), top: B:416:0x00df }] */
        /* JADX WARN: Removed duplicated region for block: B:443:0x339d A[SYNTHETIC] */
        /*
            Code decompiled incorrectly, please refer to instructions dump.
            To view partially-correct code enable 'Show inconsistent code' option in preferences
        */
        public static java.lang.Object[] a(android.content.Context r71, int r72, int r73, int r74) throws java.lang.Throwable {
            /*
                Method dump skipped, instruction units count: 15340
                To view this dump change 'Code comments level' option to 'DEBUG'
            */
            throw new UnsupportedOperationException("Method not decompiled: com.facetec.sdk.eg.e.a(android.content.Context, int, int, int):java.lang.Object[]");
        }

        /* JADX WARN: Removed duplicated region for block: B:45:0x01f8  */
        /* JADX WARN: Removed duplicated region for block: B:46:0x01f9  */
        /*
            Code decompiled incorrectly, please refer to instructions dump.
            To view partially-correct code enable 'Show inconsistent code' option in preferences
        */
        private static void f(int r26, char r27, int r28, java.lang.Object[] r29) throws java.lang.Throwable {
            /*
                Method dump skipped, instruction units count: 514
                To view this dump change 'Code comments level' option to 'DEBUG'
            */
            throw new UnsupportedOperationException("Method not decompiled: com.facetec.sdk.eg.e.f(int, char, int, java.lang.Object[]):void");
        }

        private static void g(int i, byte b2, byte b3, Object[] objArr) {
            byte[] bArr = $$a;
            int i2 = 101 - b3;
            int i3 = 4 - (b2 * 2);
            int i4 = i * 4;
            byte[] bArr2 = new byte[i4 + 1];
            int i5 = -1;
            if (bArr == null) {
                i3++;
                i2 += -i4;
            }
            while (true) {
                i5++;
                bArr2[i5] = (byte) i2;
                if (i5 == i4) {
                    objArr[0] = new String(bArr2, 0);
                    return;
                } else {
                    i3++;
                    i2 += -bArr[i3];
                }
            }
        }

        public static void init$0() {
            $$a = new byte[]{ISO7816.INS_DECREASE_STAMPED, -107, 59, -11};
            $$b = EnumC41897g.SDK_ASSET_ILLUSTRATION_VERIFICATION_IN_PROGRESS_DARK_APPEARANCE_VALUE;
        }

        public static void init$1() {
            $$c = new byte[]{126, 1, 26, -71};
            $$d = EnumC41897g.SDK_ASSET_ILLUSTRATION_INSTITUTION_LINK_CIRCLE_VALUE;
        }
    }

    private eg(NfcAdapter nfcAdapter, Activity activity, boolean z) {
        this.e = nfcAdapter;
        this.c = new WeakReference<>(activity);
        this.i = z;
    }

    public static boolean a(Activity activity) {
        return C6852.checkSelfPermission(activity, "android.permission.NFC") == 0 && e(activity) != null;
    }

    public static eg b(Activity activity, boolean z, boolean z2) {
        NfcAdapter nfcAdapterE = e(activity);
        if (nfcAdapterE == null) {
            return null;
        }
        if (z2) {
            n = 60000;
        }
        return new eg(nfcAdapterE, activity, z);
    }

    public static boolean d(Activity activity) {
        NfcAdapter nfcAdapterE;
        return C6852.checkSelfPermission(activity, "android.permission.NFC") == 0 && (nfcAdapterE = e(activity)) != null && nfcAdapterE.isEnabled();
    }

    private static NfcAdapter e(Activity activity) {
        NfcManager nfcManager = (NfcManager) activity.getSystemService("nfc");
        if (nfcManager == null) {
            return null;
        }
        return nfcManager.getDefaultAdapter();
    }

    public final boolean c(Intent intent, final b bVar) {
        if (!"android.nfc.action.TECH_DISCOVERED".equals(intent.getAction())) {
            return false;
        }
        this.d = IsoDep.get((Tag) intent.getExtras().getParcelable("android.nfc.extra.TAG"));
        new Thread(new Runnable() { // from class: com.facetec.sdk.剑日
            @Override // java.lang.Runnable
            public final void run() {
                this.f7217.a(bVar);
            }
        }).start();
        return true;
    }

    public final native String nativeStartReading(String str, String str2, String str3, String str4, boolean z);

    public final native String nativeStartReadingWithKey(String str, String str2, boolean z);

    public final native void nativeUpdateErrorHistory(String str, String str2);

    public final byte[] sendCommand(byte[] bArr) throws IOException {
        this.b = null;
        try {
            if (!this.d.isConnected()) {
                this.d.connect();
            }
            return this.d.transceive(bArr);
        } catch (IOException e2) {
            if (n <= 10000) {
                n = 20000;
            }
            this.b = e2;
            throw e2;
        }
    }

    public final void setNativeError(int i, String str) {
        this.f95885g = str;
        switch (i) {
            case 1:
                this.j = ej.Unknown;
                return;
            case 2:
                this.j = ej.InvalidMrzKey;
                return;
            case 3:
                this.j = ej.ResponseError;
                return;
            case 4:
                this.j = ej.UnknownRetry;
                return;
            case 5:
                this.j = ej.IncompatibleDoc;
                return;
            case 6:
                this.j = ej.ConnectionError;
                return;
            default:
                if (!m) {
                    throw new AssertionError();
                }
                this.j = ej.Unknown;
                return;
        }
    }

    public static int e() {
        return Build.VERSION.SDK_INT >= 31 ? 167772160 : 134217728;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void a(final b bVar) {
        eg egVar;
        final ej ejVar;
        String strNativeStartReading;
        Activity activity = this.c.get();
        if (activity != null) {
            this.b = null;
            this.j = null;
            this.f95885g = "";
            this.d.setTimeout(n);
            try {
                String str = this.a;
                if (str != null && !str.isEmpty()) {
                    strNativeStartReading = nativeStartReadingWithKey(this.a, this.h, this.i);
                    egVar = this;
                } else {
                    a aVar = this.f;
                    egVar = this;
                    try {
                        strNativeStartReading = egVar.nativeStartReading(aVar.a, aVar.d, aVar.e, this.h, this.i);
                    } catch (Throwable unused) {
                        ejVar = ej.Unknown;
                    }
                }
            } catch (Throwable unused2) {
                egVar = this;
            }
            if (strNativeStartReading != null) {
                final e eVar = new e(new JSONObject(strNativeStartReading));
                activity.runOnUiThread(new Runnable() { // from class: com.facetec.sdk.剑星
                    @Override // java.lang.Runnable
                    public final void run() {
                        bVar.e(eVar);
                    }
                });
                return;
            }
            if (egVar.b != null) {
                ejVar = ej.ConnectionError;
            } else {
                ejVar = egVar.j;
                if (ejVar == null) {
                    ejVar = ej.Unknown;
                }
            }
            String str2 = "Unknown";
            switch (ej.AnonymousClass2.b[ejVar.ordinal()]) {
                case 2:
                    str2 = "InvalidMrzKey";
                    break;
                case 3:
                    str2 = "ResponseError";
                    break;
                case 4:
                    str2 = "ConnectionError";
                    break;
                case 5:
                    str2 = "UnknownRetry";
                    break;
                case 6:
                    str2 = "IncompatibleDoc";
                    break;
            }
            nativeUpdateErrorHistory(str2, egVar.f95885g);
            activity.runOnUiThread(new Runnable() { // from class: com.facetec.sdk.剑月
                @Override // java.lang.Runnable
                public final void run() {
                    this.f7221.d(bVar, ejVar);
                }
            });
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void d(b bVar, ej ejVar) {
        bVar.d(ejVar, this.f95885g);
    }

    public final void c() {
        Activity activity = this.c.get();
        if (activity != null) {
            this.e.disableForegroundDispatch(activity);
        }
    }
}