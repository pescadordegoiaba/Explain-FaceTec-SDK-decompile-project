package com.facetec.sdk;

/* JADX INFO: loaded from: classes4.dex */
public interface eh {
    void oia(Object obj);
}