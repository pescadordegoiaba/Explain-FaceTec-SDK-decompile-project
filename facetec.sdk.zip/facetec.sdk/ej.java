package com.facetec.sdk;

/* JADX INFO: loaded from: classes4.dex */
public enum ej {
    Unknown,
    InvalidMrzKey,
    ResponseError,
    ConnectionError,
    UnknownRetry,
    IncompatibleDoc;

    /* JADX INFO: renamed from: com.facetec.sdk.ej$2, reason: invalid class name */
    public static /* synthetic */ class AnonymousClass2 {
        static final /* synthetic */ int[] b;

        static {
            int[] iArr = new int[ej.values().length];
            b = iArr;
            try {
                iArr[ej.Unknown.ordinal()] = 1;
            } catch (NoSuchFieldError unused) {
            }
            try {
                b[ej.InvalidMrzKey.ordinal()] = 2;
            } catch (NoSuchFieldError unused2) {
            }
            try {
                b[ej.ResponseError.ordinal()] = 3;
            } catch (NoSuchFieldError unused3) {
            }
            try {
                b[ej.ConnectionError.ordinal()] = 4;
            } catch (NoSuchFieldError unused4) {
            }
            try {
                b[ej.UnknownRetry.ordinal()] = 5;
            } catch (NoSuchFieldError unused5) {
            }
            try {
                b[ej.IncompatibleDoc.ordinal()] = 6;
            } catch (NoSuchFieldError unused6) {
            }
        }
    }
}