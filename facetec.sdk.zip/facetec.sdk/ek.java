package com.facetec.sdk;

import java.lang.reflect.Field;

/* JADX INFO: loaded from: classes4.dex */
public interface ek {
    String c(Field field);
}