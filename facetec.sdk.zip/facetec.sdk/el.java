package com.facetec.sdk;

import java.io.EOFException;
import java.io.IOException;
import java.io.Reader;
import java.io.StringReader;
import java.io.StringWriter;
import java.io.Writer;
import java.lang.reflect.Type;
import java.math.BigDecimal;
import java.math.BigInteger;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentMap;
import java.util.concurrent.atomic.AtomicLong;
import java.util.concurrent.atomic.AtomicLongArray;

/* JADX INFO: loaded from: classes4.dex */
public final class el {
    public static final String c = null;
    private List<fb> A;
    private ez B;
    private ez C;
    private ThreadLocal<Map<gu<?>, d<?>>> d;
    private fq f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    private gg f95887g;
    private fn h;
    private ConcurrentMap<gu<?>, fg<?>> i;
    private List<ff> j;
    private boolean k;
    private boolean l;
    private ek m;
    private boolean n;
    private Map<Type, eq<?>> o;
    private boolean p;
    private boolean q;
    private boolean r;
    private boolean s;
    private boolean t;
    private List<ff> u;
    private fd v;
    private int w;
    private String x;
    private int y;
    private List<ff> z;
    private static ek a = eo.IDENTITY;
    public static final ez e = fa.DOUBLE;
    public static final ez b = fa.LAZILY_PARSED_NUMBER;

    public static class d<T> extends gl<T> {
        public static int a;
        public static int d;
        fg<T> b;

        private fg<T> d() {
            fg<T> fgVar = this.b;
            if (fgVar != null) {
                return fgVar;
            }
            throw new IllegalStateException("Delegate has not been set yet");
        }

        @Override // com.facetec.sdk.fg
        public final T a(gs gsVar) {
            return d().a(gsVar);
        }

        @Override // com.facetec.sdk.gl
        public final fg<T> e() {
            return d();
        }

        public static int a() {
            int i = d;
            int i2 = i % 8462423;
            d = i + 1;
            if (i2 != 0) {
                return a;
            }
            int iMaxMemory = (int) Runtime.getRuntime().maxMemory();
            a = iMaxMemory;
            return iMaxMemory;
        }

        @Override // com.facetec.sdk.fg
        public final void e(ha haVar, T t) {
            d().e(haVar, t);
        }
    }

    /* JADX WARN: Illegal instructions before constructor call */
    public el() {
        fq fqVar = fq.b;
        ek ekVar = a;
        Map map = Collections.EMPTY_MAP;
        fd fdVar = fd.DEFAULT;
        String str = c;
        List list = Collections.EMPTY_LIST;
        this(fqVar, ekVar, map, false, false, false, true, false, false, false, true, fdVar, str, 2, 2, list, list, list, e, b, list);
    }

    private String a(Object obj, Type type) {
        StringWriter stringWriter = new StringWriter();
        e(obj, type, stringWriter);
        return stringWriter.toString();
    }

    public static void b(double d2) {
        if (Double.isNaN(d2) || Double.isInfinite(d2)) {
            StringBuilder sb = new StringBuilder();
            sb.append(d2);
            sb.append(" is not a valid double value as per JSON specification. To override this behavior, use GsonBuilder.serializeSpecialFloatingPointValues() method.");
            throw new IllegalArgumentException(sb.toString());
        }
    }

    public final es c(Object obj) {
        return obj == null ? ex.e : d(obj, obj.getClass());
    }

    public final <T> fg<T> d(ff ffVar, gu<T> guVar) {
        if (!this.j.contains(ffVar)) {
            ffVar = this.f95887g;
        }
        boolean z = false;
        for (ff ffVar2 : this.j) {
            if (z) {
                fg<T> fgVarB = ffVar2.b(this, guVar);
                if (fgVarB != null) {
                    return fgVarB;
                }
            } else if (ffVar2 == ffVar) {
                z = true;
            }
        }
        throw new IllegalArgumentException("GSON cannot serialize ".concat(String.valueOf(guVar)));
    }

    public final <T> fg<T> e(gu<T> guVar) {
        boolean z;
        Objects.requireNonNull(guVar, "type must not be null");
        fg<T> fgVar = (fg) this.i.get(guVar);
        if (fgVar != null) {
            return fgVar;
        }
        Map<gu<?>, d<?>> map = this.d.get();
        if (map == null) {
            map = new HashMap<>();
            this.d.set(map);
            z = true;
        } else {
            z = false;
        }
        d<?> dVar = map.get(guVar);
        if (dVar != null) {
            return dVar;
        }
        try {
            d<?> dVar2 = new d<>();
            map.put(guVar, dVar2);
            Iterator<ff> it = this.j.iterator();
            while (it.hasNext()) {
                fg<T> fgVarB = it.next().b(this, guVar);
                if (fgVarB != null) {
                    fg<T> fgVar2 = (fg) this.i.putIfAbsent(guVar, fgVarB);
                    if (fgVar2 != null) {
                        fgVarB = fgVar2;
                    }
                    if (dVar2.b != null) {
                        throw new AssertionError();
                    }
                    dVar2.b = fgVarB;
                    return fgVarB;
                }
            }
            throw new IllegalArgumentException("GSON (2.10) cannot handle ".concat(String.valueOf(guVar)));
        } finally {
            map.remove(guVar);
            if (z) {
                this.d.remove();
            }
        }
    }

    public final String toString() {
        StringBuilder sb = new StringBuilder("{serializeNulls:");
        sb.append(this.k);
        sb.append(",factories:");
        sb.append(this.j);
        sb.append(",instanceCreators:");
        sb.append(this.h);
        sb.append("}");
        return sb.toString();
    }

    private <T> T b(String str, gu<T> guVar) {
        if (str == null) {
            return null;
        }
        return (T) d(new StringReader(str), guVar);
    }

    public final <T> T c(String str, Class<T> cls) {
        return (T) ft.e(cls).cast(b(str, gu.a(cls)));
    }

    private void a(es esVar, Appendable appendable) {
        try {
            a(esVar, a(fw.c(appendable)));
        } catch (IOException e2) {
            throw new er(e2);
        }
    }

    private static void b(Object obj, gs gsVar) {
        if (obj != null) {
            try {
                if (gsVar.j() == gw.END_DOCUMENT) {
                } else {
                    throw new fc("JSON document was not fully consumed.");
                }
            } catch (gz e2) {
                throw new fc(e2);
            } catch (IOException e3) {
                throw new er(e3);
            }
        }
    }

    public el(fq fqVar, ek ekVar, Map<Type, eq<?>> map, boolean z, boolean z2, boolean z3, boolean z4, boolean z5, boolean z6, boolean z7, boolean z8, fd fdVar, String str, int i, int i2, List<ff> list, List<ff> list2, List<ff> list3, ez ezVar, ez ezVar2, List<fb> list4) {
        final fg<Number> fgVar;
        fg<Number> fgVar2;
        fg<Number> fgVar3;
        ArrayList arrayList = new ArrayList(list3);
        arrayList.add(new hm());
        this.d = new ThreadLocal<>();
        this.i = new ConcurrentHashMap();
        this.f = fqVar;
        this.m = ekVar;
        this.o = map;
        this.h = new fn(map, z8, list4);
        this.k = z;
        this.n = z2;
        this.l = z3;
        this.s = z4;
        this.r = z5;
        this.t = z6;
        this.q = z7;
        this.p = z8;
        this.v = fdVar;
        this.x = str;
        this.w = i;
        this.y = i2;
        this.u = list;
        this.z = list2;
        this.C = ezVar;
        this.B = ezVar2;
        this.A = list4;
        ArrayList arrayList2 = new ArrayList();
        arrayList2.add(gn.B);
        arrayList2.add(gk.a(ezVar));
        arrayList2.add(fqVar);
        arrayList2.addAll(arrayList);
        arrayList2.add(gn.p);
        arrayList2.add(gn.f);
        arrayList2.add(gn.a);
        arrayList2.add(gn.c);
        arrayList2.add(gn.i);
        if (fdVar == fd.DEFAULT) {
            fgVar = gn.o;
        } else {
            fgVar = new fg<Number>() { // from class: com.facetec.sdk.el.3
                @Override // com.facetec.sdk.fg
                public final /* synthetic */ Number a(gs gsVar) {
                    if (gsVar.j() != gw.NULL) {
                        return Long.valueOf(gsVar.n());
                    }
                    gsVar.m();
                    return null;
                }

                @Override // com.facetec.sdk.fg
                public final /* bridge */ /* synthetic */ void e(ha haVar, Number number) {
                    Number number2 = number;
                    if (number2 == null) {
                        haVar.g();
                    } else {
                        haVar.e(number2.toString());
                    }
                }
            };
        }
        arrayList2.add(gn.d(Long.TYPE, Long.class, fgVar));
        if (z7) {
            fgVar2 = gn.k;
        } else {
            fgVar2 = new fg<Number>() { // from class: com.facetec.sdk.el.5
                @Override // com.facetec.sdk.fg
                public final /* synthetic */ Number a(gs gsVar) {
                    if (gsVar.j() != gw.NULL) {
                        return Double.valueOf(gsVar.o());
                    }
                    gsVar.m();
                    return null;
                }

                @Override // com.facetec.sdk.fg
                public final /* bridge */ /* synthetic */ void e(ha haVar, Number number) {
                    Number number2 = number;
                    if (number2 == null) {
                        haVar.g();
                        return;
                    }
                    double dDoubleValue = number2.doubleValue();
                    el.b(dDoubleValue);
                    haVar.e(dDoubleValue);
                }
            };
        }
        arrayList2.add(gn.d(Double.TYPE, Double.class, fgVar2));
        if (z7) {
            fgVar3 = gn.m;
        } else {
            fgVar3 = new fg<Number>() { // from class: com.facetec.sdk.el.2
                @Override // com.facetec.sdk.fg
                public final /* synthetic */ Number a(gs gsVar) {
                    if (gsVar.j() != gw.NULL) {
                        return Float.valueOf((float) gsVar.o());
                    }
                    gsVar.m();
                    return null;
                }

                @Override // com.facetec.sdk.fg
                public final /* synthetic */ void e(ha haVar, Number number) {
                    Number numberValueOf = number;
                    if (numberValueOf == null) {
                        haVar.g();
                        return;
                    }
                    float fFloatValue = numberValueOf.floatValue();
                    el.b(fFloatValue);
                    if (!(numberValueOf instanceof Float)) {
                        numberValueOf = Float.valueOf(fFloatValue);
                    }
                    haVar.b(numberValueOf);
                }
            };
        }
        arrayList2.add(gn.d(Float.TYPE, Float.class, fgVar3));
        arrayList2.add(gd.c(ezVar2));
        arrayList2.add(gn.h);
        arrayList2.add(gn.j);
        arrayList2.add(gn.b(AtomicLong.class, new fg<AtomicLong>() { // from class: com.facetec.sdk.el.4
            @Override // com.facetec.sdk.fg
            public final /* bridge */ /* synthetic */ AtomicLong a(gs gsVar) {
                return new AtomicLong(((Number) fgVar.a(gsVar)).longValue());
            }

            @Override // com.facetec.sdk.fg
            public final /* bridge */ /* synthetic */ void e(ha haVar, AtomicLong atomicLong) {
                fgVar.e(haVar, Long.valueOf(atomicLong.get()));
            }
        }.b()));
        arrayList2.add(gn.b(AtomicLongArray.class, new fg<AtomicLongArray>() { // from class: com.facetec.sdk.el.1
            @Override // com.facetec.sdk.fg
            public final /* bridge */ /* synthetic */ AtomicLongArray a(gs gsVar) {
                ArrayList arrayList3 = new ArrayList();
                gsVar.c();
                while (gsVar.b()) {
                    arrayList3.add(Long.valueOf(((Number) fgVar.a(gsVar)).longValue()));
                }
                gsVar.e();
                int size = arrayList3.size();
                AtomicLongArray atomicLongArray = new AtomicLongArray(size);
                for (int i3 = 0; i3 < size; i3++) {
                    atomicLongArray.set(i3, ((Long) arrayList3.get(i3)).longValue());
                }
                return atomicLongArray;
            }

            @Override // com.facetec.sdk.fg
            public final /* bridge */ /* synthetic */ void e(ha haVar, AtomicLongArray atomicLongArray) {
                AtomicLongArray atomicLongArray2 = atomicLongArray;
                haVar.e();
                int length = atomicLongArray2.length();
                for (int i3 = 0; i3 < length; i3++) {
                    fgVar.e(haVar, Long.valueOf(atomicLongArray2.get(i3)));
                }
                haVar.a();
            }
        }.b()));
        arrayList2.add(gn.f95895g);
        arrayList2.add(gn.n);
        arrayList2.add(gn.s);
        arrayList2.add(gn.r);
        arrayList2.add(gn.b(BigDecimal.class, gn.l));
        arrayList2.add(gn.b(BigInteger.class, gn.q));
        arrayList2.add(gn.b(fp.class, gn.t));
        arrayList2.add(gn.u);
        arrayList2.add(gn.y);
        arrayList2.add(gn.x);
        arrayList2.add(gn.w);
        arrayList2.add(gn.C);
        arrayList2.add(gn.v);
        arrayList2.add(gn.d);
        arrayList2.add(gb.c);
        arrayList2.add(gn.A);
        if (gt.a) {
            arrayList2.add(gt.b);
            arrayList2.add(gt.d);
            arrayList2.add(gt.i);
        }
        arrayList2.add(ga.e);
        arrayList2.add(gn.e);
        arrayList2.add(new fy(this.h));
        arrayList2.add(new ge(this.h, z2));
        gg ggVar = new gg(this.h);
        this.f95887g = ggVar;
        arrayList2.add(ggVar);
        arrayList2.add(gn.D);
        arrayList2.add(new gm(this.h, ekVar, fqVar, this.f95887g, list4));
        this.j = Collections.unmodifiableList(arrayList2);
    }

    public final <T> fg<T> d(Class<T> cls) {
        return e((gu) gu.a(cls));
    }

    private ha a(Writer writer) throws IOException {
        if (this.l) {
            writer.write(")]}'\n");
        }
        ha haVar = new ha(writer);
        if (this.r) {
            haVar.d("  ");
        }
        haVar.e(this.s);
        haVar.a(this.t);
        haVar.c(this.k);
        return haVar;
    }

    private es d(Object obj, Type type) {
        gf gfVar = new gf();
        e(obj, type, gfVar);
        return gfVar.d();
    }

    public final String d(es esVar) {
        StringWriter stringWriter = new StringWriter();
        a(esVar, stringWriter);
        return stringWriter.toString();
    }

    private gs d(Reader reader) {
        gs gsVar = new gs(reader);
        gsVar.a(this.t);
        return gsVar;
    }

    private void a(es esVar, ha haVar) {
        boolean zJ = haVar.j();
        haVar.a(true);
        boolean zH = haVar.h();
        haVar.e(this.s);
        boolean zF = haVar.f();
        haVar.c(this.k);
        try {
            try {
                fw.c(esVar, haVar);
            } catch (IOException e2) {
                throw new er(e2);
            } catch (AssertionError e3) {
                StringBuilder sb = new StringBuilder("AssertionError (GSON 2.10): ");
                sb.append(e3.getMessage());
                AssertionError assertionError = new AssertionError(sb.toString());
                assertionError.initCause(e3);
                throw assertionError;
            }
        } finally {
            haVar.a(zJ);
            haVar.e(zH);
            haVar.c(zF);
        }
    }

    private <T> T d(Reader reader, gu<T> guVar) {
        gs gsVarD = d(reader);
        T t = (T) a(gsVarD, guVar);
        b(t, gsVarD);
        return t;
    }

    public final String e(Object obj) {
        if (obj == null) {
            return d(ex.e);
        }
        return a(obj, obj.getClass());
    }

    private void e(Object obj, Type type, Appendable appendable) {
        try {
            e(obj, type, a(fw.c(appendable)));
        } catch (IOException e2) {
            throw new er(e2);
        }
    }

    private void e(Object obj, Type type, ha haVar) {
        fg fgVarE = e((gu) gu.e(type));
        boolean zJ = haVar.j();
        haVar.a(true);
        boolean zH = haVar.h();
        haVar.e(this.s);
        boolean zF = haVar.f();
        haVar.c(this.k);
        try {
            try {
                fgVarE.e(haVar, obj);
            } catch (IOException e2) {
                throw new er(e2);
            } catch (AssertionError e3) {
                StringBuilder sb = new StringBuilder("AssertionError (GSON 2.10): ");
                sb.append(e3.getMessage());
                AssertionError assertionError = new AssertionError(sb.toString());
                assertionError.initCause(e3);
                throw assertionError;
            }
        } finally {
            haVar.a(zJ);
            haVar.e(zH);
            haVar.c(zF);
        }
    }

    private <T> T a(gs gsVar, gu<T> guVar) {
        boolean zT = gsVar.t();
        boolean z = true;
        gsVar.a(true);
        try {
            try {
                try {
                    gsVar.j();
                    z = false;
                    return e((gu) guVar).a(gsVar);
                } catch (EOFException e2) {
                    if (z) {
                        gsVar.a(zT);
                        return null;
                    }
                    throw new fc(e2);
                } catch (IOException e3) {
                    throw new fc(e3);
                }
            } catch (AssertionError e4) {
                StringBuilder sb = new StringBuilder("AssertionError (GSON 2.10): ");
                sb.append(e4.getMessage());
                AssertionError assertionError = new AssertionError(sb.toString());
                assertionError.initCause(e4);
                throw assertionError;
            } catch (IllegalStateException e5) {
                throw new fc(e5);
            }
        } finally {
            gsVar.a(zT);
        }
    }
}