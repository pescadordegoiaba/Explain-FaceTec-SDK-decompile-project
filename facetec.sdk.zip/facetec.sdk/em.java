package com.facetec.sdk;

import com.facetec.sdk.fz;
import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

/* JADX INFO: loaded from: classes4.dex */
public final class em {
    private fq a = fq.b;
    private fd e = fd.DEFAULT;
    private ek d = eo.IDENTITY;
    private final Map<Type, eq<?>> c = new HashMap();
    private final List<ff> b = new ArrayList();
    private final List<ff> h = new ArrayList();
    private boolean j = false;
    private String f = el.c;
    private int i = 2;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    private int f95888g = 2;
    private boolean o = false;
    private boolean l = false;
    private boolean n = true;
    private boolean k = false;
    private boolean m = false;
    private boolean p = false;
    private boolean q = true;
    private ez t = el.e;
    private ez s = el.b;
    private final LinkedList<fb> r = new LinkedList<>();

    public final el b() {
        ArrayList arrayList = new ArrayList(this.b.size() + this.h.size() + 3);
        arrayList.addAll(this.b);
        Collections.reverse(arrayList);
        ArrayList arrayList2 = new ArrayList(this.h);
        Collections.reverse(arrayList2);
        arrayList.addAll(arrayList2);
        b(this.f, this.i, this.f95888g, arrayList);
        return new el(this.a, this.d, new HashMap(this.c), this.j, this.o, this.m, this.n, this.k, this.p, this.l, this.q, this.e, this.f, this.i, this.f95888g, new ArrayList(this.b), new ArrayList(this.h), arrayList, this.t, this.s, new ArrayList(this.r));
    }

    public final em e() {
        this.n = false;
        return this;
    }

    private static void b(String str, int i, int i2, List<ff> list) {
        ff ffVarC;
        ff ffVarC2;
        boolean z = gt.a;
        ff ffVarC3 = null;
        if (str != null && !str.trim().isEmpty()) {
            ffVarC = fz.d.b.c(str);
            if (z) {
                ffVarC3 = gt.e.c(str);
                ffVarC2 = gt.c.c(str);
            } else {
                ffVarC2 = null;
            }
        } else {
            if (i == 2 || i2 == 2) {
                return;
            }
            ff ffVarC4 = fz.d.b.c(i, i2);
            if (z) {
                ffVarC3 = gt.e.c(i, i2);
                ff ffVarC5 = gt.c.c(i, i2);
                ffVarC = ffVarC4;
                ffVarC2 = ffVarC5;
            } else {
                ffVarC = ffVarC4;
                ffVarC2 = null;
            }
        }
        list.add(ffVarC);
        if (z) {
            list.add(ffVarC3);
            list.add(ffVarC2);
        }
    }
}