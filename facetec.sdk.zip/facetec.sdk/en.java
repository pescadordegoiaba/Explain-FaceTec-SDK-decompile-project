package com.facetec.sdk;

import java.lang.reflect.Field;
import java.util.Objects;

/* JADX INFO: loaded from: classes4.dex */
public final class en {
    private final Field b;

    public en(Field field) {
        Objects.requireNonNull(field);
        this.b = field;
    }

    public final String toString() {
        return this.b.toString();
    }
}