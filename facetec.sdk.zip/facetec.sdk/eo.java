package com.facetec.sdk;

import java.lang.reflect.Field;
import java.util.Locale;

/* JADX INFO: loaded from: classes4.dex */
public enum eo implements ek {
    IDENTITY { // from class: com.facetec.sdk.eo.2
        @Override // com.facetec.sdk.ek
        public final String c(Field field) {
            return field.getName();
        }
    },
    UPPER_CAMEL_CASE { // from class: com.facetec.sdk.eo.5
        @Override // com.facetec.sdk.ek
        public final String c(Field field) {
            return eo.a(field.getName());
        }
    },
    UPPER_CAMEL_CASE_WITH_SPACES { // from class: com.facetec.sdk.eo.1
        @Override // com.facetec.sdk.ek
        public final String c(Field field) {
            return eo.a(eo.c(field.getName(), ' '));
        }
    },
    UPPER_CASE_WITH_UNDERSCORES { // from class: com.facetec.sdk.eo.3
        @Override // com.facetec.sdk.ek
        public final String c(Field field) {
            return eo.c(field.getName(), '_').toUpperCase(Locale.ENGLISH);
        }
    },
    LOWER_CASE_WITH_UNDERSCORES { // from class: com.facetec.sdk.eo.4
        @Override // com.facetec.sdk.ek
        public final String c(Field field) {
            return eo.c(field.getName(), '_').toLowerCase(Locale.ENGLISH);
        }
    },
    LOWER_CASE_WITH_DASHES { // from class: com.facetec.sdk.eo.6
        @Override // com.facetec.sdk.ek
        public final String c(Field field) {
            return eo.c(field.getName(), '-').toLowerCase(Locale.ENGLISH);
        }
    },
    LOWER_CASE_WITH_DOTS { // from class: com.facetec.sdk.eo.9
        @Override // com.facetec.sdk.ek
        public final String c(Field field) {
            return eo.c(field.getName(), '.').toLowerCase(Locale.ENGLISH);
        }
    };

    public static String a(String str) {
        int length = str.length();
        int i = 0;
        while (true) {
            if (i >= length) {
                break;
            }
            char cCharAt = str.charAt(i);
            if (!Character.isLetter(cCharAt)) {
                i++;
            } else if (!Character.isUpperCase(cCharAt)) {
                char upperCase = Character.toUpperCase(cCharAt);
                if (i == 0) {
                    StringBuilder sb = new StringBuilder();
                    sb.append(upperCase);
                    sb.append(str.substring(1));
                    return sb.toString();
                }
                StringBuilder sb2 = new StringBuilder();
                sb2.append(str.substring(0, i));
                sb2.append(upperCase);
                sb2.append(str.substring(i + 1));
                return sb2.toString();
            }
        }
        return str;
    }

    public static String c(String str, char c) {
        StringBuilder sb = new StringBuilder();
        int length = str.length();
        for (int i = 0; i < length; i++) {
            char cCharAt = str.charAt(i);
            if (Character.isUpperCase(cCharAt) && sb.length() != 0) {
                sb.append(c);
            }
            sb.append(cCharAt);
        }
        return sb.toString();
    }

    /* synthetic */ eo(byte b) {
        this();
    }
}