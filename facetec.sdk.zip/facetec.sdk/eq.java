package com.facetec.sdk;

/* JADX INFO: loaded from: classes4.dex */
public interface eq<T> {
    T e();
}