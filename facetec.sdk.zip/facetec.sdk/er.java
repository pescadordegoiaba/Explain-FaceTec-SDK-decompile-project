package com.facetec.sdk;

/* JADX INFO: loaded from: classes4.dex */
public final class er extends ew {
    public er(String str) {
        super(str);
    }

    public er(String str, Throwable th) {
        super(str, th);
    }

    public er(Throwable th) {
        super(th);
    }
}