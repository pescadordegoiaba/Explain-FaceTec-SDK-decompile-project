package com.facetec.sdk;

import com.plaid.internal.EnumC41897g;
import java.io.IOException;
import java.io.StringWriter;
import net.sf.scuba.smartcards.ISO7816;
import org.jmrtd.PassportService;
import org.jmrtd.lds.CVCAFile;

/* JADX INFO: loaded from: classes4.dex */
public abstract class es {
    private static final byte[] $$d = {113, 46, 90, -12, 9, -5, -66, 53, -8, -1, -1, PassportService.SFI_DG12, -18, -5, -56, CVCAFile.CAR_TAG, -18, 4, ISO7816.INS_GET_RESPONSE, ISO7816.INS_DECREASE_STAMPED, PassportService.SFI_DG13};
    private static final int $$e = EnumC41897g.SDK_ASSET_ILLUSTRATION_NETWORK_SWITCH_DARK_APPEARANCE_VALUE;

    @Deprecated
    public es() {
    }

    private static void p(short s, short s2, short s3, Object[] objArr) {
        byte[] bArr = $$d;
        int i = 99 - (s2 * 2);
        int i2 = s3 + 4;
        int i3 = s * 3;
        byte[] bArr2 = new byte[i3 + 18];
        int i4 = i3 + 17;
        int i5 = -1;
        if (bArr == null) {
            i = i + i2 + 3;
            i2 = i2;
            bArr = bArr;
            i5 = -1;
        }
        while (true) {
            int i6 = i5 + 1;
            bArr2[i6] = (byte) i;
            int i7 = i2 + 1;
            if (i6 == i4) {
                objArr[0] = new String(bArr2, 0);
                return;
            }
            byte[] bArr3 = bArr;
            i = i + bArr[i7] + 3;
            i2 = i7;
            bArr = bArr3;
            i5 = i6;
        }
    }

    public int a() {
        throw new UnsupportedOperationException(getClass().getSimpleName());
    }

    public double b() {
        throw new UnsupportedOperationException(getClass().getSimpleName());
    }

    public String c() {
        throw new UnsupportedOperationException(getClass().getSimpleName());
    }

    public long d() {
        throw new UnsupportedOperationException(getClass().getSimpleName());
    }

    public Number e() {
        throw new UnsupportedOperationException(getClass().getSimpleName());
    }

    public final boolean f() {
        return this instanceof et;
    }

    public final boolean g() {
        return this instanceof ey;
    }

    public boolean i() {
        throw new UnsupportedOperationException(getClass().getSimpleName());
    }

    public final boolean j() {
        byte b = $$d[9];
        byte b2 = (byte) (b + 1);
        Object[] objArr = new Object[1];
        p(b2, b2, b, objArr);
        return Class.forName((String) objArr[0]).isInstance(this);
    }

    public final boolean l() {
        return this instanceof ex;
    }

    public final eu m() {
        if (j()) {
            return (eu) this;
        }
        throw new IllegalStateException("Not a JSON Primitive: ".concat(String.valueOf(this)));
    }

    public String toString() {
        try {
            StringWriter stringWriter = new StringWriter();
            ha haVar = new ha(stringWriter);
            haVar.a(true);
            fw.c(this, haVar);
            return stringWriter.toString();
        } catch (IOException e) {
            throw new AssertionError(e);
        }
    }
}