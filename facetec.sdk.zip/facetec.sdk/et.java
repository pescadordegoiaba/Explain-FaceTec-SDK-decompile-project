package com.facetec.sdk;

import android.os.SystemClock;
import java.util.ArrayList;
import java.util.Iterator;

/* JADX INFO: loaded from: classes4.dex */
public final class et extends es implements Iterable<es> {
    public static int c;
    public static int e;
    private final ArrayList<es> d = new ArrayList<>();

    public static int h() {
        int i = c;
        int i2 = i % 6040260;
        c = i + 1;
        if (i2 != 0) {
            return e;
        }
        int iElapsedRealtime = (int) SystemClock.elapsedRealtime();
        e = iElapsedRealtime;
        return iElapsedRealtime;
    }

    private es n() {
        int size = this.d.size();
        if (size == 1) {
            return this.d.get(0);
        }
        throw new IllegalStateException("Array must have size 1, but has size ".concat(String.valueOf(size)));
    }

    @Override // com.facetec.sdk.es
    public final int a() {
        return n().a();
    }

    public final void b(es esVar) {
        if (esVar == null) {
            esVar = ex.e;
        }
        this.d.add(esVar);
    }

    @Override // com.facetec.sdk.es
    public final String c() {
        return n().c();
    }

    public final void d(String str) {
        this.d.add(str == null ? ex.e : new eu(str));
    }

    @Override // com.facetec.sdk.es
    public final Number e() {
        return n().e();
    }

    public final boolean equals(Object obj) {
        if (obj != this) {
            return (obj instanceof et) && ((et) obj).d.equals(this.d);
        }
        return true;
    }

    public final int hashCode() {
        return this.d.hashCode();
    }

    @Override // com.facetec.sdk.es
    public final boolean i() {
        return n().i();
    }

    @Override // java.lang.Iterable
    public final Iterator<es> iterator() {
        return this.d.iterator();
    }

    @Override // com.facetec.sdk.es
    public final long d() {
        return n().d();
    }

    @Override // com.facetec.sdk.es
    public final double b() {
        return n().b();
    }
}