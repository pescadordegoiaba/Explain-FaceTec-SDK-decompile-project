package com.facetec.sdk;

import com.facetec.sdk.bd;
import com.plaid.internal.EnumC41897g;
import java.math.BigInteger;
import java.util.Objects;
import net.sf.scuba.smartcards.ISO7816;
import net.sf.scuba.smartcards.ISOFileInfo;
import org.bouncycastle.crypto.signers.PSSSigner;
import org.jmrtd.lds.CVCAFile;

/* JADX INFO: loaded from: classes4.dex */
public final class eu extends es {
    private static final byte[] $$a = null;
    private static final int $$b = 0;
    private static final byte[] $$c = null;
    private static final int $$f = 0;
    private static int $10;
    private static int $11;
    private static int a;
    private static int b;
    private static int d;
    private static byte[] e;
    private static int f;
    private static short[] h;
    private static int j;
    private final Object c;

    /* JADX WARN: Removed duplicated region for block: B:10:0x0023  */
    /* JADX WARN: Removed duplicated region for block: B:8:0x001d  */
    /* JADX WARN: Unsupported multi-entry loop pattern (BACK_EDGE: B:10:0x0023 -> B:11:0x0025). Please report as a decompilation issue!!! */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    private static java.lang.String $$g(short r6, short r7, int r8) {
        /*
            int r8 = r8 + 102
            byte[] r0 = com.facetec.sdk.eu.$$c
            int r7 = r7 * 3
            int r7 = r7 + 4
            int r6 = r6 * 3
            int r6 = 1 - r6
            byte[] r1 = new byte[r6]
            r2 = 0
            if (r0 != 0) goto L15
            r3 = r8
            r5 = r2
            r8 = r7
            goto L25
        L15:
            r3 = r2
        L16:
            byte r4 = (byte) r8
            int r5 = r3 + 1
            r1[r3] = r4
            if (r5 != r6) goto L23
            java.lang.String r6 = new java.lang.String
            r6.<init>(r1, r2)
            return r6
        L23:
            r3 = r0[r7]
        L25:
            int r7 = r7 + 1
            int r3 = -r3
            int r8 = r8 + r3
            r3 = r5
            goto L16
        */
        throw new UnsupportedOperationException("Method not decompiled: com.facetec.sdk.eu.$$g(short, short, int):java.lang.String");
    }

    static {
        init$1();
        $10 = 0;
        $11 = 1;
        init$0();
        j = 0;
        f = 1;
        a = -51337108;
        d = 114796564;
        b = 678352941;
        e = new byte[]{-1, -100, -110, 114, -99, -108, 99, -100, 79, -78, 110, -99, 99, -111, ISO7816.INS_MANAGE_CHANNEL, -98, CVCAFile.CAR_TAG, -78, 105, -8, 110, -99, 99, -111, ISO7816.INS_MANAGE_CHANNEL, -98, CVCAFile.CAR_TAG, ISO7816.INS_READ_BINARY2, 96, 74, PSSSigner.TRAILER_IMPLICIT, -102, 102, -106, 104, 107, -119, -6, -111, ISO7816.INS_MANAGE_CHANNEL, -98, CVCAFile.CAR_TAG, 117, ISO7816.INS_LOAD_KEY_FILE, 103, ISO7816.INS_MSE, -87, -104, -103, -98, 109, -107, 110, ISO7816.INS_WRITE_RECORD, 110, 97, 97, ISOFileInfo.SECURITY_ATTR_COMPACT, -99, 118, -120, 101, 106, -112, 99, -98, 113, 87, ISOFileInfo.AB, -102, 102, 101, 97, ISOFileInfo.SECURITY_ATTR_COMPACT, -99, 38, ISOFileInfo.AB, -111, ISO7816.INS_MANAGE_CHANNEL, -98, ISOFileInfo.FCP_BYTE, 86, ISOFileInfo.A0, ISOFileInfo.FMD_BYTE, -108, -97, 110, -103, 95, -33, -103, 101, 39, -17, ISOFileInfo.FCP_BYTE, ISOFileInfo.FCP_BYTE, -53, -100, -102, 105, ISOFileInfo.FCP_BYTE, -112, 106, 101, -103, 97, 97, ISOFileInfo.SECURITY_ATTR_COMPACT, -99, 109, 84, ISOFileInfo.A0, ISOFileInfo.FMD_BYTE, -108, -97, 110, -103, 95, -33, -103, 101, 39, -81, -105, -98, 97, ISO7816.INS_MSE, -23, -50, -100, 115, -101, -102, 102, 101, 97, ISOFileInfo.SECURITY_ATTR_COMPACT, -99, 38, ISOFileInfo.AB, -102, 102, 101, 97, ISOFileInfo.SECURITY_ATTR_COMPACT, -99, 38, ISOFileInfo.AB, -111, ISO7816.INS_MANAGE_CHANNEL, -98, ISOFileInfo.FCP_BYTE, 86, ISOFileInfo.A0, ISOFileInfo.FMD_BYTE, -108, -97, 110, -103, 95, -33, -103, 101, 39};
    }

    public eu(Boolean bool) {
        Objects.requireNonNull(bool);
        this.c = bool;
    }

    private static /* synthetic */ Object c(Object[] objArr) {
        eu euVar = (eu) objArr[0];
        int i = (j + 19) % 128;
        f = i;
        boolean z = euVar.c instanceof Number;
        int i2 = i + 107;
        j = i2 % 128;
        if (i2 % 2 == 0) {
            return Boolean.valueOf(z);
        }
        throw null;
    }

    public static /* synthetic */ Object d(int i, int i2, int i3, int i4, Object[] objArr, int i5, int i6) {
        int i7 = ~i2;
        int i8 = ~i5;
        int i9 = ~(i7 | i8 | i);
        int i10 = ~i;
        int i11 = (~(i7 | i10)) | (~(i8 | i2 | i));
        int i12 = (~(i | i7)) | (~(i8 | i10));
        int i13 = i2 + i5 + i4 + ((-1255669517) * i6) + (533247121 * i3);
        int i14 = i13 * i13;
        int i15 = ((i2 * (-1895547823)) - 858849280) + ((-1895547823) * i5) + (i9 * (-204618832)) + (i11 * (-204618832)) + ((-204618832) * i12) + ((-2100166656) * i4) + (760610816 * i6) + ((-1057882112) * i3) + (1344208896 * i14);
        int i16 = ((i2 * (-122328301)) - 2132886715) + (i5 * (-122328301)) + (i9 * EnumC41897g.SDK_ASSET_ILLUSTRATION_USER_BRUSHSTROKE_VALUE) + (i11 * EnumC41897g.SDK_ASSET_ILLUSTRATION_USER_BRUSHSTROKE_VALUE) + (i12 * EnumC41897g.SDK_ASSET_ILLUSTRATION_USER_BRUSHSTROKE_VALUE) + (i4 * (-122328029)) + (i6 * (-1196579527)) + (i3 * 656595923) + (i14 * 138215424);
        return i15 + ((i16 * i16) * (-833028096)) != 1 ? c(objArr) : d(objArr);
    }

    public static void init$0() {
        $$a = new byte[]{41, ISO7816.INS_GET_RESPONSE, -63, -4};
        $$b = 116;
    }

    public static void init$1() {
        $$c = new byte[]{ISO7816.INS_DECREASE_STAMPED, -107, 59, -11};
        $$f = 59;
    }

    /* JADX WARN: Removed duplicated region for block: B:54:0x0227 A[PHI: r3
      0x0227: PHI (r3v52 int) = (r3v9 int), (r3v55 int) binds: [B:53:0x0225, B:50:0x0217] A[DONT_GENERATE, DONT_INLINE]] */
    /* JADX WARN: Removed duplicated region for block: B:55:0x0229 A[PHI: r3
      0x0229: PHI (r3v10 int) = (r3v9 int), (r3v55 int) binds: [B:53:0x0225, B:50:0x0217] A[DONT_GENERATE, DONT_INLINE]] */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    private static void n(short r28, int r29, byte r30, int r31, int r32, java.lang.Object[] r33) throws java.lang.Throwable {
        /*
            Method dump skipped, instruction units count: 792
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: com.facetec.sdk.eu.n(short, int, byte, int, int, java.lang.Object[]):void");
    }

    /* JADX WARN: Removed duplicated region for block: B:10:0x002a  */
    /* JADX WARN: Removed duplicated region for block: B:8:0x0022  */
    /* JADX WARN: Unsupported multi-entry loop pattern (BACK_EDGE: B:10:0x002a -> B:11:0x0031). Please report as a decompilation issue!!! */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    private static void q(byte r7, int r8, byte r9, java.lang.Object[] r10) {
        /*
            int r9 = r9 * 4
            int r9 = r9 + 98
            int r8 = r8 * 3
            int r8 = 1 - r8
            int r7 = r7 * 3
            int r7 = 3 - r7
            byte[] r0 = com.facetec.sdk.eu.$$a
            byte[] r1 = new byte[r8]
            r2 = 0
            if (r0 != 0) goto L18
            r3 = r0
            r4 = r2
            r0 = r9
            r9 = r7
            goto L31
        L18:
            r3 = r2
        L19:
            int r7 = r7 + 1
            int r4 = r3 + 1
            byte r5 = (byte) r9
            r1[r3] = r5
            if (r4 != r8) goto L2a
            java.lang.String r7 = new java.lang.String
            r7.<init>(r1, r2)
            r10[r2] = r7
            return
        L2a:
            r3 = r0[r7]
            r6 = r9
            r9 = r7
            r7 = r3
            r3 = r0
            r0 = r6
        L31:
            int r7 = r7 + r0
            r0 = r9
            r9 = r7
            r7 = r0
            r0 = r3
            r3 = r4
            goto L19
        */
        throw new UnsupportedOperationException("Method not decompiled: com.facetec.sdk.eu.q(byte, int, byte, java.lang.Object[]):void");
    }

    @Override // com.facetec.sdk.es
    public final int a() {
        int i = j + 1;
        f = i % 128;
        if (i % 2 == 0) {
            int iC = bd.d.c();
            int iC2 = bd.d.c();
            int iC3 = bd.d.c();
            ((Boolean) d(iC, 13458657, bd.d.c(), iC2, new Object[]{this}, -13458657, iC3)).booleanValue();
            throw null;
        }
        int iC4 = bd.d.c();
        int iC5 = bd.d.c();
        int iC6 = bd.d.c();
        if (((Boolean) d(iC4, 13458657, bd.d.c(), iC5, new Object[]{this}, -13458657, iC6)).booleanValue()) {
            return e().intValue();
        }
        int i2 = Integer.parseInt(c());
        int i3 = j + 29;
        f = i3 % 128;
        if (i3 % 2 != 0) {
            return i2;
        }
        throw null;
    }

    @Override // com.facetec.sdk.es
    public final double b() {
        int i = f + 89;
        j = i % 128;
        int i2 = i % 2;
        Object[] objArr = {this};
        int iC = bd.d.c();
        int iC2 = bd.d.c();
        int iC3 = bd.d.c();
        int iC4 = bd.d.c();
        if (i2 != 0) {
            ((Boolean) d(iC, 13458657, iC4, iC2, objArr, -13458657, iC3)).booleanValue();
            throw null;
        }
        if (((Boolean) d(iC, 13458657, iC4, iC2, objArr, -13458657, iC3)).booleanValue()) {
            return e().doubleValue();
        }
        double d2 = Double.parseDouble(c());
        int i3 = f + 89;
        j = i3 % 128;
        if (i3 % 2 == 0) {
            return d2;
        }
        throw null;
    }

    @Override // com.facetec.sdk.es
    public final Number e() {
        int i = f + 85;
        j = i % 128;
        if (i % 2 != 0) {
            throw null;
        }
        Object obj = this.c;
        if (obj instanceof Number) {
            return (Number) obj;
        }
        if (!(obj instanceof String)) {
            throw new UnsupportedOperationException("Primitive is neither a number nor a string");
        }
        fp fpVar = new fp((String) obj);
        f = (j + 77) % 128;
        return fpVar;
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj != null) {
            int i = f + 3;
            j = i % 128;
            if (i % 2 != 0) {
                obj.getClass();
                throw null;
            }
            if (eu.class == obj.getClass()) {
                eu euVar = (eu) obj;
                if (this.c == null) {
                    return euVar.c == null;
                }
                if (((Boolean) d(bd.d.c(), 236756225, bd.d.c(), bd.d.c(), new Object[]{this}, -236756224, bd.d.c())).booleanValue()) {
                    if (((Boolean) d(bd.d.c(), 236756225, bd.d.c(), bd.d.c(), new Object[]{euVar}, -236756224, bd.d.c())).booleanValue()) {
                        f = (j + 55) % 128;
                        return e().longValue() == euVar.e().longValue();
                    }
                }
                Object obj2 = this.c;
                if ((obj2 instanceof Number) && (euVar.c instanceof Number)) {
                    double dDoubleValue = e().doubleValue();
                    double dDoubleValue2 = euVar.e().doubleValue();
                    return dDoubleValue == dDoubleValue2 || (Double.isNaN(dDoubleValue) && Double.isNaN(dDoubleValue2));
                }
                boolean zEquals = obj2.equals(euVar.c);
                int i2 = f + 37;
                j = i2 % 128;
                if (i2 % 2 == 0) {
                    return zEquals;
                }
                throw null;
            }
        }
        return false;
    }

    public final boolean h() {
        int i = j;
        boolean z = this.c instanceof Boolean;
        int i2 = i + 35;
        f = i2 % 128;
        if (i2 % 2 != 0) {
            return z;
        }
        throw null;
    }

    public final int hashCode() {
        if (this.c == null) {
            f = (j + 83) % 128;
            return 31;
        }
        int iC = bd.d.c();
        int iC2 = bd.d.c();
        int iC3 = bd.d.c();
        if (((Boolean) d(iC, 236756225, bd.d.c(), iC2, new Object[]{this}, -236756224, iC3)).booleanValue()) {
            long jLongValue = e().longValue();
            int i = (int) (jLongValue ^ (jLongValue >>> 32));
            f = (j + 31) % 128;
            return i;
        }
        Object obj = this.c;
        if (!(obj instanceof Number)) {
            return obj.hashCode();
        }
        long jDoubleToLongBits = Double.doubleToLongBits(e().doubleValue());
        return (int) (jDoubleToLongBits ^ (jDoubleToLongBits >>> 32));
    }

    @Override // com.facetec.sdk.es
    public final boolean i() {
        int i = j + 37;
        f = i % 128;
        if (i % 2 == 0) {
            h();
            throw null;
        }
        if (!h()) {
            return Boolean.parseBoolean(c());
        }
        boolean zBooleanValue = ((Boolean) this.c).booleanValue();
        f = (j + 23) % 128;
        return zBooleanValue;
    }

    public final boolean k() {
        int i = j + 23;
        f = i % 128;
        if (i % 2 != 0) {
            return this.c instanceof String;
        }
        throw null;
    }

    public final boolean o() {
        int iC = bd.d.c();
        int iC2 = bd.d.c();
        int iC3 = bd.d.c();
        return ((Boolean) d(iC, 13458657, bd.d.c(), iC2, new Object[]{this}, -13458657, iC3)).booleanValue();
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r24v10 */
    /* JADX WARN: Type inference failed for: r24v12 */
    /* JADX WARN: Type inference failed for: r24v14 */
    /* JADX WARN: Type inference failed for: r24v7, types: [long] */
    /* JADX WARN: Type inference failed for: r24v8 */
    /* JADX WARN: Type inference failed for: r24v9 */
    /*  JADX ERROR: NoSuchElementException in pass: ReplaceNewArray
        java.util.NoSuchElementException
        	at java.base/java.util.TreeMap.key(TreeMap.java:1637)
        	at java.base/java.util.TreeMap.lastKey(TreeMap.java:309)
        	at jadx.core.dex.visitors.ReplaceNewArray.processNewArray(ReplaceNewArray.java:171)
        	at jadx.core.dex.visitors.ReplaceNewArray.processInsn(ReplaceNewArray.java:72)
        	at jadx.core.dex.visitors.ReplaceNewArray.visit(ReplaceNewArray.java:53)
        */
    public static java.lang.Object[] a(int r33, int r34) {
        /*
            Method dump skipped, instruction units count: 2660
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: com.facetec.sdk.eu.a(int, int):java.lang.Object[]");
    }

    private static boolean b(eu euVar) {
        int iC = bd.d.c();
        int iC2 = bd.d.c();
        int iC3 = bd.d.c();
        return ((Boolean) d(iC, 236756225, bd.d.c(), iC2, new Object[]{euVar}, -236756224, iC3)).booleanValue();
    }

    @Override // com.facetec.sdk.es
    public final String c() {
        int i = j;
        f = (i + 111) % 128;
        Object obj = this.c;
        if (obj instanceof String) {
            String str = (String) obj;
            int i2 = i + 115;
            f = i2 % 128;
            if (i2 % 2 == 0) {
                int i3 = 29 / 0;
            }
            return str;
        }
        int iC = bd.d.c();
        int iC2 = bd.d.c();
        int iC3 = bd.d.c();
        if (((Boolean) d(iC, 13458657, bd.d.c(), iC2, new Object[]{this}, -13458657, iC3)).booleanValue()) {
            return e().toString();
        }
        if (h()) {
            return ((Boolean) this.c).toString();
        }
        StringBuilder sb = new StringBuilder("Unexpected value type: ");
        sb.append(this.c.getClass());
        throw new AssertionError(sb.toString());
    }

    @Override // com.facetec.sdk.es
    public final long d() {
        int i = j + 85;
        f = i % 128;
        int i2 = i % 2;
        Object[] objArr = {this};
        int iC = bd.d.c();
        int iC2 = bd.d.c();
        int iC3 = bd.d.c();
        int iC4 = bd.d.c();
        if (i2 == 0) {
            ((Boolean) d(iC, 13458657, iC4, iC2, objArr, -13458657, iC3)).booleanValue();
            throw null;
        }
        if (!((Boolean) d(iC, 13458657, iC4, iC2, objArr, -13458657, iC3)).booleanValue()) {
            return Long.parseLong(c());
        }
        int i3 = f + EnumC41897g.SDK_ASSET_ILLUSTRATION_CALENDAR_VALUE;
        j = i3 % 128;
        if (i3 % 2 == 0) {
            return e().longValue();
        }
        e().longValue();
        throw null;
    }

    public eu(Number number) {
        Objects.requireNonNull(number);
        this.c = number;
    }

    private static /* synthetic */ Object d(Object[] objArr) {
        Object obj = ((eu) objArr[0]).c;
        if (!(obj instanceof Number)) {
            return Boolean.FALSE;
        }
        int i = f;
        j = (i + 49) % 128;
        Number number = (Number) obj;
        if (!(number instanceof BigInteger) && !(number instanceof Long)) {
            int i2 = i + 93;
            j = i2 % 128;
            if (i2 % 2 == 0) {
                if (!(number instanceof Integer)) {
                    j = (i + 55) % 128;
                    if (!(number instanceof Short) && !(number instanceof Byte)) {
                        return Boolean.FALSE;
                    }
                }
            } else {
                throw null;
            }
        }
        int i3 = j + 99;
        f = i3 % 128;
        if (i3 % 2 != 0) {
            return Boolean.TRUE;
        }
        throw null;
    }

    public eu(String str) {
        Objects.requireNonNull(str);
        this.c = str;
    }
}