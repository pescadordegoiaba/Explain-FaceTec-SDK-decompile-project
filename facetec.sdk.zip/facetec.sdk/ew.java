package com.facetec.sdk;

/* JADX INFO: loaded from: classes4.dex */
public class ew extends RuntimeException {
    public ew(String str) {
        super(str);
    }

    public ew(String str, Throwable th) {
        super(str, th);
    }

    public ew(Throwable th) {
        super(th);
    }
}