package com.facetec.sdk;

/* JADX INFO: loaded from: classes4.dex */
public final class ex extends es {
    public static final ex e = new ex();

    @Deprecated
    public ex() {
    }

    public final boolean equals(Object obj) {
        return this == obj || (obj instanceof ex);
    }

    public final int hashCode() {
        return ex.class.hashCode();
    }
}