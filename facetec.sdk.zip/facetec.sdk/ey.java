package com.facetec.sdk;

import java.util.Map;
import java.util.Set;

/* JADX INFO: loaded from: classes4.dex */
public final class ey extends es {
    private final fs<String, es> e = new fs<>((byte) 0);

    public final void a(String str, es esVar) {
        fs<String, es> fsVar = this.e;
        if (esVar == null) {
            esVar = ex.e;
        }
        fsVar.put(str, esVar);
    }

    public final void b(String str, Number number) {
        a(str, number == null ? ex.e : new eu(number));
    }

    public final void c(String str, String str2) {
        a(str, str2 == null ? ex.e : new eu(str2));
    }

    public final boolean equals(Object obj) {
        if (obj != this) {
            return (obj instanceof ey) && ((ey) obj).e.equals(this.e);
        }
        return true;
    }

    public final Set<Map.Entry<String, es>> h() {
        return this.e.entrySet();
    }

    public final int hashCode() {
        return this.e.hashCode();
    }
}