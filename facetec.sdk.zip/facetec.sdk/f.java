package com.facetec.sdk;

import android.animation.Animator;

/* JADX INFO: loaded from: classes4.dex */
@FunctionalInterface
interface f extends Animator.AnimatorListener {
    @Override // android.animation.Animator.AnimatorListener
    default void onAnimationCancel(Animator animator) {
    }

    @Override // android.animation.Animator.AnimatorListener
    default void onAnimationRepeat(Animator animator) {
    }

    @Override // android.animation.Animator.AnimatorListener
    default void onAnimationStart(Animator animator) {
    }
}