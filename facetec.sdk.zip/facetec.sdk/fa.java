package com.facetec.sdk;

import java.math.BigDecimal;

/* JADX INFO: loaded from: classes4.dex */
public enum fa implements ez {
    DOUBLE { // from class: com.facetec.sdk.fa.5
        @Override // com.facetec.sdk.ez
        public final /* synthetic */ Number c(gs gsVar) {
            return Double.valueOf(gsVar.o());
        }
    },
    LAZILY_PARSED_NUMBER { // from class: com.facetec.sdk.fa.1
        @Override // com.facetec.sdk.ez
        public final Number c(gs gsVar) {
            return new fp(gsVar.h());
        }
    },
    LONG_OR_DOUBLE { // from class: com.facetec.sdk.fa.4
        @Override // com.facetec.sdk.ez
        public final Number c(gs gsVar) throws gz {
            String strH = gsVar.h();
            try {
                try {
                    return Long.valueOf(Long.parseLong(strH));
                } catch (NumberFormatException e) {
                    StringBuilder sb = new StringBuilder("Cannot parse ");
                    sb.append(strH);
                    sb.append("; at path ");
                    sb.append(gsVar.q());
                    throw new ew(sb.toString(), e);
                }
            } catch (NumberFormatException unused) {
                Double dValueOf = Double.valueOf(strH);
                if (dValueOf.isInfinite() || dValueOf.isNaN()) {
                    if (!gsVar.t()) {
                        StringBuilder sb2 = new StringBuilder("JSON forbids NaN and infinities: ");
                        sb2.append(dValueOf);
                        sb2.append("; at path ");
                        sb2.append(gsVar.q());
                        throw new gz(sb2.toString());
                    }
                }
                return dValueOf;
            }
        }
    },
    BIG_DECIMAL { // from class: com.facetec.sdk.fa.3
        private static BigDecimal e(gs gsVar) {
            String strH = gsVar.h();
            try {
                return new BigDecimal(strH);
            } catch (NumberFormatException e) {
                StringBuilder sb = new StringBuilder("Cannot parse ");
                sb.append(strH);
                sb.append("; at path ");
                sb.append(gsVar.q());
                throw new ew(sb.toString(), e);
            }
        }

        @Override // com.facetec.sdk.ez
        public final /* synthetic */ Number c(gs gsVar) {
            return e(gsVar);
        }
    };

    /* synthetic */ fa(byte b) {
        this();
    }
}