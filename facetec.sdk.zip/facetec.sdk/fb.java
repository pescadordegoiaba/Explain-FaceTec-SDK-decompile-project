package com.facetec.sdk;

/* JADX INFO: loaded from: classes4.dex */
public interface fb {

    /* JADX INFO: renamed from: com.facetec.sdk.fb$2, reason: invalid class name */
    public class AnonymousClass2 implements fb {
        @Override // com.facetec.sdk.fb
        public final a a(Class<?> cls) {
            return fv.d(cls) ? a.BLOCK_INACCESSIBLE : a.INDECISIVE;
        }
    }

    /* JADX INFO: renamed from: com.facetec.sdk.fb$3, reason: invalid class name */
    public class AnonymousClass3 implements fb {
        @Override // com.facetec.sdk.fb
        public final a a(Class<?> cls) {
            return fv.d(cls.getName()) ? a.BLOCK_ALL : a.INDECISIVE;
        }
    }

    /* JADX INFO: renamed from: com.facetec.sdk.fb$4, reason: invalid class name */
    public class AnonymousClass4 implements fb {
        @Override // com.facetec.sdk.fb
        public final a a(Class<?> cls) {
            return fv.d(cls) ? a.BLOCK_ALL : a.INDECISIVE;
        }
    }

    /* JADX INFO: renamed from: com.facetec.sdk.fb$5, reason: invalid class name */
    public class AnonymousClass5 implements fb {
        @Override // com.facetec.sdk.fb
        public final a a(Class<?> cls) {
            String name = cls.getName();
            return (fv.d(name) || name.startsWith("kotlin.") || name.startsWith("kotlinx.") || name.startsWith("scala.")) ? a.BLOCK_ALL : a.INDECISIVE;
        }
    }

    public enum a {
        ALLOW,
        INDECISIVE,
        BLOCK_INACCESSIBLE,
        BLOCK_ALL
    }

    a a(Class<?> cls);
}