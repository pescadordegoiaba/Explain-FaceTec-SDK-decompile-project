package com.facetec.sdk;

import android.graphics.Color;
import android.graphics.PointF;
import android.os.Process;
import android.text.TextUtils;
import android.view.ViewConfiguration;
import android.widget.ExpandableListView;
import com.incode.welcome_sdk.modules.SelfieScan;
import com.plaid.internal.EnumC41897g;
import java.lang.reflect.Method;
import net.sf.scuba.smartcards.ISO7816;

/* JADX INFO: loaded from: classes4.dex */
public final class fc extends ew {
    private static final byte[] $$a = null;
    private static final int $$b = 0;
    private static final byte[] $$c = null;
    private static final int $$d = 0;
    private static int $10;
    private static int $11;
    private static char a;
    private static char b;
    private static char c;
    private static char d;
    private static int e;
    private static int j;

    /* JADX WARN: Removed duplicated region for block: B:10:0x0028  */
    /* JADX WARN: Removed duplicated region for block: B:8:0x0022  */
    /* JADX WARN: Unsupported multi-entry loop pattern (BACK_EDGE: B:10:0x0028 -> B:11:0x002c). Please report as a decompilation issue!!! */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    private static java.lang.String $$e(int r5, int r6, int r7) {
        /*
            int r5 = r5 * 2
            int r5 = 3 - r5
            int r7 = r7 * 2
            int r7 = 112 - r7
            byte[] r0 = com.facetec.sdk.fc.$$c
            int r6 = r6 * 2
            int r1 = r6 + 1
            byte[] r1 = new byte[r1]
            r2 = 0
            if (r0 != 0) goto L17
            r7 = r5
            r3 = r6
            r4 = r2
            goto L2c
        L17:
            r3 = r7
            r7 = r5
            r5 = r3
            r3 = r2
        L1b:
            byte r4 = (byte) r5
            r1[r3] = r4
            int r4 = r3 + 1
            if (r3 != r6) goto L28
            java.lang.String r5 = new java.lang.String
            r5.<init>(r1, r2)
            return r5
        L28:
            int r7 = r7 + 1
            r3 = r0[r7]
        L2c:
            int r5 = r5 + r3
            r3 = r4
            goto L1b
        */
        throw new UnsupportedOperationException("Method not decompiled: com.facetec.sdk.fc.$$e(int, int, int):java.lang.String");
    }

    static {
        init$1();
        $10 = 0;
        $11 = 1;
        init$0();
        e = 0;
        j = 1;
        b = (char) 56595;
        a = (char) 4884;
        c = (char) 29619;
        d = (char) 32920;
    }

    public fc(String str) {
        super(str);
    }

    /*  JADX ERROR: NoSuchElementException in pass: ReplaceNewArray
        java.util.NoSuchElementException
        	at java.base/java.util.TreeMap.key(TreeMap.java:1637)
        	at java.base/java.util.TreeMap.lastKey(TreeMap.java:309)
        	at jadx.core.dex.visitors.ReplaceNewArray.processNewArray(ReplaceNewArray.java:171)
        	at jadx.core.dex.visitors.ReplaceNewArray.processInsn(ReplaceNewArray.java:72)
        	at jadx.core.dex.visitors.ReplaceNewArray.visit(ReplaceNewArray.java:53)
        */
    public static java.lang.Object[] b(android.content.Context r28, int r29, int r30, int r31) {
        /*
            Method dump skipped, instruction units count: 1601
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: com.facetec.sdk.fc.b(android.content.Context, int, int, int):java.lang.Object[]");
    }

    private static void f(String str, int i, Object[] objArr) throws Throwable {
        char[] charArray = str != null ? str.toCharArray() : str;
        hq hqVar = new hq();
        char[] cArr = new char[charArray.length];
        hqVar.d = 0;
        int i2 = 2;
        char[] cArr2 = new char[2];
        while (true) {
            int i3 = hqVar.d;
            if (i3 >= charArray.length) {
                break;
            }
            $10 = ($11 + 21) % 128;
            cArr2[0] = charArray[i3];
            char c2 = 1;
            cArr2[1] = charArray[i3 + 1];
            int i4 = 58224;
            int i5 = 0;
            while (i5 < 16) {
                char c3 = cArr2[c2];
                char c4 = cArr2[0];
                char c5 = c2;
                int i6 = i2;
                char[] cArr3 = cArr2;
                int i7 = (c4 + i4) ^ ((c4 << 4) + ((char) (((long) c) ^ (-5528393735828501205L))));
                int i8 = c4 >>> 5;
                try {
                    Object[] objArr2 = new Object[4];
                    objArr2[3] = Integer.valueOf(d);
                    objArr2[i6] = Integer.valueOf(i8);
                    objArr2[c5] = Integer.valueOf(i7);
                    objArr2[0] = Integer.valueOf(c3);
                    Object objD = an.d(681770103);
                    Class cls = Integer.TYPE;
                    if (objD == null) {
                        objD = an.d(Process.getGidForName("") + 358, (char) (PointF.length(SelfieScan.RECOGNITION_FAIL_RESULT, SelfieScan.RECOGNITION_FAIL_RESULT) > SelfieScan.RECOGNITION_FAIL_RESULT ? 1 : (PointF.length(SelfieScan.RECOGNITION_FAIL_RESULT, SelfieScan.RECOGNITION_FAIL_RESULT) == SelfieScan.RECOGNITION_FAIL_RESULT ? 0 : -1)), 24 - Color.blue(0), 1589849900, false, "s", new Class[]{cls, cls, cls, cls});
                    }
                    char cCharValue = ((Character) ((Method) objD).invoke(null, objArr2)).charValue();
                    cArr3[c5] = cCharValue;
                    char c6 = cArr3[0];
                    int i9 = (cCharValue + i4) ^ ((cCharValue << 4) + ((char) (((long) b) ^ (-5528393735828501205L))));
                    int i10 = cCharValue >>> 5;
                    Object[] objArr3 = new Object[4];
                    objArr3[3] = Integer.valueOf(a);
                    objArr3[i6] = Integer.valueOf(i10);
                    objArr3[c5] = Integer.valueOf(i9);
                    objArr3[0] = Integer.valueOf(c6);
                    Object objD2 = an.d(681770103);
                    if (objD2 == null) {
                        objD2 = an.d((ExpandableListView.getPackedPositionForGroup(0) > 0L ? 1 : (ExpandableListView.getPackedPositionForGroup(0) == 0L ? 0 : -1)) + 357, (char) (ViewConfiguration.getKeyRepeatDelay() >> 16), 24 - TextUtils.getOffsetBefore("", 0), 1589849900, false, "s", new Class[]{cls, cls, cls, cls});
                    }
                    cArr3[0] = ((Character) ((Method) objD2).invoke(null, objArr3)).charValue();
                    i4 -= 40503;
                    i5++;
                    c2 = c5;
                    i2 = i6;
                    cArr2 = cArr3;
                } catch (Throwable th) {
                    Throwable cause = th.getCause();
                    if (cause == null) {
                        throw th;
                    }
                    throw cause;
                }
            }
            int i11 = i2;
            char[] cArr4 = cArr2;
            char c7 = c2;
            int i12 = hqVar.d;
            cArr[i12] = cArr4[0];
            cArr[i12 + 1] = cArr4[c7];
            Object[] objArr4 = new Object[i11];
            objArr4[c7] = hqVar;
            objArr4[0] = hqVar;
            Object objD3 = an.d(227457195);
            if (objD3 == null) {
                byte b2 = (byte) 0;
                byte b3 = b2;
                objD3 = an.d(1827 - (ViewConfiguration.getScrollBarFadeDuration() >> 16), (char) ((-16777216) - Color.rgb(0, 0, 0)), (PointF.length(SelfieScan.RECOGNITION_FAIL_RESULT, SelfieScan.RECOGNITION_FAIL_RESULT) > SelfieScan.RECOGNITION_FAIL_RESULT ? 1 : (PointF.length(SelfieScan.RECOGNITION_FAIL_RESULT, SelfieScan.RECOGNITION_FAIL_RESULT) == SelfieScan.RECOGNITION_FAIL_RESULT ? 0 : -1)) + 24, 2079288304, false, $$e(b2, b3, b3), new Class[]{Object.class, Object.class});
            }
            ((Method) objD3).invoke(null, objArr4);
            cArr2 = cArr4;
            i2 = 2;
        }
        String str2 = new String(cArr, 0, i);
        int i13 = $10 + 63;
        $11 = i13 % 128;
        if (i13 % 2 == 0) {
            throw null;
        }
        objArr[0] = str2;
    }

    /* JADX WARN: Removed duplicated region for block: B:10:0x0028  */
    /* JADX WARN: Removed duplicated region for block: B:8:0x0020  */
    /* JADX WARN: Unsupported multi-entry loop pattern (BACK_EDGE: B:10:0x0028 -> B:11:0x002d). Please report as a decompilation issue!!! */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    private static void g(int r6, int r7, int r8, java.lang.Object[] r9) {
        /*
            int r8 = r8 * 2
            int r8 = r8 + 4
            byte[] r0 = com.facetec.sdk.fc.$$a
            int r7 = r7 + 98
            int r6 = r6 * 2
            int r6 = r6 + 1
            byte[] r1 = new byte[r6]
            r2 = 0
            if (r0 != 0) goto L15
            r4 = r6
            r7 = r8
            r3 = r2
            goto L2d
        L15:
            r3 = r8
            r8 = r7
            r7 = r3
            r3 = r2
        L19:
            byte r4 = (byte) r8
            r1[r3] = r4
            int r3 = r3 + 1
            if (r3 != r6) goto L28
            java.lang.String r6 = new java.lang.String
            r6.<init>(r1, r2)
            r9[r2] = r6
            return
        L28:
            r4 = r0[r7]
            r5 = r8
            r8 = r7
            r7 = r5
        L2d:
            int r8 = r8 + 1
            int r7 = r7 + r4
            r5 = r8
            r8 = r7
            r7 = r5
            goto L19
        */
        throw new UnsupportedOperationException("Method not decompiled: com.facetec.sdk.fc.g(int, int, int, java.lang.Object[]):void");
    }

    public static void init$0() {
        $$a = new byte[]{ISO7816.INS_INCREASE, -82, -81, 124};
        $$b = 10;
    }

    public static void init$1() {
        $$c = new byte[]{9, 8, ISO7816.INS_MANAGE_CHANNEL, 107};
        $$d = EnumC41897g.SDK_ASSET_ICON_ALERT_ERROR_BLACK_VALUE;
    }

    public fc(String str, Throwable th) {
        super(str, th);
    }

    public fc(Throwable th) {
        super(th);
    }
}