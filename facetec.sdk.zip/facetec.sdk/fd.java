package com.facetec.sdk;

/* JADX INFO: loaded from: classes4.dex */
public enum fd {
    DEFAULT { // from class: com.facetec.sdk.fd.5
    },
    STRING { // from class: com.facetec.sdk.fd.4
    };

    /* synthetic */ fd(byte b2) {
        this();
    }
}