package com.facetec.sdk;

/* JADX INFO: loaded from: classes4.dex */
public interface ff {
    <T> fg<T> b(el elVar, gu<T> guVar);
}