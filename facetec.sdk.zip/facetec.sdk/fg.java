package com.facetec.sdk;

import java.io.IOException;

/* JADX INFO: loaded from: classes4.dex */
public abstract class fg<T> {
    public final es a(T t) {
        try {
            gf gfVar = new gf();
            e(gfVar, t);
            return gfVar.d();
        } catch (IOException e) {
            throw new er(e);
        }
    }

    public abstract T a(gs gsVar);

    public final fg<T> b() {
        return new fg<T>() { // from class: com.facetec.sdk.fg.5
            @Override // com.facetec.sdk.fg
            public final T a(gs gsVar) {
                if (gsVar.j() != gw.NULL) {
                    return (T) fg.this.a(gsVar);
                }
                gsVar.m();
                return null;
            }

            @Override // com.facetec.sdk.fg
            public final void e(ha haVar, T t) {
                if (t == null) {
                    haVar.g();
                } else {
                    fg.this.e(haVar, t);
                }
            }
        };
    }

    public abstract void e(ha haVar, T t);
}