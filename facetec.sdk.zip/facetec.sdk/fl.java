package com.facetec.sdk;

/* JADX INFO: loaded from: classes4.dex */
public final class fl {
    public static void c(boolean z) {
        if (!z) {
            throw new IllegalArgumentException();
        }
    }
}