package com.facetec.sdk;

import ai.luciq.library.logging.LuciqLog;
import java.io.Serializable;
import java.lang.reflect.Array;
import java.lang.reflect.GenericArrayType;
import java.lang.reflect.GenericDeclaration;
import java.lang.reflect.Modifier;
import java.lang.reflect.ParameterizedType;
import java.lang.reflect.Type;
import java.lang.reflect.TypeVariable;
import java.lang.reflect.WildcardType;
import java.util.Arrays;
import java.util.Collection;
import java.util.HashMap;
import java.util.Map;
import java.util.NoSuchElementException;
import java.util.Objects;
import java.util.Properties;

/* JADX INFO: loaded from: classes4.dex */
public final class fm {
    private static /* synthetic */ boolean a = true;
    static final Type[] b = new Type[0];

    public static final class a implements Serializable, ParameterizedType {
        private final Type a;
        private final Type c;
        private final Type[] e;

        public a(Type type, Type type2, Type... typeArr) {
            Objects.requireNonNull(type2);
            if (type2 instanceof Class) {
                Class cls = (Class) type2;
                boolean z = true;
                boolean z2 = Modifier.isStatic(cls.getModifiers()) || cls.getEnclosingClass() == null;
                if (type == null && !z2) {
                    z = false;
                }
                fl.c(z);
            }
            this.c = type == null ? null : fm.a(type);
            this.a = fm.a(type2);
            Type[] typeArr2 = (Type[]) typeArr.clone();
            this.e = typeArr2;
            int length = typeArr2.length;
            for (int i = 0; i < length; i++) {
                Objects.requireNonNull(this.e[i]);
                fm.c(this.e[i]);
                Type[] typeArr3 = this.e;
                typeArr3[i] = fm.a(typeArr3[i]);
            }
        }

        public final boolean equals(Object obj) {
            return (obj instanceof ParameterizedType) && fm.e(this, (ParameterizedType) obj);
        }

        @Override // java.lang.reflect.ParameterizedType
        public final Type[] getActualTypeArguments() {
            return (Type[]) this.e.clone();
        }

        @Override // java.lang.reflect.ParameterizedType
        public final Type getOwnerType() {
            return this.c;
        }

        @Override // java.lang.reflect.ParameterizedType
        public final Type getRawType() {
            return this.a;
        }

        public final int hashCode() {
            int iHashCode = Arrays.hashCode(this.e) ^ this.a.hashCode();
            Type type = this.c;
            return iHashCode ^ (type != null ? type.hashCode() : 0);
        }

        public final String toString() {
            int length = this.e.length;
            if (length == 0) {
                return fm.d(this.a);
            }
            StringBuilder sb = new StringBuilder((length + 1) * 30);
            sb.append(fm.d(this.a));
            sb.append("<");
            sb.append(fm.d(this.e[0]));
            for (int i = 1; i < length; i++) {
                sb.append(", ");
                sb.append(fm.d(this.e[i]));
            }
            sb.append(">");
            return sb.toString();
        }
    }

    public static final class d implements Serializable, WildcardType {
        private final Type c;
        private final Type d;

        public d(Type[] typeArr, Type[] typeArr2) {
            fl.c(typeArr2.length <= 1);
            fl.c(typeArr.length == 1);
            if (typeArr2.length != 1) {
                Objects.requireNonNull(typeArr[0]);
                fm.c(typeArr[0]);
                this.c = null;
                this.d = fm.a(typeArr[0]);
                return;
            }
            Objects.requireNonNull(typeArr2[0]);
            fm.c(typeArr2[0]);
            fl.c(typeArr[0] == Object.class);
            this.c = fm.a(typeArr2[0]);
            this.d = Object.class;
        }

        public final boolean equals(Object obj) {
            return (obj instanceof WildcardType) && fm.e(this, (WildcardType) obj);
        }

        @Override // java.lang.reflect.WildcardType
        public final Type[] getLowerBounds() {
            Type type = this.c;
            return type != null ? new Type[]{type} : fm.b;
        }

        @Override // java.lang.reflect.WildcardType
        public final Type[] getUpperBounds() {
            return new Type[]{this.d};
        }

        public final int hashCode() {
            Type type = this.c;
            return (type != null ? type.hashCode() + 31 : 1) ^ (this.d.hashCode() + 31);
        }

        public final String toString() {
            if (this.c != null) {
                StringBuilder sb = new StringBuilder("? super ");
                sb.append(fm.d(this.c));
                return sb.toString();
            }
            if (this.d == Object.class) {
                return "?";
            }
            StringBuilder sb2 = new StringBuilder("? extends ");
            sb2.append(fm.d(this.d));
            return sb2.toString();
        }
    }

    public static final class e implements Serializable, GenericArrayType {
        private final Type b;

        public e(Type type) {
            Objects.requireNonNull(type);
            this.b = fm.a(type);
        }

        public final boolean equals(Object obj) {
            return (obj instanceof GenericArrayType) && fm.e(this, (GenericArrayType) obj);
        }

        @Override // java.lang.reflect.GenericArrayType
        public final Type getGenericComponentType() {
            return this.b;
        }

        public final int hashCode() {
            return this.b.hashCode();
        }

        public final String toString() {
            StringBuilder sb = new StringBuilder();
            sb.append(fm.d(this.b));
            sb.append("[]");
            return sb.toString();
        }
    }

    private fm() {
        throw new UnsupportedOperationException();
    }

    private static ParameterizedType a(Type type, Type type2, Type... typeArr) {
        return new a(type, type2, typeArr);
    }

    public static Class<?> b(Type type) {
        while (!(type instanceof Class)) {
            if (type instanceof ParameterizedType) {
                Type rawType = ((ParameterizedType) type).getRawType();
                fl.c(rawType instanceof Class);
                return (Class) rawType;
            }
            if (type instanceof GenericArrayType) {
                return Array.newInstance(b(((GenericArrayType) type).getGenericComponentType()), 0).getClass();
            }
            if (type instanceof TypeVariable) {
                return Object.class;
            }
            if (!(type instanceof WildcardType)) {
                String name = type == null ? LuciqLog.LogMessage.NULL_LOG : type.getClass().getName();
                StringBuilder sb = new StringBuilder("Expected a Class, ParameterizedType, or GenericArrayType, but <");
                sb.append(type);
                sb.append("> is of type ");
                sb.append(name);
                throw new IllegalArgumentException(sb.toString());
            }
            Type[] upperBounds = ((WildcardType) type).getUpperBounds();
            if (!a && upperBounds.length != 1) {
                throw new AssertionError();
            }
            type = upperBounds[0];
        }
        return (Class) type;
    }

    /* JADX WARN: Removed duplicated region for block: B:19:0x0037 A[LOOP:2: B:19:0x0037->B:28:0x0051, LOOP_START, PHI: r5
      0x0037: PHI (r5v2 java.lang.Class<?>) = (r5v1 java.lang.Class<?>), (r5v4 java.lang.Class<?>) binds: [B:18:0x0035, B:28:0x0051] A[DONT_GENERATE, DONT_INLINE]] */
    /* JADX WARN: Removed duplicated region for block: B:32:0x0053 A[SYNTHETIC] */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    private static java.lang.reflect.Type c(java.lang.reflect.Type r4, java.lang.Class<?> r5, java.lang.Class<?> r6) {
        /*
        L0:
            if (r6 != r5) goto L3
            return r4
        L3:
            boolean r4 = r6.isInterface()
            if (r4 == 0) goto L31
            java.lang.Class[] r4 = r5.getInterfaces()
            int r0 = r4.length
            r1 = 0
        Lf:
            if (r1 >= r0) goto L31
            r2 = r4[r1]
            if (r2 != r6) goto L1c
            java.lang.reflect.Type[] r4 = r5.getGenericInterfaces()
            r4 = r4[r1]
            return r4
        L1c:
            boolean r2 = r6.isAssignableFrom(r2)
            if (r2 == 0) goto L2e
            java.lang.reflect.Type[] r5 = r5.getGenericInterfaces()
            r5 = r5[r1]
            r4 = r4[r1]
        L2a:
            r3 = r5
            r5 = r4
            r4 = r3
            goto L0
        L2e:
            int r1 = r1 + 1
            goto Lf
        L31:
            boolean r4 = r5.isInterface()
            if (r4 != 0) goto L53
        L37:
            java.lang.Class<java.lang.Object> r4 = java.lang.Object.class
            if (r5 == r4) goto L53
            java.lang.Class r4 = r5.getSuperclass()
            if (r4 != r6) goto L46
            java.lang.reflect.Type r4 = r5.getGenericSuperclass()
            return r4
        L46:
            boolean r0 = r6.isAssignableFrom(r4)
            if (r0 == 0) goto L51
            java.lang.reflect.Type r5 = r5.getGenericSuperclass()
            goto L2a
        L51:
            r5 = r4
            goto L37
        L53:
            return r6
        */
        throw new UnsupportedOperationException("Method not decompiled: com.facetec.sdk.fm.c(java.lang.reflect.Type, java.lang.Class, java.lang.Class):java.lang.reflect.Type");
    }

    public static String d(Type type) {
        return type instanceof Class ? ((Class) type).getName() : type.toString();
    }

    public static boolean e(Type type, Type type2) {
        while (type != type2) {
            if (type instanceof Class) {
                return type.equals(type2);
            }
            if (type instanceof ParameterizedType) {
                if (!(type2 instanceof ParameterizedType)) {
                    return false;
                }
                ParameterizedType parameterizedType = (ParameterizedType) type;
                ParameterizedType parameterizedType2 = (ParameterizedType) type2;
                return b(parameterizedType.getOwnerType(), parameterizedType2.getOwnerType()) && parameterizedType.getRawType().equals(parameterizedType2.getRawType()) && Arrays.equals(parameterizedType.getActualTypeArguments(), parameterizedType2.getActualTypeArguments());
            }
            if (!(type instanceof GenericArrayType)) {
                if (type instanceof WildcardType) {
                    if (!(type2 instanceof WildcardType)) {
                        return false;
                    }
                    WildcardType wildcardType = (WildcardType) type;
                    WildcardType wildcardType2 = (WildcardType) type2;
                    return Arrays.equals(wildcardType.getUpperBounds(), wildcardType2.getUpperBounds()) && Arrays.equals(wildcardType.getLowerBounds(), wildcardType2.getLowerBounds());
                }
                if (!(type instanceof TypeVariable) || !(type2 instanceof TypeVariable)) {
                    return false;
                }
                TypeVariable typeVariable = (TypeVariable) type;
                TypeVariable typeVariable2 = (TypeVariable) type2;
                return typeVariable.getGenericDeclaration() == typeVariable2.getGenericDeclaration() && typeVariable.getName().equals(typeVariable2.getName());
            }
            if (!(type2 instanceof GenericArrayType)) {
                return false;
            }
            type = ((GenericArrayType) type).getGenericComponentType();
            type2 = ((GenericArrayType) type2).getGenericComponentType();
        }
        return true;
    }

    private static WildcardType f(Type type) {
        return new d(type instanceof WildcardType ? ((WildcardType) type).getUpperBounds() : new Type[]{type}, b);
    }

    private static GenericArrayType g(Type type) {
        return new e(type);
    }

    private static WildcardType j(Type type) {
        return new d(new Type[]{Object.class}, type instanceof WildcardType ? ((WildcardType) type).getLowerBounds() : new Type[]{type});
    }

    public static Type a(Type type) {
        if (type instanceof Class) {
            Class cls = (Class) type;
            boolean zIsArray = cls.isArray();
            Type eVar = cls;
            if (zIsArray) {
                eVar = new e(a(cls.getComponentType()));
            }
            return eVar;
        }
        if (type instanceof ParameterizedType) {
            ParameterizedType parameterizedType = (ParameterizedType) type;
            return new a(parameterizedType.getOwnerType(), parameterizedType.getRawType(), parameterizedType.getActualTypeArguments());
        }
        if (type instanceof GenericArrayType) {
            return new e(((GenericArrayType) type).getGenericComponentType());
        }
        if (!(type instanceof WildcardType)) {
            return type;
        }
        WildcardType wildcardType = (WildcardType) type;
        return new d(wildcardType.getUpperBounds(), wildcardType.getLowerBounds());
    }

    private static Type d(Type type, Class<?> cls, Class<?> cls2) {
        if (type instanceof WildcardType) {
            Type[] upperBounds = ((WildcardType) type).getUpperBounds();
            if (!a && upperBounds.length != 1) {
                throw new AssertionError();
            }
            type = upperBounds[0];
        }
        fl.c(cls2.isAssignableFrom(cls));
        return a(type, cls, c(type, cls, cls2));
    }

    private static Class<?> d(TypeVariable<?> typeVariable) {
        GenericDeclaration genericDeclaration = typeVariable.getGenericDeclaration();
        if (genericDeclaration instanceof Class) {
            return (Class) genericDeclaration;
        }
        return null;
    }

    public static Type[] c(Type type, Class<?> cls) {
        if (type == Properties.class) {
            return new Type[]{String.class, String.class};
        }
        Type typeD = d(type, cls, Map.class);
        if (typeD instanceof ParameterizedType) {
            return ((ParameterizedType) typeD).getActualTypeArguments();
        }
        return new Type[]{Object.class, Object.class};
    }

    public static Type a(Type type, Class<?> cls, Type type2) {
        return c(type, cls, type2, new HashMap());
    }

    private static int a(Object[] objArr, Object obj) {
        int length = objArr.length;
        for (int i = 0; i < length; i++) {
            if (obj.equals(objArr[i])) {
                return i;
            }
        }
        throw new NoSuchElementException();
    }

    private static boolean b(Object obj, Object obj2) {
        if (obj != obj2) {
            return obj != null && obj.equals(obj2);
        }
        return true;
    }

    public static Type b(Type type, Class<?> cls) {
        Type typeD = d(type, cls, Collection.class);
        if (typeD instanceof ParameterizedType) {
            return ((ParameterizedType) typeD).getActualTypeArguments()[0];
        }
        return Object.class;
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Removed duplicated region for block: B:25:0x0048  */
    /* JADX WARN: Type inference failed for: r11v0, types: [java.lang.reflect.Type] */
    /* JADX WARN: Type inference failed for: r11v1, types: [java.lang.reflect.Type] */
    /* JADX WARN: Type inference failed for: r11v10, types: [java.lang.Object, java.lang.reflect.Type] */
    /* JADX WARN: Type inference failed for: r11v11, types: [java.lang.reflect.Type] */
    /* JADX WARN: Type inference failed for: r11v2, types: [java.lang.reflect.WildcardType] */
    /* JADX WARN: Type inference failed for: r11v3, types: [java.lang.reflect.WildcardType] */
    /* JADX WARN: Type inference failed for: r11v4, types: [java.lang.reflect.WildcardType] */
    /* JADX WARN: Type inference failed for: r11v5, types: [java.lang.reflect.ParameterizedType] */
    /* JADX WARN: Type inference failed for: r11v6, types: [java.lang.reflect.GenericArrayType] */
    /* JADX WARN: Type inference failed for: r11v7 */
    /* JADX WARN: Type inference failed for: r11v9 */
    /* JADX WARN: Type inference failed for: r12v0, types: [java.util.Map, java.util.Map<java.lang.reflect.TypeVariable<?>, java.lang.reflect.Type>] */
    /* JADX WARN: Type inference failed for: r1v17 */
    /* JADX WARN: Type inference failed for: r1v19 */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    private static java.lang.reflect.Type c(java.lang.reflect.Type r9, java.lang.Class<?> r10, java.lang.reflect.Type r11, java.util.Map<java.lang.reflect.TypeVariable<?>, java.lang.reflect.Type> r12) {
        /*
            Method dump skipped, instruction units count: 222
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: com.facetec.sdk.fm.c(java.lang.reflect.Type, java.lang.Class, java.lang.reflect.Type, java.util.Map):java.lang.reflect.Type");
    }

    public static Type e(Type type) {
        if (type instanceof GenericArrayType) {
            return ((GenericArrayType) type).getGenericComponentType();
        }
        return ((Class) type).getComponentType();
    }

    private static Type c(Type type, Class<?> cls, TypeVariable<?> typeVariable) {
        Class<?> clsD = d(typeVariable);
        if (clsD != null) {
            Type typeC = c(type, cls, clsD);
            if (typeC instanceof ParameterizedType) {
                return ((ParameterizedType) typeC).getActualTypeArguments()[a(clsD.getTypeParameters(), typeVariable)];
            }
        }
        return typeVariable;
    }

    public static void c(Type type) {
        fl.c(((type instanceof Class) && ((Class) type).isPrimitive()) ? false : true);
    }
}