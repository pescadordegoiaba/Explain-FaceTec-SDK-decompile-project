package com.facetec.sdk;

import android.graphics.Color;
import android.media.AudioTrack;
import android.text.TextUtils;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewConfiguration;
import android.widget.ExpandableListView;
import com.incode.welcome_sdk.modules.SelfieScan;
import java.lang.reflect.Method;

/* JADX INFO: loaded from: classes4.dex */
public final class fo {
    private static final byte[] $$a = null;
    private static final int $$b = 0;
    private static final int c;
    private static char d;
    private static char[] e;

    /* JADX WARN: Removed duplicated region for block: B:10:0x0026  */
    /* JADX WARN: Removed duplicated region for block: B:8:0x0020  */
    /* JADX WARN: Unsupported multi-entry loop pattern (BACK_EDGE: B:10:0x0026 -> B:11:0x002b). Please report as a decompilation issue!!! */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    private static java.lang.String $$c(int r6, byte r7, short r8) {
        /*
            int r8 = r8 * 4
            int r8 = r8 + 4
            int r6 = 116 - r6
            byte[] r0 = com.facetec.sdk.fo.$$a
            int r7 = r7 * 4
            int r7 = r7 + 1
            byte[] r1 = new byte[r7]
            r2 = 0
            if (r0 != 0) goto L15
            r4 = r7
            r6 = r8
            r3 = r2
            goto L2b
        L15:
            r3 = r8
            r8 = r6
            r6 = r3
            r3 = r2
        L19:
            byte r4 = (byte) r8
            r1[r3] = r4
            int r3 = r3 + 1
            if (r3 != r7) goto L26
            java.lang.String r6 = new java.lang.String
            r6.<init>(r1, r2)
            return r6
        L26:
            r4 = r0[r6]
            r5 = r8
            r8 = r6
            r6 = r5
        L2b:
            int r4 = -r4
            int r8 = r8 + 1
            int r6 = r6 + r4
            r5 = r8
            r8 = r6
            r6 = r5
            goto L19
        */
        throw new UnsupportedOperationException("Method not decompiled: com.facetec.sdk.fo.$$c(int, byte, short):java.lang.String");
    }

    static {
        init$0();
        a();
        try {
            Object[] objArr = new Object[1];
            b("\u0011\u0012\f\u0016\u0000\r\u0012\u0013\u0012\u0000\u0003\u0016\u0015\u0014\u0003\u000b", Color.red(0) + 16, (byte) (63 - Color.argb(0, 0, 0, 0)), objArr);
            Class<?> cls = Class.forName((String) objArr[0]);
            Object[] objArr2 = new Object[1];
            b("\u0010\u0000\u0014\u0004\u0007\u0017\u0006\u0000\t\u0017㘍", (ViewConfiguration.getScrollFriction() > SelfieScan.RECOGNITION_FAIL_RESULT ? 1 : (ViewConfiguration.getScrollFriction() == SelfieScan.RECOGNITION_FAIL_RESULT ? 0 : -1)) + 10, (byte) (42 - (ViewConfiguration.getScrollBarSize() >> 8)), objArr2);
            String str = (String) cls.getMethod((String) objArr2[0], String.class).invoke(null, "java.version");
            int iA = a(str);
            if (iA == -1) {
                iA = c(str);
            }
            if (iA == -1) {
                iA = 6;
            }
            c = iA;
        } catch (Throwable th) {
            Throwable cause = th.getCause();
            if (cause == null) {
                throw th;
            }
            throw cause;
        }
    }

    private static int a(String str) {
        try {
            String[] strArrSplit = str.split("[._]");
            int i = Integer.parseInt(strArrSplit[0]);
            return (i != 1 || strArrSplit.length <= 1) ? i : Integer.parseInt(strArrSplit[1]);
        } catch (NumberFormatException unused) {
            return -1;
        }
    }

    private static void b(String str, int i, byte b, Object[] objArr) throws Throwable {
        int i2;
        int i3;
        char c2;
        char c3;
        char c4;
        char c5;
        long j;
        int i4;
        char[] charArray = str != null ? str.toCharArray() : str;
        ho hoVar = new ho();
        char[] cArr = e;
        Class cls = Integer.TYPE;
        long j2 = 0;
        int i5 = -1584280535;
        int i6 = 0;
        if (cArr != null) {
            int length = cArr.length;
            char[] cArr2 = new char[length];
            int i7 = 0;
            while (i7 < length) {
                try {
                    Object[] objArr2 = {Integer.valueOf(cArr[i7])};
                    Object objD = an.d(i5);
                    if (objD == null) {
                        j = j2;
                        byte b2 = (byte) 0;
                        i4 = i5;
                        byte b3 = b2;
                        objD = an.d(2158 - View.MeasureSpec.getMode(0), (char) (1 - (ViewConfiguration.getZoomControlsTimeout() > j2 ? 1 : (ViewConfiguration.getZoomControlsTimeout() == j2 ? 0 : -1))), 23 - (ViewConfiguration.getScrollDefaultDelay() >> 16), -672129166, false, $$c(b2, b3, b3), new Class[]{cls});
                    } else {
                        j = j2;
                        i4 = i5;
                    }
                    cArr2[i7] = ((Character) ((Method) objD).invoke(null, objArr2)).charValue();
                    i7++;
                    i5 = i4;
                    j2 = j;
                } catch (Throwable th) {
                    Throwable cause = th.getCause();
                    if (cause == null) {
                        throw th;
                    }
                    throw cause;
                }
            }
            cArr = cArr2;
        }
        long j3 = j2;
        int i8 = i5;
        Object[] objArr3 = {Integer.valueOf(d)};
        Object objD2 = an.d(i8);
        if (objD2 == null) {
            byte b4 = (byte) 0;
            byte b5 = b4;
            objD2 = an.d(TextUtils.indexOf("", "") + 2158, (char) ((-1) - MotionEvent.axisFromString("")), TextUtils.indexOf("", "") + 23, -672129166, false, $$c(b4, b5, b5), new Class[]{cls});
        }
        char cCharValue = ((Character) ((Method) objD2).invoke(null, objArr3)).charValue();
        char[] cArr3 = new char[i];
        if (i % 2 != 0) {
            i2 = i - 1;
            cArr3[i2] = (char) (charArray[i2] - b);
        } else {
            i2 = i;
        }
        if (i2 > 1) {
            hoVar.b = 0;
            while (true) {
                int i9 = hoVar.b;
                if (i9 >= i2) {
                    break;
                }
                char c6 = charArray[i9];
                hoVar.d = c6;
                char c7 = charArray[i9 + 1];
                hoVar.e = c7;
                if (c6 == c7) {
                    cArr3[i9] = (char) (c6 - b);
                    cArr3[i9 + 1] = (char) (c7 - b);
                } else {
                    Object[] objArr4 = new Object[13];
                    objArr4[12] = hoVar;
                    objArr4[11] = Integer.valueOf(cCharValue);
                    objArr4[10] = hoVar;
                    objArr4[9] = hoVar;
                    objArr4[8] = Integer.valueOf(cCharValue);
                    objArr4[7] = hoVar;
                    objArr4[6] = hoVar;
                    objArr4[5] = Integer.valueOf(cCharValue);
                    objArr4[4] = hoVar;
                    objArr4[3] = hoVar;
                    objArr4[2] = Integer.valueOf(cCharValue);
                    objArr4[1] = hoVar;
                    objArr4[i6] = hoVar;
                    Object objD3 = an.d(945118461);
                    if (objD3 == null) {
                        c2 = '\n';
                        int i10 = (AudioTrack.getMaxVolume() > SelfieScan.RECOGNITION_FAIL_RESULT ? 1 : (AudioTrack.getMaxVolume() == SelfieScan.RECOGNITION_FAIL_RESULT ? 0 : -1)) + 2355;
                        c3 = 2;
                        char c8 = (char) ((-1) - (ExpandableListView.getPackedPositionForChild(i6, i6) > j3 ? 1 : (ExpandableListView.getPackedPositionForChild(i6, i6) == j3 ? 0 : -1)));
                        int iIndexOf = TextUtils.indexOf("", "", i6, i6) + 23;
                        c4 = '\t';
                        byte b6 = (byte) ($$b >>> 2);
                        c5 = 7;
                        byte b7 = (byte) (b6 - 2);
                        i3 = i6;
                        String str$$c = $$c(b6, b7, b7);
                        Class cls2 = Integer.TYPE;
                        objD3 = an.d(i10, c8, iIndexOf, 1312067494, false, str$$c, new Class[]{Object.class, Object.class, cls2, Object.class, Object.class, cls2, Object.class, Object.class, cls2, Object.class, Object.class, cls2, Object.class});
                    } else {
                        i3 = i6;
                        c2 = '\n';
                        c3 = 2;
                        c4 = '\t';
                        c5 = 7;
                    }
                    int iIntValue = ((Integer) ((Method) objD3).invoke(null, objArr4)).intValue();
                    int i11 = hoVar.f95903g;
                    if (iIntValue == i11) {
                        Object[] objArr5 = new Object[11];
                        objArr5[c2] = hoVar;
                        objArr5[c4] = Integer.valueOf(cCharValue);
                        objArr5[8] = hoVar;
                        objArr5[c5] = Integer.valueOf(cCharValue);
                        objArr5[6] = Integer.valueOf(cCharValue);
                        objArr5[5] = hoVar;
                        objArr5[4] = hoVar;
                        objArr5[3] = Integer.valueOf(cCharValue);
                        objArr5[c3] = Integer.valueOf(cCharValue);
                        objArr5[1] = hoVar;
                        objArr5[i3] = hoVar;
                        Object objD4 = an.d(-1909092408);
                        if (objD4 == null) {
                            int i12 = i3;
                            int capsMode = TextUtils.getCapsMode("", i12, i12) + 877;
                            char jumpTapTimeout = (char) (ViewConfiguration.getJumpTapTimeout() >> 16);
                            int keyRepeatDelay = (ViewConfiguration.getKeyRepeatDelay() >> 16) + 24;
                            byte b8 = (byte) ($$b - 5);
                            byte b9 = (byte) (b8 - 3);
                            String str$$c2 = $$c(b8, b9, b9);
                            Class cls3 = Integer.TYPE;
                            objD4 = an.d(capsMode, jumpTapTimeout, keyRepeatDelay, -128689005, false, str$$c2, new Class[]{Object.class, Object.class, cls3, cls3, Object.class, Object.class, cls3, cls3, Object.class, cls3, Object.class});
                        }
                        int iIntValue2 = ((Integer) ((Method) objD4).invoke(null, objArr5)).intValue();
                        int i13 = (hoVar.a * cCharValue) + hoVar.f95903g;
                        int i14 = hoVar.b;
                        cArr3[i14] = cArr[iIntValue2];
                        cArr3[i14 + 1] = cArr[i13];
                    } else {
                        int i15 = hoVar.c;
                        int i16 = hoVar.a;
                        if (i15 == i16) {
                            int i17 = ((hoVar.j + cCharValue) - 1) % cCharValue;
                            hoVar.j = i17;
                            int i18 = ((i11 + cCharValue) - 1) % cCharValue;
                            hoVar.f95903g = i18;
                            int i19 = (i16 * cCharValue) + i18;
                            int i20 = hoVar.b;
                            cArr3[i20] = cArr[(i15 * cCharValue) + i17];
                            cArr3[i20 + 1] = cArr[i19];
                        } else {
                            int i21 = (i15 * cCharValue) + i11;
                            int i22 = (i16 * cCharValue) + hoVar.j;
                            int i23 = hoVar.b;
                            cArr3[i23] = cArr[i21];
                            cArr3[i23 + 1] = cArr[i22];
                            hoVar.b += 2;
                            i6 = 0;
                        }
                    }
                }
                hoVar.b += 2;
                i6 = 0;
            }
        }
        for (int i24 = 0; i24 < i; i24++) {
            cArr3[i24] = (char) (cArr3[i24] ^ 13722);
        }
        objArr[0] = new String(cArr3);
    }

    private static int c(String str) {
        try {
            StringBuilder sb = new StringBuilder();
            for (int i = 0; i < str.length(); i++) {
                char cCharAt = str.charAt(i);
                if (!Character.isDigit(cCharAt)) {
                    break;
                }
                sb.append(cCharAt);
            }
            return Integer.parseInt(sb.toString());
        } catch (NumberFormatException unused) {
            return -1;
        }
    }

    public static boolean d() {
        return c >= 9;
    }

    public static void init$0() {
        $$a = new byte[]{57, 126, 65, 8};
        $$b = 8;
    }

    public static void a() {
        e = new char[]{15057, 15076, 15058, 15023, 15063, 15089, 15056, 15095, 15091, 15060, 15085, 15061, 15050, 15084, 15051, 15078, 15083, 15072, 15087, 15049, 15090, 15062, 15086, 15096, 15093};
        d = (char) 3870;
    }
}