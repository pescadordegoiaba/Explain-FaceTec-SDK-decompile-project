package com.facetec.sdk;

import java.io.InvalidObjectException;
import java.io.ObjectInputStream;
import java.math.BigDecimal;

/* JADX INFO: loaded from: classes4.dex */
public final class fp extends Number {
    private final String e;

    public fp(String str) {
        this.e = str;
    }

    private void readObject(ObjectInputStream objectInputStream) throws InvalidObjectException {
        throw new InvalidObjectException("Deserialization is unsupported");
    }

    private Object writeReplace() {
        return new BigDecimal(this.e);
    }

    @Override // java.lang.Number
    public final double doubleValue() {
        return Double.parseDouble(this.e);
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof fp)) {
            return false;
        }
        String str = this.e;
        String str2 = ((fp) obj).e;
        return str == str2 || str.equals(str2);
    }

    @Override // java.lang.Number
    public final float floatValue() {
        return Float.parseFloat(this.e);
    }

    public final int hashCode() {
        return this.e.hashCode();
    }

    @Override // java.lang.Number
    public final int intValue() {
        try {
            try {
                return Integer.parseInt(this.e);
            } catch (NumberFormatException unused) {
                return new BigDecimal(this.e).intValue();
            }
        } catch (NumberFormatException unused2) {
            return (int) Long.parseLong(this.e);
        }
    }

    @Override // java.lang.Number
    public final long longValue() {
        try {
            return Long.parseLong(this.e);
        } catch (NumberFormatException unused) {
            return new BigDecimal(this.e).longValue();
        }
    }

    public final String toString() {
        return this.e;
    }
}