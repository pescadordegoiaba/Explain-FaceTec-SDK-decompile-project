package com.facetec.sdk;

import java.util.Collections;
import java.util.Iterator;
import java.util.List;

/* JADX INFO: loaded from: classes4.dex */
public final class fq implements ff, Cloneable {
    public static final fq b = new fq();
    public boolean a;
    public List<ei> h;
    public List<ei> i;
    public double d = -1.0d;
    public int e = 136;
    public boolean c = true;

    public fq() {
        List<ei> list = Collections.EMPTY_LIST;
        this.i = list;
        this.h = list;
    }

    /* JADX INFO: Access modifiers changed from: private */
    /* JADX INFO: renamed from: a, reason: merged with bridge method [inline-methods] */
    public fq clone() {
        try {
            return (fq) super.clone();
        } catch (CloneNotSupportedException e) {
            throw new AssertionError(e);
        }
    }

    public static boolean c(Class<?> cls) {
        return cls.isMemberClass() && !b(cls);
    }

    public static boolean d(Class<?> cls) {
        if (Enum.class.isAssignableFrom(cls) || b(cls)) {
            return false;
        }
        return cls.isAnonymousClass() || cls.isLocalClass();
    }

    @Override // com.facetec.sdk.ff
    public final <T> fg<T> b(final el elVar, final gu<T> guVar) {
        boolean zA = a(guVar.d());
        final boolean z = zA || e(true);
        final boolean z2 = zA || e(false);
        if (z || z2) {
            return new fg<T>() { // from class: com.facetec.sdk.fq.4
                private fg<T> b;

                private fg<T> d() {
                    fg<T> fgVar = this.b;
                    if (fgVar != null) {
                        return fgVar;
                    }
                    fg<T> fgVarD = elVar.d(fq.this, guVar);
                    this.b = fgVarD;
                    return fgVarD;
                }

                @Override // com.facetec.sdk.fg
                public final T a(gs gsVar) {
                    if (!z2) {
                        return d().a(gsVar);
                    }
                    gsVar.l();
                    return null;
                }

                @Override // com.facetec.sdk.fg
                public final void e(ha haVar, T t) {
                    if (z) {
                        haVar.g();
                    } else {
                        d().e(haVar, t);
                    }
                }
            };
        }
        return null;
    }

    public final boolean e(boolean z) {
        Iterator<ei> it = (z ? this.i : this.h).iterator();
        while (it.hasNext()) {
            if (it.next().d()) {
                return true;
            }
        }
        return false;
    }

    public final boolean a(Class<?> cls) {
        if (this.d == -1.0d || d((fk) cls.getAnnotation(fk.class), (fj) cls.getAnnotation(fj.class))) {
            return (!this.c && c(cls)) || d(cls);
        }
        return true;
    }

    public final boolean d(fk fkVar, fj fjVar) {
        return e(fkVar) && a(fjVar);
    }

    private boolean e(fk fkVar) {
        if (fkVar != null) {
            return this.d >= fkVar.a();
        }
        return true;
    }

    private boolean a(fj fjVar) {
        if (fjVar != null) {
            return this.d < fjVar.b();
        }
        return true;
    }

    private static boolean b(Class<?> cls) {
        return (cls.getModifiers() & 8) != 0;
    }
}