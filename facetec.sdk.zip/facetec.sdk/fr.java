package com.facetec.sdk;

/* JADX INFO: loaded from: classes4.dex */
public abstract class fr {
    public static fr a;

    public abstract void c(gs gsVar);
}