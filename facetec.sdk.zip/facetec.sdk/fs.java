package com.facetec.sdk;

import android.content.Context;
import com.facetec.sdk.cb;
import com.plaid.internal.EnumC41897g;
import java.io.InvalidObjectException;
import java.io.ObjectInputStream;
import java.io.Serializable;
import java.lang.reflect.Method;
import java.util.AbstractMap;
import java.util.AbstractSet;
import java.util.Comparator;
import java.util.ConcurrentModificationException;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.NoSuchElementException;
import java.util.Set;
import net.sf.scuba.smartcards.ISO7816;
import net.sf.scuba.smartcards.ISOFileInfo;
import org.jmrtd.PassportService;
import org.jmrtd.lds.CVCAFile;

/* JADX INFO: loaded from: classes4.dex */
public final class fs<K, V> extends AbstractMap<K, V> implements Serializable {
    private static final Comparator<Comparable> a = new Comparator<Comparable>() { // from class: com.facetec.sdk.fs.1
        @Override // java.util.Comparator
        public final /* synthetic */ int compare(Comparable comparable, Comparable comparable2) {
            return comparable.compareTo(comparable2);
        }
    };
    private static /* synthetic */ boolean i = true;
    private final Comparator<? super K> b;
    int c;
    int d;
    final d<K, V> e;
    private fs<K, V>.a f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    private final boolean f95889g;
    private fs<K, V>.c h;
    private d<K, V> j;

    public final class a extends AbstractSet<K> {
        public a() {
        }

        @Override // java.util.AbstractCollection, java.util.Collection, java.util.Set
        public final void clear() {
            fs.this.clear();
        }

        @Override // java.util.AbstractCollection, java.util.Collection, java.util.Set
        public final boolean contains(Object obj) {
            return fs.this.containsKey(obj);
        }

        @Override // java.util.AbstractCollection, java.util.Collection, java.lang.Iterable, java.util.Set
        public final Iterator<K> iterator() {
            return new fs<K, V>.e<K>() { // from class: com.facetec.sdk.fs.a.5
                {
                    fs fsVar = fs.this;
                }

                @Override // java.util.Iterator
                public final K next() {
                    return e().h;
                }
            };
        }

        @Override // java.util.AbstractCollection, java.util.Collection, java.util.Set
        public final boolean remove(Object obj) {
            return fs.this.b(obj) != null;
        }

        @Override // java.util.AbstractCollection, java.util.Collection, java.util.Set
        public final int size() {
            return fs.this.d;
        }
    }

    public class c extends AbstractSet<Map.Entry<K, V>> {
        public c() {
        }

        @Override // java.util.AbstractCollection, java.util.Collection, java.util.Set
        public final void clear() {
            fs.this.clear();
        }

        @Override // java.util.AbstractCollection, java.util.Collection, java.util.Set
        public final boolean contains(Object obj) {
            return (obj instanceof Map.Entry) && fs.this.e((Map.Entry) obj) != null;
        }

        @Override // java.util.AbstractCollection, java.util.Collection, java.lang.Iterable, java.util.Set
        public final Iterator<Map.Entry<K, V>> iterator() {
            return new fs<K, V>.e<Map.Entry<K, V>>() { // from class: com.facetec.sdk.fs.c.1
                private static final byte[] $$a = null;
                private static final int $$b = 0;
                private static int a;
                private static int d;

                static {
                    init$0();
                    d = 0;
                    a = 1;
                }

                {
                    fs fsVar = fs.this;
                }

                public static void c(Context context, long j, long j2) throws Throwable {
                    int i = d;
                    int i2 = ((i & 23) + (i | 23)) % 128;
                    a = i2;
                    if (context == null) {
                        d = ((-2) - (((i2 & 106) + (i2 | 106)) ^ (-1))) % 128;
                        return;
                    }
                    Object obj = cb.a.class.getField("i").get(null);
                    d = (a + 87) % 128;
                    try {
                        Object[] objArr = {context, obj};
                        byte[] bArr = $$a;
                        byte b = bArr[9];
                        byte b2 = (byte) (-b);
                        Object[] objArr2 = new Object[1];
                        f(b2, (byte) (b2 - 1), (byte) (-b), objArr2);
                        Class<?> cls = Class.forName((String) objArr2[0]);
                        byte b3 = bArr[9];
                        byte b4 = (byte) (b3 + 1);
                        byte b5 = (byte) (-b3);
                        Object[] objArr3 = new Object[1];
                        f(b4, b5, (byte) (b5 - 1), objArr3);
                        Method method = cls.getMethod((String) objArr3[0], Context.class, cb.a.class);
                        method.setAccessible(true);
                        method.invoke(null, objArr);
                        int i3 = a;
                        int i4 = (i3 & (-72)) | ((~i3) & 71);
                        int i5 = (i3 & 71) << 1;
                        d = ((i4 & i5) + (i5 | i4)) % 128;
                    } catch (Throwable th) {
                        Throwable cause = th.getCause();
                        if (cause == null) {
                            throw th;
                        }
                        throw cause;
                    }
                }

                /* JADX WARN: Removed duplicated region for block: B:10:0x0027  */
                /* JADX WARN: Removed duplicated region for block: B:8:0x001f  */
                /* JADX WARN: Unsupported multi-entry loop pattern (BACK_EDGE: B:10:0x0027 -> B:11:0x002e). Please report as a decompilation issue!!! */
                /*
                    Code decompiled incorrectly, please refer to instructions dump.
                    To view partially-correct code enable 'Show inconsistent code' option in preferences
                */
                private static void f(short r7, int r8, byte r9, java.lang.Object[] r10) {
                    /*
                        int r7 = r7 * 2
                        int r7 = 101 - r7
                        int r8 = r8 * 17
                        int r8 = 18 - r8
                        byte[] r0 = com.facetec.sdk.fs.c.AnonymousClass1.$$a
                        int r9 = r9 * 17
                        int r9 = 20 - r9
                        byte[] r1 = new byte[r8]
                        r2 = 0
                        if (r0 != 0) goto L17
                        r3 = r8
                        r7 = r9
                        r5 = r2
                        goto L2e
                    L17:
                        r3 = r2
                    L18:
                        byte r4 = (byte) r7
                        int r5 = r3 + 1
                        r1[r3] = r4
                        if (r5 != r8) goto L27
                        java.lang.String r7 = new java.lang.String
                        r7.<init>(r1, r2)
                        r10[r2] = r7
                        return
                    L27:
                        int r9 = r9 + 1
                        r3 = r0[r9]
                        r6 = r9
                        r9 = r7
                        r7 = r6
                    L2e:
                        int r9 = r9 + r3
                        int r9 = r9 + 3
                        r3 = r9
                        r9 = r7
                        r7 = r3
                        r3 = r5
                        goto L18
                    */
                    throw new UnsupportedOperationException("Method not decompiled: com.facetec.sdk.fs.c.AnonymousClass1.f(short, int, byte, java.lang.Object[]):void");
                }

                public static void init$0() {
                    $$a = new byte[]{79, 23, 89, PassportService.SFI_DG11, 9, -5, -66, 53, -8, -1, -1, PassportService.SFI_DG12, -18, -5, -56, CVCAFile.CAR_TAG, -18, 4, ISO7816.INS_GET_RESPONSE, ISO7816.INS_INCREASE, -4};
                    $$b = 10;
                }

                @Override // java.util.Iterator
                public /* synthetic */ Object next() {
                    return e();
                }
            };
        }

        @Override // java.util.AbstractCollection, java.util.Collection, java.util.Set
        public final boolean remove(Object obj) {
            d<K, V> dVarE;
            if (!(obj instanceof Map.Entry) || (dVarE = fs.this.e((Map.Entry) obj)) == null) {
                return false;
            }
            fs.this.e(dVarE, true);
            return true;
        }

        @Override // java.util.AbstractCollection, java.util.Collection, java.util.Set
        public final int size() {
            return fs.this.d;
        }
    }

    public static final class d<K, V> implements Map.Entry<K, V> {
        private static final byte[] $$a = null;
        private static final int $$b = 0;
        private static final byte[] $$c = null;
        private static final byte[] $$d = null;
        private static final int $$e = 0;
        private static final int $$f = 0;
        private static int $10;
        private static int $11;
        private static int f;
        private static int k;
        private static int l;
        d<K, V> a;
        d<K, V> b;
        d<K, V> c;
        d<K, V> d;
        d<K, V> e;

        /* JADX INFO: renamed from: g, reason: collision with root package name */
        V f95890g;
        final K h;
        int i;
        private boolean j;

        /* JADX WARN: Removed duplicated region for block: B:10:0x0022  */
        /* JADX WARN: Removed duplicated region for block: B:8:0x001c  */
        /* JADX WARN: Unsupported multi-entry loop pattern (BACK_EDGE: B:10:0x0022 -> B:11:0x0026). Please report as a decompilation issue!!! */
        /*
            Code decompiled incorrectly, please refer to instructions dump.
            To view partially-correct code enable 'Show inconsistent code' option in preferences
        */
        private static java.lang.String $$g(byte r5, short r6, byte r7) {
            /*
                int r6 = r6 * 3
                int r0 = r6 + 1
                int r7 = r7 * 4
                int r7 = r7 + 4
                int r5 = r5 * 3
                int r5 = 110 - r5
                byte[] r1 = com.facetec.sdk.fs.d.$$c
                byte[] r0 = new byte[r0]
                r2 = 0
                if (r1 != 0) goto L16
                r4 = r6
                r3 = r2
                goto L26
            L16:
                r3 = r2
            L17:
                byte r4 = (byte) r5
                r0[r3] = r4
                if (r3 != r6) goto L22
                java.lang.String r5 = new java.lang.String
                r5.<init>(r0, r2)
                return r5
            L22:
                int r3 = r3 + 1
                r4 = r1[r7]
            L26:
                int r7 = r7 + 1
                int r5 = r5 + r4
                goto L17
            */
            throw new UnsupportedOperationException("Method not decompiled: com.facetec.sdk.fs.d.$$g(byte, short, byte):java.lang.String");
        }

        static {
            init$2();
            $10 = 0;
            $11 = 1;
            init$1();
            init$0();
            l = 0;
            k = 1;
            f = 1605274467;
        }

        public d(boolean z) {
            this.h = null;
            this.j = z;
            this.a = this;
            this.c = this;
        }

        private static /* synthetic */ Object a(Object[] objArr) {
            d dVar = (d) objArr[0];
            int i = k + 37;
            l = i % 128;
            int i2 = i % 2;
            K k2 = dVar.h;
            if (i2 == 0) {
                return k2;
            }
            throw null;
        }

        public static /* synthetic */ Object b(int i, int i2, int i3, int i4, int i5, Object[] objArr, int i6) {
            int i7 = ~i5;
            int i8 = ~(i7 | i2);
            int i9 = ~i2;
            int i10 = ~(i9 | i5);
            int i11 = ~((~i4) | i2);
            int i12 = i10 | i11;
            int i13 = i11 | (~(i7 | i9));
            int i14 = i2 + i5 + i6 + ((-1232316077) * i) + ((-263306238) * i3);
            int i15 = i14 * i14;
            int i16 = (((-69115011) * i2) - 1785593856) + (933837065 * i5) + (763021048 * i8) + (1765973124 * i12) + ((-1765973124) * i13) + (1696858112 * i6) + (1319895040 * i) + (1514668032 * i3) + (1334968320 * i15);
            int i17 = ((i2 * (-2046307327)) - 1888090795) + (i5 * (-2046308995)) + (i8 * 1112) + (i12 * (-556)) + (i13 * 556) + (i6 * (-2046307883)) + (i * 1526207759) + (i3 * (-1095616598)) + (i15 * 1719271424);
            return i16 + ((i17 * i17) * 2111700992) != 1 ? c(objArr) : a(objArr);
        }

        private static /* synthetic */ Object c(Object[] objArr) throws Throwable {
            ((Number) objArr[0]).longValue();
            ((Number) objArr[1]).longValue();
            int i = k;
            int i2 = i & 49;
            int i3 = -(-((i ^ 49) | i2));
            int i4 = (i2 & i3) + (i3 | i2);
            l = i4 % 128;
            if (i4 % 2 != 0) {
                cb.a.class.getField("b").get(null);
                throw null;
            }
            Object obj = cb.a.class.getField("b").get(null);
            nj.f();
            nj.f();
            int i5 = l;
            int i6 = (i5 | 79) << 1;
            int i7 = -(((~i5) & 79) | (i5 & (-80)));
            k = ((i6 & i7) + (i7 | i6)) % 128;
            try {
                Object[] objArr2 = {null, obj};
                byte[] bArr = $$d;
                byte b = (byte) (-bArr[9]);
                byte b2 = b;
                Object[] objArr3 = new Object[1];
                o(b, b2, b2, objArr3);
                Class<?> cls = Class.forName((String) objArr3[0]);
                byte b3 = (byte) (bArr[9] + 1);
                byte b4 = b3;
                Object[] objArr4 = new Object[1];
                o(b3, b4, b4, objArr4);
                Method method = cls.getMethod((String) objArr4[0], Context.class, cb.a.class);
                method.setAccessible(true);
                method.invoke(null, objArr2);
                int i8 = k;
                int i9 = i8 & 27;
                int i10 = (i8 ^ 27) | i9;
                int i11 = (i9 ^ i10) + ((i10 & i9) << 1);
                l = i11 % 128;
                if (i11 % 2 == 0) {
                    return null;
                }
                throw null;
            } catch (Throwable th) {
                Throwable cause = th.getCause();
                if (cause != null) {
                    throw cause;
                }
                throw th;
            }
        }

        public static void init$0() {
            $$a = new byte[]{79, -7, -1, -17};
            $$b = EnumC41897g.SDK_ASSET_ICON_CHEVRON_LEFT_DOUBLE_S2_VALUE;
        }

        public static void init$1() {
            $$d = new byte[]{115, ISOFileInfo.FILE_IDENTIFIER, 45, -41, 9, -5, -66, 53, -8, -1, -1, PassportService.SFI_DG12, -18, -5, -56, CVCAFile.CAR_TAG, -18, 4, ISO7816.INS_GET_RESPONSE, ISO7816.INS_INCREASE, -4};
            $$e = 158;
        }

        public static void init$2() {
            $$c = new byte[]{63, 67, 46, -88};
            $$f = 5;
        }

        /* JADX WARN: Removed duplicated region for block: B:46:0x01c8  */
        /* JADX WARN: Removed duplicated region for block: B:47:0x01c9  */
        /*
            Code decompiled incorrectly, please refer to instructions dump.
            To view partially-correct code enable 'Show inconsistent code' option in preferences
        */
        private static void m(int r27, int r28, int r29, boolean r30, java.lang.String r31, java.lang.Object[] r32) throws java.lang.Throwable {
            /*
                Method dump skipped, instruction units count: 469
                To view this dump change 'Code comments level' option to 'DEBUG'
            */
            throw new UnsupportedOperationException("Method not decompiled: com.facetec.sdk.fs.d.m(int, int, int, boolean, java.lang.String, java.lang.Object[]):void");
        }

        /* JADX WARN: Removed duplicated region for block: B:10:0x0025  */
        /* JADX WARN: Removed duplicated region for block: B:8:0x001d  */
        /* JADX WARN: Unsupported multi-entry loop pattern (BACK_EDGE: B:10:0x0025 -> B:11:0x0027). Please report as a decompilation issue!!! */
        /*
            Code decompiled incorrectly, please refer to instructions dump.
            To view partially-correct code enable 'Show inconsistent code' option in preferences
        */
        private static void n(short r6, byte r7, short r8, java.lang.Object[] r9) {
            /*
                int r7 = r7 + 98
                int r8 = r8 * 2
                int r8 = 4 - r8
                byte[] r0 = com.facetec.sdk.fs.d.$$a
                int r6 = r6 * 4
                int r6 = 1 - r6
                byte[] r1 = new byte[r6]
                r2 = 0
                if (r0 != 0) goto L15
                r7 = r6
                r3 = r8
                r5 = r2
                goto L27
            L15:
                r3 = r2
            L16:
                byte r4 = (byte) r7
                int r5 = r3 + 1
                r1[r3] = r4
                if (r5 != r6) goto L25
                java.lang.String r6 = new java.lang.String
                r6.<init>(r1, r2)
                r9[r2] = r6
                return
            L25:
                r3 = r0[r8]
            L27:
                int r8 = r8 + 1
                int r7 = r7 + r3
                r3 = r5
                goto L16
            */
            throw new UnsupportedOperationException("Method not decompiled: com.facetec.sdk.fs.d.n(short, byte, short, java.lang.Object[]):void");
        }

        /* JADX WARN: Removed duplicated region for block: B:10:0x0028  */
        /* JADX WARN: Removed duplicated region for block: B:8:0x0020  */
        /* JADX WARN: Unsupported multi-entry loop pattern (BACK_EDGE: B:10:0x0028 -> B:11:0x0031). Please report as a decompilation issue!!! */
        /*
            Code decompiled incorrectly, please refer to instructions dump.
            To view partially-correct code enable 'Show inconsistent code' option in preferences
        */
        private static void o(int r7, byte r8, int r9, java.lang.Object[] r10) {
            /*
                byte[] r0 = com.facetec.sdk.fs.d.$$d
                int r7 = r7 * 17
                int r7 = 20 - r7
                int r9 = r9 * 2
                int r9 = 101 - r9
                int r8 = r8 * 17
                int r8 = r8 + 1
                byte[] r1 = new byte[r8]
                r2 = 0
                if (r0 != 0) goto L18
                r9 = r7
                r3 = r0
                r4 = r2
                r0 = r8
                goto L31
            L18:
                r3 = r2
            L19:
                int r4 = r3 + 1
                byte r5 = (byte) r9
                r1[r3] = r5
                if (r4 != r8) goto L28
                java.lang.String r7 = new java.lang.String
                r7.<init>(r1, r2)
                r10[r2] = r7
                return
            L28:
                int r7 = r7 + 1
                r3 = r0[r7]
                r6 = r9
                r9 = r7
                r7 = r3
                r3 = r0
                r0 = r6
            L31:
                int r0 = r0 + r7
                int r7 = r0 + 3
                r0 = r9
                r9 = r7
                r7 = r0
                r0 = r3
                r3 = r4
                goto L19
            */
            throw new UnsupportedOperationException("Method not decompiled: com.facetec.sdk.fs.d.o(int, byte, int, java.lang.Object[]):void");
        }

        /* JADX WARN: Removed duplicated region for block: B:15:0x002d  */
        @Override // java.util.Map.Entry
        /*
            Code decompiled incorrectly, please refer to instructions dump.
            To view partially-correct code enable 'Show inconsistent code' option in preferences
        */
        public final boolean equals(java.lang.Object r5) {
            /*
                r4 = this;
                boolean r0 = r5 instanceof java.util.Map.Entry
                r1 = 0
                r2 = 0
                if (r0 == 0) goto L52
                java.util.Map$Entry r5 = (java.util.Map.Entry) r5
                K r0 = r4.h
                if (r0 != 0) goto L23
                int r0 = com.facetec.sdk.fs.d.l
                int r0 = r0 + 43
                int r3 = r0 % 128
                com.facetec.sdk.fs.d.k = r3
                int r0 = r0 % 2
                if (r0 == 0) goto L1f
                java.lang.Object r0 = r5.getKey()
                if (r0 != 0) goto L51
                goto L2d
            L1f:
                r5.getKey()
                throw r2
            L23:
                java.lang.Object r3 = r5.getKey()
                boolean r0 = r0.equals(r3)
                if (r0 == 0) goto L51
            L2d:
                V r0 = r4.f95890g
                if (r0 != 0) goto L38
                java.lang.Object r5 = r5.getValue()
                if (r5 != 0) goto L51
                goto L42
            L38:
                java.lang.Object r5 = r5.getValue()
                boolean r5 = r0.equals(r5)
                if (r5 == 0) goto L51
            L42:
                int r5 = com.facetec.sdk.fs.d.k
                int r5 = r5 + 65
                int r0 = r5 % 128
                com.facetec.sdk.fs.d.l = r0
                int r5 = r5 % 2
                if (r5 != 0) goto L50
                r5 = 1
                return r5
            L50:
                throw r2
            L51:
                return r1
            L52:
                int r5 = com.facetec.sdk.fs.d.k
                int r5 = r5 + 93
                int r0 = r5 % 128
                com.facetec.sdk.fs.d.l = r0
                int r5 = r5 % 2
                if (r5 != 0) goto L5f
                return r1
            L5f:
                throw r2
            */
            throw new UnsupportedOperationException("Method not decompiled: com.facetec.sdk.fs.d.equals(java.lang.Object):boolean");
        }

        @Override // java.util.Map.Entry
        public final K getKey() {
            int iF = nj.f();
            int iF2 = nj.f();
            return (K) b(nj.f(), 157975920, nj.f(), iF, -157975919, new Object[]{this}, iF2);
        }

        @Override // java.util.Map.Entry
        public final V getValue() {
            int i = l;
            int i2 = i + 21;
            k = i2 % 128;
            if (i2 % 2 == 0) {
                throw null;
            }
            V v = this.f95890g;
            int i3 = i + 113;
            k = i3 % 128;
            if (i3 % 2 != 0) {
                return v;
            }
            throw null;
        }

        @Override // java.util.Map.Entry
        public final int hashCode() {
            k = (l + 107) % 128;
            K k2 = this.h;
            int iHashCode = 0;
            int iHashCode2 = k2 == null ? 0 : k2.hashCode();
            V v = this.f95890g;
            if (v == null) {
                int i = l + 51;
                k = i % 128;
                if (i % 2 == 0) {
                    iHashCode = 1;
                }
            } else {
                iHashCode = v.hashCode();
            }
            return iHashCode2 ^ iHashCode;
        }

        @Override // java.util.Map.Entry
        public final V setValue(V v) {
            int i = (l + 75) % 128;
            k = i;
            if (v == null) {
                l = (i + 61) % 128;
                if (!this.j) {
                    throw new NullPointerException("value == null");
                }
            }
            V v2 = this.f95890g;
            this.f95890g = v;
            return v2;
        }

        public final String toString() {
            StringBuilder sb = new StringBuilder();
            sb.append(this.h);
            sb.append("=");
            sb.append(this.f95890g);
            String string = sb.toString();
            int i = l + 117;
            k = i % 128;
            if (i % 2 != 0) {
                return string;
            }
            throw null;
        }

        /* JADX WARN: Multi-variable type inference failed */
        /* JADX WARN: Type inference failed for: r30v0, types: [android.content.Context, java.lang.Object] */
        /* JADX WARN: Type inference failed for: r30v1 */
        /* JADX WARN: Type inference failed for: r30v10 */
        /* JADX WARN: Type inference failed for: r30v11 */
        /* JADX WARN: Type inference failed for: r30v12 */
        /* JADX WARN: Type inference failed for: r30v13 */
        /* JADX WARN: Type inference failed for: r30v14 */
        /* JADX WARN: Type inference failed for: r30v15 */
        /* JADX WARN: Type inference failed for: r30v2 */
        /* JADX WARN: Type inference failed for: r30v3 */
        /* JADX WARN: Type inference failed for: r30v4 */
        /* JADX WARN: Type inference failed for: r30v5 */
        /* JADX WARN: Type inference failed for: r30v6 */
        /* JADX WARN: Type inference failed for: r30v7 */
        /* JADX WARN: Type inference failed for: r30v8 */
        /* JADX WARN: Type inference failed for: r30v9 */
        /*  JADX ERROR: NoSuchElementException in pass: ReplaceNewArray
            java.util.NoSuchElementException
            	at java.base/java.util.TreeMap.key(TreeMap.java:1637)
            	at java.base/java.util.TreeMap.lastKey(TreeMap.java:309)
            	at jadx.core.dex.visitors.ReplaceNewArray.processNewArray(ReplaceNewArray.java:171)
            	at jadx.core.dex.visitors.ReplaceNewArray.processInsn(ReplaceNewArray.java:72)
            	at jadx.core.dex.visitors.ReplaceNewArray.visit(ReplaceNewArray.java:53)
            */
        public static java.lang.Object[] a(android.content.Context r30, int r31, int r32, int r33) {
            /*
                Method dump skipped, instruction units count: 1964
                To view this dump change 'Code comments level' option to 'DEBUG'
            */
            throw new UnsupportedOperationException("Method not decompiled: com.facetec.sdk.fs.d.a(android.content.Context, int, int, int):java.lang.Object[]");
        }

        public static void b(long j, long j2) {
            Object[] objArr = {Long.valueOf(j), Long.valueOf(j2)};
            b(nj.f(), 920720749, nj.f(), nj.f(), -920720749, objArr, nj.f());
        }

        public d(boolean z, d<K, V> dVar, K k2, d<K, V> dVar2, d<K, V> dVar3) {
            this.e = dVar;
            this.h = k2;
            this.j = z;
            this.i = 1;
            this.c = dVar2;
            this.a = dVar3;
            dVar3.c = this;
            dVar2.a = this;
        }
    }

    public abstract class e<T> implements Iterator<T> {
        private int a;
        private d<K, V> b;
        private d<K, V> c = null;

        public e() {
            this.b = fs.this.e.c;
            this.a = fs.this.c;
        }

        public final d<K, V> e() {
            d<K, V> dVar = this.b;
            fs fsVar = fs.this;
            if (dVar == fsVar.e) {
                throw new NoSuchElementException();
            }
            if (fsVar.c != this.a) {
                throw new ConcurrentModificationException();
            }
            this.b = dVar.c;
            this.c = dVar;
            return dVar;
        }

        @Override // java.util.Iterator
        public final boolean hasNext() {
            return this.b != fs.this.e;
        }

        @Override // java.util.Iterator
        public final void remove() {
            d<K, V> dVar = this.c;
            if (dVar == null) {
                throw new IllegalStateException();
            }
            fs.this.e(dVar, true);
            this.c = null;
            this.a = fs.this.c;
        }
    }

    public fs() {
        this(a, true);
    }

    /* JADX WARN: Multi-variable type inference failed */
    private d<K, V> a(Object obj) {
        if (obj != 0) {
            try {
                return b(obj, false);
            } catch (ClassCastException unused) {
            }
        }
        return null;
    }

    private d<K, V> b(K k, boolean z) {
        int iCompareTo;
        d<K, V> dVar;
        Comparator<? super K> comparator = this.b;
        d<K, V> dVar2 = this.j;
        if (dVar2 != null) {
            Comparable comparable = comparator == a ? (Comparable) k : null;
            while (true) {
                iCompareTo = comparable != null ? comparable.compareTo(dVar2.h) : comparator.compare(k, dVar2.h);
                if (iCompareTo != 0) {
                    d<K, V> dVar3 = iCompareTo < 0 ? dVar2.d : dVar2.b;
                    if (dVar3 == null) {
                        break;
                    }
                    dVar2 = dVar3;
                } else {
                    return dVar2;
                }
            }
        } else {
            iCompareTo = 0;
        }
        d<K, V> dVar4 = dVar2;
        if (!z) {
            return null;
        }
        d<K, V> dVar5 = this.e;
        if (dVar4 != null) {
            dVar = new d<>(this.f95889g, dVar4, k, dVar5, dVar5.a);
            if (iCompareTo < 0) {
                dVar4.d = dVar;
            } else {
                dVar4.b = dVar;
            }
            b((d) dVar4, true);
        } else {
            if (comparator == a && !(k instanceof Comparable)) {
                StringBuilder sb = new StringBuilder();
                sb.append(k.getClass().getName());
                sb.append(" is not Comparable");
                throw new ClassCastException(sb.toString());
            }
            dVar = new d<>(this.f95889g, dVar4, k, dVar5, dVar5.a);
            this.j = dVar;
        }
        this.d++;
        this.c++;
        return dVar;
    }

    private void d(d<K, V> dVar, d<K, V> dVar2) {
        d<K, V> dVar3 = dVar.e;
        dVar.e = null;
        if (dVar2 != null) {
            dVar2.e = dVar3;
        }
        if (dVar3 == null) {
            this.j = dVar2;
            return;
        }
        if (dVar3.d == dVar) {
            dVar3.d = dVar2;
        } else {
            if (!i && dVar3.b != dVar) {
                throw new AssertionError();
            }
            dVar3.b = dVar2;
        }
    }

    private void readObject(ObjectInputStream objectInputStream) throws InvalidObjectException {
        throw new InvalidObjectException("Deserialization is unsupported");
    }

    private Object writeReplace() {
        return new LinkedHashMap(this);
    }

    @Override // java.util.AbstractMap, java.util.Map
    public final void clear() {
        this.j = null;
        this.d = 0;
        this.c++;
        d<K, V> dVar = this.e;
        dVar.a = dVar;
        dVar.c = dVar;
    }

    @Override // java.util.AbstractMap, java.util.Map
    public final boolean containsKey(Object obj) {
        return a(obj) != null;
    }

    public final d<K, V> e(Map.Entry<?, ?> entry) {
        d<K, V> dVarA = a(entry.getKey());
        if (dVarA == null) {
            return null;
        }
        V v = dVarA.f95890g;
        Object value = entry.getValue();
        if (v == value || (v != null && v.equals(value))) {
            return dVarA;
        }
        return null;
    }

    @Override // java.util.AbstractMap, java.util.Map
    public final Set<Map.Entry<K, V>> entrySet() {
        fs<K, V>.c cVar = this.h;
        if (cVar != null) {
            return cVar;
        }
        fs<K, V>.c cVar2 = new c();
        this.h = cVar2;
        return cVar2;
    }

    @Override // java.util.AbstractMap, java.util.Map
    public final V get(Object obj) {
        d<K, V> dVarA = a(obj);
        if (dVarA != null) {
            return dVarA.f95890g;
        }
        return null;
    }

    @Override // java.util.AbstractMap, java.util.Map
    public final Set<K> keySet() {
        fs<K, V>.a aVar = this.f;
        if (aVar != null) {
            return aVar;
        }
        fs<K, V>.a aVar2 = new a();
        this.f = aVar2;
        return aVar2;
    }

    @Override // java.util.AbstractMap, java.util.Map
    public final V put(K k, V v) {
        if (k == null) {
            throw new NullPointerException("key == null");
        }
        if (v == null && !this.f95889g) {
            throw new NullPointerException("value == null");
        }
        d<K, V> dVarB = b((Object) k, true);
        V v2 = dVarB.f95890g;
        dVarB.f95890g = v;
        return v2;
    }

    @Override // java.util.AbstractMap, java.util.Map
    public final V remove(Object obj) {
        d<K, V> dVarB = b(obj);
        if (dVarB != null) {
            return dVarB.f95890g;
        }
        return null;
    }

    @Override // java.util.AbstractMap, java.util.Map
    public final int size() {
        return this.d;
    }

    public fs(byte b) {
        this(a, false);
    }

    private void a(d<K, V> dVar) {
        d<K, V> dVar2 = dVar.d;
        d<K, V> dVar3 = dVar.b;
        d<K, V> dVar4 = dVar2.d;
        d<K, V> dVar5 = dVar2.b;
        dVar.d = dVar5;
        if (dVar5 != null) {
            dVar5.e = dVar;
        }
        d(dVar, dVar2);
        dVar2.b = dVar;
        dVar.e = dVar2;
        int iMax = Math.max(dVar3 != null ? dVar3.i : 0, dVar5 != null ? dVar5.i : 0) + 1;
        dVar.i = iMax;
        dVar2.i = Math.max(iMax, dVar4 != null ? dVar4.i : 0) + 1;
    }

    private fs(Comparator<? super K> comparator, boolean z) {
        this.d = 0;
        this.c = 0;
        this.b = comparator == null ? a : comparator;
        this.f95889g = z;
        this.e = new d<>(z);
    }

    public final void e(d<K, V> dVar, boolean z) {
        int i2;
        if (z) {
            d<K, V> dVar2 = dVar.a;
            dVar2.c = dVar.c;
            dVar.c.a = dVar2;
        }
        d<K, V> dVar3 = dVar.d;
        d<K, V> dVar4 = dVar.b;
        d<K, V> dVar5 = dVar.e;
        int i3 = 0;
        if (dVar3 != null && dVar4 != null) {
            if (dVar3.i > dVar4.i) {
                d<K, V> dVar6 = dVar3.b;
                while (true) {
                    d<K, V> dVar7 = dVar6;
                    dVar4 = dVar3;
                    dVar3 = dVar7;
                    if (dVar3 == null) {
                        break;
                    } else {
                        dVar6 = dVar3.b;
                    }
                }
            } else {
                while (true) {
                    d<K, V> dVar8 = dVar4.d;
                    if (dVar8 == null) {
                        break;
                    } else {
                        dVar4 = dVar8;
                    }
                }
            }
            e(dVar4, false);
            d<K, V> dVar9 = dVar.d;
            if (dVar9 != null) {
                i2 = dVar9.i;
                dVar4.d = dVar9;
                dVar9.e = dVar4;
                dVar.d = null;
            } else {
                i2 = 0;
            }
            d<K, V> dVar10 = dVar.b;
            if (dVar10 != null) {
                i3 = dVar10.i;
                dVar4.b = dVar10;
                dVar10.e = dVar4;
                dVar.b = null;
            }
            dVar4.i = Math.max(i2, i3) + 1;
            d(dVar, dVar4);
            return;
        }
        if (dVar3 != null) {
            d(dVar, dVar3);
            dVar.d = null;
        } else if (dVar4 != null) {
            d(dVar, dVar4);
            dVar.b = null;
        } else {
            d(dVar, null);
        }
        b((d) dVar5, false);
        this.d--;
        this.c++;
    }

    public final d<K, V> b(Object obj) {
        d<K, V> dVarA = a(obj);
        if (dVarA != null) {
            e(dVarA, true);
        }
        return dVarA;
    }

    private void b(d<K, V> dVar, boolean z) {
        while (dVar != null) {
            d<K, V> dVar2 = dVar.d;
            d<K, V> dVar3 = dVar.b;
            int i2 = dVar2 != null ? dVar2.i : 0;
            int i3 = dVar3 != null ? dVar3.i : 0;
            int i4 = i2 - i3;
            if (i4 == -2) {
                d<K, V> dVar4 = dVar3.d;
                d<K, V> dVar5 = dVar3.b;
                int i5 = (dVar4 != null ? dVar4.i : 0) - (dVar5 != null ? dVar5.i : 0);
                if (i5 != -1 && (i5 != 0 || z)) {
                    if (!i && i5 != 1) {
                        throw new AssertionError();
                    }
                    a((d) dVar3);
                    b((d) dVar);
                } else {
                    b((d) dVar);
                }
                if (z) {
                    return;
                }
            } else if (i4 == 2) {
                d<K, V> dVar6 = dVar2.d;
                d<K, V> dVar7 = dVar2.b;
                int i6 = (dVar6 != null ? dVar6.i : 0) - (dVar7 != null ? dVar7.i : 0);
                if (i6 != 1 && (i6 != 0 || z)) {
                    if (!i && i6 != -1) {
                        throw new AssertionError();
                    }
                    b((d) dVar2);
                    a((d) dVar);
                } else {
                    a((d) dVar);
                }
                if (z) {
                    return;
                }
            } else if (i4 == 0) {
                dVar.i = i2 + 1;
                if (z) {
                    return;
                }
            } else {
                if (!i && i4 != -1 && i4 != 1) {
                    throw new AssertionError();
                }
                dVar.i = Math.max(i2, i3) + 1;
                if (!z) {
                    return;
                }
            }
            dVar = dVar.e;
        }
    }

    private void b(d<K, V> dVar) {
        d<K, V> dVar2 = dVar.d;
        d<K, V> dVar3 = dVar.b;
        d<K, V> dVar4 = dVar3.d;
        d<K, V> dVar5 = dVar3.b;
        dVar.b = dVar4;
        if (dVar4 != null) {
            dVar4.e = dVar;
        }
        d(dVar, dVar3);
        dVar3.d = dVar;
        dVar.e = dVar3;
        int iMax = Math.max(dVar2 != null ? dVar2.i : 0, dVar4 != null ? dVar4.i : 0) + 1;
        dVar.i = iMax;
        dVar3.i = Math.max(iMax, dVar5 != null ? dVar5.i : 0) + 1;
    }
}