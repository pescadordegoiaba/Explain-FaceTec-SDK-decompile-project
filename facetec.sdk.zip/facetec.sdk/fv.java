package com.facetec.sdk;

import com.facetec.sdk.fb;
import java.lang.reflect.AccessibleObject;
import java.lang.reflect.Method;
import java.util.Iterator;
import java.util.List;

/* JADX INFO: loaded from: classes4.dex */
public final class fv {

    public static abstract class a {
        public static final a d;

        static {
            a aVar;
            if (fo.d()) {
                try {
                    final Method declaredMethod = AccessibleObject.class.getDeclaredMethod("canAccess", Object.class);
                    aVar = new a() { // from class: com.facetec.sdk.fv.a.1
                        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
                        {
                            super((byte) 0);
                        }

                        @Override // com.facetec.sdk.fv.a
                        public final boolean e(AccessibleObject accessibleObject, Object obj) {
                            try {
                                return ((Boolean) declaredMethod.invoke(accessibleObject, obj)).booleanValue();
                            } catch (Exception e) {
                                throw new RuntimeException("Failed invoking canAccess", e);
                            }
                        }
                    };
                } catch (NoSuchMethodException unused) {
                    aVar = null;
                }
            } else {
                aVar = null;
            }
            if (aVar == null) {
                aVar = new a() { // from class: com.facetec.sdk.fv.a.4
                    @Override // com.facetec.sdk.fv.a
                    public final boolean e(AccessibleObject accessibleObject, Object obj) {
                        return true;
                    }
                };
            }
            d = aVar;
        }

        private a() {
        }

        public abstract boolean e(AccessibleObject accessibleObject, Object obj);

        public /* synthetic */ a(byte b) {
            this();
        }
    }

    private static boolean b(String str) {
        return str.startsWith("java.") || str.startsWith("javax.");
    }

    public static boolean d(Class<?> cls) {
        return b(cls.getName());
    }

    public static boolean e(AccessibleObject accessibleObject, Object obj) {
        return a.d.e(accessibleObject, obj);
    }

    public static fb.a b(List<fb> list, Class<?> cls) {
        Iterator<fb> it = list.iterator();
        while (it.hasNext()) {
            fb.a aVarA = it.next().a(cls);
            if (aVarA != fb.a.INDECISIVE) {
                return aVarA;
            }
        }
        return fb.a.ALLOW;
    }

    public static boolean d(String str) {
        return str.startsWith("android.") || str.startsWith("androidx.") || b(str);
    }
}