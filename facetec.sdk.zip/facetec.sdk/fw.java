package com.facetec.sdk;

import java.io.EOFException;
import java.io.IOException;
import java.io.Writer;
import java.util.Objects;
import java.util.Random;

/* JADX INFO: loaded from: classes4.dex */
public final class fw {

    public static final class e extends Writer {
        public static int b;
        public static int c;
        private final Appendable a;
        private final b e = new b(0);

        public static class b implements CharSequence {
            char[] a;
            String d;

            private b() {
            }

            @Override // java.lang.CharSequence
            public final char charAt(int i) {
                return this.a[i];
            }

            @Override // java.lang.CharSequence
            public final int length() {
                return this.a.length;
            }

            @Override // java.lang.CharSequence
            public final CharSequence subSequence(int i, int i2) {
                return new String(this.a, i, i2 - i);
            }

            @Override // java.lang.CharSequence
            public final String toString() {
                if (this.d == null) {
                    this.d = new String(this.a);
                }
                return this.d;
            }

            public /* synthetic */ b(byte b) {
                this();
            }
        }

        public e(Appendable appendable) {
            this.a = appendable;
        }

        public static int d() {
            int i = c;
            int i2 = i % 5013366;
            c = i + 1;
            if (i2 != 0) {
                return b;
            }
            int iNextInt = new Random().nextInt();
            b = iNextInt;
            return iNextInt;
        }

        @Override // java.io.Writer, java.lang.Appendable
        public final /* bridge */ /* synthetic */ Appendable append(CharSequence charSequence) {
            return append(charSequence);
        }

        @Override // java.io.Writer, java.io.Closeable, java.lang.AutoCloseable
        public final void close() {
        }

        @Override // java.io.Writer, java.io.Flushable
        public final void flush() {
        }

        @Override // java.io.Writer
        public final void write(char[] cArr, int i, int i2) throws IOException {
            b bVar = this.e;
            bVar.a = cArr;
            bVar.d = null;
            this.a.append(bVar, i, i2 + i);
        }

        @Override // java.io.Writer, java.lang.Appendable
        public final /* bridge */ /* synthetic */ Appendable append(CharSequence charSequence, int i, int i2) {
            return append(charSequence, i, i2);
        }

        @Override // java.io.Writer, java.lang.Appendable
        public final Writer append(CharSequence charSequence) throws IOException {
            this.a.append(charSequence);
            return this;
        }

        @Override // java.io.Writer, java.lang.Appendable
        public final Writer append(CharSequence charSequence, int i, int i2) throws IOException {
            this.a.append(charSequence, i, i2);
            return this;
        }

        @Override // java.io.Writer
        public final void write(int i) throws IOException {
            this.a.append((char) i);
        }

        @Override // java.io.Writer
        public final void write(String str, int i, int i2) throws IOException {
            Objects.requireNonNull(str);
            this.a.append(str, i, i2 + i);
        }
    }

    public static es a(gs gsVar) {
        boolean z;
        try {
            try {
                gsVar.j();
                z = false;
                try {
                    return gn.z.a(gsVar);
                } catch (EOFException e2) {
                    e = e2;
                    if (z) {
                        return ex.e;
                    }
                    throw new fc(e);
                }
            } catch (gz e3) {
                throw new fc(e3);
            } catch (IOException e4) {
                throw new er(e4);
            } catch (NumberFormatException e5) {
                throw new fc(e5);
            }
        } catch (EOFException e6) {
            e = e6;
            z = true;
        }
    }

    public static void c(es esVar, ha haVar) {
        gn.z.e(haVar, esVar);
    }

    public static Writer c(Appendable appendable) {
        return appendable instanceof Writer ? (Writer) appendable : new e(appendable);
    }
}