package com.facetec.sdk;

import java.lang.reflect.Type;
import java.util.Collection;
import java.util.Iterator;

/* JADX INFO: loaded from: classes4.dex */
public final class fy implements ff {
    private final fn d;

    public static final class d<E> extends fg<Collection<E>> {
        private final fg<E> b;
        private final fu<? extends Collection<E>> e;

        public d(el elVar, Type type, fg<E> fgVar, fu<? extends Collection<E>> fuVar) {
            this.b = new gj(elVar, fgVar, type);
            this.e = fuVar;
        }

        @Override // com.facetec.sdk.fg
        public final /* bridge */ /* synthetic */ Object a(gs gsVar) {
            if (gsVar.j() == gw.NULL) {
                gsVar.m();
                return null;
            }
            Collection<E> collectionB = this.e.b();
            gsVar.c();
            while (gsVar.b()) {
                collectionB.add(this.b.a(gsVar));
            }
            gsVar.e();
            return collectionB;
        }

        @Override // com.facetec.sdk.fg
        public final /* bridge */ /* synthetic */ void e(ha haVar, Object obj) {
            Collection collection = (Collection) obj;
            if (collection == null) {
                haVar.g();
                return;
            }
            haVar.e();
            Iterator<E> it = collection.iterator();
            while (it.hasNext()) {
                this.b.e(haVar, it.next());
            }
            haVar.a();
        }
    }

    public fy(fn fnVar) {
        this.d = fnVar;
    }

    @Override // com.facetec.sdk.ff
    public final <T> fg<T> b(el elVar, gu<T> guVar) {
        Type typeA = guVar.a();
        Class<? super T> clsD = guVar.d();
        if (!Collection.class.isAssignableFrom(clsD)) {
            return null;
        }
        Type typeB = fm.b(typeA, (Class<?>) clsD);
        return new d(elVar, typeB, elVar.e((gu) gu.e(typeB)), this.d.e(guVar));
    }
}