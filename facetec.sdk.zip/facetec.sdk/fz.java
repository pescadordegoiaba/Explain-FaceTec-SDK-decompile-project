package com.facetec.sdk;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.ParsePosition;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.Objects;

/* JADX INFO: loaded from: classes4.dex */
public final class fz<T extends Date> extends fg<T> {
    private final List<DateFormat> c;
    private final d<T> d;

    public static abstract class d<T extends Date> {
        public static final d<Date> b = new d<Date>(Date.class) { // from class: com.facetec.sdk.fz.d.1
            @Override // com.facetec.sdk.fz.d
            public final Date e(Date date) {
                return date;
            }
        };
        private final Class<T> d;

        public d(Class<T> cls) {
            this.d = cls;
        }

        private final ff a(fz<T> fzVar) {
            return gn.b(this.d, fzVar);
        }

        public final ff c(String str) {
            return a(new fz<>((d) this, str, (byte) 0));
        }

        public abstract T e(Date date);

        public final ff c(int i, int i2) {
            return a(new fz<>(this, i, i2, (byte) 0));
        }
    }

    public /* synthetic */ fz(d dVar, int i, int i2, byte b) {
        this(dVar, i, i2);
    }

    private Date c(gs gsVar) {
        String strH = gsVar.h();
        synchronized (this.c) {
            Iterator<DateFormat> it = this.c.iterator();
            while (it.hasNext()) {
                try {
                    return it.next().parse(strH);
                } catch (ParseException unused) {
                }
            }
            try {
                return gp.a(strH, new ParsePosition(0));
            } catch (ParseException e) {
                StringBuilder sb = new StringBuilder("Failed parsing '");
                sb.append(strH);
                sb.append("' as Date; at path ");
                sb.append(gsVar.q());
                throw new fc(sb.toString(), e);
            }
        }
    }

    @Override // com.facetec.sdk.fg
    public final /* synthetic */ Object a(gs gsVar) {
        if (gsVar.j() == gw.NULL) {
            gsVar.m();
            return null;
        }
        return this.d.e(c(gsVar));
    }

    @Override // com.facetec.sdk.fg
    public final /* bridge */ /* synthetic */ void e(ha haVar, Object obj) {
        String str;
        Date date = (Date) obj;
        if (date == null) {
            haVar.g();
            return;
        }
        DateFormat dateFormat = this.c.get(0);
        synchronized (this.c) {
            str = dateFormat.format(date);
        }
        haVar.e(str);
    }

    public final String toString() {
        DateFormat dateFormat = this.c.get(0);
        if (dateFormat instanceof SimpleDateFormat) {
            StringBuilder sb = new StringBuilder("DefaultDateTypeAdapter(");
            sb.append(((SimpleDateFormat) dateFormat).toPattern());
            sb.append(')');
            return sb.toString();
        }
        StringBuilder sb2 = new StringBuilder("DefaultDateTypeAdapter(");
        sb2.append(dateFormat.getClass().getSimpleName());
        sb2.append(')');
        return sb2.toString();
    }

    public /* synthetic */ fz(d dVar, String str, byte b) {
        this(dVar, str);
    }

    private fz(d<T> dVar, String str) {
        ArrayList arrayList = new ArrayList();
        this.c = arrayList;
        Objects.requireNonNull(dVar);
        this.d = dVar;
        Locale locale = Locale.US;
        arrayList.add(new SimpleDateFormat(str, locale));
        if (Locale.getDefault().equals(locale)) {
            return;
        }
        arrayList.add(new SimpleDateFormat(str));
    }

    private fz(d<T> dVar, int i, int i2) {
        ArrayList arrayList = new ArrayList();
        this.c = arrayList;
        Objects.requireNonNull(dVar);
        this.d = dVar;
        Locale locale = Locale.US;
        arrayList.add(DateFormat.getDateTimeInstance(i, i2, locale));
        if (!Locale.getDefault().equals(locale)) {
            arrayList.add(DateFormat.getDateTimeInstance(i, i2));
        }
        if (fo.d()) {
            arrayList.add(fx.c(i, i2));
        }
    }
}