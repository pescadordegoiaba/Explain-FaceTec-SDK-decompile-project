package com.facetec.sdk;

import java.lang.reflect.Array;
import java.lang.reflect.GenericArrayType;
import java.lang.reflect.Type;
import java.util.ArrayList;

/* JADX INFO: loaded from: classes4.dex */
public final class ga<E> extends fg<Object> {
    public static final ff e = new ff() { // from class: com.facetec.sdk.ga.3
        @Override // com.facetec.sdk.ff
        public final <T> fg<T> b(el elVar, gu<T> guVar) {
            Type typeA = guVar.a();
            if (!(typeA instanceof GenericArrayType) && (!(typeA instanceof Class) || !((Class) typeA).isArray())) {
                return null;
            }
            Type typeE = fm.e(typeA);
            return new ga(elVar, elVar.e((gu) gu.e(typeE)), fm.b(typeE));
        }
    };
    private final fg<E> a;
    private final Class<E> c;

    public ga(el elVar, fg<E> fgVar, Class<E> cls) {
        this.a = new gj(elVar, fgVar, cls);
        this.c = cls;
    }

    @Override // com.facetec.sdk.fg
    public final Object a(gs gsVar) {
        if (gsVar.j() == gw.NULL) {
            gsVar.m();
            return null;
        }
        ArrayList arrayList = new ArrayList();
        gsVar.c();
        while (gsVar.b()) {
            arrayList.add(this.a.a(gsVar));
        }
        gsVar.e();
        int size = arrayList.size();
        if (!this.c.isPrimitive()) {
            return arrayList.toArray((Object[]) Array.newInstance((Class<?>) this.c, size));
        }
        Object objNewInstance = Array.newInstance((Class<?>) this.c, size);
        for (int i = 0; i < size; i++) {
            Array.set(objNewInstance, i, arrayList.get(i));
        }
        return objNewInstance;
    }

    @Override // com.facetec.sdk.fg
    public final void e(ha haVar, Object obj) {
        if (obj == null) {
            haVar.g();
            return;
        }
        haVar.e();
        int length = Array.getLength(obj);
        for (int i = 0; i < length; i++) {
            this.a.e(haVar, (E) Array.get(obj, i));
        }
        haVar.a();
    }
}