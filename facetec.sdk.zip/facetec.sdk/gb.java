package com.facetec.sdk;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.ParsePosition;
import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;

/* JADX INFO: loaded from: classes4.dex */
public final class gb extends fg<Date> {
    public static final ff c = new ff() { // from class: com.facetec.sdk.gb.4
        @Override // com.facetec.sdk.ff
        public final <T> fg<T> b(el elVar, gu<T> guVar) {
            if (guVar.d() == Date.class) {
                return new gb();
            }
            return null;
        }
    };
    private final List<DateFormat> d;

    public gb() {
        ArrayList arrayList = new ArrayList();
        this.d = arrayList;
        Locale locale = Locale.US;
        arrayList.add(DateFormat.getDateTimeInstance(2, 2, locale));
        if (!Locale.getDefault().equals(locale)) {
            arrayList.add(DateFormat.getDateTimeInstance(2, 2));
        }
        if (fo.d()) {
            arrayList.add(fx.c(2, 2));
        }
    }

    private Date b(gs gsVar) {
        String strH = gsVar.h();
        synchronized (this.d) {
            Iterator<DateFormat> it = this.d.iterator();
            while (it.hasNext()) {
                try {
                    return it.next().parse(strH);
                } catch (ParseException unused) {
                }
            }
            try {
                return gp.a(strH, new ParsePosition(0));
            } catch (ParseException e) {
                StringBuilder sb = new StringBuilder("Failed parsing '");
                sb.append(strH);
                sb.append("' as Date; at path ");
                sb.append(gsVar.q());
                throw new fc(sb.toString(), e);
            }
        }
    }

    @Override // com.facetec.sdk.fg
    public final /* synthetic */ Date a(gs gsVar) {
        if (gsVar.j() != gw.NULL) {
            return b(gsVar);
        }
        gsVar.m();
        return null;
    }

    @Override // com.facetec.sdk.fg
    public final /* bridge */ /* synthetic */ void e(ha haVar, Date date) {
        String str;
        Date date2 = date;
        if (date2 == null) {
            haVar.g();
            return;
        }
        DateFormat dateFormat = this.d.get(0);
        synchronized (this.d) {
            str = dateFormat.format(date2);
        }
        haVar.e(str);
    }
}