package com.facetec.sdk;

import java.io.ObjectInputStream;
import java.io.ObjectStreamClass;
import java.lang.reflect.Field;
import java.lang.reflect.Method;

/* JADX INFO: loaded from: classes4.dex */
public abstract class gc {
    public static final gc b = a();

    private static gc a() {
        try {
            try {
                try {
                    Class<?> cls = Class.forName("sun.misc.Unsafe");
                    Field declaredField = cls.getDeclaredField("theUnsafe");
                    declaredField.setAccessible(true);
                    final Object obj = declaredField.get(null);
                    final Method method = cls.getMethod("allocateInstance", Class.class);
                    return new gc() { // from class: com.facetec.sdk.gc.2
                        @Override // com.facetec.sdk.gc
                        public final <T> T a(Class<T> cls2) {
                            gc.b(cls2);
                            return (T) method.invoke(obj, cls2);
                        }
                    };
                } catch (Exception unused) {
                    Method declaredMethod = ObjectStreamClass.class.getDeclaredMethod("getConstructorId", Class.class);
                    declaredMethod.setAccessible(true);
                    final int iIntValue = ((Integer) declaredMethod.invoke(null, Object.class)).intValue();
                    final Method declaredMethod2 = ObjectStreamClass.class.getDeclaredMethod("newInstance", Class.class, Integer.TYPE);
                    declaredMethod2.setAccessible(true);
                    return new gc() { // from class: com.facetec.sdk.gc.1
                        @Override // com.facetec.sdk.gc
                        public final <T> T a(Class<T> cls2) {
                            gc.b(cls2);
                            return (T) declaredMethod2.invoke(null, cls2, Integer.valueOf(iIntValue));
                        }
                    };
                }
            } catch (Exception unused2) {
                final Method declaredMethod3 = ObjectInputStream.class.getDeclaredMethod("newInstance", Class.class, Class.class);
                declaredMethod3.setAccessible(true);
                return new gc() { // from class: com.facetec.sdk.gc.5
                    @Override // com.facetec.sdk.gc
                    public final <T> T a(Class<T> cls2) {
                        gc.b(cls2);
                        return (T) declaredMethod3.invoke(null, cls2, Object.class);
                    }
                };
            }
        } catch (Exception unused3) {
            return new gc() { // from class: com.facetec.sdk.gc.4
                @Override // com.facetec.sdk.gc
                public final <T> T a(Class<T> cls2) {
                    StringBuilder sb = new StringBuilder("Cannot allocate ");
                    sb.append(cls2);
                    sb.append(". Usage of JDK sun.misc.Unsafe is enabled, but it could not be used. Make sure your runtime is configured correctly.");
                    throw new UnsupportedOperationException(sb.toString());
                }
            };
        }
    }

    public static /* synthetic */ void b(Class cls) {
        String strE = fn.e((Class<?>) cls);
        if (strE != null) {
            throw new AssertionError("UnsafeAllocator is used for non-instantiable type: ".concat(strE));
        }
    }

    public abstract <T> T a(Class<T> cls);
}