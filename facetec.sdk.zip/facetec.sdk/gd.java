package com.facetec.sdk;

/* JADX INFO: loaded from: classes4.dex */
public final class gd extends fg<Number> {
    private static final ff a = a((ez) fa.LAZILY_PARSED_NUMBER);
    private final ez c;

    /* JADX INFO: renamed from: com.facetec.sdk.gd$1, reason: invalid class name */
    public static /* synthetic */ class AnonymousClass1 {
        static final /* synthetic */ int[] c;

        static {
            int[] iArr = new int[gw.values().length];
            c = iArr;
            try {
                iArr[gw.NULL.ordinal()] = 1;
            } catch (NoSuchFieldError unused) {
            }
            try {
                c[gw.NUMBER.ordinal()] = 2;
            } catch (NoSuchFieldError unused2) {
            }
            try {
                c[gw.STRING.ordinal()] = 3;
            } catch (NoSuchFieldError unused3) {
            }
        }
    }

    private gd(ez ezVar) {
        this.c = ezVar;
    }

    private static ff a(ez ezVar) {
        return new ff() { // from class: com.facetec.sdk.gd.5
            @Override // com.facetec.sdk.ff
            public final <T> fg<T> b(el elVar, gu<T> guVar) {
                if (guVar.d() == Number.class) {
                    return gd.this;
                }
                return null;
            }
        };
    }

    public static ff c(ez ezVar) {
        return ezVar == fa.LAZILY_PARSED_NUMBER ? a : a(ezVar);
    }

    @Override // com.facetec.sdk.fg
    public final /* synthetic */ void e(ha haVar, Number number) {
        haVar.b(number);
    }

    @Override // com.facetec.sdk.fg
    public final /* synthetic */ Number a(gs gsVar) {
        gw gwVarJ = gsVar.j();
        int i = AnonymousClass1.c[gwVarJ.ordinal()];
        if (i == 1) {
            gsVar.m();
            return null;
        }
        if (i != 2 && i != 3) {
            StringBuilder sb = new StringBuilder("Expecting number, got: ");
            sb.append(gwVarJ);
            sb.append("; at path ");
            sb.append(gsVar.p());
            throw new fc(sb.toString());
        }
        return this.c.c(gsVar);
    }
}