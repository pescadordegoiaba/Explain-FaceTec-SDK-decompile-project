package com.facetec.sdk;

import ai.luciq.library.logging.LuciqLog;
import android.os.Process;
import com.facetec.sdk.bd;
import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.Map;

/* JADX INFO: loaded from: classes4.dex */
public final class ge implements ff {
    public static int c;
    public static int d;
    private final fn a;
    final boolean e;

    public final class e<K, V> extends fg<Map<K, V>> {
        private final fg<V> a;
        private final fg<K> b;
        private final fu<? extends Map<K, V>> e;

        public e(el elVar, Type type, fg<K> fgVar, Type type2, fg<V> fgVar2, fu<? extends Map<K, V>> fuVar) {
            this.b = new gj(elVar, fgVar, type);
            this.a = new gj(elVar, fgVar2, type2);
            this.e = fuVar;
        }

        @Override // com.facetec.sdk.fg
        public final /* bridge */ /* synthetic */ Object a(gs gsVar) {
            gw gwVarJ = gsVar.j();
            if (gwVarJ == gw.NULL) {
                gsVar.m();
                return null;
            }
            Map<K, V> mapB = this.e.b();
            if (gwVarJ != gw.BEGIN_ARRAY) {
                gsVar.d();
                while (gsVar.b()) {
                    fr.a.c(gsVar);
                    K kA = this.b.a(gsVar);
                    if (mapB.put(kA, this.a.a(gsVar)) != null) {
                        throw new fc("duplicate key: ".concat(String.valueOf(kA)));
                    }
                }
                gsVar.a();
                return mapB;
            }
            gsVar.c();
            while (gsVar.b()) {
                gsVar.c();
                K kA2 = this.b.a(gsVar);
                if (mapB.put(kA2, this.a.a(gsVar)) != null) {
                    throw new fc("duplicate key: ".concat(String.valueOf(kA2)));
                }
                gsVar.e();
            }
            gsVar.e();
            return mapB;
        }

        @Override // com.facetec.sdk.fg
        public final /* bridge */ /* synthetic */ void e(ha haVar, Object obj) {
            String strC;
            Map map = (Map) obj;
            if (map == null) {
                haVar.g();
                return;
            }
            if (!ge.this.e) {
                haVar.c();
                for (Map.Entry<K, V> entry : map.entrySet()) {
                    haVar.c(String.valueOf(entry.getKey()));
                    this.a.e(haVar, entry.getValue());
                }
                haVar.b();
                return;
            }
            ArrayList arrayList = new ArrayList(map.size());
            ArrayList arrayList2 = new ArrayList(map.size());
            int i = 0;
            boolean z = false;
            for (Map.Entry<K, V> entry2 : map.entrySet()) {
                es esVarA = this.b.a(entry2.getKey());
                arrayList.add(esVarA);
                arrayList2.add(entry2.getValue());
                z |= esVarA.f() || esVarA.g();
            }
            if (z) {
                haVar.e();
                int size = arrayList.size();
                while (i < size) {
                    haVar.e();
                    fw.c((es) arrayList.get(i), haVar);
                    this.a.e(haVar, (V) arrayList2.get(i));
                    haVar.a();
                    i++;
                }
                haVar.a();
                return;
            }
            haVar.c();
            int size2 = arrayList.size();
            while (i < size2) {
                es esVar = (es) arrayList.get(i);
                if (esVar.j()) {
                    eu euVarM = esVar.m();
                    if (((Boolean) eu.d(bd.d.c(), 13458657, bd.d.c(), bd.d.c(), new Object[]{euVarM}, -13458657, bd.d.c())).booleanValue()) {
                        strC = String.valueOf(euVarM.e());
                    } else if (euVarM.h()) {
                        strC = Boolean.toString(euVarM.i());
                    } else {
                        if (!euVarM.k()) {
                            throw new AssertionError();
                        }
                        strC = euVarM.c();
                    }
                } else {
                    if (!esVar.l()) {
                        throw new AssertionError();
                    }
                    strC = LuciqLog.LogMessage.NULL_LOG;
                }
                haVar.c(strC);
                this.a.e(haVar, (V) arrayList2.get(i));
                i++;
            }
            haVar.b();
        }
    }

    public ge(fn fnVar, boolean z) {
        this.a = fnVar;
        this.e = z;
    }

    public static int c() {
        int i = c;
        int i2 = i % 5687762;
        c = i + 1;
        if (i2 != 0) {
            return d;
        }
        int iMyPid = Process.myPid();
        d = iMyPid;
        return iMyPid;
    }

    @Override // com.facetec.sdk.ff
    public final <T> fg<T> b(el elVar, gu<T> guVar) {
        Type typeA = guVar.a();
        Class<? super T> clsD = guVar.d();
        if (!Map.class.isAssignableFrom(clsD)) {
            return null;
        }
        Type[] typeArrC = fm.c(typeA, clsD);
        Type type = typeArrC[0];
        return new e(elVar, typeArrC[0], (type == Boolean.TYPE || type == Boolean.class) ? gn.b : elVar.e((gu) gu.e(type)), typeArrC[1], elVar.e((gu) gu.e(typeArrC[1])), this.a.e(guVar));
    }
}