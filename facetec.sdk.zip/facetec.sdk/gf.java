package com.facetec.sdk;

import java.io.IOException;
import java.io.Writer;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

/* JADX INFO: loaded from: classes4.dex */
public final class gf extends ha {
    private static final Writer a = new Writer() { // from class: com.facetec.sdk.gf.1
        @Override // java.io.Writer, java.io.Closeable, java.lang.AutoCloseable
        public final void close() {
            throw new AssertionError();
        }

        @Override // java.io.Writer, java.io.Flushable
        public final void flush() {
            throw new AssertionError();
        }

        @Override // java.io.Writer
        public final void write(char[] cArr, int i, int i2) {
            throw new AssertionError();
        }
    };
    private static final eu c = new eu("closed");
    private es b;
    private final List<es> d;
    private String e;

    public gf() {
        super(a);
        this.d = new ArrayList();
        this.b = ex.e;
    }

    private void c(es esVar) {
        if (this.e != null) {
            if (!esVar.l() || f()) {
                ((ey) i()).a(this.e, esVar);
            }
            this.e = null;
            return;
        }
        if (this.d.isEmpty()) {
            this.b = esVar;
            return;
        }
        es esVarI = i();
        if (!(esVarI instanceof et)) {
            throw new IllegalStateException();
        }
        ((et) esVarI).b(esVar);
    }

    private es i() {
        return this.d.get(r0.size() - 1);
    }

    @Override // com.facetec.sdk.ha
    public final ha a() {
        if (this.d.isEmpty() || this.e != null) {
            throw new IllegalStateException();
        }
        if (!(i() instanceof et)) {
            throw new IllegalStateException();
        }
        this.d.remove(r0.size() - 1);
        return this;
    }

    @Override // com.facetec.sdk.ha
    public final ha b() {
        if (this.d.isEmpty() || this.e != null) {
            throw new IllegalStateException();
        }
        if (!(i() instanceof ey)) {
            throw new IllegalStateException();
        }
        this.d.remove(r0.size() - 1);
        return this;
    }

    @Override // com.facetec.sdk.ha, java.io.Closeable, java.lang.AutoCloseable
    public final void close() throws IOException {
        if (!this.d.isEmpty()) {
            throw new IOException("Incomplete document");
        }
        this.d.add(c);
    }

    public final es d() {
        if (this.d.isEmpty()) {
            return this.b;
        }
        StringBuilder sb = new StringBuilder("Expected one JSON element but was ");
        sb.append(this.d);
        throw new IllegalStateException(sb.toString());
    }

    @Override // com.facetec.sdk.ha
    public final ha e() {
        et etVar = new et();
        c(etVar);
        this.d.add(etVar);
        return this;
    }

    @Override // com.facetec.sdk.ha, java.io.Flushable
    public final void flush() {
    }

    @Override // com.facetec.sdk.ha
    public final ha g() {
        c(ex.e);
        return this;
    }

    @Override // com.facetec.sdk.ha
    public final ha d(long j) {
        c(new eu(Long.valueOf(j)));
        return this;
    }

    @Override // com.facetec.sdk.ha
    public final ha e(String str) {
        if (str == null) {
            return g();
        }
        c(new eu(str));
        return this;
    }

    @Override // com.facetec.sdk.ha
    public final ha e(Boolean bool) {
        if (bool == null) {
            return g();
        }
        c(new eu(bool));
        return this;
    }

    @Override // com.facetec.sdk.ha
    public final ha b(boolean z) {
        c(new eu(Boolean.valueOf(z)));
        return this;
    }

    @Override // com.facetec.sdk.ha
    public final ha b(Number number) {
        if (number == null) {
            return g();
        }
        if (!j()) {
            double dDoubleValue = number.doubleValue();
            if (Double.isNaN(dDoubleValue) || Double.isInfinite(dDoubleValue)) {
                throw new IllegalArgumentException("JSON forbids NaN and infinities: ".concat(String.valueOf(number)));
            }
        }
        c(new eu(number));
        return this;
    }

    @Override // com.facetec.sdk.ha
    public final ha e(double d) {
        if (!j() && (Double.isNaN(d) || Double.isInfinite(d))) {
            throw new IllegalArgumentException("JSON forbids NaN and infinities: ".concat(String.valueOf(d)));
        }
        c(new eu(Double.valueOf(d)));
        return this;
    }

    @Override // com.facetec.sdk.ha
    public final ha c() {
        ey eyVar = new ey();
        c(eyVar);
        this.d.add(eyVar);
        return this;
    }

    @Override // com.facetec.sdk.ha
    public final ha c(String str) {
        Objects.requireNonNull(str, "name == null");
        if (!this.d.isEmpty() && this.e == null) {
            if (i() instanceof ey) {
                this.e = str;
                return this;
            }
            throw new IllegalStateException();
        }
        throw new IllegalStateException();
    }
}