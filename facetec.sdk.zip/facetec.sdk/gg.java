package com.facetec.sdk;

import android.content.Context;
import com.facetec.sdk.cb;
import java.lang.reflect.Method;
import java.util.Random;
import net.sf.scuba.smartcards.ISO7816;
import org.jmrtd.lds.CVCAFile;

/* JADX INFO: loaded from: classes4.dex */
public final class gg implements ff {
    private static final byte[] $$a = null;
    private static final int $$b = 0;
    public static int a;
    private static int b;
    public static int c;
    private static int e;
    private final fn d;

    static {
        init$0();
        e = 0;
        b = 1;
    }

    public gg(fn fnVar) {
        this.d = fnVar;
    }

    public static fg<?> c(fn fnVar, el elVar, gu<?> guVar, fi fiVar) {
        fg<?> fgVarB;
        Object objB = fnVar.e(gu.a(fiVar.a())).b();
        boolean zB = fiVar.b();
        if (objB instanceof fg) {
            fgVarB = (fg) objB;
        } else if (objB instanceof ff) {
            fgVarB = ((ff) objB).b(elVar, guVar);
        } else {
            boolean z = objB instanceof ev;
            if (!z && !(objB instanceof ep)) {
                StringBuilder sb = new StringBuilder("Invalid attempt to bind an instance of ");
                sb.append(objB.getClass().getName());
                sb.append(" as a @JsonAdapter for ");
                sb.append(guVar.toString());
                sb.append(". @JsonAdapter value must be a TypeAdapter, TypeAdapterFactory, JsonSerializer or JsonDeserializer.");
                throw new IllegalArgumentException(sb.toString());
            }
            gi giVar = new gi(z ? (ev) objB : null, objB instanceof ep ? (ep) objB : null, elVar, guVar, zB);
            zB = false;
            fgVarB = giVar;
        }
        return (fgVarB == null || !zB) ? fgVarB : fgVarB.b();
    }

    public static int e() {
        int i = c;
        int i2 = i % 9705804;
        c = i + 1;
        if (i2 != 0) {
            return a;
        }
        int iNextInt = new Random().nextInt();
        a = iNextInt;
        return iNextInt;
    }

    /* JADX WARN: Removed duplicated region for block: B:10:0x0024  */
    /* JADX WARN: Removed duplicated region for block: B:8:0x001c  */
    /* JADX WARN: Unsupported multi-entry loop pattern (BACK_EDGE: B:10:0x0024 -> B:11:0x0028). Please report as a decompilation issue!!! */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    private static void f(int r5, short r6, byte r7, java.lang.Object[] r8) {
        /*
            byte[] r0 = com.facetec.sdk.gg.$$a
            int r6 = r6 * 2
            int r6 = 101 - r6
            int r7 = r7 * 17
            int r1 = r7 + 1
            int r5 = r5 + 4
            byte[] r1 = new byte[r1]
            r2 = 0
            if (r0 != 0) goto L14
            r4 = r7
            r3 = r2
            goto L28
        L14:
            r3 = r2
        L15:
            int r5 = r5 + 1
            byte r4 = (byte) r6
            r1[r3] = r4
            if (r3 != r7) goto L24
            java.lang.String r5 = new java.lang.String
            r5.<init>(r1, r2)
            r8[r2] = r5
            return
        L24:
            int r3 = r3 + 1
            r4 = r0[r5]
        L28:
            int r4 = -r4
            int r6 = r6 + r4
            int r6 = r6 + 3
            goto L15
        */
        throw new UnsupportedOperationException("Method not decompiled: com.facetec.sdk.gg.f(int, short, byte, java.lang.Object[]):void");
    }

    public static void init$0() {
        $$a = new byte[]{ISO7816.INS_UNBLOCK_CHV, 39, 61, 29, -9, 5, CVCAFile.CAR_TAG, -53, 8, 1, 1, -12, 18, 5, 56, -66, 18, -4, 64, -50, 4};
        $$b = 91;
    }

    @Override // com.facetec.sdk.ff
    public final <T> fg<T> b(el elVar, gu<T> guVar) {
        fi fiVar = (fi) guVar.d().getAnnotation(fi.class);
        if (fiVar == null) {
            return null;
        }
        return (fg<T>) c(this.d, elVar, guVar, fiVar);
    }

    public static void c(long j, long j2) throws Throwable {
        int i = e;
        int i2 = (i & (-8)) | ((~i) & 7);
        int i3 = (i & 7) << 1;
        int i4 = (i2 ^ i3) + ((i3 & i2) << 1);
        b = i4 % 128;
        if (i4 % 2 == 0) {
            cb.a.class.getField("b").get(null);
            throw null;
        }
        Object obj = cb.a.class.getField("b").get(null);
        int i5 = b;
        int i6 = i5 & 9;
        int i7 = (i5 ^ 9) | i6;
        e = (((i6 | i7) << 1) - (i7 ^ i6)) % 128;
        try {
            Object[] objArr = {null, obj};
            byte[] bArr = $$a;
            byte b2 = bArr[9];
            byte b3 = (byte) (-b2);
            byte b4 = b2;
            Object[] objArr2 = new Object[1];
            f(b3, b4, b4, objArr2);
            Class<?> cls = Class.forName((String) objArr2[0]);
            byte b5 = (byte) ($$b & 52);
            byte b6 = (byte) (bArr[9] - 1);
            Object[] objArr3 = new Object[1];
            f(b5, b6, b6, objArr3);
            Method method = cls.getMethod((String) objArr3[0], Context.class, cb.a.class);
            method.setAccessible(true);
            method.invoke(null, objArr);
            int i8 = b;
            int i9 = i8 & 109;
            e = (((((i8 ^ 109) | i9) << 1) - (~(-((i8 | 109) & (~i9))))) - 1) % 128;
        } catch (Throwable th) {
            Throwable cause = th.getCause();
            if (cause == null) {
                throw th;
            }
            throw cause;
        }
    }
}