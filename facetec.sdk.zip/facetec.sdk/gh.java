package com.facetec.sdk;

import com.facetec.sdk.bd;
import java.io.Reader;
import java.util.Arrays;
import java.util.Iterator;
import java.util.Map;
import net.sf.scuba.smartcards.ISO7816;
import org.jmrtd.PassportService;
import org.jmrtd.lds.CVCAFile;

/* JADX INFO: loaded from: classes4.dex */
public final class gh extends gs {
    private static final byte[] $$a = null;
    private static final int $$b = 0;
    private static final Object c;
    private Object[] a;
    private int d;
    private String[] e;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    private int[] f95891g;

    /* JADX INFO: renamed from: com.facetec.sdk.gh$3, reason: invalid class name */
    public static /* synthetic */ class AnonymousClass3 {
        static final /* synthetic */ int[] c;

        static {
            int[] iArr = new int[gw.values().length];
            c = iArr;
            try {
                iArr[gw.NAME.ordinal()] = 1;
            } catch (NoSuchFieldError unused) {
            }
            try {
                c[gw.END_ARRAY.ordinal()] = 2;
            } catch (NoSuchFieldError unused2) {
            }
            try {
                c[gw.END_OBJECT.ordinal()] = 3;
            } catch (NoSuchFieldError unused3) {
            }
            try {
                c[gw.END_DOCUMENT.ordinal()] = 4;
            } catch (NoSuchFieldError unused4) {
            }
        }
    }

    static {
        init$0();
        new Reader() { // from class: com.facetec.sdk.gh.5
            @Override // java.io.Reader, java.io.Closeable, java.lang.AutoCloseable
            public final void close() {
                throw new AssertionError();
            }

            @Override // java.io.Reader
            public final int read(char[] cArr, int i, int i2) {
                throw new AssertionError();
            }
        };
        c = new Object();
    }

    public static void init$0() {
        $$a = new byte[]{CVCAFile.CAR_TAG, ISO7816.INS_UPDATE_BINARY, -1, 80, 9, -5, -66, 53, -8, -1, -1, PassportService.SFI_DG12, -18, -5, -56, CVCAFile.CAR_TAG, -18, 4, ISO7816.INS_GET_RESPONSE, ISO7816.INS_DECREASE_STAMPED, PassportService.SFI_DG13};
        $$b = 250;
    }

    private String x() {
        StringBuilder sb = new StringBuilder(" at path ");
        sb.append(p());
        return sb.toString();
    }

    private Object y() {
        Object[] objArr = this.a;
        int i = this.d - 1;
        this.d = i;
        Object obj = objArr[i];
        objArr[i] = null;
        return obj;
    }

    /* JADX WARN: Removed duplicated region for block: B:10:0x002a  */
    /* JADX WARN: Removed duplicated region for block: B:8:0x0022  */
    /* JADX WARN: Unsupported multi-entry loop pattern (BACK_EDGE: B:10:0x002a -> B:11:0x0031). Please report as a decompilation issue!!! */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    private static void z(short r7, byte r8, short r9, java.lang.Object[] r10) {
        /*
            int r7 = r7 * 2
            int r7 = 18 - r7
            int r9 = r9 * 4
            int r9 = 99 - r9
            byte[] r0 = com.facetec.sdk.gh.$$a
            int r8 = r8 * 4
            int r8 = 3 - r8
            byte[] r1 = new byte[r7]
            r2 = 0
            if (r0 != 0) goto L18
            r3 = r0
            r5 = r2
            r0 = r9
            r9 = r8
            goto L31
        L18:
            r3 = r2
        L19:
            int r8 = r8 + 1
            byte r4 = (byte) r9
            int r5 = r3 + 1
            r1[r3] = r4
            if (r5 != r7) goto L2a
            java.lang.String r7 = new java.lang.String
            r7.<init>(r1, r2)
            r10[r2] = r7
            return
        L2a:
            r3 = r0[r8]
            r6 = r9
            r9 = r8
            r8 = r3
            r3 = r0
            r0 = r6
        L31:
            int r0 = r0 + r8
            int r8 = r0 + 3
            r0 = r9
            r9 = r8
            r8 = r0
            r0 = r3
            r3 = r5
            goto L19
        */
        throw new UnsupportedOperationException("Method not decompiled: com.facetec.sdk.gh.z(short, byte, short, java.lang.Object[]):void");
    }

    @Override // com.facetec.sdk.gs
    public final void a() {
        b(gw.END_OBJECT);
        this.e[this.d - 1] = null;
        y();
        y();
        int i = this.d;
        if (i > 0) {
            int[] iArr = this.f95891g;
            int i2 = i - 1;
            iArr[i2] = iArr[i2] + 1;
        }
    }

    @Override // com.facetec.sdk.gs
    public final boolean b() {
        gw gwVarJ = j();
        return (gwVarJ == gw.END_OBJECT || gwVarJ == gw.END_ARRAY || gwVarJ == gw.END_DOCUMENT) ? false : true;
    }

    @Override // com.facetec.sdk.gs
    public final void c() {
        b(gw.BEGIN_ARRAY);
        e(((et) i()).iterator());
        this.f95891g[this.d - 1] = 0;
    }

    @Override // com.facetec.sdk.gs, java.io.Closeable, java.lang.AutoCloseable
    public final void close() {
        this.a = new Object[]{c};
        this.d = 1;
    }

    @Override // com.facetec.sdk.gs
    public final void d() {
        b(gw.BEGIN_OBJECT);
        e(((ey) i()).h().iterator());
    }

    @Override // com.facetec.sdk.gs
    public final void e() {
        b(gw.END_ARRAY);
        y();
        y();
        int i = this.d;
        if (i > 0) {
            int[] iArr = this.f95891g;
            int i2 = i - 1;
            iArr[i2] = iArr[i2] + 1;
        }
    }

    @Override // com.facetec.sdk.gs
    public final boolean f() {
        b(gw.BOOLEAN);
        boolean zI = ((es) y()).i();
        int i = this.d;
        if (i > 0) {
            int[] iArr = this.f95891g;
            int i2 = i - 1;
            iArr[i2] = iArr[i2] + 1;
        }
        return zI;
    }

    @Override // com.facetec.sdk.gs
    public final String g() {
        return c(false);
    }

    @Override // com.facetec.sdk.gs
    public final String h() {
        gw gwVarJ = j();
        gw gwVar = gw.STRING;
        if (gwVarJ != gwVar && gwVarJ != gw.NUMBER) {
            StringBuilder sb = new StringBuilder("Expected ");
            sb.append(gwVar);
            sb.append(" but was ");
            sb.append(gwVarJ);
            sb.append(x());
            throw new IllegalStateException(sb.toString());
        }
        String strC = ((es) y()).c();
        int i = this.d;
        if (i > 0) {
            int[] iArr = this.f95891g;
            int i2 = i - 1;
            iArr[i2] = iArr[i2] + 1;
        }
        return strC;
    }

    public final Object i() {
        return this.a[this.d - 1];
    }

    @Override // com.facetec.sdk.gs
    public final gw j() throws gz {
        while (this.d != 0) {
            Object objI = i();
            if (!(objI instanceof Iterator)) {
                if (objI instanceof ey) {
                    return gw.BEGIN_OBJECT;
                }
                if (objI instanceof et) {
                    return gw.BEGIN_ARRAY;
                }
                byte b = (byte) ($$a[2] + 1);
                byte b2 = b;
                Object[] objArr = new Object[1];
                z(b, b2, b2, objArr);
                if (!Class.forName((String) objArr[0]).isInstance(objI)) {
                    if (objI instanceof ex) {
                        return gw.NULL;
                    }
                    if (objI == c) {
                        throw new IllegalStateException("JsonReader is closed");
                    }
                    StringBuilder sb = new StringBuilder("Custom JsonElement subclass ");
                    sb.append(objI.getClass().getName());
                    sb.append(" is not supported");
                    throw new gz(sb.toString());
                }
                eu euVar = (eu) objI;
                if (euVar.k()) {
                    return gw.STRING;
                }
                if (euVar.h()) {
                    return gw.BOOLEAN;
                }
                if (((Boolean) eu.d(bd.d.c(), 13458657, bd.d.c(), bd.d.c(), new Object[]{euVar}, -13458657, bd.d.c())).booleanValue()) {
                    return gw.NUMBER;
                }
                throw new AssertionError();
            }
            boolean z = this.a[this.d - 2] instanceof ey;
            Iterator it = (Iterator) objI;
            if (!it.hasNext()) {
                return z ? gw.END_OBJECT : gw.END_ARRAY;
            }
            if (z) {
                return gw.NAME;
            }
            e(it.next());
        }
        return gw.END_DOCUMENT;
    }

    @Override // com.facetec.sdk.gs
    public final int k() {
        gw gwVarJ = j();
        gw gwVar = gw.NUMBER;
        if (gwVarJ != gwVar && gwVarJ != gw.STRING) {
            StringBuilder sb = new StringBuilder("Expected ");
            sb.append(gwVar);
            sb.append(" but was ");
            sb.append(gwVarJ);
            sb.append(x());
            throw new IllegalStateException(sb.toString());
        }
        int iA = ((es) i()).a();
        y();
        int i = this.d;
        if (i > 0) {
            int[] iArr = this.f95891g;
            int i2 = i - 1;
            iArr[i2] = iArr[i2] + 1;
        }
        return iA;
    }

    @Override // com.facetec.sdk.gs
    public final void l() {
        int i = AnonymousClass3.c[j().ordinal()];
        if (i == 1) {
            c(true);
            return;
        }
        if (i == 2) {
            e();
            return;
        }
        if (i == 3) {
            a();
            return;
        }
        if (i != 4) {
            y();
            int i2 = this.d;
            if (i2 > 0) {
                int[] iArr = this.f95891g;
                int i3 = i2 - 1;
                iArr[i3] = iArr[i3] + 1;
            }
        }
    }

    @Override // com.facetec.sdk.gs
    public final void m() {
        b(gw.NULL);
        y();
        int i = this.d;
        if (i > 0) {
            int[] iArr = this.f95891g;
            int i2 = i - 1;
            iArr[i2] = iArr[i2] + 1;
        }
    }

    @Override // com.facetec.sdk.gs
    public final long n() {
        gw gwVarJ = j();
        gw gwVar = gw.NUMBER;
        if (gwVarJ != gwVar && gwVarJ != gw.STRING) {
            StringBuilder sb = new StringBuilder("Expected ");
            sb.append(gwVar);
            sb.append(" but was ");
            sb.append(gwVarJ);
            sb.append(x());
            throw new IllegalStateException(sb.toString());
        }
        long jD = ((es) i()).d();
        y();
        int i = this.d;
        if (i > 0) {
            int[] iArr = this.f95891g;
            int i2 = i - 1;
            iArr[i2] = iArr[i2] + 1;
        }
        return jD;
    }

    @Override // com.facetec.sdk.gs
    public final double o() throws gz {
        gw gwVarJ = j();
        gw gwVar = gw.NUMBER;
        if (gwVarJ != gwVar && gwVarJ != gw.STRING) {
            StringBuilder sb = new StringBuilder("Expected ");
            sb.append(gwVar);
            sb.append(" but was ");
            sb.append(gwVarJ);
            sb.append(x());
            throw new IllegalStateException(sb.toString());
        }
        double dB = ((es) i()).b();
        if (!t() && (Double.isNaN(dB) || Double.isInfinite(dB))) {
            throw new gz("JSON forbids NaN and infinities: ".concat(String.valueOf(dB)));
        }
        y();
        int i = this.d;
        if (i > 0) {
            int[] iArr = this.f95891g;
            int i2 = i - 1;
            iArr[i2] = iArr[i2] + 1;
        }
        return dB;
    }

    @Override // com.facetec.sdk.gs
    public final String p() {
        return e(false);
    }

    @Override // com.facetec.sdk.gs
    public final String q() {
        return e(true);
    }

    @Override // com.facetec.sdk.gs
    public final String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append(gh.class.getSimpleName());
        sb.append(x());
        return sb.toString();
    }

    public final void b(gw gwVar) {
        if (j() == gwVar) {
            return;
        }
        StringBuilder sb = new StringBuilder("Expected ");
        sb.append(gwVar);
        sb.append(" but was ");
        sb.append(j());
        sb.append(x());
        throw new IllegalStateException(sb.toString());
    }

    private String c(boolean z) {
        b(gw.NAME);
        Map.Entry entry = (Map.Entry) ((Iterator) i()).next();
        String str = (String) entry.getKey();
        this.e[this.d - 1] = z ? "<skipped>" : str;
        e(entry.getValue());
        return str;
    }

    public final void e(Object obj) {
        int i = this.d;
        Object[] objArr = this.a;
        if (i == objArr.length) {
            int i2 = i << 1;
            this.a = Arrays.copyOf(objArr, i2);
            this.f95891g = Arrays.copyOf(this.f95891g, i2);
            this.e = (String[]) Arrays.copyOf(this.e, i2);
        }
        Object[] objArr2 = this.a;
        int i3 = this.d;
        this.d = i3 + 1;
        objArr2[i3] = obj;
    }

    private String e(boolean z) {
        StringBuilder sb = new StringBuilder("$");
        int i = 0;
        while (true) {
            int i2 = this.d;
            if (i < i2) {
                Object[] objArr = this.a;
                Object obj = objArr[i];
                if (obj instanceof et) {
                    i++;
                    if (i < i2 && (objArr[i] instanceof Iterator)) {
                        int i3 = this.f95891g[i];
                        if (z && i3 > 0 && (i == i2 - 1 || i == i2 - 2)) {
                            i3--;
                        }
                        sb.append('[');
                        sb.append(i3);
                        sb.append(']');
                    }
                } else if ((obj instanceof ey) && (i = i + 1) < i2 && (objArr[i] instanceof Iterator)) {
                    sb.append('.');
                    String str = this.e[i];
                    if (str != null) {
                        sb.append(str);
                    }
                }
                i++;
            } else {
                return sb.toString();
            }
        }
    }
}