package com.facetec.sdk;

/* JADX INFO: loaded from: classes4.dex */
public final class gi<T> extends gl<T> {
    private final ep<T> a;
    private final gu<T> b;
    private el c;
    private final ev<T> e;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    private final boolean f95892g;
    private volatile fg<T> i;
    private final gi<T>.e f = new e(this, 0);
    private final ff d = null;

    public final class e {
        private e() {
        }

        public /* synthetic */ e(gi giVar, byte b) {
            this();
        }
    }

    public gi(ev<T> evVar, ep<T> epVar, el elVar, gu<T> guVar, boolean z) {
        this.e = evVar;
        this.a = epVar;
        this.c = elVar;
        this.b = guVar;
        this.f95892g = z;
    }

    private fg<T> d() {
        fg<T> fgVar = this.i;
        if (fgVar != null) {
            return fgVar;
        }
        fg<T> fgVarD = this.c.d(this.d, this.b);
        this.i = fgVarD;
        return fgVarD;
    }

    @Override // com.facetec.sdk.fg
    public final T a(gs gsVar) {
        if (this.a == null) {
            return d().a(gsVar);
        }
        es esVarA = fw.a(gsVar);
        if (this.f95892g && esVarA.l()) {
            return null;
        }
        ep<T> epVar = this.a;
        this.b.a();
        return epVar.e();
    }

    @Override // com.facetec.sdk.fg
    public final void e(ha haVar, T t) {
        ev<T> evVar = this.e;
        if (evVar == null) {
            d().e(haVar, t);
        } else if (this.f95892g && t == null) {
            haVar.g();
        } else {
            this.b.a();
            fw.c(evVar.d(), haVar);
        }
    }

    @Override // com.facetec.sdk.gl
    public final fg<T> e() {
        return this.e != null ? this : d();
    }
}