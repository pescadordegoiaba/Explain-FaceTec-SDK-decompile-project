package com.facetec.sdk;

import com.facetec.sdk.gm;
import java.lang.reflect.Type;
import java.lang.reflect.TypeVariable;

/* JADX INFO: loaded from: classes4.dex */
final class gj<T> extends fg<T> {
    private final el b;
    private final fg<T> d;
    private final Type e;

    public gj(el elVar, fg<T> fgVar, Type type) {
        this.b = elVar;
        this.d = fgVar;
        this.e = type;
    }

    @Override // com.facetec.sdk.fg
    public final T a(gs gsVar) {
        return this.d.a(gsVar);
    }

    @Override // com.facetec.sdk.fg
    public final void e(ha haVar, T t) {
        fg<T> fgVarE;
        fg<T> fgVarE2 = this.d;
        Type type = this.e;
        if (t != null && ((type instanceof Class) || (type instanceof TypeVariable))) {
            type = t.getClass();
        }
        if (type != this.e) {
            fgVarE2 = this.b.e((gu) gu.e(type));
            if (fgVarE2 instanceof gm.a) {
                fg<T> fgVar = this.d;
                while ((fgVar instanceof gl) && (fgVarE = ((gl) fgVar).e()) != fgVar) {
                    fgVar = fgVarE;
                }
                if (!(fgVar instanceof gm.a)) {
                    fgVarE2 = this.d;
                }
            }
        }
        fgVarE2.e(haVar, t);
    }
}