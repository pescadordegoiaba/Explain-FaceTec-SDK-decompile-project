package com.facetec.sdk;

/* JADX INFO: loaded from: classes4.dex */
public abstract class gl<T> extends fg<T> {
    public abstract fg<T> e();
}