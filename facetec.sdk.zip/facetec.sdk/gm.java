package com.facetec.sdk;

import com.facetec.sdk.fb;
import com.incode.welcome_sdk.modules.SelfieScan;
import java.lang.reflect.AccessibleObject;
import java.lang.reflect.Constructor;
import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Member;
import java.lang.reflect.Modifier;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

/* JADX INFO: loaded from: classes4.dex */
public final class gm implements ff {
    private final fn a;
    private final List<fb> b;
    private final ek c;
    private final fq d;
    private final gg e;

    public static abstract class a<T, A> extends fg<T> {
        private Map<String, e> c;

        public a(Map<String, e> map) {
            this.c = map;
        }

        @Override // com.facetec.sdk.fg
        public final T a(gs gsVar) {
            if (gsVar.j() == gw.NULL) {
                gsVar.m();
                return null;
            }
            A aC = c();
            try {
                gsVar.d();
                while (gsVar.b()) {
                    e eVar = this.c.get(gsVar.g());
                    if (eVar == null || !eVar.b) {
                        gsVar.l();
                    } else {
                        b(aC, gsVar, eVar);
                    }
                }
                gsVar.a();
                return c(aC);
            } catch (IllegalAccessException e) {
                throw go.e(e);
            } catch (IllegalStateException e2) {
                throw new fc(e2);
            }
        }

        public abstract void b(A a, gs gsVar, e eVar);

        public abstract A c();

        public abstract T c(A a);

        @Override // com.facetec.sdk.fg
        public final void e(ha haVar, T t) {
            if (t == null) {
                haVar.g();
                return;
            }
            haVar.c();
            try {
                Iterator<e> it = this.c.values().iterator();
                while (it.hasNext()) {
                    it.next().a(haVar, t);
                }
                haVar.b();
            } catch (IllegalAccessException e) {
                throw go.e(e);
            }
        }
    }

    public static final class b<T> extends a<T, Object[]> {
        private static Map<Class<?>, Object> b;
        private final Map<String, Integer> c;
        private final Constructor<T> d;
        private final Object[] e;

        static {
            HashMap map = new HashMap();
            map.put(Byte.TYPE, (byte) 0);
            map.put(Short.TYPE, (short) 0);
            map.put(Integer.TYPE, 0);
            map.put(Long.TYPE, 0L);
            map.put(Float.TYPE, Float.valueOf(SelfieScan.RECOGNITION_FAIL_RESULT));
            map.put(Double.TYPE, Double.valueOf(0.0d));
            map.put(Character.TYPE, (char) 0);
            map.put(Boolean.TYPE, Boolean.FALSE);
            b = map;
        }

        public b(Class<T> cls, Map<String, e> map, boolean z) {
            super(map);
            this.c = new HashMap();
            Constructor<T> constructorB = go.b(cls);
            this.d = constructorB;
            if (z) {
                gm.c(null, constructorB);
            } else {
                go.d(constructorB);
            }
            String[] strArrD = go.d((Class<?>) cls);
            for (int i = 0; i < strArrD.length; i++) {
                this.c.put(strArrD[i], Integer.valueOf(i));
            }
            Class<?>[] parameterTypes = this.d.getParameterTypes();
            this.e = new Object[parameterTypes.length];
            for (int i2 = 0; i2 < parameterTypes.length; i2++) {
                this.e[i2] = b.get(parameterTypes[i2]);
            }
        }

        @Override // com.facetec.sdk.gm.a
        public final /* synthetic */ void b(Object[] objArr, gs gsVar, e eVar) {
            Object[] objArr2 = objArr;
            Integer num = this.c.get(eVar.c);
            if (num != null) {
                eVar.d(gsVar, num.intValue(), objArr2);
                return;
            }
            StringBuilder sb = new StringBuilder("Could not find the index in the constructor '");
            sb.append(go.e((Constructor<?>) this.d));
            sb.append("' for field with name '");
            sb.append(eVar.c);
            sb.append("', unable to determine which argument in the constructor the field corresponds to. This is unexpected behavior, as we expect the RecordComponents to have the same names as the fields in the Java class, and that the order of the RecordComponents is the same as the order of the canonical constructor parameters.");
            throw new IllegalStateException(sb.toString());
        }

        /* JADX INFO: Access modifiers changed from: private */
        @Override // com.facetec.sdk.gm.a
        public T c(Object[] objArr) {
            try {
                return this.d.newInstance(objArr);
            } catch (IllegalAccessException e) {
                throw go.e(e);
            } catch (IllegalArgumentException e2) {
                e = e2;
                StringBuilder sb = new StringBuilder("Failed to invoke constructor '");
                sb.append(go.e((Constructor<?>) this.d));
                sb.append("' with args ");
                sb.append(Arrays.toString(objArr));
                throw new RuntimeException(sb.toString(), e);
            } catch (InstantiationException e3) {
                e = e3;
                StringBuilder sb2 = new StringBuilder("Failed to invoke constructor '");
                sb2.append(go.e((Constructor<?>) this.d));
                sb2.append("' with args ");
                sb2.append(Arrays.toString(objArr));
                throw new RuntimeException(sb2.toString(), e);
            } catch (InvocationTargetException e4) {
                StringBuilder sb3 = new StringBuilder("Failed to invoke constructor '");
                sb3.append(go.e((Constructor<?>) this.d));
                sb3.append("' with args ");
                sb3.append(Arrays.toString(objArr));
                throw new RuntimeException(sb3.toString(), e4.getCause());
            }
        }

        @Override // com.facetec.sdk.gm.a
        public final /* synthetic */ Object[] c() {
            return (Object[]) this.e.clone();
        }
    }

    public static final class d<T> extends a<T, T> {
        private final fu<T> a;

        public d(fu<T> fuVar, Map<String, e> map) {
            super(map);
            this.a = fuVar;
        }

        @Override // com.facetec.sdk.gm.a
        public final void b(T t, gs gsVar, e eVar) {
            eVar.e(gsVar, t);
        }

        @Override // com.facetec.sdk.gm.a
        public final T c(T t) {
            return t;
        }

        @Override // com.facetec.sdk.gm.a
        public final T c() {
            return this.a.b();
        }
    }

    public static abstract class e {
        final boolean b;
        final String c;
        final String d;
        final boolean e;

        public e(String str, String str2, boolean z, boolean z2) {
            this.d = str;
            this.c = str2;
            this.e = z;
            this.b = z2;
        }

        public abstract void a(ha haVar, Object obj);

        public abstract void d(gs gsVar, int i, Object[] objArr);

        public abstract void e(gs gsVar, Object obj);
    }

    public gm(fn fnVar, ek ekVar, fq fqVar, gg ggVar, List<fb> list) {
        this.a = fnVar;
        this.c = ekVar;
        this.d = fqVar;
        this.e = ggVar;
        this.b = list;
    }

    /* JADX WARN: Multi-variable type inference failed */
    public static /* synthetic */ void c(Object obj, AccessibleObject accessibleObject) {
        if (Modifier.isStatic(((Member) accessibleObject).getModifiers())) {
            obj = null;
        }
        if (fv.e(accessibleObject, obj)) {
            return;
        }
        String strC = go.c(accessibleObject, true);
        StringBuilder sb = new StringBuilder();
        sb.append(strC);
        sb.append(" is not accessible and ReflectionAccessFilter does not permit making it accessible. Register a TypeAdapter for the declaring type, adjust the access filter or increase the visibility of the element and its declaring type.");
        throw new er(sb.toString());
    }

    private boolean d(Field field, boolean z) {
        fq fqVar = this.d;
        if (fqVar.a(field.getType()) || fqVar.e(z)) {
            return false;
        }
        fq fqVar2 = this.d;
        if ((fqVar2.e & field.getModifiers()) != 0) {
            return false;
        }
        if ((fqVar2.d != -1.0d && !fqVar2.d((fk) field.getAnnotation(fk.class), (fj) field.getAnnotation(fj.class))) || field.isSynthetic()) {
            return false;
        }
        if (fqVar2.a) {
            fh fhVar = (fh) field.getAnnotation(fh.class);
            if (fhVar == null) {
                return false;
            }
            if (z) {
                if (!fhVar.b()) {
                    return false;
                }
            } else if (!fhVar.d()) {
                return false;
            }
        }
        if ((!fqVar2.c && fq.c(field.getType())) || fq.d(field.getType())) {
            return false;
        }
        List<ei> list = z ? fqVar2.i : fqVar2.h;
        if (list.isEmpty()) {
            return true;
        }
        new en(field);
        Iterator<ei> it = list.iterator();
        while (it.hasNext()) {
            if (it.next().b()) {
                return false;
            }
        }
        return true;
    }

    @Override // com.facetec.sdk.ff
    public final <T> fg<T> b(el elVar, gu<T> guVar) {
        Class<? super T> clsD = guVar.d();
        if (!Object.class.isAssignableFrom(clsD)) {
            return null;
        }
        fb.a aVarB = fv.b(this.b, clsD);
        if (aVarB != fb.a.BLOCK_ALL) {
            boolean z = aVarB == fb.a.BLOCK_INACCESSIBLE;
            return go.c(clsD) ? new b(clsD, b(elVar, guVar, clsD, z, true), z) : new d(this.a.e(guVar), b(elVar, guVar, clsD, z, false));
        }
        StringBuilder sb = new StringBuilder("ReflectionAccessFilter does not permit using reflection for ");
        sb.append(clsD);
        sb.append(". Register a TypeAdapter for this type or adjust the access filter.");
        throw new er(sb.toString());
    }

    /* JADX WARN: Removed duplicated region for block: B:101:0x01ec A[SYNTHETIC] */
    /* JADX WARN: Removed duplicated region for block: B:49:0x00f0  */
    /* JADX WARN: Removed duplicated region for block: B:51:0x00fd  */
    /* JADX WARN: Removed duplicated region for block: B:57:0x0127  */
    /* JADX WARN: Removed duplicated region for block: B:98:0x0204 A[SYNTHETIC] */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    private java.util.Map<java.lang.String, com.facetec.sdk.gm.e> b(com.facetec.sdk.el r31, com.facetec.sdk.gu<?> r32, java.lang.Class<?> r33, boolean r34, boolean r35) {
        /*
            Method dump skipped, instruction units count: 585
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: com.facetec.sdk.gm.b(com.facetec.sdk.el, com.facetec.sdk.gu, java.lang.Class, boolean, boolean):java.util.Map");
    }
}