package com.facetec.sdk;

import ai.luciq.library.logging.LuciqLog;
import ai.luciq.library.screenshot.analytics.ScreenShotAnalyticsMapper;
import android.content.Context;
import android.graphics.PointF;
import android.os.Process;
import android.os.SystemClock;
import android.text.TextUtils;
import android.view.KeyEvent;
import android.view.ViewConfiguration;
import com.facetec.sdk.bd;
import com.facetec.sdk.cb;
import com.incode.welcome_sdk.modules.SelfieScan;
import com.plaid.internal.EnumC41897g;
import io.sentry.metrics.MetricsUnit;
import java.lang.reflect.AccessibleObject;
import java.lang.reflect.Constructor;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.math.BigDecimal;
import java.math.BigInteger;
import java.net.InetAddress;
import java.net.URI;
import java.net.URISyntaxException;
import java.net.URL;
import java.security.AccessController;
import java.security.PrivilegedAction;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.BitSet;
import java.util.Calendar;
import java.util.Currency;
import java.util.GregorianCalendar;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Locale;
import java.util.Map;
import java.util.Random;
import java.util.StringTokenizer;
import java.util.UUID;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.atomic.AtomicIntegerArray;
import net.sf.scuba.smartcards.ISO7816;
import net.sf.scuba.smartcards.ISOFileInfo;
import org.jmrtd.PassportService;
import org.jmrtd.lds.CVCAFile;

/* JADX INFO: loaded from: classes4.dex */
public final class gn {
    public static final ff A;
    public static final ff B;
    public static final ff C;
    public static final ff D;
    private static fg<Number> E;
    private static fg<BitSet> F;
    private static fg<Number> G;
    private static fg<Boolean> H;
    private static fg<Class> I;
    private static fg<Character> J;
    private static fg<Number> K;
    private static fg<AtomicBoolean> L;
    private static fg<AtomicIntegerArray> M;
    private static fg<AtomicInteger> N;
    private static fg<String> O;
    private static fg<StringBuilder> P;
    private static fg<URI> Q;
    private static fg<URL> R;
    private static fg<StringBuffer> S;
    private static fg<UUID> T;
    private static fg<InetAddress> U;
    private static fg<Calendar> V;
    private static fg<Locale> W;
    private static fg<Currency> X;
    public static final ff a;
    public static final fg<Boolean> b;
    public static final ff c;
    public static final ff d;
    public static final ff e;
    public static final ff f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public static final ff f95895g;
    public static final ff h;
    public static final ff i;
    public static final ff j;
    public static final fg<Number> k;
    public static final fg<BigDecimal> l;
    public static final fg<Number> m;
    public static final ff n;
    public static final fg<Number> o;
    public static final ff p;
    public static final fg<BigInteger> q;
    public static final ff r;
    public static final ff s;
    public static final fg<fp> t;
    public static final ff u;
    public static final ff v;
    public static final ff w;
    public static final ff x;
    public static final ff y;
    public static final fg<es> z;

    /* JADX INFO: renamed from: com.facetec.sdk.gn$18, reason: invalid class name */
    public class AnonymousClass18 extends fg<Currency> {
        private static final byte[] $$a = null;
        private static final int $$b = 0;
        private static final byte[] $$c = null;
        private static final byte[] $$d = null;
        private static final int $$e = 0;
        private static final int $$f = 0;
        private static int $10;
        private static int $11;
        private static int a;
        private static long b;
        private static int c;
        private static int e;

        /* JADX WARN: Removed duplicated region for block: B:10:0x0024  */
        /* JADX WARN: Removed duplicated region for block: B:8:0x001e  */
        /* JADX WARN: Unsupported multi-entry loop pattern (BACK_EDGE: B:10:0x0024 -> B:11:0x002e). Please report as a decompilation issue!!! */
        /*
            Code decompiled incorrectly, please refer to instructions dump.
            To view partially-correct code enable 'Show inconsistent code' option in preferences
        */
        private static java.lang.String $$g(byte r6, byte r7, byte r8) {
            /*
                int r7 = r7 * 4
                int r7 = 4 - r7
                byte[] r0 = com.facetec.sdk.gn.AnonymousClass18.$$c
                int r6 = r6 + 99
                int r8 = r8 * 2
                int r1 = 1 - r8
                byte[] r1 = new byte[r1]
                r2 = 0
                int r8 = 0 - r8
                if (r0 != 0) goto L18
                r3 = r0
                r4 = r2
                r0 = r7
                r7 = r8
                goto L2e
            L18:
                r3 = r2
            L19:
                byte r4 = (byte) r6
                r1[r3] = r4
                if (r3 != r8) goto L24
                java.lang.String r6 = new java.lang.String
                r6.<init>(r1, r2)
                return r6
            L24:
                r4 = r0[r7]
                int r3 = r3 + 1
                r5 = r7
                r7 = r6
                r6 = r4
                r4 = r3
                r3 = r0
                r0 = r5
            L2e:
                int r6 = -r6
                int r6 = r6 + r7
                int r7 = r0 + 1
                r0 = r3
                r3 = r4
                goto L19
            */
            throw new UnsupportedOperationException("Method not decompiled: com.facetec.sdk.gn.AnonymousClass18.$$g(byte, byte, byte):java.lang.String");
        }

        static {
            init$2();
            $10 = 0;
            $11 = 1;
            init$1();
            init$0();
            a = 0;
            c = 1;
            e = 1605274430;
            b = 6695477809520062164L;
        }

        /* JADX WARN: Removed duplicated region for block: B:162:0x1421  */
        /* JADX WARN: Removed duplicated region for block: B:174:0x1590  */
        /* JADX WARN: Removed duplicated region for block: B:176:0x1595 A[PHI: r0 r7 r10
          0x1595: PHI (r0v40 int) = (r0v39 int), (r0v309 int) binds: [B:99:0x104c, B:121:0x10f2] A[DONT_GENERATE, DONT_INLINE]
          0x1595: PHI (r7v13 int) = (r7v12 int), (r7v739 int) binds: [B:99:0x104c, B:121:0x10f2] A[DONT_GENERATE, DONT_INLINE]
          0x1595: PHI (r10v30 java.lang.Class) = (r10v29 java.lang.Class), (r10v111 java.lang.Class) binds: [B:99:0x104c, B:121:0x10f2] A[DONT_GENERATE, DONT_INLINE]] */
        /* JADX WARN: Removed duplicated region for block: B:214:0x1b53  */
        /* JADX WARN: Removed duplicated region for block: B:262:0x1f70 A[PHI: r18
          0x1f70: PHI (r18v37 char) = (r18v21 char), (r18v22 char), (r18v40 char), (r18v40 char), (r18v40 char), (r18v40 char), (r18v40 char) binds: [B:305:0x2123, B:516:0x1f70, B:272:0x1ff6, B:284:0x20ee, B:291:0x2101, B:276:0x2037, B:261:0x1f6e] A[DONT_GENERATE, DONT_INLINE]] */
        /* JADX WARN: Removed duplicated region for block: B:263:0x1f73  */
        /* JADX WARN: Removed duplicated region for block: B:316:0x21f8 A[PHI: r0
          0x21f8: PHI (r0v225 int) = (r0v121 int), (r0v121 int), (r0v122 int) binds: [B:315:0x21f6, B:323:0x236e, B:560:0x21f8] A[DONT_GENERATE, DONT_INLINE]] */
        /* JADX WARN: Removed duplicated region for block: B:42:0x03e9  */
        /* JADX WARN: Removed duplicated region for block: B:52:0x04ea  */
        /* JADX WARN: Removed duplicated region for block: B:70:0x06e2  */
        /* JADX WARN: Removed duplicated region for block: B:80:0x0820  */
        /* JADX WARN: Removed duplicated region for block: B:87:0x08e7  */
        /*
            Code decompiled incorrectly, please refer to instructions dump.
            To view partially-correct code enable 'Show inconsistent code' option in preferences
        */
        public static java.lang.Object[] a$5fe48fd(int r81, java.lang.Object r82) throws java.lang.Throwable {
            /*
                Method dump skipped, instruction units count: 15354
                To view this dump change 'Code comments level' option to 'DEBUG'
            */
            throw new UnsupportedOperationException("Method not decompiled: com.facetec.sdk.gn.AnonymousClass18.a$5fe48fd(int, java.lang.Object):java.lang.Object[]");
        }

        /* JADX WARN: Multi-variable type inference failed */
        /* JADX WARN: Type inference failed for: r0v2, types: [int, java.lang.String] */
        private static Currency c(gs gsVar) {
            int i = a + 67;
            c = i % 128;
            ?? r0 = i % 2;
            try {
                if (r0 != 0) {
                    return Currency.getInstance(gsVar.h());
                }
                Currency.getInstance(gsVar.h());
                throw null;
            } catch (IllegalArgumentException e2) {
                StringBuilder sb = new StringBuilder("Failed parsing '");
                sb.append((String) r0);
                sb.append("' as Currency; at path ");
                sb.append(gsVar.q());
                throw new fc(sb.toString(), e2);
            }
        }

        /* JADX WARN: Removed duplicated region for block: B:10:0x0025  */
        /* JADX WARN: Removed duplicated region for block: B:8:0x001d  */
        /* JADX WARN: Unsupported multi-entry loop pattern (BACK_EDGE: B:10:0x0025 -> B:11:0x0027). Please report as a decompilation issue!!! */
        /*
            Code decompiled incorrectly, please refer to instructions dump.
            To view partially-correct code enable 'Show inconsistent code' option in preferences
        */
        private static void f(byte r6, int r7, int r8, java.lang.Object[] r9) {
            /*
                int r8 = 101 - r8
                int r6 = r6 * 4
                int r6 = r6 + 1
                byte[] r0 = com.facetec.sdk.gn.AnonymousClass18.$$d
                int r7 = r7 * 2
                int r7 = 4 - r7
                byte[] r1 = new byte[r6]
                r2 = 0
                if (r0 != 0) goto L15
                r3 = r8
                r5 = r2
                r8 = r7
                goto L27
            L15:
                r3 = r2
            L16:
                byte r4 = (byte) r8
                int r5 = r3 + 1
                r1[r3] = r4
                if (r5 != r6) goto L25
                java.lang.String r6 = new java.lang.String
                r6.<init>(r1, r2)
                r9[r2] = r6
                return
            L25:
                r3 = r0[r7]
            L27:
                int r7 = r7 + 1
                int r3 = -r3
                int r8 = r8 + r3
                r3 = r5
                goto L16
            */
            throw new UnsupportedOperationException("Method not decompiled: com.facetec.sdk.gn.AnonymousClass18.f(byte, int, int, java.lang.Object[]):void");
        }

        /* JADX WARN: Removed duplicated region for block: B:40:0x0166  */
        /* JADX WARN: Removed duplicated region for block: B:41:0x0167  */
        /*
            Code decompiled incorrectly, please refer to instructions dump.
            To view partially-correct code enable 'Show inconsistent code' option in preferences
        */
        private static void g(int r25, int r26, int r27, boolean r28, java.lang.String r29, java.lang.Object[] r30) throws java.lang.Throwable {
            /*
                Method dump skipped, instruction units count: 372
                To view this dump change 'Code comments level' option to 'DEBUG'
            */
            throw new UnsupportedOperationException("Method not decompiled: com.facetec.sdk.gn.AnonymousClass18.g(int, int, int, boolean, java.lang.String, java.lang.Object[]):void");
        }

        /* JADX WARN: Removed duplicated region for block: B:37:0x013a  */
        /* JADX WARN: Removed duplicated region for block: B:38:0x013b  */
        /*
            Code decompiled incorrectly, please refer to instructions dump.
            To view partially-correct code enable 'Show inconsistent code' option in preferences
        */
        private static void h(java.lang.String r21, int r22, java.lang.Object[] r23) throws java.lang.Throwable {
            /*
                Method dump skipped, instruction units count: 324
                To view this dump change 'Code comments level' option to 'DEBUG'
            */
            throw new UnsupportedOperationException("Method not decompiled: com.facetec.sdk.gn.AnonymousClass18.h(java.lang.String, int, java.lang.Object[]):void");
        }

        /* JADX WARN: Removed duplicated region for block: B:10:0x0029  */
        /* JADX WARN: Removed duplicated region for block: B:8:0x0021  */
        /* JADX WARN: Unsupported multi-entry loop pattern (BACK_EDGE: B:10:0x0029 -> B:11:0x0030). Please report as a decompilation issue!!! */
        /*
            Code decompiled incorrectly, please refer to instructions dump.
            To view partially-correct code enable 'Show inconsistent code' option in preferences
        */
        private static void i(short r6, int r7, int r8, java.lang.Object[] r9) {
            /*
                int r6 = r6 * 9
                int r6 = 115 - r6
                byte[] r0 = com.facetec.sdk.gn.AnonymousClass18.$$a
                int r7 = r7 * 15
                int r7 = 18 - r7
                int r8 = r8 * 11
                int r1 = r8 + 5
                byte[] r1 = new byte[r1]
                int r8 = r8 + 4
                r2 = 0
                if (r0 != 0) goto L19
                r6 = r7
                r4 = r8
                r3 = r2
                goto L30
            L19:
                r3 = r2
            L1a:
                byte r4 = (byte) r6
                int r7 = r7 + 1
                r1[r3] = r4
                if (r3 != r8) goto L29
                java.lang.String r6 = new java.lang.String
                r6.<init>(r1, r2)
                r9[r2] = r6
                return
            L29:
                int r3 = r3 + 1
                r4 = r0[r7]
                r5 = r7
                r7 = r6
                r6 = r5
            L30:
                int r7 = r7 + r4
                int r7 = r7 + 2
                r5 = r7
                r7 = r6
                r6 = r5
                goto L1a
            */
            throw new UnsupportedOperationException("Method not decompiled: com.facetec.sdk.gn.AnonymousClass18.i(short, int, int, java.lang.Object[]):void");
        }

        public static void init$0() {
            $$a = new byte[]{ISO7816.INS_DECREASE, 86, 58, 71, -11, 19, -23, -53, 60, -13, PassportService.SFI_DG11, -9, -59, ISO7816.INS_CHANGE_CHV, 18, 8, -15, -6, 1, -1, -21, PassportService.SFI_DG15, 0};
            $$b = 114;
        }

        public static void init$1() {
            $$d = new byte[]{23, 124, -70, -17};
            $$e = EnumC41897g.SDK_ASSET_ILLUSTRATION_EXIT_VALUE;
        }

        public static void init$2() {
            $$c = new byte[]{121, -58, 81, 67};
            $$f = 100;
        }

        @Override // com.facetec.sdk.fg
        public final /* synthetic */ Currency a(gs gsVar) {
            a = (c + 33) % 128;
            Currency currencyC = c(gsVar);
            int i = c + 117;
            a = i % 128;
            if (i % 2 != 0) {
                int i2 = 48 / 0;
            }
            return currencyC;
        }

        @Override // com.facetec.sdk.fg
        public final /* bridge */ /* synthetic */ void e(ha haVar, Currency currency) {
            a = (c + 61) % 128;
            haVar.e(currency.getCurrencyCode());
            a = (c + 41) % 128;
        }
    }

    /* JADX INFO: renamed from: com.facetec.sdk.gn$22, reason: invalid class name */
    public class AnonymousClass22 extends fg<es> {
        public static int b;
        public static int d;

        private static es b(gs gsVar, gw gwVar) {
            int i = AnonymousClass27.d[gwVar.ordinal()];
            if (i == 4) {
                gsVar.c();
                return new et();
            }
            if (i != 5) {
                return null;
            }
            gsVar.d();
            return new ey();
        }

        public static int c() {
            int i = b;
            int i2 = i % 5905017;
            b = i + 1;
            if (i2 != 0) {
                return d;
            }
            int iMyTid = Process.myTid();
            d = iMyTid;
            return iMyTid;
        }

        @Override // com.facetec.sdk.fg
        public final /* bridge */ /* synthetic */ es a(gs gsVar) {
            if (gsVar instanceof gh) {
                gh ghVar = (gh) gsVar;
                gw gwVarJ = ghVar.j();
                if (gwVarJ != gw.NAME && gwVarJ != gw.END_ARRAY && gwVarJ != gw.END_OBJECT && gwVarJ != gw.END_DOCUMENT) {
                    es esVar = (es) ghVar.i();
                    ghVar.l();
                    return esVar;
                }
                StringBuilder sb = new StringBuilder("Unexpected ");
                sb.append(gwVarJ);
                sb.append(" when reading a JsonElement.");
                throw new IllegalStateException(sb.toString());
            }
            gw gwVarJ2 = gsVar.j();
            es esVarB = b(gsVar, gwVarJ2);
            if (esVarB == null) {
                return e(gsVar, gwVarJ2);
            }
            ArrayDeque arrayDeque = new ArrayDeque();
            while (true) {
                if (gsVar.b()) {
                    String strG = esVarB instanceof ey ? gsVar.g() : null;
                    gw gwVarJ3 = gsVar.j();
                    es esVarB2 = b(gsVar, gwVarJ3);
                    boolean z = esVarB2 != null;
                    if (esVarB2 == null) {
                        esVarB2 = e(gsVar, gwVarJ3);
                    }
                    if (esVarB instanceof et) {
                        ((et) esVarB).b(esVarB2);
                    } else {
                        ((ey) esVarB).a(strG, esVarB2);
                    }
                    if (z) {
                        arrayDeque.addLast(esVarB);
                        esVarB = esVarB2;
                    }
                } else {
                    if (esVarB instanceof et) {
                        gsVar.e();
                    } else {
                        gsVar.a();
                    }
                    if (arrayDeque.isEmpty()) {
                        return esVarB;
                    }
                    esVarB = (es) arrayDeque.removeLast();
                }
            }
        }

        private static es e(gs gsVar, gw gwVar) {
            int i = AnonymousClass27.d[gwVar.ordinal()];
            if (i == 1) {
                return new eu(new fp(gsVar.h()));
            }
            if (i == 2) {
                return new eu(gsVar.h());
            }
            if (i == 3) {
                return new eu(Boolean.valueOf(gsVar.f()));
            }
            if (i != 6) {
                throw new IllegalStateException("Unexpected token: ".concat(String.valueOf(gwVar)));
            }
            gsVar.m();
            return ex.e;
        }

        /* JADX INFO: Access modifiers changed from: private */
        @Override // com.facetec.sdk.fg
        /* JADX INFO: renamed from: b, reason: merged with bridge method [inline-methods] */
        public void e(ha haVar, es esVar) {
            if (esVar != null && !esVar.l()) {
                if (esVar.j()) {
                    eu euVarM = esVar.m();
                    int iC = bd.d.c();
                    int iC2 = bd.d.c();
                    int iC3 = bd.d.c();
                    if (((Boolean) eu.d(iC, 13458657, bd.d.c(), iC2, new Object[]{euVarM}, -13458657, iC3)).booleanValue()) {
                        haVar.b(euVarM.e());
                        return;
                    } else if (euVarM.h()) {
                        haVar.b(euVarM.i());
                        return;
                    } else {
                        haVar.e(euVarM.c());
                        return;
                    }
                }
                if (esVar.f()) {
                    haVar.e();
                    if (esVar.f()) {
                        Iterator<es> it = ((et) esVar).iterator();
                        while (it.hasNext()) {
                            e(haVar, it.next());
                        }
                        haVar.a();
                        return;
                    }
                    throw new IllegalStateException("Not a JSON Array: ".concat(String.valueOf(esVar)));
                }
                if (esVar.g()) {
                    haVar.c();
                    if (esVar.g()) {
                        for (Map.Entry<String, es> entry : ((ey) esVar).h()) {
                            haVar.c(entry.getKey());
                            e(haVar, entry.getValue());
                        }
                        haVar.b();
                        return;
                    }
                    throw new IllegalStateException("Not a JSON Object: ".concat(String.valueOf(esVar)));
                }
                StringBuilder sb = new StringBuilder("Couldn't write ");
                sb.append(esVar.getClass());
                throw new IllegalArgumentException(sb.toString());
            }
            haVar.g();
        }
    }

    /* JADX INFO: renamed from: com.facetec.sdk.gn$27, reason: invalid class name */
    public static /* synthetic */ class AnonymousClass27 {
        static final /* synthetic */ int[] d;

        static {
            int[] iArr = new int[gw.values().length];
            d = iArr;
            try {
                iArr[gw.NUMBER.ordinal()] = 1;
            } catch (NoSuchFieldError unused) {
            }
            try {
                d[gw.STRING.ordinal()] = 2;
            } catch (NoSuchFieldError unused2) {
            }
            try {
                d[gw.BOOLEAN.ordinal()] = 3;
            } catch (NoSuchFieldError unused3) {
            }
            try {
                d[gw.BEGIN_ARRAY.ordinal()] = 4;
            } catch (NoSuchFieldError unused4) {
            }
            try {
                d[gw.BEGIN_OBJECT.ordinal()] = 5;
            } catch (NoSuchFieldError unused5) {
            }
            try {
                d[gw.NULL.ordinal()] = 6;
            } catch (NoSuchFieldError unused6) {
            }
        }
    }

    /* JADX INFO: renamed from: com.facetec.sdk.gn$28, reason: invalid class name */
    public class AnonymousClass28 implements ff {
        public static int c;
        public static int d;
        final /* synthetic */ fg a;
        private /* synthetic */ Class e;

        public AnonymousClass28(Class cls, fg fgVar) {
            this.e = cls;
            this.a = fgVar;
        }

        public static int e() {
            int i = d;
            int i2 = i % 8628999;
            d = i + 1;
            if (i2 != 0) {
                return c;
            }
            int iFreeMemory = (int) Runtime.getRuntime().freeMemory();
            c = iFreeMemory;
            return iFreeMemory;
        }

        @Override // com.facetec.sdk.ff
        public final <T2> fg<T2> b(el elVar, gu<T2> guVar) {
            final Class<? super T2> clsD = guVar.d();
            if (this.e.isAssignableFrom(clsD)) {
                return (fg<T2>) new fg<T1>() { // from class: com.facetec.sdk.gn.28.1
                    @Override // com.facetec.sdk.fg
                    public final T1 a(gs gsVar) {
                        T1 t1 = (T1) AnonymousClass28.this.a.a(gsVar);
                        if (t1 == null || clsD.isInstance(t1)) {
                            return t1;
                        }
                        StringBuilder sb = new StringBuilder("Expected a ");
                        sb.append(clsD.getName());
                        sb.append(" but was ");
                        sb.append(t1.getClass().getName());
                        sb.append("; at path ");
                        sb.append(gsVar.q());
                        throw new fc(sb.toString());
                    }

                    @Override // com.facetec.sdk.fg
                    public final void e(ha haVar, T1 t1) {
                        AnonymousClass28.this.a.e(haVar, t1);
                    }
                };
            }
            return null;
        }

        public final String toString() {
            StringBuilder sb = new StringBuilder("Factory[typeHierarchy=");
            sb.append(this.e.getName());
            sb.append(",adapter=");
            sb.append(this.a);
            sb.append("]");
            return sb.toString();
        }
    }

    /* JADX INFO: renamed from: com.facetec.sdk.gn$4, reason: invalid class name */
    public class AnonymousClass4 extends fg<Number> {
        private static final byte[] $$a = null;
        private static final int $$b = 0;
        private static final byte[] $$c = null;
        private static final byte[] $$d = null;
        private static final int $$e = 0;
        private static final int $$f = 0;
        private static int $10;
        private static int $11;
        private static int a;
        private static char[] b;
        private static long c;
        private static long d;
        private static int e;

        /* JADX WARN: Removed duplicated region for block: B:10:0x0022  */
        /* JADX WARN: Removed duplicated region for block: B:8:0x001c  */
        /* JADX WARN: Unsupported multi-entry loop pattern (BACK_EDGE: B:10:0x0022 -> B:11:0x0024). Please report as a decompilation issue!!! */
        /*
            Code decompiled incorrectly, please refer to instructions dump.
            To view partially-correct code enable 'Show inconsistent code' option in preferences
        */
        private static java.lang.String $$g(short r6, int r7, byte r8) {
            /*
                int r8 = 111 - r8
                int r6 = r6 * 3
                int r6 = r6 + 1
                byte[] r0 = com.facetec.sdk.gn.AnonymousClass4.$$c
                int r7 = r7 * 3
                int r7 = r7 + 4
                byte[] r1 = new byte[r6]
                r2 = 0
                if (r0 != 0) goto L14
                r3 = r6
                r4 = r2
                goto L24
            L14:
                r3 = r2
            L15:
                int r4 = r3 + 1
                byte r5 = (byte) r8
                r1[r3] = r5
                if (r4 != r6) goto L22
                java.lang.String r6 = new java.lang.String
                r6.<init>(r1, r2)
                return r6
            L22:
                r3 = r0[r7]
            L24:
                int r8 = r8 + r3
                int r7 = r7 + 1
                r3 = r4
                goto L15
            */
            throw new UnsupportedOperationException("Method not decompiled: com.facetec.sdk.gn.AnonymousClass4.$$g(short, int, byte):java.lang.String");
        }

        static {
            init$2();
            $10 = 0;
            $11 = 1;
            init$1();
            init$0();
            a = 0;
            e = 1;
            c = 1353515813577673669L;
            b = new char[]{57911, 37947, 3608, 32866, 14916, 44202, 57919, 37933, 3588, 32872, 14918, 44196, 28645, 6649, 33744, 3488, 46996, 8565, 43863, 21886, 57091, 18685, 4110, 26131, 64559, 29248, 51312, 24196, 54442, 10956, 44171, 55958, 16554, 52928, 29924, 57871, 26669, 38478, 7270, 35727, 12729, 49101, 9723, 21252, 57892, 37932, 3589, 32868, 14943, 44195, 9880, 57893, 37921, 3591, 32892, 14919, 44204, 9884, 39471, 60471, 30224, 63584, 16963, 54434, 57893, 37948, 34826, 65043, 25633, 59968, 20583, 50837, 19621, 45779, 14574, 57891, 37927, 3615, 32866, 14916, 44201, 9907, 55549, 21195, 50470, 32575, 61802, 27468, 7587, 38795, 57891, 37927, 3615, 32866, 14916, 44201, 9907, 55548, 21207, 50476, 32514, 61804, 27470, 7606, 57977, 37946, 3601, 32888, 14942, 44200, 9857, 55456, 21196, 50472, 32526, 61740, 41299, 55056, 19771, 50002, 31023, 61313, 26037, 39818, 4599, 34318, 15398, 45632, 10342, 24218, 54454, 19074, 49385, 31005, 61236, 25950, 39778, 4500, 34739, 57977, 37933, 3597, 32893, 57977, 37946, 3601, 32888, 14942, 44200, 9857, 57977, 37946, 3601, 32888, 14942, 44200, 9857, 55456, 21213, 50467, 32521, 61805, 57977, 37951, 3597, 32869, 14926, 44194, 9886, 55456, 21196, 50472, 32526, 57977, 37946, 3594, 32866, 14916, 57892, 37926, 3654, 32873, 14943, 44196, 9856, 55531, 21120, 50473, 32527, 61808, 27478, 57919, 37927, 3585, 32895, 14852, 44222, 9882, 55532, 21120, 50482, 32533, 61788, 27462, 7588, 38785, 2538, 33737, 14903, 57892, 37948, 3590, 32869, 14915, 44195, 9867, 57977, 37933, 3593, 32895, 14923, 44258, 9856, 55520, 21197, 50464, 32524, 61740, 57977, 37933, 3593, 32895, 14923, 44258, 9856, 55520, 21197, 50464, 32524, 61740, 27482, 7591, 38797, 2537, 33673, 47554, 53121, 21937, 56281, 25087, 63321, 35685, 64806, 26381, 59748, 21314, 50612, 20381, 45500, 15312, 44084, 5650, 38960, 528, 29884, 65152, 24815, 60053, 57977, 37946, 3601, 32888, 14942, 44200, 9857, 55456, 21213, 50469, 32591, 61819, 27456, 7596, 38794, 2472, 57977, 37948, 3611, 32889, 14853, 44207, 9861, 55521, 21121, 58814, 37885, 2522, 34787, 15759, 43875, 8517, 57191, 29560, 1292, 40752, 4423, 43778, 15763, 57977, 37924, 3591, 32894, 14916, 44217, 9887, 57977, 37946, 3601, 32888, 14853, 44203, 9887, 55456, 21213, 50468, 32524, 61802, 27468, 7600, 38812, 2472, 33750, 14902, 44052, 9842, 55385, 21156};
            d = 5436242896150107209L;
        }

        /* JADX WARN: Can't wrap try/catch for region: R(146:0|2|634|3|(1:5)|6|7|8|9|(1:11)(1:12)|13|14|(6:16|17|(1:19)(1:20)|21|22|(142:24|25|(1:27)|28|29|30|(1:32)(1:33)|34|(139:36|(1:38)(1:39)|40|41|(0)(1:44)|81|(6:83|84|(1:86)|87|88|(1:90)(1:91))(5:92|93|(1:95)|96|97)|(1:99)|103|104|(1:106)(1:107)|108|(128:110|(2:111|(4:113|(1:115)(1:117)|116|(2:119|(1:644)(1:122))(3:643|123|124))(2:642|125))|(128:127|(1:129)(1:130)|131|(11:133|134|(1:136)(1:137)|138|139|140|(1:142)(1:143)|144|(1:146)(1:147)|148|(3:150|164|(4:166|(1:168)|169|170)(5:173|174|(1:176)|177|178))(1:(6:182|183|(1:185)|186|187|(4:189|(4:190|(1:192)(1:193)|194|(1:645)(7:199|200|(1:202)(1:203)|204|205|(2:207|647)(2:208|646)|209))|196|(1:198)))))(9:151|152|(1:154)|155|156|157|(1:159)(1:160)|161|(0)(0))|213|214|(1:216)|217|218|219|(1:221)|222|223|(3:225|(1:227)(1:228)|(4:230|(1:232)(1:234)|233|(1:238)(1:237))(0))(0)|239|240|(1:242)|243|244|245|(1:247)|248|249|(1:265)(4:251|(1:253)(1:254)|255|(4:258|(1:260)(1:261)|262|(1:264)(0))(0))|266|(4:267|(1:269)(1:270)|271|(6:273|274|(1:276)(1:277)|278|279|(2:649|281)(1:282))(2:648|283))|284|614|285|619|286|(1:288)|291|(1:293)(1:294)|295|(11:297|298|630|299|(1:301)|304|305|306|307|(1:309)(9:311|316|626|317|(1:319)|322|(1:324)(1:326)|325|(0)(2:329|(3:331|332|(1:334)(7:335|338|606|339|(1:341)|344|(0)(4:346|(1:348)(1:349)|350|(2:352|(1:354)(1:355)))))(2:336|(6:338|606|339|(0)|344|(0)(0)))))|310)(0)|368|369|(1:371)|372|(7:374|375|(1:377)|378|379|(1:381)(1:382)|(1:398)(4:385|(7:388|389|(1:391)(1:392)|393|394|(2:651|396)(1:397)|386)|650|398))(0)|399|636|400|401|(4:638|402|403|(4:405|(3:408|(3:410|(1:412)(1:413)|(3:415|655|426)(1:653))(3:418|419|(1:652)(2:656|426))|406)|654|427)(4:617|428|429|430))|421|422|423|604|424|(1:441)(1:442)|443|640|444|445|(5:615|446|447|(1:449)(1:450)|(4:452|659|(3:454|(1:456)(1:457)|(5:459|460|(1:462)(1:464)|463|(2:466|660)(4:658|467|610|468))(4:657|472|473|474))|661)(3:623|475|476))|(2:487|(1:489)(1:490))(0)|491|492|(1:494)|495|496|(1:498)(1:499)|500|501|(1:503)|504|505|(1:507)(1:508)|509|510|(1:512)|513|514|515|(1:517)|518|519|520|(1:522)|523|524|(1:526)|527|528|(1:530)(1:531)|532|533|534|(1:536)|537|538|539|(1:541)|542|543|544|(1:546)|547|548|(1:550)|551|552|(1:554)|555|556|(1:558)(1:559)|560|561|(1:563)|564|565|566|(1:568)|569|570|571|(1:573)|574|575|576|(1:578)|579|621|580|581|582)|212|213|214|(0)|217|218|219|(0)|222|223|(0)(0)|239|240|(0)|243|244|245|(0)|248|249|(0)(0)|266|(5:267|(0)(0)|271|(0)(0)|282)|284|614|285|619|286|(0)|291|(0)(0)|295|(0)(0)|368|369|(0)|372|(0)(0)|399|636|400|401|(5:638|402|403|(0)(0)|427)|421|422|423|604|424|(0)(0)|443|640|444|445|(6:615|446|447|(0)(0)|(0)(0)|661)|(0)(0)|491|492|(0)|495|496|(0)(0)|500|501|(0)|504|505|(0)(0)|509|510|(0)|513|514|515|(0)|518|519|520|(0)|523|524|(0)|527|528|(0)(0)|532|533|534|(0)|537|538|539|(0)|542|543|544|(0)|547|548|(0)|551|552|(0)|555|556|(0)(0)|560|561|(0)|564|565|566|(0)|569|570|571|(0)|574|575|576|(0)|579|621|580|581|582)(1:211)|210|212|213|214|(0)|217|218|219|(0)|222|223|(0)(0)|239|240|(0)|243|244|245|(0)|248|249|(0)(0)|266|(5:267|(0)(0)|271|(0)(0)|282)|284|614|285|619|286|(0)|291|(0)(0)|295|(0)(0)|368|369|(0)|372|(0)(0)|399|636|400|401|(5:638|402|403|(0)(0)|427)|421|422|423|604|424|(0)(0)|443|640|444|445|(6:615|446|447|(0)(0)|(0)(0)|661)|(0)(0)|491|492|(0)|495|496|(0)(0)|500|501|(0)|504|505|(0)(0)|509|510|(0)|513|514|515|(0)|518|519|520|(0)|523|524|(0)|527|528|(0)(0)|532|533|534|(0)|537|538|539|(0)|542|543|544|(0)|547|548|(0)|551|552|(0)|555|556|(0)(0)|560|561|(0)|564|565|566|(0)|569|570|571|(0)|574|575|576|(0)|579|621|580|581|582)(1:45)|(137:47|48|(1:50)|51|52|(0)(3:81|(0)(0)|(0)(0))|103|104|(0)(0)|108|(0)(0)|210|212|213|214|(0)|217|218|219|(0)|222|223|(0)(0)|239|240|(0)|243|244|245|(0)|248|249|(0)(0)|266|(5:267|(0)(0)|271|(0)(0)|282)|284|614|285|619|286|(0)|291|(0)(0)|295|(0)(0)|368|369|(0)|372|(0)(0)|399|636|400|401|(5:638|402|403|(0)(0)|427)|421|422|423|604|424|(0)(0)|443|640|444|445|(6:615|446|447|(0)(0)|(0)(0)|661)|(0)(0)|491|492|(0)|495|496|(0)(0)|500|501|(0)|504|505|(0)(0)|509|510|(0)|513|514|515|(0)|518|519|520|(0)|523|524|(0)|527|528|(0)(0)|532|533|534|(0)|537|538|539|(0)|542|543|544|(0)|547|548|(0)|551|552|(0)|555|556|(0)(0)|560|561|(0)|564|565|566|(0)|569|570|571|(0)|574|575|576|(0)|579|621|580|581|582)(1:55)|(6:57|58|(1:60)|61|62|(1:(2:65|(5:67|(1:69)|70|71|(0))(6:74|75|(1:77)|78|79|(0))))(0))(0)|103|104|(0)(0)|108|(0)(0)|210|212|213|214|(0)|217|218|219|(0)|222|223|(0)(0)|239|240|(0)|243|244|245|(0)|248|249|(0)(0)|266|(5:267|(0)(0)|271|(0)(0)|282)|284|614|285|619|286|(0)|291|(0)(0)|295|(0)(0)|368|369|(0)|372|(0)(0)|399|636|400|401|(5:638|402|403|(0)(0)|427)|421|422|423|604|424|(0)(0)|443|640|444|445|(6:615|446|447|(0)(0)|(0)(0)|661)|(0)(0)|491|492|(0)|495|496|(0)(0)|500|501|(0)|504|505|(0)(0)|509|510|(0)|513|514|515|(0)|518|519|520|(0)|523|524|(0)|527|528|(0)(0)|532|533|534|(0)|537|538|539|(0)|542|543|544|(0)|547|548|(0)|551|552|(0)|555|556|(0)(0)|560|561|(0)|564|565|566|(0)|569|570|571|(0)|574|575|576|(0)|579|621|580|581|582)(1:100))(1:101)|102|103|104|(0)(0)|108|(0)(0)|210|212|213|214|(0)|217|218|219|(0)|222|223|(0)(0)|239|240|(0)|243|244|245|(0)|248|249|(0)(0)|266|(5:267|(0)(0)|271|(0)(0)|282)|284|614|285|619|286|(0)|291|(0)(0)|295|(0)(0)|368|369|(0)|372|(0)(0)|399|636|400|401|(5:638|402|403|(0)(0)|427)|421|422|423|604|424|(0)(0)|443|640|444|445|(6:615|446|447|(0)(0)|(0)(0)|661)|(0)(0)|491|492|(0)|495|496|(0)(0)|500|501|(0)|504|505|(0)(0)|509|510|(0)|513|514|515|(0)|518|519|520|(0)|523|524|(0)|527|528|(0)(0)|532|533|534|(0)|537|538|539|(0)|542|543|544|(0)|547|548|(0)|551|552|(0)|555|556|(0)(0)|560|561|(0)|564|565|566|(0)|569|570|571|(0)|574|575|576|(0)|579|621|580|581|582|(1:(0))) */
        /* JADX WARN: Can't wrap try/catch for region: R(96:(5:(6:16|17|(1:19)(1:20)|21|22|(142:24|25|(1:27)|28|29|30|(1:32)(1:33)|34|(139:36|(1:38)(1:39)|40|41|(0)(1:44)|81|(6:83|84|(1:86)|87|88|(1:90)(1:91))(5:92|93|(1:95)|96|97)|(1:99)|103|104|(1:106)(1:107)|108|(128:110|(2:111|(4:113|(1:115)(1:117)|116|(2:119|(1:644)(1:122))(3:643|123|124))(2:642|125))|(128:127|(1:129)(1:130)|131|(11:133|134|(1:136)(1:137)|138|139|140|(1:142)(1:143)|144|(1:146)(1:147)|148|(3:150|164|(4:166|(1:168)|169|170)(5:173|174|(1:176)|177|178))(1:(6:182|183|(1:185)|186|187|(4:189|(4:190|(1:192)(1:193)|194|(1:645)(7:199|200|(1:202)(1:203)|204|205|(2:207|647)(2:208|646)|209))|196|(1:198)))))(9:151|152|(1:154)|155|156|157|(1:159)(1:160)|161|(0)(0))|213|214|(1:216)|217|218|219|(1:221)|222|223|(3:225|(1:227)(1:228)|(4:230|(1:232)(1:234)|233|(1:238)(1:237))(0))(0)|239|240|(1:242)|243|244|245|(1:247)|248|249|(1:265)(4:251|(1:253)(1:254)|255|(4:258|(1:260)(1:261)|262|(1:264)(0))(0))|266|(4:267|(1:269)(1:270)|271|(6:273|274|(1:276)(1:277)|278|279|(2:649|281)(1:282))(2:648|283))|284|614|285|619|286|(1:288)|291|(1:293)(1:294)|295|(11:297|298|630|299|(1:301)|304|305|306|307|(1:309)(9:311|316|626|317|(1:319)|322|(1:324)(1:326)|325|(0)(2:329|(3:331|332|(1:334)(7:335|338|606|339|(1:341)|344|(0)(4:346|(1:348)(1:349)|350|(2:352|(1:354)(1:355)))))(2:336|(6:338|606|339|(0)|344|(0)(0)))))|310)(0)|368|369|(1:371)|372|(7:374|375|(1:377)|378|379|(1:381)(1:382)|(1:398)(4:385|(7:388|389|(1:391)(1:392)|393|394|(2:651|396)(1:397)|386)|650|398))(0)|399|636|400|401|(4:638|402|403|(4:405|(3:408|(3:410|(1:412)(1:413)|(3:415|655|426)(1:653))(3:418|419|(1:652)(2:656|426))|406)|654|427)(4:617|428|429|430))|421|422|423|604|424|(1:441)(1:442)|443|640|444|445|(5:615|446|447|(1:449)(1:450)|(4:452|659|(3:454|(1:456)(1:457)|(5:459|460|(1:462)(1:464)|463|(2:466|660)(4:658|467|610|468))(4:657|472|473|474))|661)(3:623|475|476))|(2:487|(1:489)(1:490))(0)|491|492|(1:494)|495|496|(1:498)(1:499)|500|501|(1:503)|504|505|(1:507)(1:508)|509|510|(1:512)|513|514|515|(1:517)|518|519|520|(1:522)|523|524|(1:526)|527|528|(1:530)(1:531)|532|533|534|(1:536)|537|538|539|(1:541)|542|543|544|(1:546)|547|548|(1:550)|551|552|(1:554)|555|556|(1:558)(1:559)|560|561|(1:563)|564|565|566|(1:568)|569|570|571|(1:573)|574|575|576|(1:578)|579|621|580|581|582)|212|213|214|(0)|217|218|219|(0)|222|223|(0)(0)|239|240|(0)|243|244|245|(0)|248|249|(0)(0)|266|(5:267|(0)(0)|271|(0)(0)|282)|284|614|285|619|286|(0)|291|(0)(0)|295|(0)(0)|368|369|(0)|372|(0)(0)|399|636|400|401|(5:638|402|403|(0)(0)|427)|421|422|423|604|424|(0)(0)|443|640|444|445|(6:615|446|447|(0)(0)|(0)(0)|661)|(0)(0)|491|492|(0)|495|496|(0)(0)|500|501|(0)|504|505|(0)(0)|509|510|(0)|513|514|515|(0)|518|519|520|(0)|523|524|(0)|527|528|(0)(0)|532|533|534|(0)|537|538|539|(0)|542|543|544|(0)|547|548|(0)|551|552|(0)|555|556|(0)(0)|560|561|(0)|564|565|566|(0)|569|570|571|(0)|574|575|576|(0)|579|621|580|581|582)(1:211)|210|212|213|214|(0)|217|218|219|(0)|222|223|(0)(0)|239|240|(0)|243|244|245|(0)|248|249|(0)(0)|266|(5:267|(0)(0)|271|(0)(0)|282)|284|614|285|619|286|(0)|291|(0)(0)|295|(0)(0)|368|369|(0)|372|(0)(0)|399|636|400|401|(5:638|402|403|(0)(0)|427)|421|422|423|604|424|(0)(0)|443|640|444|445|(6:615|446|447|(0)(0)|(0)(0)|661)|(0)(0)|491|492|(0)|495|496|(0)(0)|500|501|(0)|504|505|(0)(0)|509|510|(0)|513|514|515|(0)|518|519|520|(0)|523|524|(0)|527|528|(0)(0)|532|533|534|(0)|537|538|539|(0)|542|543|544|(0)|547|548|(0)|551|552|(0)|555|556|(0)(0)|560|561|(0)|564|565|566|(0)|569|570|571|(0)|574|575|576|(0)|579|621|580|581|582)(1:45)|(137:47|48|(1:50)|51|52|(0)(3:81|(0)(0)|(0)(0))|103|104|(0)(0)|108|(0)(0)|210|212|213|214|(0)|217|218|219|(0)|222|223|(0)(0)|239|240|(0)|243|244|245|(0)|248|249|(0)(0)|266|(5:267|(0)(0)|271|(0)(0)|282)|284|614|285|619|286|(0)|291|(0)(0)|295|(0)(0)|368|369|(0)|372|(0)(0)|399|636|400|401|(5:638|402|403|(0)(0)|427)|421|422|423|604|424|(0)(0)|443|640|444|445|(6:615|446|447|(0)(0)|(0)(0)|661)|(0)(0)|491|492|(0)|495|496|(0)(0)|500|501|(0)|504|505|(0)(0)|509|510|(0)|513|514|515|(0)|518|519|520|(0)|523|524|(0)|527|528|(0)(0)|532|533|534|(0)|537|538|539|(0)|542|543|544|(0)|547|548|(0)|551|552|(0)|555|556|(0)(0)|560|561|(0)|564|565|566|(0)|569|570|571|(0)|574|575|576|(0)|579|621|580|581|582)(1:55)|(6:57|58|(1:60)|61|62|(1:(2:65|(5:67|(1:69)|70|71|(0))(6:74|75|(1:77)|78|79|(0))))(0))(0)|103|104|(0)(0)|108|(0)(0)|210|212|213|214|(0)|217|218|219|(0)|222|223|(0)(0)|239|240|(0)|243|244|245|(0)|248|249|(0)(0)|266|(5:267|(0)(0)|271|(0)(0)|282)|284|614|285|619|286|(0)|291|(0)(0)|295|(0)(0)|368|369|(0)|372|(0)(0)|399|636|400|401|(5:638|402|403|(0)(0)|427)|421|422|423|604|424|(0)(0)|443|640|444|445|(6:615|446|447|(0)(0)|(0)(0)|661)|(0)(0)|491|492|(0)|495|496|(0)(0)|500|501|(0)|504|505|(0)(0)|509|510|(0)|513|514|515|(0)|518|519|520|(0)|523|524|(0)|527|528|(0)(0)|532|533|534|(0)|537|538|539|(0)|542|543|544|(0)|547|548|(0)|551|552|(0)|555|556|(0)(0)|560|561|(0)|564|565|566|(0)|569|570|571|(0)|574|575|576|(0)|579|621|580|581|582)(1:100))(1:101)|621|580|581|582)|619|286|(0)|291|(0)(0)|295|(0)(0)|368|369|(0)|372|(0)(0)|399|636|400|401|(5:638|402|403|(0)(0)|427)|421|422|423|604|424|(0)(0)|443|640|444|445|(6:615|446|447|(0)(0)|(0)(0)|661)|(0)(0)|491|492|(0)|495|496|(0)(0)|500|501|(0)|504|505|(0)(0)|509|510|(0)|513|514|515|(0)|518|519|520|(0)|523|524|(0)|527|528|(0)(0)|532|533|534|(0)|537|538|539|(0)|542|543|544|(0)|547|548|(0)|551|552|(0)|555|556|(0)(0)|560|561|(0)|564|565|566|(0)|569|570|571|(0)|574|575|576|(0)|579) */
        /* JADX WARN: Code restructure failed: missing block: B:171:0x136f, code lost:
        
            if (((r1 & r3) | (r3 ^ r1)) != 477111747) goto L180;
         */
        /* JADX WARN: Code restructure failed: missing block: B:179:0x1489, code lost:
        
            if (((r1 & r2) | (r1 ^ r2)) != 477111747) goto L180;
         */
        /* JADX WARN: Code restructure failed: missing block: B:180:0x148b, code lost:
        
            r1 = r14;
         */
        /* JADX WARN: Code restructure failed: missing block: B:431:0x2b5f, code lost:
        
            r0 = th;
         */
        /* JADX WARN: Code restructure failed: missing block: B:432:0x2b60, code lost:
        
            r7 = null;
         */
        /* JADX WARN: Code restructure failed: missing block: B:436:0x2b67, code lost:
        
            r4 = null;
         */
        /* JADX WARN: Code restructure failed: missing block: B:477:0x2c7d, code lost:
        
            r0 = th;
         */
        /* JADX WARN: Code restructure failed: missing block: B:478:0x2c7e, code lost:
        
            r7 = null;
         */
        /* JADX WARN: Code restructure failed: missing block: B:482:0x2c85, code lost:
        
            r4 = null;
         */
        /* JADX WARN: Removed duplicated region for block: B:106:0x0fc8 A[Catch: all -> 0x3cfd, TryCatch #21 {all -> 0x3cfd, blocks: (B:3:0x0003, B:5:0x0011, B:6:0x003f, B:8:0x0123, B:11:0x0132, B:13:0x0179, B:17:0x01c7, B:19:0x01d6, B:21:0x0218, B:25:0x02f4, B:27:0x02fe, B:28:0x033a, B:30:0x0356, B:32:0x0360, B:34:0x03a2, B:36:0x03ab, B:38:0x03bf, B:40:0x03fd, B:84:0x091c, B:86:0x0929, B:87:0x0962, B:104:0x0fbe, B:106:0x0fc8, B:108:0x1018, B:134:0x10bf, B:136:0x10c9, B:138:0x110c, B:140:0x1130, B:142:0x113a, B:144:0x117d, B:166:0x1279, B:168:0x128f, B:169:0x12cd, B:214:0x1750, B:216:0x175d, B:217:0x179b, B:219:0x18be, B:221:0x18cb, B:222:0x190c, B:240:0x1a98, B:242:0x1aa5, B:243:0x1ae5, B:245:0x1c2d, B:247:0x1c3a, B:248:0x1c7a, B:274:0x1ec4, B:276:0x1ed1, B:278:0x1f1e, B:369:0x2496, B:371:0x24a0, B:372:0x24de, B:375:0x2505, B:377:0x2514, B:378:0x2550, B:389:0x28e3, B:391:0x28f0, B:393:0x2934, B:492:0x2cc0, B:494:0x2cc6, B:495:0x2d08, B:501:0x2dc5, B:503:0x2dcb, B:504:0x2e12, B:510:0x2edd, B:512:0x2ee3, B:513:0x2f29, B:515:0x3000, B:517:0x3006, B:518:0x3049, B:520:0x3109, B:522:0x310f, B:523:0x3151, B:528:0x3226, B:530:0x3233, B:532:0x327a, B:534:0x33e9, B:536:0x33fa, B:537:0x3434, B:539:0x350f, B:541:0x3515, B:542:0x3555, B:544:0x363f, B:546:0x3664, B:547:0x369d, B:552:0x3792, B:554:0x379f, B:555:0x37db, B:561:0x38a8, B:563:0x38ae, B:564:0x38e2, B:566:0x39a4, B:568:0x39aa, B:569:0x39e6, B:571:0x3aa5, B:573:0x3ab2, B:574:0x3af5, B:576:0x3bd3, B:578:0x3c02, B:579:0x3c44, B:200:0x15e7, B:202:0x15f4, B:204:0x163b, B:174:0x1375, B:176:0x1388, B:177:0x13c3, B:183:0x149e, B:185:0x14b0, B:186:0x14e6, B:152:0x11ad, B:154:0x11b7, B:155:0x11f6, B:157:0x1215, B:159:0x121f, B:161:0x1262, B:93:0x0a34, B:95:0x0a3e, B:96:0x0a80, B:48:0x04cb, B:50:0x04df, B:51:0x051d, B:58:0x05b9, B:60:0x05cc, B:61:0x0603, B:67:0x06e5, B:69:0x06fa, B:70:0x0731, B:75:0x07f4, B:77:0x0807, B:78:0x0840), top: B:634:0x0003 }] */
        /* JADX WARN: Removed duplicated region for block: B:107:0x1014  */
        /* JADX WARN: Removed duplicated region for block: B:110:0x1023  */
        /* JADX WARN: Removed duplicated region for block: B:150:0x118f A[PHI: r1 r41 r43
          0x118f: PHI (r1v963 java.lang.Object) = (r1v903 java.lang.Object), (r1v1030 java.lang.Object) binds: [B:162:0x1269, B:149:0x118d] A[DONT_GENERATE, DONT_INLINE]
          0x118f: PHI (r41v33 char) = (r41v30 char), (r41v35 char) binds: [B:162:0x1269, B:149:0x118d] A[DONT_GENERATE, DONT_INLINE]
          0x118f: PHI (r43v38 java.lang.Object) = (r43v26 java.lang.Object), (r43v48 java.lang.Object) binds: [B:162:0x1269, B:149:0x118d] A[DONT_GENERATE, DONT_INLINE]] */
        /* JADX WARN: Removed duplicated region for block: B:181:0x148c A[PHI: r1 r41
          0x148c: PHI (r1v906 java.lang.Object) = (r1v903 java.lang.Object), (r1v996 java.lang.Object), (r1v1030 java.lang.Object) binds: [B:162:0x1269, B:180:0x148b, B:149:0x118d] A[DONT_GENERATE, DONT_INLINE]
          0x148c: PHI (r41v31 char) = (r41v30 char), (r41v33 char), (r41v35 char) binds: [B:162:0x1269, B:180:0x148b, B:149:0x118d] A[DONT_GENERATE, DONT_INLINE]] */
        /* JADX WARN: Removed duplicated region for block: B:211:0x170c  */
        /* JADX WARN: Removed duplicated region for block: B:216:0x175d A[Catch: all -> 0x3cfd, TryCatch #21 {all -> 0x3cfd, blocks: (B:3:0x0003, B:5:0x0011, B:6:0x003f, B:8:0x0123, B:11:0x0132, B:13:0x0179, B:17:0x01c7, B:19:0x01d6, B:21:0x0218, B:25:0x02f4, B:27:0x02fe, B:28:0x033a, B:30:0x0356, B:32:0x0360, B:34:0x03a2, B:36:0x03ab, B:38:0x03bf, B:40:0x03fd, B:84:0x091c, B:86:0x0929, B:87:0x0962, B:104:0x0fbe, B:106:0x0fc8, B:108:0x1018, B:134:0x10bf, B:136:0x10c9, B:138:0x110c, B:140:0x1130, B:142:0x113a, B:144:0x117d, B:166:0x1279, B:168:0x128f, B:169:0x12cd, B:214:0x1750, B:216:0x175d, B:217:0x179b, B:219:0x18be, B:221:0x18cb, B:222:0x190c, B:240:0x1a98, B:242:0x1aa5, B:243:0x1ae5, B:245:0x1c2d, B:247:0x1c3a, B:248:0x1c7a, B:274:0x1ec4, B:276:0x1ed1, B:278:0x1f1e, B:369:0x2496, B:371:0x24a0, B:372:0x24de, B:375:0x2505, B:377:0x2514, B:378:0x2550, B:389:0x28e3, B:391:0x28f0, B:393:0x2934, B:492:0x2cc0, B:494:0x2cc6, B:495:0x2d08, B:501:0x2dc5, B:503:0x2dcb, B:504:0x2e12, B:510:0x2edd, B:512:0x2ee3, B:513:0x2f29, B:515:0x3000, B:517:0x3006, B:518:0x3049, B:520:0x3109, B:522:0x310f, B:523:0x3151, B:528:0x3226, B:530:0x3233, B:532:0x327a, B:534:0x33e9, B:536:0x33fa, B:537:0x3434, B:539:0x350f, B:541:0x3515, B:542:0x3555, B:544:0x363f, B:546:0x3664, B:547:0x369d, B:552:0x3792, B:554:0x379f, B:555:0x37db, B:561:0x38a8, B:563:0x38ae, B:564:0x38e2, B:566:0x39a4, B:568:0x39aa, B:569:0x39e6, B:571:0x3aa5, B:573:0x3ab2, B:574:0x3af5, B:576:0x3bd3, B:578:0x3c02, B:579:0x3c44, B:200:0x15e7, B:202:0x15f4, B:204:0x163b, B:174:0x1375, B:176:0x1388, B:177:0x13c3, B:183:0x149e, B:185:0x14b0, B:186:0x14e6, B:152:0x11ad, B:154:0x11b7, B:155:0x11f6, B:157:0x1215, B:159:0x121f, B:161:0x1262, B:93:0x0a34, B:95:0x0a3e, B:96:0x0a80, B:48:0x04cb, B:50:0x04df, B:51:0x051d, B:58:0x05b9, B:60:0x05cc, B:61:0x0603, B:67:0x06e5, B:69:0x06fa, B:70:0x0731, B:75:0x07f4, B:77:0x0807, B:78:0x0840), top: B:634:0x0003 }] */
        /* JADX WARN: Removed duplicated region for block: B:221:0x18cb A[Catch: all -> 0x3cfd, TryCatch #21 {all -> 0x3cfd, blocks: (B:3:0x0003, B:5:0x0011, B:6:0x003f, B:8:0x0123, B:11:0x0132, B:13:0x0179, B:17:0x01c7, B:19:0x01d6, B:21:0x0218, B:25:0x02f4, B:27:0x02fe, B:28:0x033a, B:30:0x0356, B:32:0x0360, B:34:0x03a2, B:36:0x03ab, B:38:0x03bf, B:40:0x03fd, B:84:0x091c, B:86:0x0929, B:87:0x0962, B:104:0x0fbe, B:106:0x0fc8, B:108:0x1018, B:134:0x10bf, B:136:0x10c9, B:138:0x110c, B:140:0x1130, B:142:0x113a, B:144:0x117d, B:166:0x1279, B:168:0x128f, B:169:0x12cd, B:214:0x1750, B:216:0x175d, B:217:0x179b, B:219:0x18be, B:221:0x18cb, B:222:0x190c, B:240:0x1a98, B:242:0x1aa5, B:243:0x1ae5, B:245:0x1c2d, B:247:0x1c3a, B:248:0x1c7a, B:274:0x1ec4, B:276:0x1ed1, B:278:0x1f1e, B:369:0x2496, B:371:0x24a0, B:372:0x24de, B:375:0x2505, B:377:0x2514, B:378:0x2550, B:389:0x28e3, B:391:0x28f0, B:393:0x2934, B:492:0x2cc0, B:494:0x2cc6, B:495:0x2d08, B:501:0x2dc5, B:503:0x2dcb, B:504:0x2e12, B:510:0x2edd, B:512:0x2ee3, B:513:0x2f29, B:515:0x3000, B:517:0x3006, B:518:0x3049, B:520:0x3109, B:522:0x310f, B:523:0x3151, B:528:0x3226, B:530:0x3233, B:532:0x327a, B:534:0x33e9, B:536:0x33fa, B:537:0x3434, B:539:0x350f, B:541:0x3515, B:542:0x3555, B:544:0x363f, B:546:0x3664, B:547:0x369d, B:552:0x3792, B:554:0x379f, B:555:0x37db, B:561:0x38a8, B:563:0x38ae, B:564:0x38e2, B:566:0x39a4, B:568:0x39aa, B:569:0x39e6, B:571:0x3aa5, B:573:0x3ab2, B:574:0x3af5, B:576:0x3bd3, B:578:0x3c02, B:579:0x3c44, B:200:0x15e7, B:202:0x15f4, B:204:0x163b, B:174:0x1375, B:176:0x1388, B:177:0x13c3, B:183:0x149e, B:185:0x14b0, B:186:0x14e6, B:152:0x11ad, B:154:0x11b7, B:155:0x11f6, B:157:0x1215, B:159:0x121f, B:161:0x1262, B:93:0x0a34, B:95:0x0a3e, B:96:0x0a80, B:48:0x04cb, B:50:0x04df, B:51:0x051d, B:58:0x05b9, B:60:0x05cc, B:61:0x0603, B:67:0x06e5, B:69:0x06fa, B:70:0x0731, B:75:0x07f4, B:77:0x0807, B:78:0x0840), top: B:634:0x0003 }] */
        /* JADX WARN: Removed duplicated region for block: B:225:0x19c7  */
        /* JADX WARN: Removed duplicated region for block: B:238:0x19f7  */
        /* JADX WARN: Removed duplicated region for block: B:242:0x1aa5 A[Catch: all -> 0x3cfd, TryCatch #21 {all -> 0x3cfd, blocks: (B:3:0x0003, B:5:0x0011, B:6:0x003f, B:8:0x0123, B:11:0x0132, B:13:0x0179, B:17:0x01c7, B:19:0x01d6, B:21:0x0218, B:25:0x02f4, B:27:0x02fe, B:28:0x033a, B:30:0x0356, B:32:0x0360, B:34:0x03a2, B:36:0x03ab, B:38:0x03bf, B:40:0x03fd, B:84:0x091c, B:86:0x0929, B:87:0x0962, B:104:0x0fbe, B:106:0x0fc8, B:108:0x1018, B:134:0x10bf, B:136:0x10c9, B:138:0x110c, B:140:0x1130, B:142:0x113a, B:144:0x117d, B:166:0x1279, B:168:0x128f, B:169:0x12cd, B:214:0x1750, B:216:0x175d, B:217:0x179b, B:219:0x18be, B:221:0x18cb, B:222:0x190c, B:240:0x1a98, B:242:0x1aa5, B:243:0x1ae5, B:245:0x1c2d, B:247:0x1c3a, B:248:0x1c7a, B:274:0x1ec4, B:276:0x1ed1, B:278:0x1f1e, B:369:0x2496, B:371:0x24a0, B:372:0x24de, B:375:0x2505, B:377:0x2514, B:378:0x2550, B:389:0x28e3, B:391:0x28f0, B:393:0x2934, B:492:0x2cc0, B:494:0x2cc6, B:495:0x2d08, B:501:0x2dc5, B:503:0x2dcb, B:504:0x2e12, B:510:0x2edd, B:512:0x2ee3, B:513:0x2f29, B:515:0x3000, B:517:0x3006, B:518:0x3049, B:520:0x3109, B:522:0x310f, B:523:0x3151, B:528:0x3226, B:530:0x3233, B:532:0x327a, B:534:0x33e9, B:536:0x33fa, B:537:0x3434, B:539:0x350f, B:541:0x3515, B:542:0x3555, B:544:0x363f, B:546:0x3664, B:547:0x369d, B:552:0x3792, B:554:0x379f, B:555:0x37db, B:561:0x38a8, B:563:0x38ae, B:564:0x38e2, B:566:0x39a4, B:568:0x39aa, B:569:0x39e6, B:571:0x3aa5, B:573:0x3ab2, B:574:0x3af5, B:576:0x3bd3, B:578:0x3c02, B:579:0x3c44, B:200:0x15e7, B:202:0x15f4, B:204:0x163b, B:174:0x1375, B:176:0x1388, B:177:0x13c3, B:183:0x149e, B:185:0x14b0, B:186:0x14e6, B:152:0x11ad, B:154:0x11b7, B:155:0x11f6, B:157:0x1215, B:159:0x121f, B:161:0x1262, B:93:0x0a34, B:95:0x0a3e, B:96:0x0a80, B:48:0x04cb, B:50:0x04df, B:51:0x051d, B:58:0x05b9, B:60:0x05cc, B:61:0x0603, B:67:0x06e5, B:69:0x06fa, B:70:0x0731, B:75:0x07f4, B:77:0x0807, B:78:0x0840), top: B:634:0x0003 }] */
        /* JADX WARN: Removed duplicated region for block: B:247:0x1c3a A[Catch: all -> 0x3cfd, TryCatch #21 {all -> 0x3cfd, blocks: (B:3:0x0003, B:5:0x0011, B:6:0x003f, B:8:0x0123, B:11:0x0132, B:13:0x0179, B:17:0x01c7, B:19:0x01d6, B:21:0x0218, B:25:0x02f4, B:27:0x02fe, B:28:0x033a, B:30:0x0356, B:32:0x0360, B:34:0x03a2, B:36:0x03ab, B:38:0x03bf, B:40:0x03fd, B:84:0x091c, B:86:0x0929, B:87:0x0962, B:104:0x0fbe, B:106:0x0fc8, B:108:0x1018, B:134:0x10bf, B:136:0x10c9, B:138:0x110c, B:140:0x1130, B:142:0x113a, B:144:0x117d, B:166:0x1279, B:168:0x128f, B:169:0x12cd, B:214:0x1750, B:216:0x175d, B:217:0x179b, B:219:0x18be, B:221:0x18cb, B:222:0x190c, B:240:0x1a98, B:242:0x1aa5, B:243:0x1ae5, B:245:0x1c2d, B:247:0x1c3a, B:248:0x1c7a, B:274:0x1ec4, B:276:0x1ed1, B:278:0x1f1e, B:369:0x2496, B:371:0x24a0, B:372:0x24de, B:375:0x2505, B:377:0x2514, B:378:0x2550, B:389:0x28e3, B:391:0x28f0, B:393:0x2934, B:492:0x2cc0, B:494:0x2cc6, B:495:0x2d08, B:501:0x2dc5, B:503:0x2dcb, B:504:0x2e12, B:510:0x2edd, B:512:0x2ee3, B:513:0x2f29, B:515:0x3000, B:517:0x3006, B:518:0x3049, B:520:0x3109, B:522:0x310f, B:523:0x3151, B:528:0x3226, B:530:0x3233, B:532:0x327a, B:534:0x33e9, B:536:0x33fa, B:537:0x3434, B:539:0x350f, B:541:0x3515, B:542:0x3555, B:544:0x363f, B:546:0x3664, B:547:0x369d, B:552:0x3792, B:554:0x379f, B:555:0x37db, B:561:0x38a8, B:563:0x38ae, B:564:0x38e2, B:566:0x39a4, B:568:0x39aa, B:569:0x39e6, B:571:0x3aa5, B:573:0x3ab2, B:574:0x3af5, B:576:0x3bd3, B:578:0x3c02, B:579:0x3c44, B:200:0x15e7, B:202:0x15f4, B:204:0x163b, B:174:0x1375, B:176:0x1388, B:177:0x13c3, B:183:0x149e, B:185:0x14b0, B:186:0x14e6, B:152:0x11ad, B:154:0x11b7, B:155:0x11f6, B:157:0x1215, B:159:0x121f, B:161:0x1262, B:93:0x0a34, B:95:0x0a3e, B:96:0x0a80, B:48:0x04cb, B:50:0x04df, B:51:0x051d, B:58:0x05b9, B:60:0x05cc, B:61:0x0603, B:67:0x06e5, B:69:0x06fa, B:70:0x0731, B:75:0x07f4, B:77:0x0807, B:78:0x0840), top: B:634:0x0003 }] */
        /* JADX WARN: Removed duplicated region for block: B:251:0x1d42  */
        /* JADX WARN: Removed duplicated region for block: B:265:0x1d62  */
        /* JADX WARN: Removed duplicated region for block: B:269:0x1eb9  */
        /* JADX WARN: Removed duplicated region for block: B:270:0x1ebc  */
        /* JADX WARN: Removed duplicated region for block: B:273:0x1ec2  */
        /* JADX WARN: Removed duplicated region for block: B:288:0x2072 A[Catch: all -> 0x20b3, TryCatch #10 {all -> 0x20b3, blocks: (B:286:0x2068, B:288:0x2072, B:291:0x20b6), top: B:619:0x2068, outer: #5 }] */
        /* JADX WARN: Removed duplicated region for block: B:293:0x20bf  */
        /* JADX WARN: Removed duplicated region for block: B:294:0x20c2  */
        /* JADX WARN: Removed duplicated region for block: B:297:0x20c8 A[Catch: Exception -> 0x2214, TRY_ENTER, TRY_LEAVE, TryCatch #5 {Exception -> 0x2214, blocks: (B:285:0x2002, B:297:0x20c8, B:306:0x214e, B:312:0x2219, B:314:0x221f, B:315:0x2220, B:316:0x2221, B:332:0x22be, B:338:0x231f, B:346:0x238f, B:354:0x23af, B:355:0x23b2, B:356:0x23b5, B:358:0x23bb, B:359:0x23bc, B:336:0x22ec, B:360:0x23bd, B:362:0x23c3, B:363:0x23c4, B:364:0x23c5, B:366:0x23cb, B:367:0x23cc, B:339:0x2333, B:341:0x233d, B:344:0x2384, B:286:0x2068, B:288:0x2072, B:291:0x20b6, B:317:0x224b, B:319:0x2255, B:322:0x2298, B:299:0x20e8, B:301:0x20f9, B:304:0x213d), top: B:614:0x2002, inners: #1, #10, #15, #18 }] */
        /* JADX WARN: Removed duplicated region for block: B:311:0x2217  */
        /* JADX WARN: Removed duplicated region for block: B:341:0x233d A[Catch: all -> 0x2382, TryCatch #1 {all -> 0x2382, blocks: (B:339:0x2333, B:341:0x233d, B:344:0x2384), top: B:606:0x2333, outer: #5 }] */
        /* JADX WARN: Removed duplicated region for block: B:346:0x238f A[Catch: Exception -> 0x2214, TRY_ENTER, TRY_LEAVE, TryCatch #5 {Exception -> 0x2214, blocks: (B:285:0x2002, B:297:0x20c8, B:306:0x214e, B:312:0x2219, B:314:0x221f, B:315:0x2220, B:316:0x2221, B:332:0x22be, B:338:0x231f, B:346:0x238f, B:354:0x23af, B:355:0x23b2, B:356:0x23b5, B:358:0x23bb, B:359:0x23bc, B:336:0x22ec, B:360:0x23bd, B:362:0x23c3, B:363:0x23c4, B:364:0x23c5, B:366:0x23cb, B:367:0x23cc, B:339:0x2333, B:341:0x233d, B:344:0x2384, B:286:0x2068, B:288:0x2072, B:291:0x20b6, B:317:0x224b, B:319:0x2255, B:322:0x2298, B:299:0x20e8, B:301:0x20f9, B:304:0x213d), top: B:614:0x2002, inners: #1, #10, #15, #18 }] */
        /* JADX WARN: Removed duplicated region for block: B:371:0x24a0 A[Catch: all -> 0x3cfd, TryCatch #21 {all -> 0x3cfd, blocks: (B:3:0x0003, B:5:0x0011, B:6:0x003f, B:8:0x0123, B:11:0x0132, B:13:0x0179, B:17:0x01c7, B:19:0x01d6, B:21:0x0218, B:25:0x02f4, B:27:0x02fe, B:28:0x033a, B:30:0x0356, B:32:0x0360, B:34:0x03a2, B:36:0x03ab, B:38:0x03bf, B:40:0x03fd, B:84:0x091c, B:86:0x0929, B:87:0x0962, B:104:0x0fbe, B:106:0x0fc8, B:108:0x1018, B:134:0x10bf, B:136:0x10c9, B:138:0x110c, B:140:0x1130, B:142:0x113a, B:144:0x117d, B:166:0x1279, B:168:0x128f, B:169:0x12cd, B:214:0x1750, B:216:0x175d, B:217:0x179b, B:219:0x18be, B:221:0x18cb, B:222:0x190c, B:240:0x1a98, B:242:0x1aa5, B:243:0x1ae5, B:245:0x1c2d, B:247:0x1c3a, B:248:0x1c7a, B:274:0x1ec4, B:276:0x1ed1, B:278:0x1f1e, B:369:0x2496, B:371:0x24a0, B:372:0x24de, B:375:0x2505, B:377:0x2514, B:378:0x2550, B:389:0x28e3, B:391:0x28f0, B:393:0x2934, B:492:0x2cc0, B:494:0x2cc6, B:495:0x2d08, B:501:0x2dc5, B:503:0x2dcb, B:504:0x2e12, B:510:0x2edd, B:512:0x2ee3, B:513:0x2f29, B:515:0x3000, B:517:0x3006, B:518:0x3049, B:520:0x3109, B:522:0x310f, B:523:0x3151, B:528:0x3226, B:530:0x3233, B:532:0x327a, B:534:0x33e9, B:536:0x33fa, B:537:0x3434, B:539:0x350f, B:541:0x3515, B:542:0x3555, B:544:0x363f, B:546:0x3664, B:547:0x369d, B:552:0x3792, B:554:0x379f, B:555:0x37db, B:561:0x38a8, B:563:0x38ae, B:564:0x38e2, B:566:0x39a4, B:568:0x39aa, B:569:0x39e6, B:571:0x3aa5, B:573:0x3ab2, B:574:0x3af5, B:576:0x3bd3, B:578:0x3c02, B:579:0x3c44, B:200:0x15e7, B:202:0x15f4, B:204:0x163b, B:174:0x1375, B:176:0x1388, B:177:0x13c3, B:183:0x149e, B:185:0x14b0, B:186:0x14e6, B:152:0x11ad, B:154:0x11b7, B:155:0x11f6, B:157:0x1215, B:159:0x121f, B:161:0x1262, B:93:0x0a34, B:95:0x0a3e, B:96:0x0a80, B:48:0x04cb, B:50:0x04df, B:51:0x051d, B:58:0x05b9, B:60:0x05cc, B:61:0x0603, B:67:0x06e5, B:69:0x06fa, B:70:0x0731, B:75:0x07f4, B:77:0x0807, B:78:0x0840), top: B:634:0x0003 }] */
        /* JADX WARN: Removed duplicated region for block: B:374:0x24e7  */
        /* JADX WARN: Removed duplicated region for block: B:398:0x2a2a  */
        /* JADX WARN: Removed duplicated region for block: B:405:0x2abd  */
        /* JADX WARN: Removed duplicated region for block: B:441:0x2b70  */
        /* JADX WARN: Removed duplicated region for block: B:442:0x2b73  */
        /* JADX WARN: Removed duplicated region for block: B:449:0x2c33  */
        /* JADX WARN: Removed duplicated region for block: B:450:0x2c35  */
        /* JADX WARN: Removed duplicated region for block: B:452:0x2c38  */
        /* JADX WARN: Removed duplicated region for block: B:487:0x2c8e  */
        /* JADX WARN: Removed duplicated region for block: B:489:0x2ca3  */
        /* JADX WARN: Removed duplicated region for block: B:494:0x2cc6 A[Catch: all -> 0x3cfd, TryCatch #21 {all -> 0x3cfd, blocks: (B:3:0x0003, B:5:0x0011, B:6:0x003f, B:8:0x0123, B:11:0x0132, B:13:0x0179, B:17:0x01c7, B:19:0x01d6, B:21:0x0218, B:25:0x02f4, B:27:0x02fe, B:28:0x033a, B:30:0x0356, B:32:0x0360, B:34:0x03a2, B:36:0x03ab, B:38:0x03bf, B:40:0x03fd, B:84:0x091c, B:86:0x0929, B:87:0x0962, B:104:0x0fbe, B:106:0x0fc8, B:108:0x1018, B:134:0x10bf, B:136:0x10c9, B:138:0x110c, B:140:0x1130, B:142:0x113a, B:144:0x117d, B:166:0x1279, B:168:0x128f, B:169:0x12cd, B:214:0x1750, B:216:0x175d, B:217:0x179b, B:219:0x18be, B:221:0x18cb, B:222:0x190c, B:240:0x1a98, B:242:0x1aa5, B:243:0x1ae5, B:245:0x1c2d, B:247:0x1c3a, B:248:0x1c7a, B:274:0x1ec4, B:276:0x1ed1, B:278:0x1f1e, B:369:0x2496, B:371:0x24a0, B:372:0x24de, B:375:0x2505, B:377:0x2514, B:378:0x2550, B:389:0x28e3, B:391:0x28f0, B:393:0x2934, B:492:0x2cc0, B:494:0x2cc6, B:495:0x2d08, B:501:0x2dc5, B:503:0x2dcb, B:504:0x2e12, B:510:0x2edd, B:512:0x2ee3, B:513:0x2f29, B:515:0x3000, B:517:0x3006, B:518:0x3049, B:520:0x3109, B:522:0x310f, B:523:0x3151, B:528:0x3226, B:530:0x3233, B:532:0x327a, B:534:0x33e9, B:536:0x33fa, B:537:0x3434, B:539:0x350f, B:541:0x3515, B:542:0x3555, B:544:0x363f, B:546:0x3664, B:547:0x369d, B:552:0x3792, B:554:0x379f, B:555:0x37db, B:561:0x38a8, B:563:0x38ae, B:564:0x38e2, B:566:0x39a4, B:568:0x39aa, B:569:0x39e6, B:571:0x3aa5, B:573:0x3ab2, B:574:0x3af5, B:576:0x3bd3, B:578:0x3c02, B:579:0x3c44, B:200:0x15e7, B:202:0x15f4, B:204:0x163b, B:174:0x1375, B:176:0x1388, B:177:0x13c3, B:183:0x149e, B:185:0x14b0, B:186:0x14e6, B:152:0x11ad, B:154:0x11b7, B:155:0x11f6, B:157:0x1215, B:159:0x121f, B:161:0x1262, B:93:0x0a34, B:95:0x0a3e, B:96:0x0a80, B:48:0x04cb, B:50:0x04df, B:51:0x051d, B:58:0x05b9, B:60:0x05cc, B:61:0x0603, B:67:0x06e5, B:69:0x06fa, B:70:0x0731, B:75:0x07f4, B:77:0x0807, B:78:0x0840), top: B:634:0x0003 }] */
        /* JADX WARN: Removed duplicated region for block: B:498:0x2db9  */
        /* JADX WARN: Removed duplicated region for block: B:499:0x2dbb  */
        /* JADX WARN: Removed duplicated region for block: B:503:0x2dcb A[Catch: all -> 0x3cfd, TryCatch #21 {all -> 0x3cfd, blocks: (B:3:0x0003, B:5:0x0011, B:6:0x003f, B:8:0x0123, B:11:0x0132, B:13:0x0179, B:17:0x01c7, B:19:0x01d6, B:21:0x0218, B:25:0x02f4, B:27:0x02fe, B:28:0x033a, B:30:0x0356, B:32:0x0360, B:34:0x03a2, B:36:0x03ab, B:38:0x03bf, B:40:0x03fd, B:84:0x091c, B:86:0x0929, B:87:0x0962, B:104:0x0fbe, B:106:0x0fc8, B:108:0x1018, B:134:0x10bf, B:136:0x10c9, B:138:0x110c, B:140:0x1130, B:142:0x113a, B:144:0x117d, B:166:0x1279, B:168:0x128f, B:169:0x12cd, B:214:0x1750, B:216:0x175d, B:217:0x179b, B:219:0x18be, B:221:0x18cb, B:222:0x190c, B:240:0x1a98, B:242:0x1aa5, B:243:0x1ae5, B:245:0x1c2d, B:247:0x1c3a, B:248:0x1c7a, B:274:0x1ec4, B:276:0x1ed1, B:278:0x1f1e, B:369:0x2496, B:371:0x24a0, B:372:0x24de, B:375:0x2505, B:377:0x2514, B:378:0x2550, B:389:0x28e3, B:391:0x28f0, B:393:0x2934, B:492:0x2cc0, B:494:0x2cc6, B:495:0x2d08, B:501:0x2dc5, B:503:0x2dcb, B:504:0x2e12, B:510:0x2edd, B:512:0x2ee3, B:513:0x2f29, B:515:0x3000, B:517:0x3006, B:518:0x3049, B:520:0x3109, B:522:0x310f, B:523:0x3151, B:528:0x3226, B:530:0x3233, B:532:0x327a, B:534:0x33e9, B:536:0x33fa, B:537:0x3434, B:539:0x350f, B:541:0x3515, B:542:0x3555, B:544:0x363f, B:546:0x3664, B:547:0x369d, B:552:0x3792, B:554:0x379f, B:555:0x37db, B:561:0x38a8, B:563:0x38ae, B:564:0x38e2, B:566:0x39a4, B:568:0x39aa, B:569:0x39e6, B:571:0x3aa5, B:573:0x3ab2, B:574:0x3af5, B:576:0x3bd3, B:578:0x3c02, B:579:0x3c44, B:200:0x15e7, B:202:0x15f4, B:204:0x163b, B:174:0x1375, B:176:0x1388, B:177:0x13c3, B:183:0x149e, B:185:0x14b0, B:186:0x14e6, B:152:0x11ad, B:154:0x11b7, B:155:0x11f6, B:157:0x1215, B:159:0x121f, B:161:0x1262, B:93:0x0a34, B:95:0x0a3e, B:96:0x0a80, B:48:0x04cb, B:50:0x04df, B:51:0x051d, B:58:0x05b9, B:60:0x05cc, B:61:0x0603, B:67:0x06e5, B:69:0x06fa, B:70:0x0731, B:75:0x07f4, B:77:0x0807, B:78:0x0840), top: B:634:0x0003 }] */
        /* JADX WARN: Removed duplicated region for block: B:507:0x2ec8  */
        /* JADX WARN: Removed duplicated region for block: B:508:0x2ecb  */
        /* JADX WARN: Removed duplicated region for block: B:512:0x2ee3 A[Catch: all -> 0x3cfd, TryCatch #21 {all -> 0x3cfd, blocks: (B:3:0x0003, B:5:0x0011, B:6:0x003f, B:8:0x0123, B:11:0x0132, B:13:0x0179, B:17:0x01c7, B:19:0x01d6, B:21:0x0218, B:25:0x02f4, B:27:0x02fe, B:28:0x033a, B:30:0x0356, B:32:0x0360, B:34:0x03a2, B:36:0x03ab, B:38:0x03bf, B:40:0x03fd, B:84:0x091c, B:86:0x0929, B:87:0x0962, B:104:0x0fbe, B:106:0x0fc8, B:108:0x1018, B:134:0x10bf, B:136:0x10c9, B:138:0x110c, B:140:0x1130, B:142:0x113a, B:144:0x117d, B:166:0x1279, B:168:0x128f, B:169:0x12cd, B:214:0x1750, B:216:0x175d, B:217:0x179b, B:219:0x18be, B:221:0x18cb, B:222:0x190c, B:240:0x1a98, B:242:0x1aa5, B:243:0x1ae5, B:245:0x1c2d, B:247:0x1c3a, B:248:0x1c7a, B:274:0x1ec4, B:276:0x1ed1, B:278:0x1f1e, B:369:0x2496, B:371:0x24a0, B:372:0x24de, B:375:0x2505, B:377:0x2514, B:378:0x2550, B:389:0x28e3, B:391:0x28f0, B:393:0x2934, B:492:0x2cc0, B:494:0x2cc6, B:495:0x2d08, B:501:0x2dc5, B:503:0x2dcb, B:504:0x2e12, B:510:0x2edd, B:512:0x2ee3, B:513:0x2f29, B:515:0x3000, B:517:0x3006, B:518:0x3049, B:520:0x3109, B:522:0x310f, B:523:0x3151, B:528:0x3226, B:530:0x3233, B:532:0x327a, B:534:0x33e9, B:536:0x33fa, B:537:0x3434, B:539:0x350f, B:541:0x3515, B:542:0x3555, B:544:0x363f, B:546:0x3664, B:547:0x369d, B:552:0x3792, B:554:0x379f, B:555:0x37db, B:561:0x38a8, B:563:0x38ae, B:564:0x38e2, B:566:0x39a4, B:568:0x39aa, B:569:0x39e6, B:571:0x3aa5, B:573:0x3ab2, B:574:0x3af5, B:576:0x3bd3, B:578:0x3c02, B:579:0x3c44, B:200:0x15e7, B:202:0x15f4, B:204:0x163b, B:174:0x1375, B:176:0x1388, B:177:0x13c3, B:183:0x149e, B:185:0x14b0, B:186:0x14e6, B:152:0x11ad, B:154:0x11b7, B:155:0x11f6, B:157:0x1215, B:159:0x121f, B:161:0x1262, B:93:0x0a34, B:95:0x0a3e, B:96:0x0a80, B:48:0x04cb, B:50:0x04df, B:51:0x051d, B:58:0x05b9, B:60:0x05cc, B:61:0x0603, B:67:0x06e5, B:69:0x06fa, B:70:0x0731, B:75:0x07f4, B:77:0x0807, B:78:0x0840), top: B:634:0x0003 }] */
        /* JADX WARN: Removed duplicated region for block: B:517:0x3006 A[Catch: all -> 0x3cfd, TryCatch #21 {all -> 0x3cfd, blocks: (B:3:0x0003, B:5:0x0011, B:6:0x003f, B:8:0x0123, B:11:0x0132, B:13:0x0179, B:17:0x01c7, B:19:0x01d6, B:21:0x0218, B:25:0x02f4, B:27:0x02fe, B:28:0x033a, B:30:0x0356, B:32:0x0360, B:34:0x03a2, B:36:0x03ab, B:38:0x03bf, B:40:0x03fd, B:84:0x091c, B:86:0x0929, B:87:0x0962, B:104:0x0fbe, B:106:0x0fc8, B:108:0x1018, B:134:0x10bf, B:136:0x10c9, B:138:0x110c, B:140:0x1130, B:142:0x113a, B:144:0x117d, B:166:0x1279, B:168:0x128f, B:169:0x12cd, B:214:0x1750, B:216:0x175d, B:217:0x179b, B:219:0x18be, B:221:0x18cb, B:222:0x190c, B:240:0x1a98, B:242:0x1aa5, B:243:0x1ae5, B:245:0x1c2d, B:247:0x1c3a, B:248:0x1c7a, B:274:0x1ec4, B:276:0x1ed1, B:278:0x1f1e, B:369:0x2496, B:371:0x24a0, B:372:0x24de, B:375:0x2505, B:377:0x2514, B:378:0x2550, B:389:0x28e3, B:391:0x28f0, B:393:0x2934, B:492:0x2cc0, B:494:0x2cc6, B:495:0x2d08, B:501:0x2dc5, B:503:0x2dcb, B:504:0x2e12, B:510:0x2edd, B:512:0x2ee3, B:513:0x2f29, B:515:0x3000, B:517:0x3006, B:518:0x3049, B:520:0x3109, B:522:0x310f, B:523:0x3151, B:528:0x3226, B:530:0x3233, B:532:0x327a, B:534:0x33e9, B:536:0x33fa, B:537:0x3434, B:539:0x350f, B:541:0x3515, B:542:0x3555, B:544:0x363f, B:546:0x3664, B:547:0x369d, B:552:0x3792, B:554:0x379f, B:555:0x37db, B:561:0x38a8, B:563:0x38ae, B:564:0x38e2, B:566:0x39a4, B:568:0x39aa, B:569:0x39e6, B:571:0x3aa5, B:573:0x3ab2, B:574:0x3af5, B:576:0x3bd3, B:578:0x3c02, B:579:0x3c44, B:200:0x15e7, B:202:0x15f4, B:204:0x163b, B:174:0x1375, B:176:0x1388, B:177:0x13c3, B:183:0x149e, B:185:0x14b0, B:186:0x14e6, B:152:0x11ad, B:154:0x11b7, B:155:0x11f6, B:157:0x1215, B:159:0x121f, B:161:0x1262, B:93:0x0a34, B:95:0x0a3e, B:96:0x0a80, B:48:0x04cb, B:50:0x04df, B:51:0x051d, B:58:0x05b9, B:60:0x05cc, B:61:0x0603, B:67:0x06e5, B:69:0x06fa, B:70:0x0731, B:75:0x07f4, B:77:0x0807, B:78:0x0840), top: B:634:0x0003 }] */
        /* JADX WARN: Removed duplicated region for block: B:522:0x310f A[Catch: all -> 0x3cfd, TryCatch #21 {all -> 0x3cfd, blocks: (B:3:0x0003, B:5:0x0011, B:6:0x003f, B:8:0x0123, B:11:0x0132, B:13:0x0179, B:17:0x01c7, B:19:0x01d6, B:21:0x0218, B:25:0x02f4, B:27:0x02fe, B:28:0x033a, B:30:0x0356, B:32:0x0360, B:34:0x03a2, B:36:0x03ab, B:38:0x03bf, B:40:0x03fd, B:84:0x091c, B:86:0x0929, B:87:0x0962, B:104:0x0fbe, B:106:0x0fc8, B:108:0x1018, B:134:0x10bf, B:136:0x10c9, B:138:0x110c, B:140:0x1130, B:142:0x113a, B:144:0x117d, B:166:0x1279, B:168:0x128f, B:169:0x12cd, B:214:0x1750, B:216:0x175d, B:217:0x179b, B:219:0x18be, B:221:0x18cb, B:222:0x190c, B:240:0x1a98, B:242:0x1aa5, B:243:0x1ae5, B:245:0x1c2d, B:247:0x1c3a, B:248:0x1c7a, B:274:0x1ec4, B:276:0x1ed1, B:278:0x1f1e, B:369:0x2496, B:371:0x24a0, B:372:0x24de, B:375:0x2505, B:377:0x2514, B:378:0x2550, B:389:0x28e3, B:391:0x28f0, B:393:0x2934, B:492:0x2cc0, B:494:0x2cc6, B:495:0x2d08, B:501:0x2dc5, B:503:0x2dcb, B:504:0x2e12, B:510:0x2edd, B:512:0x2ee3, B:513:0x2f29, B:515:0x3000, B:517:0x3006, B:518:0x3049, B:520:0x3109, B:522:0x310f, B:523:0x3151, B:528:0x3226, B:530:0x3233, B:532:0x327a, B:534:0x33e9, B:536:0x33fa, B:537:0x3434, B:539:0x350f, B:541:0x3515, B:542:0x3555, B:544:0x363f, B:546:0x3664, B:547:0x369d, B:552:0x3792, B:554:0x379f, B:555:0x37db, B:561:0x38a8, B:563:0x38ae, B:564:0x38e2, B:566:0x39a4, B:568:0x39aa, B:569:0x39e6, B:571:0x3aa5, B:573:0x3ab2, B:574:0x3af5, B:576:0x3bd3, B:578:0x3c02, B:579:0x3c44, B:200:0x15e7, B:202:0x15f4, B:204:0x163b, B:174:0x1375, B:176:0x1388, B:177:0x13c3, B:183:0x149e, B:185:0x14b0, B:186:0x14e6, B:152:0x11ad, B:154:0x11b7, B:155:0x11f6, B:157:0x1215, B:159:0x121f, B:161:0x1262, B:93:0x0a34, B:95:0x0a3e, B:96:0x0a80, B:48:0x04cb, B:50:0x04df, B:51:0x051d, B:58:0x05b9, B:60:0x05cc, B:61:0x0603, B:67:0x06e5, B:69:0x06fa, B:70:0x0731, B:75:0x07f4, B:77:0x0807, B:78:0x0840), top: B:634:0x0003 }] */
        /* JADX WARN: Removed duplicated region for block: B:526:0x31fa  */
        /* JADX WARN: Removed duplicated region for block: B:530:0x3233 A[Catch: all -> 0x3cfd, TryCatch #21 {all -> 0x3cfd, blocks: (B:3:0x0003, B:5:0x0011, B:6:0x003f, B:8:0x0123, B:11:0x0132, B:13:0x0179, B:17:0x01c7, B:19:0x01d6, B:21:0x0218, B:25:0x02f4, B:27:0x02fe, B:28:0x033a, B:30:0x0356, B:32:0x0360, B:34:0x03a2, B:36:0x03ab, B:38:0x03bf, B:40:0x03fd, B:84:0x091c, B:86:0x0929, B:87:0x0962, B:104:0x0fbe, B:106:0x0fc8, B:108:0x1018, B:134:0x10bf, B:136:0x10c9, B:138:0x110c, B:140:0x1130, B:142:0x113a, B:144:0x117d, B:166:0x1279, B:168:0x128f, B:169:0x12cd, B:214:0x1750, B:216:0x175d, B:217:0x179b, B:219:0x18be, B:221:0x18cb, B:222:0x190c, B:240:0x1a98, B:242:0x1aa5, B:243:0x1ae5, B:245:0x1c2d, B:247:0x1c3a, B:248:0x1c7a, B:274:0x1ec4, B:276:0x1ed1, B:278:0x1f1e, B:369:0x2496, B:371:0x24a0, B:372:0x24de, B:375:0x2505, B:377:0x2514, B:378:0x2550, B:389:0x28e3, B:391:0x28f0, B:393:0x2934, B:492:0x2cc0, B:494:0x2cc6, B:495:0x2d08, B:501:0x2dc5, B:503:0x2dcb, B:504:0x2e12, B:510:0x2edd, B:512:0x2ee3, B:513:0x2f29, B:515:0x3000, B:517:0x3006, B:518:0x3049, B:520:0x3109, B:522:0x310f, B:523:0x3151, B:528:0x3226, B:530:0x3233, B:532:0x327a, B:534:0x33e9, B:536:0x33fa, B:537:0x3434, B:539:0x350f, B:541:0x3515, B:542:0x3555, B:544:0x363f, B:546:0x3664, B:547:0x369d, B:552:0x3792, B:554:0x379f, B:555:0x37db, B:561:0x38a8, B:563:0x38ae, B:564:0x38e2, B:566:0x39a4, B:568:0x39aa, B:569:0x39e6, B:571:0x3aa5, B:573:0x3ab2, B:574:0x3af5, B:576:0x3bd3, B:578:0x3c02, B:579:0x3c44, B:200:0x15e7, B:202:0x15f4, B:204:0x163b, B:174:0x1375, B:176:0x1388, B:177:0x13c3, B:183:0x149e, B:185:0x14b0, B:186:0x14e6, B:152:0x11ad, B:154:0x11b7, B:155:0x11f6, B:157:0x1215, B:159:0x121f, B:161:0x1262, B:93:0x0a34, B:95:0x0a3e, B:96:0x0a80, B:48:0x04cb, B:50:0x04df, B:51:0x051d, B:58:0x05b9, B:60:0x05cc, B:61:0x0603, B:67:0x06e5, B:69:0x06fa, B:70:0x0731, B:75:0x07f4, B:77:0x0807, B:78:0x0840), top: B:634:0x0003 }] */
        /* JADX WARN: Removed duplicated region for block: B:531:0x3278  */
        /* JADX WARN: Removed duplicated region for block: B:536:0x33fa A[Catch: all -> 0x3cfd, TryCatch #21 {all -> 0x3cfd, blocks: (B:3:0x0003, B:5:0x0011, B:6:0x003f, B:8:0x0123, B:11:0x0132, B:13:0x0179, B:17:0x01c7, B:19:0x01d6, B:21:0x0218, B:25:0x02f4, B:27:0x02fe, B:28:0x033a, B:30:0x0356, B:32:0x0360, B:34:0x03a2, B:36:0x03ab, B:38:0x03bf, B:40:0x03fd, B:84:0x091c, B:86:0x0929, B:87:0x0962, B:104:0x0fbe, B:106:0x0fc8, B:108:0x1018, B:134:0x10bf, B:136:0x10c9, B:138:0x110c, B:140:0x1130, B:142:0x113a, B:144:0x117d, B:166:0x1279, B:168:0x128f, B:169:0x12cd, B:214:0x1750, B:216:0x175d, B:217:0x179b, B:219:0x18be, B:221:0x18cb, B:222:0x190c, B:240:0x1a98, B:242:0x1aa5, B:243:0x1ae5, B:245:0x1c2d, B:247:0x1c3a, B:248:0x1c7a, B:274:0x1ec4, B:276:0x1ed1, B:278:0x1f1e, B:369:0x2496, B:371:0x24a0, B:372:0x24de, B:375:0x2505, B:377:0x2514, B:378:0x2550, B:389:0x28e3, B:391:0x28f0, B:393:0x2934, B:492:0x2cc0, B:494:0x2cc6, B:495:0x2d08, B:501:0x2dc5, B:503:0x2dcb, B:504:0x2e12, B:510:0x2edd, B:512:0x2ee3, B:513:0x2f29, B:515:0x3000, B:517:0x3006, B:518:0x3049, B:520:0x3109, B:522:0x310f, B:523:0x3151, B:528:0x3226, B:530:0x3233, B:532:0x327a, B:534:0x33e9, B:536:0x33fa, B:537:0x3434, B:539:0x350f, B:541:0x3515, B:542:0x3555, B:544:0x363f, B:546:0x3664, B:547:0x369d, B:552:0x3792, B:554:0x379f, B:555:0x37db, B:561:0x38a8, B:563:0x38ae, B:564:0x38e2, B:566:0x39a4, B:568:0x39aa, B:569:0x39e6, B:571:0x3aa5, B:573:0x3ab2, B:574:0x3af5, B:576:0x3bd3, B:578:0x3c02, B:579:0x3c44, B:200:0x15e7, B:202:0x15f4, B:204:0x163b, B:174:0x1375, B:176:0x1388, B:177:0x13c3, B:183:0x149e, B:185:0x14b0, B:186:0x14e6, B:152:0x11ad, B:154:0x11b7, B:155:0x11f6, B:157:0x1215, B:159:0x121f, B:161:0x1262, B:93:0x0a34, B:95:0x0a3e, B:96:0x0a80, B:48:0x04cb, B:50:0x04df, B:51:0x051d, B:58:0x05b9, B:60:0x05cc, B:61:0x0603, B:67:0x06e5, B:69:0x06fa, B:70:0x0731, B:75:0x07f4, B:77:0x0807, B:78:0x0840), top: B:634:0x0003 }] */
        /* JADX WARN: Removed duplicated region for block: B:541:0x3515 A[Catch: all -> 0x3cfd, TryCatch #21 {all -> 0x3cfd, blocks: (B:3:0x0003, B:5:0x0011, B:6:0x003f, B:8:0x0123, B:11:0x0132, B:13:0x0179, B:17:0x01c7, B:19:0x01d6, B:21:0x0218, B:25:0x02f4, B:27:0x02fe, B:28:0x033a, B:30:0x0356, B:32:0x0360, B:34:0x03a2, B:36:0x03ab, B:38:0x03bf, B:40:0x03fd, B:84:0x091c, B:86:0x0929, B:87:0x0962, B:104:0x0fbe, B:106:0x0fc8, B:108:0x1018, B:134:0x10bf, B:136:0x10c9, B:138:0x110c, B:140:0x1130, B:142:0x113a, B:144:0x117d, B:166:0x1279, B:168:0x128f, B:169:0x12cd, B:214:0x1750, B:216:0x175d, B:217:0x179b, B:219:0x18be, B:221:0x18cb, B:222:0x190c, B:240:0x1a98, B:242:0x1aa5, B:243:0x1ae5, B:245:0x1c2d, B:247:0x1c3a, B:248:0x1c7a, B:274:0x1ec4, B:276:0x1ed1, B:278:0x1f1e, B:369:0x2496, B:371:0x24a0, B:372:0x24de, B:375:0x2505, B:377:0x2514, B:378:0x2550, B:389:0x28e3, B:391:0x28f0, B:393:0x2934, B:492:0x2cc0, B:494:0x2cc6, B:495:0x2d08, B:501:0x2dc5, B:503:0x2dcb, B:504:0x2e12, B:510:0x2edd, B:512:0x2ee3, B:513:0x2f29, B:515:0x3000, B:517:0x3006, B:518:0x3049, B:520:0x3109, B:522:0x310f, B:523:0x3151, B:528:0x3226, B:530:0x3233, B:532:0x327a, B:534:0x33e9, B:536:0x33fa, B:537:0x3434, B:539:0x350f, B:541:0x3515, B:542:0x3555, B:544:0x363f, B:546:0x3664, B:547:0x369d, B:552:0x3792, B:554:0x379f, B:555:0x37db, B:561:0x38a8, B:563:0x38ae, B:564:0x38e2, B:566:0x39a4, B:568:0x39aa, B:569:0x39e6, B:571:0x3aa5, B:573:0x3ab2, B:574:0x3af5, B:576:0x3bd3, B:578:0x3c02, B:579:0x3c44, B:200:0x15e7, B:202:0x15f4, B:204:0x163b, B:174:0x1375, B:176:0x1388, B:177:0x13c3, B:183:0x149e, B:185:0x14b0, B:186:0x14e6, B:152:0x11ad, B:154:0x11b7, B:155:0x11f6, B:157:0x1215, B:159:0x121f, B:161:0x1262, B:93:0x0a34, B:95:0x0a3e, B:96:0x0a80, B:48:0x04cb, B:50:0x04df, B:51:0x051d, B:58:0x05b9, B:60:0x05cc, B:61:0x0603, B:67:0x06e5, B:69:0x06fa, B:70:0x0731, B:75:0x07f4, B:77:0x0807, B:78:0x0840), top: B:634:0x0003 }] */
        /* JADX WARN: Removed duplicated region for block: B:546:0x3664 A[Catch: all -> 0x3cfd, TryCatch #21 {all -> 0x3cfd, blocks: (B:3:0x0003, B:5:0x0011, B:6:0x003f, B:8:0x0123, B:11:0x0132, B:13:0x0179, B:17:0x01c7, B:19:0x01d6, B:21:0x0218, B:25:0x02f4, B:27:0x02fe, B:28:0x033a, B:30:0x0356, B:32:0x0360, B:34:0x03a2, B:36:0x03ab, B:38:0x03bf, B:40:0x03fd, B:84:0x091c, B:86:0x0929, B:87:0x0962, B:104:0x0fbe, B:106:0x0fc8, B:108:0x1018, B:134:0x10bf, B:136:0x10c9, B:138:0x110c, B:140:0x1130, B:142:0x113a, B:144:0x117d, B:166:0x1279, B:168:0x128f, B:169:0x12cd, B:214:0x1750, B:216:0x175d, B:217:0x179b, B:219:0x18be, B:221:0x18cb, B:222:0x190c, B:240:0x1a98, B:242:0x1aa5, B:243:0x1ae5, B:245:0x1c2d, B:247:0x1c3a, B:248:0x1c7a, B:274:0x1ec4, B:276:0x1ed1, B:278:0x1f1e, B:369:0x2496, B:371:0x24a0, B:372:0x24de, B:375:0x2505, B:377:0x2514, B:378:0x2550, B:389:0x28e3, B:391:0x28f0, B:393:0x2934, B:492:0x2cc0, B:494:0x2cc6, B:495:0x2d08, B:501:0x2dc5, B:503:0x2dcb, B:504:0x2e12, B:510:0x2edd, B:512:0x2ee3, B:513:0x2f29, B:515:0x3000, B:517:0x3006, B:518:0x3049, B:520:0x3109, B:522:0x310f, B:523:0x3151, B:528:0x3226, B:530:0x3233, B:532:0x327a, B:534:0x33e9, B:536:0x33fa, B:537:0x3434, B:539:0x350f, B:541:0x3515, B:542:0x3555, B:544:0x363f, B:546:0x3664, B:547:0x369d, B:552:0x3792, B:554:0x379f, B:555:0x37db, B:561:0x38a8, B:563:0x38ae, B:564:0x38e2, B:566:0x39a4, B:568:0x39aa, B:569:0x39e6, B:571:0x3aa5, B:573:0x3ab2, B:574:0x3af5, B:576:0x3bd3, B:578:0x3c02, B:579:0x3c44, B:200:0x15e7, B:202:0x15f4, B:204:0x163b, B:174:0x1375, B:176:0x1388, B:177:0x13c3, B:183:0x149e, B:185:0x14b0, B:186:0x14e6, B:152:0x11ad, B:154:0x11b7, B:155:0x11f6, B:157:0x1215, B:159:0x121f, B:161:0x1262, B:93:0x0a34, B:95:0x0a3e, B:96:0x0a80, B:48:0x04cb, B:50:0x04df, B:51:0x051d, B:58:0x05b9, B:60:0x05cc, B:61:0x0603, B:67:0x06e5, B:69:0x06fa, B:70:0x0731, B:75:0x07f4, B:77:0x0807, B:78:0x0840), top: B:634:0x0003 }] */
        /* JADX WARN: Removed duplicated region for block: B:550:0x3752  */
        /* JADX WARN: Removed duplicated region for block: B:554:0x379f A[Catch: all -> 0x3cfd, TryCatch #21 {all -> 0x3cfd, blocks: (B:3:0x0003, B:5:0x0011, B:6:0x003f, B:8:0x0123, B:11:0x0132, B:13:0x0179, B:17:0x01c7, B:19:0x01d6, B:21:0x0218, B:25:0x02f4, B:27:0x02fe, B:28:0x033a, B:30:0x0356, B:32:0x0360, B:34:0x03a2, B:36:0x03ab, B:38:0x03bf, B:40:0x03fd, B:84:0x091c, B:86:0x0929, B:87:0x0962, B:104:0x0fbe, B:106:0x0fc8, B:108:0x1018, B:134:0x10bf, B:136:0x10c9, B:138:0x110c, B:140:0x1130, B:142:0x113a, B:144:0x117d, B:166:0x1279, B:168:0x128f, B:169:0x12cd, B:214:0x1750, B:216:0x175d, B:217:0x179b, B:219:0x18be, B:221:0x18cb, B:222:0x190c, B:240:0x1a98, B:242:0x1aa5, B:243:0x1ae5, B:245:0x1c2d, B:247:0x1c3a, B:248:0x1c7a, B:274:0x1ec4, B:276:0x1ed1, B:278:0x1f1e, B:369:0x2496, B:371:0x24a0, B:372:0x24de, B:375:0x2505, B:377:0x2514, B:378:0x2550, B:389:0x28e3, B:391:0x28f0, B:393:0x2934, B:492:0x2cc0, B:494:0x2cc6, B:495:0x2d08, B:501:0x2dc5, B:503:0x2dcb, B:504:0x2e12, B:510:0x2edd, B:512:0x2ee3, B:513:0x2f29, B:515:0x3000, B:517:0x3006, B:518:0x3049, B:520:0x3109, B:522:0x310f, B:523:0x3151, B:528:0x3226, B:530:0x3233, B:532:0x327a, B:534:0x33e9, B:536:0x33fa, B:537:0x3434, B:539:0x350f, B:541:0x3515, B:542:0x3555, B:544:0x363f, B:546:0x3664, B:547:0x369d, B:552:0x3792, B:554:0x379f, B:555:0x37db, B:561:0x38a8, B:563:0x38ae, B:564:0x38e2, B:566:0x39a4, B:568:0x39aa, B:569:0x39e6, B:571:0x3aa5, B:573:0x3ab2, B:574:0x3af5, B:576:0x3bd3, B:578:0x3c02, B:579:0x3c44, B:200:0x15e7, B:202:0x15f4, B:204:0x163b, B:174:0x1375, B:176:0x1388, B:177:0x13c3, B:183:0x149e, B:185:0x14b0, B:186:0x14e6, B:152:0x11ad, B:154:0x11b7, B:155:0x11f6, B:157:0x1215, B:159:0x121f, B:161:0x1262, B:93:0x0a34, B:95:0x0a3e, B:96:0x0a80, B:48:0x04cb, B:50:0x04df, B:51:0x051d, B:58:0x05b9, B:60:0x05cc, B:61:0x0603, B:67:0x06e5, B:69:0x06fa, B:70:0x0731, B:75:0x07f4, B:77:0x0807, B:78:0x0840), top: B:634:0x0003 }] */
        /* JADX WARN: Removed duplicated region for block: B:558:0x388b  */
        /* JADX WARN: Removed duplicated region for block: B:559:0x3893  */
        /* JADX WARN: Removed duplicated region for block: B:563:0x38ae A[Catch: all -> 0x3cfd, TryCatch #21 {all -> 0x3cfd, blocks: (B:3:0x0003, B:5:0x0011, B:6:0x003f, B:8:0x0123, B:11:0x0132, B:13:0x0179, B:17:0x01c7, B:19:0x01d6, B:21:0x0218, B:25:0x02f4, B:27:0x02fe, B:28:0x033a, B:30:0x0356, B:32:0x0360, B:34:0x03a2, B:36:0x03ab, B:38:0x03bf, B:40:0x03fd, B:84:0x091c, B:86:0x0929, B:87:0x0962, B:104:0x0fbe, B:106:0x0fc8, B:108:0x1018, B:134:0x10bf, B:136:0x10c9, B:138:0x110c, B:140:0x1130, B:142:0x113a, B:144:0x117d, B:166:0x1279, B:168:0x128f, B:169:0x12cd, B:214:0x1750, B:216:0x175d, B:217:0x179b, B:219:0x18be, B:221:0x18cb, B:222:0x190c, B:240:0x1a98, B:242:0x1aa5, B:243:0x1ae5, B:245:0x1c2d, B:247:0x1c3a, B:248:0x1c7a, B:274:0x1ec4, B:276:0x1ed1, B:278:0x1f1e, B:369:0x2496, B:371:0x24a0, B:372:0x24de, B:375:0x2505, B:377:0x2514, B:378:0x2550, B:389:0x28e3, B:391:0x28f0, B:393:0x2934, B:492:0x2cc0, B:494:0x2cc6, B:495:0x2d08, B:501:0x2dc5, B:503:0x2dcb, B:504:0x2e12, B:510:0x2edd, B:512:0x2ee3, B:513:0x2f29, B:515:0x3000, B:517:0x3006, B:518:0x3049, B:520:0x3109, B:522:0x310f, B:523:0x3151, B:528:0x3226, B:530:0x3233, B:532:0x327a, B:534:0x33e9, B:536:0x33fa, B:537:0x3434, B:539:0x350f, B:541:0x3515, B:542:0x3555, B:544:0x363f, B:546:0x3664, B:547:0x369d, B:552:0x3792, B:554:0x379f, B:555:0x37db, B:561:0x38a8, B:563:0x38ae, B:564:0x38e2, B:566:0x39a4, B:568:0x39aa, B:569:0x39e6, B:571:0x3aa5, B:573:0x3ab2, B:574:0x3af5, B:576:0x3bd3, B:578:0x3c02, B:579:0x3c44, B:200:0x15e7, B:202:0x15f4, B:204:0x163b, B:174:0x1375, B:176:0x1388, B:177:0x13c3, B:183:0x149e, B:185:0x14b0, B:186:0x14e6, B:152:0x11ad, B:154:0x11b7, B:155:0x11f6, B:157:0x1215, B:159:0x121f, B:161:0x1262, B:93:0x0a34, B:95:0x0a3e, B:96:0x0a80, B:48:0x04cb, B:50:0x04df, B:51:0x051d, B:58:0x05b9, B:60:0x05cc, B:61:0x0603, B:67:0x06e5, B:69:0x06fa, B:70:0x0731, B:75:0x07f4, B:77:0x0807, B:78:0x0840), top: B:634:0x0003 }] */
        /* JADX WARN: Removed duplicated region for block: B:568:0x39aa A[Catch: all -> 0x3cfd, TryCatch #21 {all -> 0x3cfd, blocks: (B:3:0x0003, B:5:0x0011, B:6:0x003f, B:8:0x0123, B:11:0x0132, B:13:0x0179, B:17:0x01c7, B:19:0x01d6, B:21:0x0218, B:25:0x02f4, B:27:0x02fe, B:28:0x033a, B:30:0x0356, B:32:0x0360, B:34:0x03a2, B:36:0x03ab, B:38:0x03bf, B:40:0x03fd, B:84:0x091c, B:86:0x0929, B:87:0x0962, B:104:0x0fbe, B:106:0x0fc8, B:108:0x1018, B:134:0x10bf, B:136:0x10c9, B:138:0x110c, B:140:0x1130, B:142:0x113a, B:144:0x117d, B:166:0x1279, B:168:0x128f, B:169:0x12cd, B:214:0x1750, B:216:0x175d, B:217:0x179b, B:219:0x18be, B:221:0x18cb, B:222:0x190c, B:240:0x1a98, B:242:0x1aa5, B:243:0x1ae5, B:245:0x1c2d, B:247:0x1c3a, B:248:0x1c7a, B:274:0x1ec4, B:276:0x1ed1, B:278:0x1f1e, B:369:0x2496, B:371:0x24a0, B:372:0x24de, B:375:0x2505, B:377:0x2514, B:378:0x2550, B:389:0x28e3, B:391:0x28f0, B:393:0x2934, B:492:0x2cc0, B:494:0x2cc6, B:495:0x2d08, B:501:0x2dc5, B:503:0x2dcb, B:504:0x2e12, B:510:0x2edd, B:512:0x2ee3, B:513:0x2f29, B:515:0x3000, B:517:0x3006, B:518:0x3049, B:520:0x3109, B:522:0x310f, B:523:0x3151, B:528:0x3226, B:530:0x3233, B:532:0x327a, B:534:0x33e9, B:536:0x33fa, B:537:0x3434, B:539:0x350f, B:541:0x3515, B:542:0x3555, B:544:0x363f, B:546:0x3664, B:547:0x369d, B:552:0x3792, B:554:0x379f, B:555:0x37db, B:561:0x38a8, B:563:0x38ae, B:564:0x38e2, B:566:0x39a4, B:568:0x39aa, B:569:0x39e6, B:571:0x3aa5, B:573:0x3ab2, B:574:0x3af5, B:576:0x3bd3, B:578:0x3c02, B:579:0x3c44, B:200:0x15e7, B:202:0x15f4, B:204:0x163b, B:174:0x1375, B:176:0x1388, B:177:0x13c3, B:183:0x149e, B:185:0x14b0, B:186:0x14e6, B:152:0x11ad, B:154:0x11b7, B:155:0x11f6, B:157:0x1215, B:159:0x121f, B:161:0x1262, B:93:0x0a34, B:95:0x0a3e, B:96:0x0a80, B:48:0x04cb, B:50:0x04df, B:51:0x051d, B:58:0x05b9, B:60:0x05cc, B:61:0x0603, B:67:0x06e5, B:69:0x06fa, B:70:0x0731, B:75:0x07f4, B:77:0x0807, B:78:0x0840), top: B:634:0x0003 }] */
        /* JADX WARN: Removed duplicated region for block: B:573:0x3ab2 A[Catch: all -> 0x3cfd, TryCatch #21 {all -> 0x3cfd, blocks: (B:3:0x0003, B:5:0x0011, B:6:0x003f, B:8:0x0123, B:11:0x0132, B:13:0x0179, B:17:0x01c7, B:19:0x01d6, B:21:0x0218, B:25:0x02f4, B:27:0x02fe, B:28:0x033a, B:30:0x0356, B:32:0x0360, B:34:0x03a2, B:36:0x03ab, B:38:0x03bf, B:40:0x03fd, B:84:0x091c, B:86:0x0929, B:87:0x0962, B:104:0x0fbe, B:106:0x0fc8, B:108:0x1018, B:134:0x10bf, B:136:0x10c9, B:138:0x110c, B:140:0x1130, B:142:0x113a, B:144:0x117d, B:166:0x1279, B:168:0x128f, B:169:0x12cd, B:214:0x1750, B:216:0x175d, B:217:0x179b, B:219:0x18be, B:221:0x18cb, B:222:0x190c, B:240:0x1a98, B:242:0x1aa5, B:243:0x1ae5, B:245:0x1c2d, B:247:0x1c3a, B:248:0x1c7a, B:274:0x1ec4, B:276:0x1ed1, B:278:0x1f1e, B:369:0x2496, B:371:0x24a0, B:372:0x24de, B:375:0x2505, B:377:0x2514, B:378:0x2550, B:389:0x28e3, B:391:0x28f0, B:393:0x2934, B:492:0x2cc0, B:494:0x2cc6, B:495:0x2d08, B:501:0x2dc5, B:503:0x2dcb, B:504:0x2e12, B:510:0x2edd, B:512:0x2ee3, B:513:0x2f29, B:515:0x3000, B:517:0x3006, B:518:0x3049, B:520:0x3109, B:522:0x310f, B:523:0x3151, B:528:0x3226, B:530:0x3233, B:532:0x327a, B:534:0x33e9, B:536:0x33fa, B:537:0x3434, B:539:0x350f, B:541:0x3515, B:542:0x3555, B:544:0x363f, B:546:0x3664, B:547:0x369d, B:552:0x3792, B:554:0x379f, B:555:0x37db, B:561:0x38a8, B:563:0x38ae, B:564:0x38e2, B:566:0x39a4, B:568:0x39aa, B:569:0x39e6, B:571:0x3aa5, B:573:0x3ab2, B:574:0x3af5, B:576:0x3bd3, B:578:0x3c02, B:579:0x3c44, B:200:0x15e7, B:202:0x15f4, B:204:0x163b, B:174:0x1375, B:176:0x1388, B:177:0x13c3, B:183:0x149e, B:185:0x14b0, B:186:0x14e6, B:152:0x11ad, B:154:0x11b7, B:155:0x11f6, B:157:0x1215, B:159:0x121f, B:161:0x1262, B:93:0x0a34, B:95:0x0a3e, B:96:0x0a80, B:48:0x04cb, B:50:0x04df, B:51:0x051d, B:58:0x05b9, B:60:0x05cc, B:61:0x0603, B:67:0x06e5, B:69:0x06fa, B:70:0x0731, B:75:0x07f4, B:77:0x0807, B:78:0x0840), top: B:634:0x0003 }] */
        /* JADX WARN: Removed duplicated region for block: B:578:0x3c02 A[Catch: all -> 0x3cfd, TryCatch #21 {all -> 0x3cfd, blocks: (B:3:0x0003, B:5:0x0011, B:6:0x003f, B:8:0x0123, B:11:0x0132, B:13:0x0179, B:17:0x01c7, B:19:0x01d6, B:21:0x0218, B:25:0x02f4, B:27:0x02fe, B:28:0x033a, B:30:0x0356, B:32:0x0360, B:34:0x03a2, B:36:0x03ab, B:38:0x03bf, B:40:0x03fd, B:84:0x091c, B:86:0x0929, B:87:0x0962, B:104:0x0fbe, B:106:0x0fc8, B:108:0x1018, B:134:0x10bf, B:136:0x10c9, B:138:0x110c, B:140:0x1130, B:142:0x113a, B:144:0x117d, B:166:0x1279, B:168:0x128f, B:169:0x12cd, B:214:0x1750, B:216:0x175d, B:217:0x179b, B:219:0x18be, B:221:0x18cb, B:222:0x190c, B:240:0x1a98, B:242:0x1aa5, B:243:0x1ae5, B:245:0x1c2d, B:247:0x1c3a, B:248:0x1c7a, B:274:0x1ec4, B:276:0x1ed1, B:278:0x1f1e, B:369:0x2496, B:371:0x24a0, B:372:0x24de, B:375:0x2505, B:377:0x2514, B:378:0x2550, B:389:0x28e3, B:391:0x28f0, B:393:0x2934, B:492:0x2cc0, B:494:0x2cc6, B:495:0x2d08, B:501:0x2dc5, B:503:0x2dcb, B:504:0x2e12, B:510:0x2edd, B:512:0x2ee3, B:513:0x2f29, B:515:0x3000, B:517:0x3006, B:518:0x3049, B:520:0x3109, B:522:0x310f, B:523:0x3151, B:528:0x3226, B:530:0x3233, B:532:0x327a, B:534:0x33e9, B:536:0x33fa, B:537:0x3434, B:539:0x350f, B:541:0x3515, B:542:0x3555, B:544:0x363f, B:546:0x3664, B:547:0x369d, B:552:0x3792, B:554:0x379f, B:555:0x37db, B:561:0x38a8, B:563:0x38ae, B:564:0x38e2, B:566:0x39a4, B:568:0x39aa, B:569:0x39e6, B:571:0x3aa5, B:573:0x3ab2, B:574:0x3af5, B:576:0x3bd3, B:578:0x3c02, B:579:0x3c44, B:200:0x15e7, B:202:0x15f4, B:204:0x163b, B:174:0x1375, B:176:0x1388, B:177:0x13c3, B:183:0x149e, B:185:0x14b0, B:186:0x14e6, B:152:0x11ad, B:154:0x11b7, B:155:0x11f6, B:157:0x1215, B:159:0x121f, B:161:0x1262, B:93:0x0a34, B:95:0x0a3e, B:96:0x0a80, B:48:0x04cb, B:50:0x04df, B:51:0x051d, B:58:0x05b9, B:60:0x05cc, B:61:0x0603, B:67:0x06e5, B:69:0x06fa, B:70:0x0731, B:75:0x07f4, B:77:0x0807, B:78:0x0840), top: B:634:0x0003 }] */
        /* JADX WARN: Removed duplicated region for block: B:617:0x2b4b A[EXC_TOP_SPLITTER, SYNTHETIC] */
        /* JADX WARN: Removed duplicated region for block: B:623:0x2c78 A[EXC_TOP_SPLITTER, SYNTHETIC] */
        /* JADX WARN: Removed duplicated region for block: B:648:0x1ff3 A[SYNTHETIC] */
        /* JADX WARN: Removed duplicated region for block: B:64:0x06d0  */
        /* JADX WARN: Removed duplicated region for block: B:81:0x08fa A[PHI: r6
          0x08fa: PHI (r6v44 java.lang.String) = 
          (r6v40 java.lang.String)
          (r6v40 java.lang.String)
          (r6v40 java.lang.String)
          (r6v41 java.lang.String)
          (r6v56 java.lang.String)
         binds: [B:80:0x08f8, B:72:0x07ef, B:63:0x06ce, B:53:0x05b2, B:44:0x04c3] A[DONT_GENERATE, DONT_INLINE]] */
        /* JADX WARN: Removed duplicated region for block: B:83:0x0900  */
        /* JADX WARN: Removed duplicated region for block: B:92:0x0a19  */
        /* JADX WARN: Removed duplicated region for block: B:99:0x0aa4  */
        /*
            Code decompiled incorrectly, please refer to instructions dump.
            To view partially-correct code enable 'Show inconsistent code' option in preferences
        */
        public static java.lang.Object[] d$2669f03c(java.lang.Object r78) throws java.lang.Throwable {
            /*
                Method dump skipped, instruction units count: 15622
                To view this dump change 'Code comments level' option to 'DEBUG'
            */
            throw new UnsupportedOperationException("Method not decompiled: com.facetec.sdk.gn.AnonymousClass4.d$2669f03c(java.lang.Object):java.lang.Object[]");
        }

        /* JADX WARN: Removed duplicated region for block: B:10:0x0028  */
        /* JADX WARN: Removed duplicated region for block: B:8:0x0020  */
        /* JADX WARN: Unsupported multi-entry loop pattern (BACK_EDGE: B:10:0x0028 -> B:11:0x002c). Please report as a decompilation issue!!! */
        /*
            Code decompiled incorrectly, please refer to instructions dump.
            To view partially-correct code enable 'Show inconsistent code' option in preferences
        */
        private static void f(short r5, int r6, short r7, java.lang.Object[] r8) {
            /*
                int r5 = r5 * 4
                int r5 = 4 - r5
                int r7 = r7 * 2
                int r0 = 1 - r7
                int r6 = r6 + 97
                byte[] r1 = com.facetec.sdk.gn.AnonymousClass4.$$d
                byte[] r0 = new byte[r0]
                r2 = 0
                int r7 = 0 - r7
                if (r1 != 0) goto L17
                r4 = r6
                r3 = r2
                r6 = r5
                goto L2c
            L17:
                r3 = r6
                r6 = r5
                r5 = r3
                r3 = r2
            L1b:
                byte r4 = (byte) r5
                r0[r3] = r4
                if (r3 != r7) goto L28
                java.lang.String r5 = new java.lang.String
                r5.<init>(r0, r2)
                r8[r2] = r5
                return
            L28:
                int r3 = r3 + 1
                r4 = r1[r6]
            L2c:
                int r5 = r5 + r4
                int r6 = r6 + 1
                goto L1b
            */
            throw new UnsupportedOperationException("Method not decompiled: com.facetec.sdk.gn.AnonymousClass4.f(short, int, short, java.lang.Object[]):void");
        }

        /* JADX WARN: Removed duplicated region for block: B:46:0x01df  */
        /* JADX WARN: Removed duplicated region for block: B:47:0x01e0  */
        /*
            Code decompiled incorrectly, please refer to instructions dump.
            To view partially-correct code enable 'Show inconsistent code' option in preferences
        */
        private static void g(java.lang.String r26, int r27, java.lang.Object[] r28) throws java.lang.Throwable {
            /*
                Method dump skipped, instruction units count: 499
                To view this dump change 'Code comments level' option to 'DEBUG'
            */
            throw new UnsupportedOperationException("Method not decompiled: com.facetec.sdk.gn.AnonymousClass4.g(java.lang.String, int, java.lang.Object[]):void");
        }

        /* JADX WARN: Code restructure failed: missing block: B:30:0x012a, code lost:
        
            r3[r4] = (char) r2[r4];
         */
        /* JADX WARN: Code restructure failed: missing block: B:31:0x0130, code lost:
        
            r0 = new java.lang.Object[]{r1, r1};
            r1 = com.facetec.sdk.an.d(1350882691);
         */
        /* JADX WARN: Code restructure failed: missing block: B:32:0x013b, code lost:
        
            if (r1 != null) goto L34;
         */
        /* JADX WARN: Code restructure failed: missing block: B:33:0x013d, code lost:
        
            r1 = (byte) 0;
            r2 = r1;
            r1 = com.facetec.sdk.an.d(1534 - android.graphics.Color.blue(0), (char) android.graphics.drawable.Drawable.resolveOpacity(0, 0), (android.view.ViewConfiguration.getTouchSlop() >> 8) + 24, 652543704, false, $$g(r1, r2, (byte) (r2 + 3)), new java.lang.Class[]{java.lang.Object.class, java.lang.Object.class});
         */
        /* JADX WARN: Code restructure failed: missing block: B:34:0x0165, code lost:
        
            ((java.lang.reflect.Method) r1).invoke(null, r0);
         */
        /* JADX WARN: Code restructure failed: missing block: B:35:0x016a, code lost:
        
            throw null;
         */
        /* JADX WARN: Removed duplicated region for block: B:45:0x01be  */
        /* JADX WARN: Removed duplicated region for block: B:46:0x01bf  */
        /*
            Code decompiled incorrectly, please refer to instructions dump.
            To view partially-correct code enable 'Show inconsistent code' option in preferences
        */
        private static void h(int r23, char r24, int r25, java.lang.Object[] r26) throws java.lang.Throwable {
            /*
                Method dump skipped, instruction units count: 478
                To view this dump change 'Code comments level' option to 'DEBUG'
            */
            throw new UnsupportedOperationException("Method not decompiled: com.facetec.sdk.gn.AnonymousClass4.h(int, char, int, java.lang.Object[]):void");
        }

        /* JADX WARN: Removed duplicated region for block: B:10:0x0029  */
        /* JADX WARN: Removed duplicated region for block: B:8:0x0021  */
        /* JADX WARN: Unsupported multi-entry loop pattern (BACK_EDGE: B:10:0x0029 -> B:11:0x002b). Please report as a decompilation issue!!! */
        /*
            Code decompiled incorrectly, please refer to instructions dump.
            To view partially-correct code enable 'Show inconsistent code' option in preferences
        */
        private static void i(short r5, int r6, int r7, java.lang.Object[] r8) {
            /*
                int r6 = r6 * 15
                int r6 = 19 - r6
                int r5 = r5 * 11
                int r0 = 16 - r5
                byte[] r1 = com.facetec.sdk.gn.AnonymousClass4.$$a
                int r7 = r7 * 9
                int r7 = r7 + 106
                byte[] r0 = new byte[r0]
                int r5 = 15 - r5
                r2 = 0
                if (r1 != 0) goto L19
                r3 = r7
                r4 = r2
                r7 = r5
                goto L2b
            L19:
                r3 = r2
            L1a:
                byte r4 = (byte) r7
                r0[r3] = r4
                int r4 = r3 + 1
                if (r3 != r5) goto L29
                java.lang.String r5 = new java.lang.String
                r5.<init>(r0, r2)
                r8[r2] = r5
                return
            L29:
                r3 = r1[r6]
            L2b:
                int r7 = r7 + r3
                int r6 = r6 + 1
                int r7 = r7 + 2
                r3 = r4
                goto L1a
            */
            throw new UnsupportedOperationException("Method not decompiled: com.facetec.sdk.gn.AnonymousClass4.i(short, int, int, java.lang.Object[]):void");
        }

        public static void init$0() {
            $$a = new byte[]{20, 103, 109, ISO7816.INS_DECREASE_STAMPED, -11, 19, -23, -53, 60, -13, PassportService.SFI_DG11, -9, -59, ISO7816.INS_CHANGE_CHV, 18, 8, -15, -6, 1, -1, -21, PassportService.SFI_DG15, 0};
            $$b = 28;
        }

        public static void init$1() {
            $$d = new byte[]{2, 77, 55, -86};
            $$e = 55;
        }

        public static void init$2() {
            $$c = new byte[]{4, 8, -22, -73};
            $$f = 6;
        }

        @Override // com.facetec.sdk.fg
        public final /* synthetic */ Number a(gs gsVar) {
            if (gsVar.j() != gw.NULL) {
                Double dValueOf = Double.valueOf(gsVar.o());
                int i = a + 43;
                e = i % 128;
                if (i % 2 != 0) {
                    return dValueOf;
                }
                throw null;
            }
            int i2 = e + 101;
            a = i2 % 128;
            if (i2 % 2 == 0) {
                gsVar.m();
                return null;
            }
            gsVar.m();
            throw null;
        }

        /* JADX WARN: Code restructure failed: missing block: B:10:0x0020, code lost:
        
            r4.e(r5.doubleValue());
         */
        /* JADX WARN: Code restructure failed: missing block: B:11:0x0027, code lost:
        
            return;
         */
        /* JADX WARN: Code restructure failed: missing block: B:5:0x0011, code lost:
        
            if (r5 == null) goto L8;
         */
        /* JADX WARN: Code restructure failed: missing block: B:7:0x0014, code lost:
        
            if (r5 == null) goto L8;
         */
        /* JADX WARN: Code restructure failed: missing block: B:8:0x0016, code lost:
        
            com.facetec.sdk.gn.AnonymousClass4.e = (r2 + 31) % 128;
            r4.g();
         */
        /* JADX WARN: Code restructure failed: missing block: B:9:0x001f, code lost:
        
            return;
         */
        @Override // com.facetec.sdk.fg
        /*
            Code decompiled incorrectly, please refer to instructions dump.
            To view partially-correct code enable 'Show inconsistent code' option in preferences
        */
        public final /* bridge */ /* synthetic */ void e(com.facetec.sdk.ha r4, java.lang.Number r5) {
            /*
                r3 = this;
                int r0 = com.facetec.sdk.gn.AnonymousClass4.e
                r1 = 55
                int r0 = r0 + r1
                int r2 = r0 % 128
                com.facetec.sdk.gn.AnonymousClass4.a = r2
                int r0 = r0 % 2
                java.lang.Number r5 = (java.lang.Number) r5
                if (r0 == 0) goto L14
                int r1 = r1 / 0
                if (r5 != 0) goto L20
                goto L16
            L14:
                if (r5 != 0) goto L20
            L16:
                int r2 = r2 + 31
                int r2 = r2 % 128
                com.facetec.sdk.gn.AnonymousClass4.e = r2
                r4.g()
                return
            L20:
                double r0 = r5.doubleValue()
                r4.e(r0)
                return
            */
            throw new UnsupportedOperationException("Method not decompiled: com.facetec.sdk.gn.AnonymousClass4.e(com.facetec.sdk.ha, java.lang.Object):void");
        }
    }

    public static final class c<T extends Enum<T>> extends fg<T> {
        private final Map<String, T> d = new HashMap();
        private final Map<String, T> e = new HashMap();
        private final Map<T, String> b = new HashMap();

        /* JADX INFO: renamed from: com.facetec.sdk.gn$c$4, reason: invalid class name */
        public class AnonymousClass4 implements PrivilegedAction<Field[]> {
            public static int d;
            public static int e;
            private /* synthetic */ Class c;

            public AnonymousClass4(Class cls) {
                this.c = cls;
            }

            public static int c() {
                int i = d;
                int i2 = i % 9921366;
                d = i + 1;
                if (i2 != 0) {
                    return e;
                }
                int iElapsedRealtime = (int) SystemClock.elapsedRealtime();
                e = iElapsedRealtime;
                return iElapsedRealtime;
            }

            @Override // java.security.PrivilegedAction
            public final /* synthetic */ Field[] run() {
                Field[] declaredFields = this.c.getDeclaredFields();
                ArrayList arrayList = new ArrayList(declaredFields.length);
                for (Field field : declaredFields) {
                    if (field.isEnumConstant()) {
                        arrayList.add(field);
                    }
                }
                Field[] fieldArr = (Field[]) arrayList.toArray(new Field[0]);
                AccessibleObject.setAccessible(fieldArr, true);
                return fieldArr;
            }
        }

        public c(Class<T> cls) {
            try {
                for (Field field : (Field[]) AccessController.doPrivileged(new AnonymousClass4(cls))) {
                    Enum r4 = (Enum) field.get(null);
                    String strName = r4.name();
                    String string = r4.toString();
                    fe feVar = (fe) field.getAnnotation(fe.class);
                    if (feVar != null) {
                        strName = feVar.a();
                        for (String str : feVar.b()) {
                            this.d.put(str, (T) r4);
                        }
                    }
                    this.d.put(strName, (T) r4);
                    this.e.put(string, (T) r4);
                    this.b.put((T) r4, strName);
                }
            } catch (IllegalAccessException e) {
                throw new AssertionError(e);
            }
        }

        @Override // com.facetec.sdk.fg
        public final /* synthetic */ Object a(gs gsVar) {
            if (gsVar.j() == gw.NULL) {
                gsVar.m();
                return null;
            }
            String strH = gsVar.h();
            T t = this.d.get(strH);
            return t == null ? this.e.get(strH) : t;
        }

        @Override // com.facetec.sdk.fg
        public final /* bridge */ /* synthetic */ void e(ha haVar, Object obj) {
            Enum r3 = (Enum) obj;
            haVar.e(r3 == null ? null : this.b.get(r3));
        }
    }

    static {
        fg<Class> fgVarB = new fg<Class>() { // from class: com.facetec.sdk.gn.3
            @Override // com.facetec.sdk.fg
            public final /* synthetic */ Class a(gs gsVar) {
                throw new UnsupportedOperationException("Attempted to deserialize a java.lang.Class. Forgot to register a type adapter?");
            }

            @Override // com.facetec.sdk.fg
            public final /* synthetic */ void e(ha haVar, Class cls) {
                StringBuilder sb = new StringBuilder("Attempted to serialize java.lang.Class: ");
                sb.append(cls.getName());
                sb.append(". Forgot to register a type adapter?");
                throw new UnsupportedOperationException(sb.toString());
            }
        }.b();
        I = fgVarB;
        e = b(Class.class, fgVarB);
        fg<BitSet> fgVarB2 = new fg<BitSet>() { // from class: com.facetec.sdk.gn.13
            @Override // com.facetec.sdk.fg
            public final /* synthetic */ BitSet a(gs gsVar) {
                BitSet bitSet = new BitSet();
                gsVar.c();
                gw gwVarJ = gsVar.j();
                int i2 = 0;
                while (gwVarJ != gw.END_ARRAY) {
                    int i3 = AnonymousClass27.d[gwVarJ.ordinal()];
                    boolean zF = true;
                    if (i3 == 1 || i3 == 2) {
                        int iK = gsVar.k();
                        if (iK == 0) {
                            zF = false;
                        } else if (iK != 1) {
                            StringBuilder sb = new StringBuilder("Invalid bitset value ");
                            sb.append(iK);
                            sb.append(", expected 0 or 1; at path ");
                            sb.append(gsVar.q());
                            throw new fc(sb.toString());
                        }
                    } else {
                        if (i3 != 3) {
                            StringBuilder sb2 = new StringBuilder("Invalid bitset value type: ");
                            sb2.append(gwVarJ);
                            sb2.append("; at path ");
                            sb2.append(gsVar.p());
                            throw new fc(sb2.toString());
                        }
                        zF = gsVar.f();
                    }
                    if (zF) {
                        bitSet.set(i2);
                    }
                    i2++;
                    gwVarJ = gsVar.j();
                }
                gsVar.e();
                return bitSet;
            }

            @Override // com.facetec.sdk.fg
            public final /* bridge */ /* synthetic */ void e(ha haVar, BitSet bitSet) {
                BitSet bitSet2 = bitSet;
                haVar.e();
                int length = bitSet2.length();
                for (int i2 = 0; i2 < length; i2++) {
                    haVar.d(bitSet2.get(i2) ? 1L : 0L);
                }
                haVar.a();
            }
        }.b();
        F = fgVarB2;
        d = b(BitSet.class, fgVarB2);
        H = new AnonymousClass24();
        b = new AnonymousClass29();
        a = d(Boolean.TYPE, Boolean.class, H);
        fg<Number> fgVar = new fg<Number>() { // from class: com.facetec.sdk.gn.26
            private static Number d(gs gsVar) {
                if (gsVar.j() == gw.NULL) {
                    gsVar.m();
                    return null;
                }
                try {
                    int iK = gsVar.k();
                    if (iK <= 255 && iK >= -128) {
                        return Byte.valueOf((byte) iK);
                    }
                    StringBuilder sb = new StringBuilder("Lossy conversion from ");
                    sb.append(iK);
                    sb.append(" to byte; at path ");
                    sb.append(gsVar.q());
                    throw new fc(sb.toString());
                } catch (NumberFormatException e2) {
                    throw new fc(e2);
                }
            }

            @Override // com.facetec.sdk.fg
            public final /* synthetic */ Number a(gs gsVar) {
                return d(gsVar);
            }

            @Override // com.facetec.sdk.fg
            public final /* synthetic */ void e(ha haVar, Number number) {
                if (number == null) {
                    haVar.g();
                } else {
                    haVar.d(r4.byteValue());
                }
            }
        };
        G = fgVar;
        c = d(Byte.TYPE, Byte.class, fgVar);
        fg<Number> fgVar2 = new fg<Number>() { // from class: com.facetec.sdk.gn.33
            private static final byte[] $$a = null;
            private static final int $$b = 0;
            private static int c;
            private static int e;

            static {
                init$0();
                e = 0;
                c = 1;
            }

            public static void d(long j2, long j3) throws Throwable {
                int i2;
                int i3 = e;
                c = (((i3 | 109) << 1) - (i3 ^ 109)) % 128;
                byte[] bArr = $$a;
                byte b2 = (byte) (bArr[9] + 1);
                byte b3 = b2;
                Object[] objArr = new Object[1];
                f(b2, b3, b3, objArr);
                if (Class.forName((String) objArr[0]).getField(ScreenShotAnalyticsMapper.capturedErrorCodes).getBoolean(null)) {
                    int i4 = c;
                    int i5 = i4 | 79;
                    int i6 = (i5 << 1) - ((~(i4 & 79)) & i5);
                    e = i6 % 128;
                    if (i6 % 2 == 0) {
                        return;
                    } else {
                        i2 = 19;
                    }
                } else {
                    byte b4 = (byte) (bArr[9] + 1);
                    byte b5 = b4;
                    Object[] objArr2 = new Object[1];
                    f(b4, b5, b5, objArr2);
                    Class.forName((String) objArr2[0]).getField(ScreenShotAnalyticsMapper.capturedErrorCodes).setBoolean(null, true);
                    c = (e + 115) % 128;
                    try {
                        byte b6 = (byte) (-bArr[9]);
                        byte b7 = b6;
                        Object[] objArr3 = new Object[1];
                        f(b6, b7, (byte) (b7 - 1), objArr3);
                        Constructor<?> declaredConstructor = Class.forName((String) objArr3[0]).getDeclaredConstructor(null);
                        declaredConstructor.setAccessible(true);
                        Object[] objArr4 = {declaredConstructor.newInstance(null)};
                        Method method = dj.class.getMethod("a", Runnable.class);
                        method.setAccessible(true);
                        method.invoke(null, objArr4);
                        int i7 = e + 103;
                        c = i7 % 128;
                        if (i7 % 2 != 0) {
                            return;
                        } else {
                            i2 = 68;
                        }
                    } catch (Throwable th) {
                        Throwable cause = th.getCause();
                        if (cause == null) {
                            throw th;
                        }
                        throw cause;
                    }
                }
                int i8 = i2 / 0;
            }

            /* JADX WARN: Removed duplicated region for block: B:10:0x002a  */
            /* JADX WARN: Removed duplicated region for block: B:8:0x0022  */
            /* JADX WARN: Unsupported multi-entry loop pattern (BACK_EDGE: B:10:0x002a -> B:11:0x0031). Please report as a decompilation issue!!! */
            /*
                Code decompiled incorrectly, please refer to instructions dump.
                To view partially-correct code enable 'Show inconsistent code' option in preferences
            */
            private static void f(short r6, int r7, short r8, java.lang.Object[] r9) {
                /*
                    int r8 = r8 * 3
                    int r8 = r8 + 99
                    int r6 = r6 * 17
                    int r6 = r6 + 4
                    byte[] r0 = com.facetec.sdk.gn.AnonymousClass33.$$a
                    int r7 = r7 * 2
                    int r1 = r7 + 18
                    byte[] r1 = new byte[r1]
                    int r7 = r7 + 17
                    r2 = 0
                    if (r0 != 0) goto L1a
                    r3 = r0
                    r4 = r2
                    r0 = r8
                    r8 = r6
                    goto L31
                L1a:
                    r3 = r2
                L1b:
                    byte r4 = (byte) r8
                    r1[r3] = r4
                    int r4 = r3 + 1
                    if (r3 != r7) goto L2a
                    java.lang.String r6 = new java.lang.String
                    r6.<init>(r1, r2)
                    r9[r2] = r6
                    return
                L2a:
                    r3 = r0[r6]
                    r5 = r8
                    r8 = r6
                    r6 = r3
                    r3 = r0
                    r0 = r5
                L31:
                    int r0 = r0 + r6
                    int r6 = r8 + 1
                    int r8 = r0 + 3
                    r0 = r3
                    r3 = r4
                    goto L1b
                */
                throw new UnsupportedOperationException("Method not decompiled: com.facetec.sdk.gn.AnonymousClass33.f(short, int, short, java.lang.Object[]):void");
            }

            public static void init$0() {
                $$a = new byte[]{4, ISO7816.INS_READ_BINARY, 45, 109, 9, -5, -66, 53, -8, -1, -1, PassportService.SFI_DG12, -18, -5, -56, CVCAFile.CAR_TAG, -18, 4, ISO7816.INS_GET_RESPONSE, ISO7816.INS_INCREASE, -4, 9, -5, -66, 53, -8, -1, -1, PassportService.SFI_DG12, -18, -5, -56, CVCAFile.CAR_TAG, -18, 4, ISO7816.INS_GET_RESPONSE, ISO7816.INS_INCREASE, -4, -65, PassportService.SFI_DG12};
                $$b = 78;
            }

            @Override // com.facetec.sdk.fg
            public final /* synthetic */ Number a(gs gsVar) {
                return e(gsVar);
            }

            @Override // com.facetec.sdk.fg
            public final /* synthetic */ void e(ha haVar, Number number) {
                if (number == null) {
                    haVar.g();
                } else {
                    haVar.d(r4.shortValue());
                }
            }

            private static Number e(gs gsVar) {
                if (gsVar.j() == gw.NULL) {
                    gsVar.m();
                    return null;
                }
                try {
                    int iK = gsVar.k();
                    if (iK <= 65535 && iK >= -32768) {
                        return Short.valueOf((short) iK);
                    }
                    StringBuilder sb = new StringBuilder("Lossy conversion from ");
                    sb.append(iK);
                    sb.append(" to short; at path ");
                    sb.append(gsVar.q());
                    throw new fc(sb.toString());
                } catch (NumberFormatException e2) {
                    throw new fc(e2);
                }
            }
        };
        E = fgVar2;
        i = d(Short.TYPE, Short.class, fgVar2);
        fg<Number> fgVar3 = new fg<Number>() { // from class: com.facetec.sdk.gn.35
            private static final byte[] $$a = null;
            private static final int $$b = 0;
            private static int a;
            private static int d;

            static {
                init$0();
                a = 0;
                d = 1;
            }

            /* JADX WARN: Removed duplicated region for block: B:10:0x0027  */
            /* JADX WARN: Removed duplicated region for block: B:8:0x001f  */
            /* JADX WARN: Unsupported multi-entry loop pattern (BACK_EDGE: B:10:0x0027 -> B:11:0x0030). Please report as a decompilation issue!!! */
            /*
                Code decompiled incorrectly, please refer to instructions dump.
                To view partially-correct code enable 'Show inconsistent code' option in preferences
            */
            private static void c(short r6, byte r7, short r8, java.lang.Object[] r9) {
                /*
                    int r6 = r6 * 2
                    int r6 = 101 - r6
                    int r7 = r7 * 17
                    int r0 = r7 + 1
                    byte[] r1 = com.facetec.sdk.gn.AnonymousClass35.$$a
                    int r8 = r8 * 17
                    int r8 = 20 - r8
                    byte[] r0 = new byte[r0]
                    r2 = 0
                    if (r1 != 0) goto L17
                    r3 = r1
                    r4 = r2
                    r1 = r8
                    goto L30
                L17:
                    r3 = r2
                L18:
                    int r8 = r8 + 1
                    byte r4 = (byte) r6
                    r0[r3] = r4
                    if (r3 != r7) goto L27
                    java.lang.String r6 = new java.lang.String
                    r6.<init>(r0, r2)
                    r9[r2] = r6
                    return
                L27:
                    int r3 = r3 + 1
                    r4 = r1[r8]
                    r5 = r1
                    r1 = r8
                    r8 = r4
                    r4 = r3
                    r3 = r5
                L30:
                    int r8 = -r8
                    int r6 = r6 + r8
                    int r6 = r6 + 3
                    r8 = r1
                    r1 = r3
                    r3 = r4
                    goto L18
                */
                throw new UnsupportedOperationException("Method not decompiled: com.facetec.sdk.gn.AnonymousClass35.c(short, byte, short, java.lang.Object[]):void");
            }

            public static void init$0() {
                $$a = new byte[]{109, 5, -57, 108, -9, 5, CVCAFile.CAR_TAG, -53, 8, 1, 1, -12, 18, 5, 56, -66, 18, -4, 64, -50, 4};
                $$b = EnumC41897g.SDK_ASSET_ILLUSTRATION_PLAID_OVERLAY_BALANCE_BEAM_02_VALUE;
            }

            @Override // com.facetec.sdk.fg
            public final /* synthetic */ Number a(gs gsVar) {
                return e(gsVar);
            }

            @Override // com.facetec.sdk.fg
            public final /* synthetic */ void e(ha haVar, Number number) {
                if (number == null) {
                    haVar.g();
                } else {
                    haVar.d(r4.intValue());
                }
            }

            public static void a(Context context, long j2, long j3) throws Throwable {
                int i2 = a;
                int i3 = ((((i2 | 66) << 1) - (i2 ^ 66)) - 1) % 128;
                d = i3;
                if (context == null) {
                    int i4 = i3 & 73;
                    int i5 = -(-((i3 ^ 73) | i4));
                    a = (((i4 | i5) << 1) - (i4 ^ i5)) % 128;
                    return;
                }
                Object obj = cb.a.class.getField("i").get(null);
                d = (a + 9) % 128;
                try {
                    Object[] objArr = {context, obj};
                    byte[] bArr = $$a;
                    byte b2 = bArr[9];
                    byte b3 = b2;
                    Object[] objArr2 = new Object[1];
                    c(b2, b3, b3, objArr2);
                    Class<?> cls = Class.forName((String) objArr2[0]);
                    byte b4 = (byte) (bArr[9] - 1);
                    byte b5 = b4;
                    Object[] objArr3 = new Object[1];
                    c(b4, b5, b5, objArr3);
                    Method method = cls.getMethod((String) objArr3[0], Context.class, cb.a.class);
                    method.setAccessible(true);
                    method.invoke(null, objArr);
                    int i6 = a;
                    int i7 = (i6 & 7) + (i6 | 7);
                    d = i7 % 128;
                    if (i7 % 2 == 0) {
                        int i8 = 18 / 0;
                    }
                } catch (Throwable th) {
                    Throwable cause = th.getCause();
                    if (cause == null) {
                        throw th;
                    }
                    throw cause;
                }
            }

            private static Number e(gs gsVar) {
                if (gsVar.j() == gw.NULL) {
                    gsVar.m();
                    return null;
                }
                try {
                    return Integer.valueOf(gsVar.k());
                } catch (NumberFormatException e2) {
                    throw new fc(e2);
                }
            }
        };
        K = fgVar3;
        f = d(Integer.TYPE, Integer.class, fgVar3);
        fg<AtomicInteger> fgVarB3 = new fg<AtomicInteger>() { // from class: com.facetec.sdk.gn.31
            private static AtomicInteger c(gs gsVar) {
                try {
                    return new AtomicInteger(gsVar.k());
                } catch (NumberFormatException e2) {
                    throw new fc(e2);
                }
            }

            @Override // com.facetec.sdk.fg
            public final /* synthetic */ AtomicInteger a(gs gsVar) {
                return c(gsVar);
            }

            @Override // com.facetec.sdk.fg
            public final /* synthetic */ void e(ha haVar, AtomicInteger atomicInteger) {
                haVar.d(atomicInteger.get());
            }
        }.b();
        N = fgVarB3;
        h = b(AtomicInteger.class, fgVarB3);
        fg<AtomicBoolean> fgVarB4 = new fg<AtomicBoolean>() { // from class: com.facetec.sdk.gn.32
            @Override // com.facetec.sdk.fg
            public final /* synthetic */ AtomicBoolean a(gs gsVar) {
                return new AtomicBoolean(gsVar.f());
            }

            @Override // com.facetec.sdk.fg
            public final /* synthetic */ void e(ha haVar, AtomicBoolean atomicBoolean) {
                haVar.b(atomicBoolean.get());
            }
        }.b();
        L = fgVarB4;
        j = b(AtomicBoolean.class, fgVarB4);
        fg<AtomicIntegerArray> fgVarB5 = new fg<AtomicIntegerArray>() { // from class: com.facetec.sdk.gn.2
            private static AtomicIntegerArray d(gs gsVar) {
                ArrayList arrayList = new ArrayList();
                gsVar.c();
                while (gsVar.b()) {
                    try {
                        arrayList.add(Integer.valueOf(gsVar.k()));
                    } catch (NumberFormatException e2) {
                        throw new fc(e2);
                    }
                }
                gsVar.e();
                int size = arrayList.size();
                AtomicIntegerArray atomicIntegerArray = new AtomicIntegerArray(size);
                for (int i2 = 0; i2 < size; i2++) {
                    atomicIntegerArray.set(i2, ((Integer) arrayList.get(i2)).intValue());
                }
                return atomicIntegerArray;
            }

            @Override // com.facetec.sdk.fg
            public final /* synthetic */ AtomicIntegerArray a(gs gsVar) {
                return d(gsVar);
            }

            @Override // com.facetec.sdk.fg
            public final /* bridge */ /* synthetic */ void e(ha haVar, AtomicIntegerArray atomicIntegerArray) {
                haVar.e();
                int length = atomicIntegerArray.length();
                for (int i2 = 0; i2 < length; i2++) {
                    haVar.d(r6.get(i2));
                }
                haVar.a();
            }
        }.b();
        M = fgVarB5;
        f95895g = b(AtomicIntegerArray.class, fgVarB5);
        o = new fg<Number>() { // from class: com.facetec.sdk.gn.5
            @Override // com.facetec.sdk.fg
            public final /* synthetic */ Number a(gs gsVar) {
                return e(gsVar);
            }

            @Override // com.facetec.sdk.fg
            public final /* synthetic */ void e(ha haVar, Number number) {
                Number number2 = number;
                if (number2 == null) {
                    haVar.g();
                } else {
                    haVar.d(number2.longValue());
                }
            }

            private static Number e(gs gsVar) {
                if (gsVar.j() == gw.NULL) {
                    gsVar.m();
                    return null;
                }
                try {
                    return Long.valueOf(gsVar.n());
                } catch (NumberFormatException e2) {
                    throw new fc(e2);
                }
            }
        };
        m = new fg<Number>() { // from class: com.facetec.sdk.gn.1
            @Override // com.facetec.sdk.fg
            public final /* synthetic */ Number a(gs gsVar) {
                if (gsVar.j() != gw.NULL) {
                    return Float.valueOf((float) gsVar.o());
                }
                gsVar.m();
                return null;
            }

            @Override // com.facetec.sdk.fg
            public final /* synthetic */ void e(ha haVar, Number number) {
                Number numberValueOf = number;
                if (numberValueOf == null) {
                    haVar.g();
                    return;
                }
                if (!(numberValueOf instanceof Float)) {
                    numberValueOf = Float.valueOf(numberValueOf.floatValue());
                }
                haVar.b(numberValueOf);
            }
        };
        k = new AnonymousClass4();
        fg<Character> fgVar4 = new fg<Character>() { // from class: com.facetec.sdk.gn.7
            @Override // com.facetec.sdk.fg
            public final /* synthetic */ Character a(gs gsVar) {
                if (gsVar.j() == gw.NULL) {
                    gsVar.m();
                    return null;
                }
                String strH = gsVar.h();
                if (strH.length() == 1) {
                    return Character.valueOf(strH.charAt(0));
                }
                StringBuilder sb = new StringBuilder("Expecting character, got: ");
                sb.append(strH);
                sb.append("; at ");
                sb.append(gsVar.q());
                throw new fc(sb.toString());
            }

            @Override // com.facetec.sdk.fg
            public final /* bridge */ /* synthetic */ void e(ha haVar, Character ch) {
                Character ch2 = ch;
                haVar.e(ch2 == null ? null : String.valueOf(ch2));
            }
        };
        J = fgVar4;
        n = d(Character.TYPE, Character.class, fgVar4);
        O = new fg<String>() { // from class: com.facetec.sdk.gn.6
            @Override // com.facetec.sdk.fg
            public final /* synthetic */ String a(gs gsVar) {
                gw gwVarJ = gsVar.j();
                if (gwVarJ != gw.NULL) {
                    return gwVarJ == gw.BOOLEAN ? Boolean.toString(gsVar.f()) : gsVar.h();
                }
                gsVar.m();
                return null;
            }

            @Override // com.facetec.sdk.fg
            public final /* bridge */ /* synthetic */ void e(ha haVar, String str) {
                haVar.e(str);
            }
        };
        l = new fg<BigDecimal>() { // from class: com.facetec.sdk.gn.10
            private static BigDecimal c(gs gsVar) {
                if (gsVar.j() == gw.NULL) {
                    gsVar.m();
                    return null;
                }
                String strH = gsVar.h();
                try {
                    return new BigDecimal(strH);
                } catch (NumberFormatException e2) {
                    StringBuilder sb = new StringBuilder("Failed parsing '");
                    sb.append(strH);
                    sb.append("' as BigDecimal; at path ");
                    sb.append(gsVar.q());
                    throw new fc(sb.toString(), e2);
                }
            }

            @Override // com.facetec.sdk.fg
            public final /* synthetic */ BigDecimal a(gs gsVar) {
                return c(gsVar);
            }

            @Override // com.facetec.sdk.fg
            public final /* synthetic */ void e(ha haVar, BigDecimal bigDecimal) {
                haVar.b(bigDecimal);
            }
        };
        q = new fg<BigInteger>() { // from class: com.facetec.sdk.gn.9
            private static BigInteger b(gs gsVar) {
                if (gsVar.j() == gw.NULL) {
                    gsVar.m();
                    return null;
                }
                String strH = gsVar.h();
                try {
                    return new BigInteger(strH);
                } catch (NumberFormatException e2) {
                    StringBuilder sb = new StringBuilder("Failed parsing '");
                    sb.append(strH);
                    sb.append("' as BigInteger; at path ");
                    sb.append(gsVar.q());
                    throw new fc(sb.toString(), e2);
                }
            }

            @Override // com.facetec.sdk.fg
            public final /* synthetic */ BigInteger a(gs gsVar) {
                return b(gsVar);
            }

            @Override // com.facetec.sdk.fg
            public final /* synthetic */ void e(ha haVar, BigInteger bigInteger) {
                haVar.b(bigInteger);
            }
        };
        t = new AnonymousClass8();
        p = b(String.class, O);
        fg<StringBuilder> fgVar5 = new fg<StringBuilder>() { // from class: com.facetec.sdk.gn.14
            private static final byte[] $$a = null;
            private static final int $$b = 0;
            private static int b;
            private static int e;

            static {
                init$0();
                b = 0;
                e = 1;
            }

            /* JADX WARN: Removed duplicated region for block: B:10:0x0029  */
            /* JADX WARN: Removed duplicated region for block: B:8:0x0021  */
            /* JADX WARN: Unsupported multi-entry loop pattern (BACK_EDGE: B:10:0x0029 -> B:11:0x002b). Please report as a decompilation issue!!! */
            /*
                Code decompiled incorrectly, please refer to instructions dump.
                To view partially-correct code enable 'Show inconsistent code' option in preferences
            */
            private static void c(short r6, short r7, byte r8, java.lang.Object[] r9) {
                /*
                    byte[] r0 = com.facetec.sdk.gn.AnonymousClass14.$$a
                    int r6 = r6 * 17
                    int r6 = 18 - r6
                    int r8 = r8 * 17
                    int r8 = 20 - r8
                    int r7 = r7 * 2
                    int r7 = r7 + 99
                    byte[] r1 = new byte[r6]
                    r2 = 0
                    if (r0 != 0) goto L17
                    r3 = r7
                    r5 = r2
                    r7 = r6
                    goto L2b
                L17:
                    r3 = r2
                L18:
                    int r8 = r8 + 1
                    byte r4 = (byte) r7
                    int r5 = r3 + 1
                    r1[r3] = r4
                    if (r5 != r6) goto L29
                    java.lang.String r6 = new java.lang.String
                    r6.<init>(r1, r2)
                    r9[r2] = r6
                    return
                L29:
                    r3 = r0[r8]
                L2b:
                    int r7 = r7 + r3
                    int r7 = r7 + 3
                    r3 = r5
                    goto L18
                */
                throw new UnsupportedOperationException("Method not decompiled: com.facetec.sdk.gn.AnonymousClass14.c(short, short, byte, java.lang.Object[]):void");
            }

            private static void e() throws Throwable {
                int i2 = e;
                int i3 = i2 & 65;
                int i4 = (i2 ^ 65) | i3;
                b = (((i3 | i4) << 1) - (i4 ^ i3)) % 128;
                Object obj = cb.a.class.getField("a").get(null);
                int i5 = e;
                b = ((((i5 & (-28)) | ((~i5) & 27)) - (~((i5 & 27) << 1))) - 1) % 128;
                int i6 = (i5 | 81) << 1;
                int i7 = -(i5 ^ 81);
                b = (((i6 | i7) << 1) - (i7 ^ i6)) % 128;
                try {
                    byte[] bArr = $$a;
                    byte b2 = bArr[9];
                    byte b3 = (byte) (b2 + 1);
                    Object[] objArr = new Object[1];
                    c(b3, b3, (byte) (-b2), objArr);
                    Class<?> cls = Class.forName((String) objArr[0]);
                    byte b4 = (byte) (-bArr[9]);
                    byte b5 = b4;
                    Object[] objArr2 = new Object[1];
                    c(b4, b5, (byte) (b5 - 1), objArr2);
                    Method method = cls.getMethod((String) objArr2[0], Context.class, cb.a.class);
                    method.setAccessible(true);
                    method.invoke(null, null, obj);
                    int i8 = b + 74;
                    int i9 = (i8 ^ (-1)) + (i8 << 1);
                    e = i9 % 128;
                    if (i9 % 2 == 0) {
                        int i10 = 11 / 0;
                    }
                } catch (Throwable th) {
                    Throwable cause = th.getCause();
                    if (cause == null) {
                        throw th;
                    }
                    throw cause;
                }
            }

            public static void init$0() {
                $$a = new byte[]{105, ISOFileInfo.A5, ISOFileInfo.ENV_TEMP_EF, 31, 9, -5, -66, 53, -8, -1, -1, PassportService.SFI_DG12, -18, -5, -56, CVCAFile.CAR_TAG, -18, 4, ISO7816.INS_GET_RESPONSE, ISO7816.INS_INCREASE, -4};
                $$b = 24;
            }

            @Override // com.facetec.sdk.fg
            public final /* synthetic */ StringBuilder a(gs gsVar) {
                if (gsVar.j() != gw.NULL) {
                    return new StringBuilder(gsVar.h());
                }
                gsVar.m();
                return null;
            }

            @Override // com.facetec.sdk.fg
            public final /* bridge */ /* synthetic */ void e(ha haVar, StringBuilder sb) {
                StringBuilder sb2 = sb;
                haVar.e(sb2 == null ? null : sb2.toString());
            }
        };
        P = fgVar5;
        s = b(StringBuilder.class, fgVar5);
        fg<StringBuffer> fgVar6 = new fg<StringBuffer>() { // from class: com.facetec.sdk.gn.12
            @Override // com.facetec.sdk.fg
            public final /* synthetic */ StringBuffer a(gs gsVar) {
                if (gsVar.j() != gw.NULL) {
                    return new StringBuffer(gsVar.h());
                }
                gsVar.m();
                return null;
            }

            @Override // com.facetec.sdk.fg
            public final /* bridge */ /* synthetic */ void e(ha haVar, StringBuffer stringBuffer) {
                StringBuffer stringBuffer2 = stringBuffer;
                haVar.e(stringBuffer2 == null ? null : stringBuffer2.toString());
            }
        };
        S = fgVar6;
        r = b(StringBuffer.class, fgVar6);
        fg<URL> fgVar7 = new fg<URL>() { // from class: com.facetec.sdk.gn.11
            @Override // com.facetec.sdk.fg
            public final /* synthetic */ URL a(gs gsVar) {
                if (gsVar.j() == gw.NULL) {
                    gsVar.m();
                    return null;
                }
                String strH = gsVar.h();
                if (LuciqLog.LogMessage.NULL_LOG.equals(strH)) {
                    return null;
                }
                return new URL(strH);
            }

            @Override // com.facetec.sdk.fg
            public final /* bridge */ /* synthetic */ void e(ha haVar, URL url) {
                URL url2 = url;
                haVar.e(url2 == null ? null : url2.toExternalForm());
            }
        };
        R = fgVar7;
        u = b(URL.class, fgVar7);
        fg<URI> fgVar8 = new fg<URI>() { // from class: com.facetec.sdk.gn.15
            private static URI b(gs gsVar) {
                if (gsVar.j() == gw.NULL) {
                    gsVar.m();
                    return null;
                }
                try {
                    String strH = gsVar.h();
                    if (LuciqLog.LogMessage.NULL_LOG.equals(strH)) {
                        return null;
                    }
                    return new URI(strH);
                } catch (URISyntaxException e2) {
                    throw new er(e2);
                }
            }

            @Override // com.facetec.sdk.fg
            public final /* synthetic */ URI a(gs gsVar) {
                return b(gsVar);
            }

            @Override // com.facetec.sdk.fg
            public final /* bridge */ /* synthetic */ void e(ha haVar, URI uri) {
                URI uri2 = uri;
                haVar.e(uri2 == null ? null : uri2.toASCIIString());
            }
        };
        Q = fgVar8;
        y = b(URI.class, fgVar8);
        fg<InetAddress> fgVar9 = new fg<InetAddress>() { // from class: com.facetec.sdk.gn.16
            private static final byte[] $$a = null;
            private static final int $$b = 0;
            private static final byte[] $$c = null;
            private static final int $$d = 0;
            private static int $10;
            private static int $11;
            private static int b;
            private static int c;
            private static long d;

            /* JADX WARN: Removed duplicated region for block: B:10:0x0025  */
            /* JADX WARN: Removed duplicated region for block: B:8:0x001f  */
            /* JADX WARN: Unsupported multi-entry loop pattern (BACK_EDGE: B:10:0x0025 -> B:11:0x002a). Please report as a decompilation issue!!! */
            /*
                Code decompiled incorrectly, please refer to instructions dump.
                To view partially-correct code enable 'Show inconsistent code' option in preferences
            */
            private static java.lang.String $$e(byte r7, int r8, byte r9) {
                /*
                    int r9 = r9 * 3
                    int r9 = 1 - r9
                    byte[] r0 = com.facetec.sdk.gn.AnonymousClass16.$$c
                    int r8 = r8 * 2
                    int r8 = r8 + 73
                    int r7 = r7 * 4
                    int r7 = 4 - r7
                    byte[] r1 = new byte[r9]
                    r2 = 0
                    if (r0 != 0) goto L17
                    r8 = r7
                    r3 = r9
                    r4 = r2
                    goto L2a
                L17:
                    r3 = r2
                L18:
                    int r4 = r3 + 1
                    byte r5 = (byte) r8
                    r1[r3] = r5
                    if (r4 != r9) goto L25
                    java.lang.String r7 = new java.lang.String
                    r7.<init>(r1, r2)
                    return r7
                L25:
                    r3 = r0[r7]
                    r6 = r8
                    r8 = r7
                    r7 = r6
                L2a:
                    int r7 = r7 + r3
                    int r8 = r8 + 1
                    r3 = r8
                    r8 = r7
                    r7 = r3
                    r3 = r4
                    goto L18
                */
                throw new UnsupportedOperationException("Method not decompiled: com.facetec.sdk.gn.AnonymousClass16.$$e(byte, int, byte):java.lang.String");
            }

            static {
                init$1();
                $10 = 0;
                $11 = 1;
                init$0();
                c = 0;
                b = 1;
                d = 7815939866278420473L;
            }

            private static void f(String str, int i2, Object[] objArr) throws Throwable {
                $10 = ($11 + 37) % 128;
                char[] charArray = str != null ? str.toCharArray() : str;
                hl hlVar = new hl();
                char[] cArrB = hl.b(d ^ (-1723600592890876272L), charArray, i2);
                hlVar.e = 4;
                $10 = ($11 + 99) % 128;
                while (true) {
                    int i3 = hlVar.e;
                    if (i3 >= cArrB.length) {
                        objArr[0] = new String(cArrB, 4, cArrB.length - 4);
                        return;
                    }
                    $10 = ($11 + 89) % 128;
                    int i4 = i3 - 4;
                    hlVar.d = i4;
                    try {
                        Object[] objArr2 = {Long.valueOf(cArrB[i3] ^ cArrB[i3 % 4]), Long.valueOf(i4), Long.valueOf(d)};
                        Object objD = an.d(-291407824);
                        if (objD == null) {
                            int scrollBarFadeDuration = 2589 - (ViewConfiguration.getScrollBarFadeDuration() >> 16);
                            char scrollBarFadeDuration2 = (char) (ViewConfiguration.getScrollBarFadeDuration() >> 16);
                            int i5 = (SystemClock.elapsedRealtimeNanos() > 0L ? 1 : (SystemClock.elapsedRealtimeNanos() == 0L ? 0 : -1)) + 22;
                            byte b2 = (byte) 0;
                            byte b3 = b2;
                            String str$$e = $$e(b2, b3, b3);
                            Class cls = Long.TYPE;
                            objD = an.d(scrollBarFadeDuration, scrollBarFadeDuration2, i5, -1732203669, false, str$$e, new Class[]{cls, cls, cls});
                        }
                        cArrB[i3] = ((Character) ((Method) objD).invoke(null, objArr2)).charValue();
                        Object[] objArr3 = {hlVar, hlVar};
                        Object objD2 = an.d(1066529625);
                        if (objD2 == null) {
                            objD2 = an.d(TextUtils.indexOf("", "", 0, 0) + EnumC41897g.SDK_ASSET_PLAID_LOGO_LOADING_INDICATOR_SUCCESS_VALUE, (char) ((-1) - ((byte) KeyEvent.getModifierMetaStateMask())), 23 - (PointF.length(SelfieScan.RECOGNITION_FAIL_RESULT, SelfieScan.RECOGNITION_FAIL_RESULT) > SelfieScan.RECOGNITION_FAIL_RESULT ? 1 : (PointF.length(SelfieScan.RECOGNITION_FAIL_RESULT, SelfieScan.RECOGNITION_FAIL_RESULT) == SelfieScan.RECOGNITION_FAIL_RESULT ? 0 : -1)), 1240473602, false, "G", new Class[]{Object.class, Object.class});
                        }
                        ((Method) objD2).invoke(null, objArr3);
                    } catch (Throwable th) {
                        Throwable cause = th.getCause();
                        if (cause == null) {
                            throw th;
                        }
                        throw cause;
                    }
                }
            }

            /* JADX WARN: Removed duplicated region for block: B:10:0x0025  */
            /* JADX WARN: Removed duplicated region for block: B:8:0x001d  */
            /* JADX WARN: Unsupported multi-entry loop pattern (BACK_EDGE: B:10:0x0025 -> B:11:0x002c). Please report as a decompilation issue!!! */
            /*
                Code decompiled incorrectly, please refer to instructions dump.
                To view partially-correct code enable 'Show inconsistent code' option in preferences
            */
            private static void g(byte r6, byte r7, int r8, java.lang.Object[] r9) {
                /*
                    int r8 = r8 * 3
                    int r8 = r8 + 98
                    int r6 = r6 * 2
                    int r6 = 4 - r6
                    int r7 = r7 * 3
                    int r0 = r7 + 1
                    byte[] r1 = com.facetec.sdk.gn.AnonymousClass16.$$a
                    byte[] r0 = new byte[r0]
                    r2 = 0
                    if (r1 != 0) goto L17
                    r4 = r8
                    r3 = r2
                    r8 = r6
                    goto L2c
                L17:
                    r3 = r2
                L18:
                    byte r4 = (byte) r8
                    r0[r3] = r4
                    if (r3 != r7) goto L25
                    java.lang.String r6 = new java.lang.String
                    r6.<init>(r0, r2)
                    r9[r2] = r6
                    return
                L25:
                    int r3 = r3 + 1
                    r4 = r1[r6]
                    r5 = r8
                    r8 = r6
                    r6 = r5
                L2c:
                    int r6 = r6 + r4
                    int r8 = r8 + 1
                    r5 = r8
                    r8 = r6
                    r6 = r5
                    goto L18
                */
                throw new UnsupportedOperationException("Method not decompiled: com.facetec.sdk.gn.AnonymousClass16.g(byte, byte, int, java.lang.Object[]):void");
            }

            public static void init$0() {
                $$a = new byte[]{115, ISOFileInfo.FILE_IDENTIFIER, 45, -41};
                $$b = 57;
            }

            public static void init$1() {
                $$c = new byte[]{81, 99, 107, 124};
                $$d = 82;
            }

            @Override // com.facetec.sdk.fg
            public final /* synthetic */ InetAddress a(gs gsVar) {
                b = (c + 67) % 128;
                if (gsVar.j() != gw.NULL) {
                    return InetAddress.getByName(gsVar.h());
                }
                c = (b + 119) % 128;
                gsVar.m();
                return null;
            }

            /* JADX WARN: Removed duplicated region for block: B:12:0x0026  */
            /* JADX WARN: Removed duplicated region for block: B:8:0x0017  */
            @Override // com.facetec.sdk.fg
            /*
                Code decompiled incorrectly, please refer to instructions dump.
                To view partially-correct code enable 'Show inconsistent code' option in preferences
            */
            public final /* bridge */ /* synthetic */ void e(com.facetec.sdk.ha r3, java.net.InetAddress r4) {
                /*
                    r2 = this;
                    int r0 = com.facetec.sdk.gn.AnonymousClass16.b
                    int r0 = r0 + 109
                    int r1 = r0 % 128
                    com.facetec.sdk.gn.AnonymousClass16.c = r1
                    int r0 = r0 % 2
                    java.net.InetAddress r4 = (java.net.InetAddress) r4
                    if (r0 == 0) goto L15
                    r0 = 45
                    int r0 = r0 / 0
                    if (r4 != 0) goto L26
                    goto L17
                L15:
                    if (r4 != 0) goto L26
                L17:
                    int r1 = r1 + 69
                    int r4 = r1 % 128
                    com.facetec.sdk.gn.AnonymousClass16.b = r4
                    int r1 = r1 % 2
                    if (r1 != 0) goto L24
                    r4 = 7
                    int r4 = r4 / 0
                L24:
                    r4 = 0
                    goto L2a
                L26:
                    java.lang.String r4 = r4.getHostAddress()
                L2a:
                    r3.e(r4)
                    return
                */
                throw new UnsupportedOperationException("Method not decompiled: com.facetec.sdk.gn.AnonymousClass16.e(com.facetec.sdk.ha, java.lang.Object):void");
            }

            /*  JADX ERROR: NoSuchElementException in pass: ReplaceNewArray
                java.util.NoSuchElementException
                	at java.base/java.util.TreeMap.key(TreeMap.java:1637)
                	at java.base/java.util.TreeMap.lastKey(TreeMap.java:309)
                	at jadx.core.dex.visitors.ReplaceNewArray.processNewArray(ReplaceNewArray.java:171)
                	at jadx.core.dex.visitors.ReplaceNewArray.processInsn(ReplaceNewArray.java:72)
                	at jadx.core.dex.visitors.ReplaceNewArray.visit(ReplaceNewArray.java:53)
                */
            public static java.lang.Object[] e(int r30, int r31) {
                /*
                    Method dump skipped, instruction units count: 1427
                    To view this dump change 'Code comments level' option to 'DEBUG'
                */
                throw new UnsupportedOperationException("Method not decompiled: com.facetec.sdk.gn.AnonymousClass16.e(int, int):java.lang.Object[]");
            }
        };
        U = fgVar9;
        v = a(InetAddress.class, fgVar9);
        fg<UUID> fgVar10 = new fg<UUID>() { // from class: com.facetec.sdk.gn.17
            @Override // com.facetec.sdk.fg
            public final /* synthetic */ UUID a(gs gsVar) {
                return e(gsVar);
            }

            @Override // com.facetec.sdk.fg
            public final /* bridge */ /* synthetic */ void e(ha haVar, UUID uuid) {
                UUID uuid2 = uuid;
                haVar.e(uuid2 == null ? null : uuid2.toString());
            }

            private static UUID e(gs gsVar) {
                if (gsVar.j() == gw.NULL) {
                    gsVar.m();
                    return null;
                }
                String strH = gsVar.h();
                try {
                    return UUID.fromString(strH);
                } catch (IllegalArgumentException e2) {
                    StringBuilder sb = new StringBuilder("Failed parsing '");
                    sb.append(strH);
                    sb.append("' as UUID; at path ");
                    sb.append(gsVar.q());
                    throw new fc(sb.toString(), e2);
                }
            }
        };
        T = fgVar10;
        x = b(UUID.class, fgVar10);
        fg<Currency> fgVarB6 = new AnonymousClass18().b();
        X = fgVarB6;
        w = b(Currency.class, fgVarB6);
        final AnonymousClass20 anonymousClass20 = new AnonymousClass20();
        V = anonymousClass20;
        final Class<Calendar> cls = Calendar.class;
        final Class<GregorianCalendar> cls2 = GregorianCalendar.class;
        A = new ff() { // from class: com.facetec.sdk.gn.30
            @Override // com.facetec.sdk.ff
            public final <T> fg<T> b(el elVar, gu<T> guVar) {
                Class<? super T> clsD = guVar.d();
                if (clsD == cls || clsD == cls2) {
                    return anonymousClass20;
                }
                return null;
            }

            public final String toString() {
                StringBuilder sb = new StringBuilder("Factory[type=");
                sb.append(cls.getName());
                sb.append("+");
                sb.append(cls2.getName());
                sb.append(",adapter=");
                sb.append(anonymousClass20);
                sb.append("]");
                return sb.toString();
            }
        };
        fg<Locale> fgVar11 = new fg<Locale>() { // from class: com.facetec.sdk.gn.19
            @Override // com.facetec.sdk.fg
            public final /* synthetic */ Locale a(gs gsVar) {
                if (gsVar.j() == gw.NULL) {
                    gsVar.m();
                    return null;
                }
                StringTokenizer stringTokenizer = new StringTokenizer(gsVar.h(), "_");
                String strNextToken = stringTokenizer.hasMoreElements() ? stringTokenizer.nextToken() : null;
                String strNextToken2 = stringTokenizer.hasMoreElements() ? stringTokenizer.nextToken() : null;
                String strNextToken3 = stringTokenizer.hasMoreElements() ? stringTokenizer.nextToken() : null;
                return (strNextToken2 == null && strNextToken3 == null) ? new Locale(strNextToken) : strNextToken3 == null ? new Locale(strNextToken, strNextToken2) : new Locale(strNextToken, strNextToken2, strNextToken3);
            }

            @Override // com.facetec.sdk.fg
            public final /* bridge */ /* synthetic */ void e(ha haVar, Locale locale) {
                Locale locale2 = locale;
                haVar.e(locale2 == null ? null : locale2.toString());
            }
        };
        W = fgVar11;
        C = b(Locale.class, fgVar11);
        AnonymousClass22 anonymousClass22 = new AnonymousClass22();
        z = anonymousClass22;
        B = a(es.class, anonymousClass22);
        D = new ff() { // from class: com.facetec.sdk.gn.21
            public static int c;
            public static int d;

            @Override // com.facetec.sdk.ff
            public final <T> fg<T> b(el elVar, gu<T> guVar) {
                Class<? super T> clsD = guVar.d();
                if (!Enum.class.isAssignableFrom(clsD) || clsD == Enum.class) {
                    return null;
                }
                if (!clsD.isEnum()) {
                    clsD = clsD.getSuperclass();
                }
                return new c(clsD);
            }

            public static int b() {
                int i2 = c;
                int i3 = i2 % 8974578;
                c = i2 + 1;
                if (i3 != 0) {
                    return d;
                }
                int iMyUid = Process.myUid();
                d = iMyUid;
                return iMyUid;
            }
        };
    }

    private static <T1> ff a(Class<T1> cls, fg<T1> fgVar) {
        return new AnonymousClass28(cls, fgVar);
    }

    public static <TT> ff b(final Class<TT> cls, final fg<TT> fgVar) {
        return new ff() { // from class: com.facetec.sdk.gn.23
            @Override // com.facetec.sdk.ff
            public final <T> fg<T> b(el elVar, gu<T> guVar) {
                if (guVar.d() == cls) {
                    return fgVar;
                }
                return null;
            }

            public final String toString() {
                StringBuilder sb = new StringBuilder("Factory[type=");
                sb.append(cls.getName());
                sb.append(",adapter=");
                sb.append(fgVar);
                sb.append("]");
                return sb.toString();
            }
        };
    }

    public static <TT> ff d(final Class<TT> cls, final Class<TT> cls2, final fg<? super TT> fgVar) {
        return new ff() { // from class: com.facetec.sdk.gn.25
            @Override // com.facetec.sdk.ff
            public final <T> fg<T> b(el elVar, gu<T> guVar) {
                Class<? super T> clsD = guVar.d();
                if (clsD == cls || clsD == cls2) {
                    return fgVar;
                }
                return null;
            }

            public final String toString() {
                StringBuilder sb = new StringBuilder("Factory[type=");
                sb.append(cls2.getName());
                sb.append("+");
                sb.append(cls.getName());
                sb.append(",adapter=");
                sb.append(fgVar);
                sb.append("]");
                return sb.toString();
            }
        };
    }

    /* JADX INFO: renamed from: com.facetec.sdk.gn$24, reason: invalid class name */
    public class AnonymousClass24 extends fg<Boolean> {
        public static int b;
        public static int d;

        @Override // com.facetec.sdk.fg
        public final /* synthetic */ Boolean a(gs gsVar) {
            gw gwVarJ = gsVar.j();
            if (gwVarJ != gw.NULL) {
                return gwVarJ == gw.STRING ? Boolean.valueOf(Boolean.parseBoolean(gsVar.h())) : Boolean.valueOf(gsVar.f());
            }
            gsVar.m();
            return null;
        }

        @Override // com.facetec.sdk.fg
        public final /* bridge */ /* synthetic */ void e(ha haVar, Boolean bool) {
            haVar.e(bool);
        }

        public static int e() {
            int i = d;
            int i2 = i % 9531042;
            d = i + 1;
            if (i2 != 0) {
                return b;
            }
            int iNextInt = new Random().nextInt();
            b = iNextInt;
            return iNextInt;
        }
    }

    /* JADX INFO: renamed from: com.facetec.sdk.gn$8, reason: invalid class name */
    public class AnonymousClass8 extends fg<fp> {
        public static int a;
        public static int e;

        @Override // com.facetec.sdk.fg
        public final /* synthetic */ fp a(gs gsVar) {
            if (gsVar.j() != gw.NULL) {
                return new fp(gsVar.h());
            }
            gsVar.m();
            return null;
        }

        @Override // com.facetec.sdk.fg
        public final /* synthetic */ void e(ha haVar, fp fpVar) {
            haVar.b(fpVar);
        }

        public static int e() {
            int i = e;
            int i2 = i % 7337734;
            e = i + 1;
            if (i2 != 0) {
                return a;
            }
            int elapsedCpuTime = (int) Process.getElapsedCpuTime();
            a = elapsedCpuTime;
            return elapsedCpuTime;
        }
    }

    /* JADX INFO: renamed from: com.facetec.sdk.gn$29, reason: invalid class name */
    public class AnonymousClass29 extends fg<Boolean> {
        public static int a;
        public static int d;

        @Override // com.facetec.sdk.fg
        public final /* synthetic */ Boolean a(gs gsVar) {
            if (gsVar.j() != gw.NULL) {
                return Boolean.valueOf(gsVar.h());
            }
            gsVar.m();
            return null;
        }

        @Override // com.facetec.sdk.fg
        public final /* bridge */ /* synthetic */ void e(ha haVar, Boolean bool) {
            Boolean bool2 = bool;
            haVar.e(bool2 == null ? LuciqLog.LogMessage.NULL_LOG : bool2.toString());
        }

        public static int a() {
            int i = a;
            int i2 = i % 5746686;
            a = i + 1;
            if (i2 != 0) {
                return d;
            }
            int iNextInt = new Random().nextInt();
            d = iNextInt;
            return iNextInt;
        }
    }

    /* JADX INFO: renamed from: com.facetec.sdk.gn$20, reason: invalid class name */
    public class AnonymousClass20 extends fg<Calendar> {
        public static int a;
        public static int c;

        @Override // com.facetec.sdk.fg
        public final /* bridge */ /* synthetic */ Calendar a(gs gsVar) {
            if (gsVar.j() == gw.NULL) {
                gsVar.m();
                return null;
            }
            gsVar.d();
            int i = 0;
            int i2 = 0;
            int i3 = 0;
            int i4 = 0;
            int i5 = 0;
            int i6 = 0;
            while (gsVar.j() != gw.END_OBJECT) {
                String strG = gsVar.g();
                int iK = gsVar.k();
                if ("year".equals(strG)) {
                    i = iK;
                } else if ("month".equals(strG)) {
                    i2 = iK;
                } else if ("dayOfMonth".equals(strG)) {
                    i3 = iK;
                } else if ("hourOfDay".equals(strG)) {
                    i4 = iK;
                } else if (MetricsUnit.Duration.MINUTE.equals(strG)) {
                    i5 = iK;
                } else if (MetricsUnit.Duration.SECOND.equals(strG)) {
                    i6 = iK;
                }
            }
            gsVar.a();
            return new GregorianCalendar(i, i2, i3, i4, i5, i6);
        }

        @Override // com.facetec.sdk.fg
        public final /* synthetic */ void e(ha haVar, Calendar calendar) {
            if (calendar == null) {
                haVar.g();
                return;
            }
            haVar.c();
            haVar.c("year");
            haVar.d(r4.get(1));
            haVar.c("month");
            haVar.d(r4.get(2));
            haVar.c("dayOfMonth");
            haVar.d(r4.get(5));
            haVar.c("hourOfDay");
            haVar.d(r4.get(11));
            haVar.c(MetricsUnit.Duration.MINUTE);
            haVar.d(r4.get(12));
            haVar.c(MetricsUnit.Duration.SECOND);
            haVar.d(r4.get(13));
            haVar.b();
        }

        public static int a() {
            int i = c;
            int i2 = i % 7287474;
            c = i + 1;
            if (i2 != 0) {
                return a;
            }
            int iUptimeMillis = (int) SystemClock.uptimeMillis();
            a = iUptimeMillis;
            return iUptimeMillis;
        }
    }
}