package com.facetec.sdk;

import java.lang.reflect.AccessibleObject;
import java.lang.reflect.Constructor;
import java.lang.reflect.Field;
import java.lang.reflect.Method;

/* JADX INFO: loaded from: classes4.dex */
public final class go {
    private static final c a;

    public static class b extends c {
        private b() {
            super((byte) 0);
        }

        @Override // com.facetec.sdk.go.c
        public final <T> Constructor<T> a(Class<T> cls) {
            throw new UnsupportedOperationException("Records are not supported on this JVM, this method should not be called");
        }

        @Override // com.facetec.sdk.go.c
        public final String[] c(Class<?> cls) {
            throw new UnsupportedOperationException("Records are not supported on this JVM, this method should not be called");
        }

        @Override // com.facetec.sdk.go.c
        public final boolean d(Class<?> cls) {
            return false;
        }

        public /* synthetic */ b(byte b) {
            this();
        }

        @Override // com.facetec.sdk.go.c
        public final Method c(Class<?> cls, Field field) {
            throw new UnsupportedOperationException("Records are not supported on this JVM, this method should not be called");
        }
    }

    public static abstract class c {
        private c() {
        }

        public abstract <T> Constructor<T> a(Class<T> cls);

        public abstract Method c(Class<?> cls, Field field);

        public abstract String[] c(Class<?> cls);

        public abstract boolean d(Class<?> cls);

        public /* synthetic */ c(byte b) {
            this();
        }
    }

    public static class d extends c {
        private final Method a;
        private final Method c;
        private final Method d;
        private final Method e;

        public /* synthetic */ d(byte b) {
            this();
        }

        @Override // com.facetec.sdk.go.c
        public final <T> Constructor<T> a(Class<T> cls) {
            try {
                Object[] objArr = (Object[]) this.e.invoke(cls, null);
                Class<?>[] clsArr = new Class[objArr.length];
                for (int i = 0; i < objArr.length; i++) {
                    clsArr[i] = (Class) this.a.invoke(objArr[i], null);
                }
                return cls.getDeclaredConstructor(clsArr);
            } catch (ReflectiveOperationException e) {
                throw go.d(e);
            }
        }

        @Override // com.facetec.sdk.go.c
        public final String[] c(Class<?> cls) {
            try {
                Object[] objArr = (Object[]) this.e.invoke(cls, null);
                String[] strArr = new String[objArr.length];
                for (int i = 0; i < objArr.length; i++) {
                    strArr[i] = (String) this.d.invoke(objArr[i], null);
                }
                return strArr;
            } catch (ReflectiveOperationException e) {
                throw go.d(e);
            }
        }

        @Override // com.facetec.sdk.go.c
        public final boolean d(Class<?> cls) {
            try {
                return ((Boolean) this.c.invoke(cls, null)).booleanValue();
            } catch (ReflectiveOperationException e) {
                throw go.d(e);
            }
        }

        private d() throws NoSuchMethodException {
            super((byte) 0);
            this.c = Class.class.getMethod("isRecord", null);
            Method method = Class.class.getMethod("getRecordComponents", null);
            this.e = method;
            Class<?> componentType = method.getReturnType().getComponentType();
            this.d = componentType.getMethod("getName", null);
            this.a = componentType.getMethod("getType", null);
        }

        @Override // com.facetec.sdk.go.c
        public final Method c(Class<?> cls, Field field) {
            try {
                return cls.getMethod(field.getName(), null);
            } catch (ReflectiveOperationException e) {
                throw go.d(e);
            }
        }
    }

    static {
        c bVar;
        byte b2 = 0;
        try {
            bVar = new d(b2);
        } catch (NoSuchMethodException unused) {
            bVar = new b(b2);
        }
        a = bVar;
    }

    public static <T> Constructor<T> b(Class<T> cls) {
        return a.a(cls);
    }

    public static String c(AccessibleObject accessibleObject, boolean z) {
        String string;
        if (accessibleObject instanceof Field) {
            Field field = (Field) accessibleObject;
            StringBuilder sb = new StringBuilder("field '");
            sb.append(field.getDeclaringClass().getName());
            sb.append("#");
            sb.append(field.getName());
            sb.append("'");
            string = sb.toString();
        } else if (accessibleObject instanceof Method) {
            Method method = (Method) accessibleObject;
            StringBuilder sb2 = new StringBuilder(method.getName());
            d(method, sb2);
            String string2 = sb2.toString();
            StringBuilder sb3 = new StringBuilder("method '");
            sb3.append(method.getDeclaringClass().getName());
            sb3.append("#");
            sb3.append(string2);
            sb3.append("'");
            string = sb3.toString();
        } else if (accessibleObject instanceof Constructor) {
            StringBuilder sb4 = new StringBuilder("constructor '");
            sb4.append(e((Constructor<?>) accessibleObject));
            sb4.append("'");
            string = sb4.toString();
        } else {
            StringBuilder sb5 = new StringBuilder("<unknown AccessibleObject> ");
            sb5.append(accessibleObject.toString());
            string = sb5.toString();
        }
        if (!z || !Character.isLowerCase(string.charAt(0))) {
            return string;
        }
        StringBuilder sb6 = new StringBuilder();
        sb6.append(Character.toUpperCase(string.charAt(0)));
        sb6.append(string.substring(1));
        return sb6.toString();
    }

    public static void d(AccessibleObject accessibleObject) {
        try {
            accessibleObject.setAccessible(true);
        } catch (Exception e) {
            String strC = c(accessibleObject, false);
            StringBuilder sb = new StringBuilder("Failed making ");
            sb.append(strC);
            sb.append(" accessible; either increase its visibility or write a custom TypeAdapter for its declaring type.");
            throw new er(sb.toString(), e);
        }
    }

    public static String e(Constructor<?> constructor) {
        StringBuilder sb = new StringBuilder(constructor.getDeclaringClass().getName());
        d(constructor, sb);
        return sb.toString();
    }

    private static void d(AccessibleObject accessibleObject, StringBuilder sb) {
        Class<?>[] parameterTypes;
        sb.append('(');
        if (accessibleObject instanceof Method) {
            parameterTypes = ((Method) accessibleObject).getParameterTypes();
        } else {
            parameterTypes = ((Constructor) accessibleObject).getParameterTypes();
        }
        for (int i = 0; i < parameterTypes.length; i++) {
            if (i > 0) {
                sb.append(", ");
            }
            sb.append(parameterTypes[i].getSimpleName());
        }
        sb.append(')');
    }

    public static RuntimeException e(IllegalAccessException illegalAccessException) {
        throw new RuntimeException("Unexpected IllegalAccessException occurred (Gson 2.10). Certain ReflectionAccessFilter features require Java >= 9 to work correctly. If you are not using ReflectionAccessFilter, report this to the Gson maintainers.", illegalAccessException);
    }

    public static String d(Constructor<?> constructor) {
        try {
            constructor.setAccessible(true);
            return null;
        } catch (Exception e) {
            StringBuilder sb = new StringBuilder("Failed making constructor '");
            sb.append(e(constructor));
            sb.append("' accessible; either increase its visibility or write a custom InstanceCreator or TypeAdapter for its declaring type: ");
            sb.append(e.getMessage());
            return sb.toString();
        }
    }

    public static boolean c(Class<?> cls) {
        return a.d(cls);
    }

    public static String[] d(Class<?> cls) {
        return a.c(cls);
    }

    public static Method d(Class<?> cls, Field field) {
        return a.c(cls, field);
    }

    public static /* synthetic */ RuntimeException d(ReflectiveOperationException reflectiveOperationException) {
        throw new RuntimeException("Unexpected ReflectiveOperationException occurred (Gson 2.10). To support Java records, reflection is utilized to read out information about records. All these invocations happens after it is established that records exist in the JVM. This exception is unexpected behavior.", reflectiveOperationException);
    }
}