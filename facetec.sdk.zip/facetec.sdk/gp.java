package com.facetec.sdk;

import java.util.TimeZone;

/* JADX INFO: loaded from: classes4.dex */
public final class gp {
    private static final TimeZone a = TimeZone.getTimeZone("UTC");

    /* JADX WARN: Removed duplicated region for block: B:102:0x01f5  */
    /* JADX WARN: Removed duplicated region for block: B:104:0x01fb  */
    /* JADX WARN: Removed duplicated region for block: B:66:0x00fa A[Catch: IllegalArgumentException -> 0x004e, NumberFormatException -> 0x0051, IndexOutOfBoundsException -> 0x0054, TryCatch #2 {IndexOutOfBoundsException -> 0x0054, NumberFormatException -> 0x0051, IllegalArgumentException -> 0x004e, blocks: (B:3:0x0004, B:5:0x0017, B:6:0x0019, B:8:0x0025, B:9:0x0027, B:11:0x0037, B:13:0x003d, B:23:0x005e, B:25:0x006e, B:26:0x0070, B:28:0x007c, B:29:0x007f, B:31:0x0085, B:35:0x008f, B:40:0x009f, B:42:0x00a7, B:43:0x00ab, B:45:0x00b1, B:50:0x00be, B:53:0x00c9, B:64:0x00f4, B:66:0x00fa, B:68:0x0100, B:93:0x019f, B:73:0x010c, B:74:0x0124, B:75:0x0125, B:79:0x0142, B:81:0x014f, B:84:0x0158, B:86:0x016c, B:89:0x017b, B:90:0x019a, B:92:0x019d, B:78:0x0131, B:95:0x01d0, B:96:0x01d7, B:57:0x00d9, B:58:0x00dc, B:52:0x00c5), top: B:107:0x0004 }] */
    /* JADX WARN: Removed duplicated region for block: B:95:0x01d0 A[Catch: IllegalArgumentException -> 0x004e, NumberFormatException -> 0x0051, IndexOutOfBoundsException -> 0x0054, TryCatch #2 {IndexOutOfBoundsException -> 0x0054, NumberFormatException -> 0x0051, IllegalArgumentException -> 0x004e, blocks: (B:3:0x0004, B:5:0x0017, B:6:0x0019, B:8:0x0025, B:9:0x0027, B:11:0x0037, B:13:0x003d, B:23:0x005e, B:25:0x006e, B:26:0x0070, B:28:0x007c, B:29:0x007f, B:31:0x0085, B:35:0x008f, B:40:0x009f, B:42:0x00a7, B:43:0x00ab, B:45:0x00b1, B:50:0x00be, B:53:0x00c9, B:64:0x00f4, B:66:0x00fa, B:68:0x0100, B:93:0x019f, B:73:0x010c, B:74:0x0124, B:75:0x0125, B:79:0x0142, B:81:0x014f, B:84:0x0158, B:86:0x016c, B:89:0x017b, B:90:0x019a, B:92:0x019d, B:78:0x0131, B:95:0x01d0, B:96:0x01d7, B:57:0x00d9, B:58:0x00dc, B:52:0x00c5), top: B:107:0x0004 }] */
    /* JADX WARN: Removed duplicated region for block: B:98:0x01da  */
    /* JADX WARN: Removed duplicated region for block: B:99:0x01dc  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public static java.util.Date a(java.lang.String r17, java.text.ParsePosition r18) throws java.text.ParseException {
        /*
            Method dump skipped, instruction units count: 569
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: com.facetec.sdk.gp.a(java.lang.String, java.text.ParsePosition):java.util.Date");
    }

    private static boolean b(String str, int i, char c) {
        return i < str.length() && str.charAt(i) == c;
    }

    private static int a(String str, int i, int i2) {
        int i3;
        int i4;
        if (i < 0 || i2 > str.length() || i > i2) {
            throw new NumberFormatException(str);
        }
        if (i < i2) {
            i4 = i + 1;
            int iDigit = Character.digit(str.charAt(i), 10);
            if (iDigit < 0) {
                StringBuilder sb = new StringBuilder("Invalid number: ");
                sb.append(str.substring(i, i2));
                throw new NumberFormatException(sb.toString());
            }
            i3 = -iDigit;
        } else {
            i3 = 0;
            i4 = i;
        }
        while (i4 < i2) {
            int i5 = i4 + 1;
            int iDigit2 = Character.digit(str.charAt(i4), 10);
            if (iDigit2 < 0) {
                StringBuilder sb2 = new StringBuilder("Invalid number: ");
                sb2.append(str.substring(i, i2));
                throw new NumberFormatException(sb2.toString());
            }
            i3 = (i3 * 10) - iDigit2;
            i4 = i5;
        }
        return -i3;
    }
}