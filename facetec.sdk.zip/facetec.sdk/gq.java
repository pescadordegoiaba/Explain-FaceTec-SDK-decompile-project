package com.facetec.sdk;

import java.sql.Time;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

/* JADX INFO: loaded from: classes4.dex */
final class gq extends fg<Time> {
    static final ff c = new ff() { // from class: com.facetec.sdk.gq.4
        @Override // com.facetec.sdk.ff
        public final <T> fg<T> b(el elVar, gu<T> guVar) {
            if (guVar.d() == Time.class) {
                return new gq((byte) 0);
            }
            return null;
        }
    };
    private final DateFormat d;

    public /* synthetic */ gq(byte b) {
        this();
    }

    /* JADX INFO: Access modifiers changed from: private */
    @Override // com.facetec.sdk.fg
    /* JADX INFO: renamed from: c, reason: merged with bridge method [inline-methods] */
    public Time a(gs gsVar) {
        Time time;
        if (gsVar.j() == gw.NULL) {
            gsVar.m();
            return null;
        }
        String strH = gsVar.h();
        try {
            synchronized (this) {
                time = new Time(this.d.parse(strH).getTime());
            }
            return time;
        } catch (ParseException e) {
            StringBuilder sb = new StringBuilder("Failed parsing '");
            sb.append(strH);
            sb.append("' as SQL Time; at path ");
            sb.append(gsVar.q());
            throw new fc(sb.toString(), e);
        }
    }

    @Override // com.facetec.sdk.fg
    public final /* bridge */ /* synthetic */ void e(ha haVar, Time time) {
        String str;
        Time time2 = time;
        if (time2 == null) {
            haVar.g();
            return;
        }
        synchronized (this) {
            str = this.d.format((Date) time2);
        }
        haVar.e(str);
    }

    private gq() {
        this.d = new SimpleDateFormat("hh:mm:ss a");
    }
}