package com.facetec.sdk;

import java.sql.Date;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;

/* JADX INFO: loaded from: classes4.dex */
final class gr extends fg<Date> {
    static final ff e = new ff() { // from class: com.facetec.sdk.gr.4
        @Override // com.facetec.sdk.ff
        public final <T> fg<T> b(el elVar, gu<T> guVar) {
            if (guVar.d() == Date.class) {
                return new gr((byte) 0);
            }
            return null;
        }
    };
    private final DateFormat c;

    public /* synthetic */ gr(byte b) {
        this();
    }

    /* JADX INFO: Access modifiers changed from: private */
    @Override // com.facetec.sdk.fg
    /* JADX INFO: renamed from: c, reason: merged with bridge method [inline-methods] */
    public Date a(gs gsVar) {
        java.util.Date date;
        if (gsVar.j() == gw.NULL) {
            gsVar.m();
            return null;
        }
        String strH = gsVar.h();
        try {
            synchronized (this) {
                date = this.c.parse(strH);
            }
            return new Date(date.getTime());
        } catch (ParseException e2) {
            StringBuilder sb = new StringBuilder("Failed parsing '");
            sb.append(strH);
            sb.append("' as SQL Date; at path ");
            sb.append(gsVar.q());
            throw new fc(sb.toString(), e2);
        }
    }

    @Override // com.facetec.sdk.fg
    public final /* bridge */ /* synthetic */ void e(ha haVar, Date date) {
        String str;
        Date date2 = date;
        if (date2 == null) {
            haVar.g();
            return;
        }
        synchronized (this) {
            str = this.c.format((java.util.Date) date2);
        }
        haVar.e(str);
    }

    private gr() {
        this.c = new SimpleDateFormat("MMM d, yyyy");
    }
}