package com.facetec.sdk;

import ai.luciq.library.logging.LuciqLog;
import android.text.TextUtils;
import android.view.Gravity;
import android.view.View;
import android.view.ViewConfiguration;
import java.io.Closeable;
import java.io.IOException;
import java.io.Reader;
import java.util.Arrays;
import java.util.Iterator;
import java.util.Map;
import java.util.Objects;

/* JADX INFO: loaded from: classes4.dex */
public class gs implements Closeable {
    private static final byte[] $$c = null;
    private static final int $$d = 0;
    private static long r;
    private static char[] s;
    private final Reader d;
    private int i;
    private long j;
    private String[] l;
    private String m;
    private int[] n;
    private int[] o;
    private boolean c = false;
    private final char[] e = new char[1024];
    private int a = 0;
    private int f = 0;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    private int f95896g = 0;
    private int h = 0;
    int b = 0;
    private int k = 1;

    /* JADX WARN: Removed duplicated region for block: B:10:0x0028  */
    /* JADX WARN: Removed duplicated region for block: B:8:0x0022  */
    /* JADX WARN: Unsupported multi-entry loop pattern (BACK_EDGE: B:10:0x0028 -> B:11:0x002a). Please report as a decompilation issue!!! */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    private static java.lang.String $$e(short r5, byte r6, int r7) {
        /*
            byte[] r0 = com.facetec.sdk.gs.$$c
            int r7 = r7 * 2
            int r1 = 1 - r7
            int r6 = r6 * 4
            int r6 = 4 - r6
            int r5 = 111 - r5
            byte[] r1 = new byte[r1]
            r2 = 0
            int r7 = 0 - r7
            if (r0 != 0) goto L17
            r5 = r6
            r3 = r7
            r4 = r2
            goto L2a
        L17:
            r3 = r6
            r6 = r5
            r5 = r3
            r3 = r2
        L1b:
            byte r4 = (byte) r6
            r1[r3] = r4
            int r4 = r3 + 1
            if (r3 != r7) goto L28
            java.lang.String r5 = new java.lang.String
            r5.<init>(r1, r2)
            return r5
        L28:
            r3 = r0[r5]
        L2a:
            int r6 = r6 + r3
            int r5 = r5 + 1
            r3 = r4
            goto L1b
        */
        throw new UnsupportedOperationException("Method not decompiled: com.facetec.sdk.gs.$$e(short, byte, int):java.lang.String");
    }

    static {
        init$0();
        v();
        fr.a = new fr() { // from class: com.facetec.sdk.gs.4
            public static int b;
            public static int d;

            public static int e() {
                int i = b;
                int i2 = i % 6709459;
                b = i + 1;
                if (i2 != 0) {
                    return d;
                }
                int iFreeMemory = (int) Runtime.getRuntime().freeMemory();
                d = iFreeMemory;
                return iFreeMemory;
            }

            @Override // com.facetec.sdk.fr
            public final void c(gs gsVar) throws Throwable {
                if (gsVar instanceof gh) {
                    gh ghVar = (gh) gsVar;
                    ghVar.b(gw.NAME);
                    Map.Entry entry = (Map.Entry) ((Iterator) ghVar.i()).next();
                    ghVar.e(entry.getValue());
                    ghVar.e(new eu((String) entry.getKey()));
                    return;
                }
                int iR = gsVar.b;
                if (iR == 0) {
                    iR = gsVar.r();
                }
                if (iR == 13) {
                    gsVar.b = 9;
                    return;
                }
                if (iR == 12) {
                    gsVar.b = 8;
                } else {
                    if (iR == 14) {
                        gsVar.b = 10;
                        return;
                    }
                    StringBuilder sb = new StringBuilder("Expected a name but was ");
                    sb.append(gsVar.j());
                    sb.append(gsVar.s());
                    throw new IllegalStateException(sb.toString());
                }
            }
        };
    }

    public gs(Reader reader) {
        int[] iArr = new int[32];
        this.n = iArr;
        iArr[0] = 6;
        this.l = new String[32];
        this.o = new int[32];
        Objects.requireNonNull(reader, "in == null");
        this.d = reader;
    }

    private void A() throws Throwable {
        b(true);
        int i = this.a;
        this.a = i - 1;
        if (i + 4 <= this.f || b(5)) {
            int i2 = this.a;
            char[] cArr = this.e;
            if (cArr[i2] == ')' && cArr[i2 + 1] == ']' && cArr[i2 + 2] == '}' && cArr[i2 + 3] == '\'' && cArr[i2 + 4] == '\n') {
                this.a = i2 + 5;
            }
        }
    }

    private char B() throws IOException {
        int i;
        if (this.a == this.f && !b(1)) {
            throw e("Unterminated escape sequence");
        }
        char[] cArr = this.e;
        int i2 = this.a;
        int i3 = i2 + 1;
        this.a = i3;
        char c = cArr[i2];
        if (c == '\n') {
            this.f95896g++;
            this.h = i3;
            return c;
        }
        if (c == '\"' || c == '\'' || c == '/' || c == '\\') {
            return c;
        }
        if (c == 'b') {
            return '\b';
        }
        if (c == 'f') {
            return '\f';
        }
        if (c == 'n') {
            return '\n';
        }
        if (c == 'r') {
            return '\r';
        }
        if (c == 't') {
            return '\t';
        }
        if (c != 'u') {
            throw e("Invalid escape sequence");
        }
        if (i2 + 5 > this.f && !b(4)) {
            throw e("Unterminated escape sequence");
        }
        int i4 = this.a;
        int i5 = i4 + 4;
        char c2 = 0;
        while (i4 < i5) {
            char c3 = this.e[i4];
            char c4 = (char) (c2 << 4);
            if (c3 >= '0' && c3 <= '9') {
                i = c3 - '0';
            } else if (c3 >= 'a' && c3 <= 'f') {
                i = c3 - 'W';
            } else {
                if (c3 < 'A' || c3 > 'F') {
                    StringBuilder sb = new StringBuilder("\\u");
                    sb.append(new String(this.e, this.a, 4));
                    throw new NumberFormatException(sb.toString());
                }
                i = c3 - '7';
            }
            c2 = (char) (c4 + i);
            i4++;
        }
        this.a += 4;
        return c2;
    }

    private void C() {
        char c;
        do {
            if (this.a >= this.f && !b(1)) {
                return;
            }
            char[] cArr = this.e;
            int i = this.a;
            int i2 = i + 1;
            this.a = i2;
            c = cArr[i];
            if (c == '\n') {
                this.f95896g++;
                this.h = i2;
                return;
            }
        } while (c != '\r');
    }

    /* JADX WARN: Removed duplicated region for block: B:36:0x017d  */
    /* JADX WARN: Removed duplicated region for block: B:37:0x017e  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    private static void D(int r26, char r27, int r28, java.lang.Object[] r29) throws java.lang.Throwable {
        /*
            Method dump skipped, instruction units count: 391
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: com.facetec.sdk.gs.D(int, char, int, java.lang.Object[]):void");
    }

    private int i() {
        String str;
        String str2;
        int i;
        char c = this.e[this.a];
        if (c == 't' || c == 'T') {
            str = "true";
            str2 = "TRUE";
            i = 5;
        } else if (c == 'f' || c == 'F') {
            str = "false";
            str2 = "FALSE";
            i = 6;
        } else {
            if (c != 'n' && c != 'N') {
                return 0;
            }
            str = LuciqLog.LogMessage.NULL_LOG;
            str2 = "NULL";
            i = 7;
        }
        int length = str.length();
        for (int i2 = 1; i2 < length; i2++) {
            if (this.a + i2 >= this.f && !b(i2 + 1)) {
                return 0;
            }
            char c2 = this.e[this.a + i2];
            if (c2 != str.charAt(i2) && c2 != str2.charAt(i2)) {
                return 0;
            }
        }
        if ((this.a + length < this.f || b(length + 1)) && d(this.e[this.a + length])) {
            return 0;
        }
        this.a += length;
        this.b = i;
        return i;
    }

    public static void init$0() {
        $$c = new byte[]{109, 5, -57, 108};
        $$d = 158;
    }

    /* JADX WARN: Code restructure failed: missing block: B:33:0x0048, code lost:
    
        y();
     */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    private void u() throws java.io.IOException {
        /*
            r4 = this;
        L0:
            r0 = 0
        L1:
            int r1 = r4.a
            int r2 = r1 + r0
            int r3 = r4.f
            if (r2 >= r3) goto L51
            char[] r2 = r4.e
            int r1 = r1 + r0
            char r1 = r2[r1]
            r2 = 9
            if (r1 == r2) goto L4b
            r2 = 10
            if (r1 == r2) goto L4b
            r2 = 12
            if (r1 == r2) goto L4b
            r2 = 13
            if (r1 == r2) goto L4b
            r2 = 32
            if (r1 == r2) goto L4b
            r2 = 35
            if (r1 == r2) goto L48
            r2 = 44
            if (r1 == r2) goto L4b
            r2 = 47
            if (r1 == r2) goto L48
            r2 = 61
            if (r1 == r2) goto L48
            r2 = 123(0x7b, float:1.72E-43)
            if (r1 == r2) goto L4b
            r2 = 125(0x7d, float:1.75E-43)
            if (r1 == r2) goto L4b
            r2 = 58
            if (r1 == r2) goto L4b
            r2 = 59
            if (r1 == r2) goto L48
            switch(r1) {
                case 91: goto L4b;
                case 92: goto L48;
                case 93: goto L4b;
                default: goto L45;
            }
        L45:
            int r0 = r0 + 1
            goto L1
        L48:
            r4.y()
        L4b:
            int r1 = r4.a
            int r1 = r1 + r0
            r4.a = r1
            return
        L51:
            int r1 = r1 + r0
            r4.a = r1
            r0 = 1
            boolean r0 = r4.b(r0)
            if (r0 != 0) goto L0
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: com.facetec.sdk.gs.u():void");
    }

    public static void v() {
        s = new char[]{57916, 18187, 43096, 3459, 30344, 55318, 15711, 26268, 52177, 11620, 38493, 64443, 23797, 34350, 60283, 19647, 57911, 18200, 43100, 3459, 30431, 55321, 15697, 26242, 52175};
        r = 9042168974321928042L;
    }

    /* JADX WARN: Code restructure failed: missing block: B:52:0x0094, code lost:
    
        if (d(r14) == false) goto L54;
     */
    /* JADX WARN: Code restructure failed: missing block: B:53:0x0096, code lost:
    
        return r18;
     */
    /* JADX WARN: Code restructure failed: missing block: B:54:0x0097, code lost:
    
        if (r9 != 2) goto L67;
     */
    /* JADX WARN: Code restructure failed: missing block: B:55:0x0099, code lost:
    
        if (r10 == 0) goto L67;
     */
    /* JADX WARN: Code restructure failed: missing block: B:57:0x009f, code lost:
    
        if (r11 != Long.MIN_VALUE) goto L59;
     */
    /* JADX WARN: Code restructure failed: missing block: B:58:0x00a1, code lost:
    
        if (r13 == false) goto L67;
     */
    /* JADX WARN: Code restructure failed: missing block: B:60:0x00a5, code lost:
    
        if (r11 != 0) goto L62;
     */
    /* JADX WARN: Code restructure failed: missing block: B:61:0x00a7, code lost:
    
        if (r13 != false) goto L67;
     */
    /* JADX WARN: Code restructure failed: missing block: B:62:0x00a9, code lost:
    
        if (r13 == false) goto L64;
     */
    /* JADX WARN: Code restructure failed: missing block: B:64:0x00ac, code lost:
    
        r11 = -r11;
     */
    /* JADX WARN: Code restructure failed: missing block: B:65:0x00ad, code lost:
    
        r19.j = r11;
        r19.a += r8;
        r19.b = 15;
     */
    /* JADX WARN: Code restructure failed: missing block: B:66:0x00b8, code lost:
    
        return 15;
     */
    /* JADX WARN: Code restructure failed: missing block: B:67:0x00b9, code lost:
    
        if (r9 == 2) goto L74;
     */
    /* JADX WARN: Code restructure failed: missing block: B:69:0x00bc, code lost:
    
        if (r9 == 4) goto L74;
     */
    /* JADX WARN: Code restructure failed: missing block: B:71:0x00bf, code lost:
    
        if (r9 != 7) goto L73;
     */
    /* JADX WARN: Code restructure failed: missing block: B:73:0x00c2, code lost:
    
        return r18;
     */
    /* JADX WARN: Code restructure failed: missing block: B:74:0x00c3, code lost:
    
        r19.i = r8;
        r19.b = 16;
     */
    /* JADX WARN: Code restructure failed: missing block: B:75:0x00c9, code lost:
    
        return 16;
     */
    /* JADX WARN: Removed duplicated region for block: B:14:0x0037  */
    /* JADX WARN: Removed duplicated region for block: B:91:0x00e2  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    private int w() {
        /*
            Method dump skipped, instruction units count: 237
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: com.facetec.sdk.gs.w():int");
    }

    /* JADX WARN: Code restructure failed: missing block: B:34:0x004a, code lost:
    
        y();
     */
    /* JADX WARN: Failed to find 'out' block for switch in B:32:0x0044. Please report as an issue. */
    /* JADX WARN: Removed duplicated region for block: B:46:0x0080  */
    /* JADX WARN: Removed duplicated region for block: B:47:0x008a  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    private java.lang.String x() throws java.io.IOException {
        /*
            r6 = this;
            r0 = 0
            r1 = 0
        L2:
            r2 = r1
        L3:
            int r3 = r6.a
            int r4 = r3 + r2
            int r5 = r6.f
            if (r4 >= r5) goto L4e
            char[] r4 = r6.e
            int r3 = r3 + r2
            char r3 = r4[r3]
            r4 = 9
            if (r3 == r4) goto L5c
            r4 = 10
            if (r3 == r4) goto L5c
            r4 = 12
            if (r3 == r4) goto L5c
            r4 = 13
            if (r3 == r4) goto L5c
            r4 = 32
            if (r3 == r4) goto L5c
            r4 = 35
            if (r3 == r4) goto L4a
            r4 = 44
            if (r3 == r4) goto L5c
            r4 = 47
            if (r3 == r4) goto L4a
            r4 = 61
            if (r3 == r4) goto L4a
            r4 = 123(0x7b, float:1.72E-43)
            if (r3 == r4) goto L5c
            r4 = 125(0x7d, float:1.75E-43)
            if (r3 == r4) goto L5c
            r4 = 58
            if (r3 == r4) goto L5c
            r4 = 59
            if (r3 == r4) goto L4a
            switch(r3) {
                case 91: goto L5c;
                case 92: goto L4a;
                case 93: goto L5c;
                default: goto L47;
            }
        L47:
            int r2 = r2 + 1
            goto L3
        L4a:
            r6.y()
            goto L5c
        L4e:
            char[] r3 = r6.e
            int r3 = r3.length
            if (r2 >= r3) goto L5e
            int r3 = r2 + 1
            boolean r3 = r6.b(r3)
            if (r3 == 0) goto L5c
            goto L3
        L5c:
            r1 = r2
            goto L7e
        L5e:
            if (r0 != 0) goto L6b
            java.lang.StringBuilder r0 = new java.lang.StringBuilder
            r3 = 16
            int r3 = java.lang.Math.max(r2, r3)
            r0.<init>(r3)
        L6b:
            char[] r3 = r6.e
            int r4 = r6.a
            r0.append(r3, r4, r2)
            int r3 = r6.a
            int r3 = r3 + r2
            r6.a = r3
            r2 = 1
            boolean r2 = r6.b(r2)
            if (r2 != 0) goto L2
        L7e:
            if (r0 != 0) goto L8a
            java.lang.String r0 = new java.lang.String
            char[] r2 = r6.e
            int r3 = r6.a
            r0.<init>(r2, r3, r1)
            goto L95
        L8a:
            char[] r2 = r6.e
            int r3 = r6.a
            r0.append(r2, r3, r1)
            java.lang.String r0 = r0.toString()
        L95:
            int r2 = r6.a
            int r2 = r2 + r1
            r6.a = r2
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: com.facetec.sdk.gs.x():java.lang.String");
    }

    private void y() throws IOException {
        if (!this.c) {
            throw e("Use JsonReader.setLenient(true) to accept malformed JSON");
        }
    }

    public final void a(boolean z) {
        this.c = z;
    }

    public boolean b() throws Throwable {
        int iR = this.b;
        if (iR == 0) {
            iR = r();
        }
        return (iR == 2 || iR == 4 || iR == 17) ? false : true;
    }

    public void c() {
        int iR = this.b;
        if (iR == 0) {
            iR = r();
        }
        if (iR == 3) {
            a(1);
            this.o[this.k - 1] = 0;
            this.b = 0;
        } else {
            StringBuilder sb = new StringBuilder("Expected BEGIN_ARRAY but was ");
            sb.append(j());
            sb.append(s());
            throw new IllegalStateException(sb.toString());
        }
    }

    @Override // java.io.Closeable, java.lang.AutoCloseable
    public void close() throws IOException {
        this.b = 0;
        this.n[0] = 8;
        this.k = 1;
        this.d.close();
    }

    public void d() {
        int iR = this.b;
        if (iR == 0) {
            iR = r();
        }
        if (iR == 1) {
            a(3);
            this.b = 0;
        } else {
            StringBuilder sb = new StringBuilder("Expected BEGIN_OBJECT but was ");
            sb.append(j());
            sb.append(s());
            throw new IllegalStateException(sb.toString());
        }
    }

    public void e() {
        int iR = this.b;
        if (iR == 0) {
            iR = r();
        }
        if (iR != 4) {
            StringBuilder sb = new StringBuilder("Expected END_ARRAY but was ");
            sb.append(j());
            sb.append(s());
            throw new IllegalStateException(sb.toString());
        }
        int i = this.k;
        this.k = i - 1;
        int[] iArr = this.o;
        int i2 = i - 2;
        iArr[i2] = iArr[i2] + 1;
        this.b = 0;
    }

    public boolean f() {
        int iR = this.b;
        if (iR == 0) {
            iR = r();
        }
        if (iR == 5) {
            this.b = 0;
            int[] iArr = this.o;
            int i = this.k - 1;
            iArr[i] = iArr[i] + 1;
            return true;
        }
        if (iR != 6) {
            StringBuilder sb = new StringBuilder("Expected a boolean but was ");
            sb.append(j());
            sb.append(s());
            throw new IllegalStateException(sb.toString());
        }
        this.b = 0;
        int[] iArr2 = this.o;
        int i2 = this.k - 1;
        iArr2[i2] = iArr2[i2] + 1;
        return false;
    }

    public String g() {
        String strC;
        int iR = this.b;
        if (iR == 0) {
            iR = r();
        }
        if (iR == 14) {
            strC = x();
        } else if (iR == 12) {
            strC = c('\'');
        } else {
            if (iR != 13) {
                StringBuilder sb = new StringBuilder("Expected a name but was ");
                sb.append(j());
                sb.append(s());
                throw new IllegalStateException(sb.toString());
            }
            strC = c('\"');
        }
        this.b = 0;
        this.l[this.k - 1] = strC;
        return strC;
    }

    public String h() {
        String str;
        int iR = this.b;
        if (iR == 0) {
            iR = r();
        }
        if (iR == 10) {
            str = x();
        } else if (iR == 8) {
            str = c('\'');
        } else if (iR == 9) {
            str = c('\"');
        } else if (iR == 11) {
            str = this.m;
            this.m = null;
        } else if (iR == 15) {
            str = Long.toString(this.j);
        } else {
            if (iR != 16) {
                StringBuilder sb = new StringBuilder("Expected a string but was ");
                sb.append(j());
                sb.append(s());
                throw new IllegalStateException(sb.toString());
            }
            str = new String(this.e, this.a, this.i);
            this.a += this.i;
        }
        this.b = 0;
        int[] iArr = this.o;
        int i = this.k - 1;
        iArr[i] = iArr[i] + 1;
        return str;
    }

    public gw j() {
        int iR = this.b;
        if (iR == 0) {
            iR = r();
        }
        switch (iR) {
            case 1:
                return gw.BEGIN_OBJECT;
            case 2:
                return gw.END_OBJECT;
            case 3:
                return gw.BEGIN_ARRAY;
            case 4:
                return gw.END_ARRAY;
            case 5:
            case 6:
                return gw.BOOLEAN;
            case 7:
                return gw.NULL;
            case 8:
            case 9:
            case 10:
            case 11:
                return gw.STRING;
            case 12:
            case 13:
            case 14:
                return gw.NAME;
            case 15:
            case 16:
                return gw.NUMBER;
            case 17:
                return gw.END_DOCUMENT;
            default:
                throw new AssertionError();
        }
    }

    public int k() {
        int iR = this.b;
        if (iR == 0) {
            iR = r();
        }
        if (iR == 15) {
            long j = this.j;
            int i = (int) j;
            if (j != i) {
                StringBuilder sb = new StringBuilder("Expected an int but was ");
                sb.append(this.j);
                sb.append(s());
                throw new NumberFormatException(sb.toString());
            }
            this.b = 0;
            int[] iArr = this.o;
            int i2 = this.k - 1;
            iArr[i2] = iArr[i2] + 1;
            return i;
        }
        if (iR == 16) {
            this.m = new String(this.e, this.a, this.i);
            this.a += this.i;
        } else {
            if (iR != 8 && iR != 9 && iR != 10) {
                StringBuilder sb2 = new StringBuilder("Expected an int but was ");
                sb2.append(j());
                sb2.append(s());
                throw new IllegalStateException(sb2.toString());
            }
            if (iR == 10) {
                this.m = x();
            } else {
                this.m = c(iR == 8 ? '\'' : '\"');
            }
            try {
                int i3 = Integer.parseInt(this.m);
                this.b = 0;
                int[] iArr2 = this.o;
                int i4 = this.k - 1;
                iArr2[i4] = iArr2[i4] + 1;
                return i3;
            } catch (NumberFormatException unused) {
            }
        }
        this.b = 11;
        double d = Double.parseDouble(this.m);
        int i5 = (int) d;
        if (i5 != d) {
            StringBuilder sb3 = new StringBuilder("Expected an int but was ");
            sb3.append(this.m);
            sb3.append(s());
            throw new NumberFormatException(sb3.toString());
        }
        this.m = null;
        this.b = 0;
        int[] iArr3 = this.o;
        int i6 = this.k - 1;
        iArr3[i6] = iArr3[i6] + 1;
        return i5;
    }

    /* JADX WARN: Can't fix incorrect switch cases order, some code will duplicate */
    public void l() {
        int i = 0;
        do {
            int iR = this.b;
            if (iR == 0) {
                iR = r();
            }
            switch (iR) {
                case 1:
                    a(3);
                    i++;
                    this.b = 0;
                    break;
                case 2:
                    if (i == 0) {
                        this.l[this.k - 1] = null;
                    }
                    this.k--;
                    i--;
                    this.b = 0;
                    break;
                case 3:
                    a(1);
                    i++;
                    this.b = 0;
                    break;
                case 4:
                    this.k--;
                    i--;
                    this.b = 0;
                    break;
                case 5:
                case 6:
                case 7:
                case 11:
                case 15:
                default:
                    this.b = 0;
                    break;
                case 8:
                    e('\'');
                    this.b = 0;
                    break;
                case 9:
                    e('\"');
                    this.b = 0;
                    break;
                case 10:
                    u();
                    this.b = 0;
                    break;
                case 12:
                    e('\'');
                    if (i == 0) {
                        this.l[this.k - 1] = "<skipped>";
                    }
                    this.b = 0;
                    break;
                case 13:
                    e('\"');
                    if (i == 0) {
                        this.l[this.k - 1] = "<skipped>";
                    }
                    this.b = 0;
                    break;
                case 14:
                    u();
                    if (i == 0) {
                        this.l[this.k - 1] = "<skipped>";
                    }
                    this.b = 0;
                    break;
                case 16:
                    this.a += this.i;
                    this.b = 0;
                    break;
                case 17:
                    break;
            }
            return;
        } while (i > 0);
        int[] iArr = this.o;
        int i2 = this.k - 1;
        iArr[i2] = iArr[i2] + 1;
    }

    public void m() {
        int iR = this.b;
        if (iR == 0) {
            iR = r();
        }
        if (iR != 7) {
            StringBuilder sb = new StringBuilder("Expected null but was ");
            sb.append(j());
            sb.append(s());
            throw new IllegalStateException(sb.toString());
        }
        this.b = 0;
        int[] iArr = this.o;
        int i = this.k - 1;
        iArr[i] = iArr[i] + 1;
    }

    public long n() throws Throwable {
        int iR = this.b;
        if (iR == 0) {
            iR = r();
        }
        if (iR == 15) {
            this.b = 0;
            int[] iArr = this.o;
            int i = this.k - 1;
            iArr[i] = iArr[i] + 1;
            return this.j;
        }
        if (iR == 16) {
            this.m = new String(this.e, this.a, this.i);
            this.a += this.i;
        } else {
            if (iR != 8 && iR != 9 && iR != 10) {
                StringBuilder sb = new StringBuilder("Expected a long but was ");
                sb.append(j());
                sb.append(s());
                throw new IllegalStateException(sb.toString());
            }
            if (iR == 10) {
                this.m = x();
            } else {
                this.m = c(iR == 8 ? '\'' : '\"');
            }
            try {
                long j = Long.parseLong(this.m);
                this.b = 0;
                int[] iArr2 = this.o;
                int i2 = this.k - 1;
                iArr2[i2] = iArr2[i2] + 1;
                return j;
            } catch (NumberFormatException unused) {
            }
        }
        this.b = 11;
        double d = Double.parseDouble(this.m);
        long j2 = (long) d;
        if (j2 != d) {
            StringBuilder sb2 = new StringBuilder("Expected a long but was ");
            sb2.append(this.m);
            sb2.append(s());
            throw new NumberFormatException(sb2.toString());
        }
        this.m = null;
        this.b = 0;
        int[] iArr3 = this.o;
        int i3 = this.k - 1;
        iArr3[i3] = iArr3[i3] + 1;
        return j2;
    }

    public double o() throws Throwable {
        int iR = this.b;
        if (iR == 0) {
            iR = r();
        }
        if (iR == 15) {
            this.b = 0;
            int[] iArr = this.o;
            int i = this.k - 1;
            iArr[i] = iArr[i] + 1;
            return this.j;
        }
        if (iR == 16) {
            this.m = new String(this.e, this.a, this.i);
            this.a += this.i;
        } else if (iR == 8 || iR == 9) {
            this.m = c(iR == 8 ? '\'' : '\"');
        } else if (iR == 10) {
            this.m = x();
        } else if (iR != 11) {
            StringBuilder sb = new StringBuilder("Expected a double but was ");
            sb.append(j());
            sb.append(s());
            throw new IllegalStateException(sb.toString());
        }
        this.b = 11;
        double d = Double.parseDouble(this.m);
        if (!this.c && (Double.isNaN(d) || Double.isInfinite(d))) {
            StringBuilder sb2 = new StringBuilder("JSON forbids NaN and infinities: ");
            sb2.append(d);
            sb2.append(s());
            throw new gz(sb2.toString());
        }
        this.m = null;
        this.b = 0;
        int[] iArr2 = this.o;
        int i2 = this.k - 1;
        iArr2[i2] = iArr2[i2] + 1;
        return d;
    }

    public String p() {
        return d(false);
    }

    public String q() {
        return d(true);
    }

    public final int r() throws Throwable {
        int iB;
        int[] iArr = this.n;
        int i = this.k;
        int i2 = iArr[i - 1];
        if (i2 == 1) {
            iArr[i - 1] = 2;
        } else if (i2 == 2) {
            int iB2 = b(true);
            if (iB2 != 44) {
                if (iB2 != 59) {
                    if (iB2 != 93) {
                        throw e("Unterminated array");
                    }
                    this.b = 4;
                    return 4;
                }
                y();
            }
        } else {
            if (i2 == 3 || i2 == 5) {
                iArr[i - 1] = 4;
                if (i2 == 5 && (iB = b(true)) != 44) {
                    if (iB != 59) {
                        if (iB != 125) {
                            throw e("Unterminated object");
                        }
                        this.b = 2;
                        return 2;
                    }
                    y();
                }
                int iB3 = b(true);
                if (iB3 == 34) {
                    this.b = 13;
                    return 13;
                }
                if (iB3 == 39) {
                    y();
                    this.b = 12;
                    return 12;
                }
                if (iB3 == 125) {
                    if (i2 == 5) {
                        throw e("Expected name");
                    }
                    this.b = 2;
                    return 2;
                }
                y();
                this.a--;
                if (!d((char) iB3)) {
                    throw e("Expected name");
                }
                this.b = 14;
                return 14;
            }
            if (i2 == 4) {
                iArr[i - 1] = 5;
                int iB4 = b(true);
                if (iB4 != 58) {
                    if (iB4 != 61) {
                        throw e("Expected ':'");
                    }
                    y();
                    if (this.a < this.f || b(1)) {
                        char[] cArr = this.e;
                        int i3 = this.a;
                        if (cArr[i3] == '>') {
                            this.a = i3 + 1;
                        }
                    }
                }
            } else if (i2 == 6) {
                if (this.c) {
                    A();
                }
                this.n[this.k - 1] = 7;
            } else if (i2 == 7) {
                if (b(false) == -1) {
                    this.b = 17;
                    return 17;
                }
                y();
                this.a--;
            } else if (i2 == 8) {
                throw new IllegalStateException("JsonReader is closed");
            }
        }
        int iB5 = b(true);
        if (iB5 == 34) {
            this.b = 9;
            return 9;
        }
        if (iB5 == 39) {
            y();
            this.b = 8;
            return 8;
        }
        if (iB5 != 44 && iB5 != 59) {
            if (iB5 == 91) {
                this.b = 3;
                return 3;
            }
            if (iB5 != 93) {
                if (iB5 == 123) {
                    this.b = 1;
                    return 1;
                }
                this.a--;
                int i4 = i();
                if (i4 != 0) {
                    return i4;
                }
                int iW = w();
                if (iW != 0) {
                    return iW;
                }
                if (!d(this.e[this.a])) {
                    throw e("Expected value");
                }
                y();
                this.b = 10;
                return 10;
            }
            if (i2 == 1) {
                this.b = 4;
                return 4;
            }
        }
        if (i2 != 1 && i2 != 2) {
            throw e("Unexpected value");
        }
        y();
        this.a--;
        this.b = 7;
        return 7;
    }

    public final String s() {
        int i = this.f95896g + 1;
        int i2 = (this.a - this.h) + 1;
        StringBuilder sb = new StringBuilder(" at line ");
        sb.append(i);
        sb.append(" column ");
        sb.append(i2);
        sb.append(" path ");
        sb.append(p());
        return sb.toString();
    }

    public final boolean t() {
        return this.c;
    }

    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append(getClass().getSimpleName());
        sb.append(s());
        return sb.toString();
    }

    public void a() {
        int iR = this.b;
        if (iR == 0) {
            iR = r();
        }
        if (iR != 2) {
            StringBuilder sb = new StringBuilder("Expected END_OBJECT but was ");
            sb.append(j());
            sb.append(s());
            throw new IllegalStateException(sb.toString());
        }
        int i = this.k;
        int i2 = i - 1;
        this.k = i2;
        this.l[i2] = null;
        int[] iArr = this.o;
        int i3 = i - 2;
        iArr[i3] = iArr[i3] + 1;
        this.b = 0;
    }

    private boolean b(int i) throws Throwable {
        int i2;
        int i3;
        char[] cArr = this.e;
        int i4 = this.h;
        int i5 = this.a;
        this.h = i4 - i5;
        int i6 = this.f;
        if (i6 != i5) {
            int i7 = i6 - i5;
            this.f = i7;
            try {
                Object[] objArr = {cArr, Integer.valueOf(i5), cArr, 0, Integer.valueOf(i7)};
                Object[] objArr2 = new Object[1];
                D((ViewConfiguration.getZoomControlsTimeout() > 0L ? 1 : (ViewConfiguration.getZoomControlsTimeout() == 0L ? 0 : -1)) - 1, (char) (TextUtils.indexOf((CharSequence) "", '0') + 1), View.MeasureSpec.getMode(0) + 16, objArr2);
                Class<?> cls = Class.forName((String) objArr2[0]);
                Object[] objArr3 = new Object[1];
                D(View.MeasureSpec.getSize(0) + 16, (char) TextUtils.getOffsetAfter("", 0), Gravity.getAbsoluteGravity(0, 0) + 9, objArr3);
                String str = (String) objArr3[0];
                Class cls2 = Integer.TYPE;
                cls.getMethod(str, Object.class, cls2, Object.class, cls2, cls2).invoke(null, objArr);
            } catch (Throwable th) {
                Throwable cause = th.getCause();
                if (cause != null) {
                    throw cause;
                }
                throw th;
            }
        } else {
            this.f = 0;
        }
        this.a = 0;
        do {
            Reader reader = this.d;
            int i8 = this.f;
            int i9 = reader.read(cArr, i8, cArr.length - i8);
            if (i9 == -1) {
                return false;
            }
            i2 = this.f + i9;
            this.f = i2;
            if (this.f95896g == 0 && (i3 = this.h) == 0 && i2 > 0 && cArr[0] == 65279) {
                this.a++;
                this.h = i3 + 1;
                i++;
            }
        } while (i2 < i);
        return true;
    }

    private boolean d(char c) throws IOException {
        if (c == '\t' || c == '\n' || c == '\f' || c == '\r' || c == ' ') {
            return false;
        }
        if (c != '#') {
            if (c == ',') {
                return false;
            }
            if (c != '/' && c != '=') {
                if (c == '{' || c == '}' || c == ':') {
                    return false;
                }
                if (c != ';') {
                    switch (c) {
                        case '[':
                        case ']':
                            return false;
                        case '\\':
                            break;
                        default:
                            return true;
                    }
                }
            }
        }
        y();
        return false;
    }

    private String c(char c) throws IOException {
        char[] cArr = this.e;
        StringBuilder sb = null;
        while (true) {
            int i = this.a;
            int i2 = this.f;
            int i3 = i;
            while (true) {
                if (i3 < i2) {
                    int i4 = i3 + 1;
                    char c2 = cArr[i3];
                    if (c2 == c) {
                        this.a = i4;
                        int i5 = (i4 - i) - 1;
                        if (sb == null) {
                            return new String(cArr, i, i5);
                        }
                        sb.append(cArr, i, i5);
                        return sb.toString();
                    }
                    if (c2 == '\\') {
                        this.a = i4;
                        int i6 = i4 - i;
                        int i7 = i6 - 1;
                        if (sb == null) {
                            sb = new StringBuilder(Math.max(i6 << 1, 16));
                        }
                        sb.append(cArr, i, i7);
                        sb.append(B());
                    } else {
                        if (c2 == '\n') {
                            this.f95896g++;
                            this.h = i4;
                        }
                        i3 = i4;
                    }
                } else {
                    if (sb == null) {
                        sb = new StringBuilder(Math.max((i3 - i) << 1, 16));
                    }
                    sb.append(cArr, i, i3 - i);
                    this.a = i3;
                    if (!b(1)) {
                        throw e("Unterminated string");
                    }
                }
            }
        }
    }

    private String d(boolean z) {
        StringBuilder sb = new StringBuilder("$");
        int i = 0;
        while (true) {
            int i2 = this.k;
            if (i < i2) {
                int i3 = this.n[i];
                if (i3 == 1 || i3 == 2) {
                    int i4 = this.o[i];
                    if (z && i4 > 0 && i == i2 - 1) {
                        i4--;
                    }
                    sb.append('[');
                    sb.append(i4);
                    sb.append(']');
                } else if (i3 == 3 || i3 == 4 || i3 == 5) {
                    sb.append('.');
                    String str = this.l[i];
                    if (str != null) {
                        sb.append(str);
                    }
                }
                i++;
            } else {
                return sb.toString();
            }
        }
    }

    private void e(char c) throws IOException {
        char[] cArr = this.e;
        while (true) {
            int i = this.a;
            int i2 = this.f;
            while (true) {
                if (i < i2) {
                    int i3 = i + 1;
                    char c2 = cArr[i];
                    if (c2 == c) {
                        this.a = i3;
                        return;
                    }
                    if (c2 == '\\') {
                        this.a = i3;
                        B();
                        break;
                    } else {
                        if (c2 == '\n') {
                            this.f95896g++;
                            this.h = i3;
                        }
                        i = i3;
                    }
                } else {
                    this.a = i;
                    if (!b(1)) {
                        throw e("Unterminated string");
                    }
                }
            }
        }
    }

    private void a(int i) {
        int i2 = this.k;
        int[] iArr = this.n;
        if (i2 == iArr.length) {
            int i3 = i2 << 1;
            this.n = Arrays.copyOf(iArr, i3);
            this.o = Arrays.copyOf(this.o, i3);
            this.l = (String[]) Arrays.copyOf(this.l, i3);
        }
        int[] iArr2 = this.n;
        int i4 = this.k;
        this.k = i4 + 1;
        iArr2[i4] = i;
    }

    /* JADX WARN: Code restructure failed: missing block: B:32:0x0072, code lost:
    
        return r5;
     */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    private int b(boolean r9) throws java.lang.Throwable {
        /*
            r8 = this;
            char[] r0 = r8.e
            int r1 = r8.a
            int r2 = r8.f
        L6:
            r3 = 1
            if (r1 != r2) goto L32
            r8.a = r1
            boolean r1 = r8.b(r3)
            if (r1 == 0) goto L16
            int r1 = r8.a
            int r2 = r8.f
            goto L32
        L16:
            if (r9 != 0) goto L1a
            r9 = -1
            return r9
        L1a:
            java.io.EOFException r9 = new java.io.EOFException
            java.lang.StringBuilder r0 = new java.lang.StringBuilder
            java.lang.String r1 = "End of input"
            r0.<init>(r1)
            java.lang.String r1 = r8.s()
            r0.append(r1)
            java.lang.String r0 = r0.toString()
            r9.<init>(r0)
            throw r9
        L32:
            int r4 = r1 + 1
            char r5 = r0[r1]
            r6 = 10
            if (r5 != r6) goto L42
            int r1 = r8.f95896g
            int r1 = r1 + r3
            r8.f95896g = r1
            r8.h = r4
            goto Lae
        L42:
            r6 = 32
            if (r5 == r6) goto Lae
            r6 = 13
            if (r5 == r6) goto Lae
            r6 = 9
            if (r5 == r6) goto Lae
            r6 = 47
            if (r5 != r6) goto L99
            r8.a = r4
            r7 = 2
            if (r4 != r2) goto L65
            r8.a = r1
            boolean r1 = r8.b(r7)
            int r2 = r8.a
            int r2 = r2 + r3
            r8.a = r2
            if (r1 != 0) goto L65
            goto L72
        L65:
            r8.y()
            int r1 = r8.a
            char r2 = r0[r1]
            r3 = 42
            if (r2 == r3) goto L7f
            if (r2 == r6) goto L73
        L72:
            return r5
        L73:
            int r1 = r1 + 1
            r8.a = r1
            r8.C()
            int r1 = r8.a
            int r2 = r8.f
            goto L6
        L7f:
            int r1 = r1 + 1
            r8.a = r1
        */
        //  java.lang.String r1 = "*/"
        /*
            boolean r1 = r8.c(r1)
            if (r1 == 0) goto L92
            int r1 = r8.a
            int r1 = r1 + r7
            int r2 = r8.f
            goto L6
        L92:
            java.lang.String r9 = "Unterminated comment"
            java.io.IOException r9 = r8.e(r9)
            throw r9
        L99:
            r1 = 35
            if (r5 != r1) goto Lab
            r8.a = r4
            r8.y()
            r8.C()
            int r1 = r8.a
            int r2 = r8.f
            goto L6
        Lab:
            r8.a = r4
            return r5
        Lae:
            r1 = r4
            goto L6
        */
        throw new UnsupportedOperationException("Method not decompiled: com.facetec.sdk.gs.b(boolean):int");
    }

    private IOException e(String str) throws gz {
        StringBuilder sb = new StringBuilder();
        sb.append(str);
        sb.append(s());
        throw new gz(sb.toString());
    }

    private boolean c(String str) {
        int i;
        int length = str.length();
        while (true) {
            if (this.a + length > this.f && !b(length)) {
                return false;
            }
            char[] cArr = this.e;
            int i2 = this.a;
            if (cArr[i2] != '\n') {
                while (i < length) {
                    i = this.e[this.a + i] == str.charAt(i) ? i + 1 : 0;
                }
                return true;
            }
            this.f95896g++;
            this.h = i2 + 1;
            this.a++;
        }
    }
}