package com.facetec.sdk;

import com.facetec.sdk.fz;
import java.sql.Timestamp;
import java.util.Date;

/* JADX INFO: loaded from: classes4.dex */
public final class gt {
    public static final boolean a;
    public static final ff b;
    public static final fz.d<? extends Date> c;
    public static final ff d;
    public static final fz.d<? extends Date> e;
    public static final ff i;

    static {
        boolean z;
        try {
            Class.forName("java.sql.Date");
            z = true;
        } catch (ClassNotFoundException unused) {
            z = false;
        }
        a = z;
        if (z) {
            c = new fz.d<java.sql.Date>(java.sql.Date.class) { // from class: com.facetec.sdk.gt.3
                @Override // com.facetec.sdk.fz.d
                public final /* synthetic */ Date e(Date date) {
                    return new java.sql.Date(date.getTime());
                }
            };
            e = new fz.d<Timestamp>(Timestamp.class) { // from class: com.facetec.sdk.gt.1
                @Override // com.facetec.sdk.fz.d
                public final /* synthetic */ Date e(Date date) {
                    return new Timestamp(date.getTime());
                }
            };
            d = gr.e;
            b = gq.c;
            i = gv.b;
            return;
        }
        c = null;
        e = null;
        d = null;
        b = null;
        i = null;
    }
}