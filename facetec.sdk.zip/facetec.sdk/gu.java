package com.facetec.sdk;

import java.lang.reflect.ParameterizedType;
import java.lang.reflect.Type;
import java.util.Objects;

/* JADX INFO: loaded from: classes4.dex */
public class gu<T> {
    private final Class<? super T> a;
    private final int c;
    private final Type e;

    public gu() {
        Type genericSuperclass = getClass().getGenericSuperclass();
        if (genericSuperclass instanceof ParameterizedType) {
            ParameterizedType parameterizedType = (ParameterizedType) genericSuperclass;
            if (parameterizedType.getRawType() == gu.class) {
                Type typeA = fm.a(parameterizedType.getActualTypeArguments()[0]);
                this.e = typeA;
                this.a = (Class<? super T>) fm.b(typeA);
                this.c = typeA.hashCode();
                return;
            }
        } else if (genericSuperclass == gu.class) {
            throw new IllegalStateException("TypeToken must be created with a type argument: new TypeToken<...>() {}; When using code shrinkers (ProGuard, R8, ...) make sure that generic signatures are preserved.");
        }
        throw new IllegalStateException("Must only create direct subclasses of TypeToken");
    }

    public static gu<?> e(Type type) {
        return new gu<>(type);
    }

    public final Type a() {
        return this.e;
    }

    public final Class<? super T> d() {
        return this.a;
    }

    public final boolean equals(Object obj) {
        return (obj instanceof gu) && fm.e(this.e, ((gu) obj).e);
    }

    public final int hashCode() {
        return this.c;
    }

    public final String toString() {
        return fm.d(this.e);
    }

    public static <T> gu<T> a(Class<T> cls) {
        return new gu<>(cls);
    }

    private gu(Type type) {
        Objects.requireNonNull(type);
        Type typeA = fm.a(type);
        this.e = typeA;
        this.a = (Class<? super T>) fm.b(typeA);
        this.c = typeA.hashCode();
    }
}