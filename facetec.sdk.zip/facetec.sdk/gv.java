package com.facetec.sdk;

import java.sql.Timestamp;
import java.util.Date;
import java.util.Random;

/* JADX INFO: loaded from: classes4.dex */
final class gv extends fg<Timestamp> {
    static final ff b = new AnonymousClass4();
    private final fg<Date> c;

    /* JADX INFO: renamed from: com.facetec.sdk.gv$4, reason: invalid class name */
    public class AnonymousClass4 implements ff {
        public static int d;
        public static int e;

        public static int e() {
            int i = e;
            int i2 = i % 9971423;
            e = i + 1;
            if (i2 != 0) {
                return d;
            }
            int iNextInt = new Random().nextInt();
            d = iNextInt;
            return iNextInt;
        }

        @Override // com.facetec.sdk.ff
        public final <T> fg<T> b(el elVar, gu<T> guVar) {
            if (guVar.d() == Timestamp.class) {
                return new gv(elVar.d(Date.class), (byte) 0);
            }
            return null;
        }
    }

    public /* synthetic */ gv(fg fgVar, byte b2) {
        this(fgVar);
    }

    @Override // com.facetec.sdk.fg
    public final /* bridge */ /* synthetic */ Timestamp a(gs gsVar) {
        Date dateA = this.c.a(gsVar);
        if (dateA != null) {
            return new Timestamp(dateA.getTime());
        }
        return null;
    }

    @Override // com.facetec.sdk.fg
    public final /* bridge */ /* synthetic */ void e(ha haVar, Timestamp timestamp) {
        this.c.e(haVar, timestamp);
    }

    private gv(fg<Date> fgVar) {
        this.c = fgVar;
    }
}