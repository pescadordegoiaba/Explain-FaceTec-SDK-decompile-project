package com.facetec.sdk;

import java.io.IOException;

/* JADX INFO: loaded from: classes4.dex */
public final class gz extends IOException {
    public gz(String str) {
        super(str);
    }
}