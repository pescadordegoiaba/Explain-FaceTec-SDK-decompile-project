package com.facetec.sdk;

import android.annotation.SuppressLint;
import android.content.ContentResolver;
import android.content.Context;
import android.graphics.Color;
import android.os.Looper;
import android.os.Process;
import android.provider.Settings;
import android.text.TextUtils;
import android.util.TypedValue;
import android.view.KeyEvent;
import android.view.ViewConfiguration;
import android.widget.ExpandableListView;
import com.incode.welcome_sdk.modules.SelfieScan;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.nio.charset.StandardCharsets;
import net.sf.scuba.smartcards.ISO7816;
import org.json.JSONException;
import org.json.JSONObject;

/* JADX INFO: loaded from: classes4.dex */
final class h {
    private static final byte[] $$a = null;
    private static final int $$b = 0;
    private static int $10;
    private static int $11;
    private static a c;
    private static byte[] d;
    private static h e;
    private static long f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    private static Object f95898g;
    private static int h;
    private static /* synthetic */ boolean i;
    private static int j;
    private static int l;
    private static int o;
    private b a;
    private aa b;

    /* JADX INFO: renamed from: com.facetec.sdk.h$1, reason: invalid class name */
    public static /* synthetic */ class AnonymousClass1 {
        static final /* synthetic */ int[] e;

        static {
            int[] iArr = new int[b.e.values().length];
            e = iArr;
            try {
                iArr[b.e.ID.ordinal()] = 1;
            } catch (NoSuchFieldError unused) {
            }
            try {
                e[b.e.APP_SEND_DIAGNOSTICS.ordinal()] = 2;
            } catch (NoSuchFieldError unused2) {
            }
            try {
                e[b.e.DIAGNOSTICS_SIZE.ordinal()] = 3;
            } catch (NoSuchFieldError unused3) {
            }
            try {
                e[b.e.CACHE_KEY.ordinal()] = 4;
            } catch (NoSuchFieldError unused4) {
            }
            try {
                e[b.e.IS_VERSION_DEPRECATED.ordinal()] = 5;
            } catch (NoSuchFieldError unused5) {
            }
            try {
                e[b.e.RECENT_FAILURES.ordinal()] = 6;
            } catch (NoSuchFieldError unused6) {
            }
            try {
                e[b.e.APPLICATION_ID.ordinal()] = 7;
            } catch (NoSuchFieldError unused7) {
            }
            try {
                e[b.e.IS_LATEST_VERSION.ordinal()] = 8;
            } catch (NoSuchFieldError unused8) {
            }
        }
    }

    public enum a {
        Old,
        New
    }

    public static class b {
        String a;
        Integer b;
        Boolean c;
        String d;
        Boolean e;
        Integer f;
        private Boolean h;
        Integer i;

        public enum e {
            ID("id"),
            APP_SEND_DIAGNOSTICS("sd"),
            DIAGNOSTICS_SIZE("ds"),
            CACHE_KEY("ck"),
            IS_VERSION_DEPRECATED("vd"),
            RECENT_FAILURES("rf"),
            APPLICATION_ID("ai"),
            IS_LATEST_VERSION("lv");

            final String i;

            e(String str) {
                this.i = str;
            }
        }

        public b() {
            Boolean bool = Boolean.FALSE;
            this.e = bool;
            this.b = 10;
            this.c = bool;
            this.h = Boolean.TRUE;
        }

        public static b b(JSONObject jSONObject) {
            b bVar = new b();
            for (e eVar : e.values()) {
                switch (AnonymousClass1.e[eVar.ordinal()]) {
                    case 1:
                        bVar.a = jSONObject.getString(eVar.i);
                        break;
                    case 2:
                        bVar.e = Boolean.valueOf(jSONObject.getBoolean(eVar.i));
                        break;
                    case 3:
                        bVar.b = Integer.valueOf(jSONObject.getInt(eVar.i));
                        break;
                    case 4:
                        bVar.d = jSONObject.getString(eVar.i);
                        break;
                    case 5:
                        bVar.c = Boolean.valueOf(jSONObject.getBoolean(eVar.i));
                        break;
                    case 6:
                        bVar.i = Integer.valueOf(jSONObject.getInt(eVar.i));
                        break;
                    case 7:
                        bVar.f = Integer.valueOf(jSONObject.getInt(eVar.i));
                        break;
                    case 8:
                        bVar.h = Boolean.valueOf(jSONObject.getBoolean(eVar.i));
                        break;
                }
            }
            return bVar;
        }

        public final String c() {
            int i;
            JSONObject jSONObject = new JSONObject();
            try {
            } catch (JSONException e2) {
                e2.printStackTrace();
            }
            for (e eVar : e.values()) {
                switch (AnonymousClass1.e[eVar.ordinal()]) {
                    case 1:
                        jSONObject.put(eVar.i, this.a);
                        continue;
                        break;
                    case 2:
                        jSONObject.put(eVar.i, this.e);
                        continue;
                        break;
                    case 3:
                        jSONObject.put(eVar.i, this.b);
                        continue;
                        break;
                    case 4:
                        jSONObject.put(eVar.i, this.d);
                        continue;
                        break;
                    case 5:
                        jSONObject.put(eVar.i, this.c);
                        continue;
                        break;
                    case 6:
                        jSONObject.put(eVar.i, this.i);
                        continue;
                        break;
                    case 7:
                        jSONObject.put(eVar.i, this.f);
                        continue;
                        break;
                    case 8:
                        jSONObject.put(eVar.i, this.h);
                        continue;
                        break;
                    default:
                        continue;
                        break;
                }
                e2.printStackTrace();
                return jSONObject.toString();
            }
            return jSONObject.toString();
        }
    }

    /* JADX WARN: Removed duplicated region for block: B:10:0x0022  */
    /* JADX WARN: Removed duplicated region for block: B:8:0x001c  */
    /* JADX WARN: Unsupported multi-entry loop pattern (BACK_EDGE: B:10:0x0022 -> B:11:0x0024). Please report as a decompilation issue!!! */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    private static java.lang.String $$c(byte r6, int r7, int r8) {
        /*
            int r7 = r7 * 4
            int r7 = 4 - r7
            int r8 = r8 + 99
            int r6 = r6 * 2
            int r6 = r6 + 1
            byte[] r0 = com.facetec.sdk.h.$$a
            byte[] r1 = new byte[r6]
            r2 = 0
            if (r0 != 0) goto L14
            r3 = r6
            r5 = r2
            goto L24
        L14:
            r3 = r2
        L15:
            byte r4 = (byte) r8
            int r5 = r3 + 1
            r1[r3] = r4
            if (r5 != r6) goto L22
            java.lang.String r6 = new java.lang.String
            r6.<init>(r1, r2)
            return r6
        L22:
            r3 = r0[r7]
        L24:
            int r7 = r7 + 1
            int r3 = -r3
            int r8 = r8 + r3
            r3 = r5
            goto L15
        */
        throw new UnsupportedOperationException("Method not decompiled: com.facetec.sdk.h.$$c(byte, int, int):java.lang.String");
    }

    static {
        init$0();
        $10 = 0;
        $11 = 1;
        l = 0;
        o = 1;
        j = 0;
        h = 1;
        b();
        int i2 = o + 27;
        l = i2 % 128;
        i = !(i2 % 2 != 0);
        d = null;
        e = null;
        c = a.Old;
        f95898g = new Object();
        o = (l + 25) % 128;
    }

    private h(Context context) throws Throwable {
        this.a = new b();
        this.b = new aa(context);
        try {
            String strF = f(context);
            byte[] bArrI = i(context);
            byte[] bArrB = new ag(bArrI).b(bq.a(context, strF));
            JSONObject jSONObject = new JSONObject(new String(bArrB, 0, bArrB.length, StandardCharsets.UTF_8));
            Object[] objArr = new Object[1];
            k("ɕ㜬梌ꈟퟳॣ䋛瑜", 13680 - (ViewConfiguration.getScrollFriction() > SelfieScan.RECOGNITION_FAIL_RESULT ? 1 : (ViewConfiguration.getScrollFriction() == SelfieScan.RECOGNITION_FAIL_RESULT ? 0 : -1)), objArr);
            String strOptString = jSONObject.optString(((String) objArr[0]).intern(), "");
            Object[] objArr2 = new Object[1];
            k("ɕ\udd27벜鱵翞", 57191 - TextUtils.getOffsetAfter("", 0), objArr2);
            JSONObject jSONObjectOptJSONObject = jSONObject.optJSONObject(((String) objArr2[0]).intern());
            if (!strOptString.isEmpty()) {
                this.a = b.b(new JSONObject(strOptString));
            }
            if (jSONObjectOptJSONObject != null) {
                this.b = aa.b(context, jSONObjectOptJSONObject.toString());
            }
        } catch (FileNotFoundException unused) {
        } catch (Exception e2) {
            n.a(e2);
        }
    }

    public static synchronized a a(Context context) {
        a aVar;
        try {
            int i2 = h + 69;
            j = i2 % 128;
            if (i2 % 2 != 0) {
                j(context);
                throw null;
            }
            j(context);
            aVar = c;
            int i3 = h + 79;
            j = i3 % 128;
            if (i3 % 2 != 0) {
                throw null;
            }
        } catch (Throwable th) {
            throw th;
        }
        return aVar;
    }

    private static synchronized h b(Context context) {
        h hVar;
        try {
            if (e == null) {
                e = new h(context);
                h = (j + 29) % 128;
            }
            hVar = e;
            j = (h + 85) % 128;
        } catch (Throwable th) {
            throw th;
        }
        return hVar;
    }

    private void c(Context context) throws Throwable {
        if (!i) {
            int i2 = j + 59;
            h = i2 % 128;
            if (i2 % 2 == 0) {
                Thread.currentThread().equals(Looper.getMainLooper().getThread());
                throw null;
            }
            if (Thread.currentThread().equals(Looper.getMainLooper().getThread())) {
                throw new AssertionError();
            }
        }
        e = this;
        JSONObject jSONObject = new JSONObject();
        String strC = this.a.c();
        Object[] objArr = new Object[1];
        k("ɕ㜬梌ꈟퟳॣ䋛瑜", (ViewConfiguration.getScrollFriction() > SelfieScan.RECOGNITION_FAIL_RESULT ? 1 : (ViewConfiguration.getScrollFriction() == SelfieScan.RECOGNITION_FAIL_RESULT ? 0 : -1)) + 13678, objArr);
        jSONObject.put(((String) objArr[0]).intern(), strC);
        Object[] objArr2 = new Object[1];
        k("ɕ\udd27벜鱵翞", TextUtils.indexOf("", "", 0, 0) + 57191, objArr2);
        jSONObject.put(((String) objArr2[0]).intern(), this.b.c());
        Object[] objArr3 = new Object[1];
        k("ɔ㫠猆ꮷ\ue0d5ᤈ", 14503 - (ViewConfiguration.getJumpTapTimeout() >> 16), objArr3);
        jSONObject.put(((String) objArr3[0]).intern(), bh.b(16, 32));
        bq.c(context, f(context), i(context), jSONObject.toString().getBytes(StandardCharsets.UTF_8));
        j = (h + 39) % 128;
    }

    public static byte[] d(Context context) {
        synchronized (f95898g) {
            try {
                if (d == null) {
                    d = j(context);
                }
            } catch (Throwable th) {
                throw th;
            }
        }
        return bp.b(d);
    }

    /* JADX WARN: Removed duplicated region for block: B:17:0x0020 A[Catch: all -> 0x001a, TryCatch #2 {all -> 0x001a, blocks: (B:4:0x0003, B:6:0x0010, B:27:0x0038, B:28:0x0053, B:30:0x0055, B:17:0x0020, B:19:0x002a, B:22:0x0030, B:26:0x0037, B:12:0x0019, B:15:0x001c, B:24:0x0035, B:8:0x0014), top: B:39:0x0003, inners: #0, #1, #3 }] */
    /* JADX WARN: Removed duplicated region for block: B:40:0x0038 A[EXC_TOP_SPLITTER, SYNTHETIC] */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    private static synchronized com.facetec.sdk.h.b e() {
        /*
            java.lang.Class<com.facetec.sdk.h> r0 = com.facetec.sdk.h.class
            monitor-enter(r0)
            int r1 = com.facetec.sdk.h.j     // Catch: java.lang.Throwable -> L1a
            int r2 = r1 + 11
            int r3 = r2 % 128
            com.facetec.sdk.h.h = r3     // Catch: java.lang.Throwable -> L1a
            int r2 = r2 % 2
            r3 = 0
            if (r2 != 0) goto L1c
            com.facetec.sdk.h r2 = com.facetec.sdk.h.e     // Catch: java.lang.Throwable -> L1a
            r4 = 93
            int r4 = r4 / r3
            if (r2 == 0) goto L38
            goto L20
        L18:
            r1 = move-exception
            throw r1     // Catch: java.lang.Throwable -> L1a
        L1a:
            r1 = move-exception
            goto L5f
        L1c:
            com.facetec.sdk.h r2 = com.facetec.sdk.h.e     // Catch: java.lang.Throwable -> L1a
            if (r2 == 0) goto L38
        L20:
            int r1 = r1 + 7
            int r2 = r1 % 128
            com.facetec.sdk.h.h = r2     // Catch: java.lang.Throwable -> L1a
            int r1 = r1 % 2
            if (r1 == 0) goto L30
            com.facetec.sdk.h r1 = com.facetec.sdk.h.e     // Catch: java.lang.Throwable -> L1a
            com.facetec.sdk.h$b r1 = r1.a     // Catch: java.lang.Throwable -> L1a
            monitor-exit(r0)
            return r1
        L30:
            com.facetec.sdk.h r1 = com.facetec.sdk.h.e     // Catch: java.lang.Throwable -> L1a
            com.facetec.sdk.h$b r1 = r1.a     // Catch: java.lang.Throwable -> L1a
            r1 = 0
            throw r1     // Catch: java.lang.Throwable -> L36
        L36:
            r1 = move-exception
            throw r1     // Catch: java.lang.Throwable -> L1a
        L38:
            java.lang.RuntimeException r1 = new java.lang.RuntimeException     // Catch: java.lang.Throwable -> L1a java.lang.Exception -> L54
            java.lang.String r2 = "ɵ䬖郸\ud9ad✛泡떿̆䢮醶\udf1d⓲涩묞î䦺"
            int r4 = android.view.View.MeasureSpec.getMode(r3)     // Catch: java.lang.Throwable -> L1a java.lang.Exception -> L54
            int r4 = r4 + 18773
            r5 = 1
            java.lang.Object[] r5 = new java.lang.Object[r5]     // Catch: java.lang.Throwable -> L1a java.lang.Exception -> L54
            k(r2, r4, r5)     // Catch: java.lang.Throwable -> L1a java.lang.Exception -> L54
            r2 = r5[r3]     // Catch: java.lang.Throwable -> L1a java.lang.Exception -> L54
            java.lang.String r2 = (java.lang.String) r2     // Catch: java.lang.Throwable -> L1a java.lang.Exception -> L54
            java.lang.String r2 = r2.intern()     // Catch: java.lang.Throwable -> L1a java.lang.Exception -> L54
            r1.<init>(r2)     // Catch: java.lang.Throwable -> L1a java.lang.Exception -> L54
            throw r1     // Catch: java.lang.Throwable -> L1a java.lang.Exception -> L54
        L54:
            r1 = move-exception
            com.facetec.sdk.n.a(r1)     // Catch: java.lang.Throwable -> L1a
            com.facetec.sdk.h$b r1 = new com.facetec.sdk.h$b     // Catch: java.lang.Throwable -> L1a
            r1.<init>()     // Catch: java.lang.Throwable -> L1a
            monitor-exit(r0)
            return r1
        L5f:
            monitor-exit(r0)     // Catch: java.lang.Throwable -> L1a
            throw r1
        */
        throw new UnsupportedOperationException("Method not decompiled: com.facetec.sdk.h.e():com.facetec.sdk.h$b");
    }

    private static String f(Context context) throws Throwable {
        int i2 = h + 83;
        j = i2 % 128;
        if (i2 % 2 == 0) {
            byte[] bArrD = d(context);
            Object[] objArr = new Object[1];
            k("ɼ밒绿㥚\ufb0b떑瑴㘟\uf09f덡淉⾙\uee50", ExpandableListView.getPackedPositionChild(0L) + 48732, objArr);
            return bp.d(bArrD, ((String) objArr[0]).intern());
        }
        byte[] bArrD2 = d(context);
        Object[] objArr2 = new Object[1];
        k("ɼ밒绿㥚\ufb0b떑瑴㘟\uf09f덡淉⾙\uee50", 48732 - ExpandableListView.getPackedPositionChild(0L), objArr2);
        return bp.d(bArrD2, ((String) objArr2[0]).intern());
    }

    private static byte[] i(Context context) throws Throwable {
        int i2 = h + 5;
        j = i2 % 128;
        if (i2 % 2 == 0) {
            byte[] bArrD = d(context);
            Object[] objArr = new Object[1];
            k("ɼ㓂潟ꇪ\ud84bዡ䔔羯똟\ue8b1〈喔資읐", 13963 - ((Process.getThreadPriority(0) + 20) >> 6), objArr);
            return bp.b(bArrD, ((String) objArr[0]).intern());
        }
        byte[] bArrD2 = d(context);
        Process.getThreadPriority(1);
        Object[] objArr2 = new Object[1];
        k("ɼ㓂潟ꇪ\ud84bዡ䔔羯똟\ue8b1〈喔資읐", 31324 % 0, objArr2);
        return bp.b(bArrD2, ((String) objArr2[0]).intern());
    }

    public static void init$0() {
        $$a = new byte[]{104, -2, 24, ISO7816.INS_READ_RECORD_STAMPED};
        $$b = 34;
    }

    private static byte[] j(Context context) throws Throwable {
        byte[] bArrA;
        ContentResolver contentResolver = context.getContentResolver();
        Object[] objArr = new Object[1];
        k("ɇ봅糘㾳ｽ뻎禌㥢\uf827믷", Color.rgb(0, 0, 0) + 16826189, objArr);
        String string = Settings.Secure.getString(contentResolver, ((String) objArr[0]).intern());
        StringBuilder sb = new StringBuilder();
        sb.append(context.getPackageName());
        sb.append(string);
        Object[] objArr2 = new Object[1];
        k("ɇ퓹꼈虴壪㌥\u0a4e\udc8e뜭蹤", (TypedValue.complexToFraction(0, SelfieScan.RECOGNITION_FAIL_RESULT, SelfieScan.RECOGNITION_FAIL_RESULT) > SelfieScan.RECOGNITION_FAIL_RESULT ? 1 : (TypedValue.complexToFraction(0, SelfieScan.RECOGNITION_FAIL_RESULT, SelfieScan.RECOGNITION_FAIL_RESULT) == SelfieScan.RECOGNITION_FAIL_RESULT ? 0 : -1)) + 54959, objArr2);
        sb.append(((String) objArr2[0]).intern());
        String strB = bp.b(sb.toString());
        StringBuilder sb2 = new StringBuilder();
        sb2.append(context.getPackageName());
        sb2.append(string);
        Object[] objArr3 = new Object[1];
        k("ɏ籦︐砫", 32296 - ((byte) KeyEvent.getModifierMetaStateMask()), objArr3);
        sb2.append(((String) objArr3[0]).intern());
        String strB2 = bp.b(sb2.toString());
        try {
            bArrA = bq.a(context, strB);
        } catch (FileNotFoundException unused) {
        }
        if (bArrA.length > 0) {
            int i2 = j + 57;
            h = i2 % 128;
            try {
                if (i2 % 2 != 0) {
                    c = a.values()[bq.c(context, strB2)];
                    return bArrA;
                }
                c = a.values()[bq.c(context, strB2)];
                throw null;
            } catch (Exception unused2) {
                return bArrA;
            }
        }
        j = (h + 89) % 128;
        byte[] bArrA2 = bh.a(32, 128);
        bq.e(context, strB, bArrA2);
        a aVar = a.New;
        c = aVar;
        byte bOrdinal = (byte) aVar.ordinal();
        FileOutputStream fileOutputStreamOpenFileOutput = context.openFileOutput(strB2, 0);
        fileOutputStreamOpenFileOutput.write(bOrdinal);
        fileOutputStreamOpenFileOutput.close();
        return bArrA2;
    }

    /* JADX WARN: Removed duplicated region for block: B:36:0x014d  */
    /* JADX WARN: Removed duplicated region for block: B:37:0x014e  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    private static void k(java.lang.String r21, int r22, java.lang.Object[] r23) throws java.lang.Throwable {
        /*
            Method dump skipped, instruction units count: 343
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: com.facetec.sdk.h.k(java.lang.String, int, java.lang.Object[]):void");
    }

    public static void b() {
        f = -2129626769913977967L;
    }

    public static int a() {
        h = (j + 77) % 128;
        int iIntValue = e().b.intValue();
        j = (h + 7) % 128;
        return iIntValue;
    }

    public static synchronized aa e(Context context) {
        aa aaVar;
        try {
            j = (h + 51) % 128;
            try {
                aaVar = b(context).b;
                int i2 = h + 53;
                j = i2 % 128;
                if (i2 % 2 != 0) {
                    throw null;
                }
            } catch (Exception unused) {
                return new aa(context);
            }
        } catch (Throwable th) {
            throw th;
        }
        return aaVar;
    }

    @SuppressLint({"StaticFieldLeak"})
    public static synchronized void c(Context context, b bVar) {
        h = (j + 67) % 128;
        try {
            h hVarB = b(context);
            hVarB.a = bVar;
            hVarB.c(context);
            int i2 = j + 93;
            h = i2 % 128;
            if (i2 % 2 == 0) {
                int i3 = 44 / 0;
            }
        } catch (Exception e2) {
            n.a(e2);
        }
    }

    public static synchronized void e(Context context, aa aaVar) {
        int i2 = j + 47;
        h = i2 % 128;
        try {
            if (i2 % 2 != 0) {
                h hVarB = b(context);
                hVarB.b = aaVar;
                hVarB.c(context);
            } else {
                h hVarB2 = b(context);
                hVarB2.b = aaVar;
                hVarB2.c(context);
                throw null;
            }
        } catch (Exception e2) {
            n.a(e2);
        }
    }

    public static boolean c() {
        j = (h + 81) % 128;
        if (!bj.f) {
            return e().e.booleanValue();
        }
        j = (h + 115) % 128;
        return true;
    }
}