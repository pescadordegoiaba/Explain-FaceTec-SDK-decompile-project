package com.facetec.sdk;

import ai.luciq.library.logging.LuciqLog;
import ai.luciq.library.networkv2.request.Constants;
import java.io.Closeable;
import java.io.Flushable;
import java.io.IOException;
import java.io.Writer;
import java.math.BigDecimal;
import java.math.BigInteger;
import java.util.Arrays;
import java.util.Objects;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.atomic.AtomicLong;
import java.util.regex.Pattern;

/* JADX INFO: loaded from: classes4.dex */
public class ha implements Closeable, Flushable {
    private static final String[] d;
    private final Writer c;
    private String f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    private boolean f95900g;
    private boolean h;
    private String i;
    private boolean l;
    private String m;
    private static final Pattern b = Pattern.compile("-?(?:0|[1-9][0-9]*)(?:\\.[0-9]+)?(?:[eE][-+]?[0-9]+)?");
    private static final String[] a = new String[128];
    private int[] e = new int[32];
    private int j = 0;

    static {
        for (int i = 0; i <= 31; i++) {
            a[i] = String.format("\\u%04x", Integer.valueOf(i));
        }
        String[] strArr = a;
        strArr[34] = "\\\"";
        strArr[92] = "\\\\";
        strArr[9] = "\\t";
        strArr[8] = "\\b";
        strArr[10] = "\\n";
        strArr[13] = "\\r";
        strArr[12] = "\\f";
        String[] strArr2 = (String[]) strArr.clone();
        d = strArr2;
        strArr2[60] = "\\u003c";
        strArr2[62] = "\\u003e";
        strArr2[38] = "\\u0026";
        strArr2[61] = "\\u003d";
        strArr2[39] = "\\u0027";
    }

    public ha(Writer writer) {
        d(6);
        this.f = Constants.SEPARATOR;
        this.l = true;
        Objects.requireNonNull(writer, "out == null");
        this.c = writer;
    }

    private void i() throws IOException {
        if (this.m != null) {
            l();
            a(this.m);
            this.m = null;
        }
    }

    private void k() throws IOException {
        if (this.i == null) {
            return;
        }
        this.c.write(10);
        int i = this.j;
        for (int i2 = 1; i2 < i; i2++) {
            this.c.write(this.i);
        }
    }

    private void l() throws IOException {
        int iD = d();
        if (iD == 5) {
            this.c.write(44);
        } else if (iD != 3) {
            throw new IllegalStateException("Nesting problem.");
        }
        k();
        a(4);
    }

    private void o() throws IOException {
        int iD = d();
        if (iD == 1) {
            a(2);
            k();
            return;
        }
        if (iD == 2) {
            this.c.append(',');
            k();
        } else {
            if (iD == 4) {
                this.c.append((CharSequence) this.f);
                a(5);
                return;
            }
            if (iD != 6) {
                if (iD != 7) {
                    throw new IllegalStateException("Nesting problem.");
                }
                if (!this.f95900g) {
                    throw new IllegalStateException("JSON must have only one top-level value.");
                }
            }
            a(7);
        }
    }

    public final void a(boolean z) {
        this.f95900g = z;
    }

    public ha b() {
        return b(3, 5, '}');
    }

    public final void c(boolean z) {
        this.l = z;
    }

    @Override // java.io.Closeable, java.lang.AutoCloseable
    public void close() throws IOException {
        this.c.close();
        int i = this.j;
        if (i > 1 || (i == 1 && this.e[i - 1] != 7)) {
            throw new IOException("Incomplete document");
        }
        this.j = 0;
    }

    public final void d(String str) {
        if (str.length() == 0) {
            this.i = null;
            this.f = Constants.SEPARATOR;
        } else {
            this.i = str;
            this.f = ": ";
        }
    }

    public final void e(boolean z) {
        this.h = z;
    }

    public final boolean f() {
        return this.l;
    }

    public void flush() throws IOException {
        if (this.j == 0) {
            throw new IllegalStateException("JsonWriter is closed.");
        }
        this.c.flush();
    }

    public ha g() {
        if (this.m != null) {
            if (!this.l) {
                this.m = null;
                return this;
            }
            i();
        }
        o();
        this.c.write(LuciqLog.LogMessage.NULL_LOG);
        return this;
    }

    public final boolean h() {
        return this.h;
    }

    public final boolean j() {
        return this.f95900g;
    }

    private ha b(int i, int i2, char c) throws IOException {
        int iD = d();
        if (iD != i2 && iD != i) {
            throw new IllegalStateException("Nesting problem.");
        }
        if (this.m != null) {
            StringBuilder sb = new StringBuilder("Dangling name: ");
            sb.append(this.m);
            throw new IllegalStateException(sb.toString());
        }
        this.j--;
        if (iD == i2) {
            k();
        }
        this.c.write(c);
        return this;
    }

    public ha a() {
        return b(1, 2, ']');
    }

    public ha c() {
        i();
        return c(3, '{');
    }

    public ha e() {
        i();
        return c(1, '[');
    }

    private void a(int i) {
        this.e[this.j - 1] = i;
    }

    /* JADX WARN: Removed duplicated region for block: B:20:0x0034  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    private void a(java.lang.String r9) throws java.io.IOException {
        /*
            r8 = this;
            boolean r0 = r8.h
            if (r0 == 0) goto L7
            java.lang.String[] r0 = com.facetec.sdk.ha.d
            goto L9
        L7:
            java.lang.String[] r0 = com.facetec.sdk.ha.a
        L9:
            java.io.Writer r1 = r8.c
            r2 = 34
            r1.write(r2)
            int r1 = r9.length()
            r3 = 0
            r4 = r3
        L16:
            if (r3 >= r1) goto L45
            char r5 = r9.charAt(r3)
            r6 = 128(0x80, float:1.8E-43)
            if (r5 >= r6) goto L25
            r5 = r0[r5]
            if (r5 != 0) goto L32
            goto L42
        L25:
            r6 = 8232(0x2028, float:1.1535E-41)
            if (r5 != r6) goto L2c
            java.lang.String r5 = "\\u2028"
            goto L32
        L2c:
            r6 = 8233(0x2029, float:1.1537E-41)
            if (r5 != r6) goto L42
            java.lang.String r5 = "\\u2029"
        L32:
            if (r4 >= r3) goto L3b
            java.io.Writer r6 = r8.c
            int r7 = r3 - r4
            r6.write(r9, r4, r7)
        L3b:
            java.io.Writer r4 = r8.c
            r4.write(r5)
            int r4 = r3 + 1
        L42:
            int r3 = r3 + 1
            goto L16
        L45:
            if (r4 >= r1) goto L4d
            java.io.Writer r0 = r8.c
            int r1 = r1 - r4
            r0.write(r9, r4, r1)
        L4d:
            java.io.Writer r9 = r8.c
            r9.write(r2)
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: com.facetec.sdk.ha.a(java.lang.String):void");
    }

    private ha c(int i, char c) throws IOException {
        o();
        d(i);
        this.c.write(c);
        return this;
    }

    public ha e(String str) {
        if (str == null) {
            return g();
        }
        i();
        o();
        a(str);
        return this;
    }

    private void d(int i) {
        int i2 = this.j;
        int[] iArr = this.e;
        if (i2 == iArr.length) {
            this.e = Arrays.copyOf(iArr, i2 << 1);
        }
        int[] iArr2 = this.e;
        int i3 = this.j;
        this.j = i3 + 1;
        iArr2[i3] = i;
    }

    public ha c(String str) {
        Objects.requireNonNull(str, "name == null");
        if (this.m == null) {
            if (this.j != 0) {
                this.m = str;
                return this;
            }
            throw new IllegalStateException("JsonWriter is closed.");
        }
        throw new IllegalStateException();
    }

    public ha e(Boolean bool) {
        if (bool == null) {
            return g();
        }
        i();
        o();
        this.c.write(bool.booleanValue() ? "true" : "false");
        return this;
    }

    private int d() {
        int i = this.j;
        if (i != 0) {
            return this.e[i - 1];
        }
        throw new IllegalStateException("JsonWriter is closed.");
    }

    public ha b(boolean z) {
        i();
        o();
        this.c.write(z ? "true" : "false");
        return this;
    }

    public ha b(Number number) {
        if (number == null) {
            return g();
        }
        i();
        String string = number.toString();
        if (!string.equals("-Infinity") && !string.equals("Infinity") && !string.equals("NaN")) {
            Class<?> cls = number.getClass();
            if (cls != Integer.class && cls != Long.class && cls != Double.class && cls != Float.class && cls != Byte.class && cls != Short.class && cls != BigDecimal.class && cls != BigInteger.class && cls != AtomicInteger.class && cls != AtomicLong.class && !b.matcher(string).matches()) {
                StringBuilder sb = new StringBuilder("String created by ");
                sb.append(cls);
                sb.append(" is not a valid JSON number: ");
                sb.append(string);
                throw new IllegalArgumentException(sb.toString());
            }
        } else if (!this.f95900g) {
            throw new IllegalArgumentException("Numeric values must be finite, but was ".concat(string));
        }
        o();
        this.c.append((CharSequence) string);
        return this;
    }

    public ha d(long j) {
        i();
        o();
        this.c.write(Long.toString(j));
        return this;
    }

    public ha e(double d2) {
        i();
        if (!this.f95900g && (Double.isNaN(d2) || Double.isInfinite(d2))) {
            throw new IllegalArgumentException("Numeric values must be finite, but was ".concat(String.valueOf(d2)));
        }
        o();
        this.c.append((CharSequence) Double.toString(d2));
        return this;
    }
}