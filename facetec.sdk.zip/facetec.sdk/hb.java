package com.facetec.sdk;

import org.bouncycastle.asn1.cmc.BodyPartID;

/* JADX INFO: loaded from: classes4.dex */
public final class hb {
    public static long[] e(int i, int i2) {
        long[] jArr = new long[4];
        jArr[0] = (((long) i2) & BodyPartID.bodyIdMax) | ((((long) i) & BodyPartID.bodyIdMax) << 32);
        for (int i3 = 1; i3 < 4; i3++) {
            long j = jArr[i3 - 1];
            jArr[i3] = ((j ^ (j >> 30)) * 1812433253) + ((long) i3);
        }
        return jArr;
    }
}