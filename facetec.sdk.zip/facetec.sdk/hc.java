package com.facetec.sdk;

/* JADX INFO: loaded from: classes4.dex */
public final class hc {
    public int a;
    public int c;
    public int d;
}