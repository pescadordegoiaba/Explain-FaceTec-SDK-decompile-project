package com.facetec.sdk;

/* JADX INFO: loaded from: classes4.dex */
public final class hd {
    public int d;
}