package com.facetec.sdk;

import java.io.BufferedInputStream;
import java.io.FilterInputStream;
import java.io.IOException;
import java.io.InputStream;

/* JADX INFO: loaded from: classes4.dex */
public final class he extends FilterInputStream {
    private final int a;
    private int b;
    private final int c;
    private final int d;
    private gy e;
    private byte[] f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    private int[] f95901g;
    private byte[] h;
    private byte[] i;
    private int j;
    private int l;
    private int m;
    private int o;

    public he(InputStream inputStream, int[] iArr, byte[] bArr, int i, boolean z, int i2) {
        this(inputStream, iArr, bArr, i, false, i2, (byte) 0);
    }

    private void a() {
        int i = this.b;
        if (i < this.c) {
            this.b = i + 1;
        } else {
            this.b = 1;
        }
    }

    private void c() {
        if (this.o == 2) {
            byte[] bArr = this.f;
            System.arraycopy(bArr, 0, this.h, 0, bArr.length);
        }
        byte[] bArr2 = this.f;
        int i = ((bArr2[0] << 24) & (-16777216)) + ((bArr2[1] << 16) & 16711680) + ((bArr2[2] << 8) & 65280) + (bArr2[3] & 255);
        int i2 = ((-16777216) & (bArr2[4] << 24)) + (16711680 & (bArr2[5] << 16)) + (65280 & (bArr2[6] << 8)) + (bArr2[7] & 255);
        int i3 = this.a;
        gy gyVar = this.e;
        gx.c(i, i2, false, i3, gyVar.d, gyVar.b, this.f95901g);
        int[] iArr = this.f95901g;
        int i4 = iArr[0];
        int i5 = iArr[1];
        byte[] bArr3 = this.f;
        bArr3[0] = (byte) (i4 >> 24);
        bArr3[1] = (byte) (i4 >> 16);
        bArr3[2] = (byte) (i4 >> 8);
        bArr3[3] = (byte) i4;
        bArr3[4] = (byte) (i5 >> 24);
        bArr3[5] = (byte) (i5 >> 16);
        bArr3[6] = (byte) (i5 >> 8);
        bArr3[7] = (byte) i5;
        if (this.o == 2) {
            for (int i6 = 0; i6 < 8; i6++) {
                byte[] bArr4 = this.f;
                bArr4[i6] = (byte) (bArr4[i6] ^ this.i[i6]);
            }
            byte[] bArr5 = this.h;
            System.arraycopy(bArr5, 0, this.i, 0, bArr5.length);
        }
    }

    private int e() throws IOException {
        if (this.m == Integer.MAX_VALUE) {
            this.m = ((FilterInputStream) this).in.read();
        }
        if (this.j == 8) {
            byte[] bArr = this.f;
            int i = this.m;
            bArr[0] = (byte) i;
            if (i < 0) {
                throw new IllegalStateException("unexpected block size");
            }
            int i2 = 1;
            do {
                int i3 = ((FilterInputStream) this).in.read(this.f, i2, 8 - i2);
                if (i3 <= 0) {
                    break;
                }
                i2 += i3;
            } while (i2 < 8);
            if (i2 < 8) {
                throw new IllegalStateException("unexpected block size");
            }
            int i4 = this.d;
            if (i4 == this.c) {
                c();
            } else {
                if (this.b <= i4) {
                    c();
                }
                a();
            }
            int i5 = ((FilterInputStream) this).in.read();
            this.m = i5;
            this.j = 0;
            this.l = i5 < 0 ? 8 - (this.f[7] & 255) : 8;
        }
        return this.l;
    }

    @Override // java.io.FilterInputStream, java.io.InputStream
    public final int available() throws IOException {
        e();
        return this.l - this.j;
    }

    @Override // java.io.FilterInputStream, java.io.InputStream
    public final boolean markSupported() {
        return false;
    }

    @Override // java.io.FilterInputStream, java.io.InputStream
    public final int read() throws IOException {
        e();
        int i = this.j;
        if (i >= this.l) {
            return -1;
        }
        byte[] bArr = this.f;
        this.j = i + 1;
        return bArr[i] & 255;
    }

    @Override // java.io.FilterInputStream, java.io.InputStream
    public final long skip(long j) {
        long j2 = 0;
        while (j2 < j && read() != -1) {
            j2++;
        }
        return j2;
    }

    private he(InputStream inputStream, int[] iArr, byte[] bArr, int i, boolean z, int i2, byte b) {
        super(new BufferedInputStream(inputStream, 4096));
        this.b = 1;
        this.m = Integer.MAX_VALUE;
        int iMin = Math.min(Math.max(i, 3), 16);
        this.a = iMin;
        this.f = new byte[8];
        byte[] bArr2 = new byte[8];
        this.i = bArr2;
        this.h = new byte[8];
        this.f95901g = new int[2];
        this.j = 8;
        this.l = 8;
        this.o = i2;
        if (i2 == 2) {
            System.arraycopy(bArr, 0, bArr2, 0, 8);
        }
        this.e = new gy(iArr, iMin, true, z);
        this.d = 100;
        this.c = 100;
    }

    @Override // java.io.FilterInputStream, java.io.InputStream
    public final int read(byte[] bArr, int i, int i2) throws IOException {
        int i3 = i + i2;
        for (int i4 = i; i4 < i3; i4++) {
            e();
            int i5 = this.j;
            if (i5 >= this.l) {
                if (i4 == i) {
                    return -1;
                }
                return i2 - (i3 - i4);
            }
            byte[] bArr2 = this.f;
            this.j = i5 + 1;
            bArr[i4] = bArr2[i5];
        }
        return i2;
    }
}