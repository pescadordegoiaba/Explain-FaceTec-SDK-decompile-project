package com.facetec.sdk;

import java.io.BufferedInputStream;
import java.io.FilterInputStream;
import java.io.IOException;
import java.io.InputStream;

/* JADX INFO: loaded from: classes4.dex */
public final class hf extends FilterInputStream {
    private final int a;
    private final int b;
    private final int c;
    private int d;
    private long[] e;
    private int f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    private int f95902g;
    private long[] h;
    private short i;
    private byte[] j;
    private int n;

    public hf(InputStream inputStream, int i, int i2, short s, int i3, int i4) {
        this(inputStream, i, i2, s, i3, i4, (byte) 0);
    }

    private void a() {
        int i = this.d;
        if (i < this.b) {
            this.d = i + 1;
        } else {
            this.d = 1;
        }
    }

    private void b() {
        long[] jArr = this.e;
        long[] jArr2 = this.h;
        short s = this.i;
        long j = jArr[s % 4] * 2147483085;
        long j2 = jArr2[(s + 2) % 4];
        int i = (s + 3) % 4;
        jArr2[i] = ((jArr[i] * 2147483085) + j2) / 2147483647L;
        jArr[i] = (j + j2) % 2147483647L;
        for (int i2 = 0; i2 < this.a; i2++) {
            this.j[i2] = (byte) (((long) r1[i2]) ^ ((this.e[this.i] >> (i2 << 3)) & 255));
        }
        this.i = (short) ((this.i + 1) % 4);
    }

    private int c() throws IOException {
        int i;
        if (this.f95902g == Integer.MAX_VALUE) {
            this.f95902g = ((FilterInputStream) this).in.read();
        }
        if (this.f == this.a) {
            byte[] bArr = this.j;
            int i2 = this.f95902g;
            bArr[0] = (byte) i2;
            if (i2 < 0) {
                throw new IllegalStateException("unexpected block size");
            }
            int i3 = 1;
            do {
                int i4 = ((FilterInputStream) this).in.read(this.j, i3, this.a - i3);
                if (i4 <= 0) {
                    break;
                }
                i3 += i4;
            } while (i3 < this.a);
            if (i3 < this.a) {
                throw new IllegalStateException("unexpected block size");
            }
            int i5 = this.c;
            if (i5 == this.b) {
                b();
            } else {
                if (this.d <= i5) {
                    b();
                }
                a();
            }
            int i6 = ((FilterInputStream) this).in.read();
            this.f95902g = i6;
            this.f = 0;
            if (i6 < 0) {
                int i7 = this.a;
                i = i7 - (this.j[i7 - 1] & 255);
            } else {
                i = this.a;
            }
            this.n = i;
        }
        return this.n;
    }

    @Override // java.io.FilterInputStream, java.io.InputStream
    public final int available() throws IOException {
        c();
        return this.n - this.f;
    }

    @Override // java.io.FilterInputStream, java.io.InputStream
    public final boolean markSupported() {
        return false;
    }

    @Override // java.io.FilterInputStream, java.io.InputStream
    public final int read() throws IOException {
        c();
        int i = this.f;
        if (i >= this.n) {
            return -1;
        }
        byte[] bArr = this.j;
        this.f = i + 1;
        return bArr[i] & 255;
    }

    @Override // java.io.FilterInputStream, java.io.InputStream
    public final long skip(long j) {
        long j2 = 0;
        while (j2 < j && read() != -1) {
            j2++;
        }
        return j2;
    }

    private hf(InputStream inputStream, int i, int i2, short s, int i3, int i4, byte b) {
        super(new BufferedInputStream(inputStream, 4096));
        this.d = 1;
        this.f95902g = Integer.MAX_VALUE;
        int iMin = Math.min(Math.max((int) s, 4), 8);
        this.a = iMin;
        this.j = new byte[iMin];
        this.e = new long[4];
        this.h = new long[4];
        this.f = iMin;
        this.n = iMin;
        this.e = hb.e(i ^ i4, iMin ^ i4);
        this.h = hb.e(i2 ^ i4, i3 ^ i4);
        this.c = 100;
        this.b = 100;
    }

    @Override // java.io.FilterInputStream, java.io.InputStream
    public final int read(byte[] bArr, int i, int i2) throws IOException {
        int i3 = i + i2;
        for (int i4 = i; i4 < i3; i4++) {
            c();
            int i5 = this.f;
            if (i5 >= this.n) {
                if (i4 == i) {
                    return -1;
                }
                return i2 - (i3 - i4);
            }
            byte[] bArr2 = this.j;
            this.f = i5 + 1;
            bArr[i4] = bArr2[i5];
        }
        return i2;
    }
}