package com.facetec.sdk;

/* JADX INFO: loaded from: classes4.dex */
public final class hh {
    public int b;
    public char c;
    public int d;
    public char e;
}