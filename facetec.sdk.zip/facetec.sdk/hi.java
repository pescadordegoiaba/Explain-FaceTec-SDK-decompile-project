package com.facetec.sdk;

/* JADX INFO: loaded from: classes4.dex */
public final class hi {
    public int d;
    public char e;
}