package com.facetec.sdk;

/* JADX INFO: loaded from: classes4.dex */
public final class hj {
    public int b;
    public int e;
}