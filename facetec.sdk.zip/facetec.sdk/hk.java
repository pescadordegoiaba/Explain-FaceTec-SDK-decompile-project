package com.facetec.sdk;

/* JADX INFO: loaded from: classes4.dex */
public final class hk {
    public int a;
}