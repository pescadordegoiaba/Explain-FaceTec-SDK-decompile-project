package com.facetec.sdk;

/* JADX INFO: loaded from: classes4.dex */
public final class hm implements ff {
    private static final hv d = new hv();
    private static final hs a = new hs();

    @Override // com.facetec.sdk.ff
    public final <T> fg<T> b(el elVar, gu<T> guVar) {
        try {
            if (guVar.d() == q.class) {
                return new ci(elVar, d, a);
            }
        } catch (NoClassDefFoundError unused) {
        }
        try {
            if (EnumC39477r.class.isAssignableFrom(guVar.d())) {
                return new cl(elVar, d, a);
            }
            return null;
        } catch (NoClassDefFoundError unused2) {
            return null;
        }
    }
}