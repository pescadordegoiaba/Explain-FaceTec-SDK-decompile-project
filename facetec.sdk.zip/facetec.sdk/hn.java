package com.facetec.sdk;

/* JADX INFO: loaded from: classes4.dex */
public final class hn {
    public int b;
    public int c;
}