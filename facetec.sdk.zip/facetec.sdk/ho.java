package com.facetec.sdk;

/* JADX INFO: loaded from: classes4.dex */
public final class ho {
    public int a;
    public int b;
    public int c;
    public char d;
    public char e;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public int f95903g;
    public int j;
}