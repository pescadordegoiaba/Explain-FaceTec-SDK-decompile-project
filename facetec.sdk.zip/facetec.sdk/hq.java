package com.facetec.sdk;

/* JADX INFO: loaded from: classes4.dex */
public final class hq {
    public int d;
}