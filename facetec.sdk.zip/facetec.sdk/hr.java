package com.facetec.sdk;

/* JADX INFO: loaded from: classes4.dex */
public interface hr {
    int a(gs gsVar);

    int b(gs gsVar);
}