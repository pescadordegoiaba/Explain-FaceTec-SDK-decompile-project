package com.facetec.sdk;

import android.graphics.Color;
import android.graphics.drawable.Drawable;
import android.os.Process;
import android.os.SystemClock;
import android.telephony.cdma.CdmaCellLocation;
import android.text.TextUtils;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.View;
import android.view.ViewConfiguration;
import android.widget.ExpandableListView;
import java.lang.reflect.Method;
import net.sf.scuba.smartcards.ISO7816;
import org.jmrtd.PassportService;

/* JADX INFO: loaded from: classes4.dex */
public final class hs implements hu {
    private static final byte[] $$a = null;
    private static final int $$b = 0;
    private static final String[] a;
    private static long c;
    private static char d;
    private static char[] e;

    /* JADX WARN: Removed duplicated region for block: B:10:0x0023  */
    /* JADX WARN: Removed duplicated region for block: B:8:0x001d  */
    /* JADX WARN: Unsupported multi-entry loop pattern (BACK_EDGE: B:10:0x0023 -> B:11:0x0027). Please report as a decompilation issue!!! */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    private static java.lang.String $$c(byte r5, short r6, byte r7) {
        /*
            byte[] r0 = com.facetec.sdk.hs.$$a
            int r6 = r6 * 3
            int r6 = r6 + 4
            int r5 = r5 + 99
            int r7 = r7 * 2
            int r1 = 1 - r7
            byte[] r1 = new byte[r1]
            r2 = 0
            int r7 = 0 - r7
            if (r0 != 0) goto L17
            r4 = r5
            r5 = r7
            r3 = r2
            goto L27
        L17:
            r3 = r2
        L18:
            byte r4 = (byte) r5
            r1[r3] = r4
            if (r3 != r7) goto L23
            java.lang.String r5 = new java.lang.String
            r5.<init>(r1, r2)
            return r5
        L23:
            int r3 = r3 + 1
            r4 = r0[r6]
        L27:
            int r6 = r6 + 1
            int r5 = r5 + r4
            goto L18
        */
        throw new UnsupportedOperationException("Method not decompiled: com.facetec.sdk.hs.$$c(byte, short, byte):java.lang.String");
    }

    static {
        init$0();
        a();
        Object[] objArr = new Object[1];
        b("ⱼ눷ლ", 40530 - (ViewConfiguration.getZoomControlsTimeout() > 0L ? 1 : (ViewConfiguration.getZoomControlsTimeout() == 0L ? 0 : -1)), objArr);
        String[] strArr = {(String) objArr[0], (String) objArr[0], (String) objArr[0], (String) objArr[0], (String) objArr[0], (String) objArr[0], (String) objArr[0], (String) objArr[0], (String) objArr[0], (String) objArr[0], (String) objArr[0], (String) objArr[0], (String) objArr[0]};
        Object[] objArr2 = new Object[1];
        b("ⱼ杗먘", View.resolveSize(0, 0) + 19249, objArr2);
        Object[] objArr3 = new Object[1];
        b("Ɒ\u0892斍䊥뾳钑\uf1ce⻕\u0bce惩巠뫷", Gravity.getAbsoluteGravity(0, 0) + 9461, objArr3);
        Object[] objArr4 = new Object[1];
        b("Ɒﺼ觩启来㆚\udcd2\uef01멃䒞ក⋽촲顽ꪞ痓\u000b퍫ﶏ", 53958 - TextUtils.indexOf((CharSequence) "", '0'), objArr4);
        Object[] objArr5 = new Object[1];
        b("ⱼꂻ㗦諬Ἀ\uec30慒\uf67f䪑\udf99곳ℹ똪୍顭河\ue1b5盔쯰堓ⴵ", 36061 - (ViewConfiguration.getJumpTapTimeout() >> 16), objArr5);
        Object[] objArr6 = new Object[1];
        f((byte) (68 - TextUtils.getOffsetBefore("", 0)), ExpandableListView.getPackedPositionChild(0L) + 3, "\u0006\u000f", objArr6);
        Object[] objArr7 = new Object[1];
        f((byte) ((ViewConfiguration.getTouchSlop() >> 8) + 54), 4 - (ViewConfiguration.getDoubleTapTimeout() >> 16), "\u0002\u0005\u000e\u0002", objArr7);
        Object[] objArr8 = new Object[1];
        f((byte) (TextUtils.indexOf((CharSequence) "", '0', 0, 0) + 91), Drawable.resolveOpacity(0, 0) + 14, "\u000f\b\n\u000e\f\u0003\r\u0002\b\u0007\u0001\u000e\t\u0004", objArr8);
        Object[] objArr9 = new Object[1];
        b("ⱼબ懼壡뜀\uee2a앿㱷\u1a9c熷꣙蜅︺하౪檅䆌룜", 9949 - KeyEvent.normalizeMetaState(0), objArr9);
        Object[] objArr10 = new Object[1];
        b("ⱱ喏\udf92䆫쮷䷅\uf7d4秄\ue3e4旽\uef3eᄔ鬝ᴭ蜾ौ덷㕓뽷Ⅾꪐⲹ嚘\ud8b5䊳쓚", (SystemClock.uptimeMillis() > 0L ? 1 : (SystemClock.uptimeMillis() == 0L ? 0 : -1)) + 31218, objArr10);
        Object[] objArr11 = new Object[1];
        f((byte) (11 - (CdmaCellLocation.convertQuartSecToDecDegrees(0) > 0.0d ? 1 : (CdmaCellLocation.convertQuartSecToDecDegrees(0) == 0.0d ? 0 : -1))), 19 - View.MeasureSpec.getSize(0), "\u000f\b\n\u000e\f\u0003\r\u0002\b\u0007\u0001\u0007㗴㗴\b\u0003\r\u000b㘉", objArr11);
        Object[] objArr12 = new Object[1];
        f((byte) ((ViewConfiguration.getMaximumDrawingCacheSize() >> 24) + 44), 12 - KeyEvent.getDeadChar(0, 0), "\u000f\b\n\u000e\f\u0003\r\u0002\b\u0007\b\r", objArr12);
        Object[] objArr13 = new Object[1];
        b("Ɀⶁ⾴⧎", Color.rgb(0, 0, 0) + 16777703, objArr13);
        a = strArr;
    }

    /* JADX WARN: Removed duplicated region for block: B:32:0x0126  */
    /* JADX WARN: Removed duplicated region for block: B:33:0x0127  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    private static void b(java.lang.String r23, int r24, java.lang.Object[] r25) throws java.lang.Throwable {
        /*
            Method dump skipped, instruction units count: 304
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: com.facetec.sdk.hs.b(java.lang.String, int, java.lang.Object[]):void");
    }

    private static void f(byte b, int i, String str, Object[] objArr) throws Throwable {
        int i2;
        char c2;
        char c3;
        char c4;
        char c5;
        char c6;
        char[] charArray = str != null ? str.toCharArray() : str;
        ho hoVar = new ho();
        char[] cArr = e;
        Class cls = Integer.TYPE;
        int i3 = 17;
        int i4 = 0;
        if (cArr != null) {
            int length = cArr.length;
            char[] cArr2 = new char[length];
            int i5 = 0;
            while (i5 < length) {
                try {
                    Object[] objArr2 = {Integer.valueOf(cArr[i5])};
                    Object objD = an.d(-1584280535);
                    if (objD == null) {
                        byte b2 = (byte) i3;
                        byte b3 = (byte) i4;
                        objD = an.d(2158 - TextUtils.getOffsetBefore("", i4), (char) (1 - (SystemClock.uptimeMillis() > 0L ? 1 : (SystemClock.uptimeMillis() == 0L ? 0 : -1))), KeyEvent.keyCodeFromString("") + 23, -672129166, false, $$c(b2, b3, b3), new Class[]{cls});
                    }
                    cArr2[i5] = ((Character) ((Method) objD).invoke(null, objArr2)).charValue();
                    i5++;
                    i3 = 17;
                    i4 = 0;
                } catch (Throwable th) {
                    Throwable cause = th.getCause();
                    if (cause == null) {
                        throw th;
                    }
                    throw cause;
                }
            }
            cArr = cArr2;
        }
        Object[] objArr3 = {Integer.valueOf(d)};
        Object objD2 = an.d(-1584280535);
        char c7 = '\b';
        if (objD2 == null) {
            byte b4 = (byte) 0;
            objD2 = an.d(2158 - (ViewConfiguration.getJumpTapTimeout() >> 16), (char) (ViewConfiguration.getKeyRepeatTimeout() >> 16), (ViewConfiguration.getTouchSlop() >> 8) + 23, -672129166, false, $$c((byte) 17, b4, b4), new Class[]{cls});
        }
        char cCharValue = ((Character) ((Method) objD2).invoke(null, objArr3)).charValue();
        char[] cArr3 = new char[i];
        if (i % 2 != 0) {
            i2 = i - 1;
            cArr3[i2] = (char) (charArray[i2] - b);
        } else {
            i2 = i;
        }
        if (i2 > 1) {
            hoVar.b = 0;
            while (true) {
                int i6 = hoVar.b;
                if (i6 >= i2) {
                    break;
                }
                char c8 = charArray[i6];
                hoVar.d = c8;
                char c9 = charArray[i6 + 1];
                hoVar.e = c9;
                if (c8 == c9) {
                    cArr3[i6] = (char) (c8 - b);
                    cArr3[i6 + 1] = (char) (c9 - b);
                    c2 = c7;
                } else {
                    Object[] objArr4 = new Object[13];
                    objArr4[12] = hoVar;
                    objArr4[11] = Integer.valueOf(cCharValue);
                    objArr4[10] = hoVar;
                    objArr4[9] = hoVar;
                    objArr4[c7] = Integer.valueOf(cCharValue);
                    objArr4[7] = hoVar;
                    objArr4[6] = hoVar;
                    objArr4[5] = Integer.valueOf(cCharValue);
                    objArr4[4] = hoVar;
                    objArr4[3] = hoVar;
                    objArr4[2] = Integer.valueOf(cCharValue);
                    objArr4[1] = hoVar;
                    c2 = c7;
                    objArr4[0] = hoVar;
                    Object objD3 = an.d(945118461);
                    if (objD3 == null) {
                        c3 = '\n';
                        int iNormalizeMetaState = KeyEvent.normalizeMetaState(0) + 2356;
                        c4 = 2;
                        char c10 = (char) (1 - (ViewConfiguration.getZoomControlsTimeout() > 0L ? 1 : (ViewConfiguration.getZoomControlsTimeout() == 0L ? 0 : -1)));
                        int iGreen = Color.green(0) + 23;
                        c5 = '\t';
                        c6 = 7;
                        byte b5 = (byte) 0;
                        String str$$c = $$c($$a[0], b5, b5);
                        Class cls2 = Integer.TYPE;
                        objD3 = an.d(iNormalizeMetaState, c10, iGreen, 1312067494, false, str$$c, new Class[]{Object.class, Object.class, cls2, Object.class, Object.class, cls2, Object.class, Object.class, cls2, Object.class, Object.class, cls2, Object.class});
                    } else {
                        c3 = '\n';
                        c4 = 2;
                        c5 = '\t';
                        c6 = 7;
                    }
                    int iIntValue = ((Integer) ((Method) objD3).invoke(null, objArr4)).intValue();
                    int i7 = hoVar.f95903g;
                    if (iIntValue == i7) {
                        Object[] objArr5 = new Object[11];
                        objArr5[c3] = hoVar;
                        objArr5[c5] = Integer.valueOf(cCharValue);
                        objArr5[c2] = hoVar;
                        objArr5[c6] = Integer.valueOf(cCharValue);
                        objArr5[6] = Integer.valueOf(cCharValue);
                        objArr5[5] = hoVar;
                        objArr5[4] = hoVar;
                        objArr5[3] = Integer.valueOf(cCharValue);
                        objArr5[c4] = Integer.valueOf(cCharValue);
                        objArr5[1] = hoVar;
                        objArr5[0] = hoVar;
                        Object objD4 = an.d(-1909092408);
                        if (objD4 == null) {
                            int threadPriority = ((Process.getThreadPriority(0) + 20) >> 6) + 24;
                            byte b6 = (byte) 0;
                            String str$$c2 = $$c((byte) ($$a[0] - 1), b6, b6);
                            Class cls3 = Integer.TYPE;
                            objD4 = an.d(TextUtils.getCapsMode("", 0, 0) + 877, (char) ((SystemClock.elapsedRealtime() > 0L ? 1 : (SystemClock.elapsedRealtime() == 0L ? 0 : -1)) - 1), threadPriority, -128689005, false, str$$c2, new Class[]{Object.class, Object.class, cls3, cls3, Object.class, Object.class, cls3, cls3, Object.class, cls3, Object.class});
                        }
                        int iIntValue2 = ((Integer) ((Method) objD4).invoke(null, objArr5)).intValue();
                        int i8 = (hoVar.a * cCharValue) + hoVar.f95903g;
                        int i9 = hoVar.b;
                        cArr3[i9] = cArr[iIntValue2];
                        cArr3[i9 + 1] = cArr[i8];
                    } else {
                        int i10 = hoVar.c;
                        int i11 = hoVar.a;
                        if (i10 == i11) {
                            int i12 = ((hoVar.j + cCharValue) - 1) % cCharValue;
                            hoVar.j = i12;
                            int i13 = ((i7 + cCharValue) - 1) % cCharValue;
                            hoVar.f95903g = i13;
                            int i14 = (i11 * cCharValue) + i13;
                            int i15 = hoVar.b;
                            cArr3[i15] = cArr[(i10 * cCharValue) + i12];
                            cArr3[i15 + 1] = cArr[i14];
                        } else {
                            int i16 = (i10 * cCharValue) + i7;
                            int i17 = (i11 * cCharValue) + hoVar.j;
                            int i18 = hoVar.b;
                            cArr3[i18] = cArr[i16];
                            cArr3[i18 + 1] = cArr[i17];
                            hoVar.b += 2;
                            c7 = c2;
                        }
                    }
                }
                hoVar.b += 2;
                c7 = c2;
            }
        }
        for (int i19 = 0; i19 < i; i19++) {
            cArr3[i19] = (char) (cArr3[i19] ^ 13722);
        }
        objArr[0] = new String(cArr3);
    }

    public static void init$0() {
        $$a = new byte[]{PassportService.SFI_DG15, -57, ISO7816.INS_UPDATE_BINARY, 5};
        $$b = 131;
    }

    @Override // com.facetec.sdk.hu
    public final void a(ha haVar, int i) {
        haVar.c(a[i]);
    }

    @Override // com.facetec.sdk.hu
    public final void e(ha haVar, int i) {
        haVar.e(a[i]);
    }

    public static void a() {
        c = 1742708327156895138L;
        e = new char[]{15086, 15093, 15061, 15058, 15074, 15076, 15072, 15079, 15089, 15048, 15078, 15080, 15077, 15096, 15090, 15087};
        d = (char) 3871;
    }
}