package com.facetec.sdk;

import com.facetec.sdk.gm;
import java.lang.reflect.Type;
import java.lang.reflect.TypeVariable;

/* JADX INFO: loaded from: classes4.dex */
public final class ht {
    public static Type a(Type type, Object obj) {
        return obj != null ? (type == Object.class || (type instanceof TypeVariable) || (type instanceof Class)) ? obj.getClass() : type : type;
    }

    public static boolean b(fg fgVar) {
        return ((fgVar instanceof hp) || (fgVar instanceof gm.a)) ? false : true;
    }
}