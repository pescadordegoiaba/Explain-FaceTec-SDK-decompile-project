package com.facetec.sdk;

/* JADX INFO: loaded from: classes4.dex */
public interface hu {
    void a(ha haVar, int i);

    void e(ha haVar, int i);
}