package com.facetec.sdk;

import android.graphics.Color;
import android.graphics.ImageFormat;
import android.media.AudioTrack;
import android.os.Process;
import android.os.SystemClock;
import android.text.TextUtils;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.View;
import android.view.ViewConfiguration;
import android.widget.ExpandableListView;
import com.incode.welcome_sdk.modules.SelfieScan;
import com.plaid.internal.EnumC41897g;
import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.Map;

/* JADX INFO: loaded from: classes4.dex */
public final class hv implements hr {
    private static final byte[] $$a = null;
    private static final int $$b = 0;
    private static final Map<String, Integer> c;
    private static int d;
    private static long e;

    private static String $$c(int i, short s, byte b) {
        int i2 = i + 73;
        int i3 = s * 3;
        int i4 = 4 - (b * 4);
        byte[] bArr = $$a;
        byte[] bArr2 = new byte[i3 + 1];
        int i5 = -1;
        if (bArr == null) {
            i2 = (-i2) + i4;
            i4++;
            bArr = bArr;
            i5 = -1;
        }
        while (true) {
            int i6 = i5 + 1;
            bArr2[i6] = (byte) i2;
            if (i6 == i3) {
                return new String(bArr2, 0);
            }
            i2 = (-bArr[i4]) + i2;
            i4++;
            bArr = bArr;
            i5 = i6;
        }
    }

    static {
        init$0();
        e();
        HashMap map = new HashMap();
        Object[] objArr = new Object[1];
        f("넣ྵ鏸녊₡\ue812쵛", 1 - KeyEvent.keyCodeFromString(""), objArr);
        map.put((String) objArr[0], 5);
        Object[] objArr2 = new Object[1];
        f("픀\ue7e9䍑합죽\uecb6ᷰ", 1 - (ViewConfiguration.getTapTimeout() >> 16), objArr2);
        map.put((String) objArr2[0], 0);
        Object[] objArr3 = new Object[1];
        g(TextUtils.getCapsMode("", 0, 0) + 3, true, View.resolveSizeAndState(0, 0, 0) + EnumC41897g.SDK_ASSET_ILLUSTRATION_SIGNATURE_VALUE, 12 - KeyEvent.getDeadChar(0, 0), "\t\t￼￼\ufffe\ufff8\n\n￼￤\t\u0006", objArr3);
        map.put((String) objArr3[0], 8);
        Object[] objArr4 = new Object[1];
        g(11 - (ViewConfiguration.getScrollBarFadeDuration() >> 16), false, 124 - Color.blue(0), 19 - (ViewConfiguration.getTapTimeout() >> 16), "\u0005\u000b￪￼\n\n\u0000\u0006\u0005￠\ufffb￼\u0005\t\u0006\u0003\u0003\u0004￼", objArr4);
        map.put((String) objArr4[0], 3);
        Object[] objArr5 = new Object[1];
        g(11 - ImageFormat.getBitsPerPixel(0), true, View.MeasureSpec.makeMeasureSpec(0, 0) + 117, TextUtils.getTrimmedLength("") + 21, "\ufff1￢\uffe7\n\uffff\u0007\u0012\u0007\f\uffe7\u0011\u0007\u0002\uffff\r\n\u000e\ufff3\f\uffff\u0001", objArr5);
        map.put((String) objArr5[0], 1);
        Object[] objArr6 = new Object[1];
        g(2 - TextUtils.indexOf("", "", 0), true, (AudioTrack.getMinVolume() > SelfieScan.RECOGNITION_FAIL_RESULT ? 1 : (AudioTrack.getMinVolume() == SelfieScan.RECOGNITION_FAIL_RESULT ? 0 : -1)) + 127, (ExpandableListView.getPackedPositionForChild(0, 0) > 0L ? 1 : (ExpandableListView.getPackedPositionForChild(0, 0) == 0L ? 0 : -1)) + 3, "\u0007\ufffa", objArr6);
        map.put((String) objArr6[0], 6);
        Object[] objArr7 = new Object[1];
        g((ViewConfiguration.getZoomControlsTimeout() > 0L ? 1 : (ViewConfiguration.getZoomControlsTimeout() == 0L ? 0 : -1)) + 1, false, (KeyEvent.getMaxKeyCode() >> 16) + 126, 4 - Color.green(0), "￼\b\t\ufff6", objArr7);
        map.put((String) objArr7[0], 12);
        Object[] objArr8 = new Object[1];
        g(13 - TextUtils.indexOf("", "", 0), true, (Process.myPid() >> 22) + EnumC41897g.SDK_ASSET_ILLUSTRATION_SIGNATURE_VALUE, (ViewConfiguration.getEdgeSlop() >> 16) + 14, "\u0007\u0010￫\ufffa\u0000\u000b\n\u0006\u0005\ufffe\ufff8\u0000\ufffb￼", objArr8);
        map.put((String) objArr8[0], 11);
        Object[] objArr9 = new Object[1];
        g(9 - (AudioTrack.getMinVolume() > SelfieScan.RECOGNITION_FAIL_RESULT ? 1 : (AudioTrack.getMinVolume() == SelfieScan.RECOGNITION_FAIL_RESULT ? 0 : -1)), true, 118 - View.MeasureSpec.getMode(0), 18 - (ViewConfiguration.getJumpTapTimeout() >> 16), "\ufffe\u0006￡\u000b\ufffe\u0000\ufff0\u0001\u0006\u0001￦\u0000\u0006\u0011\u0010\f\u000b\u0004", objArr9);
        map.put((String) objArr9[0], 7);
        Object[] objArr10 = new Object[1];
        f("쐮毞⮦쑊䓐懞甉\uef8c秜蚲㞿⩻뽿섢\uf1f5棃ﲖΊ뱥ꚳ㈌乬绬\ue509灛裮㤓⏪뗨쪥", View.resolveSize(0, 0) + 1, objArr10);
        map.put((String) objArr10[0], 2);
        Object[] objArr11 = new Object[1];
        g(-TextUtils.lastIndexOf("", '0', 0), true, 122 - Gravity.getAbsoluteGravity(0, 0), 19 - (ViewConfiguration.getWindowTouchSlop() >> 8), "��￢\u0007\b\u0002\f\f\ufffe￬￼\u0002\r\f\b\u0007\u0000\ufffa\u0002", objArr11);
        map.put((String) objArr11[0], 10);
        Object[] objArr12 = new Object[1];
        f("\uec90\uec99甼\uecf4쎗᧔⮓鞆兢ǵ椥剱韁䙥꽳ო", View.resolveSizeAndState(0, 0, 0) + 1, objArr12);
        map.put((String) objArr12[0], 9);
        Object[] objArr13 = new Object[1];
        g(2 - (ViewConfiguration.getScrollBarSize() >> 8), false, Gravity.getAbsoluteGravity(0, 0) + 129, (ViewConfiguration.getKeyRepeatDelay() >> 16) + 4, "\u0001\u0000￼\u0005", objArr13);
        map.put((String) objArr13[0], 4);
        c = map;
    }

    public static void e() {
        e = 7094165034443342327L;
        d = 1605274434;
    }

    private static void f(String str, int i, Object[] objArr) throws Throwable {
        char[] charArray = str != null ? str.toCharArray() : str;
        hl hlVar = new hl();
        char[] cArrB = hl.b(e ^ (-1723600592890876272L), charArray, i);
        hlVar.e = 4;
        while (true) {
            int i2 = hlVar.e;
            if (i2 >= cArrB.length) {
                objArr[0] = new String(cArrB, 4, cArrB.length - 4);
                return;
            }
            int i3 = i2 - 4;
            hlVar.d = i3;
            try {
                Object[] objArr2 = {Long.valueOf(cArrB[i2] ^ cArrB[i2 % 4]), Long.valueOf(i3), Long.valueOf(e)};
                Object objD = an.d(-291407824);
                if (objD == null) {
                    int modifierMetaStateMask = ((byte) KeyEvent.getModifierMetaStateMask()) + 24;
                    byte b = (byte) 0;
                    byte b2 = b;
                    String str$$c = $$c(b, b2, b2);
                    Class cls = Long.TYPE;
                    objD = an.d((SystemClock.uptimeMillis() > 0L ? 1 : (SystemClock.uptimeMillis() == 0L ? 0 : -1)) + 2588, (char) ((ViewConfiguration.getGlobalActionKeyTimeout() > 0L ? 1 : (ViewConfiguration.getGlobalActionKeyTimeout() == 0L ? 0 : -1)) - 1), modifierMetaStateMask, -1732203669, false, str$$c, new Class[]{cls, cls, cls});
                }
                cArrB[i2] = ((Character) ((Method) objD).invoke(null, objArr2)).charValue();
                Object[] objArr3 = {hlVar, hlVar};
                Object objD2 = an.d(1066529625);
                if (objD2 == null) {
                    objD2 = an.d(TextUtils.getOffsetAfter("", 0) + EnumC41897g.SDK_ASSET_PLAID_LOGO_LOADING_INDICATOR_SUCCESS_VALUE, (char) KeyEvent.keyCodeFromString(""), 23 - KeyEvent.keyCodeFromString(""), 1240473602, false, "G", new Class[]{Object.class, Object.class});
                }
                ((Method) objD2).invoke(null, objArr3);
            } catch (Throwable th) {
                Throwable cause = th.getCause();
                if (cause == null) {
                    throw th;
                }
                throw cause;
            }
        }
    }

    /* JADX WARN: Removed duplicated region for block: B:37:0x0143  */
    /* JADX WARN: Removed duplicated region for block: B:38:0x0144  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    private static void g(int r24, boolean r25, int r26, int r27, java.lang.String r28, java.lang.Object[] r29) throws java.lang.Throwable {
        /*
            Method dump skipped, instruction units count: 334
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: com.facetec.sdk.hv.g(int, boolean, int, int, java.lang.String, java.lang.Object[]):void");
    }

    public static void init$0() {
        $$a = new byte[]{80, 83, -21, -55};
        $$b = EnumC41897g.SDK_ASSET_ILLUSTRATION_PAYWITHPLAID_LOGO_VALUE;
    }

    @Override // com.facetec.sdk.hr
    public final int a(gs gsVar) {
        Integer num = c.get(gsVar.g());
        if (num == null) {
            return -1;
        }
        return num.intValue();
    }

    @Override // com.facetec.sdk.hr
    public final int b(gs gsVar) {
        Integer num = c.get(gsVar.h());
        if (num == null) {
            return -1;
        }
        return num.intValue();
    }
}