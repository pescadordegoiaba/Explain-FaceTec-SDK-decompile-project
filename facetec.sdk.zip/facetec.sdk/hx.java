package com.facetec.sdk;

import android.os.Bundle;
import android.os.Handler;
import android.os.HandlerThread;
import android.os.ResultReceiver;
import io.sentry.protocol.FeatureFlag;

/* JADX INFO: loaded from: classes4.dex */
public final class hx extends ResultReceiver {
    private static int c = 0;
    private static int e = 1;
    private String b;
    public HandlerThread d;

    public hx(Handler handler, HandlerThread handlerThread) {
        super(handler);
        this.b = null;
        this.d = handlerThread;
    }

    public final String c() {
        int i = c;
        String str = this.b;
        e = (i + 25) % 128;
        return str;
    }

    public final void d() {
        e = (c + 101) % 128;
        this.d.quit();
        int i = e + 51;
        c = i % 128;
        if (i % 2 != 0) {
            throw null;
        }
    }

    @Override // android.os.ResultReceiver
    public final void onReceiveResult(int i, Bundle bundle) {
        int i2 = c + 115;
        e = i2 % 128;
        if (i2 % 2 != 0) {
            this.b = bundle.getString(FeatureFlag.JsonKeys.RESULT);
        } else {
            this.b = bundle.getString(FeatureFlag.JsonKeys.RESULT);
            throw null;
        }
    }
}