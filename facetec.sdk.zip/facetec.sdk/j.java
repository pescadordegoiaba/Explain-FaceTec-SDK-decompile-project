package com.facetec.sdk;

import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.PointF;
import android.graphics.drawable.Drawable;
import android.os.Process;
import android.os.SystemClock;
import android.text.AndroidCharacter;
import android.text.TextUtils;
import android.view.KeyEvent;
import android.view.View;
import android.view.ViewConfiguration;
import android.widget.ExpandableListView;
import com.facetec.sdk.nj;
import com.incode.welcome_sdk.modules.SelfieScan;
import com.plaid.internal.EnumC41897g;
import java.lang.reflect.Method;
import net.sf.scuba.smartcards.ISO7816;
import net.sf.scuba.smartcards.ISOFileInfo;
import org.bouncycastle.crypto.signers.PSSSigner;
import org.jmrtd.PassportService;

/* JADX INFO: loaded from: classes4.dex */
final class j {
    private static final byte[] $$a = null;
    private static final int $$b = 0;
    private static int $10;
    private static int $11;
    private static final nb a;
    private static int b;
    private static char c;
    private static int d;
    private static long e;
    private static byte[] f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    private static int f95904g;
    private static int h;
    private static int i;
    private static short[] j;
    private static int l;
    private static int m;
    private static int n;

    public static class c extends Exception {
        public c(String str) {
            super(str);
        }
    }

    /* JADX WARN: Removed duplicated region for block: B:10:0x0021  */
    /* JADX WARN: Removed duplicated region for block: B:8:0x001b  */
    /* JADX WARN: Unsupported multi-entry loop pattern (BACK_EDGE: B:10:0x0021 -> B:11:0x0025). Please report as a decompilation issue!!! */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    private static java.lang.String $$c(int r5, byte r6, byte r7) {
        /*
            int r5 = 106 - r5
            byte[] r0 = com.facetec.sdk.j.$$a
            int r6 = r6 + 4
            int r7 = r7 * 4
            int r1 = r7 + 1
            byte[] r1 = new byte[r1]
            r2 = 0
            if (r0 != 0) goto L13
            r4 = r5
            r5 = r7
            r3 = r2
            goto L25
        L13:
            r3 = r2
        L14:
            byte r4 = (byte) r5
            int r6 = r6 + 1
            r1[r3] = r4
            if (r3 != r7) goto L21
            java.lang.String r5 = new java.lang.String
            r5.<init>(r1, r2)
            return r5
        L21:
            int r3 = r3 + 1
            r4 = r0[r6]
        L25:
            int r5 = r5 + r4
            goto L14
        */
        throw new UnsupportedOperationException("Method not decompiled: com.facetec.sdk.j.$$c(int, byte, byte):java.lang.String");
    }

    static {
        init$0();
        $10 = 0;
        $11 = 1;
        m = 0;
        n = 1;
        f95904g = 0;
        l = 1;
        a();
        KeyEvent.getDeadChar(0, 0);
        KeyEvent.getDeadChar(0, 0);
        Object[] objArr = new Object[1];
        o((short) ((Process.getThreadPriority(0) + 20) >> 6), 1520419973 + (SystemClock.elapsedRealtime() > 0L ? 1 : (SystemClock.elapsedRealtime() == 0L ? 0 : -1)), (-114) - (Process.getElapsedCpuTime() > 0L ? 1 : (Process.getElapsedCpuTime() == 0L ? 0 : -1)), 1072789176 + (ViewConfiguration.getScrollDefaultDelay() >> 16), (byte) (45 - View.combineMeasuredStates(0, 0)), objArr);
        a = nb.a(((String) objArr[0]).intern());
        int i2 = n + 105;
        m = i2 % 128;
        if (i2 % 2 != 0) {
            throw null;
        }
    }

    public static void a() {
        e = -454109638403774796L;
        b = 1453607623;
        c = (char) 19143;
        d = -958848751;
        i = 114796561;
        h = -1548250184;
        f = new byte[]{-7, 10, 5, -14, ISO7816.INS_PSO, 24, -73, 1, -2, 18, ISO7816.INS_CHANGE_CHV, -39, -4, 70, 74, -72, 73, 9, -120, 76, -70, 14, ISOFileInfo.DATA_BYTES1, -75, -70, ISO7816.INS_REHABILITATE_CHV, 73, 73, ISO7816.INS_READ_BINARY, -8, 76, -65, -71, 94, ISOFileInfo.FCP_BYTE, ISOFileInfo.ENV_TEMP_EF, -72, 64, 71, 91, 83, -112, -50, 69, -119, PSSSigner.TRAILER_IMPLICIT, ISO7816.INS_READ_BINARY2, 118, ISOFileInfo.FCI_EXT, 65, PSSSigner.TRAILER_IMPLICIT, 79, 95, -73, 75, PassportService.SFI_DG13, ISOFileInfo.AB, ISOFileInfo.FILE_IDENTIFIER, ISO7816.INS_READ_BINARY2, -78, 71, 117, -113, ISO7816.INS_READ_BINARY2, 72, -69, 93, ISO7816.INS_READ_BINARY, ISO7816.INS_READ_BINARY_STAMPED, ISO7816.INS_READ_RECORD2, -78, 78, 65};
    }

    public static nj b(Context context, String str, Object obj) {
        f95904g = (l + 91) % 128;
        nj njVarD = d(context, str, obj, Boolean.TRUE);
        int i2 = l + 31;
        f95904g = i2 % 128;
        if (i2 % 2 == 0) {
            return njVarD;
        }
        throw null;
    }

    public static nj d(Context context, String str, Object obj, Boolean bool) {
        nj njVarD = d(context, str, bool).b(ni.a(a, new em().e().b().e(obj))).d();
        int i2 = f95904g + 103;
        l = i2 % 128;
        if (i2 % 2 == 0) {
            int i3 = 59 / 0;
        }
        return njVarD;
    }

    public static nj.b e(Context context, String str) throws Throwable {
        int i2 = f95904g + 103;
        l = i2 % 128;
        if (i2 % 2 == 0) {
            d(context, str, Boolean.TRUE);
            throw null;
        }
        nj.b bVarD = d(context, str, Boolean.TRUE);
        int i3 = l + 65;
        f95904g = i3 % 128;
        if (i3 % 2 != 0) {
            int i4 = 24 / 0;
        }
        return bVarD;
    }

    public static void init$0() {
        $$a = new byte[]{80, 83, -21, -55};
        $$b = 10;
    }

    private static void k(char c2, String str, String str2, String str3, int i2, Object[] objArr) throws Throwable {
        char[] charArray;
        int i3;
        int i4;
        char c3;
        String str4;
        String str5 = "";
        char[] charArray2 = str3 != null ? str3.toCharArray() : str3;
        char[] charArray3 = str2 != null ? str2.toCharArray() : str2;
        Object obj = null;
        int i5 = 2;
        if (str != null) {
            int i6 = $10 + 23;
            $11 = i6 % 128;
            if (i6 % 2 == 0) {
                str.toCharArray();
                throw null;
            }
            charArray = str.toCharArray();
        } else {
            charArray = str;
        }
        char[] cArr = charArray;
        hi hiVar = new hi();
        int length = charArray3.length;
        char[] cArr2 = new char[length];
        int length2 = cArr.length;
        char[] cArr3 = new char[length2];
        int i7 = 0;
        System.arraycopy(charArray3, 0, cArr2, 0, length);
        System.arraycopy(cArr, 0, cArr3, 0, length2);
        cArr2[0] = (char) (cArr2[0] ^ c2);
        cArr3[2] = (char) (cArr3[2] + ((char) i2));
        int length3 = charArray2.length;
        char[] cArr4 = new char[length3];
        hiVar.d = 0;
        while (hiVar.d < length3) {
            $10 = ($11 + 7) % 128;
            try {
                Object[] objArr2 = {hiVar};
                Object objD = an.d(1217746441);
                if (objD == null) {
                    objD = an.d(215 - (ViewConfiguration.getMaximumDrawingCacheSize() >> 24), (char) (AndroidCharacter.getMirror('0') + 63290), TextUtils.indexOf(str5, str5, i7, i7) + 24, 1056212306, false, "b", new Class[]{Object.class});
                }
                int iIntValue = ((Integer) ((Method) objD).invoke(obj, objArr2)).intValue();
                Object[] objArr3 = {hiVar};
                Object objD2 = an.d(1379992360);
                if (objD2 == null) {
                    c3 = 1;
                    i3 = i5;
                    byte b2 = (byte) (-1);
                    i4 = i7;
                    objD2 = an.d(Color.green(i7) + 688, (char) (Color.argb(i7, i7, i7, i7) + 33107), Color.red(i7) + 23, 606130291, false, $$c((byte) ($$b - 1), b2, (byte) (b2 + 1)), new Class[]{Object.class});
                } else {
                    i3 = i5;
                    i4 = i7;
                    c3 = 1;
                }
                int iIntValue2 = ((Integer) ((Method) objD2).invoke(obj, objArr3)).intValue();
                int i8 = cArr2[hiVar.d % 4] * 32718;
                Object[] objArr4 = new Object[3];
                objArr4[i3] = Integer.valueOf(cArr3[iIntValue]);
                objArr4[c3] = Integer.valueOf(i8);
                objArr4[i4] = hiVar;
                Object objD3 = an.d(-1522168148);
                Class cls = Integer.TYPE;
                if (objD3 == null) {
                    int i9 = i4;
                    int i10 = (ExpandableListView.getPackedPositionForChild(i9, i9) > 0L ? 1 : (ExpandableListView.getPackedPositionForChild(i9, i9) == 0L ? 0 : -1)) + 1305;
                    char cResolveOpacity = (char) Drawable.resolveOpacity(i9, i9);
                    int scrollDefaultDelay = (ViewConfiguration.getScrollDefaultDelay() >> 16) + 24;
                    byte b3 = (byte) ($$b >>> 2);
                    byte b4 = (byte) (b3 - 3);
                    str4 = str5;
                    objD3 = an.d(i10, cResolveOpacity, scrollDefaultDelay, -752591369, false, $$c(b3, b4, (byte) (b4 + 1)), new Class[]{Object.class, cls, cls});
                } else {
                    str4 = str5;
                }
                ((Method) objD3).invoke(null, objArr4);
                int i11 = cArr2[iIntValue2] * 32718;
                char c4 = cArr3[iIntValue];
                int i12 = i3;
                Object[] objArr5 = new Object[i12];
                objArr5[c3] = Integer.valueOf(c4);
                objArr5[0] = Integer.valueOf(i11);
                Object objD4 = an.d(-1578548222);
                if (objD4 == null) {
                    objD4 = an.d(1969 - ((byte) KeyEvent.getModifierMetaStateMask()), (char) (1 - (ViewConfiguration.getScrollFriction() > SelfieScan.RECOGNITION_FAIL_RESULT ? 1 : (ViewConfiguration.getScrollFriction() == SelfieScan.RECOGNITION_FAIL_RESULT ? 0 : -1))), (ViewConfiguration.getKeyRepeatTimeout() >> 16) + 24, -678914215, false, "i", new Class[]{cls, cls});
                }
                obj = null;
                cArr3[iIntValue2] = ((Character) ((Method) objD4).invoke(null, objArr5)).charValue();
                cArr2[iIntValue2] = hiVar.e;
                int i13 = hiVar.d;
                cArr4[i13] = (char) (((((long) (r0 ^ charArray2[i13])) ^ (e ^ 1396024866991524551L)) ^ ((long) ((int) (((long) b) ^ 1396024866991524551L)))) ^ ((long) ((char) (((long) c) ^ 1396024866991524551L))));
                hiVar.d = i13 + 1;
                i5 = i12;
                str5 = str4;
                i7 = 0;
            } catch (Throwable th) {
                Throwable cause = th.getCause();
                if (cause == null) {
                    throw th;
                }
                throw cause;
            }
        }
        objArr[0] = new String(cArr4);
    }

    private static void o(short s, int i2, int i3, int i4, byte b2, Object[] objArr) throws Throwable {
        int i5;
        int i6;
        long j2;
        int i7;
        int i8;
        int i9;
        int i10;
        int i11;
        char c2;
        int i12;
        int i13;
        hh hhVar = new hh();
        StringBuilder sb = new StringBuilder();
        try {
            int i14 = 1;
            Object[] objArr2 = {Integer.valueOf(i3), Integer.valueOf(i)};
            int i15 = 0;
            Object objD = an.d(962055330);
            Class cls = Integer.TYPE;
            if (objD == null) {
                byte b3 = (byte) 0;
                byte b4 = (byte) (b3 - 1);
                objD = an.d(2402 - Drawable.resolveOpacity(0, 0), (char) View.resolveSize(0, 0), 24 - (ViewConfiguration.getScrollBarSize() >> 8), 1328947193, false, $$c(b3, b4, (byte) (b4 + 1)), new Class[]{cls, cls});
            }
            int iIntValue = ((Integer) ((Method) objD).invoke(null, objArr2)).intValue();
            boolean z = iIntValue == -1;
            int i16 = 3;
            if (!(!z)) {
                $11 = ($10 + 15) % 128;
                byte[] bArr = f;
                if (bArr != null) {
                    int length = bArr.length;
                    i10 = 962055330;
                    byte[] bArr2 = new byte[length];
                    int i17 = 0;
                    j2 = -7666492657327691677L;
                    while (i17 < length) {
                        int i18 = i14;
                        Object[] objArr3 = {Integer.valueOf(bArr[i17])};
                        Object objD2 = an.d(399840230);
                        if (objD2 == null) {
                            i12 = i15;
                            byte b5 = (byte) i16;
                            i13 = i16;
                            byte b6 = (byte) (b5 - 4);
                            objD2 = an.d(2064 - View.MeasureSpec.makeMeasureSpec(i15, i15), (char) (14865 - ((byte) KeyEvent.getModifierMetaStateMask())), AndroidCharacter.getMirror('0') - 24, 1639235773, false, $$c(b5, b6, (byte) (b6 + 1)), new Class[]{cls});
                        } else {
                            i12 = i15;
                            i13 = i16;
                        }
                        bArr2[i17] = ((Byte) ((Method) objD2).invoke(null, objArr3)).byteValue();
                        i17++;
                        i14 = i18;
                        i15 = i12;
                        i16 = i13;
                    }
                    i5 = i14;
                    i11 = i15;
                    i6 = i16;
                    c2 = '0';
                    $11 = ($10 + 1) % 128;
                    bArr = bArr2;
                } else {
                    i10 = 962055330;
                    i5 = 1;
                    i11 = 0;
                    i6 = 3;
                    j2 = -7666492657327691677L;
                    c2 = '0';
                }
                if (bArr != null) {
                    byte[] bArr3 = f;
                    Object[] objArr4 = new Object[2];
                    objArr4[i5] = Integer.valueOf(d);
                    objArr4[i11] = Integer.valueOf(i4);
                    Object objD3 = an.d(i10);
                    if (objD3 == null) {
                        int i19 = i11;
                        byte b7 = (byte) 0;
                        byte b8 = (byte) (b7 - 1);
                        objD3 = an.d(Color.rgb(i19, i19, i19) + 16779618, (char) (1 - (ViewConfiguration.getScrollFriction() > SelfieScan.RECOGNITION_FAIL_RESULT ? 1 : (ViewConfiguration.getScrollFriction() == SelfieScan.RECOGNITION_FAIL_RESULT ? 0 : -1))), 23 - TextUtils.lastIndexOf("", c2), 1328947193, false, $$c(b7, b8, (byte) (b8 + 1)), new Class[]{cls, cls});
                    }
                    iIntValue = (byte) (((byte) (((long) bArr3[((Integer) ((Method) objD3).invoke(null, objArr4)).intValue()]) ^ j2)) + ((int) (((long) i) ^ j2)));
                } else {
                    iIntValue = (short) (((short) (((long) j[i4 + ((int) (((long) d) ^ j2))]) ^ j2)) + ((int) (((long) i) ^ j2)));
                }
            } else {
                i5 = 1;
                i6 = 3;
                j2 = -7666492657327691677L;
            }
            if (iIntValue > 0) {
                int i20 = ((i4 + iIntValue) - 2) + ((int) (((long) d) ^ j2));
                if (z) {
                    $10 = ($11 + 85) % 128;
                    i7 = i5;
                } else {
                    i7 = 0;
                }
                hhVar.d = i20 + i7;
                int i21 = h;
                Object[] objArr5 = new Object[4];
                objArr5[i6] = sb;
                objArr5[2] = Integer.valueOf(i21);
                objArr5[i5] = Integer.valueOf(i2);
                objArr5[0] = hhVar;
                Object objD4 = an.d(-1066327576);
                if (objD4 == null) {
                    int iLastIndexOf = TextUtils.lastIndexOf("", '0') + 1804;
                    char gidForName = (char) (9691 - Process.getGidForName(""));
                    int tapTimeout = 24 - (ViewConfiguration.getTapTimeout() >> 16);
                    byte length2 = (byte) $$a.length;
                    byte b9 = (byte) (length2 - 5);
                    objD4 = an.d(iLastIndexOf, gidForName, tapTimeout, -1240403277, false, $$c(length2, b9, (byte) (b9 + 1)), new Class[]{Object.class, cls, cls, Object.class});
                }
                ((StringBuilder) ((Method) objD4).invoke(null, objArr5)).append(hhVar.e);
                hhVar.c = hhVar.e;
                byte[] bArr4 = f;
                if (bArr4 != null) {
                    int length3 = bArr4.length;
                    byte[] bArr5 = new byte[length3];
                    for (int i22 = 0; i22 < length3; i22++) {
                        bArr5[i22] = (byte) (((long) bArr4[i22]) ^ j2);
                    }
                    bArr4 = bArr5;
                }
                if (bArr4 != null) {
                    i9 = i5;
                    i8 = 0;
                } else {
                    i8 = i5;
                    i9 = i8;
                }
                while (true) {
                    hhVar.b = i9;
                    if (hhVar.b >= iIntValue) {
                        break;
                    }
                    if (i8 == 0) {
                        byte[] bArr6 = f;
                        hhVar.d = hhVar.d - 1;
                        hhVar.e = (char) (hhVar.c + (((byte) (((byte) (((long) bArr6[r4]) ^ j2)) + s)) ^ b2));
                    } else {
                        short[] sArr = j;
                        hhVar.d = hhVar.d - 1;
                        hhVar.e = (char) (hhVar.c + (((short) (((short) (((long) sArr[r4]) ^ j2)) + s)) ^ b2));
                    }
                    sb.append(hhVar.e);
                    hhVar.c = hhVar.e;
                    i9 = hhVar.b + 1;
                }
            }
            objArr[0] = sb.toString();
        } catch (Throwable th) {
            Throwable cause = th.getCause();
            if (cause == null) {
                throw th;
            }
            throw cause;
        }
    }

    public static nj.b d(Context context, String str, Boolean bool) throws Throwable {
        String str2 = bk.a;
        if (str2 == null) {
            l = (f95904g + EnumC41897g.SDK_ASSET_ILLUSTRATION_CALENDAR_VALUE) % 128;
            str2 = "";
        }
        nj.b bVarE = new nj.b().e(str);
        Object[] objArr = new Object[1];
        k((char) Color.red(0), "\uec73콸\u0088\ueaed", "⊋섵ᭃ༆", "\uebe8쟅ꟶ谼\uf318넵ᖤ丈珒범㮸", (Process.myPid() >> 22) + 1136735522, objArr);
        nj.b bVarB = bVarE.b(((String) objArr[0]).intern(), str2);
        Object[] objArr2 = new Object[1];
        k((char) (ViewConfiguration.getScrollDefaultDelay() >> 16), "\uec73콸\u0088\ueaed", "䎌肾Ᾰ婵", "\u1cceꑓᎈ䜺翥\ue735搅苎徂陚", Process.myPid() >> 22, objArr2);
        nj.b bVarB2 = bVarB.b(((String) objArr2[0]).intern(), ay.c(bk.a));
        Object[] objArr3 = new Object[1];
        o((short) View.getDefaultSize(0, 0), Color.green(0) + 1520419965, (-116) - TextUtils.indexOf((CharSequence) "", '0', 0), (ViewConfiguration.getPressedStateDuration() >> 16) + 1072789134, (byte) (Color.blue(0) + 111), objArr3);
        nj.b bVarB3 = bVarB2.b(((String) objArr3[0]).intern(), ay.c(bk.a));
        Object[] objArr4 = new Object[1];
        k((char) (Color.green(0) + 63569), "\uec73콸\u0088\ueaed", "\uddae橕凸諸", "醺\ud9fa픪臥튠캱놧\u139e沃፝䑌밵\uf368彳汒", ((Process.getThreadPriority(0) + 20) >> 6) - 127248931, objArr4);
        String strIntern = ((String) objArr4[0]).intern();
        Object[] objArr5 = new Object[1];
        k((char) ((PointF.length(SelfieScan.RECOGNITION_FAIL_RESULT, SelfieScan.RECOGNITION_FAIL_RESULT) > SelfieScan.RECOGNITION_FAIL_RESULT ? 1 : (PointF.length(SelfieScan.RECOGNITION_FAIL_RESULT, SelfieScan.RECOGNITION_FAIL_RESULT) == SelfieScan.RECOGNITION_FAIL_RESULT ? 0 : -1)) + 53388), "\uec73콸\u0088\ueaed", "踦䏽賴쫐", "廃叙ǆ疉崂㥦칔\udd3e\ue0e1섋诡翄㫄鰟粜唙糌董藫릹왭“왣槯尪㋗橕杸傠㨙ሚ⫂", ViewConfiguration.getMaximumDrawingCacheSize() >> 24, objArr5);
        nj.b bVarB4 = bVarB3.b(strIntern, ((String) objArr5[0]).intern());
        Object[] objArr6 = new Object[1];
        o((short) (ViewConfiguration.getFadingEdgeLength() >> 16), 1520419979 - View.MeasureSpec.getSize(0), (-115) - (ViewConfiguration.getFadingEdgeLength() >> 16), TextUtils.lastIndexOf("", '0', 0) + 1072789147, (byte) (39 - TextUtils.lastIndexOf("", '0')), objArr6);
        SharedPreferences sharedPreferences = context.getSharedPreferences(((String) objArr6[0]).intern(), 0);
        Object[] objArr7 = new Object[1];
        k((char) (27686 - (ViewConfiguration.getMinimumFlingVelocity() >> 16)), "\uec73콸\u0088\ueaed", "ᴭ\uf147⚝ｬ", "䣄됉괝\uf5fa旺툮쓅ᶮ\ue911㎼㩼痊唍戆탌人머瑭뷹鸢࿔뺰쓼\uf7a3큎摠㵱魛䛅\uf2c2", Color.blue(0), objArr7);
        String string = sharedPreferences.getString(((String) objArr7[0]).intern(), "");
        if (!string.equals("")) {
            Object[] objArr8 = new Object[1];
            k((char) KeyEvent.keyCodeFromString(""), "\uec73콸\u0088\ueaed", "\ufdd3\u0b45恣瞆", "耡憏랧출ꠏ\ue86c⭂滺妬䷼害굆", (ViewConfiguration.getZoomControlsTimeout() > 0L ? 1 : (ViewConfiguration.getZoomControlsTimeout() == 0L ? 0 : -1)) - 1, objArr8);
            bVarB4.b(((String) objArr8[0]).intern(), string);
        }
        if (!bool.booleanValue()) {
            return bVarB4;
        }
        f95904g = (l + 11) % 128;
        if (ay.a == null) {
            Object[] objArr9 = new Object[1];
            k((char) View.MeasureSpec.getMode(0), "\uec73콸\u0088\ueaed", "ꗐ酧镡퍝", "Ჿ⟬ᱹ튉㓘鞕ꂇ怍奢\uf238䙕焛ᷩĤ䈁筏鱊㻙巆獃昀㥧", TextUtils.indexOf((CharSequence) "", '0', 0) + 1, objArr9);
            throw new c(((String) objArr9[0]).intern());
        }
        try {
            StringBuilder sb = new StringBuilder();
            Object[] objArr10 = new Object[1];
            k((char) (53388 - KeyEvent.keyCodeFromString("")), "\uec73콸\u0088\ueaed", "踦䏽賴쫐", "廃叙ǆ疉崂㥦칔\udd3e\ue0e1섋诡翄㫄鰟粜唙糌董藫릹왭“왣槯尪㋗橕杸傠㨙ሚ⫂", 1 - (SystemClock.uptimeMillis() > 0L ? 1 : (SystemClock.uptimeMillis() == 0L ? 0 : -1)), objArr10);
            sb.append(((String) objArr10[0]).intern());
            sb.append(ay.a);
            String lowerCase = bp.b(sb.toString()).toLowerCase();
            Object[] objArr11 = new Object[1];
            o((short) (ViewConfiguration.getMinimumFlingVelocity() >> 16), TextUtils.indexOf((CharSequence) "", '0') + 1520419966, (-114) - (ViewConfiguration.getGlobalActionKeyTimeout() > 0L ? 1 : (ViewConfiguration.getGlobalActionKeyTimeout() == 0L ? 0 : -1)), (ExpandableListView.getPackedPositionForGroup(0) > 0L ? 1 : (ExpandableListView.getPackedPositionForGroup(0) == 0L ? 0 : -1)) + 1072789163, (byte) (39 - (SystemClock.elapsedRealtimeNanos() > 0L ? 1 : (SystemClock.elapsedRealtimeNanos() == 0L ? 0 : -1))), objArr11);
            bVarB4.b(((String) objArr11[0]).intern(), lowerCase);
            l = (f95904g + 125) % 128;
            return bVarB4;
        } catch (Exception unused) {
            Object[] objArr12 = new Object[1];
            k((char) (33208 - (ViewConfiguration.getDoubleTapTimeout() >> 16)), "\uec73콸\u0088\ueaed", "Ȩ텑롙뒁", "簦賗\uf053怼좡ꅧ笧ᣫꚃꕪ⛀㡋ꤢޮ稒歁㒄煄☺ㄳ㬂㸓斆꺺⍰㰀", (ExpandableListView.getPackedPositionForGroup(0) > 0L ? 1 : (ExpandableListView.getPackedPositionForGroup(0) == 0L ? 0 : -1)), objArr12);
            throw new c(((String) objArr12[0]).intern());
        }
    }
}