package com.facetec.sdk;

import android.content.Context;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.view.View;
import android.widget.LinearLayout;
import com.incode.welcome_sdk.modules.SelfieScan;

/* JADX INFO: loaded from: classes4.dex */
final class k extends LinearLayout {
    public k(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        setEnabled(false);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void d(Runnable runnable, View view) {
        if (isEnabled()) {
            setEnabled(false);
            if (runnable != null) {
                runnable.run();
            }
        }
    }

    @Override // android.view.View
    public final boolean onTouchEvent(MotionEvent motionEvent) {
        super.onTouchEvent(motionEvent);
        if (!isEnabled()) {
            return false;
        }
        if (motionEvent.getAction() == 0) {
            setAlpha(0.4f);
            postInvalidate();
        } else if (motionEvent.getAction() == 1 || motionEvent.getAction() == 3 || motionEvent.getX() < SelfieScan.RECOGNITION_FAIL_RESULT || motionEvent.getX() > getWidth() || motionEvent.getY() < SelfieScan.RECOGNITION_FAIL_RESULT || motionEvent.getY() > getHeight()) {
            setAlpha(1.0f);
            postInvalidate();
        }
        return true;
    }

    public final void setOnClickRunnable(final Runnable runnable) {
        setEnabled(true);
        setClickable(true);
        setOnClickListener(new View.OnClickListener() { // from class: com.facetec.sdk.剑木
            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                this.f7224.d(runnable, view);
            }
        });
    }
}