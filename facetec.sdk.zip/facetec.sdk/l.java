package com.facetec.sdk;

/* JADX INFO: loaded from: classes4.dex */
final class l<T> {
    private T d = null;

    @FunctionalInterface
    public interface a {
        Object create();
    }

    public final synchronized void a() {
        this.d = null;
    }

    public final synchronized T c(a aVar) {
        try {
            if (this.d == null) {
                this.d = (T) aVar.create();
            }
        } catch (Throwable th) {
            throw th;
        }
        return this.d;
    }

    public final synchronized T d() {
        return this.d;
    }
}