package com.facetec.sdk;

import ai.luciq.library.model.NetworkLog;
import ai.luciq.library.networkv2.request.Header;
import android.content.Context;
import android.os.Looper;
import android.os.Process;
import com.facetec.sdk.bv;
import com.facetec.sdk.nf;
import com.facetec.sdk.nj;
import com.facetec.sdk.t;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.concurrent.Semaphore;
import java.util.concurrent.TimeUnit;

/* JADX INFO: loaded from: classes4.dex */
class m {
    private static /* synthetic */ boolean a = true;
    private static nf c;
    private final Context b;
    private final Semaphore e = new Semaphore(1);

    public m(Context context) {
        this.b = context.getApplicationContext();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void a(Context context, ar arVar) throws Throwable {
        Process.setThreadPriority(19);
        t.d(context, arVar, true, bv.b.FRONT, cp.c);
        this.e.release();
    }

    private static ArrayList<String> b(t.b bVar, boolean z) throws Throwable {
        boolean zN = cv.n();
        ArrayList<String> arrayList = new ArrayList<>();
        arrayList.add(ao.e);
        cu cuVarI = cu.ZOOM_FAR;
        if (z) {
            cuVarI = cv.i();
        }
        if (cuVarI == cu.PROCESSING_COMPLETE_SUCCESS) {
            arrayList.add(ao.c);
        } else if (cuVarI == cu.PROCESSING_COMPLETE_RETRY) {
            arrayList.add(ao.b);
        } else if (bVar == t.b.USER_CANCELLED) {
            arrayList.add(ao.a);
            arrayList.add(t.d);
        } else if (bVar == t.b.SESSION_CONTEXT_SWITCH) {
            arrayList.add(ao.j);
            arrayList.add(t.d);
        } else if (bVar == t.b.PRE_SESSION_PHASE_1_TIMEOUT) {
            arrayList.add(ao.p);
            arrayList.add(t.d);
        } else if (bVar == t.b.PRE_SESSION_PHASE_2_TIMEOUT) {
            arrayList.add(ao.r);
            arrayList.add(t.d);
        } else if (bVar == t.b.SESSION_TIMEOUT) {
            arrayList.add(ao.i);
            arrayList.add(t.d);
        } else if (bVar == t.b.USER_WAS_SUCCESSFUL) {
            arrayList.add(ao.c);
        } else {
            arrayList.add(ao.b);
        }
        if (zN) {
            arrayList.add(ao.h);
            return arrayList;
        }
        arrayList.add(ao.f95821g);
        return arrayList;
    }

    private static synchronized nf c() {
        try {
            if (c == null) {
                nf.a aVar = new nf.a();
                TimeUnit timeUnit = TimeUnit.SECONDS;
                aVar.x = nu.c("timeout", 60L, timeUnit);
                aVar.B = nu.c("timeout", 60L, timeUnit);
                aVar.z = nu.c("timeout", 60L, timeUnit);
                c = aVar.b();
            }
        } catch (Throwable th) {
            throw th;
        }
        return c;
    }

    public final synchronized void e(final String str, final t.b bVar) {
        try {
            if (((Boolean) bk.d(-261957882, nf.a.e(), nf.a.e(), nf.a.e(), nf.a.e(), new Object[0], 261957889)).booleanValue()) {
                bh.c();
                final ArrayList<String> arrayListB = b(bVar, true);
                if (bVar != t.b.USER_WAS_SUCCESSFUL) {
                    Iterator<String> it = arrayListB.iterator();
                    while (it.hasNext()) {
                        cv.E(it.next());
                    }
                }
                if (t.c()) {
                    t.b(this.b, bVar);
                    try {
                        this.e.acquire();
                        dj.d(new Runnable() { // from class: com.facetec.sdk.剑梦
                            @Override // java.lang.Runnable
                            public final void run() throws Throwable {
                                this.f7226.b(bVar, arrayListB, str);
                            }
                        });
                    } catch (InterruptedException e) {
                        n.a(e);
                    }
                    final Context context = this.b;
                    bh.c();
                    if (!((Boolean) bk.d(-261957882, nf.a.e(), nf.a.e(), nf.a.e(), nf.a.e(), new Object[0], 261957889)).booleanValue() || bVar == t.b.WAYPOINT_UPLOAD) {
                        return;
                    }
                    try {
                        final ar arVarF = ah.e(context).booleanValue() ? ah.e : ah.f();
                        this.e.acquire();
                        dj.d(new Runnable() { // from class: com.facetec.sdk.剑气
                            @Override // java.lang.Runnable
                            public final void run() throws Throwable {
                                this.f7230.a(context, arVarF);
                            }
                        });
                    } catch (ak e2) {
                        e2.printStackTrace();
                    } catch (InterruptedException e3) {
                        n.a(e3);
                    }
                }
            }
        } catch (Throwable th) {
            throw th;
        }
    }

    public final synchronized void c(FaceTecSessionResult faceTecSessionResult, String str) {
        if (((Boolean) bk.d(-261957882, nf.a.e(), nf.a.e(), nf.a.e(), nf.a.e(), new Object[0], 261957889)).booleanValue()) {
            bh.c();
            ey eyVar = new ey();
            eyVar.c("faceScan", faceTecSessionResult.getFaceScanBase64());
            eyVar.c("auditTrailImage", faceTecSessionResult.getAuditTrailCompressedBase64()[0]);
            eyVar.c("lowQualityAuditTrailImage", faceTecSessionResult.getLowQualityAuditTrailCompressedBase64()[0]);
            if (t.c()) {
                c().b(new nj.b().e("https://api.facetec.com/api/v3.1/biometrics/liveness-3d").d(Header.CONTENT_TYPE, NetworkLog.JSON).d("X-Device-Key", str).d("User-Agent", FaceTecSDK.createFaceTecAPIUserAgentString(faceTecSessionResult.getSessionId())).d("X-User-Agent", FaceTecSDK.createFaceTecAPIUserAgentString(faceTecSessionResult.getSessionId())).d("x-on-device-retry", "true").b(ni.a(nb.a("application/json; charset=utf-8"), eyVar.toString())).d()).e(new mm() { // from class: com.facetec.sdk.m.1
                    @Override // com.facetec.sdk.mm
                    public final void b(nh nhVar) {
                    }

                    @Override // com.facetec.sdk.mm
                    public final void c(IOException iOException) {
                    }
                });
            }
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void c(t.b bVar, ArrayList arrayList, EnumC39477r enumC39477r, String str, String str2, boolean z) throws Throwable {
        if (bVar != t.b.USER_CANCELLED) {
            Process.setThreadPriority(19);
        }
        t.a(this.b, arrayList, "", enumC39477r, str, str2, z);
        this.e.release();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void b(t.b bVar, ArrayList arrayList, String str) throws Throwable {
        if (bVar != t.b.USER_CANCELLED) {
            Process.setThreadPriority(19);
        }
        t.a(this.b, arrayList, "", EnumC39477r.FACE_SCAN, str, "", false);
        this.e.release();
    }

    public final synchronized void b(final t.b bVar, final String str, final String str2, boolean z, final boolean z2) {
        Throwable th;
        EnumC39477r enumC39477r;
        try {
            try {
                if (!((Boolean) bk.d(-261957882, nf.a.e(), nf.a.e(), nf.a.e(), nf.a.e(), new Object[0], 261957889)).booleanValue()) {
                    return;
                }
                bh.c();
                if (z) {
                    try {
                        enumC39477r = EnumC39477r.ID_SCAN_ONLY;
                    } catch (Throwable th2) {
                        th = th2;
                    }
                } else {
                    enumC39477r = EnumC39477r.ID_SCAN_MATCH;
                }
                final EnumC39477r enumC39477r2 = enumC39477r;
                final ArrayList<String> arrayListB = b(bVar, false);
                if (bVar != t.b.USER_WAS_SUCCESSFUL) {
                    Iterator<String> it = arrayListB.iterator();
                    while (it.hasNext()) {
                        cv.E(it.next());
                    }
                }
                if (!t.c()) {
                    return;
                }
                t.b(this.b, bVar);
                try {
                    this.e.acquire();
                    try {
                        dj.d(new Runnable() { // from class: com.facetec.sdk.剑水
                            @Override // java.lang.Runnable
                            public final void run() throws Throwable {
                                this.f7233.c(bVar, arrayListB, enumC39477r2, str, str2, z2);
                            }
                        });
                        return;
                    } catch (InterruptedException e) {
                        e = e;
                        n.a(e);
                        return;
                    }
                } catch (InterruptedException e2) {
                    e = e2;
                }
            } catch (Throwable th3) {
                th = th3;
            }
        } catch (Throwable th4) {
            th = th4;
        }
        th = th;
        throw th;
    }

    public final void b() {
        if (!a && Thread.currentThread().equals(Looper.getMainLooper().getThread())) {
            throw new AssertionError();
        }
        Semaphore semaphore = this.e;
        if (semaphore != null) {
            try {
                if (semaphore.tryAcquire(5L, TimeUnit.SECONDS)) {
                    this.e.release();
                }
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
    }
}