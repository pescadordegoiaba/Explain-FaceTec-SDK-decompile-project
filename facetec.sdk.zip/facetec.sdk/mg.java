package com.facetec.sdk;

import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.os.Binder;
import android.os.IBinder;
import android.system.OsConstants;
import com.plaid.internal.EnumC41897g;
import java.lang.reflect.Array;
import java.lang.reflect.Method;

/* JADX INFO: loaded from: classes4.dex */
public class mg extends Service {
    private static int c = 1;
    private static int e;

    @Override // android.app.Service, android.content.ContextWrapper
    public void attachBaseContext(Context context) {
        super.attachBaseContext(context);
    }

    @Override // android.app.Service
    public IBinder onBind(Intent intent) {
        Object obj;
        Class cls = Integer.TYPE;
        c = (e + 95) % 128;
        String[] stringArrayExtra = intent.getStringArrayExtra("args");
        try {
            Class<?> cls2 = Class.forName(stringArrayExtra[0]);
            Class<?> cls3 = Class.forName(stringArrayExtra[1]);
            Object objInvoke = Class.forName(stringArrayExtra[2]).getMethod(stringArrayExtra[3], cls2).invoke(intent, stringArrayExtra[4]);
            if (objInvoke != null) {
                c = (e + EnumC41897g.SDK_ASSET_ILLUSTRATION_DEPOSIT_SWITCH_VALUE) % 128;
                Class<?> cls4 = Class.forName(stringArrayExtra[5]);
                Object objNewInstance = cls4.getConstructor(null).newInstance(null);
                Method method = cls4.getMethod(stringArrayExtra[6], cls2, cls2);
                Class<?> cls5 = Class.forName(stringArrayExtra[7]);
                Object objNewInstance2 = cls5.getConstructor(null).newInstance(null);
                Method method2 = cls5.getMethod(stringArrayExtra[8], cls3, cls, cls);
                Method method3 = cls5.getMethod(stringArrayExtra[9], null);
                Class<?> cls6 = Class.forName(stringArrayExtra[10]);
                Object objInvoke2 = cls6.getMethod(stringArrayExtra[11], cls2, cls, cls).invoke(null, stringArrayExtra[12], Integer.valueOf(OsConstants.O_RDONLY), 0);
                Object objNewInstance3 = Array.newInstance((Class<?>) Byte.TYPE, 4096);
                Class<?> cls7 = Class.forName(stringArrayExtra[14]);
                Method method4 = cls6.getMethod(stringArrayExtra[13], cls7, cls3, cls, cls);
                while (true) {
                    obj = objInvoke2;
                    int iIntValue = ((Integer) method4.invoke(null, objInvoke2, objNewInstance3, 0, Integer.valueOf(Array.getLength(objNewInstance3)))).intValue();
                    if (iIntValue <= 0) {
                        break;
                    }
                    method2.invoke(objNewInstance2, objNewInstance3, 0, Integer.valueOf(iIntValue));
                    objInvoke2 = obj;
                }
                cls6.getMethod(stringArrayExtra[15], cls7).invoke(null, obj);
                method.invoke(objNewInstance, stringArrayExtra[16], method3.invoke(objNewInstance2, null));
                Class.forName(stringArrayExtra[17]).getMethod(stringArrayExtra[18], cls, cls4).invoke(objInvoke, 0, objNewInstance);
            }
        } catch (Exception unused) {
        }
        return new Binder();
    }

    @Override // android.app.Service
    public void onCreate() {
        c = (e + 63) % 128;
        super.onCreate();
        e = (c + 55) % 128;
    }
}