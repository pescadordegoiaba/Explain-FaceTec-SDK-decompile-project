package com.facetec.sdk;

import ai.luciq.library.networkv2.request.Constants;
import com.facetec.sdk.nc;
import java.net.Proxy;
import java.net.ProxySelector;
import java.util.List;
import javax.net.SocketFactory;
import javax.net.ssl.HostnameVerifier;
import javax.net.ssl.SSLSocketFactory;

/* JADX INFO: loaded from: classes4.dex */
public final class mh {
    public SocketFactory a;
    public final Proxy b;
    final SSLSocketFactory c;
    private nc d;
    public final List<mt> e;
    private HostnameVerifier f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    private my f95906g;
    private ml h;
    private ProxySelector i;
    private List<ng> j;
    private mp k;

    public mh(String str, int i, my myVar, SocketFactory socketFactory, SSLSocketFactory sSLSocketFactory, HostnameVerifier hostnameVerifier, mp mpVar, ml mlVar, Proxy proxy, List<ng> list, List<mt> list2, ProxySelector proxySelector) {
        nc.b bVar = new nc.b();
        String str2 = sSLSocketFactory != null ? "https" : "http";
        if (str2.equalsIgnoreCase("http")) {
            bVar.e = "http";
        } else {
            if (!str2.equalsIgnoreCase("https")) {
                throw new IllegalArgumentException("unexpected scheme: ".concat(str2));
            }
            bVar.e = "https";
        }
        if (str == null) {
            throw new NullPointerException("host == null");
        }
        String strD = nc.b.d(str, 0, str.length());
        if (strD == null) {
            throw new IllegalArgumentException("unexpected host: ".concat(str));
        }
        bVar.d = strD;
        if (i <= 0 || i > 65535) {
            throw new IllegalArgumentException("unexpected port: ".concat(String.valueOf(i)));
        }
        bVar.a = i;
        this.d = bVar.a();
        if (myVar == null) {
            throw new NullPointerException("dns == null");
        }
        this.f95906g = myVar;
        if (socketFactory == null) {
            throw new NullPointerException("socketFactory == null");
        }
        this.a = socketFactory;
        if (mlVar == null) {
            throw new NullPointerException("proxyAuthenticator == null");
        }
        this.h = mlVar;
        if (list == null) {
            throw new NullPointerException("protocols == null");
        }
        this.j = nu.e(list);
        if (list2 == null) {
            throw new NullPointerException("connectionSpecs == null");
        }
        this.e = nu.e(list2);
        if (proxySelector == null) {
            throw new NullPointerException("proxySelector == null");
        }
        this.i = proxySelector;
        this.b = proxy;
        this.c = sSLSocketFactory;
        this.f = hostnameVerifier;
        this.k = mpVar;
    }

    public final my a() {
        return this.f95906g;
    }

    public final ml b() {
        return this.h;
    }

    public final nc c() {
        return this.d;
    }

    public final List<ng> d() {
        return this.j;
    }

    public final ProxySelector e() {
        return this.i;
    }

    public final boolean equals(Object obj) {
        if (!(obj instanceof mh)) {
            return false;
        }
        mh mhVar = (mh) obj;
        return this.d.equals(mhVar.d) && c(mhVar);
    }

    public final mp f() {
        return this.k;
    }

    public final HostnameVerifier g() {
        return this.f;
    }

    public final SSLSocketFactory h() {
        return this.c;
    }

    public final int hashCode() {
        int iHashCode = (((((((((((this.d.hashCode() + 527) * 31) + this.f95906g.hashCode()) * 31) + this.h.hashCode()) * 31) + this.j.hashCode()) * 31) + this.e.hashCode()) * 31) + this.i.hashCode()) * 31;
        Proxy proxy = this.b;
        int iHashCode2 = (iHashCode + (proxy != null ? proxy.hashCode() : 0)) * 31;
        SSLSocketFactory sSLSocketFactory = this.c;
        int iHashCode3 = (iHashCode2 + (sSLSocketFactory != null ? sSLSocketFactory.hashCode() : 0)) * 31;
        HostnameVerifier hostnameVerifier = this.f;
        int iHashCode4 = (iHashCode3 + (hostnameVerifier != null ? hostnameVerifier.hashCode() : 0)) * 31;
        mp mpVar = this.k;
        return iHashCode4 + (mpVar != null ? mpVar.hashCode() : 0);
    }

    public final String toString() {
        StringBuilder sb = new StringBuilder("Address{");
        sb.append(this.d.g());
        sb.append(Constants.SEPARATOR);
        sb.append(this.d.h());
        if (this.b != null) {
            sb.append(", proxy=");
            sb.append(this.b);
        } else {
            sb.append(", proxySelector=");
            sb.append(this.i);
        }
        sb.append("}");
        return sb.toString();
    }

    public final boolean c(mh mhVar) {
        return this.f95906g.equals(mhVar.f95906g) && this.h.equals(mhVar.h) && this.j.equals(mhVar.j) && this.e.equals(mhVar.e) && this.i.equals(mhVar.i) && nu.a(this.b, mhVar.b) && nu.a(this.c, mhVar.c) && nu.a(this.f, mhVar.f) && nu.a(this.k, mhVar.k) && c().h() == mhVar.c().h();
    }
}