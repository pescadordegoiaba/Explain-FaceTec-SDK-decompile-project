package com.facetec.sdk;

import android.content.ComponentName;
import android.content.ServiceConnection;
import android.os.IBinder;

/* JADX INFO: loaded from: classes4.dex */
public final class mk implements ServiceConnection {
    private static int b = 1;
    private static int d;
    public boolean c = false;
    public hx e;

    public mk(hx hxVar) {
        this.e = hxVar;
    }

    public final hx c() {
        int i = d;
        hx hxVar = this.e;
        b = (i + 23) % 128;
        return hxVar;
    }

    public final boolean d() {
        int i = d;
        boolean z = this.c;
        int i2 = i + 73;
        b = i2 % 128;
        if (i2 % 2 != 0) {
            return z;
        }
        throw null;
    }

    @Override // android.content.ServiceConnection
    public final void onServiceConnected(ComponentName componentName, IBinder iBinder) {
        int i = b + 111;
        d = i % 128;
        this.c = i % 2 == 0;
    }

    @Override // android.content.ServiceConnection
    public final void onServiceDisconnected(ComponentName componentName) {
        int i = d + 35;
        b = i % 128;
        this.c = i % 2 == 0;
        this.e.d();
    }
}