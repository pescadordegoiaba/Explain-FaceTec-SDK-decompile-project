package com.facetec.sdk;

/* JADX INFO: loaded from: classes4.dex */
public interface ml {
    public static final ml b = new ml() { // from class: com.facetec.sdk.ml.2
        @Override // com.facetec.sdk.ml
        public final nj d() {
            return null;
        }
    };

    nj d();
}