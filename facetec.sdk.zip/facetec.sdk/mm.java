package com.facetec.sdk;

import java.io.IOException;

/* JADX INFO: loaded from: classes4.dex */
public interface mm {
    void b(nh nhVar);

    void c(IOException iOException);
}