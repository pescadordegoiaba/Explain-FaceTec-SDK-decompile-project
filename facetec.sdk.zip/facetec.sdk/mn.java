package com.facetec.sdk;

/* JADX INFO: loaded from: classes4.dex */
public interface mn extends Cloneable {
    void e(mm mmVar);
}