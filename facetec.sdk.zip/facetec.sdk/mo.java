package com.facetec.sdk;

import java.util.concurrent.TimeUnit;

/* JADX INFO: loaded from: classes4.dex */
public final class mo {
    public final boolean a;
    private final boolean b;
    private final int c;
    public final boolean d;
    private final boolean e;
    private final int f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    private final int f95907g;
    private final boolean h;
    private final int i;
    private final boolean j;
    private final boolean k;
    private final boolean m;
    private String n;

    public static final class b {
        boolean b;
        boolean c;

        /* JADX INFO: renamed from: g, reason: collision with root package name */
        boolean f95908g;
        boolean h;
        boolean j;
        int d = -1;
        int a = -1;
        int e = -1;

        public final mo b() {
            return new mo(this);
        }
    }

    static {
        b bVar = new b();
        bVar.b = true;
        bVar.b();
        b bVar2 = new b();
        bVar2.j = true;
        long seconds = TimeUnit.SECONDS.toSeconds(2147483647L);
        bVar2.a = seconds > 2147483647L ? Integer.MAX_VALUE : (int) seconds;
        bVar2.b();
    }

    private mo(boolean z, boolean z2, int i, int i2, boolean z3, boolean z4, boolean z5, int i3, int i4, boolean z6, boolean z7, boolean z8, String str) {
        this.b = z;
        this.e = z2;
        this.c = i;
        this.f95907g = i2;
        this.h = z3;
        this.j = z4;
        this.a = z5;
        this.i = i3;
        this.f = i4;
        this.d = z6;
        this.k = z7;
        this.m = z8;
        this.n = str;
    }

    public final int a() {
        return this.c;
    }

    public final boolean b() {
        return this.b;
    }

    public final boolean c() {
        return this.e;
    }

    public final boolean d() {
        return this.h;
    }

    public final boolean e() {
        return this.j;
    }

    public final int f() {
        return this.i;
    }

    public final int i() {
        return this.f;
    }

    public final String toString() {
        String string;
        String str = this.n;
        if (str != null) {
            return str;
        }
        StringBuilder sb = new StringBuilder();
        if (this.b) {
            sb.append("no-cache, ");
        }
        if (this.e) {
            sb.append("no-store, ");
        }
        if (this.c != -1) {
            sb.append("max-age=");
            sb.append(this.c);
            sb.append(", ");
        }
        if (this.f95907g != -1) {
            sb.append("s-maxage=");
            sb.append(this.f95907g);
            sb.append(", ");
        }
        if (this.h) {
            sb.append("private, ");
        }
        if (this.j) {
            sb.append("public, ");
        }
        if (this.a) {
            sb.append("must-revalidate, ");
        }
        if (this.i != -1) {
            sb.append("max-stale=");
            sb.append(this.i);
            sb.append(", ");
        }
        if (this.f != -1) {
            sb.append("min-fresh=");
            sb.append(this.f);
            sb.append(", ");
        }
        if (this.d) {
            sb.append("only-if-cached, ");
        }
        if (this.k) {
            sb.append("no-transform, ");
        }
        if (this.m) {
            sb.append("immutable, ");
        }
        if (sb.length() == 0) {
            string = "";
        } else {
            sb.delete(sb.length() - 2, sb.length());
            string = sb.toString();
        }
        this.n = string;
        return string;
    }

    /* JADX WARN: Removed duplicated region for block: B:15:0x0044  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public static com.facetec.sdk.mo b(com.facetec.sdk.mz r23) {
        /*
            Method dump skipped, instruction units count: 357
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: com.facetec.sdk.mo.b(com.facetec.sdk.mz):com.facetec.sdk.mo");
    }

    public mo(b bVar) {
        this.b = bVar.b;
        this.e = bVar.c;
        this.c = bVar.d;
        this.f95907g = -1;
        this.h = false;
        this.j = false;
        this.a = false;
        this.i = bVar.a;
        this.f = bVar.e;
        this.d = bVar.j;
        this.k = bVar.f95908g;
        this.m = bVar.h;
    }
}