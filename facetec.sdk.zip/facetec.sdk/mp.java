package com.facetec.sdk;

import ai.luciq.library.networkv2.request.Constants;
import java.security.cert.Certificate;
import java.security.cert.X509Certificate;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;
import javax.net.ssl.SSLPeerUnverifiedException;

/* JADX INFO: loaded from: classes4.dex */
public final class mp {
    public static final mp d = new d().b();
    final po b;
    final Set<a> c;

    public static final class a {
        final String a;
        final String b;
        final qb d;
        final String e;

        public a(String str, String str2) {
            String strG;
            this.e = str;
            if (str.startsWith("*.")) {
                StringBuilder sb = new StringBuilder("http://");
                sb.append(str.substring(2));
                strG = nc.b(sb.toString()).g();
            } else {
                strG = nc.b("http://".concat(str)).g();
            }
            this.b = strG;
            if (str2.startsWith("sha1/")) {
                this.a = "sha1/";
                this.d = qb.a(str2.substring(5));
            } else {
                if (!str2.startsWith("sha256/")) {
                    throw new IllegalArgumentException("pins must start with 'sha256/' or 'sha1/': ".concat(str2));
                }
                this.a = "sha256/";
                this.d = qb.a(str2.substring(7));
            }
            if (this.d == null) {
                throw new IllegalArgumentException("pins must be base64: ".concat(str2));
            }
        }

        public final boolean equals(Object obj) {
            if (!(obj instanceof a)) {
                return false;
            }
            a aVar = (a) obj;
            return this.e.equals(aVar.e) && this.a.equals(aVar.a) && this.d.equals(aVar.d);
        }

        public final int hashCode() {
            return ((((this.e.hashCode() + 527) * 31) + this.a.hashCode()) * 31) + this.d.hashCode();
        }

        public final String toString() {
            StringBuilder sb = new StringBuilder();
            sb.append(this.a);
            sb.append(this.d.c());
            return sb.toString();
        }
    }

    public static final class d {
        public final List<a> a = new ArrayList();

        public final mp b() {
            return new mp(new LinkedHashSet(this.a), null);
        }
    }

    public mp(Set<a> set, po poVar) {
        this.c = set;
        this.b = poVar;
    }

    public static String b(Certificate certificate) {
        if (!(certificate instanceof X509Certificate)) {
            throw new IllegalArgumentException("Certificate pinning requires X509 certificates");
        }
        StringBuilder sb = new StringBuilder("sha256/");
        sb.append(c((X509Certificate) certificate).c());
        return sb.toString();
    }

    private static qb c(X509Certificate x509Certificate) {
        return qb.c(x509Certificate.getPublicKey().getEncoded()).a();
    }

    public final boolean equals(Object obj) {
        if (obj == this) {
            return true;
        }
        if (!(obj instanceof mp)) {
            return false;
        }
        mp mpVar = (mp) obj;
        return nu.a(this.b, mpVar.b) && this.c.equals(mpVar.c);
    }

    public final int hashCode() {
        po poVar = this.b;
        return ((poVar != null ? poVar.hashCode() : 0) * 31) + this.c.hashCode();
    }

    public final void b(String str, List<Certificate> list) throws SSLPeerUnverifiedException {
        int i;
        List arrayList = Collections.EMPTY_LIST;
        Iterator<a> it = this.c.iterator();
        while (true) {
            zEquals = false;
            boolean zEquals = false;
            if (!it.hasNext()) {
                break;
            }
            a next = it.next();
            if (next.e.startsWith("*.")) {
                int iIndexOf = str.indexOf(46);
                if ((str.length() - iIndexOf) - 1 == next.b.length()) {
                    String str2 = next.b;
                    if (str.regionMatches(false, iIndexOf + 1, str2, 0, str2.length())) {
                        zEquals = true;
                    }
                }
            } else {
                zEquals = str.equals(next.b);
            }
            if (zEquals) {
                if (arrayList.isEmpty()) {
                    arrayList = new ArrayList();
                }
                arrayList.add(next);
            }
        }
        if (arrayList.isEmpty()) {
            return;
        }
        po poVar = this.b;
        List<Certificate> listA = poVar != null ? poVar.a(list, str) : list;
        int size = listA.size();
        for (int i2 = 0; i2 < size; i2++) {
            X509Certificate x509Certificate = (X509Certificate) listA.get(i2);
            int size2 = arrayList.size();
            qb qbVarC = null;
            qb qbVarB = null;
            for (int i3 = 0; i3 < size2; i3++) {
                a aVar = (a) arrayList.get(i3);
                if (aVar.a.equals("sha256/")) {
                    if (qbVarC == null) {
                        qbVarC = c(x509Certificate);
                    }
                    if (aVar.d.equals(qbVarC)) {
                        return;
                    }
                } else if (aVar.a.equals("sha1/")) {
                    if (qbVarB == null) {
                        qbVarB = qb.c(x509Certificate.getPublicKey().getEncoded()).b();
                    }
                    if (aVar.d.equals(qbVarB)) {
                        return;
                    }
                } else {
                    StringBuilder sb = new StringBuilder("unsupported hashAlgorithm: ");
                    sb.append(aVar.a);
                    throw new AssertionError(sb.toString());
                }
            }
        }
        StringBuilder sb2 = new StringBuilder("Certificate pinning failure!\n  Peer certificate chain:");
        int size3 = listA.size();
        for (int i4 = 0; i4 < size3; i4++) {
            X509Certificate x509Certificate2 = (X509Certificate) listA.get(i4);
            sb2.append("\n    ");
            sb2.append(b(x509Certificate2));
            sb2.append(": ");
            sb2.append(x509Certificate2.getSubjectDN().getName());
        }
        sb2.append("\n  Pinned certificates for ");
        sb2.append(str);
        sb2.append(Constants.SEPARATOR);
        int size4 = arrayList.size();
        for (i = 0; i < size4; i++) {
            a aVar2 = (a) arrayList.get(i);
            sb2.append("\n    ");
            sb2.append(aVar2);
        }
        throw new SSLPeerUnverifiedException(sb2.toString());
    }
}