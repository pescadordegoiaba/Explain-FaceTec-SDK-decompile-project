package com.facetec.sdk;

import android.content.Context;
import com.facetec.sdk.cb;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import net.sf.scuba.smartcards.ISO7816;
import net.sf.scuba.smartcards.ISOFileInfo;
import org.jmrtd.PassportService;
import org.jmrtd.lds.CVCAFile;

/* JADX INFO: loaded from: classes4.dex */
public final class mq {
    public static final mq a;
    public static final mq b;
    public static final mq c;
    public static final mq e;
    public static final mq f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public static final mq f95909g;
    public static final mq h;
    public static final mq i;
    public static final mq j;
    public static final mq k;
    public static final mq l;
    public static final mq m;
    public static final mq n;
    public static final mq o;
    public static final mq q;
    public static final mq r;
    public static final mq s;
    public static final mq t;
    final String p;
    static final Comparator<String> d = new Comparator<String>() { // from class: com.facetec.sdk.mq.4
        private static final byte[] $$a = null;
        private static final int $$b = 0;
        private static int a;
        private static int e;

        static {
            init$0();
            a = 0;
            e = 1;
        }

        /* JADX WARN: Removed duplicated region for block: B:10:0x002a  */
        /* JADX WARN: Removed duplicated region for block: B:8:0x0022  */
        /* JADX WARN: Unsupported multi-entry loop pattern (BACK_EDGE: B:10:0x002a -> B:11:0x002c). Please report as a decompilation issue!!! */
        /*
            Code decompiled incorrectly, please refer to instructions dump.
            To view partially-correct code enable 'Show inconsistent code' option in preferences
        */
        private static void b(short r6, int r7, short r8, java.lang.Object[] r9) {
            /*
                byte[] r0 = com.facetec.sdk.mq.AnonymousClass4.$$a
                int r7 = r7 * 17
                int r7 = 18 - r7
                int r8 = r8 * 17
                int r8 = r8 + 4
                int r6 = r6 * 2
                int r6 = r6 + 99
                byte[] r1 = new byte[r7]
                r2 = 0
                if (r0 != 0) goto L17
                r3 = r7
                r6 = r8
                r5 = r2
                goto L2c
            L17:
                r3 = r8
                r8 = r6
                r6 = r3
                r3 = r2
            L1b:
                byte r4 = (byte) r8
                int r5 = r3 + 1
                r1[r3] = r4
                if (r5 != r7) goto L2a
                java.lang.String r6 = new java.lang.String
                r6.<init>(r1, r2)
                r9[r2] = r6
                return
            L2a:
                r3 = r0[r6]
            L2c:
                int r8 = r8 + r3
                int r6 = r6 + 1
                int r8 = r8 + 3
                r3 = r5
                goto L1b
            */
            throw new UnsupportedOperationException("Method not decompiled: com.facetec.sdk.mq.AnonymousClass4.b(short, int, short, java.lang.Object[]):void");
        }

        private static void e() throws Throwable {
            int i2 = a + 61;
            e = i2 % 128;
            if (i2 % 2 == 0) {
                cb.a.class.getField("c").get(null);
                throw null;
            }
            Object obj = cb.a.class.getField("c").get(null);
            int i3 = a;
            int i4 = i3 & 55;
            int i5 = -(-((i3 ^ 55) | i4));
            e = ((i4 & i5) + (i5 | i4)) % 128;
            try {
                Object[] objArr = {null, obj};
                byte[] bArr = $$a;
                byte b2 = (byte) (bArr[9] + 1);
                byte b3 = b2;
                Object[] objArr2 = new Object[1];
                b(b2, b3, b3, objArr2);
                Class<?> cls = Class.forName((String) objArr2[0]);
                byte b4 = (byte) (-bArr[9]);
                byte b5 = b4;
                Object[] objArr3 = new Object[1];
                b(b4, b5, b5, objArr3);
                Method method = cls.getMethod((String) objArr3[0], Context.class, cb.a.class);
                method.setAccessible(true);
                method.invoke(null, objArr);
                int i6 = a;
                int i7 = i6 & 117;
                int i8 = ((i6 ^ 117) | i7) << 1;
                int i9 = -((i6 | 117) & (~i7));
                e = (((i8 | i9) << 1) - (i9 ^ i8)) % 128;
            } catch (Throwable th) {
                Throwable cause = th.getCause();
                if (cause == null) {
                    throw th;
                }
                throw cause;
            }
        }

        public static void init$0() {
            $$a = new byte[]{ISOFileInfo.FCI_BYTE, -53, -88, 102, 9, -5, -66, 53, -8, -1, -1, PassportService.SFI_DG12, -18, -5, -56, CVCAFile.CAR_TAG, -18, 4, ISO7816.INS_GET_RESPONSE, ISO7816.INS_INCREASE, -4};
            $$b = 21;
        }

        @Override // java.util.Comparator
        public final /* synthetic */ int compare(String str, String str2) {
            String str3 = str;
            String str4 = str2;
            int iMin = Math.min(str3.length(), str4.length());
            for (int i2 = 4; i2 < iMin; i2++) {
                char cCharAt = str3.charAt(i2);
                char cCharAt2 = str4.charAt(i2);
                if (cCharAt != cCharAt2) {
                    return cCharAt < cCharAt2 ? -1 : 1;
                }
            }
            int length = str3.length();
            int length2 = str4.length();
            if (length != length2) {
                return length < length2 ? -1 : 1;
            }
            return 0;
        }
    };
    private static final Map<String, mq> x = new LinkedHashMap();

    static {
        c("SSL_RSA_WITH_NULL_MD5");
        c("SSL_RSA_WITH_NULL_SHA");
        c("SSL_RSA_EXPORT_WITH_RC4_40_MD5");
        c("SSL_RSA_WITH_RC4_128_MD5");
        c("SSL_RSA_WITH_RC4_128_SHA");
        c("SSL_RSA_EXPORT_WITH_DES40_CBC_SHA");
        c("SSL_RSA_WITH_DES_CBC_SHA");
        e = c("SSL_RSA_WITH_3DES_EDE_CBC_SHA");
        c("SSL_DHE_DSS_EXPORT_WITH_DES40_CBC_SHA");
        c("SSL_DHE_DSS_WITH_DES_CBC_SHA");
        c("SSL_DHE_DSS_WITH_3DES_EDE_CBC_SHA");
        c("SSL_DHE_RSA_EXPORT_WITH_DES40_CBC_SHA");
        c("SSL_DHE_RSA_WITH_DES_CBC_SHA");
        c("SSL_DHE_RSA_WITH_3DES_EDE_CBC_SHA");
        c("SSL_DH_anon_EXPORT_WITH_RC4_40_MD5");
        c("SSL_DH_anon_WITH_RC4_128_MD5");
        c("SSL_DH_anon_EXPORT_WITH_DES40_CBC_SHA");
        c("SSL_DH_anon_WITH_DES_CBC_SHA");
        c("SSL_DH_anon_WITH_3DES_EDE_CBC_SHA");
        c("TLS_KRB5_WITH_DES_CBC_SHA");
        c("TLS_KRB5_WITH_3DES_EDE_CBC_SHA");
        c("TLS_KRB5_WITH_RC4_128_SHA");
        c("TLS_KRB5_WITH_DES_CBC_MD5");
        c("TLS_KRB5_WITH_3DES_EDE_CBC_MD5");
        c("TLS_KRB5_WITH_RC4_128_MD5");
        c("TLS_KRB5_EXPORT_WITH_DES_CBC_40_SHA");
        c("TLS_KRB5_EXPORT_WITH_RC4_40_SHA");
        c("TLS_KRB5_EXPORT_WITH_DES_CBC_40_MD5");
        c("TLS_KRB5_EXPORT_WITH_RC4_40_MD5");
        a = c("TLS_RSA_WITH_AES_128_CBC_SHA");
        c("TLS_DHE_DSS_WITH_AES_128_CBC_SHA");
        c("TLS_DHE_RSA_WITH_AES_128_CBC_SHA");
        c("TLS_DH_anon_WITH_AES_128_CBC_SHA");
        b = c("TLS_RSA_WITH_AES_256_CBC_SHA");
        c("TLS_DHE_DSS_WITH_AES_256_CBC_SHA");
        c("TLS_DHE_RSA_WITH_AES_256_CBC_SHA");
        c("TLS_DH_anon_WITH_AES_256_CBC_SHA");
        c("TLS_RSA_WITH_NULL_SHA256");
        c("TLS_RSA_WITH_AES_128_CBC_SHA256");
        c("TLS_RSA_WITH_AES_256_CBC_SHA256");
        c("TLS_DHE_DSS_WITH_AES_128_CBC_SHA256");
        c("TLS_RSA_WITH_CAMELLIA_128_CBC_SHA");
        c("TLS_DHE_DSS_WITH_CAMELLIA_128_CBC_SHA");
        c("TLS_DHE_RSA_WITH_CAMELLIA_128_CBC_SHA");
        c("TLS_DHE_RSA_WITH_AES_128_CBC_SHA256");
        c("TLS_DHE_DSS_WITH_AES_256_CBC_SHA256");
        c("TLS_DHE_RSA_WITH_AES_256_CBC_SHA256");
        c("TLS_DH_anon_WITH_AES_128_CBC_SHA256");
        c("TLS_DH_anon_WITH_AES_256_CBC_SHA256");
        c("TLS_RSA_WITH_CAMELLIA_256_CBC_SHA");
        c("TLS_DHE_DSS_WITH_CAMELLIA_256_CBC_SHA");
        c("TLS_DHE_RSA_WITH_CAMELLIA_256_CBC_SHA");
        c("TLS_PSK_WITH_RC4_128_SHA");
        c("TLS_PSK_WITH_3DES_EDE_CBC_SHA");
        c("TLS_PSK_WITH_AES_128_CBC_SHA");
        c("TLS_PSK_WITH_AES_256_CBC_SHA");
        c("TLS_RSA_WITH_SEED_CBC_SHA");
        c = c("TLS_RSA_WITH_AES_128_GCM_SHA256");
        h = c("TLS_RSA_WITH_AES_256_GCM_SHA384");
        c("TLS_DHE_RSA_WITH_AES_128_GCM_SHA256");
        c("TLS_DHE_RSA_WITH_AES_256_GCM_SHA384");
        c("TLS_DHE_DSS_WITH_AES_128_GCM_SHA256");
        c("TLS_DHE_DSS_WITH_AES_256_GCM_SHA384");
        c("TLS_DH_anon_WITH_AES_128_GCM_SHA256");
        c("TLS_DH_anon_WITH_AES_256_GCM_SHA384");
        c("TLS_EMPTY_RENEGOTIATION_INFO_SCSV");
        c("TLS_FALLBACK_SCSV");
        c("TLS_ECDH_ECDSA_WITH_NULL_SHA");
        c("TLS_ECDH_ECDSA_WITH_RC4_128_SHA");
        c("TLS_ECDH_ECDSA_WITH_3DES_EDE_CBC_SHA");
        c("TLS_ECDH_ECDSA_WITH_AES_128_CBC_SHA");
        c("TLS_ECDH_ECDSA_WITH_AES_256_CBC_SHA");
        c("TLS_ECDHE_ECDSA_WITH_NULL_SHA");
        c("TLS_ECDHE_ECDSA_WITH_RC4_128_SHA");
        c("TLS_ECDHE_ECDSA_WITH_3DES_EDE_CBC_SHA");
        c("TLS_ECDHE_ECDSA_WITH_AES_128_CBC_SHA");
        c("TLS_ECDHE_ECDSA_WITH_AES_256_CBC_SHA");
        c("TLS_ECDH_RSA_WITH_NULL_SHA");
        c("TLS_ECDH_RSA_WITH_RC4_128_SHA");
        c("TLS_ECDH_RSA_WITH_3DES_EDE_CBC_SHA");
        c("TLS_ECDH_RSA_WITH_AES_128_CBC_SHA");
        c("TLS_ECDH_RSA_WITH_AES_256_CBC_SHA");
        c("TLS_ECDHE_RSA_WITH_NULL_SHA");
        c("TLS_ECDHE_RSA_WITH_RC4_128_SHA");
        c("TLS_ECDHE_RSA_WITH_3DES_EDE_CBC_SHA");
        i = c("TLS_ECDHE_RSA_WITH_AES_128_CBC_SHA");
        f95909g = c("TLS_ECDHE_RSA_WITH_AES_256_CBC_SHA");
        c("TLS_ECDH_anon_WITH_NULL_SHA");
        c("TLS_ECDH_anon_WITH_RC4_128_SHA");
        c("TLS_ECDH_anon_WITH_3DES_EDE_CBC_SHA");
        c("TLS_ECDH_anon_WITH_AES_128_CBC_SHA");
        c("TLS_ECDH_anon_WITH_AES_256_CBC_SHA");
        c("TLS_ECDHE_ECDSA_WITH_AES_128_CBC_SHA256");
        c("TLS_ECDHE_ECDSA_WITH_AES_256_CBC_SHA384");
        c("TLS_ECDH_ECDSA_WITH_AES_128_CBC_SHA256");
        c("TLS_ECDH_ECDSA_WITH_AES_256_CBC_SHA384");
        c("TLS_ECDHE_RSA_WITH_AES_128_CBC_SHA256");
        c("TLS_ECDHE_RSA_WITH_AES_256_CBC_SHA384");
        c("TLS_ECDH_RSA_WITH_AES_128_CBC_SHA256");
        c("TLS_ECDH_RSA_WITH_AES_256_CBC_SHA384");
        f = c("TLS_ECDHE_ECDSA_WITH_AES_128_GCM_SHA256");
        j = c("TLS_ECDHE_ECDSA_WITH_AES_256_GCM_SHA384");
        c("TLS_ECDH_ECDSA_WITH_AES_128_GCM_SHA256");
        c("TLS_ECDH_ECDSA_WITH_AES_256_GCM_SHA384");
        n = c("TLS_ECDHE_RSA_WITH_AES_128_GCM_SHA256");
        o = c("TLS_ECDHE_RSA_WITH_AES_256_GCM_SHA384");
        c("TLS_ECDH_RSA_WITH_AES_128_GCM_SHA256");
        c("TLS_ECDH_RSA_WITH_AES_256_GCM_SHA384");
        c("TLS_ECDHE_PSK_WITH_AES_128_CBC_SHA");
        c("TLS_ECDHE_PSK_WITH_AES_256_CBC_SHA");
        l = c("TLS_ECDHE_RSA_WITH_CHACHA20_POLY1305_SHA256");
        m = c("TLS_ECDHE_ECDSA_WITH_CHACHA20_POLY1305_SHA256");
        c("TLS_DHE_RSA_WITH_CHACHA20_POLY1305_SHA256");
        c("TLS_ECDHE_PSK_WITH_CHACHA20_POLY1305_SHA256");
        k = c("TLS_AES_128_GCM_SHA256");
        r = c("TLS_AES_256_GCM_SHA384");
        q = c("TLS_CHACHA20_POLY1305_SHA256");
        s = c("TLS_AES_128_CCM_SHA256");
        t = c("TLS_AES_256_CCM_8_SHA256");
    }

    private mq(String str) {
        str.getClass();
        this.p = str;
    }

    public static synchronized mq a(String str) {
        mq mqVar;
        String string;
        try {
            Map<String, mq> map = x;
            mqVar = map.get(str);
            if (mqVar == null) {
                if (str.startsWith("TLS_")) {
                    StringBuilder sb = new StringBuilder("SSL_");
                    sb.append(str.substring(4));
                    string = sb.toString();
                } else if (str.startsWith("SSL_")) {
                    StringBuilder sb2 = new StringBuilder("TLS_");
                    sb2.append(str.substring(4));
                    string = sb2.toString();
                } else {
                    string = str;
                }
                mqVar = map.get(string);
                if (mqVar == null) {
                    mqVar = new mq(str);
                }
                map.put(str, mqVar);
            }
        } catch (Throwable th) {
            throw th;
        }
        return mqVar;
    }

    private static mq c(String str) {
        mq mqVar = new mq(str);
        x.put(str, mqVar);
        return mqVar;
    }

    public final String toString() {
        return this.p;
    }

    public static List<mq> a(String... strArr) {
        ArrayList arrayList = new ArrayList(strArr.length);
        for (String str : strArr) {
            arrayList.add(a(str));
        }
        return Collections.unmodifiableList(arrayList);
    }
}