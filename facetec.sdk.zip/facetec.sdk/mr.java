package com.facetec.sdk;

import java.util.Collections;
import java.util.List;

/* JADX INFO: loaded from: classes4.dex */
public interface mr {
    public static final mr a = new mr() { // from class: com.facetec.sdk.mr.3
        @Override // com.facetec.sdk.mr
        public final List<ms> b() {
            return Collections.EMPTY_LIST;
        }
    };

    List<ms> b();
}