package com.facetec.sdk;

import android.graphics.drawable.Drawable;
import android.text.TextUtils;
import android.view.ViewConfiguration;
import android.widget.ExpandableListView;
import com.incode.welcome_sdk.modules.SelfieScan;
import com.plaid.internal.EnumC41897g;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.List;
import java.util.regex.Pattern;
import org.jmrtd.PassportService;

/* JADX INFO: loaded from: classes4.dex */
public final class ms {
    private static final byte[] $$a = null;
    private static final int $$b = 0;
    private static final Pattern a;
    private static final Pattern c;
    private static final Pattern e;
    private static final Pattern h;
    private static char[] k;
    private static long l;
    public final String b;
    public final String d;
    private final String f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    private final boolean f95910g;
    private final long i;
    private final String j;
    private final boolean m;
    private final boolean n;
    private final boolean o;

    private static String $$c(int i, short s, short s2) {
        int i2 = s2 * 3;
        int i3 = 111 - s;
        byte[] bArr = $$a;
        int i4 = 3 - (i * 3);
        byte[] bArr2 = new byte[i2 + 1];
        int i5 = -1;
        if (bArr == null) {
            i3 = (-i3) + i2;
            i4++;
            bArr = bArr;
            i5 = -1;
        }
        while (true) {
            int i6 = i5 + 1;
            bArr2[i6] = (byte) i3;
            if (i6 == i2) {
                return new String(bArr2, 0);
            }
            i3 = (-bArr[i4]) + i3;
            i4++;
            bArr = bArr;
            i5 = i6;
        }
    }

    static {
        init$0();
        d();
        a = Pattern.compile("(\\d{2,4})[^\\d]*");
        c = Pattern.compile("(?i)(jan|feb|mar|apr|may|jun|jul|aug|sep|oct|nov|dec).*");
        e = Pattern.compile("(\\d{1,2})[^\\d]*");
        h = Pattern.compile("(\\d{1,2}):(\\d{1,2}):(\\d{1,2})[^\\d]*");
    }

    private ms(String str, String str2, long j, String str3, String str4, boolean z, boolean z2, boolean z3, boolean z4) {
        this.b = str;
        this.d = str2;
        this.i = j;
        this.j = str3;
        this.f = str4;
        this.f95910g = z;
        this.m = z2;
        this.o = z3;
        this.n = z4;
    }

    public static List<ms> b(nc ncVar, mz mzVar) throws Throwable {
        int iD = mzVar.d();
        ArrayList arrayList = null;
        for (int i = 0; i < iD; i++) {
            if ("Set-Cookie".equalsIgnoreCase(mzVar.a(i))) {
                if (arrayList == null) {
                    arrayList = new ArrayList(2);
                }
                arrayList.add(mzVar.b(i));
            }
        }
        List listUnmodifiableList = arrayList != null ? Collections.unmodifiableList(arrayList) : Collections.EMPTY_LIST;
        int size = listUnmodifiableList.size();
        ArrayList arrayList2 = null;
        for (int i2 = 0; i2 < size; i2++) {
            String str = (String) listUnmodifiableList.get(i2);
            try {
                Object[] objArr = new Object[1];
                p((-1) - ExpandableListView.getPackedPositionChild(0L), (char) ((-1) - TextUtils.lastIndexOf("", '0')), (ViewConfiguration.getTapTimeout() >> 16) + 16, objArr);
                Class<?> cls = Class.forName((String) objArr[0]);
                Object[] objArr2 = new Object[1];
                p(17 - (ViewConfiguration.getScrollFriction() > SelfieScan.RECOGNITION_FAIL_RESULT ? 1 : (ViewConfiguration.getScrollFriction() == SelfieScan.RECOGNITION_FAIL_RESULT ? 0 : -1)), (char) (ViewConfiguration.getKeyRepeatTimeout() >> 16), 17 - Drawable.resolveOpacity(0, 0), objArr2);
                ms msVarE = e(((Long) cls.getMethod((String) objArr2[0], null).invoke(null, null)).longValue(), ncVar, str);
                if (msVarE != null) {
                    if (arrayList2 == null) {
                        arrayList2 = new ArrayList();
                    }
                    arrayList2.add(msVarE);
                }
            } catch (Throwable th) {
                Throwable cause = th.getCause();
                if (cause != null) {
                    throw cause;
                }
                throw th;
            }
        }
        return arrayList2 != null ? Collections.unmodifiableList(arrayList2) : Collections.EMPTY_LIST;
    }

    private static long c(String str) {
        try {
            long j = Long.parseLong(str);
            if (j <= 0) {
                return Long.MIN_VALUE;
            }
            return j;
        } catch (NumberFormatException e2) {
            if (str.matches("-?\\d+")) {
                return str.startsWith("-") ? Long.MIN_VALUE : Long.MAX_VALUE;
            }
            throw e2;
        }
    }

    private static int d(String str, int i, int i2, boolean z) {
        while (i < i2) {
            char cCharAt = str.charAt(i);
            if (((cCharAt < ' ' && cCharAt != '\t') || cCharAt >= 127 || (cCharAt >= '0' && cCharAt <= '9') || ((cCharAt >= 'a' && cCharAt <= 'z') || ((cCharAt >= 'A' && cCharAt <= 'Z') || cCharAt == ':'))) == (!z)) {
                return i;
            }
            i++;
        }
        return i2;
    }

    /* JADX WARN: Removed duplicated region for block: B:169:0x032a A[RETURN] */
    /* JADX WARN: Type inference failed for: r3v0 */
    /* JADX WARN: Type inference failed for: r3v1, types: [boolean, int] */
    /* JADX WARN: Type inference failed for: r3v15 */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    private static com.facetec.sdk.ms e(long r35, com.facetec.sdk.nc r37, java.lang.String r38) {
        /*
            Method dump skipped, instruction units count: 861
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: com.facetec.sdk.ms.e(long, com.facetec.sdk.nc, java.lang.String):com.facetec.sdk.ms");
    }

    public static void init$0() {
        $$a = new byte[]{PassportService.SFI_DG15, 58, -59};
        $$b = EnumC41897g.SDK_ASSET_ILLUSTRATION_PAYWITHPLAID_LOGO_VALUE;
    }

    /* JADX WARN: Removed duplicated region for block: B:35:0x0176  */
    /* JADX WARN: Removed duplicated region for block: B:36:0x0177  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    private static void p(int r27, char r28, int r29, java.lang.Object[] r30) throws java.lang.Throwable {
        /*
            Method dump skipped, instruction units count: 384
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: com.facetec.sdk.ms.p(int, char, int, java.lang.Object[]):void");
    }

    public final boolean equals(Object obj) {
        if (!(obj instanceof ms)) {
            return false;
        }
        ms msVar = (ms) obj;
        return msVar.b.equals(this.b) && msVar.d.equals(this.d) && msVar.j.equals(this.j) && msVar.f.equals(this.f) && msVar.i == this.i && msVar.f95910g == this.f95910g && msVar.m == this.m && msVar.n == this.n && msVar.o == this.o;
    }

    public final int hashCode() {
        int iHashCode = (((((((this.b.hashCode() + 527) * 31) + this.d.hashCode()) * 31) + this.j.hashCode()) * 31) + this.f.hashCode()) * 31;
        long j = this.i;
        return ((((((((iHashCode + ((int) (j ^ (j >>> 32)))) * 31) + (!this.f95910g ? 1 : 0)) * 31) + (!this.m ? 1 : 0)) * 31) + (!this.n ? 1 : 0)) * 31) + (!this.o ? 1 : 0);
    }

    public final String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append(this.b);
        sb.append('=');
        sb.append(this.d);
        if (this.n) {
            if (this.i == Long.MIN_VALUE) {
                sb.append("; max-age=0");
            } else {
                sb.append("; expires=");
                sb.append(og.b(new Date(this.i)));
            }
        }
        if (!this.o) {
            sb.append("; domain=");
            sb.append(this.j);
        }
        sb.append("; path=");
        sb.append(this.f);
        if (this.f95910g) {
            sb.append("; secure");
        }
        if (this.m) {
            sb.append("; httponly");
        }
        return sb.toString();
    }

    public static void d() {
        k = new char[]{57916, 57241, 39292, 23357, 5312, 54876, 36899, 19962, 3905, 51558, 35529, 17493, 1549, 50164, 48567, 32521, 57909, 57229, 39288, 23342, 5259, 54878, 36918, 19904, 3919, 51493, 35583, 17505, 1559, 50156, 48574, 32525, 14533};
        l = 3886109546488258552L;
    }
}