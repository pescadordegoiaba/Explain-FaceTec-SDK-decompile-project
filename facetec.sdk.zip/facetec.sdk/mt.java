package com.facetec.sdk;

import java.util.Arrays;
import javax.net.ssl.SSLSocket;

/* JADX INFO: loaded from: classes4.dex */
public final class mt {
    public static final mt b;
    public static final mt d;
    private static final mq[] h;
    private static final mq[] i;
    final boolean a;
    final String[] c;
    final boolean e;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    final String[] f95911g;

    static {
        mq mqVar = mq.k;
        mq mqVar2 = mq.r;
        mq mqVar3 = mq.q;
        mq mqVar4 = mq.s;
        mq mqVar5 = mq.t;
        mq mqVar6 = mq.f;
        mq mqVar7 = mq.n;
        mq mqVar8 = mq.j;
        mq mqVar9 = mq.o;
        mq mqVar10 = mq.m;
        mq mqVar11 = mq.l;
        mq[] mqVarArr = {mqVar, mqVar2, mqVar3, mqVar4, mqVar5, mqVar6, mqVar7, mqVar8, mqVar9, mqVar10, mqVar11};
        h = mqVarArr;
        mq[] mqVarArr2 = {mqVar, mqVar2, mqVar3, mqVar4, mqVar5, mqVar6, mqVar7, mqVar8, mqVar9, mqVar10, mqVar11, mq.i, mq.f95909g, mq.c, mq.h, mq.a, mq.b, mq.e};
        i = mqVarArr2;
        a aVarC = new a(true).c(mqVarArr);
        nl nlVar = nl.TLS_1_3;
        nl nlVar2 = nl.TLS_1_2;
        aVarC.c(nlVar, nlVar2).a().e();
        a aVarC2 = new a(true).c(mqVarArr2);
        nl nlVar3 = nl.TLS_1_1;
        nl nlVar4 = nl.TLS_1_0;
        b = aVarC2.c(nlVar, nlVar2, nlVar3, nlVar4).a().e();
        new a(true).c(mqVarArr2).c(nlVar4).a().e();
        d = new a(false).e();
    }

    public mt(a aVar) {
        this.a = aVar.e;
        this.c = aVar.d;
        this.f95911g = aVar.b;
        this.e = aVar.a;
    }

    public final boolean a() {
        return this.e;
    }

    public final boolean e(SSLSocket sSLSocket) {
        if (!this.a) {
            return false;
        }
        String[] strArr = this.f95911g;
        if (strArr != null && !nu.d(nu.f95924g, strArr, sSLSocket.getEnabledProtocols())) {
            return false;
        }
        String[] strArr2 = this.c;
        return strArr2 == null || nu.d(mq.d, strArr2, sSLSocket.getEnabledCipherSuites());
    }

    public final boolean equals(Object obj) {
        if (!(obj instanceof mt)) {
            return false;
        }
        if (obj == this) {
            return true;
        }
        mt mtVar = (mt) obj;
        boolean z = this.a;
        if (z != mtVar.a) {
            return false;
        }
        return !z || (Arrays.equals(this.c, mtVar.c) && Arrays.equals(this.f95911g, mtVar.f95911g) && this.e == mtVar.e);
    }

    public final int hashCode() {
        if (this.a) {
            return ((((Arrays.hashCode(this.c) + 527) * 31) + Arrays.hashCode(this.f95911g)) * 31) + (!this.e ? 1 : 0);
        }
        return 17;
    }

    public final String toString() {
        String string;
        if (!this.a) {
            return "ConnectionSpec()";
        }
        String[] strArr = this.c;
        String string2 = "[all enabled]";
        if (strArr != null) {
            string = (strArr != null ? mq.a(strArr) : null).toString();
        } else {
            string = "[all enabled]";
        }
        String[] strArr2 = this.f95911g;
        if (strArr2 != null) {
            string2 = (strArr2 != null ? nl.a(strArr2) : null).toString();
        }
        StringBuilder sb = new StringBuilder("ConnectionSpec(cipherSuites=");
        sb.append(string);
        sb.append(", tlsVersions=");
        sb.append(string2);
        sb.append(", supportsTlsExtensions=");
        sb.append(this.e);
        sb.append(")");
        return sb.toString();
    }

    public static final class a {
        boolean a;
        String[] b;
        String[] d;
        boolean e;

        public a(boolean z) {
            this.e = z;
        }

        public final a a() {
            if (!this.e) {
                throw new IllegalStateException("no TLS extensions for cleartext connections");
            }
            this.a = true;
            return this;
        }

        public final a c(mq... mqVarArr) {
            if (!this.e) {
                throw new IllegalStateException("no cipher suites for cleartext connections");
            }
            String[] strArr = new String[mqVarArr.length];
            for (int i = 0; i < mqVarArr.length; i++) {
                strArr[i] = mqVarArr[i].p;
            }
            return c(strArr);
        }

        public final a e(String... strArr) {
            if (!this.e) {
                throw new IllegalStateException("no TLS versions for cleartext connections");
            }
            if (strArr.length == 0) {
                throw new IllegalArgumentException("At least one TLS version is required");
            }
            this.b = (String[]) strArr.clone();
            return this;
        }

        public a(mt mtVar) {
            this.e = mtVar.a;
            this.d = mtVar.c;
            this.b = mtVar.f95911g;
            this.a = mtVar.e;
        }

        public final mt e() {
            return new mt(this);
        }

        public final a c(String... strArr) {
            if (this.e) {
                if (strArr.length != 0) {
                    this.d = (String[]) strArr.clone();
                    return this;
                }
                throw new IllegalArgumentException("At least one cipher suite is required");
            }
            throw new IllegalStateException("no cipher suites for cleartext connections");
        }

        public final a c(nl... nlVarArr) {
            if (this.e) {
                String[] strArr = new String[nlVarArr.length];
                for (int i = 0; i < nlVarArr.length; i++) {
                    strArr[i] = nlVarArr[i].c;
                }
                return e(strArr);
            }
            throw new IllegalStateException("no TLS versions for cleartext connections");
        }
    }
}