package com.facetec.sdk;

import com.facetec.sdk.nk;
import java.io.InterruptedIOException;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Deque;
import java.util.Iterator;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.RejectedExecutionException;
import java.util.concurrent.SynchronousQueue;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;

/* JADX INFO: loaded from: classes4.dex */
public final class mu {
    private static /* synthetic */ boolean j = true;
    private Runnable d;
    private ExecutorService e;
    public int a = 64;
    private int b = 5;
    final Deque<nk.a> c = new ArrayDeque();
    private final Deque<nk.a> i = new ArrayDeque();
    private final Deque<nk> f = new ArrayDeque();

    private synchronized ExecutorService a() {
        try {
            if (this.e == null) {
                this.e = new ThreadPoolExecutor(0, Integer.MAX_VALUE, 60L, TimeUnit.SECONDS, new SynchronousQueue(), nu.d("OkHttp Dispatcher", false));
            }
        } catch (Throwable th) {
            throw th;
        }
        return this.e;
    }

    private <T> void b(Deque<T> deque, T t) {
        Runnable runnable;
        synchronized (this) {
            if (!deque.remove(t)) {
                throw new AssertionError("Call wasn't in-flight!");
            }
            runnable = this.d;
        }
        if (e() || runnable == null) {
            return;
        }
        runnable.run();
    }

    private synchronized int c() {
        return this.i.size() + this.f.size();
    }

    public final boolean e() {
        int i;
        boolean z;
        if (!j && Thread.holdsLock(this)) {
            throw new AssertionError();
        }
        ArrayList arrayList = new ArrayList();
        synchronized (this) {
            try {
                Iterator<nk.a> it = this.c.iterator();
                while (true) {
                    i = 0;
                    if (!it.hasNext()) {
                        break;
                    }
                    nk.a next = it.next();
                    if (this.i.size() >= this.a) {
                        break;
                    }
                    for (nk.a aVar : this.i) {
                        if (!nk.this.h && aVar.d().equals(next.d())) {
                            i++;
                        }
                    }
                    if (i < this.b) {
                        it.remove();
                        arrayList.add(next);
                        this.i.add(next);
                    }
                }
                z = c() > 0;
            } catch (Throwable th) {
                throw th;
            }
        }
        int size = arrayList.size();
        while (i < size) {
            nk.a aVar2 = (nk.a) arrayList.get(i);
            ExecutorService executorServiceA = a();
            if (!nk.a.c && Thread.holdsLock(nk.this.c.l())) {
                throw new AssertionError();
            }
            try {
                try {
                    executorServiceA.execute(aVar2);
                } catch (RejectedExecutionException e) {
                    InterruptedIOException interruptedIOException = new InterruptedIOException("executor rejected");
                    interruptedIOException.initCause(e);
                    na unused = nk.this.d;
                    aVar2.e.c(interruptedIOException);
                    nk.this.c.l().a(aVar2);
                }
                i++;
            } catch (Throwable th2) {
                nk.this.c.l().a(aVar2);
                throw th2;
            }
        }
        return z;
    }

    public final void a(nk.a aVar) {
        b(this.i, aVar);
    }
}