package com.facetec.sdk;

import android.media.AudioTrack;
import android.os.Process;
import android.telephony.cdma.CdmaCellLocation;
import android.text.AndroidCharacter;
import android.text.TextUtils;
import android.util.TypedValue;
import android.view.View;
import android.view.ViewConfiguration;
import com.facetec.sdk.oe;
import com.incode.welcome_sdk.modules.SelfieScan;
import java.lang.ref.Reference;
import java.lang.reflect.Method;
import java.util.ArrayDeque;
import java.util.Deque;
import java.util.List;
import java.util.concurrent.Executor;
import java.util.concurrent.SynchronousQueue;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;
import org.jmrtd.PassportService;

/* JADX INFO: loaded from: classes4.dex */
public final class mv {
    static final Executor e = new ThreadPoolExecutor(0, Integer.MAX_VALUE, 60, TimeUnit.SECONDS, new SynchronousQueue(), nu.d("OkHttp ConnectionPool", true));
    static final /* synthetic */ boolean f = true;
    final int a;
    final Runnable b;
    final oc c;
    final Deque<nx> d;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    private final long f95912g;
    boolean h;

    public mv() {
        this(TimeUnit.MINUTES);
    }

    public final long a(long j) {
        int size;
        synchronized (this) {
            try {
                nx nxVar = null;
                long j2 = Long.MIN_VALUE;
                int i = 0;
                int i2 = 0;
                for (nx nxVar2 : this.d) {
                    List<Reference<oe>> list = nxVar2.k;
                    int i3 = 0;
                    while (true) {
                        if (i3 >= list.size()) {
                            size = list.size();
                            break;
                        }
                        Reference<oe> reference = list.get(i3);
                        if (reference.get() == null) {
                            StringBuilder sb = new StringBuilder("A connection to ");
                            sb.append(nxVar2.b().d().c());
                            sb.append(" was leaked. Did you forget to close a response body?");
                            pm.i().e(sb.toString(), ((oe.b) reference).e);
                            list.remove(i3);
                            nxVar2.f = true;
                            if (list.isEmpty()) {
                                nxVar2.n = j - this.f95912g;
                                size = 0;
                                break;
                            }
                        } else {
                            i3++;
                        }
                    }
                    if (size > 0) {
                        i2++;
                    } else {
                        i++;
                        long j3 = j - nxVar2.n;
                        if (j3 > j2) {
                            nxVar = nxVar2;
                            j2 = j3;
                        }
                    }
                }
                long j4 = this.f95912g;
                if (j2 < j4 && i <= this.a) {
                    if (i > 0) {
                        return j4 - j2;
                    }
                    if (i2 > 0) {
                        return j4;
                    }
                    this.h = false;
                    return -1L;
                }
                this.d.remove(nxVar);
                nu.d(nxVar.d());
                return 0L;
            } catch (Throwable th) {
                throw th;
            }
        }
    }

    private mv(TimeUnit timeUnit) {
        this.b = new Runnable() { // from class: com.facetec.sdk.mv.4
            private static final byte[] $$a = null;
            private static final int $$b = 0;
            private static char b;
            private static char c;
            private static char d;
            private static char e;

            /* JADX WARN: Removed duplicated region for block: B:10:0x0027  */
            /* JADX WARN: Removed duplicated region for block: B:8:0x0021  */
            /* JADX WARN: Unsupported multi-entry loop pattern (BACK_EDGE: B:10:0x0027 -> B:11:0x002d). Please report as a decompilation issue!!! */
            /*
                Code decompiled incorrectly, please refer to instructions dump.
                To view partially-correct code enable 'Show inconsistent code' option in preferences
            */
            private static java.lang.String $$c(int r6, byte r7, short r8) {
                /*
                    byte[] r0 = com.facetec.sdk.mv.AnonymousClass4.$$a
                    int r8 = r8 * 3
                    int r8 = 112 - r8
                    int r7 = r7 * 2
                    int r7 = 2 - r7
                    int r6 = r6 * 2
                    int r1 = r6 + 1
                    byte[] r1 = new byte[r1]
                    r2 = 0
                    if (r0 != 0) goto L17
                    r3 = r0
                    r4 = r2
                    r0 = r6
                    goto L2d
                L17:
                    r3 = r2
                L18:
                    int r7 = r7 + 1
                    byte r4 = (byte) r8
                    r1[r3] = r4
                    int r4 = r3 + 1
                    if (r3 != r6) goto L27
                    java.lang.String r6 = new java.lang.String
                    r6.<init>(r1, r2)
                    return r6
                L27:
                    r3 = r0[r7]
                    r5 = r0
                    r0 = r8
                    r8 = r3
                    r3 = r5
                L2d:
                    int r8 = -r8
                    int r8 = r8 + r0
                    r0 = r3
                    r3 = r4
                    goto L18
                */
                throw new UnsupportedOperationException("Method not decompiled: com.facetec.sdk.mv.AnonymousClass4.$$c(int, byte, short):java.lang.String");
            }

            static {
                init$0();
                b = (char) 26356;
                e = (char) 52353;
                d = (char) 64910;
                c = (char) 3725;
            }

            private static void f(String str, int i, Object[] objArr) throws Throwable {
                char[] charArray = str != null ? str.toCharArray() : str;
                hq hqVar = new hq();
                char[] cArr = new char[charArray.length];
                hqVar.d = 0;
                int i2 = 2;
                char[] cArr2 = new char[2];
                while (true) {
                    int i3 = hqVar.d;
                    if (i3 >= charArray.length) {
                        objArr[0] = new String(cArr, 0, i);
                        return;
                    }
                    cArr2[0] = charArray[i3];
                    char c2 = 1;
                    cArr2[1] = charArray[i3 + 1];
                    int i4 = 58224;
                    int i5 = 0;
                    while (i5 < 16) {
                        char c3 = cArr2[c2];
                        char c4 = cArr2[0];
                        char c5 = c2;
                        int i6 = i2;
                        char[] cArr3 = cArr2;
                        int i7 = (c4 + i4) ^ ((c4 << 4) + ((char) (((long) d) ^ (-5528393735828501205L))));
                        int i8 = c4 >>> 5;
                        try {
                            Object[] objArr2 = new Object[4];
                            objArr2[3] = Integer.valueOf(c);
                            objArr2[i6] = Integer.valueOf(i8);
                            objArr2[c5] = Integer.valueOf(i7);
                            objArr2[0] = Integer.valueOf(c3);
                            Object objD = an.d(681770103);
                            Class cls = Integer.TYPE;
                            if (objD == null) {
                                objD = an.d(View.MeasureSpec.getSize(0) + 357, (char) ('0' - AndroidCharacter.getMirror('0')), 24 - (ViewConfiguration.getScrollDefaultDelay() >> 16), 1589849900, false, "s", new Class[]{cls, cls, cls, cls});
                            }
                            char cCharValue = ((Character) ((Method) objD).invoke(null, objArr2)).charValue();
                            cArr3[c5] = cCharValue;
                            char c6 = cArr3[0];
                            int i9 = (cCharValue + i4) ^ ((cCharValue << 4) + ((char) (((long) b) ^ (-5528393735828501205L))));
                            int i10 = cCharValue >>> 5;
                            Object[] objArr3 = new Object[4];
                            objArr3[3] = Integer.valueOf(e);
                            objArr3[i6] = Integer.valueOf(i10);
                            objArr3[c5] = Integer.valueOf(i9);
                            objArr3[0] = Integer.valueOf(c6);
                            Object objD2 = an.d(681770103);
                            if (objD2 == null) {
                                objD2 = an.d(((Process.getThreadPriority(0) + 20) >> 6) + 357, (char) (TypedValue.complexToFraction(0, SelfieScan.RECOGNITION_FAIL_RESULT, SelfieScan.RECOGNITION_FAIL_RESULT) > SelfieScan.RECOGNITION_FAIL_RESULT ? 1 : (TypedValue.complexToFraction(0, SelfieScan.RECOGNITION_FAIL_RESULT, SelfieScan.RECOGNITION_FAIL_RESULT) == SelfieScan.RECOGNITION_FAIL_RESULT ? 0 : -1)), (CdmaCellLocation.convertQuartSecToDecDegrees(0) > 0.0d ? 1 : (CdmaCellLocation.convertQuartSecToDecDegrees(0) == 0.0d ? 0 : -1)) + 24, 1589849900, false, "s", new Class[]{cls, cls, cls, cls});
                            }
                            cArr3[0] = ((Character) ((Method) objD2).invoke(null, objArr3)).charValue();
                            i4 -= 40503;
                            i5++;
                            c2 = c5;
                            i2 = i6;
                            cArr2 = cArr3;
                        } catch (Throwable th) {
                            Throwable cause = th.getCause();
                            if (cause == null) {
                                throw th;
                            }
                            throw cause;
                        }
                    }
                    int i11 = i2;
                    char[] cArr4 = cArr2;
                    char c7 = c2;
                    int i12 = hqVar.d;
                    cArr[i12] = cArr4[0];
                    cArr[i12 + 1] = cArr4[c7];
                    i2 = i11;
                    Object[] objArr4 = new Object[i2];
                    objArr4[c7] = hqVar;
                    objArr4[0] = hqVar;
                    Object objD3 = an.d(227457195);
                    if (objD3 == null) {
                        byte b2 = (byte) 0;
                        byte b3 = b2;
                        objD3 = an.d(1826 - TextUtils.lastIndexOf("", '0', 0), (char) ((ViewConfiguration.getGlobalActionKeyTimeout() > 0L ? 1 : (ViewConfiguration.getGlobalActionKeyTimeout() == 0L ? 0 : -1)) - 1), 25 - (AudioTrack.getMaxVolume() > SelfieScan.RECOGNITION_FAIL_RESULT ? 1 : (AudioTrack.getMaxVolume() == SelfieScan.RECOGNITION_FAIL_RESULT ? 0 : -1)), 2079288304, false, $$c(b2, b3, b3), new Class[]{Object.class, Object.class});
                    }
                    ((Method) objD3).invoke(null, objArr4);
                    cArr2 = cArr4;
                }
            }

            public static void init$0() {
                $$a = new byte[]{PassportService.SFI_DG15, 58, -59};
                $$b = 70;
            }

            @Override // java.lang.Runnable
            public final void run() throws Throwable {
                while (true) {
                    mv mvVar = mv.this;
                    try {
                        Object[] objArr = new Object[1];
                        f("觪ᢔ錉典\uf43e\u2d7d麿䚁ᣢ\ue93f\udbb6찕欃\udad7貛\udd1b", TextUtils.lastIndexOf("", '0', 0, 0) + 17, objArr);
                        Class<?> cls = Class.forName((String) objArr[0]);
                        Object[] objArr2 = new Object[1];
                        f("⤕\uf784５巗௸튺暿䒇", (ViewConfiguration.getWindowTouchSlop() >> 8) + 8, objArr2);
                        long jA = mvVar.a(((Long) cls.getMethod((String) objArr2[0], null).invoke(null, null)).longValue());
                        if (jA == -1) {
                            return;
                        }
                        if (jA > 0) {
                            long j = jA / 1000000;
                            long j2 = jA - (1000000 * j);
                            synchronized (mv.this) {
                                try {
                                    mv.this.wait(j, (int) j2);
                                } catch (InterruptedException unused) {
                                }
                            }
                        }
                    } catch (Throwable th) {
                        Throwable cause = th.getCause();
                        if (cause == null) {
                            throw th;
                        }
                        throw cause;
                    }
                }
            }
        };
        this.d = new ArrayDeque();
        this.c = new oc();
        this.a = 5;
        this.f95912g = timeUnit.toNanos(5L);
    }
}