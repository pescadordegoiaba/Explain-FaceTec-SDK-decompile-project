package com.facetec.sdk;

import java.nio.charset.Charset;
import java.util.ArrayList;
import java.util.List;

/* JADX INFO: loaded from: classes4.dex */
public final class mw extends ni {
    private static final nb a = nb.c("application/x-www-form-urlencoded");
    private final List<String> d;
    private final List<String> e;

    public static final class c {
        private final Charset c;
        private final List<String> d;
        private final List<String> e;

        public c() {
            this((byte) 0);
        }

        public final mw b() {
            return new mw(this.e, this.d);
        }

        public final c e(String str, String str2) {
            if (str == null) {
                throw new NullPointerException("name == null");
            }
            if (str2 == null) {
                throw new NullPointerException("value == null");
            }
            this.e.add(nc.d(str, " \"':;<=>@[]^`{}|/\\?#&!$(),~", this.c));
            this.d.add(nc.d(str2, " \"':;<=>@[]^`{}|/\\?#&!$(),~", this.c));
            return this;
        }

        private c(byte b) {
            this.e = new ArrayList();
            this.d = new ArrayList();
            this.c = null;
        }
    }

    public mw(List<String> list, List<String> list2) {
        this.e = nu.e(list);
        this.d = nu.e(list2);
    }

    private long c(pu puVar, boolean z) {
        px pxVar = z ? new px() : puVar.d();
        int size = this.e.size();
        for (int i = 0; i < size; i++) {
            if (i > 0) {
                pxVar.g(38);
            }
            pxVar.a(this.e.get(i));
            pxVar.g(61);
            pxVar.a(this.d.get(i));
        }
        if (!z) {
            return 0L;
        }
        long jE = pxVar.e();
        pxVar.q();
        return jE;
    }

    @Override // com.facetec.sdk.ni
    public final nb b() {
        return a;
    }

    @Override // com.facetec.sdk.ni
    public final long d() {
        return c(null, true);
    }

    @Override // com.facetec.sdk.ni
    public final void b(pu puVar) {
        c(puVar, false);
    }
}