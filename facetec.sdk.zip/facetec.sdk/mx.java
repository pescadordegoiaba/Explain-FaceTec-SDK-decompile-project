package com.facetec.sdk;

import java.io.IOException;
import java.security.cert.Certificate;
import java.util.Collections;
import java.util.List;
import javax.net.ssl.SSLPeerUnverifiedException;
import javax.net.ssl.SSLSession;

/* JADX INFO: loaded from: classes4.dex */
public final class mx {
    private final List<Certificate> a;
    private final List<Certificate> b;
    public final mq c;
    private final nl e;

    private mx(nl nlVar, mq mqVar, List<Certificate> list, List<Certificate> list2) {
        this.e = nlVar;
        this.c = mqVar;
        this.b = list;
        this.a = list2;
    }

    public static mx b(SSLSession sSLSession) throws IOException {
        Certificate[] peerCertificates;
        String cipherSuite = sSLSession.getCipherSuite();
        if (cipherSuite == null) {
            throw new IllegalStateException("cipherSuite == null");
        }
        if ("SSL_NULL_WITH_NULL_NULL".equals(cipherSuite)) {
            throw new IOException("cipherSuite == SSL_NULL_WITH_NULL_NULL");
        }
        mq mqVarA = mq.a(cipherSuite);
        String protocol = sSLSession.getProtocol();
        if (protocol == null) {
            throw new IllegalStateException("tlsVersion == null");
        }
        if ("NONE".equals(protocol)) {
            throw new IOException("tlsVersion == NONE");
        }
        nl nlVarB = nl.b(protocol);
        try {
            peerCertificates = sSLSession.getPeerCertificates();
        } catch (SSLPeerUnverifiedException unused) {
            peerCertificates = null;
        }
        List listB = peerCertificates != null ? nu.b(peerCertificates) : Collections.EMPTY_LIST;
        Certificate[] localCertificates = sSLSession.getLocalCertificates();
        return new mx(nlVarB, mqVarA, listB, localCertificates != null ? nu.b(localCertificates) : Collections.EMPTY_LIST);
    }

    public final List<Certificate> d() {
        return this.b;
    }

    public final boolean equals(Object obj) {
        if (!(obj instanceof mx)) {
            return false;
        }
        mx mxVar = (mx) obj;
        return this.e.equals(mxVar.e) && this.c.equals(mxVar.c) && this.b.equals(mxVar.b) && this.a.equals(mxVar.a);
    }

    public final int hashCode() {
        return ((((((this.e.hashCode() + 527) * 31) + this.c.hashCode()) * 31) + this.b.hashCode()) * 31) + this.a.hashCode();
    }
}