package com.facetec.sdk;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

/* JADX INFO: loaded from: classes4.dex */
public final class mz {
    private final String[] e;

    public mz(a aVar) {
        List<String> list = aVar.d;
        this.e = (String[]) list.toArray(new String[list.size()]);
    }

    public static void e(String str) {
        if (str == null) {
            throw new NullPointerException("name == null");
        }
        if (str.isEmpty()) {
            throw new IllegalArgumentException("name is empty");
        }
        int length = str.length();
        for (int i = 0; i < length; i++) {
            char cCharAt = str.charAt(i);
            if (cCharAt <= ' ' || cCharAt >= 127) {
                throw new IllegalArgumentException(nu.b("Unexpected char %#04x at %d in header name: %s", Integer.valueOf(cCharAt), Integer.valueOf(i), str));
            }
        }
    }

    public final String a(String str) {
        String[] strArr = this.e;
        for (int length = strArr.length - 2; length >= 0; length -= 2) {
            if (str.equalsIgnoreCase(strArr[length])) {
                return strArr[length + 1];
            }
        }
        return null;
    }

    public final String b(int i) {
        return this.e[(i << 1) + 1];
    }

    public final int d() {
        return this.e.length / 2;
    }

    public final boolean equals(Object obj) {
        return (obj instanceof mz) && Arrays.equals(((mz) obj).e, this.e);
    }

    public final int hashCode() {
        return Arrays.hashCode(this.e);
    }

    public final String toString() {
        StringBuilder sb = new StringBuilder();
        int iD = d();
        for (int i = 0; i < iD; i++) {
            sb.append(a(i));
            sb.append(": ");
            sb.append(b(i));
            sb.append("\n");
        }
        return sb.toString();
    }

    public final a b() {
        a aVar = new a();
        Collections.addAll(aVar.d, this.e);
        return aVar;
    }

    public static final class a {
        final List<String> d = new ArrayList(20);

        public final a a(String str, String str2) {
            mz.e(str);
            mz.e(str2, str);
            return b(str, str2);
        }

        public final a b(String str, String str2) {
            this.d.add(str);
            this.d.add(str2.trim());
            return this;
        }

        public final mz c() {
            return new mz(this);
        }

        public final a d(String str) {
            int i = 0;
            while (i < this.d.size()) {
                if (str.equalsIgnoreCase(this.d.get(i))) {
                    this.d.remove(i);
                    this.d.remove(i);
                    i -= 2;
                }
                i += 2;
            }
            return this;
        }

        public final a e(String str, String str2) {
            mz.e(str);
            return b(str, str2);
        }

        public final a d(String str, String str2) {
            mz.e(str);
            mz.e(str2, str);
            d(str);
            b(str, str2);
            return this;
        }
    }

    public final String a(int i) {
        return this.e[i << 1];
    }

    public static void e(String str, String str2) {
        if (str != null) {
            int length = str.length();
            for (int i = 0; i < length; i++) {
                char cCharAt = str.charAt(i);
                if ((cCharAt <= 31 && cCharAt != '\t') || cCharAt >= 127) {
                    throw new IllegalArgumentException(nu.b("Unexpected char %#04x at %d in %s value: %s", Integer.valueOf(cCharAt), Integer.valueOf(i), str2, str));
                }
            }
            return;
        }
        StringBuilder sb = new StringBuilder("value for name ");
        sb.append(str2);
        sb.append(" == null");
        throw new NullPointerException(sb.toString());
    }
}