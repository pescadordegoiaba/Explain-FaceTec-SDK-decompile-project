package com.facetec.sdk;

import android.graphics.Color;
import android.media.AudioTrack;
import android.os.Process;
import android.view.ViewConfiguration;
import com.incode.welcome_sdk.modules.SelfieScan;
import java.lang.reflect.Method;

/* JADX INFO: loaded from: classes4.dex */
final class n {
    private static final byte[] $$a = null;
    private static final int $$b = 0;
    private static int $10;
    private static int $11;
    private static int a;
    private static int c;
    private static int d;

    /* JADX WARN: Removed duplicated region for block: B:10:0x0026  */
    /* JADX WARN: Removed duplicated region for block: B:8:0x0020  */
    /* JADX WARN: Unsupported multi-entry loop pattern (BACK_EDGE: B:10:0x0026 -> B:11:0x0028). Please report as a decompilation issue!!! */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    private static java.lang.String $$c(int r5, byte r6, int r7) {
        /*
            int r6 = r6 * 3
            int r6 = 110 - r6
            int r5 = r5 * 3
            int r0 = 1 - r5
            byte[] r1 = com.facetec.sdk.n.$$a
            int r7 = r7 * 4
            int r7 = 4 - r7
            byte[] r0 = new byte[r0]
            r2 = 0
            int r5 = 0 - r5
            if (r1 != 0) goto L18
            r3 = r5
            r4 = r2
            goto L28
        L18:
            r3 = r2
        L19:
            byte r4 = (byte) r6
            r0[r3] = r4
            int r4 = r3 + 1
            if (r3 != r5) goto L26
            java.lang.String r5 = new java.lang.String
            r5.<init>(r0, r2)
            return r5
        L26:
            r3 = r1[r7]
        L28:
            int r6 = r6 + r3
            int r7 = r7 + 1
            r3 = r4
            goto L19
        */
        throw new UnsupportedOperationException("Method not decompiled: com.facetec.sdk.n.$$c(int, byte, int):java.lang.String");
    }

    static {
        init$0();
        $10 = 0;
        $11 = 1;
        c = 0;
        d = 1;
        a = 1605274599;
    }

    /* JADX WARN: Removed duplicated region for block: B:11:0x0078  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public static void a(java.lang.Throwable r12) {
        /*
            r0 = 0
            java.lang.String r1 = com.facetec.sdk.bk.d(r0)
            if (r1 == 0) goto L99
            int r2 = com.facetec.sdk.n.d
            int r2 = r2 + 7
            int r3 = r2 % 128
            com.facetec.sdk.n.c = r3
            int r2 = r2 % 2
            r3 = 1
            r4 = 0
            r5 = 0
            if (r2 == 0) goto L48
            long r6 = android.os.Process.getElapsedCpuTime()
            r8 = 1
            int r2 = (r6 > r8 ? 1 : (r6 == r8 ? 0 : -1))
            int r6 = r2 + 4
            float r2 = android.view.ViewConfiguration.getScrollFriction()
            int r2 = (r2 > r4 ? 1 : (r2 == r4 ? 0 : -1))
            int r8 = r2 + 20072
            int r2 = android.view.ViewConfiguration.getKeyRepeatDelay()
            int r2 = r2 / 66
            r4 = 3
            int r10 = r4 / r2
            java.lang.Object[] r11 = new java.lang.Object[r3]
            r7 = 1
            java.lang.String r9 = "\uffd1\u0010\u0012\u0006\uffd1\u0006\b\u0017\b\u0006\u0004\t"
            e(r6, r7, r8, r9, r10, r11)
            r2 = r11[r5]
            java.lang.String r2 = (java.lang.String) r2
            java.lang.String r2 = r2.intern()
            boolean r1 = r1.startsWith(r2)
            if (r1 == 0) goto L99
            goto L78
        L48:
            long r6 = android.os.Process.getElapsedCpuTime()
            r8 = 0
            int r2 = (r6 > r8 ? 1 : (r6 == r8 ? 0 : -1))
            int r6 = 13 - r2
            float r2 = android.view.ViewConfiguration.getScrollFriction()
            int r2 = (r2 > r4 ? 1 : (r2 == r4 ? 0 : -1))
            int r8 = r2 + 274
            int r2 = android.view.ViewConfiguration.getKeyRepeatDelay()
            int r2 = r2 >> 16
            int r10 = 4 - r2
            java.lang.Object[] r11 = new java.lang.Object[r3]
            r7 = 1
            java.lang.String r9 = "\uffd1\u0010\u0012\u0006\uffd1\u0006\b\u0017\b\u0006\u0004\t"
            e(r6, r7, r8, r9, r10, r11)
            r2 = r11[r5]
            java.lang.String r2 = (java.lang.String) r2
            java.lang.String r2 = r2.intern()
            boolean r1 = r1.startsWith(r2)
            if (r1 == 0) goto L99
        L78:
            java.lang.reflect.Method r1 = c()
            if (r1 == 0) goto L99
            int r2 = com.facetec.sdk.n.c
            int r2 = r2 + 25
            int r3 = r2 % 128
            com.facetec.sdk.n.d = r3
            int r2 = r2 % 2
            if (r2 != 0) goto L92
            java.lang.Object[] r2 = new java.lang.Object[r5]     // Catch: java.lang.Exception -> L99
            r2[r5] = r12     // Catch: java.lang.Exception -> L99
            r1.invoke(r0, r0)     // Catch: java.lang.Exception -> L99
            goto L99
        L92:
            java.lang.Object[] r2 = new java.lang.Object[]{r12}     // Catch: java.lang.Exception -> L99
            r1.invoke(r0, r2)     // Catch: java.lang.Exception -> L99
        L99:
            android.util.Log.getStackTraceString(r12)
            int r12 = com.facetec.sdk.n.c
            int r12 = r12 + 111
            int r1 = r12 % 128
            com.facetec.sdk.n.d = r1
            int r12 = r12 % 2
            if (r12 == 0) goto La9
            return
        La9:
            throw r0
        */
        throw new UnsupportedOperationException("Method not decompiled: com.facetec.sdk.n.a(java.lang.Throwable):void");
    }

    private static Method c() {
        c = (d + 101) % 128;
        try {
            Object[] objArr = new Object[1];
            e(35 - (ViewConfiguration.getScrollDefaultDelay() >> 16), false, 283 - (AudioTrack.getMinVolume() > SelfieScan.RECOGNITION_FAIL_RESULT ? 1 : (AudioTrack.getMinVolume() == SelfieScan.RECOGNITION_FAIL_RESULT ? 0 : -1)), "\r\n\u0004\uffff\uffc9\uffde\r￼\u000e\u0003\u0007\u0014\u000f\u0004\ufffe\u000e\ufffe\n\b\uffc9\ufffe\r￼\u000e\u0003\u0007\u0014\u000f\u0004\ufffe\u000e\uffc9￼\t\uffff", 16 - (Process.myPid() >> 22), objArr);
            Class<?> cls = Class.forName(((String) objArr[0]).intern());
            Object[] objArr2 = new Object[1];
            e(12 - (ViewConfiguration.getScrollBarFadeDuration() >> 16), false, 287 - Color.green(0), "￼\u0007\u000b\u0000\u0006\u0005\u0003\u0006\ufffeￜ\u000f\ufffa", 6 - (AudioTrack.getMinVolume() > SelfieScan.RECOGNITION_FAIL_RESULT ? 1 : (AudioTrack.getMinVolume() == SelfieScan.RECOGNITION_FAIL_RESULT ? 0 : -1)), objArr2);
            Method method = cls.getMethod(((String) objArr2[0]).intern(), Throwable.class);
            int i = c + 101;
            d = i % 128;
            if (i % 2 != 0) {
                return method;
            }
            throw null;
        } catch (ClassNotFoundException | NoSuchMethodException unused) {
            return null;
        }
    }

    /* JADX WARN: Removed duplicated region for block: B:40:0x017a  */
    /* JADX WARN: Removed duplicated region for block: B:41:0x017b  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    private static void e(int r25, boolean r26, int r27, java.lang.String r28, int r29, java.lang.Object[] r30) throws java.lang.Throwable {
        /*
            Method dump skipped, instruction units count: 392
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: com.facetec.sdk.n.e(int, boolean, int, java.lang.String, int, java.lang.Object[]):void");
    }

    public static void init$0() {
        $$a = new byte[]{94, -53, 28, -60};
        $$b = 74;
    }
}