package com.facetec.sdk;

/* JADX INFO: loaded from: classes4.dex */
public abstract class na {
    public static final na a = new na() { // from class: com.facetec.sdk.na.4
    };

    public interface e {
        na d();
    }

    public static e c(na naVar) {
        return new e() { // from class: com.facetec.sdk.na.3
            @Override // com.facetec.sdk.na.e
            public final na d() {
                return na.this;
            }
        };
    }
}