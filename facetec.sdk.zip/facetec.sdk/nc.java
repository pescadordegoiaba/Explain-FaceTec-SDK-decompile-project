package com.facetec.sdk;

import ai.luciq.library.screenshot.analytics.ScreenShotAnalyticsMapper;
import com.plaid.internal.EnumC41897g;
import java.lang.reflect.Constructor;
import java.lang.reflect.Method;
import java.net.URI;
import java.net.URISyntaxException;
import java.nio.charset.Charset;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import net.sf.scuba.smartcards.ISO7816;
import org.jmrtd.PassportService;
import org.jmrtd.lds.CVCAFile;

/* JADX INFO: loaded from: classes4.dex */
public final class nc {
    private static final char[] b = {'0', '1', '2', '3', '4', '5', '6', '7', '8', '9', 'A', 'B', 'C', 'D', 'E', 'F'};
    final String a;
    public final List<String> c;
    final int d;
    final String e;
    private final String f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    private final String f95913g;
    private final String h;
    private final String i;
    private final List<String> j;

    public static final class b {
        private static final byte[] $$a = null;
        private static final int $$b = 0;
        private static int i;
        private static int j;
        String d;
        String e;
        final List<String> f;

        /* JADX INFO: renamed from: g, reason: collision with root package name */
        List<String> f95914g;
        String h;
        String c = "";
        String b = "";
        int a = -1;

        static {
            init$0();
            j = 0;
            i = 1;
        }

        public b() {
            ArrayList arrayList = new ArrayList();
            this.f = arrayList;
            arrayList.add("");
        }

        public static void b(long j2, long j3) throws Throwable {
            int i2 = i;
            int i3 = i2 & EnumC41897g.SDK_ASSET_ILLUSTRATION_DEPOSIT_SWITCH_VALUE;
            j = ((i3 - (~((i2 ^ EnumC41897g.SDK_ASSET_ILLUSTRATION_DEPOSIT_SWITCH_VALUE) | i3))) - 1) % 128;
            byte[] bArr = $$a;
            byte b = (byte) (bArr[9] + 1);
            byte b2 = b;
            Object[] objArr = new Object[1];
            k(b, b2, b2, objArr);
            if (Class.forName((String) objArr[0]).getField(ScreenShotAnalyticsMapper.capturedErrorCodes).getBoolean(null)) {
                int i4 = i;
                int i5 = i4 & 81;
                int i6 = (i4 ^ 81) | i5;
                j = ((i5 & i6) + (i6 | i5)) % 128;
                return;
            }
            byte b3 = (byte) (bArr[9] + 1);
            byte b4 = b3;
            Object[] objArr2 = new Object[1];
            k(b3, b4, b4, objArr2);
            Class.forName((String) objArr2[0]).getField(ScreenShotAnalyticsMapper.capturedErrorCodes).setBoolean(null, true);
            int i7 = j;
            i = ((i7 & 67) + (i7 | 67)) % 128;
            i = (i7 + 79) % 128;
            try {
                byte b5 = bArr[9];
                byte b6 = (byte) (-b5);
                Object[] objArr3 = new Object[1];
                k(b6, (byte) (b6 - 1), (byte) (-b5), objArr3);
                Constructor<?> declaredConstructor = Class.forName((String) objArr3[0]).getDeclaredConstructor(null);
                declaredConstructor.setAccessible(true);
                Object[] objArr4 = {declaredConstructor.newInstance(null)};
                Method method = dj.class.getMethod("a", Runnable.class);
                method.setAccessible(true);
                method.invoke(null, objArr4);
                int i8 = i;
                int i9 = ((i8 | 97) << 1) - (i8 ^ 97);
                j = i9 % 128;
                if (i9 % 2 != 0) {
                    throw null;
                }
            } catch (Throwable th) {
                Throwable cause = th.getCause();
                if (cause == null) {
                    throw th;
                }
                throw cause;
            }
        }

        private static boolean d(String str) {
            return str.equals(".") || str.equalsIgnoreCase("%2e");
        }

        private static boolean e(String str) {
            return str.equals("..") || str.equalsIgnoreCase("%2e.") || str.equalsIgnoreCase(".%2e") || str.equalsIgnoreCase("%2e%2e");
        }

        private static int h(String str, int i2, int i3) {
            int i4;
            try {
                i4 = Integer.parseInt(nc.d(str, i2, i3, "", false, false, false, true, null));
            } catch (NumberFormatException unused) {
            }
            if (i4 <= 0 || i4 > 65535) {
                return -1;
            }
            return i4;
        }

        public static void init$0() {
            $$a = new byte[]{61, -49, -70, 93, 9, -5, -66, 53, -8, -1, -1, PassportService.SFI_DG12, -18, -5, -56, CVCAFile.CAR_TAG, -18, 4, ISO7816.INS_GET_RESPONSE, ISO7816.INS_INCREASE, -4, 9, -5, -66, 53, -8, -1, -1, PassportService.SFI_DG12, -18, -5, -56, CVCAFile.CAR_TAG, -18, 4, ISO7816.INS_GET_RESPONSE, ISO7816.INS_INCREASE, -4, -65, PassportService.SFI_DG12};
            $$b = 97;
        }

        /* JADX WARN: Removed duplicated region for block: B:10:0x0027  */
        /* JADX WARN: Removed duplicated region for block: B:8:0x001f  */
        /* JADX WARN: Unsupported multi-entry loop pattern (BACK_EDGE: B:10:0x0027 -> B:11:0x002c). Please report as a decompilation issue!!! */
        /*
            Code decompiled incorrectly, please refer to instructions dump.
            To view partially-correct code enable 'Show inconsistent code' option in preferences
        */
        private static void k(short r6, byte r7, int r8, java.lang.Object[] r9) {
            /*
                int r7 = r7 * 2
                int r7 = 99 - r7
                int r8 = r8 * 2
                int r8 = r8 + 18
                byte[] r0 = com.facetec.sdk.nc.b.$$a
                int r6 = r6 * 17
                int r6 = r6 + 4
                byte[] r1 = new byte[r8]
                r2 = 0
                if (r0 != 0) goto L17
                r4 = r7
                r3 = r2
                r7 = r6
                goto L2c
            L17:
                r3 = r2
            L18:
                byte r4 = (byte) r7
                r1[r3] = r4
                int r3 = r3 + 1
                if (r3 != r8) goto L27
                java.lang.String r6 = new java.lang.String
                r6.<init>(r1, r2)
                r9[r2] = r6
                return
            L27:
                r4 = r0[r6]
                r5 = r7
                r7 = r6
                r6 = r5
            L2c:
                int r6 = r6 + r4
                int r6 = r6 + 3
                int r7 = r7 + 1
                r5 = r7
                r7 = r6
                r6 = r5
                goto L18
            */
            throw new UnsupportedOperationException("Method not decompiled: com.facetec.sdk.nc.b.k(short, byte, int, java.lang.Object[]):void");
        }

        public final nc a() {
            if (this.e == null) {
                throw new IllegalStateException("scheme == null");
            }
            if (this.d != null) {
                return new nc(this);
            }
            throw new IllegalStateException("host == null");
        }

        public final int c() {
            int i2 = this.a;
            return i2 != -1 ? i2 : nc.e(this.e);
        }

        public final String toString() {
            StringBuilder sb = new StringBuilder();
            String str = this.e;
            if (str != null) {
                sb.append(str);
                sb.append("://");
            } else {
                sb.append("//");
            }
            if (!this.c.isEmpty() || !this.b.isEmpty()) {
                sb.append(this.c);
                if (!this.b.isEmpty()) {
                    sb.append(':');
                    sb.append(this.b);
                }
                sb.append('@');
            }
            String str2 = this.d;
            if (str2 != null) {
                if (str2.indexOf(58) != -1) {
                    sb.append('[');
                    sb.append(this.d);
                    sb.append(']');
                } else {
                    sb.append(this.d);
                }
            }
            if (this.a != -1 || this.e != null) {
                int iC = c();
                String str3 = this.e;
                if (str3 == null || iC != nc.e(str3)) {
                    sb.append(':');
                    sb.append(iC);
                }
            }
            nc.b(sb, this.f);
            if (this.f95914g != null) {
                sb.append('?');
                nc.e(sb, this.f95914g);
            }
            if (this.h != null) {
                sb.append('#');
                sb.append(this.h);
            }
            return sb.toString();
        }

        private void c(String str, int i2, int i3, boolean z) {
            String strD = nc.d(str, i2, i3, " \"<>^`{}|/\\?#", true, false, false, true, null);
            if (d(strD)) {
                return;
            }
            if (e(strD)) {
                b();
                return;
            }
            if (this.f.get(r11.size() - 1).isEmpty()) {
                this.f.set(r11.size() - 1, strD);
            } else {
                this.f.add(strD);
            }
            if (z) {
                this.f.add("");
            }
        }

        public static String d(String str, int i2, int i3) {
            return nu.b(nc.c(str, i2, i3, false));
        }

        private static int e(String str, int i2, int i3) {
            int i4 = 0;
            while (i2 < i3) {
                char cCharAt = str.charAt(i2);
                if (cCharAt != '\\' && cCharAt != '/') {
                    break;
                }
                i4++;
                i2++;
            }
            return i4;
        }

        public final b a(nc ncVar, String str) {
            int iE;
            String str2;
            int i2;
            String str3;
            String str4 = str;
            int iC = nu.c(str4, 0, str4.length());
            int iA = nu.a(str4, iC, str4.length());
            int iB = b(str4, iC, iA);
            if (iB != -1) {
                if (str4.regionMatches(true, iC, "https:", 0, 6)) {
                    this.e = "https";
                    iC += 6;
                    str4 = str;
                } else {
                    str4 = str;
                    if (str4.regionMatches(true, iC, "http:", 0, 5)) {
                        this.e = "http";
                        iC += 5;
                    } else {
                        StringBuilder sb = new StringBuilder("Expected URL scheme 'http' or 'https' but was '");
                        sb.append(str4.substring(0, iB));
                        sb.append("'");
                        throw new IllegalArgumentException(sb.toString());
                    }
                }
            } else if (ncVar != null) {
                this.e = ncVar.e;
            } else {
                throw new IllegalArgumentException("Expected URL scheme 'http' or 'https' but no colon was found");
            }
            int iE2 = e(str4, iC, iA);
            char c = '#';
            if (iE2 < 2 && ncVar != null && ncVar.e.equals(this.e)) {
                this.c = ncVar.a();
                this.b = ncVar.d();
                this.d = ncVar.a;
                this.a = ncVar.d;
                this.f.clear();
                this.f.addAll(ncVar.f());
                if (iC == iA || str4.charAt(iC) == '#') {
                    b(ncVar.i());
                }
                str2 = str4;
            } else {
                int i3 = iC + iE2;
                boolean z = false;
                boolean z2 = false;
                while (true) {
                    iE = nu.e(str4, i3, iA, "@/\\?#");
                    byte bCharAt = iE != iA ? str4.charAt(iE) : (byte) -1;
                    if (bCharAt == -1 || bCharAt == c || bCharAt == 47 || bCharAt == 92 || bCharAt == 63) {
                        break;
                    }
                    if (bCharAt == 64) {
                        if (!z) {
                            int iA2 = nu.a(str4, i3, iE, ':');
                            String strD = nc.d(str, i3, iA2, " \"':;<=>@[]^`{}|/\\?#", true, false, false, true, null);
                            if (z2) {
                                StringBuilder sb2 = new StringBuilder();
                                sb2.append(this.c);
                                sb2.append("%40");
                                sb2.append(strD);
                                strD = sb2.toString();
                            }
                            this.c = strD;
                            if (iA2 != iE) {
                                i2 = iE;
                                this.b = nc.d(str, iA2 + 1, i2, " \"':;<=>@[]^`{}|/\\?#", true, false, false, true, null);
                                z = true;
                            } else {
                                i2 = iE;
                            }
                            str3 = str;
                            z2 = true;
                        } else {
                            i2 = iE;
                            StringBuilder sb3 = new StringBuilder();
                            sb3.append(this.b);
                            sb3.append("%40");
                            str3 = str;
                            sb3.append(nc.d(str3, i3, i2, " \"':;<=>@[]^`{}|/\\?#", true, false, false, true, null));
                            this.b = sb3.toString();
                        }
                        i3 = i2 + 1;
                        str4 = str3;
                        c = '#';
                    }
                }
                str2 = str4;
                int i4 = i3;
                int iC2 = c(str2, i4, iE);
                int i5 = iC2 + 1;
                if (i5 < iE) {
                    this.d = d(str2, i4, iC2);
                    int iH = h(str2, i5, iE);
                    this.a = iH;
                    if (iH == -1) {
                        StringBuilder sb4 = new StringBuilder("Invalid URL port: \"");
                        sb4.append(str2.substring(i5, iE));
                        sb4.append('\"');
                        throw new IllegalArgumentException(sb4.toString());
                    }
                } else {
                    this.d = d(str2, i4, iC2);
                    this.a = nc.e(this.e);
                }
                if (this.d == null) {
                    StringBuilder sb5 = new StringBuilder("Invalid URL host: \"");
                    sb5.append(str2.substring(i4, iC2));
                    sb5.append('\"');
                    throw new IllegalArgumentException(sb5.toString());
                }
                iC = iE;
            }
            int iE3 = nu.e(str2, iC, iA, "?#");
            a(str2, iC, iE3);
            if (iE3 < iA && str2.charAt(iE3) == '?') {
                int iA3 = nu.a(str2, iE3, iA, '#');
                this.f95914g = nc.c(nc.d(str2, iE3 + 1, iA3, " \"'<>#", true, false, true, true, null));
                iE3 = iA3;
            }
            if (iE3 < iA && str2.charAt(iE3) == '#') {
                this.h = nc.d(str2, iE3 + 1, iA, "", true, false, false, false, null);
            }
            return this;
        }

        public final b b(String str) {
            this.f95914g = str != null ? nc.c(nc.e(str, " \"'<>#", true, false, true, true)) : null;
            return this;
        }

        private static int c(String str, int i2, int i3) {
            while (i2 < i3) {
                char cCharAt = str.charAt(i2);
                if (cCharAt == ':') {
                    return i2;
                }
                if (cCharAt == '[') {
                    do {
                        i2++;
                        if (i2 < i3) {
                        }
                    } while (str.charAt(i2) != ']');
                }
                i2++;
            }
            return i3;
        }

        private void b() {
            if (this.f.remove(r0.size() - 1).isEmpty() && !this.f.isEmpty()) {
                this.f.set(r0.size() - 1, "");
            } else {
                this.f.add("");
            }
        }

        private static int b(String str, int i2, int i3) {
            if (i3 - i2 < 2) {
                return -1;
            }
            char cCharAt = str.charAt(i2);
            if ((cCharAt >= 'a' && cCharAt <= 'z') || (cCharAt >= 'A' && cCharAt <= 'Z')) {
                while (true) {
                    i2++;
                    if (i2 >= i3) {
                        break;
                    }
                    char cCharAt2 = str.charAt(i2);
                    if (cCharAt2 < 'a' || cCharAt2 > 'z') {
                        if (cCharAt2 < 'A' || cCharAt2 > 'Z') {
                            if (cCharAt2 < '0' || cCharAt2 > '9') {
                                if (cCharAt2 != '+' && cCharAt2 != '-' && cCharAt2 != '.') {
                                    if (cCharAt2 == ':') {
                                        return i2;
                                    }
                                }
                            }
                        }
                    }
                }
            }
            return -1;
        }

        private void a(String str, int i2, int i3) {
            if (i2 == i3) {
                return;
            }
            char cCharAt = str.charAt(i2);
            if (cCharAt != '/' && cCharAt != '\\') {
                List<String> list = this.f;
                list.set(list.size() - 1, "");
            } else {
                this.f.clear();
                this.f.add("");
                i2++;
            }
            while (i2 < i3) {
                int iE = nu.e(str, i2, i3, "/\\");
                boolean z = iE < i3;
                c(str, i2, iE, z);
                if (z) {
                    iE++;
                }
                i2 = iE;
            }
        }
    }

    public nc(b bVar) {
        this.e = bVar.e;
        this.f95913g = d(bVar.c, false);
        this.f = d(bVar.b, false);
        this.a = bVar.d;
        this.d = bVar.c();
        this.j = a(bVar.f, false);
        List<String> list = bVar.f95914g;
        this.c = list != null ? a(list, true) : null;
        String str = bVar.h;
        this.h = str != null ? d(str, false) : null;
        this.i = bVar.toString();
    }

    public static List<String> c(String str) {
        ArrayList arrayList = new ArrayList();
        int i = 0;
        while (i <= str.length()) {
            int iIndexOf = str.indexOf(38, i);
            if (iIndexOf == -1) {
                iIndexOf = str.length();
            }
            int iIndexOf2 = str.indexOf(61, i);
            if (iIndexOf2 == -1 || iIndexOf2 > iIndexOf) {
                arrayList.add(str.substring(i, iIndexOf));
                arrayList.add(null);
            } else {
                arrayList.add(str.substring(i, iIndexOf2));
                arrayList.add(str.substring(iIndexOf2 + 1, iIndexOf));
            }
            i = iIndexOf + 1;
        }
        return arrayList;
    }

    public final String a() {
        if (this.f95913g.isEmpty()) {
            return "";
        }
        int length = this.e.length() + 3;
        String str = this.i;
        return this.i.substring(length, nu.e(str, length, str.length(), ":@"));
    }

    public final boolean b() {
        return this.e.equals("https");
    }

    public final String d() {
        if (this.f.isEmpty()) {
            return "";
        }
        return this.i.substring(this.i.indexOf(58, this.e.length() + 3) + 1, this.i.indexOf(64));
    }

    public final String e() {
        return this.e;
    }

    public final boolean equals(Object obj) {
        return (obj instanceof nc) && ((nc) obj).i.equals(this.i);
    }

    public final List<String> f() {
        int iIndexOf = this.i.indexOf(47, this.e.length() + 3);
        String str = this.i;
        int iE = nu.e(str, iIndexOf, str.length(), "?#");
        ArrayList arrayList = new ArrayList();
        while (iIndexOf < iE) {
            int i = iIndexOf + 1;
            int iA = nu.a(this.i, i, iE, '/');
            arrayList.add(this.i.substring(i, iA));
            iIndexOf = iA;
        }
        return arrayList;
    }

    public final String g() {
        return this.a;
    }

    public final int h() {
        return this.d;
    }

    public final int hashCode() {
        return this.i.hashCode();
    }

    public final String i() {
        if (this.c == null) {
            return null;
        }
        int iIndexOf = this.i.indexOf(63) + 1;
        String str = this.i;
        return this.i.substring(iIndexOf, nu.a(str, iIndexOf, str.length(), '#'));
    }

    public final String j() {
        int iIndexOf = this.i.indexOf(47, this.e.length() + 3);
        String str = this.i;
        return this.i.substring(iIndexOf, nu.e(str, iIndexOf, str.length(), "?#"));
    }

    public final String toString() {
        return this.i;
    }

    public static void b(StringBuilder sb, List<String> list) {
        int size = list.size();
        for (int i = 0; i < size; i++) {
            sb.append('/');
            sb.append(list.get(i));
        }
    }

    public static int e(String str) {
        if (str.equals("http")) {
            return 80;
        }
        return str.equals("https") ? 443 : -1;
    }

    public static void e(StringBuilder sb, List<String> list) {
        int size = list.size();
        for (int i = 0; i < size; i += 2) {
            String str = list.get(i);
            String str2 = list.get(i + 1);
            if (i > 0) {
                sb.append('&');
            }
            sb.append(str);
            if (str2 != null) {
                sb.append('=');
                sb.append(str2);
            }
        }
    }

    public static nc b(String str) {
        return new b().a(null, str).a();
    }

    private static String d(String str, boolean z) {
        return c(str, 0, str.length(), z);
    }

    public final b a(String str) {
        try {
            return new b().a(this, str);
        } catch (IllegalArgumentException unused) {
            return null;
        }
    }

    private static List<String> a(List<String> list, boolean z) {
        int size = list.size();
        ArrayList arrayList = new ArrayList(size);
        for (int i = 0; i < size; i++) {
            String str = list.get(i);
            arrayList.add(str != null ? d(str, z) : null);
        }
        return Collections.unmodifiableList(arrayList);
    }

    /* JADX WARN: Removed duplicated region for block: B:15:0x0039  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    private static void b(com.facetec.sdk.px r5, java.lang.String r6, int r7, int r8, boolean r9) {
        /*
        L0:
            if (r7 >= r8) goto L42
            int r0 = r6.codePointAt(r7)
            r1 = 37
            if (r0 != r1) goto L2d
            int r1 = r7 + 2
            if (r1 >= r8) goto L2d
            int r2 = r7 + 1
            char r2 = r6.charAt(r2)
            int r2 = com.facetec.sdk.nu.d(r2)
            char r3 = r6.charAt(r1)
            int r3 = com.facetec.sdk.nu.d(r3)
            r4 = -1
            if (r2 == r4) goto L39
            if (r3 == r4) goto L39
            int r7 = r2 << 4
            int r7 = r7 + r3
            r5.g(r7)
            r7 = r1
            goto L3c
        L2d:
            r1 = 43
            if (r0 != r1) goto L39
            if (r9 == 0) goto L39
            r1 = 32
            r5.g(r1)
            goto L3c
        L39:
            r5.e(r0)
        L3c:
            int r0 = java.lang.Character.charCount(r0)
            int r7 = r7 + r0
            goto L0
        L42:
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: com.facetec.sdk.nc.b(com.facetec.sdk.px, java.lang.String, int, int, boolean):void");
    }

    private static boolean d(String str, int i, int i2) {
        int i3 = i + 2;
        return i3 < i2 && str.charAt(i) == '%' && nu.d(str.charAt(i + 1)) != -1 && nu.d(str.charAt(i3)) != -1;
    }

    public static String d(String str, int i, int i2, String str2, boolean z, boolean z2, boolean z3, boolean z4, Charset charset) {
        int iCharCount = i;
        while (iCharCount < i2) {
            int iCodePointAt = str.codePointAt(iCharCount);
            int i3 = 43;
            if (iCodePointAt >= 32 && iCodePointAt != 127 && ((iCodePointAt < 128 || !z4) && str2.indexOf(iCodePointAt) == -1 && ((iCodePointAt != 37 || (z && (!z2 || d(str, iCharCount, i2)))) && (iCodePointAt != 43 || !z3)))) {
                iCharCount += Character.charCount(iCodePointAt);
            } else {
                px pxVar = new px();
                pxVar.d(str, i, iCharCount);
                px pxVar2 = null;
                while (iCharCount < i2) {
                    int iCodePointAt2 = str.codePointAt(iCharCount);
                    if (!z || (iCodePointAt2 != 9 && iCodePointAt2 != 10 && iCodePointAt2 != 12 && iCodePointAt2 != 13)) {
                        if (iCodePointAt2 == i3 && z3) {
                            pxVar.a(z ? "+" : "%2B");
                        } else if (iCodePointAt2 >= 32 && iCodePointAt2 != 127 && ((iCodePointAt2 < 128 || !z4) && str2.indexOf(iCodePointAt2) == -1 && (iCodePointAt2 != 37 || (z && (!z2 || d(str, iCharCount, i2)))))) {
                            pxVar.e(iCodePointAt2);
                        } else {
                            if (pxVar2 == null) {
                                pxVar2 = new px();
                            }
                            if (charset != null && !charset.equals(nu.e)) {
                                int iCharCount2 = Character.charCount(iCodePointAt2) + iCharCount;
                                if (iCharCount < 0) {
                                    throw new IllegalAccessError("beginIndex < 0: ".concat(String.valueOf(iCharCount)));
                                }
                                if (iCharCount2 >= iCharCount) {
                                    if (iCharCount2 <= str.length()) {
                                        if (charset.equals(qq.e)) {
                                            pxVar2.d(str, iCharCount, iCharCount2);
                                        } else {
                                            byte[] bytes = str.substring(iCharCount, iCharCount2).getBytes(charset);
                                            pxVar2.d(bytes, 0, bytes.length);
                                        }
                                    } else {
                                        StringBuilder sb = new StringBuilder("endIndex > string.length: ");
                                        sb.append(iCharCount2);
                                        sb.append(" > ");
                                        sb.append(str.length());
                                        throw new IllegalArgumentException(sb.toString());
                                    }
                                } else {
                                    StringBuilder sb2 = new StringBuilder("endIndex < beginIndex: ");
                                    sb2.append(iCharCount2);
                                    sb2.append(" < ");
                                    sb2.append(iCharCount);
                                    throw new IllegalArgumentException(sb2.toString());
                                }
                            } else {
                                pxVar2.e(iCodePointAt2);
                            }
                            while (!pxVar2.b()) {
                                byte bG = pxVar2.g();
                                pxVar.g(37);
                                char[] cArr = b;
                                pxVar.g((int) cArr[((bG & 255) >> 4) & 15]);
                                pxVar.g((int) cArr[bG & PassportService.SFI_DG15]);
                            }
                        }
                    }
                    iCharCount += Character.charCount(iCodePointAt2);
                    i3 = 43;
                }
                return pxVar.m();
            }
        }
        return str.substring(i, i2);
    }

    public static String c(String str, int i, int i2, boolean z) {
        for (int i3 = i; i3 < i2; i3++) {
            char cCharAt = str.charAt(i3);
            if (cCharAt == '%' || (cCharAt == '+' && z)) {
                px pxVar = new px();
                pxVar.d(str, i, i3);
                b(pxVar, str, i3, i2, z);
                return pxVar.m();
            }
        }
        return str.substring(i, i2);
    }

    public static String e(String str, String str2, boolean z, boolean z2, boolean z3, boolean z4) {
        return d(str, 0, str.length(), str2, z, z2, z3, z4, null);
    }

    public final URI c() {
        b bVar = new b();
        bVar.e = this.e;
        bVar.c = a();
        bVar.b = d();
        bVar.d = this.a;
        bVar.a = this.d != e(this.e) ? this.d : -1;
        bVar.f.clear();
        bVar.f.addAll(f());
        bVar.b(i());
        bVar.h = this.h == null ? null : this.i.substring(this.i.indexOf(35) + 1);
        int size = bVar.f.size();
        for (int i = 0; i < size; i++) {
            bVar.f.set(i, e(bVar.f.get(i), "[]", true, true, false, true));
        }
        List<String> list = bVar.f95914g;
        if (list != null) {
            int size2 = list.size();
            for (int i2 = 0; i2 < size2; i2++) {
                String str = bVar.f95914g.get(i2);
                if (str != null) {
                    bVar.f95914g.set(i2, e(str, "\\^`{|}", true, true, true, true));
                }
            }
        }
        String str2 = bVar.h;
        if (str2 != null) {
            bVar.h = e(str2, " \"#<>\\^`{|}", true, true, false, false);
        }
        String string = bVar.toString();
        try {
            return new URI(string);
        } catch (URISyntaxException e) {
            try {
                return URI.create(string.replaceAll("[\\u0000-\\u001F\\u007F-\\u009F\\p{javaWhitespace}]", ""));
            } catch (Exception unused) {
                throw new RuntimeException(e);
            }
        }
    }

    public static String d(String str, String str2, Charset charset) {
        return d(str, 0, str.length(), str2, false, false, true, true, charset);
    }
}