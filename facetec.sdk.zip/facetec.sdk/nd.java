package com.facetec.sdk;

import ai.luciq.library.networkv2.request.Header;
import com.facetec.sdk.mz;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;
import net.sf.scuba.smartcards.ISO7816;
import org.jmrtd.PassportService;

/* JADX INFO: loaded from: classes4.dex */
public final class nd extends ni {
    private static final byte[] a;
    private static final byte[] b;
    private static final byte[] c;
    public static final nb d;
    public static final nb e = nb.c("multipart/mixed");
    private final List<b> f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    private final nb f95915g;
    private final qb h;
    private long i = -1;
    private final nb j;

    public static final class a {
        public nb a;
        public final List<b> b;
        public final qb d;

        public a() {
            this(UUID.randomUUID().toString());
        }

        public final a b(b bVar) {
            if (bVar == null) {
                throw new NullPointerException("part == null");
            }
            this.b.add(bVar);
            return this;
        }

        private a(String str) {
            this.a = nd.e;
            this.b = new ArrayList();
            this.d = qb.d(str);
        }
    }

    public static final class b {
        final mz d;
        final ni e;

        private b(mz mzVar, ni niVar) {
            this.d = mzVar;
            this.e = niVar;
        }

        private static b b(mz mzVar, ni niVar) {
            if (niVar == null) {
                throw new NullPointerException("body == null");
            }
            if (mzVar != null && mzVar.a(Header.CONTENT_TYPE) != null) {
                throw new IllegalArgumentException("Unexpected header: Content-Type");
            }
            if (mzVar == null || mzVar.a("Content-Length") == null) {
                return new b(mzVar, niVar);
            }
            throw new IllegalArgumentException("Unexpected header: Content-Length");
        }

        public static b d(String str, String str2, ni niVar) {
            if (str == null) {
                throw new NullPointerException("name == null");
            }
            StringBuilder sb = new StringBuilder("form-data; name=");
            nd.d(sb, str);
            if (str2 != null) {
                sb.append("; filename=");
                nd.d(sb, str2);
            }
            return b(new mz.a().e("Content-Disposition", sb.toString()).c(), niVar);
        }
    }

    static {
        nb.c("multipart/alternative");
        nb.c("multipart/digest");
        nb.c("multipart/parallel");
        d = nb.c("multipart/form-data");
        b = new byte[]{58, ISO7816.INS_VERIFY};
        c = new byte[]{PassportService.SFI_DG13, 10};
        a = new byte[]{45, 45};
    }

    public nd(qb qbVar, nb nbVar, List<b> list) {
        this.h = qbVar;
        this.f95915g = nbVar;
        StringBuilder sb = new StringBuilder();
        sb.append(nbVar);
        sb.append("; boundary=");
        sb.append(qbVar.d());
        this.j = nb.c(sb.toString());
        this.f = nu.e(list);
    }

    @Override // com.facetec.sdk.ni
    public final nb b() {
        return this.j;
    }

    @Override // com.facetec.sdk.ni
    public final long d() {
        long j = this.i;
        if (j != -1) {
            return j;
        }
        long jD = d((pu) null, true);
        this.i = jD;
        return jD;
    }

    @Override // com.facetec.sdk.ni
    public final void b(pu puVar) {
        d(puVar, false);
    }

    /* JADX WARN: Multi-variable type inference failed */
    private long d(pu puVar, boolean z) {
        px pxVar;
        if (z) {
            puVar = new px();
            pxVar = puVar;
        } else {
            pxVar = 0;
        }
        int size = this.f.size();
        long j = 0;
        for (int i = 0; i < size; i++) {
            b bVar = this.f.get(i);
            mz mzVar = bVar.d;
            ni niVar = bVar.e;
            puVar.d(a);
            puVar.a(this.h);
            puVar.d(c);
            if (mzVar != null) {
                int iD = mzVar.d();
                for (int i2 = 0; i2 < iD; i2++) {
                    puVar.a(mzVar.a(i2)).d(b).a(mzVar.b(i2)).d(c);
                }
            }
            nb nbVarB = niVar.b();
            if (nbVarB != null) {
                puVar.a("Content-Type: ").a(nbVarB.toString()).d(c);
            }
            long jD = niVar.d();
            if (jD != -1) {
                puVar.a("Content-Length: ").n(jD).d(c);
            } else if (z) {
                pxVar.q();
                return -1L;
            }
            byte[] bArr = c;
            puVar.d(bArr);
            if (z) {
                j += jD;
            } else {
                niVar.b(puVar);
            }
            puVar.d(bArr);
        }
        byte[] bArr2 = a;
        puVar.d(bArr2);
        puVar.a(this.h);
        puVar.d(bArr2);
        puVar.d(c);
        if (!z) {
            return j;
        }
        long jE = j + pxVar.e();
        pxVar.q();
        return jE;
    }

    public static StringBuilder d(StringBuilder sb, String str) {
        sb.append('\"');
        int length = str.length();
        for (int i = 0; i < length; i++) {
            char cCharAt = str.charAt(i);
            if (cCharAt == '\n') {
                sb.append("%0A");
            } else if (cCharAt == '\r') {
                sb.append("%0D");
            } else if (cCharAt != '\"') {
                sb.append(cCharAt);
            } else {
                sb.append("%22");
            }
        }
        sb.append('\"');
        return sb;
    }
}