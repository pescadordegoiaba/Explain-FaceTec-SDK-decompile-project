package com.facetec.sdk;

/* JADX INFO: loaded from: classes4.dex */
public interface ne {

    public interface c {
        int a();

        int b();

        int c();

        nj d();

        nh e(nj njVar);
    }

    nh c(c cVar);
}