package com.facetec.sdk;

import ai.luciq.library.networkv2.request.Constants;
import com.facetec.sdk.mt;
import com.facetec.sdk.mz;
import com.facetec.sdk.na;
import com.facetec.sdk.nh;
import java.io.IOException;
import java.lang.ref.Reference;
import java.net.Proxy;
import java.net.ProxySelector;
import java.net.Socket;
import java.security.GeneralSecurityException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Random;
import javax.net.SocketFactory;
import javax.net.ssl.HostnameVerifier;
import javax.net.ssl.SSLContext;
import javax.net.ssl.SSLSocket;
import javax.net.ssl.SSLSocketFactory;
import javax.net.ssl.TrustManager;
import javax.net.ssl.X509TrustManager;

/* JADX INFO: loaded from: classes4.dex */
public class nf implements Cloneable {
    static final List<ng> b = nu.b(ng.HTTP_2, ng.HTTP_1_1);
    static final List<mt> d = nu.b(mt.b, mt.d);
    private ml A;
    private boolean B;
    private mv C;
    private my D;
    final na.e a;
    final List<ne> c;
    final List<ne> e;
    public final ml f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public final boolean f95916g;
    final mi h;
    public final boolean i;
    final nw j;
    final int k;
    final int l;
    final int m;
    final int n;
    public final int o;
    private Proxy p;
    private ProxySelector q;
    private List<ng> r;
    private List<mt> s;
    private mu t;
    private SocketFactory u;
    private mr v;
    private SSLSocketFactory w;
    private po x;
    private HostnameVerifier y;
    private mp z;

    public static final class a {
        public static int A;
        public static int C;
        public int B;
        int D;
        Proxy a;

        /* JADX INFO: renamed from: g, reason: collision with root package name */
        ProxySelector f95917g;
        mr h;
        mi j;
        nw k;
        po l;
        HostnameVerifier m;
        SocketFactory n;
        SSLSocketFactory o;
        my p;
        ml q;
        mv r;
        public mp s;
        ml t;
        int u;
        boolean v;
        boolean w;
        public int x;
        boolean y;
        public int z;
        final List<ne> d = new ArrayList();
        final List<ne> f = new ArrayList();
        mu b = new mu();
        List<ng> e = nf.b;
        List<mt> c = nf.d;
        na.e i = na.c(na.a);

        public a() {
            ProxySelector proxySelector = ProxySelector.getDefault();
            this.f95917g = proxySelector;
            if (proxySelector == null) {
                this.f95917g = new pk();
            }
            this.h = mr.a;
            this.n = SocketFactory.getDefault();
            this.m = pr.c;
            this.s = mp.d;
            ml mlVar = ml.b;
            this.t = mlVar;
            this.q = mlVar;
            this.r = new mv();
            this.p = my.c;
            this.w = true;
            this.v = true;
            this.y = true;
            this.u = 0;
            this.x = 10000;
            this.B = 10000;
            this.z = 10000;
            this.D = 0;
        }

        public static int e() {
            int i = A;
            int i2 = i % 7277206;
            A = i + 1;
            if (i2 != 0) {
                return C;
            }
            int iNextInt = new Random().nextInt();
            C = iNextInt;
            return iNextInt;
        }

        public final nf b() {
            return new nf(this);
        }
    }

    static {
        nn.d = new nn() { // from class: com.facetec.sdk.nf.1
            @Override // com.facetec.sdk.nn
            public final boolean a(mv mvVar, nx nxVar) {
                if (!mv.f && !Thread.holdsLock(mvVar)) {
                    throw new AssertionError();
                }
                if (nxVar.f || mvVar.a == 0) {
                    mvVar.d.remove(nxVar);
                    return true;
                }
                mvVar.notifyAll();
                return false;
            }

            @Override // com.facetec.sdk.nn
            public final IOException b(mn mnVar, IOException iOException) {
                return ((nk) mnVar).d(iOException);
            }

            @Override // com.facetec.sdk.nn
            public final boolean c(mh mhVar, mh mhVar2) {
                return mhVar.c(mhVar2);
            }

            @Override // com.facetec.sdk.nn
            public final int d(nh.e eVar) {
                return eVar.d;
            }

            @Override // com.facetec.sdk.nn
            public final void e(mz.a aVar, String str, String str2) {
                aVar.b(str, str2);
            }

            @Override // com.facetec.sdk.nn
            public final nx b(mv mvVar, mh mhVar, oe oeVar, nm nmVar) {
                if (!mv.f && !Thread.holdsLock(mvVar)) {
                    throw new AssertionError();
                }
                for (nx nxVar : mvVar.d) {
                    if (nxVar.b(mhVar, nmVar)) {
                        oeVar.c(nxVar, true);
                        return nxVar;
                    }
                }
                return null;
            }

            @Override // com.facetec.sdk.nn
            public final oc c(mv mvVar) {
                return mvVar.c;
            }

            @Override // com.facetec.sdk.nn
            public final Socket d(mv mvVar, mh mhVar, oe oeVar) {
                if (!mv.f && !Thread.holdsLock(mvVar)) {
                    throw new AssertionError();
                }
                for (nx nxVar : mvVar.d) {
                    if (nxVar.b(mhVar, null) && nxVar.e() && nxVar != oeVar.b()) {
                        if (!oe.h && !Thread.holdsLock(oeVar.e)) {
                            throw new AssertionError();
                        }
                        if (oeVar.j != null || oeVar.b.k.size() != 1) {
                            throw new IllegalStateException();
                        }
                        Reference<oe> reference = oeVar.b.k.get(0);
                        Socket socketD = oeVar.d(true, false, false);
                        oeVar.b = nxVar;
                        nxVar.k.add(reference);
                        return socketD;
                    }
                }
                return null;
            }

            @Override // com.facetec.sdk.nn
            public final void c(mz.a aVar, String str) {
                int iIndexOf = str.indexOf(Constants.SEPARATOR, 1);
                if (iIndexOf != -1) {
                    aVar.b(str.substring(0, iIndexOf), str.substring(iIndexOf + 1));
                } else if (str.startsWith(Constants.SEPARATOR)) {
                    aVar.b("", str.substring(1));
                } else {
                    aVar.b("", str);
                }
            }

            @Override // com.facetec.sdk.nn
            public final void a(mt mtVar, SSLSocket sSLSocket, boolean z) {
                String[] enabledCipherSuites;
                String[] enabledProtocols;
                if (mtVar.c != null) {
                    enabledCipherSuites = nu.a(mq.d, sSLSocket.getEnabledCipherSuites(), mtVar.c);
                } else {
                    enabledCipherSuites = sSLSocket.getEnabledCipherSuites();
                }
                if (mtVar.f95911g != null) {
                    enabledProtocols = nu.a(nu.f95924g, sSLSocket.getEnabledProtocols(), mtVar.f95911g);
                } else {
                    enabledProtocols = sSLSocket.getEnabledProtocols();
                }
                String[] supportedCipherSuites = sSLSocket.getSupportedCipherSuites();
                int iE = nu.e(mq.d, supportedCipherSuites, "TLS_FALLBACK_SCSV");
                if (z && iE != -1) {
                    enabledCipherSuites = nu.c(enabledCipherSuites, supportedCipherSuites[iE]);
                }
                mt mtVarE = new mt.a(mtVar).c(enabledCipherSuites).e(enabledProtocols).e();
                String[] strArr = mtVarE.f95911g;
                if (strArr != null) {
                    sSLSocket.setEnabledProtocols(strArr);
                }
                String[] strArr2 = mtVarE.c;
                if (strArr2 != null) {
                    sSLSocket.setEnabledCipherSuites(strArr2);
                }
            }

            @Override // com.facetec.sdk.nn
            public final void b(mv mvVar, nx nxVar) {
                if (!mv.f && !Thread.holdsLock(mvVar)) {
                    throw new AssertionError();
                }
                if (!mvVar.h) {
                    mvVar.h = true;
                    mv.e.execute(mvVar.b);
                }
                mvVar.d.add(nxVar);
            }
        };
    }

    public nf() {
        this(new a());
    }

    private static SSLSocketFactory c(X509TrustManager x509TrustManager) {
        try {
            SSLContext sSLContextC = pm.i().c();
            sSLContextC.init(null, new TrustManager[]{x509TrustManager}, null);
            return sSLContextC.getSocketFactory();
        } catch (GeneralSecurityException e) {
            throw nu.e("No System TLS", e);
        }
    }

    public final SocketFactory a() {
        return this.u;
    }

    public final mr b() {
        return this.v;
    }

    public final Proxy d() {
        return this.p;
    }

    public final my e() {
        return this.D;
    }

    public final mp f() {
        return this.z;
    }

    public final mv g() {
        return this.C;
    }

    public final HostnameVerifier h() {
        return this.y;
    }

    public final ml i() {
        return this.A;
    }

    public final SSLSocketFactory j() {
        return this.w;
    }

    public final List<mt> k() {
        return this.s;
    }

    public final mu l() {
        return this.t;
    }

    public final List<ng> n() {
        return this.r;
    }

    public final boolean o() {
        return this.B;
    }

    public nf(a aVar) {
        boolean z;
        this.t = aVar.b;
        this.p = aVar.a;
        this.r = aVar.e;
        this.s = aVar.c;
        this.e = nu.e(aVar.d);
        this.c = nu.e(aVar.f);
        this.a = aVar.i;
        this.q = aVar.f95917g;
        this.v = aVar.h;
        this.h = aVar.j;
        this.j = aVar.k;
        this.u = aVar.n;
        Iterator<mt> it = this.s.iterator();
        loop0: while (true) {
            z = false;
            while (it.hasNext()) {
                z = (z || it.next().a) ? true : z;
            }
        }
        SSLSocketFactory sSLSocketFactory = aVar.o;
        if (sSLSocketFactory == null && z) {
            X509TrustManager x509TrustManagerD = nu.d();
            this.w = c(x509TrustManagerD);
            this.x = pm.i().e(x509TrustManagerD);
        } else {
            this.w = sSLSocketFactory;
            this.x = aVar.l;
        }
        if (this.w != null) {
            pm.i().e(this.w);
        }
        this.y = aVar.m;
        mp mpVar = aVar.s;
        po poVar = this.x;
        this.z = nu.a(mpVar.b, poVar) ? mpVar : new mp(mpVar.c, poVar);
        this.A = aVar.t;
        this.f = aVar.q;
        this.C = aVar.r;
        this.D = aVar.p;
        this.i = aVar.w;
        this.f95916g = aVar.v;
        this.B = aVar.y;
        this.l = aVar.u;
        this.n = aVar.x;
        this.m = aVar.B;
        this.k = aVar.z;
        this.o = aVar.D;
        if (this.e.contains(null)) {
            StringBuilder sb = new StringBuilder("Null interceptor: ");
            sb.append(this.e);
            throw new IllegalStateException(sb.toString());
        }
        if (this.c.contains(null)) {
            StringBuilder sb2 = new StringBuilder("Null network interceptor: ");
            sb2.append(this.c);
            throw new IllegalStateException(sb2.toString());
        }
    }

    public final mn b(nj njVar) {
        return nk.d(this, njVar, false);
    }

    public final ProxySelector c() {
        return this.q;
    }
}