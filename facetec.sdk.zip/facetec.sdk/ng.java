package com.facetec.sdk;

import java.io.IOException;

/* JADX INFO: loaded from: classes4.dex */
public enum ng {
    HTTP_1_0("http/1.0"),
    HTTP_1_1("http/1.1"),
    SPDY_3("spdy/3.1"),
    HTTP_2("h2"),
    H2_PRIOR_KNOWLEDGE("h2_prior_knowledge"),
    QUIC("quic");

    private final String j;

    ng(String str) {
        this.j = str;
    }

    public static ng c(String str) throws IOException {
        ng ngVar = HTTP_1_0;
        if (str.equals(ngVar.j)) {
            return ngVar;
        }
        ng ngVar2 = HTTP_1_1;
        if (str.equals(ngVar2.j)) {
            return ngVar2;
        }
        ng ngVar3 = H2_PRIOR_KNOWLEDGE;
        if (str.equals(ngVar3.j)) {
            return ngVar3;
        }
        ng ngVar4 = HTTP_2;
        if (str.equals(ngVar4.j)) {
            return ngVar4;
        }
        if (str.equals(SPDY_3.j)) {
            return SPDY_3;
        }
        if (str.equals(QUIC.j)) {
            return QUIC;
        }
        throw new IOException("Unexpected protocol: ".concat(str));
    }

    @Override // java.lang.Enum
    public final String toString() {
        return this.j;
    }
}