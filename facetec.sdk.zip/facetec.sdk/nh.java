package com.facetec.sdk;

import com.facetec.sdk.mz;
import java.io.Closeable;

/* JADX INFO: loaded from: classes4.dex */
public final class nh implements Closeable {
    final int a;
    final nj b;
    final ng c;
    public final String d;
    public final mx e;
    final nh f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    final mz f95919g;
    public final no h;
    final nh i;
    final nh j;
    final long l;
    final long n;
    private volatile mo o;

    public static class e {
        mx a;
        ng b;
        String c;
        int d;
        nj e;
        no f;

        /* JADX INFO: renamed from: g, reason: collision with root package name */
        nh f95920g;
        public nh h;
        nh i;
        public mz.a j;
        long l;
        long n;

        public e() {
            this.d = -1;
            this.j = new mz.a();
        }

        public final e a(mz mzVar) {
            this.j = mzVar.b();
            return this;
        }

        public final e b(ng ngVar) {
            this.b = ngVar;
            return this;
        }

        public final e c(nj njVar) {
            this.e = njVar;
            return this;
        }

        public final e d(String str) {
            this.c = str;
            return this;
        }

        public final e e(int i) {
            this.d = i;
            return this;
        }

        public final e a(nh nhVar) {
            if (nhVar != null) {
                c("cacheResponse", nhVar);
            }
            this.f95920g = nhVar;
            return this;
        }

        public final e b(no noVar) {
            this.f = noVar;
            return this;
        }

        public final e c(mx mxVar) {
            this.a = mxVar;
            return this;
        }

        public final e d(String str, String str2) {
            this.j.a(str, str2);
            return this;
        }

        public final e e(nh nhVar) {
            if (nhVar != null) {
                c("networkResponse", nhVar);
            }
            this.i = nhVar;
            return this;
        }

        private static void c(String str, nh nhVar) {
            if (nhVar.h == null) {
                if (nhVar.i == null) {
                    if (nhVar.j == null) {
                        if (nhVar.f == null) {
                            return;
                        }
                        StringBuilder sb = new StringBuilder();
                        sb.append(str);
                        sb.append(".priorResponse != null");
                        throw new IllegalArgumentException(sb.toString());
                    }
                    StringBuilder sb2 = new StringBuilder();
                    sb2.append(str);
                    sb2.append(".cacheResponse != null");
                    throw new IllegalArgumentException(sb2.toString());
                }
                StringBuilder sb3 = new StringBuilder();
                sb3.append(str);
                sb3.append(".networkResponse != null");
                throw new IllegalArgumentException(sb3.toString());
            }
            StringBuilder sb4 = new StringBuilder();
            sb4.append(str);
            sb4.append(".body != null");
            throw new IllegalArgumentException(sb4.toString());
        }

        public final e d(long j) {
            this.n = j;
            return this;
        }

        public e(nh nhVar) {
            this.d = -1;
            this.e = nhVar.b;
            this.b = nhVar.c;
            this.d = nhVar.a;
            this.c = nhVar.d;
            this.a = nhVar.e;
            this.j = nhVar.f95919g.b();
            this.f = nhVar.h;
            this.i = nhVar.i;
            this.f95920g = nhVar.j;
            this.h = nhVar.f;
            this.l = nhVar.l;
            this.n = nhVar.n;
        }

        public final nh a() {
            if (this.e != null) {
                if (this.b != null) {
                    if (this.d >= 0) {
                        if (this.c != null) {
                            return new nh(this);
                        }
                        throw new IllegalStateException("message == null");
                    }
                    StringBuilder sb = new StringBuilder("code < 0: ");
                    sb.append(this.d);
                    throw new IllegalStateException(sb.toString());
                }
                throw new IllegalStateException("protocol == null");
            }
            throw new IllegalStateException("request == null");
        }

        public final e c(long j) {
            this.l = j;
            return this;
        }
    }

    public nh(e eVar) {
        this.b = eVar.e;
        this.c = eVar.b;
        this.a = eVar.d;
        this.d = eVar.c;
        this.e = eVar.a;
        this.f95919g = eVar.j.c();
        this.h = eVar.f;
        this.i = eVar.i;
        this.j = eVar.f95920g;
        this.f = eVar.h;
        this.l = eVar.l;
        this.n = eVar.n;
    }

    public final boolean a() {
        int i = this.a;
        return i >= 200 && i < 300;
    }

    public final mz b() {
        return this.f95919g;
    }

    public final nj c() {
        return this.b;
    }

    @Override // java.io.Closeable, java.lang.AutoCloseable
    public final void close() {
        no noVar = this.h;
        if (noVar == null) {
            throw new IllegalStateException("response is not eligible for a body and must not be closed");
        }
        noVar.close();
    }

    public final int d() {
        return this.a;
    }

    public final no e() {
        return this.h;
    }

    public final e f() {
        return new e(this);
    }

    public final long g() {
        return this.n;
    }

    public final long h() {
        return this.l;
    }

    public final mo i() {
        mo moVar = this.o;
        if (moVar != null) {
            return moVar;
        }
        mo moVarB = mo.b(this.f95919g);
        this.o = moVarB;
        return moVarB;
    }

    public final nh j() {
        return this.f;
    }

    public final String toString() {
        StringBuilder sb = new StringBuilder("Response{protocol=");
        sb.append(this.c);
        sb.append(", code=");
        sb.append(this.a);
        sb.append(", message=");
        sb.append(this.d);
        sb.append(", url=");
        sb.append(this.b.b());
        sb.append('}');
        return sb.toString();
    }

    public final String a(String str) {
        String strA = this.f95919g.a(str);
        if (strA != null) {
            return strA;
        }
        return null;
    }
}