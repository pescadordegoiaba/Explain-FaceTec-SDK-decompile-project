package com.facetec.sdk;

import ai.luciq.library.networkv2.request.RequestMethod;
import com.facetec.sdk.mz;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.Map;

/* JADX INFO: loaded from: classes4.dex */
public final class nj {

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public static int f95921g;
    public static int h;
    final Map<Class<?>, Object> a;
    final String b;
    final ni c;
    final nc d;
    final mz e;
    private volatile mo i;

    public static class b {
        Map<Class<?>, Object> a;
        String b;
        ni c;
        public mz.a d;
        nc e;

        public b() {
            this.a = Collections.EMPTY_MAP;
            this.b = RequestMethod.GET;
            this.d = new mz.a();
        }

        public final b a(String str, ni niVar) {
            if (str == null) {
                throw new NullPointerException("method == null");
            }
            if (str.length() == 0) {
                throw new IllegalArgumentException("method.length() == 0");
            }
            if (niVar != null && !oj.b(str)) {
                StringBuilder sb = new StringBuilder("method ");
                sb.append(str);
                sb.append(" must not have a request body.");
                throw new IllegalArgumentException(sb.toString());
            }
            if (niVar != null || !oj.c(str)) {
                this.b = str;
                this.c = niVar;
                return this;
            }
            StringBuilder sb2 = new StringBuilder("method ");
            sb2.append(str);
            sb2.append(" must have a request body.");
            throw new IllegalArgumentException(sb2.toString());
        }

        public final b b(String str, String str2) {
            this.d.a(str, str2);
            return this;
        }

        public final b d(nc ncVar) {
            if (ncVar == null) {
                throw new NullPointerException("url == null");
            }
            this.e = ncVar;
            return this;
        }

        public final b e(String str) {
            String string;
            if (str == null) {
                throw new NullPointerException("url == null");
            }
            if (str.regionMatches(true, 0, "ws:", 0, 3)) {
                StringBuilder sb = new StringBuilder("http:");
                sb.append(str.substring(3));
                string = sb.toString();
            } else if (str.regionMatches(true, 0, "wss:", 0, 4)) {
                StringBuilder sb2 = new StringBuilder("https:");
                sb2.append(str.substring(4));
                string = sb2.toString();
            } else {
                string = str;
            }
            return d(nc.b(string));
        }

        public final b b(String str) {
            this.d.d(str);
            return this;
        }

        public final b b(ni niVar) {
            return a(RequestMethod.POST, niVar);
        }

        public final b d(String str, String str2) {
            this.d.d(str, str2);
            return this;
        }

        public final nj d() {
            if (this.e != null) {
                return new nj(this);
            }
            throw new IllegalStateException("url == null");
        }

        public b(nj njVar) {
            Map<Class<?>, Object> map = Collections.EMPTY_MAP;
            this.a = map;
            this.e = njVar.d;
            this.b = njVar.b;
            this.c = njVar.c;
            this.a = njVar.a.isEmpty() ? map : new LinkedHashMap<>(njVar.a);
            this.d = njVar.e.b();
        }
    }

    public nj(b bVar) {
        this.d = bVar.e;
        this.b = bVar.b;
        this.e = bVar.d.c();
        this.c = bVar.c;
        this.a = nu.b(bVar.a);
    }

    public static int f() {
        int i = h;
        int i2 = i % 8033511;
        h = i + 1;
        if (i2 != 0) {
            return f95921g;
        }
        int i3 = (int) Runtime.getRuntime().totalMemory();
        f95921g = i3;
        return i3;
    }

    public final mz a() {
        return this.e;
    }

    public final nc b() {
        return this.d;
    }

    public final String c() {
        return this.b;
    }

    public final b d() {
        return new b(this);
    }

    public final ni e() {
        return this.c;
    }

    public final mo i() {
        mo moVar = this.i;
        if (moVar != null) {
            return moVar;
        }
        mo moVarB = mo.b(this.e);
        this.i = moVarB;
        return moVarB;
    }

    public final boolean j() {
        return this.d.b();
    }

    public final String toString() {
        StringBuilder sb = new StringBuilder("Request{method=");
        sb.append(this.b);
        sb.append(", url=");
        sb.append(this.d);
        sb.append(", tags=");
        sb.append(this.a);
        sb.append('}');
        return sb.toString();
    }

    public final String a(String str) {
        return this.e.a(str);
    }
}