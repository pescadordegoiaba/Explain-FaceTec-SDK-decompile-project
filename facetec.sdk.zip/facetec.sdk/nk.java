package com.facetec.sdk;

import com.facetec.sdk.nc;
import java.io.IOException;
import java.io.InterruptedIOException;
import java.util.ArrayList;
import java.util.concurrent.TimeUnit;

/* JADX INFO: loaded from: classes4.dex */
final class nk implements mn {
    final nj a;
    final pw b;
    final nf c;
    na d;
    final ol e;
    final boolean h;
    private boolean i;

    public final class a extends np {
        static final /* synthetic */ boolean c = true;
        final mm e;

        public a(mm mmVar) {
            super("OkHttp %s", nk.this.d());
            this.e = mmVar;
        }

        @Override // com.facetec.sdk.np
        public final void c() {
            nk nkVar;
            nh nhVarE;
            nk.this.b.b();
            try {
                try {
                    nkVar = nk.this;
                    ArrayList arrayList = new ArrayList();
                    arrayList.addAll(nkVar.c.e);
                    arrayList.add(nkVar.e);
                    arrayList.add(new ob(nkVar.c.b()));
                    nf nfVar = nkVar.c;
                    mi miVar = nfVar.h;
                    arrayList.add(new nt(miVar != null ? miVar.c : nfVar.j));
                    arrayList.add(new ny(nkVar.c));
                    if (!nkVar.h) {
                        arrayList.addAll(nkVar.c.c);
                    }
                    arrayList.add(new of(nkVar.h));
                    nj njVar = nkVar.a;
                    na naVar = nkVar.d;
                    nf nfVar2 = nkVar.c;
                    nhVarE = new oo(arrayList, null, null, null, 0, njVar, nkVar, naVar, nfVar2.n, nfVar2.m, nfVar2.k).e(nkVar.a);
                } catch (IOException e) {
                    IOException iOExceptionD = nk.this.d(e);
                    if (0 != 0) {
                        pm pmVarI = pm.i();
                        StringBuilder sb = new StringBuilder("Callback failure for ");
                        nk nkVar2 = nk.this;
                        StringBuilder sb2 = new StringBuilder();
                        sb2.append(nkVar2.e.e() ? "canceled " : "");
                        sb2.append(nkVar2.h ? "web socket" : "call");
                        sb2.append(" to ");
                        sb2.append(nkVar2.d());
                        sb.append(sb2.toString());
                        pmVarI.a(4, sb.toString(), iOExceptionD);
                    } else {
                        na unused = nk.this.d;
                        this.e.c(iOExceptionD);
                    }
                } catch (Throwable th) {
                    nk.this.a();
                    if (0 == 0) {
                        this.e.c(new IOException("canceled due to ".concat(String.valueOf(th))));
                    }
                    throw th;
                }
                if (nkVar.e.e()) {
                    nu.d(nhVarE);
                    throw new IOException("Canceled");
                }
                this.e.b(nhVarE);
                nk.this.c.l().a(this);
            } catch (Throwable th2) {
                nk.this.c.l().a(this);
                throw th2;
            }
        }

        public final String d() {
            return nk.this.a.b().g();
        }
    }

    private nk(nf nfVar, nj njVar, boolean z) {
        this.c = nfVar;
        this.a = njVar;
        this.h = z;
        this.e = new ol(nfVar, z);
        pw pwVar = new pw() { // from class: com.facetec.sdk.nk.5
            @Override // com.facetec.sdk.pw
            public final void d() {
                nk.this.a();
            }
        };
        this.b = pwVar;
        pwVar.b(nfVar.l, TimeUnit.MILLISECONDS);
    }

    public static nk d(nf nfVar, nj njVar, boolean z) {
        nk nkVar = new nk(nfVar, njVar, z);
        nkVar.d = nfVar.a.d();
        return nkVar;
    }

    public final /* synthetic */ Object clone() {
        return d(this.c, this.a, this.h);
    }

    @Override // com.facetec.sdk.mn
    public final void e(mm mmVar) {
        synchronized (this) {
            if (this.i) {
                throw new IllegalStateException("Already Executed");
            }
            this.i = true;
        }
        this.e.a = pm.i().e("response.body().close()");
        mu muVarL = this.c.l();
        a aVar = new a(mmVar);
        synchronized (muVarL) {
            muVarL.c.add(aVar);
        }
        muVarL.e();
    }

    public final void a() {
        oi oiVar;
        nx nxVar;
        ol olVar = this.e;
        olVar.b = true;
        oe oeVar = olVar.c;
        if (oeVar != null) {
            synchronized (oeVar.e) {
                oeVar.f = true;
                oiVar = oeVar.j;
                nxVar = oeVar.b;
            }
            if (oiVar != null) {
                oiVar.e();
            } else if (nxVar != null) {
                nxVar.c();
            }
        }
    }

    public final IOException d(IOException iOException) {
        if (!this.b.c()) {
            return iOException;
        }
        InterruptedIOException interruptedIOException = new InterruptedIOException("timeout");
        if (iOException != null) {
            interruptedIOException.initCause(iOException);
        }
        return interruptedIOException;
    }

    public final String d() {
        nc.b bVarA = this.a.b().a("/...");
        bVarA.c = nc.e("", " \"':;<=>@[]^`{}|/\\?#", false, false, false, true);
        bVarA.b = nc.e("", " \"':;<=>@[]^`{}|/\\?#", false, false, false, true);
        return bVarA.a().toString();
    }
}