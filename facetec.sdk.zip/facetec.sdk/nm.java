package com.facetec.sdk;

import java.net.InetSocketAddress;
import java.net.Proxy;

/* JADX INFO: loaded from: classes4.dex */
public final class nm {
    private InetSocketAddress c;
    private mh d;
    private Proxy e;

    public nm(mh mhVar, Proxy proxy, InetSocketAddress inetSocketAddress) {
        if (mhVar == null) {
            throw new NullPointerException("address == null");
        }
        if (proxy == null) {
            throw new NullPointerException("proxy == null");
        }
        if (inetSocketAddress == null) {
            throw new NullPointerException("inetSocketAddress == null");
        }
        this.d = mhVar;
        this.e = proxy;
        this.c = inetSocketAddress;
    }

    public final InetSocketAddress a() {
        return this.c;
    }

    public final boolean c() {
        return this.d.c != null && this.e.type() == Proxy.Type.HTTP;
    }

    public final mh d() {
        return this.d;
    }

    public final Proxy e() {
        return this.e;
    }

    public final boolean equals(Object obj) {
        if (!(obj instanceof nm)) {
            return false;
        }
        nm nmVar = (nm) obj;
        return nmVar.d.equals(this.d) && nmVar.e.equals(this.e) && nmVar.c.equals(this.c);
    }

    public final int hashCode() {
        return ((((this.d.hashCode() + 527) * 31) + this.e.hashCode()) * 31) + this.c.hashCode();
    }

    public final String toString() {
        StringBuilder sb = new StringBuilder("Route{");
        sb.append(this.c);
        sb.append("}");
        return sb.toString();
    }
}