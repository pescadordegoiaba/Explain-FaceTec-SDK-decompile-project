package com.facetec.sdk;

import com.facetec.sdk.mz;
import com.facetec.sdk.nh;
import java.io.IOException;
import java.net.Socket;
import javax.net.ssl.SSLSocket;

/* JADX INFO: loaded from: classes4.dex */
public abstract class nn {
    public static nn d;

    public abstract void a(mt mtVar, SSLSocket sSLSocket, boolean z);

    public abstract boolean a(mv mvVar, nx nxVar);

    public abstract nx b(mv mvVar, mh mhVar, oe oeVar, nm nmVar);

    public abstract IOException b(mn mnVar, IOException iOException);

    public abstract void b(mv mvVar, nx nxVar);

    public abstract oc c(mv mvVar);

    public abstract void c(mz.a aVar, String str);

    public abstract boolean c(mh mhVar, mh mhVar2);

    public abstract int d(nh.e eVar);

    public abstract Socket d(mv mvVar, mh mhVar, oe oeVar);

    public abstract void e(mz.a aVar, String str, String str2);
}