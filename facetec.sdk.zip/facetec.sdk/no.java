package com.facetec.sdk;

import java.io.Closeable;

/* JADX INFO: loaded from: classes4.dex */
public abstract class no implements Closeable {
    public final String b() {
        pz pzVarC = c();
        try {
            nb nbVarD = d();
            String strC = pzVarC.c(nu.c(pzVarC, nbVarD != null ? nbVarD.a(nu.e) : nu.e));
            nu.d(pzVarC);
            return strC;
        } catch (Throwable th) {
            nu.d(pzVarC);
            throw th;
        }
    }

    public abstract pz c();

    @Override // java.io.Closeable, java.lang.AutoCloseable
    public void close() {
        nu.d(c());
    }

    public abstract nb d();

    public abstract long e();
}