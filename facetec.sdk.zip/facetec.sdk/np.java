package com.facetec.sdk;

/* JADX INFO: loaded from: classes4.dex */
public abstract class np implements Runnable {
    private String b;

    public np(String str, Object... objArr) {
        this.b = nu.b(str, objArr);
    }

    public abstract void c();

    @Override // java.lang.Runnable
    public final void run() {
        String name = Thread.currentThread().getName();
        Thread.currentThread().setName(this.b);
        try {
            c();
        } finally {
            Thread.currentThread().setName(name);
        }
    }
}