package com.facetec.sdk;

/* JADX INFO: loaded from: classes4.dex */
public final class nq {
    public static String b() {
        return "okhttp/3.12.13";
    }
}