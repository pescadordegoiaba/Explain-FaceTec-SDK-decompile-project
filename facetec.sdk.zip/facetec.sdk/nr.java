package com.facetec.sdk;

import java.util.Date;

/* JADX INFO: loaded from: classes4.dex */
public final class nr {
    public final nh a;
    public final nj b;

    public static class b {
        final nj a;
        Date b;
        final nh c;
        final long d;
        String e;
        long f;

        /* JADX INFO: renamed from: g, reason: collision with root package name */
        Date f95922g;
        long h;
        String i;
        Date j;
        String k;
        int o;

        public b(long j, nj njVar, nh nhVar) {
            this.o = -1;
            this.d = j;
            this.a = njVar;
            this.c = nhVar;
            if (nhVar != null) {
                this.f = nhVar.h();
                this.h = nhVar.g();
                mz mzVarB = nhVar.b();
                int iD = mzVarB.d();
                for (int i = 0; i < iD; i++) {
                    String strA = mzVarB.a(i);
                    String strB = mzVarB.b(i);
                    if ("Date".equalsIgnoreCase(strA)) {
                        this.b = og.c(strB);
                        this.e = strB;
                    } else if ("Expires".equalsIgnoreCase(strA)) {
                        this.j = og.c(strB);
                    } else if ("Last-Modified".equalsIgnoreCase(strA)) {
                        this.f95922g = og.c(strB);
                        this.i = strB;
                    } else if ("ETag".equalsIgnoreCase(strA)) {
                        this.k = strB;
                    } else if ("Age".equalsIgnoreCase(strA)) {
                        this.o = oh.d(strB, -1);
                    }
                }
            }
        }
    }

    public nr(nj njVar, nh nhVar) {
        this.b = njVar;
        this.a = nhVar;
    }

    /* JADX WARN: Code restructure failed: missing block: B:31:0x0056, code lost:
    
        if (r3.i().d() == false) goto L32;
     */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public static boolean b(com.facetec.sdk.nh r3, com.facetec.sdk.nj r4) {
        /*
            int r0 = r3.d()
            r1 = 200(0xc8, float:2.8E-43)
            r2 = 0
            if (r0 == r1) goto L59
            r1 = 410(0x19a, float:5.75E-43)
            if (r0 == r1) goto L59
            r1 = 414(0x19e, float:5.8E-43)
            if (r0 == r1) goto L59
            r1 = 501(0x1f5, float:7.02E-43)
            if (r0 == r1) goto L59
            r1 = 203(0xcb, float:2.84E-43)
            if (r0 == r1) goto L59
            r1 = 204(0xcc, float:2.86E-43)
            if (r0 == r1) goto L59
            r1 = 307(0x133, float:4.3E-43)
            if (r0 == r1) goto L31
            r1 = 308(0x134, float:4.32E-43)
            if (r0 == r1) goto L59
            r1 = 404(0x194, float:5.66E-43)
            if (r0 == r1) goto L59
            r1 = 405(0x195, float:5.68E-43)
            if (r0 == r1) goto L59
            switch(r0) {
                case 300: goto L59;
                case 301: goto L59;
                case 302: goto L31;
                default: goto L30;
            }
        L30:
            goto L58
        L31:
            java.lang.String r0 = "Expires"
            java.lang.String r0 = r3.a(r0)
            if (r0 != 0) goto L59
            com.facetec.sdk.mo r0 = r3.i()
            int r0 = r0.a()
            r1 = -1
            if (r0 != r1) goto L59
            com.facetec.sdk.mo r0 = r3.i()
            boolean r0 = r0.e()
            if (r0 != 0) goto L59
            com.facetec.sdk.mo r0 = r3.i()
            boolean r0 = r0.d()
            if (r0 != 0) goto L59
        L58:
            return r2
        L59:
            com.facetec.sdk.mo r3 = r3.i()
            boolean r3 = r3.c()
            if (r3 != 0) goto L6f
            com.facetec.sdk.mo r3 = r4.i()
            boolean r3 = r3.c()
            if (r3 != 0) goto L6f
            r3 = 1
            return r3
        L6f:
            return r2
        */
        throw new UnsupportedOperationException("Method not decompiled: com.facetec.sdk.nr.b(com.facetec.sdk.nh, com.facetec.sdk.nj):boolean");
    }
}