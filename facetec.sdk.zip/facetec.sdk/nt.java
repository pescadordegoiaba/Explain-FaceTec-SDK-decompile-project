package com.facetec.sdk;

import ai.luciq.library.networkv2.request.Header;
import android.os.Process;
import android.os.SystemClock;
import android.text.TextUtils;
import android.view.KeyEvent;
import android.view.View;
import android.view.ViewConfiguration;
import java.lang.reflect.Method;
import net.sf.scuba.smartcards.ISO7816;
import org.jmrtd.PassportService;

/* JADX INFO: loaded from: classes4.dex */
public final class nt implements ne {
    private static final byte[] $$a = null;
    private static final int $$b = 0;
    private static char a;
    private static char b;
    private static char c;
    private static char e;
    private nw d;

    /* JADX WARN: Removed duplicated region for block: B:10:0x0028  */
    /* JADX WARN: Removed duplicated region for block: B:8:0x0022  */
    /* JADX WARN: Unsupported multi-entry loop pattern (BACK_EDGE: B:10:0x0028 -> B:11:0x0031). Please report as a decompilation issue!!! */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    private static java.lang.String $$c(short r6, short r7, int r8) {
        /*
            int r6 = r6 + 4
            int r8 = r8 * 4
            int r0 = 1 - r8
            int r7 = r7 * 4
            int r7 = 112 - r7
            byte[] r1 = com.facetec.sdk.nt.$$a
            byte[] r0 = new byte[r0]
            r2 = 0
            int r8 = 0 - r8
            if (r1 != 0) goto L17
            r3 = r1
            r4 = r2
            r1 = r6
            goto L31
        L17:
            r3 = r7
            r7 = r6
            r6 = r3
            r3 = r2
        L1b:
            int r7 = r7 + 1
            byte r4 = (byte) r6
            r0[r3] = r4
            if (r3 != r8) goto L28
            java.lang.String r6 = new java.lang.String
            r6.<init>(r0, r2)
            return r6
        L28:
            r4 = r1[r7]
            int r3 = r3 + 1
            r5 = r1
            r1 = r7
            r7 = r4
            r4 = r3
            r3 = r5
        L31:
            int r6 = r6 + r7
            r7 = r1
            r1 = r3
            r3 = r4
            goto L1b
        */
        throw new UnsupportedOperationException("Method not decompiled: com.facetec.sdk.nt.$$c(short, short, int):java.lang.String");
    }

    static {
        init$0();
        b = (char) 16865;
        a = (char) 47282;
        c = (char) 62766;
        e = (char) 3716;
    }

    public nt(nw nwVar) {
        this.d = nwVar;
    }

    private static nh e(nh nhVar) {
        return (nhVar == null || nhVar.e() == null) ? nhVar : nhVar.f().b((no) null).a();
    }

    private static void f(String str, int i, Object[] objArr) throws Throwable {
        int i2;
        char[] charArray = str != null ? str.toCharArray() : str;
        hq hqVar = new hq();
        char[] cArr = new char[charArray.length];
        hqVar.d = 0;
        int i3 = 2;
        char[] cArr2 = new char[2];
        while (true) {
            int i4 = hqVar.d;
            if (i4 >= charArray.length) {
                objArr[0] = new String(cArr, 0, i);
                return;
            }
            cArr2[0] = charArray[i4];
            char c2 = 1;
            cArr2[1] = charArray[i4 + 1];
            int i5 = 58224;
            int i6 = 0;
            while (i6 < 16) {
                char c3 = cArr2[c2];
                char c4 = cArr2[0];
                char c5 = c2;
                int i7 = (c4 + i5) ^ ((c4 << 4) + ((char) (((long) c) ^ (-5528393735828501205L))));
                int i8 = c4 >>> 5;
                try {
                    Object[] objArr2 = new Object[4];
                    objArr2[3] = Integer.valueOf(e);
                    objArr2[i3] = Integer.valueOf(i8);
                    objArr2[c5] = Integer.valueOf(i7);
                    objArr2[0] = Integer.valueOf(c3);
                    Object objD = an.d(681770103);
                    Class cls = Integer.TYPE;
                    if (objD == null) {
                        i2 = 681770103;
                        objD = an.d(357 - (ViewConfiguration.getMinimumFlingVelocity() >> 16), (char) (KeyEvent.getMaxKeyCode() >> 16), 24 - View.resolveSize(0, 0), 1589849900, false, "s", new Class[]{cls, cls, cls, cls});
                    } else {
                        i2 = 681770103;
                    }
                    char cCharValue = ((Character) ((Method) objD).invoke(null, objArr2)).charValue();
                    cArr2[c5] = cCharValue;
                    char c6 = cArr2[0];
                    int i9 = i3;
                    int i10 = (cCharValue + i5) ^ ((cCharValue << 4) + ((char) (((long) b) ^ (-5528393735828501205L))));
                    int i11 = cCharValue >>> 5;
                    Object[] objArr3 = new Object[4];
                    objArr3[3] = Integer.valueOf(a);
                    objArr3[i9] = Integer.valueOf(i11);
                    objArr3[c5] = Integer.valueOf(i10);
                    objArr3[0] = Integer.valueOf(c6);
                    Object objD2 = an.d(i2);
                    if (objD2 == null) {
                        objD2 = an.d(357 - TextUtils.indexOf("", ""), (char) ((SystemClock.currentThreadTimeMillis() > (-1L) ? 1 : (SystemClock.currentThreadTimeMillis() == (-1L) ? 0 : -1)) - 1), KeyEvent.getDeadChar(0, 0) + 24, 1589849900, false, "s", new Class[]{cls, cls, cls, cls});
                    }
                    cArr2[0] = ((Character) ((Method) objD2).invoke(null, objArr3)).charValue();
                    i5 -= 40503;
                    i6++;
                    c2 = c5;
                    i3 = i9;
                } catch (Throwable th) {
                    Throwable cause = th.getCause();
                    if (cause == null) {
                        throw th;
                    }
                    throw cause;
                }
            }
            int i12 = i3;
            char c7 = c2;
            int i13 = hqVar.d;
            cArr[i13] = cArr2[0];
            cArr[i13 + 1] = cArr2[c7];
            i3 = i12;
            Object[] objArr4 = new Object[i3];
            objArr4[c7] = hqVar;
            objArr4[0] = hqVar;
            Object objD3 = an.d(227457195);
            if (objD3 == null) {
                byte b2 = (byte) (-1);
                byte b3 = (byte) (b2 + 1);
                objD3 = an.d(1826 - TextUtils.lastIndexOf("", '0'), (char) ((Process.getElapsedCpuTime() > 0L ? 1 : (Process.getElapsedCpuTime() == 0L ? 0 : -1)) - 1), 24 - (ViewConfiguration.getJumpTapTimeout() >> 16), 2079288304, false, $$c(b2, b3, b3), new Class[]{Object.class, Object.class});
            }
            ((Method) objD3).invoke(null, objArr4);
        }
    }

    public static void init$0() {
        $$a = new byte[]{PassportService.SFI_DG15, ISO7816.INS_READ_RECORD_STAMPED, 84, -51};
        $$b = 66;
    }

    /* JADX WARN: Removed duplicated region for block: B:103:0x0244  */
    /* JADX WARN: Removed duplicated region for block: B:122:0x02e6  */
    /* JADX WARN: Removed duplicated region for block: B:124:0x02f7  */
    /* JADX WARN: Removed duplicated region for block: B:46:0x012b  */
    /* JADX WARN: Removed duplicated region for block: B:91:0x01f9  */
    /* JADX WARN: Type inference failed for: r11v0 */
    /* JADX WARN: Type inference failed for: r11v28 */
    /* JADX WARN: Type inference failed for: r11v29 */
    /* JADX WARN: Type inference failed for: r11v35, types: [com.facetec.sdk.nh, com.facetec.sdk.nj] */
    /* JADX WARN: Type inference failed for: r11v38 */
    @Override // com.facetec.sdk.ne
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public final com.facetec.sdk.nh c(com.facetec.sdk.ne.c r25) throws java.lang.Throwable {
        /*
            Method dump skipped, instruction units count: 1124
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: com.facetec.sdk.nt.c(com.facetec.sdk.ne$c):com.facetec.sdk.nh");
    }

    private static boolean e(String str) {
        return (Header.CONNECTION.equalsIgnoreCase(str) || "Keep-Alive".equalsIgnoreCase(str) || "Proxy-Authenticate".equalsIgnoreCase(str) || "Proxy-Authorization".equalsIgnoreCase(str) || "TE".equalsIgnoreCase(str) || "Trailers".equalsIgnoreCase(str) || "Transfer-Encoding".equalsIgnoreCase(str) || "Upgrade".equalsIgnoreCase(str)) ? false : true;
    }

    private static boolean c(String str) {
        return "Content-Length".equalsIgnoreCase(str) || Header.CONTENT_ENCODING.equalsIgnoreCase(str) || Header.CONTENT_TYPE.equalsIgnoreCase(str);
    }
}