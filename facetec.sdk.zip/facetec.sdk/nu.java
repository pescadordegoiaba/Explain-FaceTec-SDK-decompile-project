package com.facetec.sdk;

import ai.luciq.library.networkv2.request.Constants;
import android.graphics.Color;
import android.media.AudioTrack;
import android.os.Process;
import android.os.SystemClock;
import android.text.AndroidCharacter;
import android.text.TextUtils;
import android.util.TypedValue;
import android.view.View;
import android.view.ViewConfiguration;
import com.facetec.sdk.mz;
import com.incode.welcome_sdk.modules.SelfieScan;
import com.plaid.internal.EnumC41897g;
import java.io.Closeable;
import java.io.IOException;
import java.io.InterruptedIOException;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.net.IDN;
import java.net.InetAddress;
import java.net.Socket;
import java.nio.charset.Charset;
import java.security.GeneralSecurityException;
import java.security.KeyStore;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.TimeZone;
import java.util.concurrent.ThreadFactory;
import java.util.concurrent.TimeUnit;
import java.util.regex.Pattern;
import javax.net.ssl.TrustManager;
import javax.net.ssl.TrustManagerFactory;
import javax.net.ssl.X509TrustManager;
import net.sf.scuba.smartcards.ISO7816;
import org.bouncycastle.i18n.LocalizedMessage;

/* JADX INFO: loaded from: classes4.dex */
public final class nu {
    private static final byte[] $$a = null;
    private static final int $$b = 0;
    public static final String[] a;
    public static final no b;
    public static final byte[] c;
    public static final TimeZone d;
    public static final Charset e;
    private static final qb f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public static final Comparator<String> f95924g;
    private static final qb h;
    private static final qb i;
    private static final qb j;
    private static final qb k;
    private static final Charset l;
    private static final Charset m;
    private static final Charset n;
    private static final Charset o;
    private static final Method q;
    private static int[] r;
    private static final Pattern t;

    /* JADX WARN: Removed duplicated region for block: B:10:0x0026  */
    /* JADX WARN: Removed duplicated region for block: B:8:0x0020  */
    /* JADX WARN: Unsupported multi-entry loop pattern (BACK_EDGE: B:10:0x0026 -> B:11:0x002f). Please report as a decompilation issue!!! */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    private static java.lang.String $$c(int r6, int r7, int r8) {
        /*
            int r8 = r8 * 2
            int r0 = 1 - r8
            int r6 = r6 * 2
            int r6 = r6 + 119
            byte[] r1 = com.facetec.sdk.nu.$$a
            int r7 = r7 + 4
            byte[] r0 = new byte[r0]
            r2 = 0
            int r8 = 0 - r8
            if (r1 != 0) goto L18
            r6 = r8
            r3 = r1
            r4 = r2
            r1 = r7
            goto L2f
        L18:
            r3 = r2
        L19:
            int r7 = r7 + 1
            byte r4 = (byte) r6
            r0[r3] = r4
            if (r3 != r8) goto L26
            java.lang.String r6 = new java.lang.String
            r6.<init>(r0, r2)
            return r6
        L26:
            int r3 = r3 + 1
            r4 = r1[r7]
            r5 = r1
            r1 = r7
            r7 = r4
            r4 = r3
            r3 = r5
        L2f:
            int r7 = -r7
            int r6 = r6 + r7
            r7 = r1
            r1 = r3
            r3 = r4
            goto L19
        */
        throw new UnsupportedOperationException("Method not decompiled: com.facetec.sdk.nu.$$c(int, int, int):java.lang.String");
    }

    static {
        init$0();
        a();
        byte[] bArr = new byte[0];
        c = bArr;
        a = new String[0];
        px pxVarB = new px().d(bArr);
        long length = bArr.length;
        if (pxVarB == null) {
            throw new NullPointerException("source == null");
        }
        Method declaredMethod = null;
        b = new no(0 == true ? 1 : 0, length, pxVarB) { // from class: com.facetec.sdk.no.4
            private /* synthetic */ long a;
            private /* synthetic */ pz b;
            private /* synthetic */ nb c = null;

            public AnonymousClass4(nb nbVar, long length2, pz pxVarB2) {
                this.a = length2;
                this.b = pxVarB2;
            }

            @Override // com.facetec.sdk.no
            public final pz c() {
                return this.b;
            }

            @Override // com.facetec.sdk.no
            public final nb d() {
                return this.c;
            }

            @Override // com.facetec.sdk.no
            public final long e() {
                return this.a;
            }
        };
        ni.d(null, bArr);
        i = qb.e("efbbbf");
        h = qb.e("feff");
        f = qb.e("fffe");
        j = qb.e("0000ffff");
        k = qb.e("ffff0000");
        e = Charset.forName(Constants.UTF_8);
        Charset.forName(LocalizedMessage.DEFAULT_ENCODING);
        o = Charset.forName("UTF-16BE");
        m = Charset.forName("UTF-16LE");
        n = Charset.forName("UTF-32BE");
        l = Charset.forName("UTF-32LE");
        d = TimeZone.getTimeZone("GMT");
        f95924g = new Comparator<String>() { // from class: com.facetec.sdk.nu.5
            @Override // java.util.Comparator
            public final /* synthetic */ int compare(String str, String str2) {
                return str.compareTo(str2);
            }
        };
        try {
            declaredMethod = Throwable.class.getDeclaredMethod("addSuppressed", Throwable.class);
        } catch (Exception unused) {
        }
        q = declaredMethod;
        t = Pattern.compile("([0-9a-fA-F]*:[0-9a-fA-F:.]*)|([\\d.]+)");
    }

    public static void a(Throwable th, Throwable th2) {
        Method method = q;
        if (method != null) {
            try {
                method.invoke(th, th2);
            } catch (IllegalAccessException | InvocationTargetException unused) {
            }
        }
    }

    public static boolean b(ql qlVar, int i2, TimeUnit timeUnit) throws Throwable {
        try {
            Object[] objArr = new Object[1];
            p(new int[]{-1263351806, -1226012946, -620570080, 567936685, 610802681, -12093101, -993067800, -1554627170}, (SystemClock.uptimeMillis() > 0L ? 1 : (SystemClock.uptimeMillis() == 0L ? 0 : -1)) + 15, objArr);
            Class<?> cls = Class.forName((String) objArr[0]);
            Object[] objArr2 = new Object[1];
            p(new int[]{1943327750, -1943607797, 1748312290, 1411399591}, 8 - TextUtils.getTrimmedLength(""), objArr2);
            long jLongValue = ((Long) cls.getMethod((String) objArr2[0], null).invoke(null, null)).longValue();
            long jE_ = qlVar.a().b_() ? qlVar.a().e_() - jLongValue : Long.MAX_VALUE;
            qlVar.a().d(Math.min(jE_, timeUnit.toNanos(i2)) + jLongValue);
            try {
                px pxVar = new px();
                while (qlVar.e(pxVar, 8192L) != -1) {
                    pxVar.q();
                }
                if (jE_ == Long.MAX_VALUE) {
                    qlVar.a().d_();
                } else {
                    qlVar.a().d(jLongValue + jE_);
                }
                return true;
            } catch (InterruptedIOException unused) {
                if (jE_ == Long.MAX_VALUE) {
                    qlVar.a().d_();
                } else {
                    qlVar.a().d(jLongValue + jE_);
                }
                return false;
            } catch (Throwable th) {
                if (jE_ == Long.MAX_VALUE) {
                    qlVar.a().d_();
                    throw th;
                }
                qlVar.a().d(jLongValue + jE_);
                throw th;
            }
        } catch (Throwable th2) {
            Throwable cause = th2.getCause();
            if (cause != null) {
                throw cause;
            }
            throw th2;
        }
    }

    public static String[] c(String[] strArr, String str) {
        int length = strArr.length;
        String[] strArr2 = new String[length + 1];
        try {
            Object[] objArr = {strArr, 0, strArr2, 0, Integer.valueOf(strArr.length)};
            Object[] objArr2 = new Object[1];
            p(new int[]{-1263351806, -1226012946, -620570080, 567936685, 610802681, -12093101, -993067800, -1554627170}, (AudioTrack.getMinVolume() > SelfieScan.RECOGNITION_FAIL_RESULT ? 1 : (AudioTrack.getMinVolume() == SelfieScan.RECOGNITION_FAIL_RESULT ? 0 : -1)) + 16, objArr2);
            Class<?> cls = Class.forName((String) objArr2[0]);
            Object[] objArr3 = new Object[1];
            p(new int[]{-1573241097, -617320210, 805285260, 877298219, -1913459200, 2044715568}, (ViewConfiguration.getMaximumFlingVelocity() >> 16) + 9, objArr3);
            String str2 = (String) objArr3[0];
            Class cls2 = Integer.TYPE;
            cls.getMethod(str2, Object.class, cls2, Object.class, cls2, cls2).invoke(null, objArr);
            strArr2[length] = str;
            return strArr2;
        } catch (Throwable th) {
            Throwable cause = th.getCause();
            if (cause != null) {
                throw cause;
            }
            throw th;
        }
    }

    public static int d(char c2) {
        if (c2 >= '0' && c2 <= '9') {
            return c2 - '0';
        }
        if (c2 >= 'a' && c2 <= 'f') {
            return c2 - 'W';
        }
        if (c2 < 'A' || c2 > 'F') {
            return -1;
        }
        return c2 - '7';
    }

    public static void e(long j2, long j3, long j4) {
        if (j4 < 0 || 0 > j2 || j2 < j4) {
            throw new ArrayIndexOutOfBoundsException();
        }
    }

    public static void init$0() {
        $$a = new byte[]{5, -4, ISO7816.INS_READ_BINARY, 1};
        $$b = EnumC41897g.SDK_ASSET_ICON_ARROW_UP_VALUE;
    }

    private static void p(int[] iArr, int i2, Object[] objArr) throws Throwable {
        int i3;
        char c2;
        char[] cArr;
        int i4;
        int i5;
        hg hgVar = new hg();
        char[] cArr2 = new char[4];
        int i6 = 2;
        char[] cArr3 = new char[iArr.length * 2];
        int[] iArr2 = r;
        Class cls = Integer.TYPE;
        int i7 = 0;
        if (iArr2 != null) {
            int length = iArr2.length;
            int[] iArr3 = new int[length];
            int i8 = 0;
            i3 = 2027942060;
            while (i8 < length) {
                try {
                    Object[] objArr2 = {Integer.valueOf(iArr2[i8])};
                    Object objD = an.d(2027942060);
                    if (objD == null) {
                        int iMyTid = 23 - (Process.myTid() >> 22);
                        i4 = i6;
                        byte b2 = $$a[3];
                        byte b3 = (byte) (-b2);
                        i5 = i7;
                        objD = an.d(617 - Color.alpha(i7), (char) ((SystemClock.elapsedRealtime() > 0L ? 1 : (SystemClock.elapsedRealtime() == 0L ? 0 : -1)) - 1), iMyTid, 247342071, false, $$c(b2, b3, (byte) (b3 + 1)), new Class[]{cls});
                    } else {
                        i4 = i6;
                        i5 = i7;
                    }
                    iArr3[i8] = ((Integer) ((Method) objD).invoke(null, objArr2)).intValue();
                    i8++;
                    i6 = i4;
                    i7 = i5;
                } catch (Throwable th) {
                    Throwable cause = th.getCause();
                    if (cause == null) {
                        throw th;
                    }
                    throw cause;
                }
            }
            iArr2 = iArr3;
        } else {
            i3 = 2027942060;
        }
        int i9 = i6;
        int i10 = i7;
        int length2 = iArr2.length;
        int[] iArr4 = new int[length2];
        int[] iArr5 = r;
        char c3 = '0';
        if (iArr5 != null) {
            int length3 = iArr5.length;
            int[] iArr6 = new int[length3];
            int i11 = i10;
            while (i11 < length3) {
                Object[] objArr3 = {Integer.valueOf(iArr5[i11])};
                Object objD2 = an.d(i3);
                if (objD2 == null) {
                    int i12 = 618 - (SystemClock.elapsedRealtimeNanos() > 0L ? 1 : (SystemClock.elapsedRealtimeNanos() == 0L ? 0 : -1));
                    char cAlpha = (char) Color.alpha(i10);
                    int mirror = AndroidCharacter.getMirror(c3) - 25;
                    byte b4 = $$a[3];
                    byte b5 = (byte) (-b4);
                    cArr = cArr2;
                    objD2 = an.d(i12, cAlpha, mirror, 247342071, false, $$c(b4, b5, (byte) (b5 + 1)), new Class[]{cls});
                } else {
                    cArr = cArr2;
                }
                iArr6[i11] = ((Integer) ((Method) objD2).invoke(null, objArr3)).intValue();
                i11++;
                cArr2 = cArr;
                c3 = '0';
            }
            iArr5 = iArr6;
        }
        char[] cArr4 = cArr2;
        int i13 = i10;
        System.arraycopy(iArr5, i13, iArr4, i13, length2);
        hgVar.c = i13;
        while (true) {
            int i14 = hgVar.c;
            if (i14 >= iArr.length) {
                objArr[0] = new String(cArr3, 0, i2);
                return;
            }
            int i15 = iArr[i14];
            char c4 = (char) (i15 >> 16);
            cArr4[i13] = c4;
            char c5 = (char) i15;
            char c6 = 1;
            cArr4[1] = c5;
            char c7 = (char) (iArr[i14 + 1] >> 16);
            cArr4[i9] = c7;
            char c8 = (char) iArr[i14 + 1];
            cArr4[3] = c8;
            hgVar.d = (c4 << 16) + c5;
            hgVar.a = (c7 << 16) + c8;
            hg.a(iArr4);
            int i16 = 0;
            while (i16 < 16) {
                int i17 = hgVar.d ^ iArr4[i16];
                hgVar.d = i17;
                int iB = hg.b(i17);
                Object[] objArr4 = new Object[4];
                objArr4[3] = hgVar;
                objArr4[i9] = hgVar;
                objArr4[c6] = Integer.valueOf(iB);
                objArr4[0] = hgVar;
                Object objD3 = an.d(-1264699187);
                if (objD3 == null) {
                    int i18 = 1558 - (TypedValue.complexToFloat(0) > SelfieScan.RECOGNITION_FAIL_RESULT ? 1 : (TypedValue.complexToFloat(0) == SelfieScan.RECOGNITION_FAIL_RESULT ? 0 : -1));
                    char cIndexOf = (char) (TextUtils.indexOf((CharSequence) "", '0') + 63318);
                    int tapTimeout = 32 - (ViewConfiguration.getTapTimeout() >> 16);
                    byte b6 = $$a[3];
                    byte b7 = (byte) (b6 - 1);
                    byte b8 = (byte) (-b6);
                    c2 = c6;
                    objD3 = an.d(i18, cIndexOf, tapTimeout, -1023415402, false, $$c(b7, b8, (byte) (b8 + 1)), new Class[]{Object.class, cls, Object.class, Object.class});
                } else {
                    c2 = c6;
                }
                int iIntValue = ((Integer) ((Method) objD3).invoke(null, objArr4)).intValue();
                hgVar.d = hgVar.a;
                hgVar.a = iIntValue;
                i16++;
                c6 = c2;
            }
            char c9 = c6;
            int i19 = hgVar.d;
            int i20 = hgVar.a;
            hgVar.d = i20;
            hgVar.a = i19;
            int i21 = i19 ^ iArr4[16];
            hgVar.a = i21;
            int i22 = i20 ^ iArr4[17];
            hgVar.d = i22;
            cArr4[0] = (char) (i22 >>> 16);
            cArr4[c9] = (char) i22;
            cArr4[i9] = (char) (i21 >>> 16);
            cArr4[3] = (char) i21;
            hg.a(iArr4);
            int i23 = hgVar.c;
            cArr3[i23 * 2] = cArr4[0];
            cArr3[(i23 * 2) + 1] = cArr4[c9];
            cArr3[(i23 * 2) + 2] = cArr4[i9];
            cArr3[(i23 * 2) + 3] = cArr4[3];
            int i24 = i9;
            Object[] objArr5 = new Object[i24];
            objArr5[c9] = hgVar;
            objArr5[0] = hgVar;
            Object objD4 = an.d(-204410541);
            if (objD4 == null) {
                objD4 = an.d(310 - View.MeasureSpec.makeMeasureSpec(0, 0), (char) (ViewConfiguration.getDoubleTapTimeout() >> 16), 24 - (ViewConfiguration.getZoomControlsTimeout() > 0L ? 1 : (ViewConfiguration.getZoomControlsTimeout() == 0L ? 0 : -1)), -2051988984, false, "A", new Class[]{Object.class, Object.class});
            }
            ((Method) objD4).invoke(null, objArr5);
            i9 = i24;
            i13 = 0;
        }
    }

    public static void d(Closeable closeable) {
        if (closeable != null) {
            try {
                closeable.close();
            } catch (RuntimeException e2) {
                throw e2;
            } catch (Exception unused) {
            }
        }
    }

    public static <T> List<T> e(List<T> list) {
        return Collections.unmodifiableList(new ArrayList(list));
    }

    public static boolean a(Object obj, Object obj2) {
        if (obj != obj2) {
            return obj != null && obj.equals(obj2);
        }
        return true;
    }

    public static boolean e(AssertionError assertionError) {
        return (assertionError.getCause() == null || assertionError.getMessage() == null || !assertionError.getMessage().contains("getsockname failed")) ? false : true;
    }

    public static String[] a(Comparator<? super String> comparator, String[] strArr, String[] strArr2) {
        ArrayList arrayList = new ArrayList();
        for (String str : strArr) {
            int length = strArr2.length;
            int i2 = 0;
            while (true) {
                if (i2 >= length) {
                    break;
                }
                if (comparator.compare(str, strArr2[i2]) == 0) {
                    arrayList.add(str);
                    break;
                }
                i2++;
            }
        }
        return (String[]) arrayList.toArray(new String[arrayList.size()]);
    }

    public static void d(Socket socket) {
        if (socket != null) {
            try {
                socket.close();
            } catch (AssertionError e2) {
                if (!e(e2)) {
                    throw e2;
                }
            } catch (RuntimeException e3) {
                if (!"bio == null".equals(e3.getMessage())) {
                    throw e3;
                }
            } catch (Exception unused) {
            }
        }
    }

    public static int c(String str, int i2, int i3) {
        while (i2 < i3) {
            char cCharAt = str.charAt(i2);
            if (cCharAt != '\t' && cCharAt != '\n' && cCharAt != '\f' && cCharAt != '\r' && cCharAt != ' ') {
                return i2;
            }
            i2++;
        }
        return i3;
    }

    public static int e(Comparator<String> comparator, String[] strArr, String str) {
        int length = strArr.length;
        for (int i2 = 0; i2 < length; i2++) {
            if (comparator.compare(strArr[i2], str) == 0) {
                return i2;
            }
        }
        return -1;
    }

    public static Charset c(pz pzVar, Charset charset) {
        if (pzVar.c(i)) {
            pzVar.f(r0.h());
            return e;
        }
        if (pzVar.c(h)) {
            pzVar.f(r0.h());
            return o;
        }
        if (pzVar.c(f)) {
            pzVar.f(r0.h());
            return m;
        }
        if (pzVar.c(j)) {
            pzVar.f(r0.h());
            return n;
        }
        if (!pzVar.c(k)) {
            return charset;
        }
        pzVar.f(r0.h());
        return l;
    }

    public static String e(String str, int i2, int i3) {
        int iC = c(str, i2, i3);
        return str.substring(iC, a(str, iC, i3));
    }

    public static boolean d(ql qlVar, TimeUnit timeUnit) {
        try {
            return b(qlVar, 100, timeUnit);
        } catch (IOException unused) {
            return false;
        }
    }

    public static ThreadFactory d(final String str, final boolean z) {
        return new ThreadFactory() { // from class: com.facetec.sdk.nu.3
            @Override // java.util.concurrent.ThreadFactory
            public final Thread newThread(Runnable runnable) {
                Thread thread = new Thread(runnable, str);
                thread.setDaemon(z);
                return thread;
            }
        };
    }

    public static int a(String str, int i2, int i3) {
        while (true) {
            i3--;
            if (i3 < i2) {
                return i2;
            }
            char cCharAt = str.charAt(i3);
            if (cCharAt != '\t' && cCharAt != '\n' && cCharAt != '\f' && cCharAt != '\r' && cCharAt != ' ') {
                return i3 + 1;
            }
        }
    }

    public static boolean d(Comparator<String> comparator, String[] strArr, String[] strArr2) {
        if (strArr != null && strArr2 != null && strArr.length != 0 && strArr2.length != 0) {
            for (String str : strArr) {
                for (String str2 : strArr2) {
                    if (comparator.compare(str, str2) == 0) {
                        return true;
                    }
                }
            }
        }
        return false;
    }

    public static int e(String str, int i2, int i3, String str2) {
        while (i2 < i3) {
            if (str2.indexOf(str.charAt(i2)) != -1) {
                return i2;
            }
            i2++;
        }
        return i3;
    }

    public static int a(String str, int i2, int i3, char c2) {
        while (i2 < i3) {
            if (str.charAt(i2) == c2) {
                return i2;
            }
            i2++;
        }
        return i3;
    }

    public static AssertionError e(String str, Exception exc) {
        AssertionError assertionError = new AssertionError(str);
        try {
            assertionError.initCause(exc);
        } catch (IllegalStateException unused) {
        }
        return assertionError;
    }

    public static int a(String str) {
        int length = str.length();
        for (int i2 = 0; i2 < length; i2++) {
            char cCharAt = str.charAt(i2);
            if (cCharAt <= 31 || cCharAt >= 127) {
                return i2;
            }
        }
        return -1;
    }

    public static void a() {
        r = new int[]{764981086, 1543526930, 888846410, -1178040063, 327668523, -1910483655, -1555997058, -1183156758, 393911371, -1470357355, -243614602, 475363322, -586209325, 369862950, 343534512, -343419237, -715103792, -1428615743};
    }

    public static boolean d(String str) {
        return t.matcher(str).matches();
    }

    public static <K, V> Map<K, V> b(Map<K, V> map) {
        if (map.isEmpty()) {
            return Collections.EMPTY_MAP;
        }
        return Collections.unmodifiableMap(new LinkedHashMap(map));
    }

    /* JADX WARN: Code restructure failed: missing block: B:15:0x0034, code lost:
    
        r18 = 1;
     */
    /* JADX WARN: Code restructure failed: missing block: B:49:0x00a1, code lost:
    
        if ((r12 - r10) != 0) goto L51;
     */
    /* JADX WARN: Code restructure failed: missing block: B:68:0x00f2, code lost:
    
        return null;
     */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    private static java.net.InetAddress d(java.lang.String r20, int r21, int r22) throws java.lang.Throwable {
        /*
            Method dump skipped, instruction units count: 418
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: com.facetec.sdk.nu.d(java.lang.String, int, int):java.net.InetAddress");
    }

    public static <T> List<T> b(T... tArr) {
        return Collections.unmodifiableList(Arrays.asList((Object[]) tArr.clone()));
    }

    public static String b(nc ncVar, boolean z) {
        String strG;
        if (ncVar.g().contains(Constants.SEPARATOR)) {
            StringBuilder sb = new StringBuilder("[");
            sb.append(ncVar.g());
            sb.append("]");
            strG = sb.toString();
        } else {
            strG = ncVar.g();
        }
        if (!z && ncVar.h() == nc.e(ncVar.e())) {
            return strG;
        }
        StringBuilder sb2 = new StringBuilder();
        sb2.append(strG);
        sb2.append(Constants.SEPARATOR);
        sb2.append(ncVar.h());
        return sb2.toString();
    }

    public static int c(String str, long j2, TimeUnit timeUnit) {
        if (timeUnit != null) {
            long millis = timeUnit.toMillis(60L);
            if (millis > 2147483647L) {
                StringBuilder sb = new StringBuilder();
                sb.append(str);
                sb.append(" too large.");
                throw new IllegalArgumentException(sb.toString());
            }
            if (millis != 0) {
                return (int) millis;
            }
            StringBuilder sb2 = new StringBuilder();
            sb2.append(str);
            sb2.append(" too small.");
            throw new IllegalArgumentException(sb2.toString());
        }
        throw new NullPointerException("unit == null");
    }

    public static String b(String str) throws Throwable {
        InetAddress inetAddressD;
        int i2 = -1;
        if (str.contains(Constants.SEPARATOR)) {
            if (str.startsWith("[") && str.endsWith("]")) {
                inetAddressD = d(str, 1, str.length() - 1);
            } else {
                inetAddressD = d(str, 0, str.length());
            }
            if (inetAddressD == null) {
                return null;
            }
            byte[] address = inetAddressD.getAddress();
            if (address.length == 16) {
                int i3 = 0;
                int i4 = 0;
                while (i3 < address.length) {
                    int i5 = i3;
                    while (i5 < 16 && address[i5] == 0 && address[i5 + 1] == 0) {
                        i5 += 2;
                    }
                    int i6 = i5 - i3;
                    if (i6 > i4 && i6 >= 4) {
                        i2 = i3;
                        i4 = i6;
                    }
                    i3 = i5 + 2;
                }
                px pxVar = new px();
                while (i < address.length) {
                    if (i == i2) {
                        pxVar.g(58);
                        i += i4;
                        if (i == 16) {
                            pxVar.g(58);
                        }
                    } else {
                        if (i > 0) {
                            pxVar.g(58);
                        }
                        pxVar.g(((address[i] & 255) << 8) | (address[i + 1] & 255));
                        i += 2;
                    }
                }
                return pxVar.m();
            }
            StringBuilder sb = new StringBuilder("Invalid IPv6 address: '");
            sb.append(str);
            sb.append("'");
            throw new AssertionError(sb.toString());
        }
        try {
            String lowerCase = IDN.toASCII(str).toLowerCase(Locale.US);
            if (lowerCase.isEmpty()) {
                return null;
            }
            while (i < lowerCase.length()) {
                char cCharAt = lowerCase.charAt(i);
                i = (cCharAt > 31 && cCharAt < 127 && " #%/:?@[\\]".indexOf(cCharAt) == -1) ? i + 1 : 0;
                return null;
            }
            return lowerCase;
        } catch (IllegalArgumentException unused) {
            return null;
        }
    }

    public static X509TrustManager d() {
        try {
            TrustManagerFactory trustManagerFactory = TrustManagerFactory.getInstance(TrustManagerFactory.getDefaultAlgorithm());
            trustManagerFactory.init((KeyStore) null);
            TrustManager[] trustManagers = trustManagerFactory.getTrustManagers();
            if (trustManagers.length == 1) {
                TrustManager trustManager = trustManagers[0];
                if (trustManager instanceof X509TrustManager) {
                    return (X509TrustManager) trustManager;
                }
            }
            StringBuilder sb = new StringBuilder("Unexpected default trust managers:");
            sb.append(Arrays.toString(trustManagers));
            throw new IllegalStateException(sb.toString());
        } catch (GeneralSecurityException e2) {
            throw e("No System TLS", e2);
        }
    }

    public static String b(String str, Object... objArr) {
        return String.format(Locale.US, str, objArr);
    }

    public static mz b(List<os> list) {
        mz.a aVar = new mz.a();
        for (os osVar : list) {
            nn.d.e(aVar, osVar.j.d(), osVar.f95935g.d());
        }
        return aVar.c();
    }
}