package com.facetec.sdk;

import java.io.Closeable;
import java.io.File;
import java.io.Flushable;
import java.io.IOException;
import java.util.LinkedHashMap;
import java.util.concurrent.Executor;
import java.util.regex.Pattern;

/* JADX INFO: loaded from: classes4.dex */
public final class nv implements Closeable, Flushable {
    private pu a;
    private long b;
    private long c;
    private ph d;
    private int e;
    private boolean f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    private boolean f95925g;
    private boolean h;
    private LinkedHashMap<String, a> i;
    private int j;
    private final Executor l;
    private final Runnable o;

    public final class a {
        final File[] a;
        final File[] b;
        boolean c;
        final String d;
        final long[] e;
        c i;
    }

    public final class c {
        boolean a;
        final /* synthetic */ nv d;
        final a e;
    }

    static {
        Pattern.compile("[a-z0-9_-]{1,120}");
    }

    private synchronized void a(c cVar) {
        try {
            a aVar = cVar.e;
            if (aVar.i != cVar) {
                throw new IllegalStateException();
            }
            for (int i = 0; i < this.e; i++) {
                this.d.a(aVar.b[i]);
            }
            this.j++;
            aVar.i = null;
            if (aVar.c) {
                aVar.c = true;
                this.a.a("CLEAN").g(32);
                this.a.a(aVar.d);
                pu puVar = this.a;
                for (long j : aVar.e) {
                    puVar.g(32).n(j);
                }
                this.a.g(10);
            } else {
                this.i.remove(aVar.d);
                this.a.a("REMOVE").g(32);
                this.a.a(aVar.d);
                this.a.g(10);
            }
            this.a.flush();
            if (this.b > this.c || e()) {
                this.l.execute(this.o);
            }
        } catch (Throwable th) {
            throw th;
        }
    }

    private boolean c(a aVar) {
        c cVar = aVar.i;
        if (cVar != null && cVar.e.i == cVar) {
            int i = 0;
            while (true) {
                nv nvVar = cVar.d;
                if (i >= nvVar.e) {
                    break;
                }
                try {
                    nvVar.d.a(cVar.e.b[i]);
                } catch (IOException unused) {
                }
                i++;
            }
            cVar.e.i = null;
        }
        for (int i2 = 0; i2 < this.e; i2++) {
            this.d.a(aVar.a[i2]);
            long j = this.b;
            long[] jArr = aVar.e;
            this.b = j - jArr[i2];
            jArr[i2] = 0;
        }
        this.j++;
        this.a.a("REMOVE").g(32).a(aVar.d).g(10);
        this.i.remove(aVar.d);
        if (e()) {
            this.l.execute(this.o);
        }
        return true;
    }

    private void d() {
        while (this.b > this.c) {
            c(this.i.values().iterator().next());
        }
        this.h = false;
    }

    private boolean e() {
        int i = this.j;
        return i >= 2000 && i >= this.i.size();
    }

    @Override // java.io.Closeable, java.lang.AutoCloseable
    public final synchronized void close() {
        try {
            if (this.f95925g && !this.f) {
                for (a aVar : (a[]) this.i.values().toArray(new a[this.i.size()])) {
                    c cVar = aVar.i;
                    if (cVar != null) {
                        synchronized (cVar.d) {
                            try {
                                if (cVar.a) {
                                    throw new IllegalStateException();
                                }
                                if (cVar.e.i == cVar) {
                                    cVar.d.a(cVar);
                                }
                                cVar.a = true;
                            } finally {
                            }
                        }
                    }
                }
                d();
                this.a.close();
                this.a = null;
                this.f = true;
                return;
            }
            this.f = true;
        } catch (Throwable th) {
            throw th;
        }
    }

    @Override // java.io.Flushable
    public final synchronized void flush() {
        if (this.f95925g) {
            a();
            d();
            this.a.flush();
        }
    }

    private synchronized boolean c() {
        return this.f;
    }

    private synchronized void a() {
        if (c()) {
            throw new IllegalStateException("cache is closed");
        }
    }
}