package com.facetec.sdk;

/* JADX INFO: loaded from: classes4.dex */
public interface nw {
    ns c();

    nh d();
}