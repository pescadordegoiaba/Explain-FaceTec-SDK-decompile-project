package com.facetec.sdk;

import ai.luciq.library.networkv2.request.Constants;
import android.graphics.Color;
import android.os.Process;
import android.telephony.cdma.CdmaCellLocation;
import android.text.AndroidCharacter;
import android.text.TextUtils;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.View;
import android.view.ViewConfiguration;
import android.widget.ExpandableListView;
import com.facetec.sdk.ov;
import com.incode.welcome_sdk.modules.SelfieScan;
import com.plaid.internal.EnumC41897g;
import java.io.IOException;
import java.lang.ref.Reference;
import java.lang.reflect.Method;
import java.net.ConnectException;
import java.net.Proxy;
import java.net.Socket;
import java.net.SocketException;
import java.net.SocketTimeoutException;
import java.security.cert.X509Certificate;
import java.util.ArrayList;
import java.util.List;
import javax.net.ssl.SSLPeerUnverifiedException;
import net.sf.scuba.smartcards.ISOFileInfo;
import org.bouncycastle.crypto.digests.Blake2xsDigest;
import org.jmrtd.PassportService;

/* JADX INFO: loaded from: classes4.dex */
public final class nx extends ov.e {
    private static final byte[] $$a = null;
    private static final int $$b = 0;
    private static char[] q;
    private static char s;
    mx a;
    final mv b;
    Socket c;
    Socket d;
    final nm e;
    public boolean f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    ov f95926g;
    pz h;
    ng i;
    pu j;
    public int l;
    public int o = 1;
    public final List<Reference<oe>> k = new ArrayList();
    public long n = Long.MAX_VALUE;

    private static String $$c(short s2, short s3, short s4) {
        int i = s3 + 4;
        byte[] bArr = $$a;
        int i2 = 116 - s4;
        int i3 = s2 * 4;
        byte[] bArr2 = new byte[1 - i3];
        int i4 = 0 - i3;
        int i5 = -1;
        if (bArr == null) {
            i2 = i4 + i2;
        }
        while (true) {
            i5++;
            i++;
            bArr2[i5] = (byte) i2;
            if (i5 == i4) {
                return new String(bArr2, 0);
            }
            i2 += bArr[i];
        }
    }

    static {
        init$0();
        q = new char[]{15095, 15080, 15093, 15076, 15072, 15087, 15085, 15061, 15078, 15058, 15084, 15086, 15096, 15023, 15083, 15090};
        s = (char) 3871;
    }

    public nx(mv mvVar, nm nmVar) {
        this.b = mvVar;
        this.e = nmVar;
    }

    public static void init$0() {
        $$a = new byte[]{106, -23, PassportService.SFI_DG12, ISOFileInfo.DATA_BYTES1};
        $$b = EnumC41897g.SDK_ASSET_HEADER_FINAL_SUCCESS_DARK_APPEARANCE_VALUE;
    }

    private static void p(String str, int i, byte b, Object[] objArr) throws Throwable {
        int i2;
        char c;
        char c2;
        char c3;
        char c4;
        char c5;
        int i3;
        char[] charArray = str != null ? str.toCharArray() : str;
        ho hoVar = new ho();
        char[] cArr = q;
        Class cls = Integer.TYPE;
        int i4 = -1584280535;
        int i5 = 0;
        if (cArr != null) {
            int length = cArr.length;
            char[] cArr2 = new char[length];
            int i6 = 0;
            while (i6 < length) {
                try {
                    Object[] objArr2 = {Integer.valueOf(cArr[i6])};
                    Object objD = an.d(i4);
                    if (objD == null) {
                        byte b2 = (byte) i5;
                        i3 = i4;
                        byte b3 = (byte) (b2 - 1);
                        objD = an.d(View.MeasureSpec.getMode(i5) + 2158, (char) Gravity.getAbsoluteGravity(i5, i5), (ViewConfiguration.getScrollFriction() > SelfieScan.RECOGNITION_FAIL_RESULT ? 1 : (ViewConfiguration.getScrollFriction() == SelfieScan.RECOGNITION_FAIL_RESULT ? 0 : -1)) + 22, -672129166, false, $$c(b2, b3, (byte) (b3 + 1)), new Class[]{cls});
                    } else {
                        i3 = i4;
                    }
                    cArr2[i6] = ((Character) ((Method) objD).invoke(null, objArr2)).charValue();
                    i6++;
                    i4 = i3;
                    i5 = 0;
                } catch (Throwable th) {
                    Throwable cause = th.getCause();
                    if (cause == null) {
                        throw th;
                    }
                    throw cause;
                }
            }
            cArr = cArr2;
        }
        int i7 = i4;
        Object[] objArr3 = {Integer.valueOf(s)};
        Object objD2 = an.d(i7);
        if (objD2 == null) {
            byte b4 = (byte) 0;
            byte b5 = (byte) (b4 - 1);
            objD2 = an.d(2158 - Gravity.getAbsoluteGravity(0, 0), (char) (CdmaCellLocation.convertQuartSecToDecDegrees(0) > 0.0d ? 1 : (CdmaCellLocation.convertQuartSecToDecDegrees(0) == 0.0d ? 0 : -1)), AndroidCharacter.getMirror('0') - 25, -672129166, false, $$c(b4, b5, (byte) (b5 + 1)), new Class[]{cls});
        }
        char cCharValue = ((Character) ((Method) objD2).invoke(null, objArr3)).charValue();
        char[] cArr3 = new char[i];
        if (i % 2 != 0) {
            i2 = i - 1;
            cArr3[i2] = (char) (charArray[i2] - b);
        } else {
            i2 = i;
        }
        char c6 = 1;
        if (i2 > 1) {
            hoVar.b = 0;
            while (true) {
                int i8 = hoVar.b;
                if (i8 >= i2) {
                    break;
                }
                char c7 = charArray[i8];
                hoVar.d = c7;
                char c8 = charArray[i8 + 1];
                hoVar.e = c8;
                if (c7 == c8) {
                    cArr3[i8] = (char) (c7 - b);
                    cArr3[i8 + 1] = (char) (c8 - b);
                    c = c6;
                } else {
                    Object[] objArr4 = new Object[13];
                    objArr4[12] = hoVar;
                    objArr4[11] = Integer.valueOf(cCharValue);
                    objArr4[10] = hoVar;
                    objArr4[9] = hoVar;
                    objArr4[8] = Integer.valueOf(cCharValue);
                    objArr4[7] = hoVar;
                    objArr4[6] = hoVar;
                    objArr4[5] = Integer.valueOf(cCharValue);
                    objArr4[4] = hoVar;
                    objArr4[3] = hoVar;
                    objArr4[2] = Integer.valueOf(cCharValue);
                    objArr4[c6] = hoVar;
                    objArr4[0] = hoVar;
                    Object objD3 = an.d(945118461);
                    if (objD3 == null) {
                        c = c6;
                        int maxKeyCode = 2356 - (KeyEvent.getMaxKeyCode() >> 16);
                        c2 = '\n';
                        char scrollDefaultDelay = (char) (ViewConfiguration.getScrollDefaultDelay() >> 16);
                        int maximumFlingVelocity = (ViewConfiguration.getMaximumFlingVelocity() >> 16) + 23;
                        c3 = 2;
                        c4 = '\t';
                        byte b6 = (byte) 0;
                        byte b7 = (byte) (b6 - 1);
                        c5 = 7;
                        String str$$c = $$c(b6, b7, (byte) (b7 + 3));
                        Class cls2 = Integer.TYPE;
                        objD3 = an.d(maxKeyCode, scrollDefaultDelay, maximumFlingVelocity, 1312067494, false, str$$c, new Class[]{Object.class, Object.class, cls2, Object.class, Object.class, cls2, Object.class, Object.class, cls2, Object.class, Object.class, cls2, Object.class});
                    } else {
                        c = c6;
                        c2 = '\n';
                        c3 = 2;
                        c4 = '\t';
                        c5 = 7;
                    }
                    int iIntValue = ((Integer) ((Method) objD3).invoke(null, objArr4)).intValue();
                    int i9 = hoVar.f95903g;
                    if (iIntValue == i9) {
                        Object[] objArr5 = new Object[11];
                        objArr5[c2] = hoVar;
                        objArr5[c4] = Integer.valueOf(cCharValue);
                        objArr5[8] = hoVar;
                        objArr5[c5] = Integer.valueOf(cCharValue);
                        objArr5[6] = Integer.valueOf(cCharValue);
                        objArr5[5] = hoVar;
                        objArr5[4] = hoVar;
                        objArr5[3] = Integer.valueOf(cCharValue);
                        objArr5[c3] = Integer.valueOf(cCharValue);
                        objArr5[c] = hoVar;
                        objArr5[0] = hoVar;
                        Object objD4 = an.d(-1909092408);
                        if (objD4 == null) {
                            int i10 = (ExpandableListView.getPackedPositionForGroup(0) > 0L ? 1 : (ExpandableListView.getPackedPositionForGroup(0) == 0L ? 0 : -1)) + 24;
                            byte b8 = (byte) 0;
                            byte b9 = (byte) (b8 - 1);
                            String str$$c2 = $$c(b8, b9, (byte) (b9 + 4));
                            Class cls3 = Integer.TYPE;
                            objD4 = an.d((ViewConfiguration.getScrollBarFadeDuration() >> 16) + 877, (char) ((Process.getElapsedCpuTime() > 0L ? 1 : (Process.getElapsedCpuTime() == 0L ? 0 : -1)) - 1), i10, -128689005, false, str$$c2, new Class[]{Object.class, Object.class, cls3, cls3, Object.class, Object.class, cls3, cls3, Object.class, cls3, Object.class});
                        }
                        int iIntValue2 = ((Integer) ((Method) objD4).invoke(null, objArr5)).intValue();
                        int i11 = (hoVar.a * cCharValue) + hoVar.f95903g;
                        int i12 = hoVar.b;
                        cArr3[i12] = cArr[iIntValue2];
                        cArr3[i12 + 1] = cArr[i11];
                    } else {
                        int i13 = hoVar.c;
                        int i14 = hoVar.a;
                        if (i13 == i14) {
                            int i15 = ((hoVar.j + cCharValue) - 1) % cCharValue;
                            hoVar.j = i15;
                            int i16 = ((i9 + cCharValue) - 1) % cCharValue;
                            hoVar.f95903g = i16;
                            int i17 = (i14 * cCharValue) + i16;
                            int i18 = hoVar.b;
                            cArr3[i18] = cArr[(i13 * cCharValue) + i15];
                            cArr3[i18 + 1] = cArr[i17];
                        } else {
                            int i19 = (i13 * cCharValue) + i9;
                            int i20 = (i14 * cCharValue) + hoVar.j;
                            int i21 = hoVar.b;
                            cArr3[i21] = cArr[i19];
                            cArr3[i21 + 1] = cArr[i20];
                        }
                    }
                }
                hoVar.b += 2;
                c6 = c;
            }
        }
        for (int i22 = 0; i22 < i; i22++) {
            cArr3[i22] = (char) (cArr3[i22] ^ 13722);
        }
        objArr[0] = new String(cArr3);
    }

    public final mx a() {
        return this.a;
    }

    public final boolean b(mh mhVar, nm nmVar) {
        if (this.k.size() >= this.o || this.f || !nn.d.c(this.e.d(), mhVar)) {
            return false;
        }
        if (mhVar.c().g().equals(b().d().c().g())) {
            return true;
        }
        if (this.f95926g == null || nmVar == null) {
            return false;
        }
        Proxy.Type type = nmVar.e().type();
        Proxy.Type type2 = Proxy.Type.DIRECT;
        if (type != type2 || this.e.e().type() != type2 || !this.e.a().equals(nmVar.a()) || nmVar.d().g() != pr.c || !d(mhVar.c())) {
            return false;
        }
        try {
            mhVar.f().b(mhVar.c().g(), a().d());
            return true;
        } catch (SSLPeerUnverifiedException unused) {
            return false;
        }
    }

    public final void c(int i) throws SocketException {
        this.c.setSoTimeout(0);
        ov.c cVar = new ov.c();
        Socket socket = this.c;
        String strG = this.e.d().c().g();
        pz pzVar = this.h;
        pu puVar = this.j;
        cVar.d = socket;
        cVar.a = strG;
        cVar.b = pzVar;
        cVar.c = puVar;
        cVar.e = this;
        cVar.f = i;
        ov ovVar = new ov(cVar);
        this.f95926g = ovVar;
        ovVar.o.c();
        ovVar.o.c(ovVar.k);
        if (ovVar.k.c() != 65535) {
            ovVar.o.d(0, r0 - Blake2xsDigest.UNKNOWN_DIGEST_LENGTH);
        }
        new Thread(ovVar.r).start();
    }

    public final void d(int i, int i2) throws IOException {
        Proxy proxyE = this.e.e();
        this.d = (proxyE.type() == Proxy.Type.DIRECT || proxyE.type() == Proxy.Type.HTTP) ? this.e.d().a.createSocket() : new Socket(proxyE);
        this.e.a();
        this.d.setSoTimeout(i2);
        try {
            pm.i().a(this.d, this.e.a(), i);
            try {
                this.h = qf.d(qf.e(this.d));
                this.j = qf.e(qf.c(this.d));
            } catch (NullPointerException e) {
                if ("throw with null exception".equals(e.getMessage())) {
                    throw new IOException(e);
                }
            }
        } catch (ConnectException e2) {
            StringBuilder sb = new StringBuilder("Failed to connect to ");
            sb.append(this.e.a());
            ConnectException connectException = new ConnectException(sb.toString());
            connectException.initCause(e2);
            throw connectException;
        }
    }

    @Override // com.facetec.sdk.ov.e
    public final void e(pa paVar) {
        paVar.b(or.REFUSED_STREAM);
    }

    public final String toString() {
        StringBuilder sb = new StringBuilder("Connection{");
        sb.append(this.e.d().c().g());
        sb.append(Constants.SEPARATOR);
        sb.append(this.e.d().c().h());
        sb.append(", proxy=");
        sb.append(this.e.e());
        sb.append(" hostAddress=");
        sb.append(this.e.a());
        sb.append(" cipherSuite=");
        mx mxVar = this.a;
        sb.append(mxVar != null ? mxVar.c : "none");
        sb.append(" protocol=");
        sb.append(this.i);
        sb.append('}');
        return sb.toString();
    }

    public final boolean e() {
        return this.f95926g != null;
    }

    public final nm b() {
        return this.e;
    }

    public final boolean b(boolean z) throws Throwable {
        if (this.c.isClosed() || this.c.isInputShutdown() || this.c.isOutputShutdown()) {
            return false;
        }
        ov ovVar = this.f95926g;
        if (ovVar == null) {
            if (z) {
                try {
                    int soTimeout = this.c.getSoTimeout();
                    try {
                        this.c.setSoTimeout(1);
                        return !this.h.b();
                    } finally {
                        this.c.setSoTimeout(soTimeout);
                    }
                } catch (SocketTimeoutException unused) {
                } catch (IOException unused2) {
                    return false;
                }
            }
            return true;
        }
        try {
            Object[] objArr = new Object[1];
            p("\f\u0006\u0004\b\u000e\u0005\u0005\u0006\t\f\b\r\u000e\u0003\u0002\u000b", 16 - ExpandableListView.getPackedPositionGroup(0L), (byte) (116 - Color.blue(0)), objArr);
            Class<?> cls = Class.forName((String) objArr[0]);
            Object[] objArr2 = new Object[1];
            p("\u0006\u0005\u0007\t\u0005\u0003\u000b\u0002", 7 - TextUtils.indexOf((CharSequence) "", '0'), (byte) ((ViewConfiguration.getTapTimeout() >> 16) + 4), objArr2);
            return ovVar.a(((Long) cls.getMethod((String) objArr2[0], null).invoke(null, null)).longValue());
        } catch (Throwable th) {
            Throwable cause = th.getCause();
            if (cause != null) {
                throw cause;
            }
            throw th;
        }
    }

    public final void c() {
        nu.d(this.d);
    }

    public final boolean d(nc ncVar) {
        if (ncVar.h() != this.e.d().c().h()) {
            return false;
        }
        if (ncVar.g().equals(this.e.d().c().g())) {
            return true;
        }
        return this.a != null && pr.c.a(ncVar.g(), (X509Certificate) this.a.d().get(0));
    }

    @Override // com.facetec.sdk.ov.e
    public final void b(ov ovVar) {
        synchronized (this.b) {
            this.o = ovVar.a();
        }
    }

    public final Socket d() {
        return this.c;
    }
}