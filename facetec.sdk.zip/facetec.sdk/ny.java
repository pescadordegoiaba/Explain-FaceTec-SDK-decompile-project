package com.facetec.sdk;

import ai.luciq.library.networkv2.request.RequestMethod;
import com.facetec.sdk.ne;

/* JADX INFO: loaded from: classes4.dex */
public final class ny implements ne {
    private nf d;

    public ny(nf nfVar) {
        this.d = nfVar;
    }

    @Override // com.facetec.sdk.ne
    public final nh c(ne.c cVar) {
        oo ooVar = (oo) cVar;
        nj njVarD = ooVar.d();
        oe oeVarE = ooVar.e();
        return ooVar.b(njVarD, oeVarE, oeVarE.d(this.d, cVar, !njVarD.c().equals(RequestMethod.GET)), oeVarE.b());
    }
}