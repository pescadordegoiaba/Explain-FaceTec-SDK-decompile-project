package com.facetec.sdk;

import java.util.List;

/* JADX INFO: loaded from: classes4.dex */
public final class nz {
    final List<mt> a;
    boolean c;
    boolean d;
    int e = 0;

    public nz(List<mt> list) {
        this.a = list;
    }
}