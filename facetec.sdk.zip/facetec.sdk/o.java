package com.facetec.sdk;

import android.content.Context;
import android.hardware.Camera;
import android.os.Build;
import android.util.Size;
import com.facetec.sdk.FaceTecSDK;
import java.util.Arrays;
import java.util.List;
import org.json.JSONObject;

/* JADX INFO: loaded from: classes4.dex */
final class o {
    private static final List<String> j = Arrays.asList("ro_kernel", "ro_product", "ro_boot", "ro_hardware", "ro_build", "ro_lineage_releasetype");
    static int a = 1;
    private static String f = "";
    private static String l = "";
    private static String n = "";
    private static String o = "";
    static String b = "";
    private static StringBuilder k = new StringBuilder();
    static JSONObject d = new JSONObject();
    static JSONObject c = new JSONObject();
    static int e = 0;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    static int f95927g = 0;
    static boolean h = false;
    static String i = "";

    /* JADX INFO: renamed from: com.facetec.sdk.o$2, reason: invalid class name */
    public static /* synthetic */ class AnonymousClass2 {
        static final /* synthetic */ int[] a;

        static {
            int[] iArr = new int[FaceTecSDK.c.values().length];
            a = iArr;
            try {
                iArr[FaceTecSDK.c.NORMAL.ordinal()] = 1;
            } catch (NoSuchFieldError unused) {
            }
            try {
                a[FaceTecSDK.c.BRIGHT_LIGHT.ordinal()] = 2;
            } catch (NoSuchFieldError unused2) {
            }
            try {
                a[FaceTecSDK.c.LOW_LIGHT_FROM_PHX_FACE.ordinal()] = 3;
            } catch (NoSuchFieldError unused3) {
            }
            try {
                a[FaceTecSDK.c.LOW_LIGHT_FROM_PHX_ENV.ordinal()] = 4;
            } catch (NoSuchFieldError unused4) {
            }
            try {
                a[FaceTecSDK.c.LOW_LIGHT_FROM_SENSOR.ordinal()] = 5;
            } catch (NoSuchFieldError unused5) {
            }
        }
    }

    public static void a() {
        cv.K(ao.X, h ? 1 : 0);
    }

    public static void b() {
        cv.H(ao.w, a);
        cv.I(ao.A, f);
        cv.I(ao.D, l);
        cv.I(ao.B, n);
        cv.I(ao.z, o);
    }

    public static void c() {
        cv.H(ao.aa, e);
        cv.H(ao.ah, f95927g);
    }

    public static void d() {
        cv.I(ao.H, String.valueOf(ba.c("BT")));
        cv.I(ao.M, String.valueOf(ba.c("RWT")));
        cv.I(ao.K, String.valueOf(ba.c("CTOT")));
        cv.I(ao.N, String.valueOf(ba.c("CLOT")));
        cv.I(ao.R, String.valueOf(ba.c("CTCPT")));
        cv.I(ao.S, String.valueOf(ba.c("CLCPT")));
        cv.I(ao.P, String.valueOf(ba.c("CTCCST")));
        cv.I(ao.O, String.valueOf(ba.c("CTPRT")));
        cv.I(ao.Q, String.valueOf(ba.c("CTFFT")));
        cv.I(ao.T, String.valueOf(ba.c("CLFFT")));
    }

    public static void e() {
        cv.d(ao.V, c.toString());
        cv.d(ao.U, d.toString());
        cv.H(ao.X, h ? 1 : 0);
    }

    public static void f() {
        int i2 = AnonymousClass2.a[FaceTecSDK.c.ordinal()];
        if (i2 == 1) {
            c(0);
            return;
        }
        if (i2 == 2) {
            c(4);
            return;
        }
        if (i2 == 3) {
            c(1);
        } else if (i2 == 4) {
            c(2);
        } else {
            if (i2 != 5) {
                return;
            }
            c(3);
        }
    }

    public static void g() {
        cv.M(ao.av, Build.FINGERPRINT);
        cv.M(ao.au, Build.MANUFACTURER);
        cv.M(ao.ay, Build.BRAND);
        cv.M(ao.aA, Build.BOOTLOADER);
        cv.K(ao.ax, Build.VERSION.SDK_INT);
        cv.M(ao.aB, Arrays.toString(Build.SUPPORTED_ABIS));
        cv.M(ao.A, f);
        cv.M(ao.D, l);
        cv.M(ao.B, n);
        cv.M(ao.z, o);
    }

    public static void h() {
        cv.I(ao.v, i);
        cv.M(ao.v, i);
    }

    public static void j() {
        int i2 = AnonymousClass2.a[FaceTecSDK.c.ordinal()];
        if (i2 == 3 || i2 == 4 || i2 == 5) {
            boolean z = new dg().b;
            cv.H(ao.ag, z ? 1 : 0);
            cv.K(ao.ag, z ? 1 : 0);
        }
    }

    public static void a(Context context) {
        cv.I("duas", (String) ay.e(-658106623, v.a(), new Object[]{context}, v.a(), 658106623, v.a(), v.a()));
    }

    private static void c(int i2) {
        cv.H("dlm", i2);
        cv.K("dlm", i2);
    }

    /* JADX WARN: Removed duplicated region for block: B:32:0x00b8  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public static void e(android.content.Context r9) {
        /*
            Method dump skipped, instruction units count: 208
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: com.facetec.sdk.o.e(android.content.Context):void");
    }

    public static void e(List<Camera.Size> list) {
        if (f.isEmpty()) {
            StringBuilder sb = new StringBuilder();
            for (Camera.Size size : list) {
                sb.append(size.width);
                sb.append("x");
                sb.append(size.height);
                sb.append(",");
            }
            f = sb.toString();
        }
    }

    public static void e(Size[] sizeArr) {
        if (n.isEmpty()) {
            StringBuilder sb = new StringBuilder();
            for (Size size : sizeArr) {
                sb.append(size.getWidth());
                sb.append("x");
                sb.append(size.getHeight());
                sb.append(",");
            }
            n = sb.toString();
        }
    }
}