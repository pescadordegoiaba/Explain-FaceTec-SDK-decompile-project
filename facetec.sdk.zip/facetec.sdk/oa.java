package com.facetec.sdk;

import android.content.Context;
import android.graphics.Color;
import android.graphics.ImageFormat;
import android.graphics.PointF;
import android.graphics.drawable.Drawable;
import android.os.Process;
import android.os.SystemClock;
import android.text.TextUtils;
import android.util.TypedValue;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewConfiguration;
import android.widget.ExpandableListView;
import com.facetec.sdk.gv;
import com.incode.welcome_sdk.modules.SelfieScan;
import com.plaid.internal.EnumC41897g;
import java.io.ByteArrayInputStream;
import java.io.InputStream;
import java.lang.reflect.Method;
import java.net.InetSocketAddress;
import java.net.Proxy;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Random;
import org.bouncycastle.i18n.LocalizedMessage;

/* JADX INFO: loaded from: classes4.dex */
public final class oa {
    final oc a;
    List<Proxy> b;
    final mn c;
    final mh d;
    final na e;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    List<InetSocketAddress> f95928g;
    final List<nm> i;
    int j;

    public static final class a {
        private static final byte[] $$a = null;
        private static final int $$b = 0;
        private static int $10;
        private static int $11;
        private static char[] a;
        private static int b;
        private static long e;
        private static boolean f;

        /* JADX INFO: renamed from: g, reason: collision with root package name */
        private static boolean f95929g;
        private static int i;
        private static int j;
        final List<nm> c;
        int d = 0;

        /* JADX WARN: Removed duplicated region for block: B:10:0x0024  */
        /* JADX WARN: Removed duplicated region for block: B:8:0x001e  */
        /* JADX WARN: Unsupported multi-entry loop pattern (BACK_EDGE: B:10:0x0024 -> B:11:0x002d). Please report as a decompilation issue!!! */
        /*
            Code decompiled incorrectly, please refer to instructions dump.
            To view partially-correct code enable 'Show inconsistent code' option in preferences
        */
        private static java.lang.String $$c(int r6, short r7, int r8) {
            /*
                int r8 = r8 * 4
                int r8 = r8 + 4
                byte[] r0 = com.facetec.sdk.oa.a.$$a
                int r6 = r6 * 2
                int r1 = 1 - r6
                int r7 = 118 - r7
                byte[] r1 = new byte[r1]
                r2 = 0
                int r6 = 0 - r6
                if (r0 != 0) goto L18
                r7 = r6
                r3 = r0
                r4 = r2
                r0 = r8
                goto L2d
            L18:
                r3 = r2
            L19:
                byte r4 = (byte) r7
                r1[r3] = r4
                if (r3 != r6) goto L24
                java.lang.String r6 = new java.lang.String
                r6.<init>(r1, r2)
                return r6
            L24:
                r4 = r0[r8]
                int r3 = r3 + 1
                r5 = r0
                r0 = r8
                r8 = r4
                r4 = r3
                r3 = r5
            L2d:
                int r8 = -r8
                int r0 = r0 + 1
                int r7 = r7 + r8
                r8 = r0
                r0 = r3
                r3 = r4
                goto L19
            */
            throw new UnsupportedOperationException("Method not decompiled: com.facetec.sdk.oa.a.$$c(int, short, int):java.lang.String");
        }

        static {
            init$0();
            $10 = 0;
            $11 = 1;
            i = 0;
            j = 1;
            e = 1257320983597097507L;
            a = new char[]{8199, 8197, 8436, 8232, 8217, 8219, 8195, 8237, 8206, 8202, 8225, 8198, 8207, 8196, 8193, 8270, 8200, 8205, 8203, 8437, 8250, 8433, 8249, 8194, 8438, 8208, 8245, 8264, 8241, 8251, 8235, 8218, 8204};
            b = 1071521912;
            f = true;
            f95929g = true;
        }

        public a(List<nm> list) {
            this.c = list;
        }

        public static Object[] c(Context context, int i2, int i3) {
            if (context != null) {
                try {
                    int i4 = (PointF.length(SelfieScan.RECOGNITION_FAIL_RESULT, SelfieScan.RECOGNITION_FAIL_RESULT) > SelfieScan.RECOGNITION_FAIL_RESULT ? 1 : (PointF.length(SelfieScan.RECOGNITION_FAIL_RESULT, SelfieScan.RECOGNITION_FAIL_RESULT) == SelfieScan.RECOGNITION_FAIL_RESULT ? 0 : -1));
                    int i5 = i4 * 85;
                    int i6 = (i5 ^ 85) + ((i5 & 85) << 1);
                    int i7 = ~i4;
                    int i8 = ~((i7 ^ (-2)) | (i7 & (-2)));
                    int i9 = ~i4;
                    int i10 = ~i2;
                    int i11 = ~((i9 ^ i10) | (i9 & i10));
                    int i12 = (i8 ^ i11) | (i11 & i8);
                    int i13 = ~i2;
                    int i14 = (~(((-2) ^ i13) | ((-2) & i13))) | i12;
                    int i15 = ~((i4 ^ 1) | (i4 & 1) | i2);
                    int i16 = ((i14 ^ i15) | (i14 & i15)) * (-84);
                    int i17 = ((i6 | i16) << 1) - (i16 ^ i6);
                    int i18 = ~((-2) | i2);
                    int i19 = (i18 & i4) | (i4 ^ i18);
                    int i20 = (i10 ^ 1) | (i10 & 1);
                    int i21 = ~i20;
                    int i22 = i17 + (((i19 ^ i21) | (i19 & i21)) * (-84));
                    int i23 = ~i20;
                    int i24 = ~(i4 | 1);
                    int i25 = -(-(((i23 & i24) | (i23 ^ i24)) * 84));
                    int i26 = ((i22 | i25) << 1) - (i25 ^ i22);
                    Object[] objArr = new Object[1];
                    h("䢯ⱽ䣬₀\u2fe9닦㚲钾稍፦掩\uea6cⵞ幒儷㤓킮褈鹖\u0cfc莳\ufbd1쭂䏮딽⚶㣹障砎ᅢ旫\ue444⬆屯區", i26, objArr);
                    try {
                        Object[] objArr2 = {(String) objArr[0]};
                        int size = View.MeasureSpec.getSize(0);
                        int i27 = (size ^ 1) + ((size & 1) << 1);
                        Object[] objArr3 = new Object[1];
                        h("댹▻덓⥩\ue8ccﯖ\uf1dc\uddae膍\u1aea\ua48dꍖ훂垅陀瀎⬩胕夨䗊硼\uf22cల\u0ab1亽⼡ﾞ\udff3菟ᢘꋗ괇킝喬鑄爒┷蛋䝣䟟穴\uf008", i27, objArr3);
                        Object objNewInstance = Class.forName((String) objArr3[0]).getDeclaredConstructor(String.class).newInstance(objArr2);
                        Object[] objArr4 = new Object[1];
                        h("ꧪ金ꦩ鵟\uf367ꂝ\uea54蛗鬊껡뽨\uf839찜\ue3fe跫⭃\u31e7㒢䊁ả抔䘏ឰ冺呲鬌\ue46a蓡饆겊뤍\uf619쨜\ue1e3迺", -TextUtils.indexOf((CharSequence) "", '0', 0, 0), objArr4);
                        try {
                            Object[] objArr5 = {(String) objArr4[0]};
                            Object[] objArr6 = new Object[1];
                            h("댹▻덓⥩\ue8ccﯖ\uf1dc\uddae膍\u1aea\ua48dꍖ훂垅陀瀎⬩胕夨䗊硼\uf22cల\u0ab1亽⼡ﾞ\udff3菟ᢘꋗ괇킝喬鑄爒┷蛋䝣䟟穴\uf008", 0 - (~(-View.resolveSize(0, 0))), objArr6);
                            Object objNewInstance2 = Class.forName((String) objArr6[0]).getDeclaredConstructor(String.class).newInstance(objArr5);
                            try {
                                int i28 = -KeyEvent.getDeadChar(0, 0);
                                int i29 = (i28 & 1) + (i28 | 1);
                                Object[] objArr7 = new Object[1];
                                h("簋\u2d6d籪↰ﳥ鈲\ue5e7둙亨ቻ낳쫹᧰彉艵᧷\ue40a蠔䵛ⱡ띸\ufae1\u181d挏膒➺\uebf3", i29, objArr7);
                                Class<?> cls = Class.forName((String) objArr7[0]);
                                int i30 = -TextUtils.indexOf("", "", 0);
                                int iE = gv.AnonymousClass4.e();
                                int i31 = (i30 * (-589)) + 75057;
                                int i32 = ~iE;
                                int i33 = ~((-128) | i32);
                                int i34 = ~(((-128) ^ i30) | ((-128) & i30));
                                int i35 = (i33 ^ i34) | (i34 & i33) | (~(i32 | i30));
                                int i36 = ~i30;
                                int i37 = (i36 ^ 127) | (i36 & 127);
                                int i38 = (i35 | (~((i37 ^ iE) | (i37 & iE)))) * 590;
                                int i39 = ((i31 | i38) << 1) - (i38 ^ i31);
                                int i40 = ~((-128) | i32);
                                int i41 = ~(((-128) ^ i30) | ((-128) & i30));
                                int i42 = ~iE;
                                int i43 = -(-(((i40 ^ i41) | (i40 & i41) | (~((i30 & i42) | (i42 ^ i30)))) * (-1180)));
                                int i44 = ((i39 | i43) << 1) - (i39 ^ i43);
                                int i45 = ~(i36 | i32);
                                int i46 = ~((i32 ^ 127) | (i32 & 127));
                                int i47 = -(-(((i45 & i46) | (i45 ^ i46)) * 590));
                                Object[] objArr8 = new Object[1];
                                k(null, null, (i44 & i47) + (i47 | i44), "\u008a\u0082\u0081\u0085\u0089\u0085\u0088\u0082\u0081\u0085\u0087\u0086\u0085\u0084\u0083\u0082\u0081", objArr8);
                                Object objInvoke = cls.getMethod((String) objArr8[0], null).invoke(context, null);
                                try {
                                    int threadPriority = Process.getThreadPriority(0);
                                    int i48 = threadPriority * (-445);
                                    int i49 = ((-8900) & i48) + (i48 | (-8900));
                                    int i50 = ~threadPriority;
                                    int i51 = (-21) | i50;
                                    int i52 = ((~((i50 & i13) | (i50 ^ i13))) | (~i51)) * 446;
                                    int i53 = (i49 & i52) + (i52 | i49);
                                    int i54 = ~(((-21) & threadPriority) | ((-21) ^ threadPriority));
                                    int i55 = ~threadPriority;
                                    int i56 = (i55 & 20) | (i55 ^ 20);
                                    int i57 = ~((i56 & i2) | (i56 ^ i2));
                                    int i58 = -(-(((i57 & i54) | (i54 ^ i57)) * 446));
                                    int i59 = (i53 & i58) + (i58 | i53);
                                    int i60 = -(-((~i51) * 446));
                                    int i61 = 1 - ((((i59 | i60) << 1) - (i60 ^ i59)) >> 6);
                                    Object[] objArr9 = new Object[1];
                                    h("簋\u2d6d籪↰ﳥ鈲\ue5e7둙亨ቻ낳쫹᧰彉艵᧷\ue40a蠔䵛ⱡ띸\ufae1\u181d挏膒➺\uebf3", i61, objArr9);
                                    Class<?> cls2 = Class.forName((String) objArr9[0]);
                                    int i62 = -Drawable.resolveOpacity(0, 0);
                                    int i63 = (i62 ^ 1) + ((i62 & 1) << 1);
                                    Object[] objArr10 = new Object[1];
                                    h("愫メ慌㰷\ud950騪쁂뱣历\u0ffd锉슮Ӕ䋏\ua7e0ᇺ濫間", i63, objArr10);
                                    try {
                                        Object[] objArr11 = {cls2.getMethod((String) objArr10[0], null).invoke(context, null), 64};
                                        int iArgb = Color.argb(0, 0, 0, 0);
                                        int i64 = (iArgb ^ 1) + ((iArgb & 1) << 1);
                                        Object[] objArr12 = new Object[1];
                                        h("컍騋캬雖芸ڠ鮺\u20cbﱮꔝ컮幫ꬶ\ue82fﰨ赥囌㽲㌆룳֍䶅昀\uf7b9㍐郇閱⋔﹢꜕죛倠괷\uea2d︥轨壟", i64, objArr12);
                                        Class<?> cls3 = Class.forName((String) objArr12[0]);
                                        int scrollDefaultDelay = ViewConfiguration.getScrollDefaultDelay() >> 16;
                                        int i65 = (scrollDefaultDelay * (-575)) - 73025;
                                        int i66 = ~scrollDefaultDelay;
                                        int i67 = ((~((i66 ^ (-128)) | (i66 & (-128)))) | (~(((-128) ^ i2) | ((-128) & i2)))) * 576;
                                        int i68 = (i65 & i67) + (i65 | i67);
                                        int i69 = ~((i66 ^ 127) | (i66 & 127));
                                        int i70 = ((-128) ^ i13) | ((-128) & i13);
                                        int i71 = ~((scrollDefaultDelay & i70) | (i70 ^ scrollDefaultDelay));
                                        int i72 = ((i68 + (((i71 & i69) | (i69 ^ i71)) * 576)) - (~((~((i66 ^ (-128)) | (i66 & (-128)))) * 576))) - 1;
                                        Object[] objArr13 = new Object[1];
                                        k(null, null, i72, "\u008d\u008c\u0089\u008b\u0082\u0081\u0085\u0087\u0086\u0085\u0084\u0083\u0082\u0081", objArr13);
                                        Object objInvoke2 = cls3.getMethod((String) objArr13[0], String.class, Integer.TYPE).invoke(objInvoke, objArr11);
                                        long j2 = 0;
                                        int i73 = (ExpandableListView.getPackedPositionForGroup(0) > 0L ? 1 : (ExpandableListView.getPackedPositionForGroup(0) == 0L ? 0 : -1));
                                        Object[] objArr14 = new Object[1];
                                        k(null, null, ((i73 | 127) << 1) - (i73 ^ 127), "\u008d\u008c\u0089\u008b\u0082\u0081\u0085\u0087\u0086\u0085\u0084\u0090\u0092\u0091\u0090\u0083\u0089\u0082\u0083\u0089\u008d\u0086\u0090\u008e\u008f\u008d\u008a\u008e\u0089\u0085", objArr14);
                                        Class<?> cls4 = Class.forName((String) objArr14[0]);
                                        Object[] objArr15 = new Object[1];
                                        k(null, null, 128 - (SystemClock.elapsedRealtimeNanos() > 0L ? 1 : (SystemClock.elapsedRealtimeNanos() == 0L ? 0 : -1)), "\u0093\u0082\u008a\u0094\u0083\u0085\u0089\u0081\u008f\u0093", objArr15);
                                        Object[] objArr16 = (Object[]) cls4.getField((String) objArr15[0]).get(objInvoke2);
                                        int length = objArr16.length;
                                        int i74 = 0;
                                        while (i74 < length) {
                                            Object obj = objArr16[i74];
                                            int threadPriority2 = (Process.getThreadPriority(0) + 20) >> 6;
                                            long j3 = j2;
                                            int i75 = ((threadPriority2 | 1) << 1) - (threadPriority2 ^ 1);
                                            Object[] objArr17 = new Object[1];
                                            h("\uf8bc튨\uf8e4\ude35ꖗ伡별椈쩉", i75, objArr17);
                                            try {
                                                Object[] objArr18 = {(String) objArr17[0]};
                                                Object[] objArr19 = new Object[1];
                                                h("\ue06fዽ\ue005ḯ配﵃衝\udb3b튍ⷱ\udd1aꗅ薂惄\uefda皆硲럄⃤䍛⬭앪痵\u0c49᷶ᠠ虛\ud93f탁\u2fef\udb00ꯃ莏拟\uedf1璏癬놚㻤䅈⤺", 0 - (~KeyEvent.normalizeMetaState(0)), objArr19);
                                                Class<?> cls5 = Class.forName((String) objArr19[0]);
                                                int i76 = -ExpandableListView.getPackedPositionGroup(j3);
                                                int iE2 = gv.AnonymousClass4.e();
                                                int i77 = i76 * (-405);
                                                int i78 = (i77 ^ 51689) + ((i77 & 51689) << 1);
                                                int i79 = ~(((-128) ^ iE2) | ((-128) & iE2));
                                                Object[] objArr20 = objArr16;
                                                int i80 = ~iE2;
                                                int i81 = (i80 ^ i76) | (i80 & i76);
                                                int i82 = ~((i81 ^ 127) | (i81 & 127));
                                                int i83 = -(-(((i79 ^ i82) | (i82 & i79)) * (-406)));
                                                int i84 = (i78 ^ i83) + ((i78 & i83) << 1);
                                                int i85 = ~iE2;
                                                int i86 = ((-128) ^ i85) | ((-128) & i85);
                                                int i87 = (~((i86 ^ i76) | (i86 & i76))) * (-406);
                                                int i88 = (i84 ^ i87) + ((i87 & i84) << 1);
                                                int i89 = ~i76;
                                                int i90 = ~((i89 & iE2) | (i89 ^ iE2));
                                                int i91 = ~((i85 ^ 127) | (i85 & 127));
                                                int i92 = -(-(((i90 & i91) | (i90 ^ i91)) * 406));
                                                Object[] objArr21 = new Object[1];
                                                k(null, null, (i88 ^ i92) + ((i88 & i92) << 1), "\u0082\u0086\u0089\u0085\u0083\u0093\u0089\u008b\u0083\u0082\u0081", objArr21);
                                                Object objInvoke3 = cls5.getMethod((String) objArr21[0], String.class).invoke(null, objArr18);
                                                try {
                                                    int iCombineMeasuredStates = View.combineMeasuredStates(0, 0);
                                                    int i93 = ~iCombineMeasuredStates;
                                                    int i94 = ~((i93 ^ 1) | (i93 & 1));
                                                    int i95 = length;
                                                    int i96 = ~(((-2) ^ iCombineMeasuredStates) | ((-2) & iCombineMeasuredStates));
                                                    int i97 = (((((iCombineMeasuredStates * 659) - 657) - (~((((i94 ^ i96) | (i96 & i94)) | (~((iCombineMeasuredStates ^ i2) | (iCombineMeasuredStates & i2)))) * (-658)))) - 1) - (~(-(-((~(((-2) ^ iCombineMeasuredStates) | ((-2) & iCombineMeasuredStates))) * 658))))) - 1;
                                                    int i98 = ~((-2) | iCombineMeasuredStates);
                                                    int i99 = ~(iCombineMeasuredStates | i2);
                                                    int i100 = (i97 - (~(((i98 & i99) | (i98 ^ i99)) * 658))) - 1;
                                                    Object[] objArr22 = new Object[1];
                                                    h("爐틐肋\ude0d\ue110훦\uf812\uf08d쮑\uedc6굆踭鳉ꃴ龀崣愳瞩傮梵㉲՞֨⟼ҧ\ud818\uf61c\uf292즎\uefdeꭌ聢", i100, objArr22);
                                                    Class<?> cls6 = Class.forName((String) objArr22[0]);
                                                    int i101 = -(ViewConfiguration.getScrollBarSize() >> 8);
                                                    int i102 = i101 * (-464);
                                                    int i103 = (i102 ^ (-117983)) + ((i102 & (-117983)) << 1);
                                                    int i104 = ~i101;
                                                    int i105 = (i2 ^ 127) | (i2 & 127);
                                                    int i106 = i74;
                                                    int i107 = ~i105;
                                                    int i108 = -(-(((i104 ^ i107) | (i107 & i104)) * (-465)));
                                                    int i109 = (i103 ^ i108) + ((i108 & i103) << 1);
                                                    int i110 = ~((~i101) | i2);
                                                    int i111 = ((i110 & 127) | (i110 ^ 127)) * 930;
                                                    int i112 = (((i109 & i111) + (i109 | i111)) - (~(((i105 ^ i104) | (i104 & i105)) * 465))) - 1;
                                                    Object[] objArr23 = new Object[1];
                                                    k(null, null, i112, "\u0096\u0085\u008a\u008a\u0097\u0082\u0083\u0096\u0095\u008d\u0083", objArr23);
                                                    try {
                                                        Object[] objArr24 = {new ByteArrayInputStream((byte[]) cls6.getMethod((String) objArr23[0], null).invoke(obj, null))};
                                                        Object[] objArr25 = new Object[1];
                                                        h("\ue06fዽ\ue005ḯ配﵃衝\udb3b튍ⷱ\udd1aꗅ薂惄\uefda皆硲럄⃤䍛⬭앪痵\u0c49᷶ᠠ虛\ud93f탁\u2fef\udb00ꯃ莏拟\uedf1璏癬놚㻤䅈⤺", (SystemClock.elapsedRealtime() > j3 ? 1 : (SystemClock.elapsedRealtime() == j3 ? 0 : -1)), objArr25);
                                                        Class<?> cls7 = Class.forName((String) objArr25[0]);
                                                        int iIndexOf = TextUtils.indexOf("", "", 0);
                                                        int iE3 = gv.AnonymousClass4.e();
                                                        int i113 = iIndexOf * (-755);
                                                        int i114 = ((i113 | (-755)) << 1) - (i113 ^ (-755));
                                                        int i115 = ~iIndexOf;
                                                        int i116 = i114 + ((~((i115 & (-2)) | (i115 ^ (-2)))) * 1512);
                                                        int i117 = ~iIndexOf;
                                                        int i118 = ~((i117 & (-2)) | (i117 ^ (-2)));
                                                        int i119 = (iIndexOf & 1) | (iIndexOf ^ 1);
                                                        int i120 = ~((i119 ^ iE3) | (i119 & iE3));
                                                        int i121 = ((i118 ^ i120) | (i118 & i120)) * (-756);
                                                        int i122 = ~iE3;
                                                        int i123 = (((i116 ^ i121) + ((i121 & i116) << 1)) - (~(-(-(((i119 & i122) | (i119 ^ i122)) * 756))))) - 1;
                                                        Object[] objArr26 = new Object[1];
                                                        h("儩꾊兎ꍜ萊\ueb8f鴂췳掗邔졌댏㓲\udda4惘恊줤ૻ㖩喑驸砝惹", i123, objArr26);
                                                        Object objInvoke4 = cls7.getMethod((String) objArr26[0], InputStream.class).invoke(objInvoke3, objArr24);
                                                        try {
                                                            Object[] objArr27 = new Object[1];
                                                            k(null, null, 127 - View.resolveSize(0, 0), "\u0082\u0083\u0085\u0086\u008f\u008c\u008f\u0083\u008a\u0082\u009e\u009d\u009c\u009b\u009a\u0090\u0083\u008a\u0082\u0086\u0090\u0096\u0083\u008f\u008a\u0094\u0086\u0082\u0093\u0090\u0085\u0099\u0085\u0098", objArr27);
                                                            Class<?> cls8 = Class.forName((String) objArr27[0]);
                                                            int i124 = (ViewConfiguration.getScrollFriction() > SelfieScan.RECOGNITION_FAIL_RESULT ? 1 : (ViewConfiguration.getScrollFriction() == SelfieScan.RECOGNITION_FAIL_RESULT ? 0 : -1));
                                                            Object[] objArr28 = new Object[1];
                                                            k(null, null, (i124 ^ 126) + ((i124 & 126) << 1), "¡\u0085\u0091\u008f\u0086\u0089\u008f\u008a\u0084\u009c\u009c\u009b\u009a\u0083\u0086\u0082\u0098 \u0094\u009f\u0083\u0082\u0081", objArr28);
                                                            if (!objNewInstance.equals(cls8.getMethod((String) objArr28[0], null).invoke(objInvoke4, null))) {
                                                                try {
                                                                    int i125 = -(SystemClock.currentThreadTimeMillis() > (-1L) ? 1 : (SystemClock.currentThreadTimeMillis() == (-1L) ? 0 : -1));
                                                                    int i126 = i125 * 51;
                                                                    int i127 = (i126 ^ (-6272)) + ((i126 & (-6272)) << 1) + (((i125 ^ i2) | (i125 & i2)) * (-50));
                                                                    int i128 = (~i125) | (-129);
                                                                    int i129 = ~((i128 & i2) | (i128 ^ i2));
                                                                    int i130 = ((-129) ^ i13) | ((-129) & i13);
                                                                    int i131 = ~((i130 & i125) | (i130 ^ i125));
                                                                    int i132 = i127 + (((i129 & i131) | (i129 ^ i131)) * 50);
                                                                    int i133 = ~(((-129) ^ i13) | ((-129) & i13));
                                                                    int i134 = ~(((-129) ^ i125) | ((-129) & i125));
                                                                    int i135 = -(-(((~((i125 & i10) | (i10 ^ i125))) | (i133 & i134) | (i133 ^ i134)) * 50));
                                                                    int i136 = (i132 & i135) + (i135 | i132);
                                                                    Object[] objArr29 = new Object[1];
                                                                    k(null, null, i136, "\u0082\u0083\u0085\u0086\u008f\u008c\u008f\u0083\u008a\u0082\u009e\u009d\u009c\u009b\u009a\u0090\u0083\u008a\u0082\u0086\u0090\u0096\u0083\u008f\u008a\u0094\u0086\u0082\u0093\u0090\u0085\u0099\u0085\u0098", objArr29);
                                                                    Class<?> cls9 = Class.forName((String) objArr29[0]);
                                                                    int i137 = -(ViewConfiguration.getEdgeSlop() >> 16);
                                                                    int iE4 = gv.AnonymousClass4.e();
                                                                    int i138 = ~i137;
                                                                    int i139 = (i138 & 127) | (i138 ^ 127);
                                                                    int i140 = ((i137 * (-520)) - (-66294)) + ((~((i139 & iE4) | (i139 ^ iE4))) * 521);
                                                                    int i141 = ~(((-128) ^ i137) | ((-128) & i137));
                                                                    int i142 = (i140 - (~(-(-(i141 * (-1042)))))) - 1;
                                                                    int i143 = (~i137) | (~iE4);
                                                                    int i144 = ~((i143 & 127) | (i143 ^ 127));
                                                                    Object[] objArr30 = new Object[1];
                                                                    k(null, null, i142 + (((i144 & i141) | (i141 ^ i144)) * 521), "¡\u0085\u0091\u008f\u0086\u0089\u008f\u008a\u0084\u009c\u009c\u009b\u009a\u0083\u0086\u0082\u0098 \u0094\u009f\u0083\u0082\u0081", objArr30);
                                                                    if (!objNewInstance2.equals(cls9.getMethod((String) objArr30[0], null).invoke(objInvoke4, null))) {
                                                                        i74 = (i106 ^ 1) + ((i106 & 1) << 1);
                                                                        objArr16 = objArr20;
                                                                        j2 = j3;
                                                                        length = i95;
                                                                    }
                                                                } catch (Throwable th) {
                                                                    Throwable cause = th.getCause();
                                                                    if (cause != null) {
                                                                        throw cause;
                                                                    }
                                                                    throw th;
                                                                }
                                                            }
                                                            Object[] objArr31 = {null, new int[1], new int[]{(i2 & (-2)) | (i13 & 1)}, new int[]{i2}};
                                                            int elapsedCpuTime = (int) Process.getElapsedCpuTime();
                                                            int i145 = (-1010844619) + (((~((-612771613) | elapsedCpuTime)) | 603988744 | (~(433540118 | elapsedCpuTime))) * (-880));
                                                            int i146 = (~((-612771613) | (~elapsedCpuTime))) | (-433540119);
                                                            int i147 = ~(elapsedCpuTime | 612771612);
                                                            int i148 = i145 + ((i146 | i147) * (-880)) + (i147 * 880);
                                                            int i149 = 736 + (i148 * 46);
                                                            int i150 = ~i148;
                                                            int i151 = ((~((i150 ^ i10) | (i150 & i10))) | 16) * (-90);
                                                            int i152 = (i149 & i151) + (i149 | i151);
                                                            int i153 = ~(i150 | i2);
                                                            int i154 = ~((i148 ^ 16) | (i148 & 16));
                                                            int i155 = -(-(((i153 & i154) | (i153 ^ i154)) * (-45)));
                                                            int i156 = (i152 ^ i155) + ((i155 & i152) << 1);
                                                            int i157 = ~((-17) | i2);
                                                            int i158 = (i150 & i157) | (i150 ^ i157);
                                                            int i159 = ~((i10 ^ 16) | (i10 & 16));
                                                            int i160 = i156 + (((i158 & i159) | (i158 ^ i159)) * 45);
                                                            int iE5 = gv.AnonymousClass4.e();
                                                            int i161 = i160 * (-589);
                                                            int i162 = -(-(i3 * 591));
                                                            int i163 = (i161 & i162) + (i161 | i162);
                                                            int i164 = ~i3;
                                                            int i165 = ~iE5;
                                                            int i166 = (~((i164 ^ i165) | (i164 & i165))) | (~((i164 ^ i160) | (i164 & i160)));
                                                            int i167 = ~iE5;
                                                            int i168 = ~((i167 & i160) | (i167 ^ i160));
                                                            int i169 = (i166 & i168) | (i166 ^ i168);
                                                            int i170 = ~i160;
                                                            int i171 = (i170 & i3) | (i170 ^ i3);
                                                            int i172 = ~((iE5 & i171) | (i171 ^ iE5));
                                                            int i173 = (i163 - (~(((i172 & i169) | (i169 ^ i172)) * 590))) - 1;
                                                            int i174 = ~((i164 ^ i165) | (i164 & i165));
                                                            int i175 = ~i3;
                                                            int i176 = ~((i175 & i160) | (i175 ^ i160));
                                                            int i177 = (i174 & i176) | (i174 ^ i176);
                                                            int i178 = ~((i165 ^ i160) | (i165 & i160));
                                                            int i179 = -(-(((i177 & i178) | (i177 ^ i178)) * (-1180)));
                                                            int i180 = ((i173 | i179) << 1) - (i179 ^ i173);
                                                            int i181 = ~i160;
                                                            int i182 = ~((i181 & i165) | (i181 ^ i165));
                                                            int i183 = ~((i165 ^ i3) | (i165 & i3));
                                                            int i184 = ((i182 & i183) | (i182 ^ i183)) * 590;
                                                            int i185 = ((i180 | i184) << 1) - (i184 ^ i180);
                                                            int i186 = i185 << 13;
                                                            int i187 = (i186 | i185) & (~(i185 & i186));
                                                            int i188 = i187 >>> 17;
                                                            int i189 = ((~i187) & i188) | ((~i188) & i187);
                                                            int i190 = i189 << 5;
                                                            ((int[]) objArr31[1])[0] = (i189 | i190) & (~(i189 & i190));
                                                            return objArr31;
                                                        } catch (Throwable th2) {
                                                            Throwable cause2 = th2.getCause();
                                                            if (cause2 != null) {
                                                                throw cause2;
                                                            }
                                                            throw th2;
                                                        }
                                                    } catch (Throwable th3) {
                                                        Throwable cause3 = th3.getCause();
                                                        if (cause3 != null) {
                                                            throw cause3;
                                                        }
                                                        throw th3;
                                                    }
                                                } catch (Throwable th4) {
                                                    Throwable cause4 = th4.getCause();
                                                    if (cause4 != null) {
                                                        throw cause4;
                                                    }
                                                    throw th4;
                                                }
                                            } catch (Throwable th5) {
                                                Throwable cause5 = th5.getCause();
                                                if (cause5 != null) {
                                                    throw cause5;
                                                }
                                                throw th5;
                                            }
                                        }
                                    } catch (Throwable th6) {
                                        Throwable cause6 = th6.getCause();
                                        if (cause6 != null) {
                                            throw cause6;
                                        }
                                        throw th6;
                                    }
                                } catch (Throwable th7) {
                                    Throwable cause7 = th7.getCause();
                                    if (cause7 != null) {
                                        throw cause7;
                                    }
                                    throw th7;
                                }
                            } catch (Throwable th8) {
                                Throwable cause8 = th8.getCause();
                                if (cause8 != null) {
                                    throw cause8;
                                }
                                throw th8;
                            }
                        } catch (Throwable th9) {
                            Throwable cause9 = th9.getCause();
                            if (cause9 != null) {
                                throw cause9;
                            }
                            throw th9;
                        }
                    } catch (Throwable th10) {
                        Throwable cause10 = th10.getCause();
                        if (cause10 != null) {
                            throw cause10;
                        }
                        throw th10;
                    }
                } catch (Throwable unused) {
                }
            }
            Object[] objArr32 = {null, new int[1], new int[]{i2}, new int[]{i2}};
            int iNextInt = new Random().nextInt();
            int i191 = 503411836 + (((~((~iNextInt) | 715501308)) | 357716226) * 529) + (((~(iNextInt | 715501308)) | 536269814) * 529);
            int iE6 = gv.AnonymousClass4.e();
            int i192 = ((i191 * (-813)) - (~(-(-(i3 * 408))))) - 1;
            int i193 = ~i3;
            int i194 = ((~(i193 | i191)) | (~(i191 | iE6))) * (-814);
            int i195 = ((i192 | i194) << 1) - (i192 ^ i194);
            int i196 = ~iE6;
            int i197 = ~((i196 & i193) | (i193 ^ i196));
            int i198 = ~i191;
            int i199 = ~((i198 ^ i3) | (i198 & i3));
            int i200 = (i197 & i199) | (i197 ^ i199);
            int i201 = ~((i191 ^ iE6) | (i191 & iE6));
            int i202 = ((i195 - (~(((i200 & i201) | (i200 ^ i201)) * 407))) - 1) + (((~((iE6 & i3) | (i3 ^ iE6))) | (~((~i191) | i3)) | (~((i198 & iE6) | (i198 ^ iE6)))) * 407);
            int i203 = i202 << 13;
            int i204 = (i203 & (~i202)) | ((~i203) & i202);
            int i205 = i204 >>> 17;
            int i206 = ((~i204) & i205) | ((~i205) & i204);
            int i207 = i206 << 5;
            ((int[]) objArr32[1])[0] = (i206 | i207) & (~(i206 & i207));
            return objArr32;
        }

        private static void h(String str, int i2, Object[] objArr) throws Throwable {
            char[] charArray;
            if (str != null) {
                int i3 = $11 + 85;
                $10 = i3 % 128;
                if (i3 % 2 != 0) {
                    charArray = str.toCharArray();
                    int i4 = 60 / 0;
                } else {
                    charArray = str.toCharArray();
                }
            } else {
                charArray = str;
            }
            hl hlVar = new hl();
            char[] cArrB = hl.b(e ^ (-1723600592890876272L), charArray, i2);
            hlVar.e = 4;
            while (true) {
                int i5 = hlVar.e;
                if (i5 >= cArrB.length) {
                    objArr[0] = new String(cArrB, 4, cArrB.length - 4);
                    return;
                }
                $11 = ($10 + 57) % 128;
                int i6 = i5 - 4;
                hlVar.d = i6;
                try {
                    Object[] objArr2 = {Long.valueOf(cArrB[i5] ^ cArrB[i5 % 4]), Long.valueOf(i6), Long.valueOf(e)};
                    Object objD = an.d(-291407824);
                    if (objD == null) {
                        int deadChar = KeyEvent.getDeadChar(0, 0) + 2589;
                        char cBlue = (char) Color.blue(0);
                        int iLastIndexOf = TextUtils.lastIndexOf("", '0') + 24;
                        byte b2 = (byte) 0;
                        String str$$c = $$c(b2, (byte) (b2 | 45), b2);
                        Class cls = Long.TYPE;
                        objD = an.d(deadChar, cBlue, iLastIndexOf, -1732203669, false, str$$c, new Class[]{cls, cls, cls});
                    }
                    cArrB[i5] = ((Character) ((Method) objD).invoke(null, objArr2)).charValue();
                    Object[] objArr3 = {hlVar, hlVar};
                    Object objD2 = an.d(1066529625);
                    if (objD2 == null) {
                        objD2 = an.d(310 - (TypedValue.complexToFloat(0) > SelfieScan.RECOGNITION_FAIL_RESULT ? 1 : (TypedValue.complexToFloat(0) == SelfieScan.RECOGNITION_FAIL_RESULT ? 0 : -1)), (char) TextUtils.getOffsetAfter("", 0), 23 - KeyEvent.getDeadChar(0, 0), 1240473602, false, "G", new Class[]{Object.class, Object.class});
                    }
                    ((Method) objD2).invoke(null, objArr3);
                } catch (Throwable th) {
                    Throwable cause = th.getCause();
                    if (cause == null) {
                        throw th;
                    }
                    throw cause;
                }
            }
        }

        public static void init$0() {
            $$a = new byte[]{120, 65, 99, 57};
            $$b = EnumC41897g.SDK_ASSET_ILLUSTRATION_IN_CONTROL_VALUE;
        }

        private static void k(int[] iArr, String str, int i2, String str2, Object[] objArr) throws Throwable {
            char[] charArray;
            char[] cArr;
            int i3;
            int length;
            char[] cArr2;
            int i4;
            int i5;
            String str3 = str2;
            int i6 = $10 + 77;
            $11 = i6 % 128;
            Object bytes = str3;
            if (i6 % 2 == 0) {
                throw null;
            }
            if (str3 != null) {
                bytes = str3.getBytes(LocalizedMessage.DEFAULT_ENCODING);
            }
            byte[] bArr = (byte[]) bytes;
            if (str != null) {
                int i7 = $10 + 29;
                $11 = i7 % 128;
                if (i7 % 2 == 0) {
                    str.toCharArray();
                    throw null;
                }
                charArray = str.toCharArray();
            } else {
                charArray = str;
            }
            char[] cArr3 = charArray;
            hn hnVar = new hn();
            char[] cArr4 = a;
            Class cls = Integer.TYPE;
            int i8 = 0;
            if (cArr4 != null) {
                int i9 = $11 + 11;
                $10 = i9 % 128;
                if (i9 % 2 != 0) {
                    length = cArr4.length;
                    cArr2 = new char[length];
                    i4 = 1;
                } else {
                    length = cArr4.length;
                    cArr2 = new char[length];
                    i4 = 0;
                }
                while (i4 < length) {
                    $10 = ($11 + 99) % 128;
                    try {
                        Object[] objArr2 = {Integer.valueOf(cArr4[i4])};
                        Object objD = an.d(-814569747);
                        if (objD == null) {
                            byte b2 = (byte) i8;
                            byte b3 = b2;
                            i5 = i8;
                            objD = an.d(1803 - (TypedValue.complexToFraction(i8, SelfieScan.RECOGNITION_FAIL_RESULT, SelfieScan.RECOGNITION_FAIL_RESULT) > SelfieScan.RECOGNITION_FAIL_RESULT ? 1 : (TypedValue.complexToFraction(i8, SelfieScan.RECOGNITION_FAIL_RESULT, SelfieScan.RECOGNITION_FAIL_RESULT) == SelfieScan.RECOGNITION_FAIL_RESULT ? 0 : -1)), (char) (View.combineMeasuredStates(i8, i8) + 9692), 24 - (PointF.length(SelfieScan.RECOGNITION_FAIL_RESULT, SelfieScan.RECOGNITION_FAIL_RESULT) > SelfieScan.RECOGNITION_FAIL_RESULT ? 1 : (PointF.length(SelfieScan.RECOGNITION_FAIL_RESULT, SelfieScan.RECOGNITION_FAIL_RESULT) == SelfieScan.RECOGNITION_FAIL_RESULT ? 0 : -1)), -1189907018, false, $$c(b2, b3, b3), new Class[]{cls});
                        } else {
                            i5 = i8;
                        }
                        cArr2[i4] = ((Character) ((Method) objD).invoke(null, objArr2)).charValue();
                        i4++;
                        i8 = i5;
                    } catch (Throwable th) {
                        Throwable cause = th.getCause();
                        if (cause == null) {
                            throw th;
                        }
                        throw cause;
                    }
                }
                cArr4 = cArr2;
            }
            int i10 = i8;
            Object[] objArr3 = {Integer.valueOf(b)};
            Object objD2 = an.d(-1578986303);
            if (objD2 == null) {
                byte b4 = (byte) i10;
                byte b5 = (byte) (b4 + 1);
                objD2 = an.d((Process.getElapsedCpuTime() > 0L ? 1 : (Process.getElapsedCpuTime() == 0L ? 0 : -1)) + 2565, (char) ((-1) - ImageFormat.getBitsPerPixel(i10)), 23 - KeyEvent.normalizeMetaState(i10), -679262310, false, $$c(b4, b5, (byte) (b5 - 1)), new Class[]{cls});
            }
            int iIntValue = ((Integer) ((Method) objD2).invoke(null, objArr3)).intValue();
            if (f95929g) {
                int length2 = bArr.length;
                hnVar.b = length2;
                char[] cArr5 = new char[length2];
                hnVar.c = 0;
                while (true) {
                    int i11 = hnVar.c;
                    int i12 = hnVar.b;
                    if (i11 >= i12) {
                        objArr[0] = new String(cArr5);
                        return;
                    }
                    cArr5[i11] = (char) (cArr4[bArr[(i12 - 1) - i11] + i2] - iIntValue);
                    Object[] objArr4 = {hnVar, hnVar};
                    Object objD3 = an.d(717234065);
                    if (objD3 == null) {
                        objD3 = an.d((SystemClock.currentThreadTimeMillis() > (-1L) ? 1 : (SystemClock.currentThreadTimeMillis() == (-1L) ? 0 : -1)) + 1969, (char) ((-1) - (ExpandableListView.getPackedPositionForChild(0, 0) > 0L ? 1 : (ExpandableListView.getPackedPositionForChild(0, 0) == 0L ? 0 : -1))), 23 - TextUtils.lastIndexOf("", '0', 0, 0), 1554107594, false, "x", new Class[]{Object.class, Object.class});
                    }
                    ((Method) objD3).invoke(null, objArr4);
                }
            } else if (f) {
                int i13 = $11 + 81;
                $10 = i13 % 128;
                if (i13 % 2 != 0) {
                    int length3 = cArr3.length;
                    hnVar.b = length3;
                    cArr = new char[length3];
                    i3 = 1;
                } else {
                    int length4 = cArr3.length;
                    hnVar.b = length4;
                    cArr = new char[length4];
                    i3 = 0;
                }
                hnVar.c = i3;
                while (true) {
                    int i14 = hnVar.c;
                    int i15 = hnVar.b;
                    if (i14 >= i15) {
                        objArr[0] = new String(cArr);
                        return;
                    }
                    cArr[i14] = (char) (cArr4[cArr3[(i15 - 1) - i14] - i2] - iIntValue);
                    Object[] objArr5 = {hnVar, hnVar};
                    Object objD4 = an.d(717234065);
                    if (objD4 == null) {
                        objD4 = an.d(ExpandableListView.getPackedPositionChild(0L) + 1971, (char) (MotionEvent.axisFromString("") + 1), 24 - TextUtils.getOffsetBefore("", 0), 1554107594, false, "x", new Class[]{Object.class, Object.class});
                    }
                    ((Method) objD4).invoke(null, objArr5);
                }
            } else {
                int i16 = 0;
                int length5 = iArr.length;
                hnVar.b = length5;
                char[] cArr6 = new char[length5];
                while (true) {
                    hnVar.c = i16;
                    int i17 = hnVar.c;
                    int i18 = hnVar.b;
                    if (i17 >= i18) {
                        objArr[0] = new String(cArr6);
                        return;
                    }
                    int i19 = $11 + 67;
                    $10 = i19 % 128;
                    if (i19 % 2 != 0) {
                        cArr6[i17] = (char) (cArr4[iArr[i18 / i17] / i2] - iIntValue);
                        i16 = i17 % 1;
                    } else {
                        cArr6[i17] = (char) (cArr4[iArr[(i18 - 1) - i17] - i2] - iIntValue);
                        i16 = i17 + 1;
                    }
                }
            }
        }

        public final boolean d() {
            int i2 = j + 25;
            i = i2 % 128;
            if (i2 % 2 != 0) {
                this.c.size();
                throw null;
            }
            if (this.d >= this.c.size()) {
                j = (i + 13) % 128;
                return false;
            }
            int i3 = j + 101;
            i = i3 % 128;
            if (i3 % 2 == 0) {
                return true;
            }
            throw null;
        }
    }

    public oa(mh mhVar, oc ocVar, mn mnVar, na naVar) {
        List<Proxy> listB;
        List list = Collections.EMPTY_LIST;
        this.b = list;
        this.f95928g = list;
        this.i = new ArrayList();
        this.d = mhVar;
        this.a = ocVar;
        this.c = mnVar;
        this.e = naVar;
        nc ncVarC = mhVar.c();
        Proxy proxy = mhVar.b;
        if (proxy != null) {
            listB = Collections.singletonList(proxy);
        } else {
            List<Proxy> listSelect = mhVar.e().select(ncVarC.c());
            listB = (listSelect == null || listSelect.isEmpty()) ? nu.b(Proxy.NO_PROXY) : nu.e(listSelect);
        }
        this.b = listB;
        this.j = 0;
    }

    public final boolean b() {
        return this.j < this.b.size();
    }

    public final boolean c() {
        return b() || !this.i.isEmpty();
    }
}