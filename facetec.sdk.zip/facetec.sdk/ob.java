package com.facetec.sdk;

import net.sf.scuba.smartcards.ISO7816;

/* JADX INFO: loaded from: classes4.dex */
public final class ob implements ne {
    private static final byte[] $$a = null;
    private static final int $$b = 0;
    private static final byte[] $$c = null;
    private static final int $$d = 0;
    private static int $10;
    private static int $11;
    private static long a;
    private static int b;
    private static int e;
    private final mr c;

    /* JADX WARN: Removed duplicated region for block: B:10:0x0026  */
    /* JADX WARN: Removed duplicated region for block: B:8:0x0020  */
    /* JADX WARN: Unsupported multi-entry loop pattern (BACK_EDGE: B:10:0x0026 -> B:11:0x002c). Please report as a decompilation issue!!! */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    private static java.lang.String $$e(byte r6, byte r7, int r8) {
        /*
            int r7 = r7 + 99
            int r6 = r6 * 3
            int r0 = 1 - r6
            int r8 = r8 * 2
            int r8 = 4 - r8
            byte[] r1 = com.facetec.sdk.ob.$$c
            byte[] r0 = new byte[r0]
            r2 = 0
            int r6 = 0 - r6
            if (r1 != 0) goto L18
            r7 = r6
            r3 = r1
            r4 = r2
            r1 = r8
            goto L2c
        L18:
            r3 = r2
        L19:
            byte r4 = (byte) r7
            r0[r3] = r4
            int r4 = r3 + 1
            if (r3 != r6) goto L26
            java.lang.String r6 = new java.lang.String
            r6.<init>(r0, r2)
            return r6
        L26:
            r3 = r1[r8]
            r5 = r1
            r1 = r8
            r8 = r3
            r3 = r5
        L2c:
            int r8 = -r8
            int r7 = r7 + r8
            int r8 = r1 + 1
            r1 = r3
            r3 = r4
            goto L19
        */
        throw new UnsupportedOperationException("Method not decompiled: com.facetec.sdk.ob.$$e(byte, byte, int):java.lang.String");
    }

    static {
        init$1();
        $10 = 0;
        $11 = 1;
        init$0();
        e = 0;
        b = 1;
        a = 1605197196617849652L;
    }

    public ob(mr mrVar) {
        this.c = mrVar;
    }

    /* JADX WARN: Removed duplicated region for block: B:36:0x0286  */
    /* JADX WARN: Removed duplicated region for block: B:87:0x029b A[EXC_TOP_SPLITTER, SYNTHETIC] */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public static java.lang.Object[] a(android.content.Context r31, int r32, int r33, int r34) throws java.lang.Throwable {
        /*
            Method dump skipped, instruction units count: 1472
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: com.facetec.sdk.ob.a(android.content.Context, int, int, int):java.lang.Object[]");
    }

    /* JADX WARN: Removed duplicated region for block: B:46:0x01e9  */
    /* JADX WARN: Removed duplicated region for block: B:47:0x01ea  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    private static void d(java.lang.String r26, int r27, java.lang.Object[] r28) throws java.lang.Throwable {
        /*
            Method dump skipped, instruction units count: 521
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: com.facetec.sdk.ob.d(java.lang.String, int, java.lang.Object[]):void");
    }

    /* JADX WARN: Removed duplicated region for block: B:10:0x0024  */
    /* JADX WARN: Removed duplicated region for block: B:8:0x001c  */
    /* JADX WARN: Unsupported multi-entry loop pattern (BACK_EDGE: B:10:0x0024 -> B:11:0x0028). Please report as a decompilation issue!!! */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    private static void f(short r5, int r6, int r7, java.lang.Object[] r8) {
        /*
            int r6 = r6 * 4
            int r0 = r6 + 1
            byte[] r1 = com.facetec.sdk.ob.$$a
            int r7 = r7 * 4
            int r7 = 3 - r7
            int r5 = r5 + 98
            byte[] r0 = new byte[r0]
            r2 = 0
            if (r1 != 0) goto L14
            r4 = r6
            r3 = r2
            goto L28
        L14:
            r3 = r2
        L15:
            int r7 = r7 + 1
            byte r4 = (byte) r5
            r0[r3] = r4
            if (r3 != r6) goto L24
            java.lang.String r5 = new java.lang.String
            r5.<init>(r0, r2)
            r8[r2] = r5
            return
        L24:
            int r3 = r3 + 1
            r4 = r1[r7]
        L28:
            int r5 = r5 + r4
            goto L15
        */
        throw new UnsupportedOperationException("Method not decompiled: com.facetec.sdk.ob.f(short, int, int, java.lang.Object[]):void");
    }

    public static void init$0() {
        $$a = new byte[]{69, ISO7816.INS_PUT_DATA, -90, 81};
        $$b = 118;
    }

    public static void init$1() {
        $$c = new byte[]{69, -50, 81, 75};
        $$d = 10;
    }

    /* JADX WARN: Removed duplicated region for block: B:30:0x00aa  */
    /* JADX WARN: Removed duplicated region for block: B:31:0x00af  */
    @Override // com.facetec.sdk.ne
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public final com.facetec.sdk.nh c(com.facetec.sdk.ne.c r17) {
        /*
            Method dump skipped, instruction units count: 374
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: com.facetec.sdk.ob.c(com.facetec.sdk.ne$c):com.facetec.sdk.nh");
    }
}