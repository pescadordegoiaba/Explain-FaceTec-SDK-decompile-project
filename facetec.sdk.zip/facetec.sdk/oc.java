package com.facetec.sdk;

import java.util.LinkedHashSet;
import java.util.Set;

/* JADX INFO: loaded from: classes4.dex */
public final class oc {
    private final Set<nm> e = new LinkedHashSet();

    public final synchronized boolean a(nm nmVar) {
        return this.e.contains(nmVar);
    }

    public final synchronized void b(nm nmVar) {
        this.e.remove(nmVar);
    }

    public final synchronized void c(nm nmVar) {
        this.e.add(nmVar);
    }
}