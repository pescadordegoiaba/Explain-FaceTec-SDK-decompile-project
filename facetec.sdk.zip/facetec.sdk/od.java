package com.facetec.sdk;

import java.io.IOException;

/* JADX INFO: loaded from: classes4.dex */
public final class od extends RuntimeException {
    public IOException a;
    public IOException d;

    public od(IOException iOException) {
        super(iOException);
        this.a = iOException;
        this.d = iOException;
    }
}