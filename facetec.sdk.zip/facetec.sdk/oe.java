package com.facetec.sdk;

import android.os.Process;
import android.os.SystemClock;
import android.view.Gravity;
import android.view.View;
import android.view.ViewConfiguration;
import com.facetec.sdk.ne;
import com.facetec.sdk.oa;
import com.plaid.internal.EnumC41897g;
import java.io.IOException;
import java.lang.ref.WeakReference;
import java.lang.reflect.Method;
import java.net.Proxy;
import java.net.Socket;
import java.util.concurrent.TimeUnit;
import net.sf.scuba.smartcards.ISOFileInfo;

/* JADX INFO: loaded from: classes4.dex */
public final class oe {
    private static final byte[] $$a = null;
    private static final int $$b = 0;
    public static final /* synthetic */ boolean h;
    private static long r;
    public final na a;
    public nx b;
    public final mn c;
    public nm d;
    public final mv e;
    public boolean f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    private oa.a f95930g;
    private mh i;
    public oi j;
    private final oa k;
    private boolean l;
    private final Object m;
    private int n;
    private boolean o;

    public static final class b extends WeakReference<oe> {
        public static int a;
        public static int b;
        public final Object e;

        public b(oe oeVar, Object obj) {
            super(oeVar);
            this.e = obj;
        }

        public static int d() {
            int i = b;
            int i2 = i % 9685708;
            b = i + 1;
            if (i2 != 0) {
                return a;
            }
            int iMaxMemory = (int) Runtime.getRuntime().maxMemory();
            a = iMaxMemory;
            return iMaxMemory;
        }
    }

    /* JADX WARN: Removed duplicated region for block: B:10:0x0024  */
    /* JADX WARN: Removed duplicated region for block: B:8:0x001e  */
    /* JADX WARN: Unsupported multi-entry loop pattern (BACK_EDGE: B:10:0x0024 -> B:11:0x0026). Please report as a decompilation issue!!! */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    private static java.lang.String $$c(byte r6, byte r7, byte r8) {
        /*
            int r7 = r7 * 2
            int r7 = r7 + 1
            int r8 = r8 * 2
            int r8 = 73 - r8
            byte[] r0 = com.facetec.sdk.oe.$$a
            int r6 = r6 * 4
            int r6 = r6 + 4
            byte[] r1 = new byte[r7]
            r2 = 0
            if (r0 != 0) goto L16
            r3 = r7
            r5 = r2
            goto L26
        L16:
            r3 = r2
        L17:
            byte r4 = (byte) r8
            int r5 = r3 + 1
            r1[r3] = r4
            if (r5 != r7) goto L24
            java.lang.String r6 = new java.lang.String
            r6.<init>(r1, r2)
            return r6
        L24:
            r3 = r0[r6]
        L26:
            int r6 = r6 + 1
            int r3 = -r3
            int r8 = r8 + r3
            r3 = r5
            goto L17
        */
        throw new UnsupportedOperationException("Method not decompiled: com.facetec.sdk.oe.$$c(byte, byte, byte):java.lang.String");
    }

    static {
        init$0();
        h();
        h = true;
    }

    public oe(mv mvVar, mh mhVar, mn mnVar, na naVar, Object obj) {
        this.e = mvVar;
        this.i = mhVar;
        this.c = mnVar;
        this.a = naVar;
        this.k = new oa(mhVar, g(), mnVar, naVar);
        this.m = obj;
    }

    private nx c(int i, int i2, int i3, int i4, boolean z, boolean z2) throws Throwable {
        while (true) {
            nx nxVarD = d(i, i2, i3, i4, z);
            boolean z3 = z;
            int i5 = i4;
            int i6 = i3;
            int i7 = i2;
            int i8 = i;
            synchronized (this.e) {
                if (nxVarD.l == 0 && !nxVarD.e()) {
                    return nxVarD;
                }
                if (nxVarD.b(z2)) {
                    return nxVarD;
                }
                c();
                i = i8;
                i2 = i7;
                i3 = i6;
                i4 = i5;
                z = z3;
            }
        }
    }

    private oc g() {
        return nn.d.c(this.e);
    }

    public static void h() {
        r = 1719013369111783762L;
    }

    public static void init$0() {
        $$a = new byte[]{93, 49, 76, ISOFileInfo.CHANNEL_SECURITY};
        $$b = 13;
    }

    private static void p(String str, int i, Object[] objArr) throws Throwable {
        char[] charArray = str != null ? str.toCharArray() : str;
        hl hlVar = new hl();
        char[] cArrB = hl.b(r ^ (-1723600592890876272L), charArray, i);
        hlVar.e = 4;
        while (true) {
            int i2 = hlVar.e;
            if (i2 >= cArrB.length) {
                objArr[0] = new String(cArrB, 4, cArrB.length - 4);
                return;
            }
            int i3 = i2 - 4;
            hlVar.d = i3;
            try {
                Object[] objArr2 = {Long.valueOf(cArrB[i2] ^ cArrB[i2 % 4]), Long.valueOf(i3), Long.valueOf(r)};
                Object objD = an.d(-291407824);
                if (objD == null) {
                    int iMyTid = (Process.myTid() >> 22) + 2589;
                    char cMakeMeasureSpec = (char) View.MeasureSpec.makeMeasureSpec(0, 0);
                    int i4 = (SystemClock.elapsedRealtimeNanos() > 0L ? 1 : (SystemClock.elapsedRealtimeNanos() == 0L ? 0 : -1)) + 22;
                    byte b2 = (byte) 0;
                    byte b3 = b2;
                    String str$$c = $$c(b2, b3, b3);
                    Class cls = Long.TYPE;
                    objD = an.d(iMyTid, cMakeMeasureSpec, i4, -1732203669, false, str$$c, new Class[]{cls, cls, cls});
                }
                cArrB[i2] = ((Character) ((Method) objD).invoke(null, objArr2)).charValue();
                Object[] objArr3 = {hlVar, hlVar};
                Object objD2 = an.d(1066529625);
                if (objD2 == null) {
                    objD2 = an.d(View.MeasureSpec.getMode(0) + EnumC41897g.SDK_ASSET_PLAID_LOGO_LOADING_INDICATOR_SUCCESS_VALUE, (char) Gravity.getAbsoluteGravity(0, 0), (ViewConfiguration.getMaximumDrawingCacheSize() >> 24) + 23, 1240473602, false, "G", new Class[]{Object.class, Object.class});
                }
                ((Method) objD2).invoke(null, objArr3);
            } catch (Throwable th) {
                Throwable cause = th.getCause();
                if (cause == null) {
                    throw th;
                }
                throw cause;
            }
        }
    }

    public final void a(IOException iOException) {
        boolean z;
        Socket socketD;
        synchronized (this.e) {
            try {
                if (iOException instanceof pi) {
                    or orVar = ((pi) iOException).a;
                    if (orVar == or.REFUSED_STREAM) {
                        int i = this.n + 1;
                        this.n = i;
                        if (i > 1) {
                            this.d = null;
                            z = true;
                        }
                    } else if (orVar != or.CANCEL) {
                        this.d = null;
                        z = true;
                    }
                    z = false;
                } else {
                    nx nxVar = this.b;
                    if (nxVar != null && (!nxVar.e() || (iOException instanceof oq))) {
                        if (this.b.l == 0) {
                            nm nmVar = this.d;
                            if (nmVar != null && iOException != null) {
                                oa oaVar = this.k;
                                if (nmVar.e().type() != Proxy.Type.DIRECT && oaVar.d.e() != null) {
                                    oaVar.d.e().connectFailed(oaVar.d.c().c(), nmVar.e().address(), iOException);
                                }
                                oaVar.a.c(nmVar);
                            }
                            this.d = null;
                        }
                        z = true;
                    }
                    z = false;
                }
                socketD = d(z, false, true);
                if (this.b == null) {
                    boolean z2 = this.l;
                }
            } catch (Throwable th) {
                throw th;
            }
        }
        nu.d(socketD);
    }

    public final void b(boolean z, oi oiVar, IOException iOException) {
        Socket socketD;
        boolean z2;
        synchronized (this.e) {
            if (oiVar != null) {
                try {
                    if (oiVar == this.j) {
                        if (!z) {
                            this.b.l++;
                        }
                        socketD = d(z, false, true);
                        z2 = this.o;
                    }
                } catch (Throwable th) {
                    throw th;
                }
            }
            StringBuilder sb = new StringBuilder("expected ");
            sb.append(this.j);
            sb.append(" but was ");
            sb.append(oiVar);
            throw new IllegalStateException(sb.toString());
        }
        nu.d(socketD);
        mn mnVar = this.c;
        if (iOException != null) {
            nn.d.b(mnVar, iOException);
        } else if (z2) {
            nn.d.b(mnVar, (IOException) null);
        }
    }

    public final oi d(nf nfVar, ne.c cVar, boolean z) throws Throwable {
        oi opVar;
        try {
            nx nxVarC = c(cVar.a(), cVar.b(), cVar.c(), nfVar.o, nfVar.o(), z);
            if (nxVarC.f95926g != null) {
                opVar = new ow(nfVar, cVar, this, nxVarC.f95926g);
            } else {
                nxVarC.c.setSoTimeout(cVar.b());
                qp qpVarA = nxVarC.h.a();
                long jB = cVar.b();
                TimeUnit timeUnit = TimeUnit.MILLISECONDS;
                qpVarA.b(jB, timeUnit);
                nxVarC.j.a().b(cVar.c(), timeUnit);
                opVar = new op(nfVar, this, nxVarC.h, nxVarC.j);
            }
            synchronized (this.e) {
                this.j = opVar;
            }
            return opVar;
        } catch (IOException e) {
            throw new od(e);
        }
    }

    public final oi e() {
        oi oiVar;
        synchronized (this.e) {
            oiVar = this.j;
        }
        return oiVar;
    }

    public final String toString() {
        nx nxVarB = b();
        return nxVarB != null ? nxVarB.toString() : this.i.toString();
    }

    public final void c() {
        Socket socketD;
        synchronized (this.e) {
            socketD = d(true, false, false);
        }
        nu.d(socketD);
    }

    public final synchronized nx b() {
        return this.b;
    }

    public final void c(nx nxVar, boolean z) {
        if (!h && !Thread.holdsLock(this.e)) {
            throw new AssertionError();
        }
        if (this.b == null) {
            this.b = nxVar;
            this.l = z;
            nxVar.k.add(new b(this, this.m));
            return;
        }
        throw new IllegalStateException();
    }

    /* JADX WARN: Code restructure failed: missing block: B:167:0x0483, code lost:
    
        throw new java.io.IOException("TLS tunnel buffered too many bytes!");
     */
    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Removed duplicated region for block: B:280:0x072a  */
    /* JADX WARN: Removed duplicated region for block: B:281:0x0730  */
    /* JADX WARN: Removed duplicated region for block: B:283:0x0739  */
    /* JADX WARN: Removed duplicated region for block: B:347:0x0764 A[SYNTHETIC] */
    /* JADX WARN: Type inference failed for: r12v17, types: [com.facetec.sdk.nn] */
    /* JADX WARN: Type inference failed for: r7v11, types: [com.facetec.sdk.pm] */
    /* JADX WARN: Type inference failed for: r8v0 */
    /* JADX WARN: Type inference failed for: r8v1 */
    /* JADX WARN: Type inference failed for: r8v11 */
    /* JADX WARN: Type inference failed for: r8v12, types: [java.net.Socket, javax.net.ssl.SSLSocket] */
    /* JADX WARN: Type inference failed for: r8v13 */
    /* JADX WARN: Type inference failed for: r8v2 */
    /* JADX WARN: Type inference failed for: r8v26 */
    /* JADX WARN: Type inference failed for: r8v28 */
    /* JADX WARN: Type inference failed for: r8v29, types: [int] */
    /* JADX WARN: Type inference failed for: r8v3 */
    /* JADX WARN: Type inference failed for: r8v30 */
    /* JADX WARN: Type inference failed for: r8v32, types: [com.facetec.sdk.nm] */
    /* JADX WARN: Type inference failed for: r8v4 */
    /* JADX WARN: Type inference failed for: r8v46 */
    /* JADX WARN: Type inference failed for: r8v47 */
    /* JADX WARN: Type inference failed for: r8v48 */
    /* JADX WARN: Type inference failed for: r8v49 */
    /* JADX WARN: Type inference failed for: r8v5, types: [boolean] */
    /* JADX WARN: Type inference failed for: r8v50 */
    /* JADX WARN: Type inference failed for: r8v51 */
    /* JADX WARN: Type inference fix 'apply assigned field type' failed
    java.lang.UnsupportedOperationException: ArgType.getObject(), call class: class jadx.core.dex.instructions.args.ArgType$UnknownArg
    	at jadx.core.dex.instructions.args.ArgType.getObject(ArgType.java:593)
    	at jadx.core.dex.attributes.nodes.ClassTypeVarsAttr.getTypeVarsMapFor(ClassTypeVarsAttr.java:35)
    	at jadx.core.dex.nodes.utils.TypeUtils.replaceClassGenerics(TypeUtils.java:177)
    	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.insertExplicitUseCast(FixTypesVisitor.java:397)
    	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.tryFieldTypeWithNewCasts(FixTypesVisitor.java:359)
    	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.applyFieldType(FixTypesVisitor.java:309)
    	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.visit(FixTypesVisitor.java:94)
     */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    private com.facetec.sdk.nx d(int r34, int r35, int r36, int r37, boolean r38) throws java.lang.Throwable {
        /*
            Method dump skipped, instruction units count: 1950
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: com.facetec.sdk.oe.d(int, int, int, int, boolean):com.facetec.sdk.nx");
    }

    private void c(nx nxVar) {
        int size = nxVar.k.size();
        for (int i = 0; i < size; i++) {
            if (nxVar.k.get(i).get() == this) {
                nxVar.k.remove(i);
                return;
            }
        }
        throw new IllegalStateException();
    }

    public final boolean a() {
        if (this.d != null) {
            return true;
        }
        oa.a aVar = this.f95930g;
        return (aVar != null && aVar.d()) || this.k.c();
    }

    public final void d() {
        nx nxVar;
        Socket socketD;
        synchronized (this.e) {
            nxVar = this.b;
            socketD = d(false, true, false);
            if (this.b != null) {
                nxVar = null;
            }
        }
        nu.d(socketD);
        if (nxVar != null) {
            nn.d.b(this.c, (IOException) null);
        }
    }

    /* JADX WARN: Removed duplicated region for block: B:37:0x0094  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public final java.net.Socket d(boolean r6, boolean r7, boolean r8) {
        /*
            r5 = this;
            boolean r0 = com.facetec.sdk.oe.h
            if (r0 != 0) goto L13
            com.facetec.sdk.mv r0 = r5.e
            boolean r0 = java.lang.Thread.holdsLock(r0)
            if (r0 == 0) goto Ld
            goto L13
        Ld:
            java.lang.AssertionError r6 = new java.lang.AssertionError
            r6.<init>()
            throw r6
        L13:
            r0 = 0
            if (r8 == 0) goto L18
            r5.j = r0
        L18:
            r8 = 1
            if (r7 == 0) goto L1d
            r5.o = r8
        L1d:
            com.facetec.sdk.nx r7 = r5.b
            if (r7 == 0) goto L98
            if (r6 == 0) goto L25
            r7.f = r8
        L25:
            com.facetec.sdk.oi r6 = r5.j
            if (r6 != 0) goto L98
            boolean r6 = r5.o
            if (r6 != 0) goto L31
            boolean r6 = r7.f
            if (r6 == 0) goto L98
        L31:
            r5.c(r7)
            com.facetec.sdk.nx r6 = r5.b
            java.util.List<java.lang.ref.Reference<com.facetec.sdk.oe>> r6 = r6.k
            boolean r6 = r6.isEmpty()
            if (r6 == 0) goto L94
            com.facetec.sdk.nx r6 = r5.b
            java.lang.String r7 = "催僆牸赡遼痛芓\ueee4侊哞ꎌ쿣滛㞄삦곬\u0dc7ᛖ\ue198跰"
            int r1 = android.view.ViewConfiguration.getPressedStateDuration()     // Catch: java.lang.Throwable -> L8b
            int r1 = r1 >> 16
            java.lang.Object[] r2 = new java.lang.Object[r8]     // Catch: java.lang.Throwable -> L8b
            p(r7, r1, r2)     // Catch: java.lang.Throwable -> L8b
            r7 = 0
            r1 = r2[r7]     // Catch: java.lang.Throwable -> L8b
            java.lang.String r1 = (java.lang.String) r1     // Catch: java.lang.Throwable -> L8b
            java.lang.Class r1 = java.lang.Class.forName(r1)     // Catch: java.lang.Throwable -> L8b
            java.lang.String r2 = "솗쇹▮̖䰗∍\u0cfc嬾\udecb̍ⷷ稼"
            int r3 = android.graphics.Color.rgb(r7, r7, r7)     // Catch: java.lang.Throwable -> L8b
            r4 = -16777216(0xffffffffff000000, float:-1.7014118E38)
            int r4 = r4 - r3
            java.lang.Object[] r8 = new java.lang.Object[r8]     // Catch: java.lang.Throwable -> L8b
            p(r2, r4, r8)     // Catch: java.lang.Throwable -> L8b
            r7 = r8[r7]     // Catch: java.lang.Throwable -> L8b
            java.lang.String r7 = (java.lang.String) r7     // Catch: java.lang.Throwable -> L8b
            java.lang.reflect.Method r7 = r1.getMethod(r7, r0)     // Catch: java.lang.Throwable -> L8b
            java.lang.Object r7 = r7.invoke(r0, r0)     // Catch: java.lang.Throwable -> L8b
            java.lang.Long r7 = (java.lang.Long) r7     // Catch: java.lang.Throwable -> L8b
            long r7 = r7.longValue()     // Catch: java.lang.Throwable -> L8b
            r6.n = r7
            com.facetec.sdk.nn r6 = com.facetec.sdk.nn.d
            com.facetec.sdk.mv r7 = r5.e
            com.facetec.sdk.nx r8 = r5.b
            boolean r6 = r6.a(r7, r8)
            if (r6 == 0) goto L94
            com.facetec.sdk.nx r6 = r5.b
            java.net.Socket r6 = r6.d()
            goto L95
        L8b:
            r6 = move-exception
            java.lang.Throwable r7 = r6.getCause()
            if (r7 == 0) goto L93
            throw r7
        L93:
            throw r6
        L94:
            r6 = r0
        L95:
            r5.b = r0
            return r6
        L98:
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: com.facetec.sdk.oe.d(boolean, boolean, boolean):java.net.Socket");
    }
}