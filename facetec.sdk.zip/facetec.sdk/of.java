package com.facetec.sdk;

import ai.luciq.library.networkv2.request.Header;
import android.graphics.Color;
import android.graphics.drawable.Drawable;
import android.os.Process;
import android.os.SystemClock;
import android.telephony.cdma.CdmaCellLocation;
import android.text.TextUtils;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.ViewConfiguration;
import android.widget.ExpandableListView;
import com.facetec.sdk.ne;
import com.facetec.sdk.nh;
import com.incode.welcome_sdk.modules.SelfieScan;
import com.plaid.internal.EnumC41897g;
import java.net.ProtocolException;
import net.sf.scuba.smartcards.ISOFileInfo;
import org.jmrtd.PassportService;

/* JADX INFO: loaded from: classes4.dex */
public final class of implements ne {
    private static final byte[] $$a = null;
    private static final int $$b = 0;
    private static char[] a;
    private static long c;
    private final boolean e;

    public static final class c extends qa {
        public static int a;
        public static int b;
        long c;

        public c(qj qjVar) {
            super(qjVar);
        }

        public static int e() {
            int i = a;
            int i2 = i % 5463475;
            a = i + 1;
            if (i2 != 0) {
                return b;
            }
            int iMyTid = Process.myTid();
            b = iMyTid;
            return iMyTid;
        }

        @Override // com.facetec.sdk.qa, com.facetec.sdk.qj
        public final void a(px pxVar, long j) {
            super.a(pxVar, j);
            this.c += j;
        }
    }

    /* JADX WARN: Removed duplicated region for block: B:10:0x0024  */
    /* JADX WARN: Removed duplicated region for block: B:8:0x001e  */
    /* JADX WARN: Unsupported multi-entry loop pattern (BACK_EDGE: B:10:0x0024 -> B:11:0x002b). Please report as a decompilation issue!!! */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    private static java.lang.String $$c(short r6, int r7, byte r8) {
        /*
            int r6 = r6 + 4
            int r8 = 111 - r8
            int r7 = r7 * 4
            int r0 = r7 + 1
            byte[] r1 = com.facetec.sdk.of.$$a
            byte[] r0 = new byte[r0]
            r2 = 0
            if (r1 != 0) goto L14
            r8 = r6
            r3 = r1
            r4 = r2
            r1 = r7
            goto L2b
        L14:
            r3 = r2
        L15:
            int r6 = r6 + 1
            byte r4 = (byte) r8
            r0[r3] = r4
            int r4 = r3 + 1
            if (r3 != r7) goto L24
            java.lang.String r6 = new java.lang.String
            r6.<init>(r0, r2)
            return r6
        L24:
            r3 = r1[r6]
            r5 = r8
            r8 = r6
            r6 = r3
            r3 = r1
            r1 = r5
        L2b:
            int r6 = -r6
            int r6 = r6 + r1
            r1 = r8
            r8 = r6
            r6 = r1
            r1 = r3
            r3 = r4
            goto L15
        */
        throw new UnsupportedOperationException("Method not decompiled: com.facetec.sdk.of.$$c(short, int, byte):java.lang.String");
    }

    static {
        init$0();
        a = new char[]{53690, 28524, 44060, 60710, 10890, 27629, 43167, 59829, 10079, 25659, 42273, 58070, 9215, 24733, 41379, 65358, 61772, 20359, 36071, 52682, 2622, 19216, 34933, 51568, 1966, 17543, 34280, 49693, 794, 16506, 33109, 57269, 7308};
        c = -5231579541593498485L;
    }

    public of(boolean z) {
        this.e = z;
    }

    /* JADX WARN: Removed duplicated region for block: B:35:0x0176  */
    /* JADX WARN: Removed duplicated region for block: B:36:0x0177  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    private static void b(int r23, char r24, int r25, java.lang.Object[] r26) throws java.lang.Throwable {
        /*
            Method dump skipped, instruction units count: 384
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: com.facetec.sdk.of.b(int, char, int, java.lang.Object[]):void");
    }

    public static void init$0() {
        $$a = new byte[]{ISOFileInfo.FCI_BYTE, -17, PassportService.SFI_DG11, ISOFileInfo.FILE_IDENTIFIER};
        $$b = EnumC41897g.SDK_ASSET_ILLUSTRATION_INFOCARD_BANKSTATEMENT_VALUE;
    }

    @Override // com.facetec.sdk.ne
    public final nh c(ne.c cVar) throws Throwable {
        double d;
        nh.e eVarC;
        oo ooVar = (oo) cVar;
        oi oiVar = ooVar.c;
        oe oeVarE = ooVar.e();
        nx nxVar = ooVar.e;
        nj njVarD = ooVar.d();
        try {
            Object[] objArr = new Object[1];
            b(ViewConfiguration.getScrollBarFadeDuration() >> 16, (char) (Gravity.getAbsoluteGravity(0, 0) + 13190), 16 - TextUtils.getCapsMode("", 0, 0), objArr);
            Class<?> cls = Class.forName((String) objArr[0]);
            Object[] objArr2 = new Object[1];
            b(Color.rgb(0, 0, 0) + 16777232, (char) (TextUtils.lastIndexOf("", '0', 0, 0) + 4986), (CdmaCellLocation.convertQuartSecToDecDegrees(0) > 0.0d ? 1 : (CdmaCellLocation.convertQuartSecToDecDegrees(0) == 0.0d ? 0 : -1)) + 17, objArr2);
            long jLongValue = ((Long) cls.getMethod((String) objArr2[0], null).invoke(null, null)).longValue();
            ooVar.i();
            ooVar.g();
            oiVar.d(njVarD);
            ooVar.i();
            ooVar.g();
            if (!oj.b(njVarD.c()) || njVarD.e() == null) {
                d = 0.0d;
                eVarC = null;
            } else {
                if ("100-continue".equalsIgnoreCase(njVarD.a("Expect"))) {
                    oiVar.b();
                    ooVar.i();
                    ooVar.g();
                    eVarC = oiVar.c(true);
                } else {
                    eVarC = null;
                }
                if (eVarC == null) {
                    ooVar.i();
                    ooVar.g();
                    d = 0.0d;
                    pu puVarE = qf.e(new c(oiVar.a(njVarD, njVarD.e().d())));
                    njVarD.e().b(puVarE);
                    puVarE.close();
                    ooVar.i();
                    ooVar.g();
                } else {
                    d = 0.0d;
                    if (!nxVar.e()) {
                        oeVarE.c();
                    }
                }
            }
            oiVar.a();
            if (eVarC == null) {
                ooVar.i();
                ooVar.g();
                eVarC = oiVar.c(false);
            }
            nh.e eVarC2 = eVarC.c(njVarD).c(oeVarE.b().a()).c(jLongValue);
            Object[] objArr3 = new Object[1];
            b(ViewConfiguration.getKeyRepeatDelay() >> 16, (char) (Drawable.resolveOpacity(0, 0) + 13190), 16 - Gravity.getAbsoluteGravity(0, 0), objArr3);
            Class<?> cls2 = Class.forName((String) objArr3[0]);
            Object[] objArr4 = new Object[1];
            b(17 - (SystemClock.elapsedRealtime() > 0L ? 1 : (SystemClock.elapsedRealtime() == 0L ? 0 : -1)), (char) (((Process.getThreadPriority(0) + 20) >> 6) + 4985), 16 - (ExpandableListView.getPackedPositionForChild(0, 0) > 0L ? 1 : (ExpandableListView.getPackedPositionForChild(0, 0) == 0L ? 0 : -1)), objArr4);
            nh nhVarA = eVarC2.d(((Long) cls2.getMethod((String) objArr4[0], null).invoke(null, null)).longValue()).a();
            int iD = nhVarA.d();
            if (iD == 100) {
                nh.e eVarC3 = oiVar.c(false).c(njVarD).c(oeVarE.b().a()).c(jLongValue);
                Object[] objArr5 = new Object[1];
                b((-1) - ((byte) KeyEvent.getModifierMetaStateMask()), (char) (13191 - (ViewConfiguration.getScrollFriction() > SelfieScan.RECOGNITION_FAIL_RESULT ? 1 : (ViewConfiguration.getScrollFriction() == SelfieScan.RECOGNITION_FAIL_RESULT ? 0 : -1))), 16 - (CdmaCellLocation.convertQuartSecToDecDegrees(0) > d ? 1 : (CdmaCellLocation.convertQuartSecToDecDegrees(0) == d ? 0 : -1)), objArr5);
                Class<?> cls3 = Class.forName((String) objArr5[0]);
                Object[] objArr6 = new Object[1];
                b(17 - (SystemClock.uptimeMillis() > 0L ? 1 : (SystemClock.uptimeMillis() == 0L ? 0 : -1)), (char) ((ViewConfiguration.getScrollBarSize() >> 8) + 4985), 16 - ((byte) KeyEvent.getModifierMetaStateMask()), objArr6);
                nhVarA = eVarC3.d(((Long) cls3.getMethod((String) objArr6[0], null).invoke(null, null)).longValue()).a();
                iD = nhVarA.d();
            }
            ooVar.i();
            ooVar.g();
            nh nhVarA2 = (this.e && iD == 101) ? nhVarA.f().b(nu.b).a() : nhVarA.f().b(oiVar.c(nhVarA)).a();
            if ("close".equalsIgnoreCase(nhVarA2.c().a(Header.CONNECTION)) || "close".equalsIgnoreCase(nhVarA2.a(Header.CONNECTION))) {
                oeVarE.c();
            }
            if ((iD != 204 && iD != 205) || nhVarA2.e().e() <= 0) {
                return nhVarA2;
            }
            StringBuilder sb = new StringBuilder("HTTP ");
            sb.append(iD);
            sb.append(" had non-zero Content-Length: ");
            sb.append(nhVarA2.e().e());
            throw new ProtocolException(sb.toString());
        } catch (Throwable th) {
            Throwable cause = th.getCause();
            if (cause != null) {
                throw cause;
            }
            throw th;
        }
    }
}