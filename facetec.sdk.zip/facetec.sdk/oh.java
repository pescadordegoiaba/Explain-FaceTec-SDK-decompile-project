package com.facetec.sdk;

/* JADX INFO: loaded from: classes4.dex */
public final class oh {
    static {
        qb.d("\"\\");
        qb.d("\t ,=");
    }

    public static boolean a(nh nhVar) {
        if (nhVar.c().c().equals("HEAD")) {
            return false;
        }
        int iD = nhVar.d();
        return (((iD >= 100 && iD < 200) || iD == 204 || iD == 304) && d(nhVar) == -1 && !"chunked".equalsIgnoreCase(nhVar.a("Transfer-Encoding"))) ? false : true;
    }

    private static long c(String str) {
        if (str == null) {
            return -1L;
        }
        try {
            return Long.parseLong(str);
        } catch (NumberFormatException unused) {
            return -1L;
        }
    }

    public static long d(nh nhVar) {
        return c(nhVar.b().a("Content-Length"));
    }

    public static void e(mr mrVar, nc ncVar, mz mzVar) {
        if (mrVar == mr.a) {
            return;
        }
        ms.b(ncVar, mzVar).isEmpty();
    }

    public static int d(String str, int i, String str2) {
        while (i < str.length() && str2.indexOf(str.charAt(i)) == -1) {
            i++;
        }
        return i;
    }

    public static int e(String str, int i) {
        char cCharAt;
        while (i < str.length() && ((cCharAt = str.charAt(i)) == ' ' || cCharAt == '\t')) {
            i++;
        }
        return i;
    }

    public static int d(String str, int i) {
        try {
            long j = Long.parseLong(str);
            if (j > 2147483647L) {
                return Integer.MAX_VALUE;
            }
            if (j < 0) {
                return 0;
            }
            return (int) j;
        } catch (NumberFormatException unused) {
            return i;
        }
    }
}