package com.facetec.sdk;

import com.facetec.sdk.nh;

/* JADX INFO: loaded from: classes4.dex */
public interface oi {
    qj a(nj njVar, long j);

    void a();

    void b();

    nh.e c(boolean z);

    no c(nh nhVar);

    void d(nj njVar);

    void e();
}