package com.facetec.sdk;

import ai.luciq.library.networkv2.request.RequestMethod;

/* JADX INFO: loaded from: classes4.dex */
public final class oj {
    public static boolean b(String str) {
        return (str.equals(RequestMethod.GET) || str.equals("HEAD")) ? false : true;
    }

    public static boolean c(String str) {
        return str.equals(RequestMethod.POST) || str.equals(RequestMethod.PUT) || str.equals("PATCH") || str.equals("PROPPATCH") || str.equals("REPORT");
    }
}