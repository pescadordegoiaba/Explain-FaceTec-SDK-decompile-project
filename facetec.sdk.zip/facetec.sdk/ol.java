package com.facetec.sdk;

import com.plaid.internal.EnumC41897g;
import java.io.IOException;
import java.io.InterruptedIOException;
import java.net.ProtocolException;
import java.net.SocketTimeoutException;
import java.security.cert.CertificateException;
import javax.net.ssl.HostnameVerifier;
import javax.net.ssl.SSLHandshakeException;
import javax.net.ssl.SSLPeerUnverifiedException;
import javax.net.ssl.SSLSocketFactory;

/* JADX INFO: loaded from: classes4.dex */
public final class ol implements ne {
    private static final byte[] $$a = null;
    private static final int $$b = 0;
    private static final byte[] $$c = null;
    private static final int $$d = 0;
    private static int $10;
    private static int $11;
    private static int h;
    private static long i;
    private static int j;
    public Object a;
    public volatile boolean b;
    public volatile oe c;
    private final boolean d;
    private final nf e;

    /* JADX WARN: Removed duplicated region for block: B:10:0x0024  */
    /* JADX WARN: Removed duplicated region for block: B:8:0x001e  */
    /* JADX WARN: Unsupported multi-entry loop pattern (BACK_EDGE: B:10:0x0024 -> B:11:0x002a). Please report as a decompilation issue!!! */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    private static java.lang.String $$e(int r7, byte r8, byte r9) {
        /*
            int r7 = r7 + 99
            byte[] r0 = com.facetec.sdk.ol.$$c
            int r9 = r9 * 2
            int r9 = r9 + 1
            int r8 = r8 * 4
            int r8 = r8 + 4
            byte[] r1 = new byte[r9]
            r2 = 0
            if (r0 != 0) goto L16
            r7 = r9
            r3 = r0
            r4 = r2
            r0 = r8
            goto L2a
        L16:
            r3 = r2
        L17:
            int r4 = r3 + 1
            byte r5 = (byte) r7
            r1[r3] = r5
            if (r4 != r9) goto L24
            java.lang.String r7 = new java.lang.String
            r7.<init>(r1, r2)
            return r7
        L24:
            r3 = r0[r8]
            r6 = r0
            r0 = r8
            r8 = r3
            r3 = r6
        L2a:
            int r8 = -r8
            int r7 = r7 + r8
            int r8 = r0 + 1
            r0 = r3
            r3 = r4
            goto L17
        */
        throw new UnsupportedOperationException("Method not decompiled: com.facetec.sdk.ol.$$e(int, byte, byte):java.lang.String");
    }

    static {
        init$1();
        $10 = 0;
        $11 = 1;
        init$0();
        h = 0;
        j = 1;
        i = 337683963694202110L;
    }

    public ol(nf nfVar, boolean z) {
        this.e = nfVar;
        this.d = z;
    }

    private mh b(nc ncVar) {
        SSLSocketFactory sSLSocketFactory;
        HostnameVerifier hostnameVerifier;
        mp mpVar;
        SSLSocketFactory sSLSocketFactoryJ;
        HostnameVerifier hostnameVerifierH;
        mp mpVarF;
        if (!(!ncVar.b())) {
            int i2 = h + 103;
            j = i2 % 128;
            if (i2 % 2 == 0) {
                sSLSocketFactoryJ = this.e.j();
                hostnameVerifierH = this.e.h();
                mpVarF = this.e.f();
                int i3 = 78 / 0;
            } else {
                sSLSocketFactoryJ = this.e.j();
                hostnameVerifierH = this.e.h();
                mpVarF = this.e.f();
            }
            sSLSocketFactory = sSLSocketFactoryJ;
            hostnameVerifier = hostnameVerifierH;
            mpVar = mpVarF;
        } else {
            sSLSocketFactory = null;
            hostnameVerifier = null;
            mpVar = null;
        }
        mh mhVar = new mh(ncVar.g(), ncVar.h(), this.e.e(), this.e.a(), sSLSocketFactory, hostnameVerifier, mpVar, this.e.i(), this.e.d(), this.e.n(), this.e.k(), this.e.c());
        int i4 = h + 53;
        j = i4 % 128;
        if (i4 % 2 == 0) {
            int i5 = 32 / 0;
        }
        return mhVar;
    }

    private boolean d(IOException iOException, oe oeVar, boolean z, nj njVar) {
        oeVar.a(iOException);
        if (!this.e.o()) {
            return false;
        }
        if (z) {
            j = (h + 105) % 128;
            if (e(iOException, njVar)) {
                j = (h + 41) % 128;
                return false;
            }
        }
        if (!c(iOException, z)) {
            h = (j + 13) % 128;
            return false;
        }
        if (oeVar.a()) {
            return true;
        }
        h = (j + 89) % 128;
        return false;
    }

    /* JADX WARN: Removed duplicated region for block: B:33:0x0147  */
    /* JADX WARN: Removed duplicated region for block: B:34:0x0148  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    private static void f(java.lang.String r23, int r24, java.lang.Object[] r25) throws java.lang.Throwable {
        /*
            Method dump skipped, instruction units count: 337
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: com.facetec.sdk.ol.f(java.lang.String, int, java.lang.Object[]):void");
    }

    /* JADX WARN: Removed duplicated region for block: B:10:0x0028  */
    /* JADX WARN: Removed duplicated region for block: B:8:0x0020  */
    /* JADX WARN: Unsupported multi-entry loop pattern (BACK_EDGE: B:10:0x0028 -> B:11:0x0032). Please report as a decompilation issue!!! */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    private static void g(byte r6, byte r7, int r8, java.lang.Object[] r9) {
        /*
            int r8 = r8 * 4
            int r8 = 4 - r8
            byte[] r0 = com.facetec.sdk.ol.$$a
            int r6 = r6 + 98
            int r7 = r7 * 3
            int r1 = 1 - r7
            byte[] r1 = new byte[r1]
            r2 = 0
            int r7 = 0 - r7
            if (r0 != 0) goto L17
            r3 = r0
            r4 = r2
            r0 = r8
            goto L32
        L17:
            r3 = r8
            r8 = r6
            r6 = r3
            r3 = r2
        L1b:
            byte r4 = (byte) r8
            r1[r3] = r4
            if (r3 != r7) goto L28
            java.lang.String r6 = new java.lang.String
            r6.<init>(r1, r2)
            r9[r2] = r6
            return
        L28:
            int r3 = r3 + 1
            r4 = r0[r6]
            r5 = r8
            r8 = r6
            r6 = r4
            r4 = r3
            r3 = r0
            r0 = r5
        L32:
            int r8 = r8 + 1
            int r6 = r6 + r0
            r0 = r8
            r8 = r6
            r6 = r0
            r0 = r3
            r3 = r4
            goto L1b
        */
        throw new UnsupportedOperationException("Method not decompiled: com.facetec.sdk.ol.g(byte, byte, int, java.lang.Object[]):void");
    }

    public static void init$0() {
        $$a = new byte[]{89, 120, -98, -110};
        $$b = 68;
    }

    public static void init$1() {
        $$c = new byte[]{84, -122, 19, 43};
        $$d = 3;
    }

    /* JADX WARN: Finally extract failed */
    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Removed duplicated region for block: B:120:0x0235  */
    /* JADX WARN: Removed duplicated region for block: B:173:0x0231 A[SYNTHETIC] */
    /* JADX WARN: Removed duplicated region for block: B:64:0x0123 A[Catch: IOException -> 0x00bd, TryCatch #3 {IOException -> 0x00bd, blocks: (B:13:0x005f, B:15:0x0063, B:64:0x0123, B:66:0x0129, B:70:0x013d, B:72:0x014b, B:75:0x0153, B:77:0x0169, B:79:0x016f, B:82:0x0185, B:92:0x01b9, B:94:0x01c3, B:99:0x01df, B:101:0x01ea, B:105:0x01ef, B:107:0x01fb, B:109:0x0201, B:110:0x0206, B:95:0x01c7, B:112:0x0218, B:30:0x0090, B:32:0x0098, B:35:0x00ac, B:37:0x00b2, B:42:0x00c0, B:44:0x00c6, B:47:0x00cf, B:49:0x00db, B:50:0x00e6, B:51:0x00ed, B:52:0x00ee, B:54:0x00f4, B:56:0x00fe, B:58:0x0107, B:59:0x010c, B:60:0x0115, B:62:0x011b, B:136:0x02b9, B:137:0x02be), top: B:164:0x005f }] */
    /* JADX WARN: Removed duplicated region for block: B:90:0x01af  */
    /* JADX WARN: Removed duplicated region for block: B:95:0x01c7 A[Catch: IOException -> 0x00bd, TRY_LEAVE, TryCatch #3 {IOException -> 0x00bd, blocks: (B:13:0x005f, B:15:0x0063, B:64:0x0123, B:66:0x0129, B:70:0x013d, B:72:0x014b, B:75:0x0153, B:77:0x0169, B:79:0x016f, B:82:0x0185, B:92:0x01b9, B:94:0x01c3, B:99:0x01df, B:101:0x01ea, B:105:0x01ef, B:107:0x01fb, B:109:0x0201, B:110:0x0206, B:95:0x01c7, B:112:0x0218, B:30:0x0090, B:32:0x0098, B:35:0x00ac, B:37:0x00b2, B:42:0x00c0, B:44:0x00c6, B:47:0x00cf, B:49:0x00db, B:50:0x00e6, B:51:0x00ed, B:52:0x00ee, B:54:0x00f4, B:56:0x00fe, B:58:0x0107, B:59:0x010c, B:60:0x0115, B:62:0x011b, B:136:0x02b9, B:137:0x02be), top: B:164:0x005f }] */
    /* JADX WARN: Removed duplicated region for block: B:97:0x01cd  */
    /* JADX WARN: Type inference failed for: r10v0 */
    /* JADX WARN: Type inference failed for: r10v1, types: [int] */
    /* JADX WARN: Type inference failed for: r10v34 */
    /* JADX WARN: Type inference failed for: r10v5 */
    /* JADX WARN: Type inference failed for: r10v9 */
    /* JADX WARN: Type inference failed for: r11v0 */
    /* JADX WARN: Type inference failed for: r11v1, types: [com.facetec.sdk.no, com.facetec.sdk.nx, com.facetec.sdk.oi] */
    /* JADX WARN: Type inference failed for: r11v11, types: [com.facetec.sdk.nj] */
    /* JADX WARN: Type inference failed for: r11v12 */
    /* JADX WARN: Type inference failed for: r11v13 */
    /* JADX WARN: Type inference failed for: r11v14 */
    /* JADX WARN: Type inference failed for: r11v15 */
    /* JADX WARN: Type inference failed for: r11v16 */
    /* JADX WARN: Type inference failed for: r11v17 */
    /* JADX WARN: Type inference failed for: r11v4 */
    /* JADX WARN: Type inference failed for: r11v6 */
    /* JADX WARN: Type inference failed for: r11v7 */
    /* JADX WARN: Type inference failed for: r17v0, types: [com.facetec.sdk.ol] */
    /* JADX WARN: Type inference failed for: r18v1 */
    /* JADX WARN: Type inference failed for: r18v10 */
    /* JADX WARN: Type inference failed for: r18v11 */
    /* JADX WARN: Type inference failed for: r18v12 */
    /* JADX WARN: Type inference failed for: r18v13 */
    /* JADX WARN: Type inference failed for: r18v14 */
    /* JADX WARN: Type inference failed for: r18v15 */
    /* JADX WARN: Type inference failed for: r18v16 */
    /* JADX WARN: Type inference failed for: r18v17 */
    /* JADX WARN: Type inference failed for: r18v18 */
    /* JADX WARN: Type inference failed for: r18v19 */
    /* JADX WARN: Type inference failed for: r18v2 */
    /* JADX WARN: Type inference failed for: r18v20 */
    /* JADX WARN: Type inference failed for: r18v21 */
    /* JADX WARN: Type inference failed for: r18v22 */
    /* JADX WARN: Type inference failed for: r18v26 */
    /* JADX WARN: Type inference failed for: r18v27 */
    /* JADX WARN: Type inference failed for: r18v28 */
    /* JADX WARN: Type inference failed for: r18v29 */
    /* JADX WARN: Type inference failed for: r18v3 */
    /* JADX WARN: Type inference failed for: r18v30 */
    /* JADX WARN: Type inference failed for: r18v4 */
    /* JADX WARN: Type inference failed for: r18v5 */
    /* JADX WARN: Type inference failed for: r18v6 */
    /* JADX WARN: Type inference failed for: r18v7 */
    /* JADX WARN: Type inference failed for: r18v8 */
    /* JADX WARN: Type inference failed for: r18v9 */
    /* JADX WARN: Type inference failed for: r3v1, types: [com.facetec.sdk.oo] */
    /* JADX WARN: Type inference failed for: r4v1 */
    /* JADX WARN: Type inference failed for: r4v13 */
    /* JADX WARN: Type inference failed for: r4v14, types: [com.facetec.sdk.nc] */
    /* JADX WARN: Type inference failed for: r4v2, types: [com.facetec.sdk.nj] */
    /* JADX WARN: Type inference failed for: r4v29 */
    /* JADX WARN: Type inference failed for: r4v3 */
    /* JADX WARN: Type inference failed for: r4v49, types: [com.facetec.sdk.nh$e] */
    /* JADX WARN: Type inference failed for: r4v52 */
    /* JADX WARN: Type inference failed for: r6v14, types: [com.facetec.sdk.nj$b] */
    @Override // com.facetec.sdk.ne
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public final com.facetec.sdk.nh c(com.facetec.sdk.ne.c r18) throws java.io.IOException {
        /*
            Method dump skipped, instruction units count: 794
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: com.facetec.sdk.ol.c(com.facetec.sdk.ne$c):com.facetec.sdk.nh");
    }

    public final boolean e() {
        h = (j + 63) % 128;
        boolean z = this.b;
        h = (j + 107) % 128;
        return z;
    }

    /* JADX WARN: Code restructure failed: missing block: B:11:0x002c, code lost:
    
        if (r2 != false) goto L16;
     */
    /* JADX WARN: Code restructure failed: missing block: B:13:0x002f, code lost:
    
        if (r2 != false) goto L16;
     */
    /* JADX WARN: Code restructure failed: missing block: B:15:0x0032, code lost:
    
        return false;
     */
    /* JADX WARN: Removed duplicated region for block: B:8:0x001b  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    private static boolean e(java.io.IOException r2, com.facetec.sdk.nj r3) {
        /*
            int r0 = com.facetec.sdk.ol.h
            int r0 = r0 + 119
            int r1 = r0 % 128
            com.facetec.sdk.ol.j = r1
            int r0 = r0 % 2
            r1 = 0
            com.facetec.sdk.ni r3 = r3.e()
            boolean r3 = r3 instanceof com.facetec.sdk.ot
            if (r0 != 0) goto L19
            r0 = 39
            int r0 = r0 / r1
            if (r3 != 0) goto L33
            goto L1b
        L19:
            if (r3 != 0) goto L33
        L1b:
            int r3 = com.facetec.sdk.ol.h
            int r3 = r3 + 29
            int r0 = r3 % 128
            com.facetec.sdk.ol.j = r0
            int r3 = r3 % 2
            boolean r2 = r2 instanceof java.io.FileNotFoundException
            if (r3 != 0) goto L2f
            r3 = 45
            int r3 = r3 / r1
            if (r2 == 0) goto L32
            goto L33
        L2f:
            if (r2 == 0) goto L32
            goto L33
        L32:
            return r1
        L33:
            int r2 = com.facetec.sdk.ol.j
            int r2 = r2 + 59
            int r2 = r2 % 128
            com.facetec.sdk.ol.h = r2
            r2 = 1
            return r2
        */
        throw new UnsupportedOperationException("Method not decompiled: com.facetec.sdk.ol.e(java.io.IOException, com.facetec.sdk.nj):boolean");
    }

    private static int d(nh nhVar, int i2) {
        int i3 = h + 107;
        j = i3 % 128;
        if (i3 % 2 != 0) {
            String strA = nhVar.a("Retry-After");
            if (strA == null) {
                int i4 = h + 17;
                j = i4 % 128;
                if (i4 % 2 != 0) {
                    return i2;
                }
                throw null;
            }
            if (strA.matches("\\d+")) {
                return Integer.valueOf(strA).intValue();
            }
            return Integer.MAX_VALUE;
        }
        nhVar.a("Retry-After");
        throw null;
    }

    /* JADX WARN: Removed duplicated region for block: B:32:0x0233  */
    /* JADX WARN: Removed duplicated region for block: B:87:0x0249 A[EXC_TOP_SPLITTER, SYNTHETIC] */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public static java.lang.Object[] d(android.content.Context r31, int r32, int r33, int r34) throws java.lang.Throwable {
        /*
            Method dump skipped, instruction units count: 1351
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: com.facetec.sdk.ol.d(android.content.Context, int, int, int):java.lang.Object[]");
    }

    private static boolean c(IOException iOException, boolean z) {
        if (iOException instanceof ProtocolException) {
            j = (h + EnumC41897g.SDK_ASSET_ILLUSTRATION_DEPOSIT_SWITCH_VALUE) % 128;
            return false;
        }
        if (iOException instanceof InterruptedIOException) {
            if (iOException instanceof SocketTimeoutException) {
                j = (h + 13) % 128;
                if (!z) {
                    return true;
                }
            }
            return false;
        }
        if ((iOException instanceof SSLHandshakeException) && (iOException.getCause() instanceof CertificateException)) {
            return false;
        }
        if (!(iOException instanceof SSLPeerUnverifiedException)) {
            return true;
        }
        int i2 = j + 41;
        h = i2 % 128;
        return i2 % 2 != 0;
    }

    /* JADX WARN: Removed duplicated region for block: B:9:0x003d A[PHI: r3
      0x003d: PHI (r3v3 com.facetec.sdk.nc) = (r3v2 com.facetec.sdk.nc), (r3v11 com.facetec.sdk.nc) binds: [B:8:0x003b, B:5:0x0024] A[DONT_GENERATE, DONT_INLINE]] */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    private static boolean c(com.facetec.sdk.nh r3, com.facetec.sdk.nc r4) {
        /*
            int r0 = com.facetec.sdk.ol.j
            int r0 = r0 + 93
            int r1 = r0 % 128
            com.facetec.sdk.ol.h = r1
            int r0 = r0 % 2
            r1 = 0
            if (r0 == 0) goto L27
            com.facetec.sdk.nj r3 = r3.c()
            com.facetec.sdk.nc r3 = r3.b()
            java.lang.String r0 = r3.g()
            java.lang.String r2 = r4.g()
            boolean r0 = r0.equals(r2)
            r2 = 81
            int r2 = r2 / r1
            if (r0 == 0) goto L67
            goto L3d
        L27:
            com.facetec.sdk.nj r3 = r3.c()
            com.facetec.sdk.nc r3 = r3.b()
            java.lang.String r0 = r3.g()
            java.lang.String r2 = r4.g()
            boolean r0 = r0.equals(r2)
            if (r0 == 0) goto L67
        L3d:
            int r0 = r3.h()
            int r2 = r4.h()
            if (r0 != r2) goto L67
            int r0 = com.facetec.sdk.ol.j
            int r0 = r0 + 97
            int r0 = r0 % 128
            com.facetec.sdk.ol.h = r0
            java.lang.String r3 = r3.e()
            java.lang.String r4 = r4.e()
            boolean r3 = r3.equals(r4)
            if (r3 == 0) goto L67
            int r3 = com.facetec.sdk.ol.j
            int r3 = r3 + 123
            int r3 = r3 % 128
            com.facetec.sdk.ol.h = r3
            r3 = 1
            return r3
        L67:
            return r1
        */
        throw new UnsupportedOperationException("Method not decompiled: com.facetec.sdk.ol.c(com.facetec.sdk.nh, com.facetec.sdk.nc):boolean");
    }
}