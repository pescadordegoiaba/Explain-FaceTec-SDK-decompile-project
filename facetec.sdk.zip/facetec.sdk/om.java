package com.facetec.sdk;

/* JADX INFO: loaded from: classes4.dex */
public final class om {
    public static String a(nc ncVar) {
        String strJ = ncVar.j();
        String strI = ncVar.i();
        if (strI == null) {
            return strJ;
        }
        StringBuilder sb = new StringBuilder();
        sb.append(strJ);
        sb.append('?');
        sb.append(strI);
        return sb.toString();
    }
}