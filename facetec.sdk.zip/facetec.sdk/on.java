package com.facetec.sdk;

import android.content.Context;
import android.graphics.Color;
import android.graphics.ImageFormat;
import android.graphics.PointF;
import android.media.AudioTrack;
import android.os.Process;
import android.os.SystemClock;
import android.telephony.cdma.CdmaCellLocation;
import android.text.TextUtils;
import android.util.TypedValue;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewConfiguration;
import android.widget.ExpandableListView;
import com.facetec.sdk.ov;
import com.incode.welcome_sdk.modules.SelfieScan;
import com.plaid.internal.EnumC41897g;
import java.io.ByteArrayInputStream;
import java.io.InputStream;
import java.lang.reflect.Method;
import net.sf.scuba.smartcards.ISO7816;
import net.sf.scuba.smartcards.ISOFileInfo;
import org.bouncycastle.crypto.signers.PSSSigner;
import org.jmrtd.PassportService;
import org.jmrtd.lds.CVCAFile;

/* JADX INFO: loaded from: classes4.dex */
public final class on extends no {
    private static final byte[] $$a = null;
    private static final int $$b = 0;
    private static int $10;
    private static int $11;
    private static int d;
    private static int e;
    private static int f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    private static long f95931g;
    private static short[] h;
    private static int i;
    private static byte[] j;
    private static char k;
    private static int m;
    private static int n;
    private final pz a;
    private final long b;
    private final String c;

    /* JADX WARN: Removed duplicated region for block: B:10:0x0023  */
    /* JADX WARN: Removed duplicated region for block: B:8:0x001d  */
    /* JADX WARN: Unsupported multi-entry loop pattern (BACK_EDGE: B:10:0x0023 -> B:11:0x002a). Please report as a decompilation issue!!! */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    private static java.lang.String $$c(int r6, short r7, byte r8) {
        /*
            byte[] r0 = com.facetec.sdk.on.$$a
            int r7 = 106 - r7
            int r8 = r8 * 2
            int r1 = 1 - r8
            int r6 = r6 + 4
            byte[] r1 = new byte[r1]
            r2 = 0
            int r8 = 0 - r8
            if (r0 != 0) goto L15
            r7 = r6
            r4 = r8
            r3 = r2
            goto L2a
        L15:
            r3 = r2
        L16:
            byte r4 = (byte) r7
            r1[r3] = r4
            int r6 = r6 + 1
            if (r3 != r8) goto L23
            java.lang.String r6 = new java.lang.String
            r6.<init>(r1, r2)
            return r6
        L23:
            r4 = r0[r6]
            int r3 = r3 + 1
            r5 = r7
            r7 = r6
            r6 = r5
        L2a:
            int r4 = -r4
            int r6 = r6 + r4
            r5 = r7
            r7 = r6
            r6 = r5
            goto L16
        */
        throw new UnsupportedOperationException("Method not decompiled: com.facetec.sdk.on.$$c(int, short, byte):java.lang.String");
    }

    static {
        init$0();
        $10 = 0;
        $11 = 1;
        m = 0;
        n = 1;
        d = 1621667345;
        e = 114796584;
        i = -37485859;
        j = new byte[]{-99, 123, -103, 116, ISOFileInfo.AB, -104, -103, -98, 109, -107, 78, 103, ISOFileInfo.ENV_TEMP_EF, 64, -90, -111, ISO7816.INS_MANAGE_CHANNEL, -98, CVCAFile.CAR_TAG, 71, -33, -104, -103, -98, 109, -107, 78, 103, ISOFileInfo.SECURITY_ATTR_COMPACT, 104, 104, -110, ISOFileInfo.FMD_BYTE, 101, -106, 102, -108, 65, 67, 99, -104, -66, 73, -99, 99, -104, -34, 41, ISOFileInfo.A5, -105, -100, 119, 80, ISO7816.INS_UPDATE_BINARY, 102, 104, -108, -98, 113, -99, -111, 38, -43, 116, -120, 118, -108, -111, ISO7816.INS_MANAGE_CHANNEL, -98, CVCAFile.CAR_TAG, 71, -33, -104, -103, -98, 109, -107, 78, 103, ISOFileInfo.SECURITY_ATTR_COMPACT, 104, 116, ISOFileInfo.AB, -104, -103, -98, 109, -107, 78, 103, ISOFileInfo.ENV_TEMP_EF, 64, -70, -99, 123, -103, 110, -99, 101, -112, 110, 119, ISOFileInfo.SECURITY_ATTR_EXP, -99, 101, -107, 107, 97, 114, 65, -94, -98, 33, -39, 101, 106, -110, 101, -100, ISOFileInfo.FCI_BYTE, 86, -87, -104, -103, -98, 109, -107, 110, 106, -101, 70, ISOFileInfo.FCI_EXT, -99, 101, -107, 107, 97, 114, -65, 108, -99, 106, -101, 70, ISOFileInfo.FCI_EXT, -99, 101, -107, 107, 97, 114, 65, -94, -98, 33, -39, 101, 106, -110, 101, -100, ISOFileInfo.FCI_BYTE, 86, -87, -104, -103, -98, 109, -107, 110, 106, -104, ISOFileInfo.FMD_BYTE, -75, -112, -98, ISOFileInfo.FCP_BYTE, ISO7816.INS_MANAGE_CHANNEL, -112, ISOFileInfo.FMD_BYTE, -99, 117, 70, -94, -98, 33, -39, 101, 106, -110, 101, -100, ISOFileInfo.FCI_BYTE, 86, -87, -104, -103, -98, 109, -107, 110, 123, ISOFileInfo.SECURITY_ATTR_COMPACT, 99, 82, -65, -110, -104, 84, ISO7816.INS_READ_BINARY, -104, 104, -110, ISOFileInfo.FMD_BYTE, 101, -106, 102, -108, 65, 67, 99, -104, -66, ISOFileInfo.FCI_EXT, 114, -99, -104, 107, ISOFileInfo.CHANNEL_SECURITY, 65, PSSSigner.TRAILER_IMPLICIT, 108, -99, 99, 99, 99, 99, 99, 99, 99, 99, 99, 99};
        f95931g = 1396024866991524551L;
        f = 1453607623;
        k = (char) 9460;
    }

    public on(String str, long j2, pz pzVar) {
        this.c = str;
        this.b = j2;
        this.a = pzVar;
    }

    public static void init$0() {
        $$a = new byte[]{115, PassportService.SFI_COM, 119, 102};
        $$b = 160;
    }

    private static void l(short s, int i2, byte b, int i3, int i4, Object[] objArr) throws Throwable {
        int i5;
        long j2;
        int i6;
        float f2;
        long j3;
        int i7;
        int i8;
        hh hhVar = new hh();
        StringBuilder sb = new StringBuilder();
        int i9 = 2;
        try {
            int i10 = 1;
            Object[] objArr2 = {Integer.valueOf(i2), Integer.valueOf(e)};
            Object objD = an.d(962055330);
            Class cls = Integer.TYPE;
            int i11 = -1;
            if (objD == null) {
                byte b2 = (byte) (-1);
                i5 = 962055330;
                byte b3 = (byte) (b2 + 1);
                j2 = 0;
                objD = an.d(ExpandableListView.getPackedPositionChild(0L) + 2403, (char) ((-1) - ((byte) KeyEvent.getModifierMetaStateMask())), View.resolveSize(0, 0) + 24, 1328947193, false, $$c(b2, b3, b3), new Class[]{cls, cls});
            } else {
                i5 = 962055330;
                j2 = 0;
            }
            int iIntValue = ((Integer) ((Method) objD).invoke(null, objArr2)).intValue();
            int i12 = iIntValue == -1 ? 0 : 1;
            if (i12 == 0) {
                byte[] bArr = j;
                if (bArr != null) {
                    int length = bArr.length;
                    f2 = SelfieScan.RECOGNITION_FAIL_RESULT;
                    byte[] bArr2 = new byte[length];
                    int i13 = 0;
                    j3 = -7666492657327691677L;
                    while (i13 < length) {
                        int i14 = $10 + 29;
                        int i15 = i10;
                        $11 = i14 % 128;
                        if (i14 % i9 == 0) {
                            Object[] objArr3 = {Integer.valueOf(bArr[i13])};
                            Object objD2 = an.d(399840230);
                            if (objD2 == null) {
                                byte b4 = (byte) i11;
                                byte b5 = (byte) (b4 + 4);
                                objD2 = an.d(2064 - (KeyEvent.getMaxKeyCode() >> 16), (char) ((ViewConfiguration.getScrollBarSize() >> 8) + 14866), (ViewConfiguration.getGlobalActionKeyTimeout() > j2 ? 1 : (ViewConfiguration.getGlobalActionKeyTimeout() == j2 ? 0 : -1)) + 23, 1639235773, false, $$c(b4, b5, (byte) (b5 - 3)), new Class[]{cls});
                            }
                            bArr2[i13] = ((Byte) ((Method) objD2).invoke(null, objArr3)).byteValue();
                        } else {
                            Object[] objArr4 = {Integer.valueOf(bArr[i13])};
                            Object objD3 = an.d(399840230);
                            if (objD3 == null) {
                                byte b6 = (byte) (-1);
                                byte b7 = (byte) (b6 + 4);
                                objD3 = an.d(2064 - TextUtils.indexOf("", "", 0), (char) (14867 - (AudioTrack.getMaxVolume() > SelfieScan.RECOGNITION_FAIL_RESULT ? 1 : (AudioTrack.getMaxVolume() == SelfieScan.RECOGNITION_FAIL_RESULT ? 0 : -1))), 24 - (ViewConfiguration.getDoubleTapTimeout() >> 16), 1639235773, false, $$c(b6, b7, (byte) (b7 - 3)), new Class[]{cls});
                            }
                            bArr2[i13] = ((Byte) ((Method) objD3).invoke(null, objArr4)).byteValue();
                            i13++;
                        }
                        i10 = i15;
                        i9 = 2;
                        i11 = -1;
                    }
                    i6 = i10;
                    $11 = ($10 + 115) % 128;
                    bArr = bArr2;
                } else {
                    i6 = 1;
                    f2 = SelfieScan.RECOGNITION_FAIL_RESULT;
                    j3 = -7666492657327691677L;
                }
                if (bArr != null) {
                    byte[] bArr3 = j;
                    Object[] objArr5 = new Object[2];
                    objArr5[i6] = Integer.valueOf(d);
                    objArr5[0] = Integer.valueOf(i4);
                    Object objD4 = an.d(i5);
                    if (objD4 == null) {
                        byte b8 = (byte) (-1);
                        byte b9 = (byte) (b8 + 1);
                        objD4 = an.d(Color.blue(0) + 2402, (char) TextUtils.getOffsetAfter("", 0), (ViewConfiguration.getFadingEdgeLength() >> 16) + 24, 1328947193, false, $$c(b8, b9, b9), new Class[]{cls, cls});
                    }
                    iIntValue = (byte) (((byte) (((long) bArr3[((Integer) ((Method) objD4).invoke(null, objArr5)).intValue()]) ^ j3)) + ((int) (((long) e) ^ j3)));
                } else {
                    iIntValue = (short) (((short) (((long) h[i4 + ((int) (((long) d) ^ j3))]) ^ j3)) + ((int) (((long) e) ^ j3)));
                }
            } else {
                i6 = 1;
                f2 = SelfieScan.RECOGNITION_FAIL_RESULT;
                j3 = -7666492657327691677L;
            }
            if (iIntValue > 0) {
                $10 = ($11 + 23) % 128;
                hhVar.d = ((i4 + iIntValue) - 2) + ((int) (((long) d) ^ j3)) + (i12 ^ 1);
                int i16 = i;
                Object[] objArr6 = new Object[4];
                objArr6[3] = sb;
                objArr6[2] = Integer.valueOf(i16);
                objArr6[i6] = Integer.valueOf(i3);
                objArr6[0] = hhVar;
                Object objD5 = an.d(-1066327576);
                if (objD5 == null) {
                    int maximumDrawingCacheSize = 1803 - (ViewConfiguration.getMaximumDrawingCacheSize() >> 24);
                    char c = (char) ((AudioTrack.getMinVolume() > f2 ? 1 : (AudioTrack.getMinVolume() == f2 ? 0 : -1)) + 9692);
                    int doubleTapTimeout = (ViewConfiguration.getDoubleTapTimeout() >> 16) + 24;
                    byte length2 = (byte) $$a.length;
                    objD5 = an.d(maximumDrawingCacheSize, c, doubleTapTimeout, -1240403277, false, $$c((byte) (-1), length2, (byte) (length2 - 4)), new Class[]{Object.class, cls, cls, Object.class});
                }
                ((StringBuilder) ((Method) objD5).invoke(null, objArr6)).append(hhVar.e);
                hhVar.c = hhVar.e;
                byte[] bArr4 = j;
                if (bArr4 != null) {
                    int length3 = bArr4.length;
                    byte[] bArr5 = new byte[length3];
                    for (int i17 = 0; i17 < length3; i17++) {
                        bArr5[i17] = (byte) (((long) bArr4[i17]) ^ j3);
                    }
                    bArr4 = bArr5;
                }
                if (bArr4 != null) {
                    $11 = ($10 + 5) % 128;
                    i7 = i6;
                    i8 = i7;
                } else {
                    i7 = i6;
                    i8 = 0;
                }
                while (true) {
                    hhVar.b = i7;
                    if (hhVar.b >= iIntValue) {
                        break;
                    }
                    if (i8 != 0) {
                        byte[] bArr6 = j;
                        hhVar.d = hhVar.d - 1;
                        hhVar.e = (char) (hhVar.c + (((byte) (((byte) (((long) bArr6[r3]) ^ j3)) + s)) ^ b));
                    } else {
                        short[] sArr = h;
                        hhVar.d = hhVar.d - 1;
                        hhVar.e = (char) (hhVar.c + (((short) (((short) (((long) sArr[r3]) ^ j3)) + s)) ^ b));
                    }
                    sb.append(hhVar.e);
                    hhVar.c = hhVar.e;
                    i7 = hhVar.b + 1;
                }
            }
            objArr[0] = sb.toString();
        } catch (Throwable th) {
            Throwable cause = th.getCause();
            if (cause == null) {
                throw th;
            }
            throw cause;
        }
    }

    private static void o(char c, String str, int i2, String str2, String str3, Object[] objArr) throws Throwable {
        char[] charArray;
        int i3;
        long j2;
        int i4;
        char c2;
        char[] charArray2 = str3 != null ? str3.toCharArray() : str3;
        if (str2 != null) {
            $11 = ($10 + 15) % 128;
            charArray = str2.toCharArray();
        } else {
            charArray = str2;
        }
        char[] cArr = charArray;
        char[] charArray3 = str != null ? str.toCharArray() : str;
        hi hiVar = new hi();
        int length = charArray3.length;
        char[] cArr2 = new char[length];
        int length2 = cArr.length;
        char[] cArr3 = new char[length2];
        int i5 = 0;
        System.arraycopy(charArray3, 0, cArr2, 0, length);
        System.arraycopy(cArr, 0, cArr3, 0, length2);
        cArr2[0] = (char) (cArr2[0] ^ c);
        int i6 = 2;
        cArr3[2] = (char) (cArr3[2] + ((char) i2));
        int length3 = charArray2.length;
        char[] cArr4 = new char[length3];
        hiVar.d = 0;
        while (hiVar.d < length3) {
            $10 = ($11 + 65) % 128;
            try {
                Object[] objArr2 = {hiVar};
                Object objD = an.d(1217746441);
                if (objD == null) {
                    objD = an.d(216 - (Process.getElapsedCpuTime() > 0L ? 1 : (Process.getElapsedCpuTime() == 0L ? 0 : -1)), (char) (63338 - (CdmaCellLocation.convertQuartSecToDecDegrees(i5) > 0.0d ? 1 : (CdmaCellLocation.convertQuartSecToDecDegrees(i5) == 0.0d ? 0 : -1))), 24 - (ViewConfiguration.getEdgeSlop() >> 16), 1056212306, false, "b", new Class[]{Object.class});
                }
                int iIntValue = ((Integer) ((Method) objD).invoke(null, objArr2)).intValue();
                Object[] objArr3 = {hiVar};
                Object objD2 = an.d(1379992360);
                if (objD2 == null) {
                    j2 = 0;
                    byte b = (byte) (-1);
                    i3 = i6;
                    objD2 = an.d((ViewConfiguration.getFadingEdgeLength() >> 16) + 688, (char) (33106 - TextUtils.indexOf((CharSequence) "", '0', i5)), ImageFormat.getBitsPerPixel(i5) + 24, 606130291, false, $$c(b, (byte) (b & 9), (byte) i5), new Class[]{Object.class});
                } else {
                    i3 = i6;
                    j2 = 0;
                }
                int iIntValue2 = ((Integer) ((Method) objD2).invoke(null, objArr3)).intValue();
                int i7 = cArr2[hiVar.d % 4] * 32718;
                Object[] objArr4 = new Object[3];
                objArr4[i3] = Integer.valueOf(cArr3[iIntValue]);
                objArr4[1] = Integer.valueOf(i7);
                objArr4[i5] = hiVar;
                Object objD3 = an.d(-1522168148);
                Class cls = Integer.TYPE;
                if (objD3 == null) {
                    i4 = i5;
                    byte b2 = (byte) (-1);
                    c2 = 1;
                    byte b3 = (byte) (b2 + 3);
                    objD3 = an.d((SystemClock.uptimeMillis() > j2 ? 1 : (SystemClock.uptimeMillis() == j2 ? 0 : -1)) + 1303, (char) (Process.myTid() >> 22), 25 - (SystemClock.elapsedRealtime() > j2 ? 1 : (SystemClock.elapsedRealtime() == j2 ? 0 : -1)), -752591369, false, $$c(b2, b3, (byte) (b3 - 2)), new Class[]{Object.class, cls, cls});
                } else {
                    i4 = i5;
                    c2 = 1;
                }
                ((Method) objD3).invoke(null, objArr4);
                int i8 = cArr2[iIntValue2] * 32718;
                int i9 = i3;
                Object[] objArr5 = new Object[i9];
                objArr5[c2] = Integer.valueOf(cArr3[iIntValue]);
                objArr5[i4] = Integer.valueOf(i8);
                Object objD4 = an.d(-1578548222);
                if (objD4 == null) {
                    objD4 = an.d((ViewConfiguration.getTouchSlop() >> 8) + 1970, (char) (ExpandableListView.getPackedPositionForGroup(i4) > j2 ? 1 : (ExpandableListView.getPackedPositionForGroup(i4) == j2 ? 0 : -1)), 24 - (Process.myTid() >> 22), -678914215, false, "i", new Class[]{cls, cls});
                }
                cArr3[iIntValue2] = ((Character) ((Method) objD4).invoke(null, objArr5)).charValue();
                cArr2[iIntValue2] = hiVar.e;
                int i10 = hiVar.d;
                cArr4[i10] = (char) (((((long) (r6 ^ charArray2[i10])) ^ (f95931g ^ 1396024866991524551L)) ^ ((long) ((int) (((long) f) ^ 1396024866991524551L)))) ^ ((long) ((char) (((long) k) ^ 1396024866991524551L))));
                hiVar.d = i10 + 1;
                i5 = i4;
                i6 = i9;
            } catch (Throwable th) {
                Throwable cause = th.getCause();
                if (cause == null) {
                    throw th;
                }
                throw cause;
            }
        }
        objArr[i5] = new String(cArr4);
    }

    @Override // com.facetec.sdk.no
    public final pz c() {
        int i2 = n + 101;
        m = i2 % 128;
        if (i2 % 2 == 0) {
            return this.a;
        }
        throw null;
    }

    @Override // com.facetec.sdk.no
    public final nb d() {
        int i2 = m + 125;
        n = i2 % 128;
        if (i2 % 2 == 0) {
            throw null;
        }
        String str = this.c;
        if (str == null) {
            return null;
        }
        nb nbVarA = nb.a(str);
        int i3 = n + 89;
        m = i3 % 128;
        if (i3 % 2 != 0) {
            int i4 = 52 / 0;
        }
        return nbVarA;
    }

    @Override // com.facetec.sdk.no
    public final long e() {
        int i2 = m + 75;
        int i3 = i2 % 128;
        n = i3;
        if (i2 % 2 == 0) {
            throw null;
        }
        long j2 = this.b;
        int i4 = i3 + 111;
        m = i4 % 128;
        if (i4 % 2 == 0) {
            return j2;
        }
        throw null;
    }

    public static Object[] e(Context context, int i2, int i3) {
        Class<String> cls = String.class;
        if (context != null) {
            try {
                short s = (short) (TypedValue.complexToFraction(0, SelfieScan.RECOGNITION_FAIL_RESULT, SelfieScan.RECOGNITION_FAIL_RESULT) > SelfieScan.RECOGNITION_FAIL_RESULT ? 1 : (TypedValue.complexToFraction(0, SelfieScan.RECOGNITION_FAIL_RESULT, SelfieScan.RECOGNITION_FAIL_RESULT) == SelfieScan.RECOGNITION_FAIL_RESULT ? 0 : -1));
                int i4 = (-43) - (SystemClock.uptimeMillis() > 0L ? 1 : (SystemClock.uptimeMillis() == 0L ? 0 : -1));
                byte bBlue = (byte) Color.blue(0);
                int i5 = -(-(ViewConfiguration.getWindowTouchSlop() >> 8));
                int i6 = ((i5 | 82597253) << 1) - (i5 ^ 82597253);
                int i7 = -(Process.myPid() >> 22);
                int i8 = i7 * (-1975);
                int i9 = ((i8 | 121903510) << 1) - (i8 ^ 121903510);
                int i10 = ~i7;
                int i11 = (i10 ^ (-1719600754)) | (i10 & (-1719600754));
                float f2 = 0.0f;
                int i12 = ~i11;
                int i13 = (i9 - (~(-(-(((i2 ^ i12) | (i12 & i2)) * 988))))) - 1;
                int i14 = ~((1719600753 ^ i7) | (1719600753 & i7));
                int i15 = ~i2;
                int i16 = ~(i7 | i15);
                int i17 = -(-(((i14 ^ i16) | (i14 & i16)) * (-1976)));
                int i18 = (i13 & i17) + (i13 | i17);
                int i19 = (~i11) | (~((1719600753 ^ i2) | (1719600753 & i2)));
                int i20 = ~i2;
                int i21 = ~((i20 ^ (-1719600754)) | (i20 & (-1719600754)));
                int i22 = ((i19 ^ i21) | (i21 & i19)) * 988;
                int i23 = (i18 ^ i22) + ((i22 & i18) << 1);
                Object[] objArr = new Object[1];
                l(s, i4, bBlue, i6, i23, objArr);
                try {
                    Object[] objArr2 = {(String) objArr[0]};
                    short maxKeyCode = (short) (KeyEvent.getMaxKeyCode() >> 16);
                    int packedPositionType = ExpandableListView.getPackedPositionType(0L);
                    int i24 = packedPositionType * (-112);
                    int i25 = (i24 & 4144) + (i24 | 4144);
                    int i26 = ~((36 ^ i20) | (36 & i20));
                    int i27 = -(-(((i26 & packedPositionType) | (packedPositionType ^ i26)) * EnumC41897g.SDK_ASSET_ILLUSTRATION_BALANCE_BEAM_01_CIRCLE_VALUE));
                    int i28 = ((i25 | i27) << 1) - (i27 ^ i25);
                    int i29 = ~((~packedPositionType) | (-37));
                    int i30 = ~packedPositionType;
                    int i31 = ~((i30 & i2) | (i30 ^ i2));
                    int i32 = (i29 & i31) | (i29 ^ i31);
                    int i33 = (36 ^ i15) | (36 & i15);
                    int i34 = (i28 - (~(-(-(((~((packedPositionType & i33) | (i33 ^ packedPositionType))) | i32) * (-113)))))) - 1;
                    int i35 = -(-((~((36 ^ i2) | (36 & i2))) * 113));
                    int i36 = (i34 & i35) + (i35 | i34);
                    byte b = (byte) (AudioTrack.getMinVolume() > SelfieScan.RECOGNITION_FAIL_RESULT ? 1 : (AudioTrack.getMinVolume() == SelfieScan.RECOGNITION_FAIL_RESULT ? 0 : -1));
                    int i37 = -ExpandableListView.getPackedPositionGroup(0L);
                    int i38 = ((i37 | 82597292) << 1) - (i37 ^ 82597292);
                    int iIndexOf = TextUtils.indexOf((CharSequence) "", '0');
                    int i39 = (iIndexOf * (-103)) + 1025215333;
                    int i40 = ~iIndexOf;
                    int i41 = ~((i40 ^ 1719600722) | (i40 & 1719600722));
                    int i42 = ~((1719600722 ^ i2) | (1719600722 & i2));
                    int i43 = ((i41 ^ i42) | (i42 & i41)) * 104;
                    int i44 = (i39 & i43) + (i39 | i43);
                    int i45 = (i15 ^ iIndexOf) | (i15 & iIndexOf);
                    int i46 = -(-((~((i45 ^ (-1719600723)) | (i45 & (-1719600723)))) * (-104)));
                    int i47 = (((i44 & i46) + (i46 | i44)) - (~(((iIndexOf ^ i2) | (iIndexOf & i2)) * 104))) - 1;
                    Object[] objArr3 = new Object[1];
                    l(maxKeyCode, i36, b, i38, i47, objArr3);
                    Object objNewInstance = Class.forName((String) objArr3[0]).getDeclaredConstructor(cls).newInstance(objArr2);
                    short sIndexOf = (short) TextUtils.indexOf("", "");
                    int i48 = -(ViewConfiguration.getTouchSlop() >> 8);
                    int i49 = (i48 & (-44)) + (i48 | (-44));
                    int i50 = -(ViewConfiguration.getGlobalActionKeyTimeout() > 0L ? 1 : (ViewConfiguration.getGlobalActionKeyTimeout() == 0L ? 0 : -1));
                    int iD = ov.b.AnonymousClass4.d();
                    int i51 = (i50 * 829) + 829;
                    int i52 = ~i50;
                    int i53 = ~((i52 & (-2)) | (i52 ^ (-2)));
                    int i54 = ~iD;
                    int i55 = (i54 ^ i50) | (i54 & i50);
                    int i56 = ~((i55 ^ 1) | (i55 & 1));
                    int i57 = -(-(((i53 ^ i56) | (i53 & i56)) * (-828)));
                    int i58 = (i51 ^ i57) + ((i51 & i57) << 1);
                    int i59 = (i50 & 1) | (i50 ^ 1);
                    int i60 = ((i54 & i59) | (i59 ^ i54)) * (-828);
                    byte b2 = (byte) ((i58 & i60) + (i60 | i58) + ((~i59) * 828));
                    int i61 = -(-(ViewConfiguration.getScrollBarFadeDuration() >> 16));
                    int i62 = ((i61 | 82597253) << 1) - (i61 ^ 82597253);
                    int i63 = -(-MotionEvent.axisFromString(""));
                    Object[] objArr4 = new Object[1];
                    l(sIndexOf, i49, b2, i62, (i63 & (-1719600686)) + (i63 | (-1719600686)), objArr4);
                    try {
                        Object[] objArr5 = {(String) objArr4[0]};
                        short sRed = (short) Color.red(0);
                        int i64 = -(ViewConfiguration.getEdgeSlop() >> 16);
                        int i65 = i64 * 829;
                        int i66 = ((i65 | (-30673)) << 1) - (i65 ^ (-30673));
                        int i67 = ~i64;
                        int i68 = ~((i67 & 36) | (i67 ^ 36));
                        int i69 = (i15 ^ i64) | (i15 & i64);
                        int i70 = ~((i69 & (-37)) | (i69 ^ (-37)));
                        int i71 = ((i68 & i70) | (i68 ^ i70)) * (-828);
                        int i72 = ((i66 | i71) << 1) - (i71 ^ i66);
                        int i73 = i64 | (-37);
                        int i74 = -(-(((i73 & i20) | (i73 ^ i20)) * (-828)));
                        int i75 = (i72 & i74) + (i74 | i72);
                        int i76 = -(-((~((i64 & (-37)) | (i64 ^ (-37)))) * 828));
                        int i77 = ((i75 | i76) << 1) - (i76 ^ i75);
                        byte b3 = (byte) (CdmaCellLocation.convertQuartSecToDecDegrees(0) > 0.0d ? 1 : (CdmaCellLocation.convertQuartSecToDecDegrees(0) == 0.0d ? 0 : -1));
                        int fadingEdgeLength = ViewConfiguration.getFadingEdgeLength() >> 16;
                        int i78 = (fadingEdgeLength * (-159)) - 248067540;
                        int i79 = ~fadingEdgeLength;
                        int i80 = ((i79 ^ 82597292) | (i79 & 82597292)) * 160;
                        int i81 = (i78 & i80) + (i80 | i78);
                        int i82 = ~(i20 | fadingEdgeLength);
                        int i83 = ~(82597292 | fadingEdgeLength);
                        int i84 = (i81 - (~(-(-(((i82 & i83) | (i82 ^ i83)) * (-160)))))) - 1;
                        int i85 = ~(((-82597293) & i15) | ((-82597293) ^ i15));
                        int i86 = ((fadingEdgeLength & i85) | (fadingEdgeLength ^ i85)) * 160;
                        int i87 = (i84 & i86) + (i84 | i86);
                        int i88 = -(ViewConfiguration.getKeyRepeatDelay() >> 16);
                        int i89 = ((i88 | (-1719600724)) << 1) - (i88 ^ (-1719600724));
                        Object[] objArr6 = new Object[1];
                        l(sRed, i77, b3, i87, i89, objArr6);
                        Object objNewInstance2 = Class.forName((String) objArr6[0]).getDeclaredConstructor(cls).newInstance(objArr5);
                        try {
                            char cKeyCodeFromString = (char) KeyEvent.keyCodeFromString("");
                            int i90 = -KeyEvent.keyCodeFromString("");
                            int i91 = (i90 ^ (-1670441045)) + ((i90 & (-1670441045)) << 1);
                            Object[] objArr7 = new Object[1];
                            o(cKeyCodeFromString, "ꯑ漗嶜\ue205", i91, "\u0000\u0000\u0000\u0000", "ヲᮓ剜蔲ऌ絋嶱䷳⯯䓍碤猪㢈念諡內\u1ada魄볻起픋Ⴗ\ue22f", objArr7);
                            Class<?> cls2 = Class.forName((String) objArr7[0]);
                            char c = (char) (38098 - (~(-Process.getGidForName(""))));
                            int i92 = -(-Color.red(0));
                            int i93 = (i92 ^ 1307553629) + ((i92 & 1307553629) << 1);
                            Object[] objArr8 = new Object[1];
                            o(c, "嵔\uefaf푍쮔", i93, "\u0000\u0000\u0000\u0000", "횢\ue348맋\udd97仇샋ᓻ\uf094磩럱춽㧸휒轗\u176d銁䝠", objArr8);
                            Object objInvoke = cls2.getMethod((String) objArr8[0], null).invoke(context, null);
                            try {
                                Object[] objArr9 = new Object[1];
                                o((char) Color.red(0), "ꯑ漗嶜\ue205", (-1670441046) - (~(-(ViewConfiguration.getLongPressTimeout() >> 16))), "\u0000\u0000\u0000\u0000", "ヲᮓ剜蔲ऌ絋嶱䷳⯯䓍碤猪㢈念諡內\u1ada魄볻起픋Ⴗ\ue22f", objArr9);
                                Class<?> cls3 = Class.forName((String) objArr9[0]);
                                int i94 = (SystemClock.elapsedRealtime() > 0L ? 1 : (SystemClock.elapsedRealtime() == 0L ? 0 : -1));
                                Object[] objArr10 = new Object[1];
                                o((char) ((i94 & 29313) + (i94 | 29313)), "껴꾠良ꡲ", View.MeasureSpec.getMode(0), "\u0000\u0000\u0000\u0000", "ㅐバ\udbc7阶鑰祜쓈銋楰\uefbe줦鷽㆘䤎", objArr10);
                                try {
                                    Object[] objArr11 = {cls3.getMethod((String) objArr10[0], null).invoke(context, null), 64};
                                    short sAxisFromString = (short) ((-1) - MotionEvent.axisFromString(""));
                                    int pressedStateDuration = (ViewConfiguration.getPressedStateDuration() >> 16) - 42;
                                    byte jumpTapTimeout = (byte) (ViewConfiguration.getJumpTapTimeout() >> 16);
                                    int i95 = 82597284 - (SystemClock.currentThreadTimeMillis() > (-1L) ? 1 : (SystemClock.currentThreadTimeMillis() == (-1L) ? 0 : -1));
                                    int i96 = -(-TextUtils.getCapsMode("", 0, 0));
                                    int i97 = ((i96 | (-1719600657)) << 1) - (i96 ^ (-1719600657));
                                    Object[] objArr12 = new Object[1];
                                    l(sAxisFromString, pressedStateDuration, jumpTapTimeout, i95, i97, objArr12);
                                    Class<?> cls4 = Class.forName((String) objArr12[0]);
                                    short pressedStateDuration2 = (short) (ViewConfiguration.getPressedStateDuration() >> 16);
                                    int i98 = -(-(SystemClock.elapsedRealtimeNanos() > 0L ? 1 : (SystemClock.elapsedRealtimeNanos() == 0L ? 0 : -1)));
                                    int i99 = ((i98 | (-62)) << 1) - (i98 ^ (-62));
                                    byte mode = (byte) View.MeasureSpec.getMode(0);
                                    int i100 = -(ViewConfiguration.getJumpTapTimeout() >> 16);
                                    int i101 = (i100 * (-55)) - 247883599;
                                    int i102 = ~((i100 ^ i2) | (i100 & i2));
                                    int i103 = ((i102 ^ 82597289) | (i102 & 82597289)) * 56;
                                    int i104 = (((i101 | i103) << 1) - (i103 ^ i101)) + ((~((i100 ^ 82597289) | (i100 & 82597289))) * (-56));
                                    int i105 = ~(i20 | 82597289);
                                    int i106 = -(-(((i105 & i100) | (i100 ^ i105)) * 56));
                                    int i107 = (i104 ^ i106) + ((i104 & i106) << 1);
                                    int i108 = (CdmaCellLocation.convertQuartSecToDecDegrees(0) > 0.0d ? 1 : (CdmaCellLocation.convertQuartSecToDecDegrees(0) == 0.0d ? 0 : -1));
                                    Object[] objArr13 = new Object[1];
                                    l(pressedStateDuration2, i99, mode, i107, (i108 ^ (-1719600625)) + ((i108 & (-1719600625)) << 1), objArr13);
                                    Object objInvoke2 = cls4.getMethod((String) objArr13[0], cls, Integer.TYPE).invoke(objInvoke, objArr11);
                                    int i109 = -(ViewConfiguration.getZoomControlsTimeout() > 0L ? 1 : (ViewConfiguration.getZoomControlsTimeout() == 0L ? 0 : -1));
                                    int iD2 = ov.b.AnonymousClass4.d();
                                    int i110 = ~i109;
                                    int i111 = (-2) | i109;
                                    int i112 = ((i109 * 477) - 475) + (((~((i110 & 1) | (i110 ^ 1))) | (~((i111 & iD2) | (i111 ^ iD2)))) * (-476));
                                    int i113 = ((-2) ^ i109) | ((-2) & i109);
                                    int i114 = i112 + ((~((i113 & iD2) | (i113 ^ iD2))) * 952);
                                    int i115 = ~iD2;
                                    int i116 = ((-2) & i115) | ((-2) ^ i115);
                                    int i117 = (~((i109 & i116) | (i116 ^ i109))) * 476;
                                    short s2 = (short) (((i114 | i117) << 1) - (i117 ^ i114));
                                    int i118 = -View.resolveSizeAndState(0, 0, 0);
                                    int iD3 = ov.b.AnonymousClass4.d();
                                    int i119 = i118 * (-813);
                                    int i120 = (i119 ^ (-18360)) + ((i119 & (-18360)) << 1);
                                    int i121 = ~((44 & i118) | (44 ^ i118));
                                    int i122 = ~(i118 | iD3);
                                    int i123 = i120 + (((i121 & i122) | (i121 ^ i122)) * (-814));
                                    int i124 = ~iD3;
                                    int i125 = ~((i124 & 44) | (44 ^ i124));
                                    int i126 = ~i118;
                                    int i127 = ~((i126 ^ (-45)) | (i126 & (-45)));
                                    int i128 = (i125 ^ i127) | (i125 & i127);
                                    int i129 = ~((i118 ^ iD3) | (i118 & iD3));
                                    int i130 = ~i118;
                                    int i131 = i123 + (((i128 ^ i129) | (i128 & i129)) * 407) + (((~((i130 & (-45)) | (i130 ^ (-45)))) | (~(i126 | iD3)) | (~(iD3 | (-45)))) * 407);
                                    int i132 = -(-TextUtils.lastIndexOf("", '0'));
                                    int maximumDrawingCacheSize = (ViewConfiguration.getMaximumDrawingCacheSize() >> 24) + 82597283;
                                    int i133 = -KeyEvent.getDeadChar(0, 0);
                                    int i134 = (i133 ^ (-1719600612)) + ((i133 & (-1719600612)) << 1);
                                    Object[] objArr14 = new Object[1];
                                    l(s2, i131, (byte) ((i132 ^ 1) + ((i132 & 1) << 1)), maximumDrawingCacheSize, i134, objArr14);
                                    Class<?> cls5 = Class.forName((String) objArr14[0]);
                                    Object[] objArr15 = new Object[1];
                                    o((char) (TypedValue.complexToFloat(0) > SelfieScan.RECOGNITION_FAIL_RESULT ? 1 : (TypedValue.complexToFloat(0) == SelfieScan.RECOGNITION_FAIL_RESULT ? 0 : -1)), "ᠪ䓖カ㊦", (ExpandableListView.getPackedPositionForGroup(0) > 0L ? 1 : (ExpandableListView.getPackedPositionForGroup(0) == 0L ? 0 : -1)), "\u0000\u0000\u0000\u0000", "㶜Ꞁ䲢蔟縬ं褓轒鏑ꍟ", objArr15);
                                    Object[] objArr16 = (Object[]) cls5.getField((String) objArr15[0]).get(objInvoke2);
                                    int length = objArr16.length;
                                    int i135 = 0;
                                    while (i135 < length) {
                                        Object obj = objArr16[i135];
                                        int i136 = (SystemClock.elapsedRealtimeNanos() > 0L ? 1 : (SystemClock.elapsedRealtimeNanos() == 0L ? 0 : -1));
                                        int i137 = ~i20;
                                        int i138 = ~i136;
                                        int i139 = i138 | i136;
                                        Object[] objArr17 = objArr16;
                                        int i140 = ~((i139 ^ i2) | (i139 & i2));
                                        int i141 = ((((i136 * (-830)) - 832) - (~(-(-(((i137 ^ i140) | (i140 & i137)) * (-831)))))) - 1) + ((~(i136 | i2)) * (-1662));
                                        int i142 = ~((i138 ^ i20) | (i138 & i20));
                                        int i143 = ~((i136 & i2) | (i136 ^ i2));
                                        int i144 = (i142 & i143) | (i142 ^ i143);
                                        int i145 = ~((i2 ^ (-1)) | i2);
                                        int i146 = ((i144 & i145) | (i144 ^ i145)) * 831;
                                        short s3 = (short) ((i141 & i146) + (i146 | i141));
                                        int i147 = -(AudioTrack.getMaxVolume() > f2 ? 1 : (AudioTrack.getMaxVolume() == f2 ? 0 : -1));
                                        int i148 = ((i147 | (-69)) << 1) - (i147 ^ (-69));
                                        float f3 = f2;
                                        byte b4 = (byte) (PointF.length(f3, f3) > f3 ? 1 : (PointF.length(f3, f3) == f3 ? 0 : -1));
                                        int i149 = -(TypedValue.complexToFraction(0, f3, f3) > f3 ? 1 : (TypedValue.complexToFraction(0, f3, f3) == f3 ? 0 : -1));
                                        int i150 = (i149 & 82597274) + (i149 | 82597274);
                                        int i151 = -(ViewConfiguration.getJumpTapTimeout() >> 16);
                                        int iD4 = ov.b.AnonymousClass4.d();
                                        int i152 = i151 * 477;
                                        int i153 = (i152 & 766490685) + (i152 | 766490685);
                                        int i154 = ~i151;
                                        int i155 = ~((i154 ^ (-1719600583)) | (i154 & (-1719600583)));
                                        int i156 = 1719600582 | i151;
                                        int i157 = ~((i156 ^ iD4) | (i156 & iD4));
                                        int i158 = i153 + (((i155 ^ i157) | (i157 & i155)) * (-476));
                                        int i159 = (1719600582 & i151) | (1719600582 ^ i151);
                                        int i160 = i158 + ((~((i159 & iD4) | (i159 ^ iD4))) * 952);
                                        int i161 = 1719600582 | (~iD4);
                                        int i162 = (i160 - (~(-(-((~((i161 & i151) | (i161 ^ i151))) * 476))))) - 1;
                                        Object[] objArr18 = new Object[1];
                                        l(s3, i148, b4, i150, i162, objArr18);
                                        try {
                                            Object[] objArr19 = {(String) objArr18[0]};
                                            char size = (char) View.MeasureSpec.getSize(0);
                                            int i163 = -TextUtils.indexOf("", "");
                                            int i164 = ((i163 | (-598339249)) << 1) - (i163 ^ (-598339249));
                                            Object[] objArr20 = new Object[1];
                                            o(size, "佱嘑嗜짂", i164, "\u0000\u0000\u0000\u0000", "媿⸲\ue3cb鸦홝픗쿐졷탒丵튆ᢦ戵둫\ufdcbᷮ錜闠拻ꉴ纜湃擱꤇ଢ顴鴎袓ꜵ䶚㈜\ueb9c\ue96b桴尬\ue65e\ue1a5", objArr20);
                                            Class<?> cls6 = Class.forName((String) objArr20[0]);
                                            Object[] objArr21 = new Object[1];
                                            o((char) TextUtils.getOffsetAfter("", 0), "鱆㦩翨\uf3ee", (-398874212) - TextUtils.indexOf("", ""), "\u0000\u0000\u0000\u0000", "ᾡ뷙ﳗﶩ맖辯㩲痰瞶촜皢", objArr21);
                                            Object objInvoke3 = cls6.getMethod((String) objArr21[0], cls).invoke(null, objArr19);
                                            try {
                                                short s4 = (short) (CdmaCellLocation.convertQuartSecToDecDegrees(0) > 0.0d ? 1 : (CdmaCellLocation.convertQuartSecToDecDegrees(0) == 0.0d ? 0 : -1));
                                                int packedPositionGroup = ExpandableListView.getPackedPositionGroup(0L) - 47;
                                                byte bCombineMeasuredStates = (byte) View.combineMeasuredStates(0, 0);
                                                int i165 = -(ExpandableListView.getPackedPositionForChild(0, 0) > 0L ? 1 : (ExpandableListView.getPackedPositionForChild(0, 0) == 0L ? 0 : -1));
                                                Class<String> cls7 = cls;
                                                int i166 = (i165 ^ 82597282) + ((i165 & 82597282) << 1);
                                                int i167 = -(-Color.alpha(0));
                                                int i168 = ((i167 | (-1719600579)) << 1) - (i167 ^ (-1719600579));
                                                Object[] objArr22 = new Object[1];
                                                l(s4, packedPositionGroup, bCombineMeasuredStates, i166, i168, objArr22);
                                                Class<?> cls8 = Class.forName((String) objArr22[0]);
                                                short deadChar = (short) KeyEvent.getDeadChar(0, 0);
                                                int i169 = (-63) - (ViewConfiguration.getZoomControlsTimeout() > 0L ? 1 : (ViewConfiguration.getZoomControlsTimeout() == 0L ? 0 : -1));
                                                int packedPositionChild = ExpandableListView.getPackedPositionChild(0L);
                                                int iD5 = ov.b.AnonymousClass4.d();
                                                int i170 = i15;
                                                int i171 = ~packedPositionChild;
                                                int i172 = ~((i171 ^ 1) | (i171 & 1));
                                                int i173 = ~iD5;
                                                int i174 = ~((i173 ^ packedPositionChild) | (i173 & packedPositionChild));
                                                int i175 = ((packedPositionChild * 375) - 747) + (((i172 ^ i174) | (i172 & i174)) * (-374));
                                                int i176 = (~(((-2) ^ packedPositionChild) | ((-2) & packedPositionChild))) * 748;
                                                int i177 = (i175 ^ i176) + ((i175 & i176) << 1);
                                                int i178 = ~packedPositionChild;
                                                int i179 = ~((i178 ^ (-2)) | (i178 & (-2)));
                                                int i180 = ~(packedPositionChild | (~iD5));
                                                byte b5 = (byte) (i177 + (((i179 & i180) | (i179 ^ i180)) * 374));
                                                int iMakeMeasureSpec = View.MeasureSpec.makeMeasureSpec(0, 0);
                                                int i181 = iMakeMeasureSpec * (-665);
                                                int i182 = (i181 & 1817695092) + (i181 | 1817695092);
                                                int i183 = ~iMakeMeasureSpec;
                                                int i184 = i183 * (-333);
                                                int i185 = (i182 & i184) + (i182 | i184);
                                                int i186 = -(-(((~((i2 ^ 82597302) | (i2 & 82597302))) | (~((i183 ^ i20) | (i183 & i20)))) * 333));
                                                int i187 = (i185 & i186) + (i185 | i186);
                                                int i188 = ((~((i183 ^ i2) | (i183 & i2))) | (~(i20 | 82597302))) * 333;
                                                int i189 = (i187 & i188) + (i188 | i187);
                                                int i190 = -(ViewConfiguration.getKeyRepeatDelay() >> 16);
                                                int iD6 = ov.b.AnonymousClass4.d();
                                                int i191 = (i190 * 371) - (-1978322312);
                                                int i192 = length;
                                                int i193 = ~iD6;
                                                int i194 = ~((1719600551 ^ i193) | (1719600551 & i193));
                                                int i195 = ~i190;
                                                int i196 = ~((i195 ^ iD6) | (i195 & iD6));
                                                int i197 = ((i194 ^ i196) | (i194 & i196)) * (-370);
                                                int i198 = (i191 ^ i197) + ((i197 & i191) << 1);
                                                int i199 = ~i190;
                                                int i200 = ~iD6;
                                                int i201 = ~((i199 ^ i200) | (i199 & i200));
                                                int i202 = ~(iD6 | 1719600551);
                                                int i203 = ~((i190 & (-1719600552)) | (i190 ^ (-1719600552)));
                                                int i204 = i198 + (((i201 & i202) | (i201 ^ i202) | i203) * (-370));
                                                int i205 = i203 * 370;
                                                int i206 = (i204 & i205) + (i204 | i205);
                                                Object[] objArr23 = new Object[1];
                                                l(deadChar, i169, b5, i189, i206, objArr23);
                                                try {
                                                    Object[] objArr24 = {new ByteArrayInputStream((byte[]) cls8.getMethod((String) objArr23[0], null).invoke(obj, null))};
                                                    int i207 = -(-ExpandableListView.getPackedPositionChild(0L));
                                                    int i208 = -(ViewConfiguration.getGlobalActionKeyTimeout() > 0L ? 1 : (ViewConfiguration.getGlobalActionKeyTimeout() == 0L ? 0 : -1));
                                                    int i209 = ((i208 | (-598339248)) << 1) - (i208 ^ (-598339248));
                                                    Object[] objArr25 = new Object[1];
                                                    o((char) ((i207 ^ 1) + ((i207 & 1) << 1)), "佱嘑嗜짂", i209, "\u0000\u0000\u0000\u0000", "媿⸲\ue3cb鸦홝픗쿐졷탒丵튆ᢦ戵둫\ufdcbᷮ錜闠拻ꉴ纜湃擱꤇ଢ顴鴎袓ꜵ䶚㈜\ueb9c\ue96b桴尬\ue65e\ue1a5", objArr25);
                                                    Class<?> cls9 = Class.forName((String) objArr25[0]);
                                                    int iResolveSizeAndState = View.resolveSizeAndState(0, 0, 0);
                                                    int iD7 = ov.b.AnonymousClass4.d();
                                                    int i210 = (iResolveSizeAndState * 829) - (-40493334);
                                                    int i211 = ~iResolveSizeAndState;
                                                    int i212 = ~((i211 & (-48847)) | (i211 ^ (-48847)));
                                                    int i213 = ~iD7;
                                                    int i214 = ~((i213 & iResolveSizeAndState) | (i213 ^ iResolveSizeAndState) | 48846);
                                                    int i215 = ((i212 ^ i214) | (i212 & i214)) * (-828);
                                                    int i216 = ((i210 | i215) << 1) - (i210 ^ i215);
                                                    int i217 = (iResolveSizeAndState & 48846) | (iResolveSizeAndState ^ 48846);
                                                    int i218 = ~iD7;
                                                    int i219 = -(-(((i218 & i217) | (i217 ^ i218)) * (-828)));
                                                    int i220 = ((i216 | i219) << 1) - (i219 ^ i216);
                                                    int i221 = (~i217) * 828;
                                                    int i222 = -TextUtils.lastIndexOf("", '0');
                                                    int i223 = (i222 ^ 483693024) + ((i222 & 483693024) << 1);
                                                    Object[] objArr26 = new Object[1];
                                                    o((char) (((i220 | i221) << 1) - (i221 ^ i220)), "\ue1df풑츜誾", i223, "\u0000\u0000\u0000\u0000", "\ude51앇㪹轓벺菫㲃냹隓؉觭\ue77a껣\ude07䓯쇮䋕\uf068㋾", objArr26);
                                                    Object objInvoke4 = cls9.getMethod((String) objArr26[0], InputStream.class).invoke(objInvoke3, objArr24);
                                                    try {
                                                        Object[] objArr27 = new Object[1];
                                                        o((char) (ViewConfiguration.getKeyRepeatTimeout() >> 16), "猯寊Ὴ⮷", KeyEvent.normalizeMetaState(0), "\u0000\u0000\u0000\u0000", "吊㡠綩ࣩାⲸꎝ闉⸎觔镲隃塪\ue1b6㟗桿嫇┝\uf8d7櫔Ἓ鰈풤艥\udb58燮㳞㒁믕迤逶躀\ue8b4基", objArr27);
                                                        Class<?> cls10 = Class.forName((String) objArr27[0]);
                                                        int i224 = -(SystemClock.currentThreadTimeMillis() > (-1L) ? 1 : (SystemClock.currentThreadTimeMillis() == (-1L) ? 0 : -1));
                                                        int iLastIndexOf = TextUtils.lastIndexOf("", '0', 0) - 51;
                                                        byte bMakeMeasureSpec = (byte) View.MeasureSpec.makeMeasureSpec(0, 0);
                                                        int i225 = 82597288 - (~(-View.resolveSize(0, 0)));
                                                        int i226 = (TypedValue.complexToFraction(0, SelfieScan.RECOGNITION_FAIL_RESULT, SelfieScan.RECOGNITION_FAIL_RESULT) > SelfieScan.RECOGNITION_FAIL_RESULT ? 1 : (TypedValue.complexToFraction(0, SelfieScan.RECOGNITION_FAIL_RESULT, SelfieScan.RECOGNITION_FAIL_RESULT) == SelfieScan.RECOGNITION_FAIL_RESULT ? 0 : -1));
                                                        int iD8 = ov.b.AnonymousClass4.d();
                                                        int i227 = i226 * EnumC41897g.SDK_ASSET_ICON_PROGRESS_VALUE;
                                                        int i228 = (i227 ^ 346929074) + ((i227 & 346929074) << 1);
                                                        int i229 = (~((i226 ^ iD8) | (i226 & iD8))) * EnumC41897g.SDK_ASSET_ICON_PRODUCT_MONITOR_VALUE;
                                                        int i230 = ((i228 | i229) << 1) - (i228 ^ i229);
                                                        int i231 = 1719600541 | i226;
                                                        int i232 = ~iD8;
                                                        int i233 = ~(i226 | (~iD8));
                                                        int i234 = ((i230 + (((i231 ^ i232) | (i232 & i231)) * (-216))) - (~(((i233 & (-1719600542)) | (i233 ^ (-1719600542))) * EnumC41897g.SDK_ASSET_ICON_PRODUCT_MONITOR_VALUE))) - 1;
                                                        Object[] objArr28 = new Object[1];
                                                        l((short) ((i224 ^ 1) + ((i224 & 1) << 1)), iLastIndexOf, bMakeMeasureSpec, i225, i234, objArr28);
                                                        if (!objNewInstance.equals(cls10.getMethod((String) objArr28[0], null).invoke(objInvoke4, null))) {
                                                            try {
                                                                Object[] objArr29 = new Object[1];
                                                                o((char) View.resolveSizeAndState(0, 0, 0), "猯寊Ὴ⮷", ViewConfiguration.getMaximumDrawingCacheSize() >> 24, "\u0000\u0000\u0000\u0000", "吊㡠綩ࣩାⲸꎝ闉⸎觔镲隃塪\ue1b6㟗桿嫇┝\uf8d7櫔Ἓ鰈풤艥\udb58燮㳞㒁믕迤逶躀\ue8b4基", objArr29);
                                                                Class<?> cls11 = Class.forName((String) objArr29[0]);
                                                                int i235 = -TextUtils.indexOf((CharSequence) "", '0', 0);
                                                                int i236 = i235 * 46;
                                                                int i237 = (i236 ^ (-46)) + ((i236 & (-46)) << 1);
                                                                int i238 = ~i20;
                                                                int i239 = ((i238 & i235) | (i235 ^ i238)) * (-90);
                                                                int i240 = (i237 & i239) + (i239 | i237);
                                                                int i241 = ~i2;
                                                                int i242 = ~i235;
                                                                int i243 = ~(i242 | i235);
                                                                int i244 = i240 + (((i241 & i243) | (i241 ^ i243)) * (-45));
                                                                int i245 = ~((i242 ^ i2) | (i242 & i2));
                                                                int i246 = ~((i170 & i235) | (i170 ^ i235));
                                                                int i247 = ((i246 & i245) | (i245 ^ i246)) * 45;
                                                                int i248 = (-53) - (~(-(ViewConfiguration.getMinimumFlingVelocity() >> 16)));
                                                                byte bResolveSize = (byte) View.resolveSize(0, 0);
                                                                int i249 = -View.MeasureSpec.makeMeasureSpec(0, 0);
                                                                int i250 = (i249 & 82597289) + (i249 | 82597289);
                                                                int i251 = -(-(SystemClock.elapsedRealtime() > 0L ? 1 : (SystemClock.elapsedRealtime() == 0L ? 0 : -1)));
                                                                int i252 = (i251 ^ (-1719600543)) + ((i251 & (-1719600543)) << 1);
                                                                Object[] objArr30 = new Object[1];
                                                                l((short) ((i244 ^ i247) + ((i247 & i244) << 1)), i248, bResolveSize, i250, i252, objArr30);
                                                                if (!objNewInstance2.equals(cls11.getMethod((String) objArr30[0], null).invoke(objInvoke4, null))) {
                                                                    int i253 = i135 - 64;
                                                                    i135 = (i253 ^ 65) + ((i253 & 65) << 1);
                                                                    objArr16 = objArr17;
                                                                    cls = cls7;
                                                                    i15 = i170;
                                                                    length = i192;
                                                                    f2 = SelfieScan.RECOGNITION_FAIL_RESULT;
                                                                }
                                                            } catch (Throwable th) {
                                                                Throwable cause = th.getCause();
                                                                if (cause != null) {
                                                                    throw cause;
                                                                }
                                                                throw th;
                                                            }
                                                        }
                                                        Object[] objArr31 = {null, new int[1], new int[]{(i2 & (-2)) | (i20 & 1)}, new int[]{i2}};
                                                        int iMyUid = Process.myUid();
                                                        int i254 = 1548104669 + ((~(iMyUid | 550118915)) * EnumC41897g.SDK_ASSET_ICON_PRODUCT_MONITOR_VALUE);
                                                        int i255 = ~iMyUid;
                                                        int i256 = i254 + ((920350463 | i255) * (-216)) + (((~(i255 | 550118915)) | (-370887422)) * EnumC41897g.SDK_ASSET_ICON_PRODUCT_MONITOR_VALUE);
                                                        int iD9 = ov.b.AnonymousClass4.d();
                                                        int i257 = ~i256;
                                                        int i258 = ~(((-17) ^ i257) | ((-17) & i257));
                                                        int i259 = ~((-17) | iD9);
                                                        int i260 = (-7920) + (i256 * (-495)) + (((i258 & i259) | (i258 ^ i259)) * 992);
                                                        int i261 = ~((i257 & (-17)) | ((-17) ^ i257));
                                                        int i262 = ~(((-17) & iD9) | ((-17) ^ iD9));
                                                        int i263 = (i261 & i262) | (i261 ^ i262);
                                                        int i264 = ~iD9;
                                                        int i265 = (i264 & 16) | (i264 ^ 16);
                                                        int i266 = ~((i265 & i256) | (i265 ^ i256));
                                                        int i267 = ((i263 & i266) | (i263 ^ i266)) * (-496);
                                                        int i268 = ((((i260 | i267) << 1) - (i267 ^ i260)) - (~(-(-(((iD9 & i256) | (i256 ^ iD9)) * 496))))) - 1;
                                                        int iD10 = ov.b.AnonymousClass4.d();
                                                        int i269 = i268 * 866;
                                                        int i270 = -(-(i3 * (-864)));
                                                        int i271 = (i269 ^ i270) + ((i269 & i270) << 1);
                                                        int i272 = ~i3;
                                                        int i273 = ~i268;
                                                        int i274 = ~iD10;
                                                        int i275 = -(-(((~((i273 & i274) | (i273 ^ i274))) | i272) * (-865)));
                                                        int i276 = (((i271 & i275) + (i275 | i271)) - (~((~(i268 | iD10)) * 865))) - 1;
                                                        int i277 = ~(i272 | i274);
                                                        int i278 = ~((~iD10) | i268);
                                                        int i279 = i276 + (((i278 & i277) | (i277 ^ i278)) * 865);
                                                        int i280 = (i279 << 13) ^ i279;
                                                        int i281 = i280 ^ (i280 >>> 17);
                                                        int i282 = i281 << 5;
                                                        ((int[]) objArr31[1])[0] = (i281 | i282) & (~(i281 & i282));
                                                        return objArr31;
                                                    } catch (Throwable th2) {
                                                        Throwable cause2 = th2.getCause();
                                                        if (cause2 != null) {
                                                            throw cause2;
                                                        }
                                                        throw th2;
                                                    }
                                                } catch (Throwable th3) {
                                                    Throwable cause3 = th3.getCause();
                                                    if (cause3 != null) {
                                                        throw cause3;
                                                    }
                                                    throw th3;
                                                }
                                            } catch (Throwable th4) {
                                                Throwable cause4 = th4.getCause();
                                                if (cause4 != null) {
                                                    throw cause4;
                                                }
                                                throw th4;
                                            }
                                        } catch (Throwable th5) {
                                            Throwable cause5 = th5.getCause();
                                            if (cause5 != null) {
                                                throw cause5;
                                            }
                                            throw th5;
                                        }
                                    }
                                } catch (Throwable th6) {
                                    Throwable cause6 = th6.getCause();
                                    if (cause6 != null) {
                                        throw cause6;
                                    }
                                    throw th6;
                                }
                            } catch (Throwable th7) {
                                Throwable cause7 = th7.getCause();
                                if (cause7 != null) {
                                    throw cause7;
                                }
                                throw th7;
                            }
                        } catch (Throwable th8) {
                            Throwable cause8 = th8.getCause();
                            if (cause8 != null) {
                                throw cause8;
                            }
                            throw th8;
                        }
                    } catch (Throwable th9) {
                        Throwable cause9 = th9.getCause();
                        if (cause9 != null) {
                            throw cause9;
                        }
                        throw th9;
                    }
                } catch (Throwable th10) {
                    Throwable cause10 = th10.getCause();
                    if (cause10 != null) {
                        throw cause10;
                    }
                    throw th10;
                }
            } catch (Throwable unused) {
            }
        }
        Object[] objArr32 = {null, new int[1], new int[]{i2}, new int[]{i2}};
        int iUptimeMillis = (int) SystemClock.uptimeMillis();
        int i283 = 100607773 + (((~(iUptimeMillis | (-618922378))) | 798153871) * EnumC41897g.SDK_ASSET_ILLUSTRATION_MD_ERROR_ATTEMPT_2_NEW_VALUE) + (((~((~iUptimeMillis) | (-618922378))) | 612368521) * EnumC41897g.SDK_ASSET_ILLUSTRATION_MD_ERROR_ATTEMPT_2_NEW_VALUE);
        int i284 = ((i3 | i283) << 1) - (i3 ^ i283);
        int i285 = i284 << 13;
        int i286 = (i284 | i285) & (~(i284 & i285));
        int i287 = i286 >>> 17;
        int i288 = ((~i286) & i287) | ((~i287) & i286);
        int i289 = i288 << 5;
        ((int[]) objArr32[1])[0] = (i288 | i289) & (~(i288 & i289));
        return objArr32;
    }
}