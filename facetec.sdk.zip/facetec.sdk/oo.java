package com.facetec.sdk;

import com.facetec.sdk.ne;
import java.util.List;

/* JADX INFO: loaded from: classes4.dex */
public final class oo implements ne.c {
    private final oe a;
    private final int b;
    final oi c;
    private final List<ne> d;
    final nx e;
    private final na f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    private final int f95932g;
    private final mn h;
    private final nj i;
    private final int j;
    private int k;
    private final int l;

    public oo(List<ne> list, oe oeVar, oi oiVar, nx nxVar, int i, nj njVar, mn mnVar, na naVar, int i2, int i3, int i4) {
        this.d = list;
        this.e = nxVar;
        this.a = oeVar;
        this.c = oiVar;
        this.b = i;
        this.i = njVar;
        this.h = mnVar;
        this.f = naVar;
        this.j = i2;
        this.f95932g = i3;
        this.l = i4;
    }

    @Override // com.facetec.sdk.ne.c
    public final int a() {
        return this.j;
    }

    @Override // com.facetec.sdk.ne.c
    public final int b() {
        return this.f95932g;
    }

    @Override // com.facetec.sdk.ne.c
    public final int c() {
        return this.l;
    }

    @Override // com.facetec.sdk.ne.c
    public final nj d() {
        return this.i;
    }

    public final oe e() {
        return this.a;
    }

    public final mn g() {
        return this.h;
    }

    public final na i() {
        return this.f;
    }

    public final nh b(nj njVar, oe oeVar, oi oiVar, nx nxVar) {
        if (this.b >= this.d.size()) {
            throw new AssertionError();
        }
        this.k++;
        if (this.c != null && !this.e.d(njVar.b())) {
            StringBuilder sb = new StringBuilder("network interceptor ");
            sb.append(this.d.get(this.b - 1));
            sb.append(" must retain the same host and port");
            throw new IllegalStateException(sb.toString());
        }
        if (this.c != null && this.k > 1) {
            StringBuilder sb2 = new StringBuilder("network interceptor ");
            sb2.append(this.d.get(this.b - 1));
            sb2.append(" must call proceed() exactly once");
            throw new IllegalStateException(sb2.toString());
        }
        oo ooVar = new oo(this.d, oeVar, oiVar, nxVar, this.b + 1, njVar, this.h, this.f, this.j, this.f95932g, this.l);
        ne neVar = this.d.get(this.b);
        nh nhVarC = neVar.c(ooVar);
        if (oiVar != null && this.b + 1 < this.d.size() && ooVar.k != 1) {
            StringBuilder sb3 = new StringBuilder("network interceptor ");
            sb3.append(neVar);
            sb3.append(" must call proceed() exactly once");
            throw new IllegalStateException(sb3.toString());
        }
        if (nhVarC == null) {
            StringBuilder sb4 = new StringBuilder("interceptor ");
            sb4.append(neVar);
            sb4.append(" returned null");
            throw new NullPointerException(sb4.toString());
        }
        if (nhVarC.e() != null) {
            return nhVarC;
        }
        StringBuilder sb5 = new StringBuilder("interceptor ");
        sb5.append(neVar);
        sb5.append(" returned a response with no body");
        throw new IllegalStateException(sb5.toString());
    }

    @Override // com.facetec.sdk.ne.c
    public final nh e(nj njVar) {
        return b(njVar, this.a, this.c, this.e);
    }
}