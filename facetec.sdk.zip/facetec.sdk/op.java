package com.facetec.sdk;

import ai.luciq.library.networkv2.request.Header;
import com.facetec.sdk.mz;
import com.facetec.sdk.nh;
import com.facetec.sdk.oe;
import com.plaid.internal.EnumC41897g;
import java.io.EOFException;
import java.io.IOException;
import java.net.ProtocolException;
import java.nio.ByteBuffer;
import java.util.concurrent.TimeUnit;
import org.bouncycastle.i18n.LocalizedMessage;

/* JADX INFO: loaded from: classes4.dex */
public final class op implements oi {
    private static final byte[] $$a = null;
    private static final int $$b = 0;
    private static final byte[] $$c = null;
    private static final int $$d = 0;
    private static int $10;
    private static int $11;
    private static char[] f;
    private static long h;
    private static int i;
    private static int j;
    final pu a;
    final oe b;
    final pz d;
    final nf e;
    int c = 0;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    private long f95933g = 262144;

    public final class a implements qj {
        private boolean b;
        private final py e;

        public a() {
            this.e = new py(op.this.a.a());
        }

        @Override // com.facetec.sdk.qj
        public final qp a() {
            return this.e;
        }

        @Override // com.facetec.sdk.qj, java.io.Closeable, java.lang.AutoCloseable
        public final synchronized void close() {
            if (this.b) {
                return;
            }
            this.b = true;
            op.this.a.a("0\r\n\r\n");
            op.a(this.e);
            op.this.c = 3;
        }

        @Override // com.facetec.sdk.qj, java.io.Flushable
        public final synchronized void flush() {
            if (this.b) {
                return;
            }
            op.this.a.flush();
        }

        @Override // com.facetec.sdk.qj
        public final void a(px pxVar, long j) {
            if (this.b) {
                throw new IllegalStateException("closed");
            }
            if (j == 0) {
                return;
            }
            op.this.a.g(j);
            op.this.a.a("\r\n");
            op.this.a.a(pxVar, j);
            op.this.a.a("\r\n");
        }
    }

    public class c extends b {
        private long d;

        public c(long j) {
            super(op.this, (byte) 0);
            this.d = j;
            if (j == 0) {
                b(true, null);
            }
        }

        @Override // com.facetec.sdk.ql, java.io.Closeable, java.lang.AutoCloseable
        public final void close() {
            if (this.a) {
                return;
            }
            if (this.d != 0 && !nu.d(this, TimeUnit.MILLISECONDS)) {
                b(false, null);
            }
            this.a = true;
        }

        @Override // com.facetec.sdk.op.b, com.facetec.sdk.ql
        public final long e(px pxVar, long j) throws IOException {
            if (j < 0) {
                throw new IllegalArgumentException("byteCount < 0: ".concat(String.valueOf(j)));
            }
            if (this.a) {
                throw new IllegalStateException("closed");
            }
            long j2 = this.d;
            if (j2 == 0) {
                return -1L;
            }
            long jE = super.e(pxVar, Math.min(j2, j));
            if (jE == -1) {
                ProtocolException protocolException = new ProtocolException("unexpected end of stream");
                b(false, protocolException);
                throw protocolException;
            }
            long j3 = this.d - jE;
            this.d = j3;
            if (j3 == 0) {
                b(true, null);
            }
            return jE;
        }
    }

    public final class d implements qj {
        private long a;
        private boolean b;
        private final py d;

        public d(long j) {
            this.d = new py(op.this.a.a());
            this.a = j;
        }

        @Override // com.facetec.sdk.qj
        public final qp a() {
            return this.d;
        }

        @Override // com.facetec.sdk.qj, java.io.Closeable, java.lang.AutoCloseable
        public final void close() throws ProtocolException {
            if (this.b) {
                return;
            }
            this.b = true;
            if (this.a > 0) {
                throw new ProtocolException("unexpected end of stream");
            }
            op.a(this.d);
            op.this.c = 3;
        }

        @Override // com.facetec.sdk.qj, java.io.Flushable
        public final void flush() {
            if (this.b) {
                return;
            }
            op.this.a.flush();
        }

        @Override // com.facetec.sdk.qj
        public final void a(px pxVar, long j) throws ProtocolException {
            if (this.b) {
                throw new IllegalStateException("closed");
            }
            nu.e(pxVar.e(), 0L, j);
            if (j <= this.a) {
                op.this.a.a(pxVar, j);
                this.a -= j;
            } else {
                StringBuilder sb = new StringBuilder("expected ");
                sb.append(this.a);
                sb.append(" bytes but received ");
                sb.append(j);
                throw new ProtocolException(sb.toString());
            }
        }
    }

    public class e extends b {
        private long c;
        private final nc d;
        private boolean e;

        public e(nc ncVar) {
            super(op.this, (byte) 0);
            this.c = -1L;
            this.e = true;
            this.d = ncVar;
        }

        @Override // com.facetec.sdk.ql, java.io.Closeable, java.lang.AutoCloseable
        public final void close() {
            if (this.a) {
                return;
            }
            if (this.e && !nu.d(this, TimeUnit.MILLISECONDS)) {
                b(false, null);
            }
            this.a = true;
        }

        @Override // com.facetec.sdk.op.b, com.facetec.sdk.ql
        public final long e(px pxVar, long j) throws IOException {
            if (j < 0) {
                throw new IllegalArgumentException("byteCount < 0: ".concat(String.valueOf(j)));
            }
            if (this.a) {
                throw new IllegalStateException("closed");
            }
            if (!this.e) {
                return -1L;
            }
            long j2 = this.c;
            if (j2 == 0 || j2 == -1) {
                if (j2 != -1) {
                    op.this.d.k();
                }
                try {
                    this.c = op.this.d.l();
                    String strTrim = op.this.d.k().trim();
                    if (this.c < 0 || !(strTrim.isEmpty() || strTrim.startsWith(";"))) {
                        StringBuilder sb = new StringBuilder("expected chunk size and optional extensions but was \"");
                        sb.append(this.c);
                        sb.append(strTrim);
                        sb.append("\"");
                        throw new ProtocolException(sb.toString());
                    }
                    if (this.c == 0) {
                        this.e = false;
                        oh.e(op.this.e.b(), this.d, op.this.c());
                        b(true, null);
                    }
                    if (!this.e) {
                        return -1L;
                    }
                } catch (NumberFormatException e) {
                    throw new ProtocolException(e.getMessage());
                }
            }
            long jE = super.e(pxVar, Math.min(j, this.c));
            if (jE != -1) {
                this.c -= jE;
                return jE;
            }
            ProtocolException protocolException = new ProtocolException("unexpected end of stream");
            b(false, protocolException);
            throw protocolException;
        }
    }

    public class j extends b {
        private boolean d;

        public j() {
            super(op.this, (byte) 0);
        }

        @Override // com.facetec.sdk.ql, java.io.Closeable, java.lang.AutoCloseable
        public final void close() {
            if (this.a) {
                return;
            }
            if (!this.d) {
                b(false, null);
            }
            this.a = true;
        }

        @Override // com.facetec.sdk.op.b, com.facetec.sdk.ql
        public final long e(px pxVar, long j) throws IOException {
            if (j < 0) {
                throw new IllegalArgumentException("byteCount < 0: ".concat(String.valueOf(j)));
            }
            if (this.a) {
                throw new IllegalStateException("closed");
            }
            if (this.d) {
                return -1L;
            }
            long jE = super.e(pxVar, j);
            if (jE != -1) {
                return jE;
            }
            this.d = true;
            b(true, null);
            return -1L;
        }
    }

    /* JADX WARN: Removed duplicated region for block: B:10:0x0024  */
    /* JADX WARN: Removed duplicated region for block: B:8:0x001e  */
    /* JADX WARN: Unsupported multi-entry loop pattern (BACK_EDGE: B:10:0x0024 -> B:11:0x002e). Please report as a decompilation issue!!! */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    private static java.lang.String $$e(byte r6, byte r7, short r8) {
        /*
            byte[] r0 = com.facetec.sdk.op.$$c
            int r8 = r8 * 4
            int r8 = 4 - r8
            int r6 = r6 * 4
            int r1 = 1 - r6
            int r7 = r7 + 108
            byte[] r1 = new byte[r1]
            r2 = 0
            int r6 = 0 - r6
            if (r0 != 0) goto L18
            r3 = r0
            r4 = r2
            r0 = r8
            r8 = r6
            goto L2e
        L18:
            r3 = r2
        L19:
            byte r4 = (byte) r7
            r1[r3] = r4
            if (r3 != r6) goto L24
            java.lang.String r6 = new java.lang.String
            r6.<init>(r1, r2)
            return r6
        L24:
            int r3 = r3 + 1
            r4 = r0[r8]
            r5 = r8
            r8 = r7
            r7 = r4
            r4 = r3
            r3 = r0
            r0 = r5
        L2e:
            int r0 = r0 + 1
            int r7 = -r7
            int r7 = r7 + r8
            r8 = r0
            r0 = r3
            r3 = r4
            goto L19
        */
        throw new UnsupportedOperationException("Method not decompiled: com.facetec.sdk.op.$$e(byte, byte, short):java.lang.String");
    }

    static {
        init$1();
        $10 = 0;
        $11 = 1;
        init$0();
        j = 0;
        i = 1;
        char[] cArr = new char[2156];
        ByteBuffer.wrap("{1l&UÃ=|&A\u000fµ÷YØöÁ\u009a©D\u0092ï{\u0099c&Tí<w%\u001e\u000eºöpß\u0003À¹¨]\u0091Íz\u0085b*Kß<\u0081$#âyõnÌ\u008b¤4¿\t\u0096ýn\u0011A¾XÒ0\f\u000b§âÑúnÍ¥¥.¼[\u0097æo/FqYæ1\u0016\b¨ãÝûfÒ\u0092u)b>[Û3d(Y\u0001\u00adùAÖîÏ\u0082§\\\u009c÷u\u0081m>Zõ2}+\u001b\u0000¨øy\u001fâ\bâ1\fYªB\u0092kl\u0093\u008a¼-¥XÍ\u009dö0\u001f\u0016\u0007ú0\u000eX©AÍjk\u0092¸»Æ¤qÌ¢õ#\u001eD\u0006ý/\u0019XT@çi\u0000âyõoÌ\u009a¤!¿\t\u0096þn\u0019AüXÆ0\u0018\u000b¡âÒâyõoÌ\u009a¤!¿\t\u0096én\u0017A¿X\u00980\u001a\u000b¼âÍúv\u0004{\u0013{*\u0088B#YEpê\u0088\u0018§ÿ¾æÖ.í\u0081\u0004Ï\u001cr+\u009dC\u0018ZQqà\u0089)sëdü]\u001d5¤.Õ\u0007'ÿÂÐ#ÉT¡\u008d\u009a5s^kò\\\u0007â$õeÌÀ¤ ¿I\u0096õn\nAüXÄ0\u000f\u000bªâÐúiÍ\u0093¥:¼m\u0097øo/FZYÝ1\u0002\b´ãÍû#\u0013D\u0004\u0005= U@N)g\u0095\u009fj°\u009c©¤ÁoúÊ\u0013°\u000b\t<óTZM\rf\u0098\u009eO·:¨½ÀbùÔ\u0012\u00ad\n@âyõyÌ\u0097¤1¿R\u0096ÿn\u0013AýXÚ0\u0003\u000b¬â\u008dújÍ\u0093¥<¼\\\u0097ôodF]YíÐ`Ç7þÝ\u0096x\u008d\u001d¤¶¨u¿4%\u00912\u0091\u000b\u007fcÙxºQ\u0017©û\u0086\u0015\u009f<÷ëÌH%e=\u0080\nwbÛ{¯P(¨ï\u0081ë\u009e\u0004öëÏ_$#<×\u0015}b-z\u0088S~«Ü\u0080½\u0099\u001aâyõyÌ\u0097¤1¿R\u0096ÿn\u0013AýXÔ0\u0003\u000b â\u008dúhÍ\u009f¥3¼G\u0097Ào\u0007F\u0003Yò1\u0014\bµãÎ\u0012v\u0005v<\u0098T>O]fð\u009e\u001c±ò¨ÕÀ\fû£\u0012\u0082\ne=\u009cU3LSgü\u009f(¶T©ÛÁ$ø¥\u0013Ã\u000br\"\u0089U\u008bMrd\u0082âyõnÌ\u008b¤4¿\t\u0096ôn\u001bA¿XÃ0\r\u000b»âÇúuÍ\u008eâ$õeÌÀ¤ ¿S\u0096ón\u0012A¶X\u00980\u0002\u000b¡âÑúrâ8õoÌ\u008f¤1¿C\u0096´n\u0010A·XÂÍUÚVã°\u008b\u0001\u0090i¹\u0099A4n\u0097wö\u001f#$\u0091Í÷ÕYâ¢\u008a\u0017\u0093s¸Éâ8õoÌ\u0083¤7¿U\u0096ü\u0091 \u0086a¿Ä×6ÌPåñ\u001d\u001e2£+ÑC\u001axä\u0091Ë\u0089c¾\u0090Ö/ÏPäó\u001c-5^*óB\u0010{»\u0090ÈP\u0094GÊ~%\u0016\u009eâ&õoÌ\u009c¤1¿O\u0096én\nAüXÅ0\u0013\u000b½â\u008cúdÍ\u009e¥p¼V\u0097óo(F[Yå1H\b½ãÎûgÒØ¥Ì½o\u0094\u0089l#Ge^ù6\u0002\t£àÕø\u001cÓ§ªÈ\u0082~\u0095\u009bm DS_\u0098àG÷\u000eÎý¦P½.\u0094\u0088lkC\u009dZ¤2r\tÜàíø\u0005Ïÿ§\u0011¾7\u0095\u0092mID:[\u00843)\nÜá¯ù\u0006Ð¹§\u00ad¿\u000e\u0096ènBE\u0004\\\u00984c\u000bÂâ´úyÑÆ¨©\u0080\u001f\u0097ðoAÊhÝ!äÒ\u008c\u007f\u0097\u0001¾§FDi²p\u008b\u0018]#óÊÂÒ*åÐ\u008d>\u0094\u0018¿½Gfn\u0015q«\u0019\u0006 æË\u009fÓrúÛ\u008d\u0095\u0095)â&õoÌ\u009c¤1¿O\u0096én\nAüXÅ0\u0013\u000b½â\u008cúdÍ\u009e¥p¼V\u0097óo(F[Yå1H\b¨ãÑû<Ò\u009a¥Ë½m\u00811\u0096x¯\u008bÇ&ÜXõþ\r\u001d\"ë;ÒS\u0004hª\u0081\u009b\u0099s®\u0089ÆgßAôä\f?%L:òR_k¿\u0080Æ\u0098+±\u008cÆÞÞzâ&õoÌ\u009c¤1¿O\u0096én\nAüXÅ0\u0013\u000b½â\u008cúdÍ\u009e¥p¼V\u0097óo(F[Yå1H\b¨ãÑû<Ò\u009b¥Ä½mâ õhÌ\u0081¤:¿U\u0096üâyõzÌ\u009c¤-¿E\u0096µn\u0013A½XÒ0\u001f\u000b¢âÇúu2¦%î\u001c\u0007t¼oÇFi¾\u009d\u0091'\u0088DâyõyÌ\u0097¤1¿R\u0096ÿn\u0013AýXÐ0\u0018\u000b¯âÏúcÍ\u008d¥1¼@\u0097ýoeFYYë1\b\b¾ãÑûeÒ\u0085¥\u0087½}\u0094\u009bl5GN^û6\u001f\t\u0089àùø\u000bÓ°ªÐ\u0082\u007f\u0095\u008cm|D\\_\u008b7<çYð\\É«¡\fºb\u0093Õk,DÝ]ú5#\u000e\u008cç´ÿ\u0012Èõ \u0016¹e\u0092\u0099j\u000bC{\\Æ4/\r\u0095æ°þB×¤ ã¸C\u0091£i\u0014Bc[\u00903%\f\u009fåÄý*Ö\u008d¯ñ\u0087I\u0090ðh\u0001AyZ\u001eM\u001btì\u001cK\u0007%.\u0092Ökù\u009aà½\u0088d³ËZóBUu²\u001dQ\u0004\"/Þ×Eþ>á\u0086\u0089n°Ð[©C\u001ajâ\u001d¨\u0005\u001b,«ÔVÿ4æ\u0097\u008eq±ÞX\u009a@zk\u008b\u0012²:\u0012«(¼(\u0085Æí`ö\u0003ß®'B\b¬\u0011\u008byRBý«Å³c\u0084\u0084ìlõ\u000fÞ¨&n\u000f\u001b\u0010\u008cxVAâª\u008b²/\u009bøì\u0092ô1ÝÇ%r\u000e\u0019\u0017©\u007fB@ä©¾±\u0012\u009aðã\u0087Ë;Ü\u0081$p\r\bâyõoÌ\u009a¤!¿\t\u0096ón\u0010A»XÂ0E\u000b§âÌúoÍ\u008e¥p¼Q\u0097úo%F[Yæ1\u0015\b¿ãÌûdÒ\u009f¥É½k\u0094Ìl4GY¬X»&\u0082Éêrñ\u0002Ø¼ C\u000fò\u0016\u0090~Mâ#õdÌ\u0085¤,¿I\u0096ín\u0010â5õbÌ\u009c¤-¿K\u0096ón\u000bA¿â$õeÌÀ¤2¿T\u0096õn\u001aA§XÕ0\u001e\u000bàâÆúcÍ\u008c¥7¼Q\u0097óâ õhÌ\u0081¤:¿\u001e\u0096¬n\u000eâ1õoÌ\u0080¤'¿T\u0096ón\u001d:Ï-\u0091\u0014~|ÙgªN\r¶ã\u0099s\u00800è¬Ó\u0006k\u0091|ÏE -\u00876ô\u001fSç½È-Ñn¹ò\u0082Xk]s\u0090Dnâ$õeÌÀ¤2¿T\u0096õn\u001aA§XÕ0\u001e\u000bàâÏúiÍ\u009e¥;¼^â%õnÌ\u0085]2Jfs\u009a\u001b/\u0000F)ïÑ\u0010þ¡â\u0017õzÌ\u009e¤b¿t\u0096ïn\u0010A¦Xß0\u0007\u000b«â\u0082ú`Í\u0095¥,¼\u0012\u0097Õo\"F\\Yí1\u000b\b¿:\b-{\u0014\u0095|/gVNì¶\u0005\u0099í\u0080úè1Ó\u009a:\u009d\"{\u0015\u0090}(dAOý·u\u009eW\u0081òé\u000bÐå;Ù#5\nßâ\u0017õdÌ\u008a¤0¿I\u0096ón\u001aAòXå0.\u000b\u0085â\u0082údÍ\u008f¥7¼^\u0097âojFHYí1\u0014\búãÆû*ÒÀ¥õ½8\u0094Ö¨\u0002¿C\u0086æî\fõaÜÎ$<\u000b\u0083\u0012ñz>A\u008duyb-[Ê3n(\b\u0001»ùEÖòâ õhÌ\u0081¤:¿\u001e\u0096¬?g((\u0011Ãybb\rK¬â$õeÌÀ¤2¿T\u0096õn\u001aA§XÕ0\u001e\u000bàâÀútÍ\u009b¥0¼V\"\u00025C\fæd\u000f\u007feVÎ®6\u0081\u0091\u0098üðbË\u0099\"á:M\r©¿¤+«<ê\u0005Om¾vÌ_v§\u0084\u0088/\u0091\\âfâ$õeÌÀ¤ ¿S\u0096ón\u0012A¶X\u00980\u001a\u000b¼âÍúbÍ\u008f¥=¼F0ù'¶\u001eKvçm°D+¼\u008f\u0093-ÁNÖ\u000fïª\u0087J\u009c9µ\u0099MxbÜ{ò\u0013f(ÍÁ¦Ù\u000bîõ\u0086F\u009f(´\u008eLIe*z\u009c¼Ø«\u0086\u0092iúÎá½È\u001a0ô\u001f\u0014\u0006,nçUL¼d¤\u0088\u0093vûÙâ¾É\r1Ê\u0018¤â1õoÌ\u0080¤'¿T\u0096ón\u001dA\u008dXÎ0R\u000bøâ\u008dúuÍ\u009e¥5¼m\u0097îorF\u0018Y\u00ad1\u0001\b¿ãÐûwÒ\u0084¥Ã½m\u0094½l>G\u0002^¨â1õoÌ\u0080¤'¿T\u0096ón\u001dAýXÑ0\u0005\u000b¡âÅújÍ\u009f¥\u0001¼A\u0097òo!F\u0001Yå1\u0003\b´ãÛû`Ò\u009f¥Éâ1õoÌ\u0080¤'¿T\u0096ón\u001dAýXÀ0\b\u000b¡âÚú>ÍÌ¥.¼\u001d\u0097ào(FAYú1^\bìãÎi³~çG\u0003/§4È\u001d}åÓÊ#ÓP»\u0083\u0080\u0013iGqôF\u0010.³7Þ\u001cqä\u0097ÍÔÒ8ºÒ\u0083wh[põY\u001a.M6þ\u001f\tç§ÌçÕd½È\u0082bâ$õeÌÀ¤ ¿I\u0096õn\nA¾XÙ0\u000b\u000bªâÇútâ$õeÌÀ¤ ¿I\u0096õn\nA»XÛ0\u000b\u000b©âÇú(Í\u0098¥+¼[\u0097úo.F\u0000Yä1\u000f\b´ãÙûwÒ\u0084¥Ú½|\u0094\u008bl(GNy\u001bnhW\u0086?<$E\rÿõ\u0016ÚóÃÂ«^\u0090ô\u0094{\u0083:º\u009fÒ\u007fÉ\fà¬\u0018M7é.ÇFQ}ø\u0094\u008e\u008c)»ÉÓ`Ê\u0014áç\u0019|0\u0015¨»¿ö\u0086\u0004î¯õ\u0092â?õdÌ\u0087¤6¿\b\u0096én\bA±X\u00980\u001b\u000b«âÏúsÍ×¥.¼@\u0097ùo:F]\"\u009b5Ó\f?d\u008b\u007f´VN®µ\u0081@\u0098gð·Ë\u001b\"p:Ñ\r#e\u009b|ýâ'õoÌ\u0083¤7¿\b\u0096én\u0018AüXÐ0\u000b\u000b¥âÇúYÍ\u0099¥?¼_\u0097óo8FO\u009a \u008dh´\u0084Ü0Ç\u000fîî\u0016\u001f9û ÝH\u000es\u00ad\u009aú\u0082eµ\u0098Ý7ÄFïø\u00179>Pâ$õeÌÀ¤)¿C\u0096èn\u0010A·XÚ0D\u000b¯âÌúbÍ\u0088¥1¼[\u0097òodF_Yç1\u000b\b¯ãÚâ$õeÌÀ¤ ¿I\u0096õn\nAüXÇ0\u000f\u000b£â×ú(Í\u009b¥(¼V\u0097Éo$FOYï1\u0003KÚ\\\u009be>\rÓ\u0016¼?\tÇ®èNñ=\u0099ý¢\\K8SÖdb\fÉ\u0015¢>\u000fÆÑï¢ð\f\u0098ê¡MJ.R\u0098¹Þ®\u009f\u0097:ÿÈä®Í\u000f5à\u001a]\u0003/käP\u001a¹:¡\u0089\u0096iþÈç¬ÌB4Ö\u001d½\u0002\u0016jûSE¸6 \u0098\u0089~þ9æ\u009aÏlËuÜ4å\u0091\u008d`\u0096\u000e¿¸G[hæq\u008a\u0019\u0015\"ýË\u0086Ó>äÇ\u008ck\u0095M¾¡Fro\u0011p´\u0018R!ùÊ\u009fÒ1ûÎ\u008c\u0095\u0094+ÊØÝ\u0099ä<\u008cÍ\u0097£¾\u0015FöiKp'\u0018É#WÊ&Ò\u008eå(\u008dÀ\u0094»¿\u0003GÚn¶qP\u0019ü OË,Ó\u0089úo\u008d$\u0095\u0082¼lDÓo¨v\u0016~ki*P\u008f8{#\f\n»òUÝòÄ\u008b¬\u000b\u0097ã~\u0098f QÙ9u S\u000b¿ólÚ\u000fÅª\u00adL\u0094ç\u007f\u0081g/NÐ9\u008b!5â$õeÌÀ¤4¿C\u0096ôn\u001aA½XÄ05\u000bªâÎúmÍ\u0097¥p¼P\u0097ão#FBYæ1H\b¼ã×û|Ò\u0091¥Ï½|\u0094\u0092l4GS^ð6\u0006â~¨¸¿èq÷â\u007f¾\u0097©\u0080\u0090eøÚãçÊ\u00052õ\u001dQ\u0004-lÛWP¾%¦\u0098\u0091qâyõnÌ\u008b¤4¿\t\u0096én\u0011A±XÝ0\u000f\u000bºâ\u008dúdÍ\u009b¥-¼W\u0097ôo+F@Yæ19\b½ãÛû|Ò\u008f¥ÎâyõnÌ\u008b¤4¿\t\u0096én\u0011A±XÝ0\u000f\u000bºâ\u008dúaÍ\u009f¥0¼K\u0097òâyõnÌ\u008b¤4¿\t\u0096én\u0011A±XÝ0\u000f\u000bºâ\u008dúwÍ\u009f¥3¼G\u0097òâyõyÌ\u0097¤1¿\t\u0096ën\u001bA¿XÃ05\u000bºâÐúgÍ\u0099¥;Ix^xg\u0096\u000f0\u0014S=þÅ\u0012êüóÛ\u009b\u0002 \u00adI\u008cQkf\u0092\u000e=\u0017P<ÈÄ&íNòï\u009a\u000b£´HÜPLy\u0093\u000eÎ\u0016m?\u0096Ç ìdõî\u009d\u0016¢ºKþSAx°\u0001ÈâyõnÌ\u008b¤4¿\t\u0096øn\rA¦Xé0\r\u000b¾âÑ§I°^\u0089»á\u0004ú9ÓÈ+=\u0004\u0096\u001dÙu.N\u0097§ÿ¿SâyõnÌ\u008b¤4¿\t\u0096én\u0011A±XÝ0\u000f\u000bºâ\u008dúdÍ\u0089¥*¼T\u0097ùo&FJYç1\u0014\b¾âyõyÌ\u0097¤1¿R\u0096ÿn\u0013AýXÚ0\u0003\u000b¬â\u008dújÍ\u0093¥<¼P\u0097åo>FHYí1\n\b¾ãÛû`Ò©¥À½`\u0094\u008blhGI^ñâyõnÌ\u008b¤4¿\t\u0096øn\rA¦X×0\t\u000b\u00adâÇâyõnÌ\u008b¤4¿\t\u0096øn\rA¦XÑ0\u0013\u000b¼âÍâyõnÌ\u008b¤4¿\t\u0096øn\rA¦XÛ0\u000f\u000b©âÌ\u0096Ñ\u0081Æ¸#Ð\u009cË¡âP\u001a¥5\u000e,qD°\u007f\u000f\u0096ohk\u007f|F\u0099.&5\u001b\u001cêä\u001fË´ÒÒº\u0015\u0081¯h×{\u0085l\u0092Uw=È&õ\u000f\u0004÷ñØZÁ:©ñ\u0092S{7c\u008aTeâyõnÌ\u008b¤4¿\t\u0096øn\rA¦Xé0\u0003\u000b£âÇâyõnÌ\u008f¤6¿G\u0096µn\u001aA½XÁ0\u0004\u000b¢âÍúgÍ\u009e¥-¼\u001d\u0097¸o2FLY\u00ad1\u0004\b©ãÊûyâyõgÌ\u0080¤6¿\t\u0096ín\u0017A¼XÒ0\u0005\u000b¹âÑú)Í¸¥-¼F\u0097Åo\"FOYð1\u0003\b¾ãøû}Ò\u009a¥Î½k\u0094\u0090âyõzÌ\u009c¤-¿E\u0096µn\u0017A½XÆ0\u0005\u000b¼âÖúubñuûL\u001f$õ?\u008bo\u0001x\u0002Aä)U2=\u001bÍãuÌÏÕ¢½t\u0086\u0099o·w\u001f@ò(Uâ1õxÌ\u008f¤.¿J\u0096õn\u001dAüXÑ0\u0005\u000b¢âÆú`Í\u0093¥-¼Z\u0097¸o9FA-\u001b:B\u0003\u00adk$pKYþ¡\f\u008e¬\u0097õÿ8Ä\u009b-\u00ad5T\u0002´âyõoÌ\u009a¤!¿\t\u0096÷n\u001bA¶Xß0\u000b\u000b\u0091âÁúiÍ\u009e¥;¼Q\u0097åodFVYï1\nâ4õfÌ\u009b¤'¿U\u0096în\u001fA±XÝ0\u0019âyõoÌ\u009a¤!¿\t\u0096÷n\u0011A§XØ0\u001e\u000b½âyõnÌ\u008f¤6¿G\u0096µn\u001aA½XÁ0\u0004\u000b¢âÍúgÍ\u009e¥-¼\u001d\u0097¸o.F^Y\u00ad1\u0007\bªãÎûaÒØ¥Ò½c\u0094\u008eôzãyÚ\u009f².©F\u0080¶x\u001eW¡NÀ&\u0000\u001d£ôÇìjâ\u0011õeÌ\u0082¤&¿@\u0096ón\rAºâyõnÌ\u008f¤6¿G\u0096µn\u0013A»XÅ0\t\u000báâÒútÍ\u0095¥8¼[\u0097úo/F]Y\u00ad1\u0005\b¯ãÌû=ÒÆ¥\u0085½m\u0094\u008dl+G\u0014^ó6\u001b\tµàøø\u0001Ó´ªÏ\u0082h\u0095\u008am|D[_\u008f7#\u000eWáïù\u0017Ð»".getBytes(LocalizedMessage.DEFAULT_ENCODING)).asCharBuffer().get(cArr, 0, 2156);
        f = cArr;
        h = 5469984584049882378L;
    }

    public op(nf nfVar, oe oeVar, pz pzVar, pu puVar) {
        this.e = nfVar;
        this.b = oeVar;
        this.d = pzVar;
        this.a = puVar;
    }

    public static /* synthetic */ Object c(int i2, int i3, int i4, Object[] objArr, int i5, int i6, int i7) {
        int i8 = ~i4;
        int i9 = (~(i8 | i2)) | (~(i3 | i2));
        int i10 = i3 | i4;
        int i11 = (~(i4 | (~i2))) | (~(i8 | (~i3))) | (~i10);
        int i12 = i3 + i2 + i5 + (1350191703 * i6) + ((-44904237) * i7);
        int i13 = i12 * i12;
        int i14 = ((i3 * (-560584373)) - 948043776) + ((-560584373) * i2) + ((-826660534) * i9) + (i10 * 826660534) + (826660534 * i11) + (266076160 * i5) + ((-71041024) * i6) + ((-766246912) * i7) + (1339949056 * i13);
        int i15 = (i3 * 1657715387) + 2046152777 + (i2 * 1657715387) + (i9 * (-918)) + (i10 * 918) + (i11 * 918) + (i5 * 1657716305) + (i6 * 1507858311) + (i7 * 1845144771) + (i13 * 155058176);
        return i14 + ((i15 * i15) * 417464320) != 1 ? b(objArr) : a(objArr);
    }

    public static void init$0() {
        $$a = new byte[]{84, -122, 19, 43};
        $$b = 16;
    }

    public static void init$1() {
        $$c = new byte[]{90, 10, -103, 87};
        $$d = 105;
    }

    /* JADX WARN: Removed duplicated region for block: B:52:0x02a0  */
    /* JADX WARN: Removed duplicated region for block: B:53:0x02a1  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    private static void k(int r31, char r32, int r33, java.lang.Object[] r34) throws java.lang.Throwable {
        /*
            Method dump skipped, instruction units count: 684
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: com.facetec.sdk.op.k(int, char, int, java.lang.Object[]):void");
    }

    /* JADX WARN: Removed duplicated region for block: B:10:0x0022  */
    /* JADX WARN: Removed duplicated region for block: B:8:0x001a  */
    /* JADX WARN: Unsupported multi-entry loop pattern (BACK_EDGE: B:10:0x0022 -> B:11:0x0026). Please report as a decompilation issue!!! */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    private static void l(byte r5, byte r6, short r7, java.lang.Object[] r8) {
        /*
            int r5 = r5 * 2
            int r5 = r5 + 4
            byte[] r0 = com.facetec.sdk.op.$$a
            int r6 = r6 * 4
            int r1 = r6 + 1
            int r7 = r7 + 97
            byte[] r1 = new byte[r1]
            r2 = 0
            if (r0 != 0) goto L14
            r4 = r6
            r3 = r2
            goto L26
        L14:
            r3 = r2
        L15:
            byte r4 = (byte) r7
            r1[r3] = r4
            if (r3 != r6) goto L22
            java.lang.String r5 = new java.lang.String
            r5.<init>(r1, r2)
            r8[r2] = r5
            return
        L22:
            int r3 = r3 + 1
            r4 = r0[r5]
        L26:
            int r4 = -r4
            int r7 = r7 + r4
            int r5 = r5 + 1
            goto L15
        */
        throw new UnsupportedOperationException("Method not decompiled: com.facetec.sdk.op.l(byte, byte, short, java.lang.Object[]):void");
    }

    @Override // com.facetec.sdk.oi
    public final qj a(nj njVar, long j2) {
        int i2 = i + 81;
        j = i2 % 128;
        if (i2 % 2 != 0) {
            "chunked".equalsIgnoreCase(njVar.a("Transfer-Encoding"));
            throw null;
        }
        if ("chunked".equalsIgnoreCase(njVar.a("Transfer-Encoding"))) {
            j = (i + 55) % 128;
            if (this.c == 1) {
                this.c = 2;
                return new a();
            }
            StringBuilder sb = new StringBuilder("state: ");
            sb.append(this.c);
            throw new IllegalStateException(sb.toString());
        }
        if (j2 == -1) {
            throw new IllegalStateException("Cannot stream a request body without chunked encoding or a known content length!");
        }
        j = (i + 75) % 128;
        if (this.c != 1) {
            StringBuilder sb2 = new StringBuilder("state: ");
            sb2.append(this.c);
            throw new IllegalStateException(sb2.toString());
        }
        this.c = 2;
        d dVar = new d(j2);
        int i3 = j + 65;
        i = i3 % 128;
        if (i3 % 2 != 0) {
            return dVar;
        }
        throw null;
    }

    @Override // com.facetec.sdk.oi
    public final void b() {
        int i2 = i + 29;
        j = i2 % 128;
        if (i2 % 2 == 0) {
            this.a.flush();
        } else {
            this.a.flush();
            int i3 = 27 / 0;
        }
    }

    /* JADX WARN: Removed duplicated region for block: B:11:0x0043  */
    @Override // com.facetec.sdk.oi
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public final void d(com.facetec.sdk.nj r9) {
        /*
            r8 = this;
            com.facetec.sdk.oe r0 = r8.b
            com.facetec.sdk.nx r0 = r0.b()
            com.facetec.sdk.nm r0 = r0.b()
            java.net.Proxy r0 = r0.e()
            java.net.Proxy$Type r0 = r0.type()
            java.lang.StringBuilder r1 = new java.lang.StringBuilder
            r1.<init>()
            java.lang.String r2 = r9.c()
            r1.append(r2)
            r2 = 32
            r1.append(r2)
            boolean r2 = r9.j()
            r3 = 0
            r4 = 1
            if (r2 != 0) goto L44
            int r2 = com.facetec.sdk.op.j
            int r2 = r2 + 59
            int r5 = r2 % 128
            com.facetec.sdk.op.i = r5
            int r2 = r2 % 2
            if (r2 != 0) goto L3f
            java.net.Proxy$Type r2 = java.net.Proxy.Type.HTTP
            r5 = 86
            int r5 = r5 / r3
            if (r0 != r2) goto L44
            goto L43
        L3f:
            java.net.Proxy$Type r2 = java.net.Proxy.Type.HTTP
            if (r0 != r2) goto L44
        L43:
            r3 = r4
        L44:
            r0 = r3 ^ 1
            if (r0 == r4) goto L65
            int r0 = com.facetec.sdk.op.j
            int r0 = r0 + 9
            int r2 = r0 % 128
            com.facetec.sdk.op.i = r2
            int r0 = r0 % 2
            if (r0 == 0) goto L5c
            com.facetec.sdk.nc r0 = r9.b()
            r1.append(r0)
            goto L70
        L5c:
            com.facetec.sdk.nc r9 = r9.b()
            r1.append(r9)
            r9 = 0
            throw r9
        L65:
            com.facetec.sdk.nc r0 = r9.b()
            java.lang.String r0 = com.facetec.sdk.om.a(r0)
            r1.append(r0)
        L70:
            java.lang.String r0 = " HTTP/1.1"
            r1.append(r0)
            java.lang.String r0 = r1.toString()
            com.facetec.sdk.mz r9 = r9.a()
            java.lang.Object[] r4 = new java.lang.Object[]{r8, r9, r0}
            int r3 = com.facetec.sdk.oe.b.d()
            int r5 = com.facetec.sdk.oe.b.d()
            int r6 = com.facetec.sdk.oe.b.d()
            int r7 = com.facetec.sdk.oe.b.d()
            r2 = 1889770819(0x70a39d43, float:4.050894E29)
            r1 = -1889770818(0xffffffff8f5c62be, float:-1.08658545E-29)
            c(r1, r2, r3, r4, r5, r6, r7)
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: com.facetec.sdk.op.d(com.facetec.sdk.nj):void");
    }

    @Override // com.facetec.sdk.oi
    public final void e() {
        int i2 = j + 83;
        i = i2 % 128;
        if (i2 % 2 == 0) {
            this.b.b();
            throw null;
        }
        nx nxVarB = this.b.b();
        if (nxVarB != null) {
            nxVarB.c();
        }
        i = (j + EnumC41897g.SDK_ASSET_ILLUSTRATION_CALENDAR_VALUE) % 128;
    }

    @Override // com.facetec.sdk.oi
    public final no c(nh nhVar) {
        oe oeVar = this.b;
        na naVar = oeVar.a;
        mn mnVar = oeVar.c;
        String strA = nhVar.a(Header.CONTENT_TYPE);
        if (!oh.a(nhVar)) {
            return new on(strA, 0L, qf.d(e(0L)));
        }
        if ("chunked".equalsIgnoreCase(nhVar.a("Transfer-Encoding"))) {
            nc ncVarB = nhVar.c().b();
            if (this.c == 4) {
                this.c = 5;
                return new on(strA, -1L, qf.d(new e(ncVarB)));
            }
            StringBuilder sb = new StringBuilder("state: ");
            sb.append(this.c);
            throw new IllegalStateException(sb.toString());
        }
        long jD = oh.d(nhVar);
        if (jD != -1) {
            return new on(strA, jD, qf.d(e(jD)));
        }
        if (this.c != 4) {
            StringBuilder sb2 = new StringBuilder("state: ");
            sb2.append(this.c);
            throw new IllegalStateException(sb2.toString());
        }
        oe oeVar2 = this.b;
        if (oeVar2 == null) {
            throw new IllegalStateException("streamAllocation == null");
        }
        this.c = 5;
        oeVar2.c();
        return new on(strA, -1L, qf.d(new j()));
    }

    public abstract class b implements ql {
        protected boolean a;
        private long b;
        private py e;

        private b() {
            this.e = new py(op.this.d.a());
            this.b = 0L;
        }

        @Override // com.facetec.sdk.ql
        public final qp a() {
            return this.e;
        }

        public final void b(boolean z, IOException iOException) {
            int i = op.this.c;
            if (i == 6) {
                return;
            }
            if (i != 5) {
                StringBuilder sb = new StringBuilder("state: ");
                sb.append(op.this.c);
                throw new IllegalStateException(sb.toString());
            }
            op.a(this.e);
            op opVar = op.this;
            opVar.c = 6;
            oe oeVar = opVar.b;
            if (oeVar != null) {
                oeVar.b(!z, opVar, iOException);
            }
        }

        @Override // com.facetec.sdk.ql
        public long e(px pxVar, long j) throws IOException {
            try {
                long jE = op.this.d.e(pxVar, j);
                if (jE <= 0) {
                    return jE;
                }
                this.b += jE;
                return jE;
            } catch (IOException e) {
                b(false, e);
                throw e;
            }
        }

        public /* synthetic */ b(op opVar, byte b) {
            this();
        }
    }

    private static /* synthetic */ Object b(Object[] objArr) {
        op opVar = (op) objArr[0];
        int i2 = j + 83;
        i = i2 % 128;
        if (i2 % 2 != 0) {
            opVar.a.flush();
            j = (i + 45) % 128;
            return null;
        }
        opVar.a.flush();
        throw null;
    }

    public final ql e(long j2) {
        i = (j + 5) % 128;
        if (this.c == 4) {
            this.c = 5;
            c cVar = new c(j2);
            i = (j + 15) % 128;
            return cVar;
        }
        StringBuilder sb = new StringBuilder("state: ");
        sb.append(this.c);
        throw new IllegalStateException(sb.toString());
    }

    public final void e(mz mzVar, String str) {
        c(-1889770818, 1889770819, oe.b.d(), new Object[]{this, mzVar, str}, oe.b.d(), oe.b.d(), oe.b.d());
    }

    private String d() {
        i = (j + 9) % 128;
        String strB = this.d.b(this.f95933g);
        this.f95933g -= (long) strB.length();
        j = (i + 97) % 128;
        return strB;
    }

    private static /* synthetic */ Object a(Object[] objArr) {
        op opVar = (op) objArr[0];
        mz mzVar = (mz) objArr[1];
        String str = (String) objArr[2];
        int i2 = i + 5;
        j = i2 % 128;
        if (i2 % 2 != 0) {
            int i3 = opVar.c;
            throw null;
        }
        if (opVar.c != 0) {
            StringBuilder sb = new StringBuilder("state: ");
            sb.append(opVar.c);
            throw new IllegalStateException(sb.toString());
        }
        opVar.a.a(str).a("\r\n");
        int iD = mzVar.d();
        for (int i4 = 0; i4 < iD; i4++) {
            i = (j + 13) % 128;
            opVar.a.a(mzVar.a(i4)).a(": ").a(mzVar.b(i4)).a("\r\n");
        }
        opVar.a.a("\r\n");
        opVar.c = 1;
        int i5 = i + 37;
        j = i5 % 128;
        if (i5 % 2 == 0) {
            return null;
        }
        throw null;
    }

    @Override // com.facetec.sdk.oi
    public final nh.e c(boolean z) throws IOException {
        i = (j + 109) % 128;
        int i2 = this.c;
        if (i2 != 1 && i2 != 3) {
            StringBuilder sb = new StringBuilder("state: ");
            sb.append(this.c);
            throw new IllegalStateException(sb.toString());
        }
        try {
            ok okVarB = ok.b(d());
            nh.e eVarA = new nh.e().b(okVarB.e).e(okVarB.b).d(okVarB.a).a(c());
            if (z) {
                int i3 = (i + EnumC41897g.SDK_ASSET_ILLUSTRATION_CALENDAR_VALUE) % 128;
                j = i3;
                if (okVarB.b == 100) {
                    int i4 = i3 + 49;
                    i = i4 % 128;
                    if (i4 % 2 != 0) {
                        return null;
                    }
                    throw null;
                }
            }
            if (okVarB.b == 100) {
                int i5 = i + 5;
                j = i5 % 128;
                int i6 = i5 % 2;
                this.c = 3;
                return eVarA;
            }
            this.c = 4;
            return eVarA;
        } catch (EOFException e2) {
            StringBuilder sb2 = new StringBuilder("unexpected end of stream on ");
            sb2.append(this.b);
            IOException iOException = new IOException(sb2.toString());
            iOException.initCause(e2);
            throw iOException;
        }
    }

    /* JADX WARN: Code restructure failed: missing block: B:10:0x002d, code lost:
    
        return;
     */
    /* JADX WARN: Code restructure failed: missing block: B:12:0x0035, code lost:
    
        throw new java.lang.IllegalArgumentException("delegate == null");
     */
    /* JADX WARN: Code restructure failed: missing block: B:5:0x0014, code lost:
    
        if (r1 != null) goto L9;
     */
    /* JADX WARN: Code restructure failed: missing block: B:8:0x001b, code lost:
    
        if (r1 != null) goto L9;
     */
    /* JADX WARN: Code restructure failed: missing block: B:9:0x001d, code lost:
    
        r3.c = r1;
        r0.d_();
        r0.c_();
        com.facetec.sdk.op.i = (com.facetec.sdk.op.j + 7) % 128;
     */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public static void a(com.facetec.sdk.py r3) {
        /*
            int r0 = com.facetec.sdk.op.i
            int r0 = r0 + 45
            int r1 = r0 % 128
            com.facetec.sdk.op.j = r1
            int r0 = r0 % 2
            if (r0 == 0) goto L17
            com.facetec.sdk.qp r0 = r3.c
            com.facetec.sdk.qp r1 = com.facetec.sdk.qp.b
            r2 = 82
            int r2 = r2 / 0
            if (r1 == 0) goto L2e
            goto L1d
        L17:
            com.facetec.sdk.qp r0 = r3.c
            com.facetec.sdk.qp r1 = com.facetec.sdk.qp.b
            if (r1 == 0) goto L2e
        L1d:
            r3.c = r1
            r0.d_()
            r0.c_()
            int r3 = com.facetec.sdk.op.j
            int r3 = r3 + 7
            int r3 = r3 % 128
            com.facetec.sdk.op.i = r3
            return
        L2e:
            java.lang.IllegalArgumentException r3 = new java.lang.IllegalArgumentException
            java.lang.String r0 = "delegate == null"
            r3.<init>(r0)
            throw r3
        */
        throw new UnsupportedOperationException("Method not decompiled: com.facetec.sdk.op.a(com.facetec.sdk.py):void");
    }

    @Override // com.facetec.sdk.oi
    public final void a() {
        c(-967514993, 967514993, oe.b.d(), new Object[]{this}, oe.b.d(), oe.b.d(), oe.b.d());
    }

    /* JADX WARN: Removed duplicated region for block: B:103:0x0ae6  */
    /* JADX WARN: Removed duplicated region for block: B:145:0x0f30 A[PHI: r6
      0x0f30: PHI (r6v426 java.lang.String) = (r6v422 java.lang.String), (r6v431 java.lang.String) binds: [B:144:0x0f2e, B:137:0x0edb] A[DONT_GENERATE, DONT_INLINE]] */
    /* JADX WARN: Removed duplicated region for block: B:164:0x103e  */
    /* JADX WARN: Removed duplicated region for block: B:183:0x114f  */
    /* JADX WARN: Removed duplicated region for block: B:252:0x19e9  */
    /* JADX WARN: Removed duplicated region for block: B:280:0x286e  */
    /* JADX WARN: Removed duplicated region for block: B:376:0x365a A[Catch: all -> 0x37b3, TryCatch #3 {all -> 0x37b3, blocks: (B:6:0x0124, B:8:0x0131, B:10:0x0176, B:20:0x02d2, B:22:0x02df, B:24:0x0322, B:31:0x041f, B:33:0x042c, B:34:0x0464, B:62:0x0657, B:64:0x065d, B:65:0x0696, B:84:0x091b, B:86:0x0928, B:88:0x0969, B:95:0x0a62, B:97:0x0a6c, B:98:0x0aa5, B:105:0x0b90, B:107:0x0b9f, B:108:0x0bd4, B:118:0x0cc1, B:120:0x0ccb, B:121:0x0d04, B:132:0x0e8a, B:134:0x0e94, B:135:0x0ecc, B:191:0x1266, B:193:0x1273, B:194:0x12ad, B:199:0x1355, B:201:0x1362, B:202:0x1396, B:213:0x14d1, B:215:0x14de, B:216:0x1516, B:223:0x15ff, B:225:0x1605, B:226:0x163b, B:230:0x1702, B:232:0x1713, B:233:0x174d, B:239:0x1885, B:241:0x188f, B:243:0x18cb, B:245:0x18d6, B:247:0x18f0, B:248:0x192c, B:288:0x2919, B:290:0x2923, B:291:0x2963, B:307:0x2e7e, B:309:0x2e8b, B:310:0x2ec6, B:316:0x2fa3, B:318:0x2fb0, B:319:0x2fe8, B:338:0x331c, B:340:0x332c, B:342:0x3382, B:374:0x364d, B:376:0x365a, B:377:0x3693, B:294:0x296f, B:296:0x2988, B:297:0x29c3, B:255:0x263a, B:257:0x2644, B:259:0x268b, B:267:0x26a8, B:269:0x26b9, B:270:0x26f9, B:140:0x0ee0, B:142:0x0eea, B:143:0x0f25, B:39:0x0552, B:41:0x055c, B:43:0x0597, B:49:0x05db, B:51:0x05e5, B:52:0x061f), top: B:395:0x0124 }] */
    /* JADX WARN: Removed duplicated region for block: B:79:0x0848  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public static java.lang.Object[] a(android.content.Context r68, int r69, int r70, int r71) throws java.lang.Throwable {
        /*
            Method dump skipped, instruction units count: 14268
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: com.facetec.sdk.op.a(android.content.Context, int, int, int):java.lang.Object[]");
    }

    public final mz c() {
        mz.a aVar = new mz.a();
        i = (j + 47) % 128;
        while (true) {
            String strD = d();
            if (strD.length() != 0) {
                int i2 = j + 113;
                i = i2 % 128;
                if (i2 % 2 == 0) {
                    nn.d.c(aVar, strD);
                    int i3 = 31 / 0;
                } else {
                    nn.d.c(aVar, strD);
                }
            } else {
                return aVar.c();
            }
        }
    }
}