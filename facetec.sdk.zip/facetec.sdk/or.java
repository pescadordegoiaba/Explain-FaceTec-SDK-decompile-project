package com.facetec.sdk;

/* JADX INFO: loaded from: classes4.dex */
public enum or {
    NO_ERROR(0),
    PROTOCOL_ERROR(1),
    INTERNAL_ERROR(2),
    FLOW_CONTROL_ERROR(3),
    REFUSED_STREAM(7),
    CANCEL(8),
    COMPRESSION_ERROR(9),
    CONNECT_ERROR(10),
    ENHANCE_YOUR_CALM(11),
    INADEQUATE_SECURITY(12),
    HTTP_1_1_REQUIRED(13);


    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public final int f95934g;

    or(int i) {
        this.f95934g = i;
    }

    public static or b(int i) {
        for (or orVar : values()) {
            if (orVar.f95934g == i) {
                return orVar;
            }
        }
        return null;
    }
}