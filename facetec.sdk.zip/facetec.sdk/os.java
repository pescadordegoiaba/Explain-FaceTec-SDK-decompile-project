package com.facetec.sdk;

import ai.luciq.library.networkv2.request.Constants;

/* JADX INFO: loaded from: classes4.dex */
public final class os {
    final int f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public final qb f95935g;
    public final qb j;
    public static final qb c = qb.d(Constants.SEPARATOR);
    public static final qb a = qb.d(":status");
    public static final qb d = qb.d(":method");
    public static final qb e = qb.d(":path");
    public static final qb b = qb.d(":scheme");
    public static final qb h = qb.d(":authority");

    public interface b {
    }

    public os(String str, String str2) {
        this(qb.d(str), qb.d(str2));
    }

    public final boolean equals(Object obj) {
        if (obj instanceof os) {
            os osVar = (os) obj;
            if (this.j.equals(osVar.j) && this.f95935g.equals(osVar.f95935g)) {
                return true;
            }
        }
        return false;
    }

    public final int hashCode() {
        return ((this.j.hashCode() + 527) * 31) + this.f95935g.hashCode();
    }

    public final String toString() {
        return nu.b("%s: %s", this.j.d(), this.f95935g.d());
    }

    public os(qb qbVar, String str) {
        this(qbVar, qb.d(str));
    }

    public os(qb qbVar, qb qbVar2) {
        this.j = qbVar;
        this.f95935g = qbVar2;
        this.f = qbVar.h() + 32 + qbVar2.h();
    }
}