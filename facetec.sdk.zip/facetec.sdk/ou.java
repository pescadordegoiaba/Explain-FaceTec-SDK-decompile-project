package com.facetec.sdk;

import ai.luciq.library.model.NetworkLog;
import ai.luciq.library.networkv2.request.RequestMethod;
import android.graphics.Color;
import android.graphics.ImageFormat;
import android.media.AudioTrack;
import android.os.Process;
import android.os.SystemClock;
import android.telephony.cdma.CdmaCellLocation;
import android.text.AndroidCharacter;
import android.text.TextUtils;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewConfiguration;
import android.widget.ExpandableListView;
import com.incode.welcome_sdk.modules.SelfieScan;
import com.pichillilorenzo.flutter_inappwebview_android.credential_database.URLProtectionSpaceContract;
import com.plaid.internal.EnumC41897g;
import java.io.IOException;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import net.sf.scuba.smartcards.ISO7816;
import net.sf.scuba.smartcards.ISOFileInfo;

/* JADX INFO: loaded from: classes4.dex */
final class ou {
    static final Map<qb, Integer> d;
    static final os[] e;

    public static final class c {
        private static final byte[] $$a = null;
        private static final int $$b = 0;
        private static int[] m;
        int a;
        boolean b;
        int c;
        int d;
        final px e;
        int f;

        /* JADX INFO: renamed from: g, reason: collision with root package name */
        private final boolean f95936g;
        int h;
        private int i;
        os[] j;

        /* JADX WARN: Removed duplicated region for block: B:10:0x0025  */
        /* JADX WARN: Removed duplicated region for block: B:8:0x001f  */
        /* JADX WARN: Unsupported multi-entry loop pattern (BACK_EDGE: B:10:0x0025 -> B:11:0x002e). Please report as a decompilation issue!!! */
        /*
            Code decompiled incorrectly, please refer to instructions dump.
            To view partially-correct code enable 'Show inconsistent code' option in preferences
        */
        private static java.lang.String $$c(int r6, short r7, byte r8) {
            /*
                int r6 = r6 * 2
                int r6 = r6 + 119
                int r8 = r8 * 3
                int r0 = 1 - r8
                byte[] r1 = com.facetec.sdk.ou.c.$$a
                int r7 = r7 * 3
                int r7 = 4 - r7
                byte[] r0 = new byte[r0]
                r2 = 0
                int r8 = 0 - r8
                if (r1 != 0) goto L19
                r3 = r1
                r4 = r2
                r1 = r7
                goto L2e
            L19:
                r3 = r2
            L1a:
                byte r4 = (byte) r6
                r0[r3] = r4
                if (r3 != r8) goto L25
                java.lang.String r6 = new java.lang.String
                r6.<init>(r0, r2)
                return r6
            L25:
                r4 = r1[r7]
                int r3 = r3 + 1
                r5 = r1
                r1 = r6
                r6 = r4
                r4 = r3
                r3 = r5
            L2e:
                int r7 = r7 + 1
                int r6 = r6 + r1
                r1 = r3
                r3 = r4
                goto L1a
            */
            throw new UnsupportedOperationException("Method not decompiled: com.facetec.sdk.ou.c.$$c(int, short, byte):java.lang.String");
        }

        static {
            init$0();
            m = new int[]{936560462, 834328178, 207072729, 1390009151, -728253417, 969513882, -1541164661, -1661534965, 414715557, -345838387, 1182335955, -1273392160, -820903917, 1778206474, 776025716, 375159723, 1333955014, -281508870};
        }

        public c(px pxVar) {
            this(pxVar, (byte) 0);
        }

        public static void init$0() {
            $$a = new byte[]{120, ISO7816.INS_ENVELOPE, 63, 57};
            $$b = EnumC41897g.SDK_ASSET_ICON_ARROW_DOWN_VALUE;
        }

        private static void k(int[] iArr, int i, Object[] objArr) throws Throwable {
            char[] cArr;
            int i2;
            int i3;
            int i4;
            int i5;
            hg hgVar = new hg();
            char[] cArr2 = new char[4];
            int i6 = 2;
            char[] cArr3 = new char[iArr.length * 2];
            int[] iArr2 = m;
            int i7 = 2027942060;
            Class cls = Integer.TYPE;
            int i8 = 1;
            int i9 = 0;
            if (iArr2 != null) {
                int length = iArr2.length;
                int[] iArr3 = new int[length];
                int i10 = 0;
                while (i10 < length) {
                    try {
                        Object[] objArr2 = {Integer.valueOf(iArr2[i10])};
                        Object objD = an.d(i7);
                        if (objD == null) {
                            i4 = i7;
                            int mode = 617 - View.MeasureSpec.getMode(i9);
                            i3 = i6;
                            char mode2 = (char) View.MeasureSpec.getMode(i9);
                            int absoluteGravity = 23 - Gravity.getAbsoluteGravity(i9, i9);
                            byte b = (byte) i8;
                            byte b2 = (byte) (b - 1);
                            i5 = i8;
                            objD = an.d(mode, mode2, absoluteGravity, 247342071, false, $$c(b, b2, b2), new Class[]{cls});
                        } else {
                            i3 = i6;
                            i4 = i7;
                            i5 = i8;
                        }
                        iArr3[i10] = ((Integer) ((Method) objD).invoke(null, objArr2)).intValue();
                        i10++;
                        i7 = i4;
                        i6 = i3;
                        i8 = i5;
                        i9 = 0;
                    } catch (Throwable th) {
                        Throwable cause = th.getCause();
                        if (cause == null) {
                            throw th;
                        }
                        throw cause;
                    }
                }
                iArr2 = iArr3;
            }
            int i11 = i6;
            int i12 = i7;
            int i13 = i8;
            int length2 = iArr2.length;
            int[] iArr4 = new int[length2];
            int[] iArr5 = m;
            int i14 = 16;
            if (iArr5 != null) {
                int length3 = iArr5.length;
                int[] iArr6 = new int[length3];
                int i15 = 0;
                while (i15 < length3) {
                    Object[] objArr3 = {Integer.valueOf(iArr5[i15])};
                    Object objD2 = an.d(i12);
                    if (objD2 == null) {
                        i2 = i14;
                        byte b3 = (byte) i13;
                        byte b4 = (byte) (b3 - 1);
                        cArr = cArr2;
                        objD2 = an.d(617 - (ViewConfiguration.getTapTimeout() >> 16), (char) (1 - (SystemClock.elapsedRealtime() > 0L ? 1 : (SystemClock.elapsedRealtime() == 0L ? 0 : -1))), (ViewConfiguration.getTouchSlop() >> 8) + 23, 247342071, false, $$c(b3, b4, b4), new Class[]{cls});
                    } else {
                        cArr = cArr2;
                        i2 = i14;
                    }
                    iArr6[i15] = ((Integer) ((Method) objD2).invoke(null, objArr3)).intValue();
                    i15++;
                    i14 = i2;
                    cArr2 = cArr;
                    i13 = 1;
                }
                iArr5 = iArr6;
            }
            char[] cArr4 = cArr2;
            int i16 = i14;
            char c = 0;
            System.arraycopy(iArr5, 0, iArr4, 0, length2);
            hgVar.c = 0;
            while (true) {
                int i17 = hgVar.c;
                if (i17 >= iArr.length) {
                    objArr[0] = new String(cArr3, 0, i);
                    return;
                }
                int i18 = iArr[i17];
                char c2 = (char) (i18 >> 16);
                cArr4[c] = c2;
                char c3 = (char) i18;
                cArr4[1] = c3;
                char c4 = (char) (iArr[i17 + 1] >> 16);
                cArr4[i11] = c4;
                char c5 = (char) iArr[i17 + 1];
                cArr4[3] = c5;
                hgVar.d = (c2 << 16) + c3;
                hgVar.a = (c4 << 16) + c5;
                hg.a(iArr4);
                int i19 = 0;
                while (i19 < i16) {
                    int i20 = hgVar.d ^ iArr4[i19];
                    hgVar.d = i20;
                    int iB = hg.b(i20);
                    Object[] objArr4 = new Object[4];
                    objArr4[3] = hgVar;
                    objArr4[i11] = hgVar;
                    objArr4[1] = Integer.valueOf(iB);
                    objArr4[0] = hgVar;
                    Object objD3 = an.d(-1264699187);
                    if (objD3 == null) {
                        byte b5 = (byte) 0;
                        byte b6 = b5;
                        objD3 = an.d(1558 - (Process.myTid() >> 22), (char) (63318 - (Process.getElapsedCpuTime() > 0L ? 1 : (Process.getElapsedCpuTime() == 0L ? 0 : -1))), (ViewConfiguration.getKeyRepeatDelay() >> 16) + 32, -1023415402, false, $$c(b5, b6, b6), new Class[]{Object.class, cls, Object.class, Object.class});
                    }
                    int iIntValue = ((Integer) ((Method) objD3).invoke(null, objArr4)).intValue();
                    hgVar.d = hgVar.a;
                    hgVar.a = iIntValue;
                    i19++;
                    i16 = 16;
                }
                int i21 = hgVar.d;
                int i22 = hgVar.a;
                hgVar.d = i22;
                hgVar.a = i21;
                int i23 = i21 ^ iArr4[16];
                hgVar.a = i23;
                int i24 = i22 ^ iArr4[17];
                hgVar.d = i24;
                cArr4[0] = (char) (i24 >>> 16);
                cArr4[1] = (char) i24;
                cArr4[i11] = (char) (i23 >>> 16);
                cArr4[3] = (char) i23;
                hg.a(iArr4);
                int i25 = hgVar.c;
                cArr3[i25 * 2] = cArr4[0];
                cArr3[(i25 * 2) + 1] = cArr4[1];
                cArr3[(i25 * 2) + 2] = cArr4[i11];
                cArr3[(i25 * 2) + 3] = cArr4[3];
                int i26 = i11;
                Object[] objArr5 = new Object[i26];
                objArr5[1] = hgVar;
                objArr5[0] = hgVar;
                Object objD4 = an.d(-204410541);
                if (objD4 == null) {
                    i16 = 16;
                    objD4 = an.d((ExpandableListView.getPackedPositionForChild(0, 0) > 0L ? 1 : (ExpandableListView.getPackedPositionForChild(0, 0) == 0L ? 0 : -1)) + EnumC41897g.SDK_ASSET_ILLUSTRATION_FACE_BIOMETRIC_PASSKEY_VALUE, (char) ((-1) - MotionEvent.axisFromString("")), (KeyEvent.getMaxKeyCode() >> 16) + 23, -2051988984, false, "A", new Class[]{Object.class, Object.class});
                } else {
                    i16 = 16;
                }
                ((Method) objD4).invoke(null, objArr5);
                i11 = i26;
                c = 0;
            }
        }

        public final void a() {
            Arrays.fill(this.j, (Object) null);
            this.h = this.j.length - 1;
            this.i = 0;
            this.f = 0;
        }

        public void b(os osVar) throws Throwable {
            int i = osVar.f;
            int i2 = this.d;
            if (i > i2) {
                a();
                return;
            }
            e((this.f + i) - i2);
            int i3 = this.i + 1;
            os[] osVarArr = this.j;
            if (i3 > osVarArr.length) {
                os[] osVarArr2 = new os[osVarArr.length << 1];
                try {
                    Object[] objArr = {osVarArr, 0, osVarArr2, Integer.valueOf(osVarArr.length), Integer.valueOf(osVarArr.length)};
                    Object[] objArr2 = new Object[1];
                    k(new int[]{1331577825, 927356802, 806185104, -1836187348, 962308869, 1001755127, 2049470839, -1433115948}, (ViewConfiguration.getPressedStateDuration() >> 16) + 16, objArr2);
                    Class<?> cls = Class.forName((String) objArr2[0]);
                    Object[] objArr3 = new Object[1];
                    k(new int[]{-2060528986, 110484971, -769280024, 528071353, 2068523554, 17063791}, 8 - Process.getGidForName(""), objArr3);
                    String str = (String) objArr3[0];
                    Class cls2 = Integer.TYPE;
                    cls.getMethod(str, Object.class, cls2, Object.class, cls2, cls2).invoke(null, objArr);
                    this.h = this.j.length - 1;
                    this.j = osVarArr2;
                } catch (Throwable th) {
                    Throwable cause = th.getCause();
                    if (cause == null) {
                        throw th;
                    }
                    throw cause;
                }
            }
            int i4 = this.h;
            this.h = i4 - 1;
            this.j[i4] = osVar;
            this.i++;
            this.f += i;
        }

        public void d(qb qbVar) {
            if (this.f95936g) {
                pc.d();
                if (pc.e(qbVar) < qbVar.h()) {
                    px pxVar = new px();
                    pc.d();
                    pc.b(qbVar, pxVar);
                    qb qbVarN = pxVar.n();
                    e(qbVarN.h(), 127, 128);
                    this.e.a(qbVarN);
                    return;
                }
            }
            e(qbVar.h(), 127, 0);
            this.e.a(qbVar);
        }

        public final int e(int i) throws Throwable {
            int i2;
            if (i <= 0) {
                return 0;
            }
            int length = this.j.length - 1;
            int i3 = 0;
            while (true) {
                i2 = this.h;
                if (length < i2 || i <= 0) {
                    break;
                }
                int i4 = this.j[length].f;
                i -= i4;
                this.f -= i4;
                this.i--;
                i3++;
                length--;
            }
            os[] osVarArr = this.j;
            try {
                Object[] objArr = {osVarArr, Integer.valueOf(i2 + 1), osVarArr, Integer.valueOf(i2 + 1 + i3), Integer.valueOf(this.i)};
                Object[] objArr2 = new Object[1];
                k(new int[]{1331577825, 927356802, 806185104, -1836187348, 962308869, 1001755127, 2049470839, -1433115948}, (ViewConfiguration.getLongPressTimeout() >> 16) + 16, objArr2);
                Class<?> cls = Class.forName((String) objArr2[0]);
                Object[] objArr3 = new Object[1];
                k(new int[]{-2060528986, 110484971, -769280024, 528071353, 2068523554, 17063791}, (ViewConfiguration.getMinimumFlingVelocity() >> 16) + 9, objArr3);
                String str = (String) objArr3[0];
                Class cls2 = Integer.TYPE;
                cls.getMethod(str, Object.class, cls2, Object.class, cls2, cls2).invoke(null, objArr);
                os[] osVarArr2 = this.j;
                int i5 = this.h;
                Arrays.fill(osVarArr2, i5 + 1, i5 + 1 + i3, (Object) null);
                this.h += i3;
                return i3;
            } catch (Throwable th) {
                Throwable cause = th.getCause();
                if (cause != null) {
                    throw cause;
                }
                throw th;
            }
        }

        private c(px pxVar, byte b) {
            this.c = Integer.MAX_VALUE;
            os[] osVarArr = new os[8];
            this.j = osVarArr;
            this.h = osVarArr.length - 1;
            this.i = 0;
            this.f = 0;
            this.a = 4096;
            this.d = 4096;
            this.f95936g = true;
            this.e = pxVar;
        }

        public void e(int i, int i2, int i3) {
            if (i < i2) {
                this.e.g(i | i3);
                return;
            }
            this.e.g(i3 | i2);
            int i4 = i - i2;
            while (i4 >= 128) {
                this.e.g(128 | (i4 & 127));
                i4 >>>= 7;
            }
            this.e.g(i4);
        }
    }

    public static final class d {
        private static final byte[] $$a = null;
        private static final int $$b = 0;
        private static char[] f;
        private static char h;
        private os[] a;
        private final int b;
        private final pz c;
        private final List<os> d;
        private int e;

        /* JADX INFO: renamed from: g, reason: collision with root package name */
        private int f95937g;
        private int i;
        private int j;

        /* JADX WARN: Removed duplicated region for block: B:10:0x0024  */
        /* JADX WARN: Removed duplicated region for block: B:8:0x001e  */
        /* JADX WARN: Unsupported multi-entry loop pattern (BACK_EDGE: B:10:0x0024 -> B:11:0x002a). Please report as a decompilation issue!!! */
        /*
            Code decompiled incorrectly, please refer to instructions dump.
            To view partially-correct code enable 'Show inconsistent code' option in preferences
        */
        private static java.lang.String $$c(short r7, byte r8, short r9) {
            /*
                int r7 = 116 - r7
                int r9 = r9 * 2
                int r9 = 4 - r9
                byte[] r0 = com.facetec.sdk.ou.d.$$a
                int r8 = r8 * 4
                int r8 = 1 - r8
                byte[] r1 = new byte[r8]
                r2 = 0
                if (r0 != 0) goto L16
                r7 = r8
                r3 = r0
                r5 = r2
                r0 = r9
                goto L2a
            L16:
                r3 = r2
            L17:
                byte r4 = (byte) r7
                int r5 = r3 + 1
                r1[r3] = r4
                if (r5 != r8) goto L24
                java.lang.String r7 = new java.lang.String
                r7.<init>(r1, r2)
                return r7
            L24:
                r3 = r0[r9]
                r6 = r0
                r0 = r9
                r9 = r3
                r3 = r6
            L2a:
                int r7 = r7 + r9
                int r9 = r0 + 1
                r0 = r3
                r3 = r5
                goto L17
            */
            throw new UnsupportedOperationException("Method not decompiled: com.facetec.sdk.ou.d.$$c(short, byte, short):java.lang.String");
        }

        static {
            init$0();
            f = new char[]{15096, 15102, 15023, 15089, 15090, 15058, 15095, 15103, 15084, 15074, 15094, 15078, 15091, 15072, 15082, 15101, 15100, 15087, 15076, 15086, 15083, 15092, 15088, 15085, 15093};
            h = (char) 3870;
        }

        public d(ql qlVar) {
            this(4096, 4096, qlVar);
        }

        private int a(int i) {
            return this.j + 1 + i;
        }

        private static boolean b(int i) {
            return i >= 0 && i <= ou.e.length - 1;
        }

        private void c() {
            Arrays.fill(this.a, (Object) null);
            this.j = this.a.length - 1;
            this.i = 0;
            this.f95937g = 0;
        }

        private int d(int i) throws Throwable {
            int i2;
            if (i <= 0) {
                return 0;
            }
            int length = this.a.length - 1;
            int i3 = 0;
            while (true) {
                i2 = this.j;
                if (length < i2 || i <= 0) {
                    break;
                }
                int i4 = this.a[length].f;
                i -= i4;
                this.f95937g -= i4;
                this.i--;
                i3++;
                length--;
            }
            os[] osVarArr = this.a;
            try {
                Object[] objArr = {osVarArr, Integer.valueOf(i2 + 1), osVarArr, Integer.valueOf(i2 + 1 + i3), Integer.valueOf(this.i)};
                Object[] objArr2 = new Object[1];
                k("\u0017\n\b\u000b\u0003\u0016\f\u0012\f\u0001\n\u0005\t\u0004\u0017\r", (CdmaCellLocation.convertQuartSecToDecDegrees(0) > 0.0d ? 1 : (CdmaCellLocation.convertQuartSecToDecDegrees(0) == 0.0d ? 0 : -1)) + 16, (byte) (50 - ImageFormat.getBitsPerPixel(0)), objArr2);
                Class<?> cls = Class.forName((String) objArr2[0]);
                Object[] objArr3 = new Object[1];
                k("\u000e\r\r\u000e\u0004\u0005\u0012\u0004㙕", (ViewConfiguration.getTapTimeout() >> 16) + 9, (byte) ((ViewConfiguration.getGlobalActionKeyTimeout() > 0L ? 1 : (ViewConfiguration.getGlobalActionKeyTimeout() == 0L ? 0 : -1)) + 113), objArr3);
                String str = (String) objArr3[0];
                Class cls2 = Integer.TYPE;
                cls.getMethod(str, Object.class, cls2, Object.class, cls2, cls2).invoke(null, objArr);
                this.j += i3;
                return i3;
            } catch (Throwable th) {
                Throwable cause = th.getCause();
                if (cause != null) {
                    throw cause;
                }
                throw th;
            }
        }

        public static void init$0() {
            $$a = new byte[]{81, 99, 107, 124};
            $$b = EnumC41897g.SDK_ASSET_ILLUSTRATION_UPLOAD_VALUE;
        }

        private static void k(String str, int i, byte b, Object[] objArr) throws Throwable {
            int i2;
            char c;
            char c2;
            char c3;
            char c4;
            char c5;
            char c6;
            int i3;
            char[] charArray = str != null ? str.toCharArray() : str;
            ho hoVar = new ho();
            char[] cArr = f;
            Class cls = Integer.TYPE;
            int i4 = -1584280535;
            int i5 = 0;
            if (cArr != null) {
                int length = cArr.length;
                char[] cArr2 = new char[length];
                int i6 = 0;
                while (i6 < length) {
                    try {
                        Object[] objArr2 = {Integer.valueOf(cArr[i6])};
                        Object objD = an.d(i4);
                        if (objD == null) {
                            byte b2 = (byte) i5;
                            i3 = i4;
                            byte b3 = b2;
                            objD = an.d((KeyEvent.getMaxKeyCode() >> 16) + 2158, (char) TextUtils.getTrimmedLength(""), (Process.myPid() >> 22) + 23, -672129166, false, $$c(b2, b3, b3), new Class[]{cls});
                        } else {
                            i3 = i4;
                        }
                        cArr2[i6] = ((Character) ((Method) objD).invoke(null, objArr2)).charValue();
                        i6++;
                        i4 = i3;
                        i5 = 0;
                    } catch (Throwable th) {
                        Throwable cause = th.getCause();
                        if (cause == null) {
                            throw th;
                        }
                        throw cause;
                    }
                }
                cArr = cArr2;
            }
            int i7 = i4;
            Object[] objArr3 = {Integer.valueOf(h)};
            Object objD2 = an.d(i7);
            if (objD2 == null) {
                byte b4 = (byte) 0;
                byte b5 = b4;
                objD2 = an.d(2158 - KeyEvent.keyCodeFromString(""), (char) TextUtils.getTrimmedLength(""), (SystemClock.currentThreadTimeMillis() > (-1L) ? 1 : (SystemClock.currentThreadTimeMillis() == (-1L) ? 0 : -1)) + 22, -672129166, false, $$c(b4, b5, b5), new Class[]{cls});
            }
            char cCharValue = ((Character) ((Method) objD2).invoke(null, objArr3)).charValue();
            char[] cArr3 = new char[i];
            if (i % 2 != 0) {
                i2 = i - 1;
                cArr3[i2] = (char) (charArray[i2] - b);
            } else {
                i2 = i;
            }
            char c7 = 1;
            if (i2 > 1) {
                hoVar.b = 0;
                while (true) {
                    int i8 = hoVar.b;
                    if (i8 >= i2) {
                        break;
                    }
                    char c8 = charArray[i8];
                    hoVar.d = c8;
                    char c9 = charArray[i8 + 1];
                    hoVar.e = c9;
                    if (c8 == c9) {
                        cArr3[i8] = (char) (c8 - b);
                        cArr3[i8 + 1] = (char) (c9 - b);
                        c = c7;
                    } else {
                        Object[] objArr4 = new Object[13];
                        objArr4[12] = hoVar;
                        objArr4[11] = Integer.valueOf(cCharValue);
                        objArr4[10] = hoVar;
                        objArr4[9] = hoVar;
                        objArr4[8] = Integer.valueOf(cCharValue);
                        objArr4[7] = hoVar;
                        objArr4[6] = hoVar;
                        objArr4[5] = Integer.valueOf(cCharValue);
                        objArr4[4] = hoVar;
                        c = c7;
                        objArr4[3] = hoVar;
                        objArr4[2] = Integer.valueOf(cCharValue);
                        objArr4[c] = hoVar;
                        objArr4[0] = hoVar;
                        Object objD3 = an.d(945118461);
                        if (objD3 == null) {
                            c2 = '\n';
                            int scrollDefaultDelay = (ViewConfiguration.getScrollDefaultDelay() >> 16) + 2356;
                            c3 = 2;
                            char c10 = (char) (1 - (AudioTrack.getMaxVolume() > SelfieScan.RECOGNITION_FAIL_RESULT ? 1 : (AudioTrack.getMaxVolume() == SelfieScan.RECOGNITION_FAIL_RESULT ? 0 : -1)));
                            int fadingEdgeLength = 23 - (ViewConfiguration.getFadingEdgeLength() >> 16);
                            c4 = '\t';
                            byte b6 = (byte) ($$b & 7);
                            c5 = 7;
                            byte b7 = (byte) (b6 - 2);
                            c6 = '\b';
                            String str$$c = $$c(b6, b7, b7);
                            Class cls2 = Integer.TYPE;
                            objD3 = an.d(scrollDefaultDelay, c10, fadingEdgeLength, 1312067494, false, str$$c, new Class[]{Object.class, Object.class, cls2, Object.class, Object.class, cls2, Object.class, Object.class, cls2, Object.class, Object.class, cls2, Object.class});
                        } else {
                            c2 = '\n';
                            c3 = 2;
                            c4 = '\t';
                            c5 = 7;
                            c6 = '\b';
                        }
                        int iIntValue = ((Integer) ((Method) objD3).invoke(null, objArr4)).intValue();
                        int i9 = hoVar.f95903g;
                        if (iIntValue == i9) {
                            Object[] objArr5 = new Object[11];
                            objArr5[c2] = hoVar;
                            objArr5[c4] = Integer.valueOf(cCharValue);
                            objArr5[c6] = hoVar;
                            objArr5[c5] = Integer.valueOf(cCharValue);
                            objArr5[6] = Integer.valueOf(cCharValue);
                            objArr5[5] = hoVar;
                            objArr5[4] = hoVar;
                            objArr5[3] = Integer.valueOf(cCharValue);
                            objArr5[c3] = Integer.valueOf(cCharValue);
                            objArr5[c] = hoVar;
                            objArr5[0] = hoVar;
                            Object objD4 = an.d(-1909092408);
                            if (objD4 == null) {
                                int i10 = 878 - (SystemClock.elapsedRealtime() > 0L ? 1 : (SystemClock.elapsedRealtime() == 0L ? 0 : -1));
                                char c11 = (char) (1 - (ViewConfiguration.getGlobalActionKeyTimeout() > 0L ? 1 : (ViewConfiguration.getGlobalActionKeyTimeout() == 0L ? 0 : -1)));
                                int keyRepeatDelay = 24 - (ViewConfiguration.getKeyRepeatDelay() >> 16);
                                byte b8 = (byte) 3;
                                byte b9 = (byte) (b8 - 3);
                                String str$$c2 = $$c(b8, b9, b9);
                                Class cls3 = Integer.TYPE;
                                objD4 = an.d(i10, c11, keyRepeatDelay, -128689005, false, str$$c2, new Class[]{Object.class, Object.class, cls3, cls3, Object.class, Object.class, cls3, cls3, Object.class, cls3, Object.class});
                            }
                            int iIntValue2 = ((Integer) ((Method) objD4).invoke(null, objArr5)).intValue();
                            int i11 = (hoVar.a * cCharValue) + hoVar.f95903g;
                            int i12 = hoVar.b;
                            cArr3[i12] = cArr[iIntValue2];
                            cArr3[i12 + 1] = cArr[i11];
                        } else {
                            int i13 = hoVar.c;
                            int i14 = hoVar.a;
                            if (i13 == i14) {
                                int i15 = ((hoVar.j + cCharValue) - 1) % cCharValue;
                                hoVar.j = i15;
                                int i16 = ((i9 + cCharValue) - 1) % cCharValue;
                                hoVar.f95903g = i16;
                                int i17 = (i14 * cCharValue) + i16;
                                int i18 = hoVar.b;
                                cArr3[i18] = cArr[(i13 * cCharValue) + i15];
                                cArr3[i18 + 1] = cArr[i17];
                            } else {
                                int i19 = (i13 * cCharValue) + i9;
                                int i20 = (i14 * cCharValue) + hoVar.j;
                                int i21 = hoVar.b;
                                cArr3[i21] = cArr[i19];
                                cArr3[i21 + 1] = cArr[i20];
                            }
                        }
                    }
                    hoVar.b += 2;
                    c7 = c;
                }
            }
            for (int i22 = 0; i22 < i; i22++) {
                cArr3[i22] = (char) (cArr3[i22] ^ 13722);
            }
            objArr[0] = new String(cArr3);
        }

        public final void e() throws Throwable {
            while (!this.c.b()) {
                byte bG = this.c.g();
                int i = bG & 255;
                if (i == 128) {
                    throw new IOException("index == 0");
                }
                if ((bG & ISOFileInfo.DATA_BYTES1) == 128) {
                    int iC = c(i, 127);
                    int i2 = iC - 1;
                    if (!b(i2)) {
                        int iA = a(i2 - ou.e.length);
                        if (iA >= 0) {
                            os[] osVarArr = this.a;
                            if (iA < osVarArr.length) {
                                this.d.add(osVarArr[iA]);
                            }
                        }
                        StringBuilder sb = new StringBuilder("Header index too large ");
                        sb.append(iC);
                        throw new IOException(sb.toString());
                    }
                    this.d.add(ou.e[i2]);
                } else if (i == 64) {
                    c(new os(ou.a(a()), a()));
                } else if ((bG & 64) == 64) {
                    c(new os(c(c(i, 63) - 1), a()));
                } else if ((bG & ISO7816.INS_VERIFY) == 32) {
                    int iC2 = c(i, 31);
                    this.e = iC2;
                    if (iC2 < 0 || iC2 > this.b) {
                        StringBuilder sb2 = new StringBuilder("Invalid dynamic table size update ");
                        sb2.append(this.e);
                        throw new IOException(sb2.toString());
                    }
                    int i3 = this.f95937g;
                    if (iC2 < i3) {
                        if (iC2 == 0) {
                            c();
                        } else {
                            d(i3 - iC2);
                        }
                    }
                } else if (i == 16 || i == 0) {
                    this.d.add(new os(ou.a(a()), a()));
                } else {
                    this.d.add(new os(c(c(i, 15) - 1), a()));
                }
            }
        }

        private d(int i, int i2, ql qlVar) {
            this.d = new ArrayList();
            this.a = new os[8];
            this.j = r1.length - 1;
            this.i = 0;
            this.f95937g = 0;
            this.b = 4096;
            this.e = 4096;
            this.c = qf.d(qlVar);
        }

        private qb a() {
            int iB = b();
            boolean z = (iB & 128) == 128;
            int iC = c(iB, 127);
            return z ? qb.c(pc.d().c(this.c.i(iC))) : this.c.a(iC);
        }

        private int b() {
            return this.c.g() & 255;
        }

        private qb c(int i) throws IOException {
            if (b(i)) {
                return ou.e[i].j;
            }
            int iA = a(i - ou.e.length);
            if (iA >= 0) {
                os[] osVarArr = this.a;
                if (iA < osVarArr.length) {
                    return osVarArr[iA].j;
                }
            }
            StringBuilder sb = new StringBuilder("Header index too large ");
            sb.append(i + 1);
            throw new IOException(sb.toString());
        }

        public final List<os> d() {
            ArrayList arrayList = new ArrayList(this.d);
            this.d.clear();
            return arrayList;
        }

        private void c(os osVar) throws Throwable {
            this.d.add(osVar);
            int i = osVar.f;
            int i2 = this.e;
            if (i > i2) {
                c();
                return;
            }
            d((this.f95937g + i) - i2);
            int i3 = this.i + 1;
            os[] osVarArr = this.a;
            if (i3 > osVarArr.length) {
                os[] osVarArr2 = new os[osVarArr.length << 1];
                try {
                    Object[] objArr = {osVarArr, 0, osVarArr2, Integer.valueOf(osVarArr.length), Integer.valueOf(osVarArr.length)};
                    Object[] objArr2 = new Object[1];
                    k("\u0017\n\b\u000b\u0003\u0016\f\u0012\f\u0001\n\u0005\t\u0004\u0017\r", 16 - (ViewConfiguration.getEdgeSlop() >> 16), (byte) ((SystemClock.elapsedRealtimeNanos() > 0L ? 1 : (SystemClock.elapsedRealtimeNanos() == 0L ? 0 : -1)) + 50), objArr2);
                    Class<?> cls = Class.forName((String) objArr2[0]);
                    Object[] objArr3 = new Object[1];
                    k("\u000e\r\r\u000e\u0004\u0005\u0012\u0004㙕", AndroidCharacter.getMirror('0') - '\'', (byte) (114 - Color.alpha(0)), objArr3);
                    String str = (String) objArr3[0];
                    Class cls2 = Integer.TYPE;
                    cls.getMethod(str, Object.class, cls2, Object.class, cls2, cls2).invoke(null, objArr);
                    this.j = this.a.length - 1;
                    this.a = osVarArr2;
                } catch (Throwable th) {
                    Throwable cause = th.getCause();
                    if (cause == null) {
                        throw th;
                    }
                    throw cause;
                }
            }
            int i4 = this.j;
            this.j = i4 - 1;
            this.a[i4] = osVar;
            this.i++;
            this.f95937g += i;
        }

        private int c(int i, int i2) {
            int i3 = i & i2;
            if (i3 < i2) {
                return i3;
            }
            int i4 = 0;
            while (true) {
                int iB = b();
                if ((iB & 128) == 0) {
                    return i2 + (iB << i4);
                }
                i2 += (iB & 127) << i4;
                i4 += 7;
            }
        }
    }

    static {
        os osVar = new os(os.h, "");
        qb qbVar = os.d;
        os osVar2 = new os(qbVar, RequestMethod.GET);
        os osVar3 = new os(qbVar, RequestMethod.POST);
        qb qbVar2 = os.e;
        os osVar4 = new os(qbVar2, "/");
        os osVar5 = new os(qbVar2, "/index.html");
        qb qbVar3 = os.b;
        os osVar6 = new os(qbVar3, "http");
        os osVar7 = new os(qbVar3, "https");
        qb qbVar4 = os.a;
        os[] osVarArr = {osVar, osVar2, osVar3, osVar4, osVar5, osVar6, osVar7, new os(qbVar4, "200"), new os(qbVar4, "204"), new os(qbVar4, "206"), new os(qbVar4, "304"), new os(qbVar4, "400"), new os(qbVar4, "404"), new os(qbVar4, "500"), new os("accept-charset", ""), new os("accept-encoding", "gzip, deflate"), new os("accept-language", ""), new os("accept-ranges", ""), new os("accept", ""), new os("access-control-allow-origin", ""), new os("age", ""), new os("allow", ""), new os("authorization", ""), new os("cache-control", ""), new os("content-disposition", ""), new os("content-encoding", ""), new os("content-language", ""), new os("content-length", ""), new os("content-location", ""), new os("content-range", ""), new os(NetworkLog.CONTENT_TYPE, ""), new os("cookie", ""), new os("date", ""), new os("etag", ""), new os("expect", ""), new os("expires", ""), new os("from", ""), new os(URLProtectionSpaceContract.FeedEntry.COLUMN_NAME_HOST, ""), new os("if-match", ""), new os("if-modified-since", ""), new os("if-none-match", ""), new os("if-range", ""), new os("if-unmodified-since", ""), new os("last-modified", ""), new os("link", ""), new os("location", ""), new os("max-forwards", ""), new os("proxy-authenticate", ""), new os("proxy-authorization", ""), new os("range", ""), new os("referer", ""), new os("refresh", ""), new os("retry-after", ""), new os("server", ""), new os("set-cookie", ""), new os("strict-transport-security", ""), new os("transfer-encoding", ""), new os("user-agent", ""), new os("vary", ""), new os("via", ""), new os("www-authenticate", "")};
        e = osVarArr;
        LinkedHashMap linkedHashMap = new LinkedHashMap(osVarArr.length);
        int i = 0;
        while (true) {
            os[] osVarArr2 = e;
            if (i >= osVarArr2.length) {
                d = Collections.unmodifiableMap(linkedHashMap);
                return;
            } else {
                if (!linkedHashMap.containsKey(osVarArr2[i].j)) {
                    linkedHashMap.put(osVarArr2[i].j, Integer.valueOf(i));
                }
                i++;
            }
        }
    }

    public static qb a(qb qbVar) throws IOException {
        int iH = qbVar.h();
        for (int i = 0; i < iH; i++) {
            byte bE = qbVar.e(i);
            if (bE >= 65 && bE <= 90) {
                StringBuilder sb = new StringBuilder("PROTOCOL_ERROR response malformed: mixed case name: ");
                sb.append(qbVar.d());
                throw new IOException(sb.toString());
            }
        }
        return qbVar;
    }
}