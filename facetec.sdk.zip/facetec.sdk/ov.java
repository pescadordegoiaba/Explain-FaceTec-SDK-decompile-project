package com.facetec.sdk;

import android.os.SystemClock;
import com.facetec.sdk.ox;
import com.plaid.internal.EnumC41897g;
import java.io.Closeable;
import java.io.IOException;
import java.net.Socket;
import java.util.Arrays;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.RejectedExecutionException;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.ScheduledThreadPoolExecutor;
import java.util.concurrent.SynchronousQueue;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;
import java.util.logging.Level;
import java.util.logging.Logger;
import net.sf.scuba.smartcards.ISOFileInfo;
import org.bouncycastle.crypto.digests.Blake2xsDigest;

/* JADX INFO: loaded from: classes4.dex */
public final class ov implements Closeable {
    private static /* synthetic */ boolean B = true;
    private static final ExecutorService q = new ThreadPoolExecutor(0, Integer.MAX_VALUE, 60, TimeUnit.SECONDS, new SynchronousQueue(), nu.d("OkHttp Http2Connection", true));
    private Socket C;
    final boolean a;
    final e c;
    final String d;
    int e;
    final ScheduledExecutorService f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    final pd f95938g;
    int h;
    final pb l;
    long n;
    public final oz o;
    final Set<Integer> p;
    public b r;
    private final ExecutorService s;
    private boolean t;
    final Map<Integer, pa> b = new LinkedHashMap();
    private long v = 0;
    private long u = 0;
    long j = 0;
    long i = 0;
    private long x = 0;
    private long w = 0;
    long m = 0;
    private long y = 0;
    public pb k = new pb();

    public final class a extends np {
        private int a;
        private int b;
        private boolean c;

        public a(int i, int i2) {
            super("OkHttp %s ping %08x%08x", ov.this.d, Integer.valueOf(i), Integer.valueOf(i2));
            this.c = true;
            this.b = i;
            this.a = i2;
        }

        @Override // com.facetec.sdk.np
        public final void c() {
            ov.this.c(this.c, this.b, this.a);
        }
    }

    public static class c {
        public String a;
        public pz b;
        public pu c;
        public Socket d;
        public int f;
        public e e = e.m;
        pd j = pd.d;

        /* JADX INFO: renamed from: g, reason: collision with root package name */
        boolean f95939g = true;
    }

    public final class d extends np {
        public static int a;
        public static int b;

        public d() {
            super("OkHttp %s ping", ov.this.d);
        }

        public static int a() {
            int i = b;
            int i2 = i % 8355179;
            b = i + 1;
            if (i2 != 0) {
                return a;
            }
            int iMaxMemory = (int) Runtime.getRuntime().maxMemory();
            a = iMaxMemory;
            return iMaxMemory;
        }

        @Override // com.facetec.sdk.np
        public final void c() {
            boolean z;
            synchronized (ov.this) {
                if (ov.this.u < ov.this.v) {
                    z = true;
                } else {
                    ov.a(ov.this);
                    z = false;
                }
            }
            if (z) {
                ov.this.d();
            } else {
                ov.this.c(false, 1, 0);
            }
        }
    }

    public static abstract class e {
        public static final e m = new e() { // from class: com.facetec.sdk.ov.e.1
            @Override // com.facetec.sdk.ov.e
            public final void e(pa paVar) {
                paVar.b(or.REFUSED_STREAM);
            }
        };

        public void b(ov ovVar) {
        }

        public abstract void e(pa paVar);
    }

    public ov(c cVar) {
        pb pbVar = new pb();
        this.l = pbVar;
        this.p = new LinkedHashSet();
        this.f95938g = cVar.j;
        boolean z = cVar.f95939g;
        this.a = z;
        this.c = cVar.e;
        int i = z ? 1 : 2;
        this.h = i;
        if (z) {
            this.h = i + 2;
        }
        if (z) {
            this.k.c(7, 16777216);
        }
        String str = cVar.a;
        this.d = str;
        ScheduledThreadPoolExecutor scheduledThreadPoolExecutor = new ScheduledThreadPoolExecutor(1, nu.d(nu.b("OkHttp %s Writer", str), false));
        this.f = scheduledThreadPoolExecutor;
        if (cVar.f != 0) {
            d dVar = new d();
            int i2 = cVar.f;
            scheduledThreadPoolExecutor.scheduleAtFixedRate(dVar, i2, i2, TimeUnit.MILLISECONDS);
        }
        this.s = new ThreadPoolExecutor(0, 1, 60L, TimeUnit.SECONDS, new LinkedBlockingQueue(), nu.d(nu.b("OkHttp %s Push Observer", str), true));
        pbVar.c(7, Blake2xsDigest.UNKNOWN_DIGEST_LENGTH);
        pbVar.c(5, 16384);
        this.n = pbVar.c();
        this.C = cVar.d;
        this.o = new oz(cVar.c, z);
        this.r = new b(new ox(cVar.b, z));
    }

    public static boolean a(int i) {
        return i != 0 && (i & 1) == 0;
    }

    public static /* synthetic */ long f(ov ovVar) {
        long j = ovVar.i;
        ovVar.i = 1 + j;
        return j;
    }

    public static /* synthetic */ long g(ov ovVar) {
        long j = ovVar.u;
        ovVar.u = 1 + j;
        return j;
    }

    public static /* synthetic */ boolean h(ov ovVar) {
        ovVar.t = true;
        return true;
    }

    public static /* synthetic */ long i(ov ovVar) {
        long j = ovVar.w;
        ovVar.w = 1 + j;
        return j;
    }

    @Override // java.io.Closeable, java.lang.AutoCloseable
    public final void close() throws IOException {
        e(or.NO_ERROR, or.CANCEL);
    }

    public static /* synthetic */ long a(ov ovVar) {
        long j = ovVar.v;
        ovVar.v = 1 + j;
        return j;
    }

    public final void b() {
        this.o.d();
    }

    public final synchronized pa c(int i) {
        pa paVarRemove;
        paVarRemove = this.b.remove(Integer.valueOf(i));
        notifyAll();
        return paVarRemove;
    }

    public final synchronized void d(long j) {
        long j2 = this.y + j;
        this.y = j2;
        if (j2 >= this.k.c() / 2) {
            c(0, this.y);
            this.y = 0L;
        }
    }

    public final synchronized int a() {
        pb pbVar = this.l;
        if ((pbVar.b & 16) == 0) {
            return Integer.MAX_VALUE;
        }
        return pbVar.a[4];
    }

    public final synchronized pa e(int i) {
        return this.b.get(Integer.valueOf(i));
    }

    /* JADX WARN: Code restructure failed: missing block: B:18:0x0032, code lost:
    
        r2 = java.lang.Math.min((int) java.lang.Math.min(r12, r4), r8.o.d);
        r6 = r2;
        r8.n -= r6;
     */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public final void e(int r9, boolean r10, com.facetec.sdk.px r11, long r12) {
        /*
            r8 = this;
            r0 = 0
            int r2 = (r12 > r0 ? 1 : (r12 == r0 ? 0 : -1))
            r3 = 0
            if (r2 != 0) goto Ld
            com.facetec.sdk.oz r12 = r8.o
            r12.e(r10, r9, r11, r3)
            return
        Ld:
            int r2 = (r12 > r0 ? 1 : (r12 == r0 ? 0 : -1))
            if (r2 <= 0) goto L65
            monitor-enter(r8)
        L12:
            long r4 = r8.n     // Catch: java.lang.Throwable -> L28 java.lang.InterruptedException -> L56
            int r2 = (r4 > r0 ? 1 : (r4 == r0 ? 0 : -1))
            if (r2 > 0) goto L32
            java.util.Map<java.lang.Integer, com.facetec.sdk.pa> r2 = r8.b     // Catch: java.lang.Throwable -> L28 java.lang.InterruptedException -> L56
            java.lang.Integer r4 = java.lang.Integer.valueOf(r9)     // Catch: java.lang.Throwable -> L28 java.lang.InterruptedException -> L56
            boolean r2 = r2.containsKey(r4)     // Catch: java.lang.Throwable -> L28 java.lang.InterruptedException -> L56
            if (r2 == 0) goto L2a
            r8.wait()     // Catch: java.lang.Throwable -> L28 java.lang.InterruptedException -> L56
            goto L12
        L28:
            r9 = move-exception
            goto L63
        L2a:
            java.io.IOException r9 = new java.io.IOException     // Catch: java.lang.Throwable -> L28 java.lang.InterruptedException -> L56
            java.lang.String r10 = "stream closed"
            r9.<init>(r10)     // Catch: java.lang.Throwable -> L28 java.lang.InterruptedException -> L56
            throw r9     // Catch: java.lang.Throwable -> L28 java.lang.InterruptedException -> L56
        L32:
            long r4 = java.lang.Math.min(r12, r4)     // Catch: java.lang.Throwable -> L28
            int r2 = (int) r4     // Catch: java.lang.Throwable -> L28
            com.facetec.sdk.oz r4 = r8.o     // Catch: java.lang.Throwable -> L28
            int r4 = r4.d     // Catch: java.lang.Throwable -> L28
            int r2 = java.lang.Math.min(r2, r4)     // Catch: java.lang.Throwable -> L28
            long r4 = r8.n     // Catch: java.lang.Throwable -> L28
            long r6 = (long) r2     // Catch: java.lang.Throwable -> L28
            long r4 = r4 - r6
            r8.n = r4     // Catch: java.lang.Throwable -> L28
            monitor-exit(r8)     // Catch: java.lang.Throwable -> L28
            long r12 = r12 - r6
            com.facetec.sdk.oz r4 = r8.o
            if (r10 == 0) goto L51
            int r5 = (r12 > r0 ? 1 : (r12 == r0 ? 0 : -1))
            if (r5 != 0) goto L51
            r5 = 1
            goto L52
        L51:
            r5 = r3
        L52:
            r4.e(r5, r9, r11, r2)
            goto Ld
        L56:
            java.lang.Thread r9 = java.lang.Thread.currentThread()     // Catch: java.lang.Throwable -> L28
            r9.interrupt()     // Catch: java.lang.Throwable -> L28
            java.io.InterruptedIOException r9 = new java.io.InterruptedIOException     // Catch: java.lang.Throwable -> L28
            r9.<init>()     // Catch: java.lang.Throwable -> L28
            throw r9     // Catch: java.lang.Throwable -> L28
        L63:
            monitor-exit(r8)
            throw r9
        L65:
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: com.facetec.sdk.ov.e(int, boolean, com.facetec.sdk.px, long):void");
    }

    public class b extends np implements ox.a {
        private ox b;

        /* JADX INFO: renamed from: com.facetec.sdk.ov$b$1, reason: invalid class name */
        public class AnonymousClass1 extends np {
            public static int c;
            public static int e;
            private /* synthetic */ pb b;
            private /* synthetic */ boolean d = false;

            /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
            public AnonymousClass1(String str, Object[] objArr, boolean z, pb pbVar) {
                super(str, objArr);
                this.b = pbVar;
            }

            public static int e() {
                int i = e;
                int i2 = i % 9076781;
                e = i + 1;
                if (i2 != 0) {
                    return c;
                }
                int iUptimeMillis = (int) SystemClock.uptimeMillis();
                c = iUptimeMillis;
                return iUptimeMillis;
            }

            @Override // com.facetec.sdk.np
            public final void c() {
                int i;
                pa[] paVarArr;
                long j;
                final b bVar = b.this;
                boolean z = this.d;
                pb pbVar = this.b;
                synchronized (ov.this.o) {
                    synchronized (ov.this) {
                        try {
                            int iC = ov.this.l.c();
                            if (z) {
                                pb pbVar2 = ov.this.l;
                                pbVar2.b = 0;
                                Arrays.fill(pbVar2.a, 0);
                            }
                            pb pbVar3 = ov.this.l;
                            for (int i2 = 0; i2 < 10; i2++) {
                                if (pbVar.b(i2)) {
                                    pbVar3.c(i2, pbVar.d(i2));
                                }
                            }
                            int iC2 = ov.this.l.c();
                            paVarArr = null;
                            if (iC2 == -1 || iC2 == iC) {
                                j = 0;
                            } else {
                                j = iC2 - iC;
                                if (!ov.this.b.isEmpty()) {
                                    paVarArr = (pa[]) ov.this.b.values().toArray(new pa[ov.this.b.size()]);
                                }
                            }
                        } catch (Throwable th) {
                            throw th;
                        }
                    }
                    try {
                        ov ovVar = ov.this;
                        ovVar.o.e(ovVar.l);
                    } catch (IOException unused) {
                        ov.this.d();
                    }
                }
                if (paVarArr != null) {
                    for (pa paVar : paVarArr) {
                        synchronized (paVar) {
                            paVar.c(j);
                        }
                    }
                }
                ov.q.execute(new np("OkHttp %s settings", ov.this.d) { // from class: com.facetec.sdk.ov.b.5
                    @Override // com.facetec.sdk.np
                    public final void c() {
                        ov ovVar2 = ov.this;
                        ovVar2.c.b(ovVar2);
                    }
                });
            }
        }

        /* JADX INFO: renamed from: com.facetec.sdk.ov$b$4, reason: invalid class name */
        public class AnonymousClass4 extends np {
            public static int b;
            public static int e;
            private /* synthetic */ pa d;

            /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
            public AnonymousClass4(String str, Object[] objArr, pa paVar) {
                super(str, objArr);
                this.d = paVar;
            }

            public static int d() {
                int i = e;
                int i2 = i % 8717898;
                e = i + 1;
                if (i2 != 0) {
                    return b;
                }
                int i3 = (int) Runtime.getRuntime().totalMemory();
                b = i3;
                return i3;
            }

            @Override // com.facetec.sdk.np
            public final void c() {
                try {
                    ov.this.c.e(this.d);
                } catch (IOException e2) {
                    pm pmVarI = pm.i();
                    StringBuilder sb = new StringBuilder("Http2Connection.Listener failure for ");
                    sb.append(ov.this.d);
                    pmVarI.a(4, sb.toString(), e2);
                    try {
                        this.d.b(or.PROTOCOL_ERROR);
                    } catch (IOException unused) {
                    }
                }
            }
        }

        public b(ox oxVar) {
            super("OkHttp %s", ov.this.d);
            this.b = oxVar;
        }

        @Override // com.facetec.sdk.ox.a
        public final void a(final int i, final or orVar) {
            if (ov.a(i)) {
                final ov ovVar = ov.this;
                ovVar.c(new np("OkHttp %s Push Reset[%s]", new Object[]{ovVar.d, Integer.valueOf(i)}) { // from class: com.facetec.sdk.ov.8
                    private static final byte[] $$a = null;
                    private static final int $$b = 0;
                    private static final byte[] $$c = null;
                    private static final int $$d = 0;
                    private static int $10;
                    private static int $11;
                    private static long b;
                    private static char[] e;
                    private static int h;
                    private static int j;

                    /* JADX WARN: Removed duplicated region for block: B:10:0x0023  */
                    /* JADX WARN: Removed duplicated region for block: B:8:0x001d  */
                    /* JADX WARN: Unsupported multi-entry loop pattern (BACK_EDGE: B:10:0x0023 -> B:11:0x0025). Please report as a decompilation issue!!! */
                    /*
                        Code decompiled incorrectly, please refer to instructions dump.
                        To view partially-correct code enable 'Show inconsistent code' option in preferences
                    */
                    private static java.lang.String $$e(int r6, byte r7, short r8) {
                        /*
                            int r6 = 111 - r6
                            byte[] r0 = com.facetec.sdk.ov.AnonymousClass8.$$c
                            int r8 = r8 * 4
                            int r8 = r8 + 1
                            int r7 = r7 * 3
                            int r7 = 4 - r7
                            byte[] r1 = new byte[r8]
                            r2 = 0
                            if (r0 != 0) goto L15
                            r6 = r7
                            r3 = r8
                            r4 = r2
                            goto L25
                        L15:
                            r3 = r2
                        L16:
                            int r4 = r3 + 1
                            byte r5 = (byte) r6
                            r1[r3] = r5
                            if (r4 != r8) goto L23
                            java.lang.String r6 = new java.lang.String
                            r6.<init>(r1, r2)
                            return r6
                        L23:
                            r3 = r0[r7]
                        L25:
                            int r3 = -r3
                            int r7 = r7 + 1
                            int r6 = r6 + r3
                            r3 = r4
                            goto L16
                        */
                        throw new UnsupportedOperationException("Method not decompiled: com.facetec.sdk.ov.AnonymousClass8.$$e(int, byte, short):java.lang.String");
                    }

                    static {
                        init$1();
                        $10 = 0;
                        $11 = 1;
                        init$0();
                        h = 0;
                        j = 1;
                        e = new char[]{57919, 3377, 15418, 12047, 24164, 18759, 30793, 27581, 39571, 34192, 46301, 42981, 54984, 50748, 61739, 57369, 4962, 615, 11610, 57889, 3363, 15383, 12062, 24175, 18780, 30793, 27548, 39577, 34192, 46298, 42991, 54980, 50727, 61737, 57373, 4979, 624, 57911, 3372, 15386, 12056, 24169, 18779, 30794, 27636, 39577, 34193, 46256, 42958, 54979, 50736, 61755, 57373, 57977, 3377, 15367, 12057, 24105, 18777, 30795, 27560, 39576, 34183, 46322, 42917, 54978, 50743, 61740, 57359, 4977, 557, 11594, 23640, 20391, 32401, 27015, 39156, 35793, 47757, 43581, 54591, 50196, 63328, 58987, 4436, 162, 13213, 8842, 19864, 31975, 28625, 40651, 36392, 57912, 3373, 15374, 27209, 34050, 46140, 42805, 54869, 49453, 61549, 58259, 4789, 3581, 15557, 12255, 24292, 19980, 31003, 26662, 39689, 35412, 42362, 54376, 51095, 63137, 57787, 4341, 995, 13052, 8719, 23832, 19514, 32583, 28250, 38850, 57977, 3377, 15367, 12057, 24105, 18777, 30795, 27560, 39576, 34183, 46322, 42917, 54978, 50743, 61740, 57359, 4977, 557, 11594, 23640, 20391, 32401, 27015, 39156, 35793, 47757, 43562, 54584, 50183, 63345, 58983, 4436, 177, 13213, 8849, 19844};
                        b = 7540181624212819266L;
                    }

                    /* JADX WARN: Can't wrap try/catch for region: R(16:96|16|(1:18)|19|20|(2:90|21)|(1:23)(8:89|26|106|27|28|102|29|(9:31|25|42|101|43|(1:45)(4:46|92|47|48)|(8:98|53|(1:55)(1:57)|56|(4:59|94|60|61)(2:65|66)|(1:68)(1:70)|69|(2:72|76)(3:(1:74)|75|76))(2:75|76)|77|78)(10:33|34|35|42|101|43|(0)(0)|(0)(0)|77|78))|24|25|42|101|43|(0)(0)|(0)(0)|77|78) */
                    /* JADX WARN: Multi-variable type inference failed */
                    /* JADX WARN: Removed duplicated region for block: B:45:0x0453  */
                    /* JADX WARN: Removed duplicated region for block: B:46:0x0456 A[Catch: Exception -> 0x0453, TRY_LEAVE, TryCatch #7 {Exception -> 0x0453, blocks: (B:43:0x037b, B:46:0x0456, B:48:0x056d, B:50:0x0575, B:51:0x057b, B:47:0x0460), top: B:101:0x037b, inners: #2 }] */
                    /* JADX WARN: Removed duplicated region for block: B:75:0x0681  */
                    /* JADX WARN: Removed duplicated region for block: B:98:0x057e A[EXC_TOP_SPLITTER, SYNTHETIC] */
                    /* JADX WARN: Type inference failed for: r22v0, types: [long] */
                    /* JADX WARN: Type inference failed for: r22v2 */
                    /* JADX WARN: Type inference failed for: r22v3 */
                    /* JADX WARN: Type inference failed for: r22v5 */
                    /*
                        Code decompiled incorrectly, please refer to instructions dump.
                        To view partially-correct code enable 'Show inconsistent code' option in preferences
                    */
                    public static java.lang.Object[] a(int r29, int r30) throws java.lang.Throwable {
                        /*
                            Method dump skipped, instruction units count: 1937
                            To view this dump change 'Code comments level' option to 'DEBUG'
                        */
                        throw new UnsupportedOperationException("Method not decompiled: com.facetec.sdk.ov.AnonymousClass8.a(int, int):java.lang.Object[]");
                    }

                    /* JADX WARN: Removed duplicated region for block: B:63:0x02fb  */
                    /* JADX WARN: Removed duplicated region for block: B:64:0x02fc  */
                    /*
                        Code decompiled incorrectly, please refer to instructions dump.
                        To view partially-correct code enable 'Show inconsistent code' option in preferences
                    */
                    private static void f(int r33, char r34, int r35, java.lang.Object[] r36) throws java.lang.Throwable {
                        /*
                            Method dump skipped, instruction units count: 775
                            To view this dump change 'Code comments level' option to 'DEBUG'
                        */
                        throw new UnsupportedOperationException("Method not decompiled: com.facetec.sdk.ov.AnonymousClass8.f(int, char, int, java.lang.Object[]):void");
                    }

                    /* JADX WARN: Removed duplicated region for block: B:10:0x0026  */
                    /* JADX WARN: Removed duplicated region for block: B:8:0x001e  */
                    /* JADX WARN: Unsupported multi-entry loop pattern (BACK_EDGE: B:10:0x0026 -> B:11:0x0028). Please report as a decompilation issue!!! */
                    /*
                        Code decompiled incorrectly, please refer to instructions dump.
                        To view partially-correct code enable 'Show inconsistent code' option in preferences
                    */
                    private static void g(int r6, short r7, short r8, java.lang.Object[] r9) {
                        /*
                            int r7 = r7 * 2
                            int r7 = r7 + 4
                            byte[] r0 = com.facetec.sdk.ov.AnonymousClass8.$$a
                            int r8 = r8 * 2
                            int r8 = r8 + 98
                            int r6 = r6 * 3
                            int r6 = r6 + 1
                            byte[] r1 = new byte[r6]
                            r2 = 0
                            if (r0 != 0) goto L16
                            r3 = r6
                            r4 = r2
                            goto L28
                        L16:
                            r3 = r2
                        L17:
                            int r4 = r3 + 1
                            byte r5 = (byte) r8
                            r1[r3] = r5
                            if (r4 != r6) goto L26
                            java.lang.String r6 = new java.lang.String
                            r6.<init>(r1, r2)
                            r9[r2] = r6
                            return
                        L26:
                            r3 = r0[r7]
                        L28:
                            int r7 = r7 + 1
                            int r8 = r8 + r3
                            r3 = r4
                            goto L17
                        */
                        throw new UnsupportedOperationException("Method not decompiled: com.facetec.sdk.ov.AnonymousClass8.g(int, short, short, java.lang.Object[]):void");
                    }

                    public static void init$0() {
                        $$a = new byte[]{115, ISOFileInfo.FILE_IDENTIFIER, 45, -41};
                        $$b = EnumC41897g.SDK_ASSET_ILLUSTRATION_ROUTING_NUMBER_CONFIRMED_CIRCLE_VALUE;
                    }

                    public static void init$1() {
                        $$c = new byte[]{57, 126, 65, 8};
                        $$d = EnumC41897g.SDK_ASSET_ILLUSTRATION_CONSENT_HEADER_WEB3_DARK_APPEARANCE_VALUE;
                    }

                    @Override // com.facetec.sdk.np
                    public final void c() {
                        ov ovVar2 = ov.this;
                        pd pdVar = ovVar2.f95938g;
                        synchronized (ovVar2) {
                            ov.this.p.remove(Integer.valueOf(i));
                        }
                    }
                });
            } else {
                pa paVarC = ov.this.c(i);
                if (paVarC != null) {
                    paVarC.a(orVar);
                }
            }
        }

        @Override // com.facetec.sdk.ox.a
        public final void b(final boolean z, final int i, final List<os> list) {
            boolean zC;
            if (ov.a(i)) {
                final ov ovVar = ov.this;
                try {
                    ovVar.c(new np("OkHttp %s Push Headers[%s]", new Object[]{ovVar.d, Integer.valueOf(i)}) { // from class: com.facetec.sdk.ov.4
                        @Override // com.facetec.sdk.np
                        public final void c() {
                            ov ovVar2 = ov.this;
                            pd pdVar = ovVar2.f95938g;
                            try {
                                ovVar2.o.a(i, or.CANCEL);
                                synchronized (ov.this) {
                                    ov.this.p.remove(Integer.valueOf(i));
                                }
                            } catch (IOException unused) {
                            }
                        }
                    });
                    return;
                } catch (RejectedExecutionException unused) {
                    return;
                }
            }
            synchronized (ov.this) {
                try {
                    pa paVarE = ov.this.e(i);
                    if (paVarE == null) {
                        if (ov.this.t) {
                            return;
                        }
                        ov ovVar2 = ov.this;
                        if (i <= ovVar2.e) {
                            return;
                        }
                        if (i % 2 == ovVar2.h % 2) {
                            return;
                        }
                        pa paVar = new pa(i, ov.this, false, z, nu.b(list));
                        ov ovVar3 = ov.this;
                        ovVar3.e = i;
                        ovVar3.b.put(Integer.valueOf(i), paVar);
                        ov.q.execute(new AnonymousClass4("OkHttp %s stream %d", new Object[]{ov.this.d, Integer.valueOf(i)}, paVar));
                        return;
                    }
                    if (!pa.m && Thread.holdsLock(paVarE)) {
                        throw new AssertionError();
                    }
                    synchronized (paVarE) {
                        paVarE.h = true;
                        paVarE.e.add(nu.b(list));
                        zC = paVarE.c();
                        paVarE.notifyAll();
                    }
                    if (!zC) {
                        paVarE.c.c(paVarE.d);
                    }
                    if (z) {
                        paVarE.i();
                    }
                } catch (Throwable th) {
                    throw th;
                }
            }
        }

        @Override // com.facetec.sdk.np
        public final void c() throws Throwable {
            or orVar;
            or orVar2;
            or orVar3 = or.INTERNAL_ERROR;
            try {
                try {
                    ox oxVar = this.b;
                    if (!oxVar.a) {
                        pz pzVar = oxVar.d;
                        qb qbVar = oy.a;
                        qb qbVarA = pzVar.a(qbVar.h());
                        Logger logger = ox.e;
                        if (logger.isLoggable(Level.FINE)) {
                            logger.fine(nu.b("<< CONNECTION %s", qbVarA.e()));
                        }
                        if (!qbVar.equals(qbVarA)) {
                            throw oy.c("Expected a connection header but was %s", qbVarA.d());
                        }
                    } else if (!oxVar.d(true, this)) {
                        throw oy.c("Required SETTINGS preface not received", new Object[0]);
                    }
                    while (this.b.d(false, this)) {
                    }
                    orVar2 = or.NO_ERROR;
                } catch (IOException unused) {
                    orVar2 = orVar3;
                } catch (Throwable th) {
                    th = th;
                    orVar = orVar3;
                    try {
                        ov.this.e(orVar, orVar3);
                    } catch (IOException unused2) {
                    }
                    nu.d(this.b);
                    throw th;
                }
                try {
                    try {
                        ov.this.e(orVar2, or.CANCEL);
                    } catch (Throwable th2) {
                        orVar = orVar2;
                        th = th2;
                        ov.this.e(orVar, orVar3);
                        nu.d(this.b);
                        throw th;
                    }
                } catch (IOException unused3) {
                    or orVar4 = or.PROTOCOL_ERROR;
                    ov.this.e(orVar4, orVar4);
                }
            } catch (IOException unused4) {
            }
            nu.d(this.b);
        }

        @Override // com.facetec.sdk.ox.a
        public final void d(final int i, final List<os> list) {
            final ov ovVar = ov.this;
            synchronized (ovVar) {
                try {
                    if (ovVar.p.contains(Integer.valueOf(i))) {
                        ovVar.e(i, or.PROTOCOL_ERROR);
                        return;
                    }
                    ovVar.p.add(Integer.valueOf(i));
                    try {
                        ovVar.c(new np("OkHttp %s Push Request[%s]", new Object[]{ovVar.d, Integer.valueOf(i)}) { // from class: com.facetec.sdk.ov.2
                            @Override // com.facetec.sdk.np
                            public final void c() {
                                ov ovVar2 = ov.this;
                                pd pdVar = ovVar2.f95938g;
                                try {
                                    ovVar2.o.a(i, or.CANCEL);
                                    synchronized (ov.this) {
                                        ov.this.p.remove(Integer.valueOf(i));
                                    }
                                } catch (IOException unused) {
                                }
                            }
                        });
                    } catch (RejectedExecutionException unused) {
                    }
                } catch (Throwable th) {
                    throw th;
                }
            }
        }

        /* JADX WARN: Code restructure failed: missing block: B:69:0x0119, code lost:
        
            if (r12 == false) goto L85;
         */
        /* JADX WARN: Code restructure failed: missing block: B:70:0x011b, code lost:
        
            r12.i();
         */
        /* JADX WARN: Code restructure failed: missing block: B:71:0x011e, code lost:
        
            return;
         */
        /* JADX WARN: Code restructure failed: missing block: B:85:?, code lost:
        
            return;
         */
        @Override // com.facetec.sdk.ox.a
        /*
            Code decompiled incorrectly, please refer to instructions dump.
            To view partially-correct code enable 'Show inconsistent code' option in preferences
        */
        public final void e(final boolean r12, final int r13, com.facetec.sdk.pz r14, final int r15) throws java.io.IOException {
            /*
                Method dump skipped, instruction units count: 287
                To view this dump change 'Code comments level' option to 'DEBUG'
            */
            throw new UnsupportedOperationException("Method not decompiled: com.facetec.sdk.ov.b.e(boolean, int, com.facetec.sdk.pz, int):void");
        }

        @Override // com.facetec.sdk.ox.a
        public final void a(boolean z, int i, int i2) {
            if (z) {
                synchronized (ov.this) {
                    try {
                        if (i == 1) {
                            ov.g(ov.this);
                        } else if (i == 2) {
                            ov.f(ov.this);
                        } else if (i == 3) {
                            ov.i(ov.this);
                            ov.this.notifyAll();
                        }
                    } catch (Throwable th) {
                        throw th;
                    }
                }
                return;
            }
            try {
                ov.this.f.execute(ov.this.new a(i, i2));
            } catch (RejectedExecutionException unused) {
            }
        }

        @Override // com.facetec.sdk.ox.a
        public final void a(int i, qb qbVar) {
            pa[] paVarArr;
            qbVar.h();
            synchronized (ov.this) {
                paVarArr = (pa[]) ov.this.b.values().toArray(new pa[ov.this.b.size()]);
                ov.h(ov.this);
            }
            for (pa paVar : paVarArr) {
                if (paVar.b() > i && paVar.a()) {
                    paVar.a(or.REFUSED_STREAM);
                    ov.this.c(paVar.b());
                }
            }
        }

        @Override // com.facetec.sdk.ox.a
        public final void c(int i, long j) {
            if (i == 0) {
                synchronized (ov.this) {
                    ov ovVar = ov.this;
                    ovVar.n += j;
                    ovVar.notifyAll();
                }
                return;
            }
            pa paVarE = ov.this.e(i);
            if (paVarE != null) {
                synchronized (paVarE) {
                    paVarE.c(j);
                }
            }
        }

        @Override // com.facetec.sdk.ox.a
        public final void e(pb pbVar) {
            try {
                ov.this.f.execute(new AnonymousClass1("OkHttp %s ACK Settings", new Object[]{ov.this.d}, false, pbVar));
            } catch (RejectedExecutionException unused) {
            }
        }
    }

    public final void c(int i, or orVar) {
        this.o.a(i, orVar);
    }

    public final pa a(List<os> list, boolean z) throws Throwable {
        Throwable th;
        boolean z2 = !z;
        synchronized (this.o) {
            try {
                try {
                    synchronized (this) {
                        try {
                            if (this.h > 1073741823) {
                                try {
                                    e(or.REFUSED_STREAM);
                                } catch (Throwable th2) {
                                    th = th2;
                                }
                            }
                            try {
                                if (!this.t) {
                                    int i = this.h;
                                    this.h = i + 2;
                                    pa paVar = new pa(i, this, z2, false, null);
                                    boolean z3 = !z || this.n == 0 || paVar.a == 0;
                                    if (paVar.c()) {
                                        this.b.put(Integer.valueOf(i), paVar);
                                    }
                                    this.o.a(z2, i, list);
                                    if (z3) {
                                        this.o.d();
                                    }
                                    return paVar;
                                }
                                throw new oq();
                            } catch (Throwable th3) {
                                th = th3;
                            }
                        } catch (Throwable th4) {
                            th = th4;
                        }
                        th = th;
                        throw th;
                    }
                } catch (Throwable th5) {
                    th = th5;
                    throw th;
                }
            } catch (Throwable th6) {
                th = th6;
                throw th;
            }
        }
    }

    public final void c(final int i, final long j) {
        try {
            this.f.execute(new np("OkHttp Window Update %s stream %d", new Object[]{this.d, Integer.valueOf(i)}) { // from class: com.facetec.sdk.ov.5
                @Override // com.facetec.sdk.np
                public final void c() {
                    try {
                        ov.this.o.d(i, j);
                    } catch (IOException unused) {
                        ov.this.d();
                    }
                }
            });
        } catch (RejectedExecutionException unused) {
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void d() {
        try {
            or orVar = or.PROTOCOL_ERROR;
            e(orVar, orVar);
        } catch (IOException unused) {
        }
    }

    public final void c(boolean z, int i, int i2) {
        try {
            this.o.d(z, i, i2);
        } catch (IOException unused) {
            d();
        }
    }

    public final synchronized void c(np npVar) {
        if (!this.t) {
            this.s.execute(npVar);
        }
    }

    public final void e(final int i, final or orVar) {
        try {
            this.f.execute(new np("OkHttp %s stream %d", new Object[]{this.d, Integer.valueOf(i)}) { // from class: com.facetec.sdk.ov.3
                @Override // com.facetec.sdk.np
                public final void c() {
                    try {
                        ov.this.c(i, orVar);
                    } catch (IOException unused) {
                        ov.this.d();
                    }
                }
            });
        } catch (RejectedExecutionException unused) {
        }
    }

    private void e(or orVar) {
        synchronized (this.o) {
            synchronized (this) {
                if (this.t) {
                    return;
                }
                this.t = true;
                this.o.a(this.e, orVar, nu.c);
            }
        }
    }

    public final synchronized boolean a(long j) {
        if (this.t) {
            return false;
        }
        if (this.i < this.j) {
            if (j >= this.m) {
                return false;
            }
        }
        return true;
    }

    public final void e(or orVar, or orVar2) throws IOException {
        if (!B && Thread.holdsLock(this)) {
            throw new AssertionError();
        }
        pa[] paVarArr = null;
        try {
            e(orVar);
            e = null;
        } catch (IOException e2) {
            e = e2;
        }
        synchronized (this) {
            try {
                if (!this.b.isEmpty()) {
                    paVarArr = (pa[]) this.b.values().toArray(new pa[this.b.size()]);
                    this.b.clear();
                }
            } catch (Throwable th) {
                throw th;
            }
        }
        if (paVarArr != null) {
            for (pa paVar : paVarArr) {
                try {
                    paVar.b(orVar2);
                } catch (IOException e3) {
                    if (e != null) {
                        e = e3;
                    }
                }
            }
        }
        try {
            this.o.close();
        } catch (IOException e4) {
            if (e == null) {
                e = e4;
            }
        }
        try {
            this.C.close();
        } catch (IOException e5) {
            e = e5;
        }
        this.f.shutdown();
        this.s.shutdown();
        if (e != null) {
            throw e;
        }
    }
}