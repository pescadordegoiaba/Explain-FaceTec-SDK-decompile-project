package com.facetec.sdk;

import ai.luciq.library.networkv2.request.Header;
import com.facetec.sdk.mz;
import com.facetec.sdk.ne;
import com.facetec.sdk.nh;
import com.facetec.sdk.pa;
import com.pichillilorenzo.flutter_inappwebview_android.credential_database.URLProtectionSpaceContract;
import com.plaid.internal.EnumC41897g;
import io.sentry.rrweb.RRWebVideoEvent;
import java.io.IOException;
import java.net.ProtocolException;
import java.nio.ByteBuffer;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.TimeUnit;
import net.sf.scuba.smartcards.ISO7816;
import org.bouncycastle.i18n.LocalizedMessage;
import org.jmrtd.PassportService;

/* JADX INFO: loaded from: classes4.dex */
public final class ow implements oi {
    private static final List<String> d = nu.b("connection", URLProtectionSpaceContract.FeedEntry.COLUMN_NAME_HOST, "keep-alive", "proxy-connection", "te", "transfer-encoding", RRWebVideoEvent.JsonKeys.ENCODING, "upgrade", ":method", ":path", ":scheme", ":authority");
    private static final List<String> e = nu.b("connection", URLProtectionSpaceContract.FeedEntry.COLUMN_NAME_HOST, "keep-alive", "proxy-connection", "te", "transfer-encoding", RRWebVideoEvent.JsonKeys.ENCODING, "upgrade");
    final oe a;
    private final ne.c b;
    private final ov c;
    private final ng f;
    private pa h;

    public class b extends qc {
        private static final byte[] $$a = null;
        private static final int $$b = 0;
        private static final byte[] $$c = null;
        private static final int $$d = 0;
        private static int $10;
        private static int $11;
        private static long d;
        private static char[] e;

        /* JADX INFO: renamed from: g, reason: collision with root package name */
        private static int f95940g;
        private static int h;
        private boolean a;
        private long c;

        /* JADX WARN: Removed duplicated region for block: B:10:0x0023  */
        /* JADX WARN: Removed duplicated region for block: B:8:0x001d  */
        /* JADX WARN: Unsupported multi-entry loop pattern (BACK_EDGE: B:10:0x0023 -> B:11:0x0028). Please report as a decompilation issue!!! */
        /*
            Code decompiled incorrectly, please refer to instructions dump.
            To view partially-correct code enable 'Show inconsistent code' option in preferences
        */
        private static java.lang.String $$e(byte r6, int r7, int r8) {
            /*
                int r7 = 111 - r7
                int r8 = r8 * 3
                int r8 = 1 - r8
                byte[] r0 = com.facetec.sdk.ow.b.$$c
                int r6 = r6 * 2
                int r6 = 4 - r6
                byte[] r1 = new byte[r8]
                r2 = 0
                if (r0 != 0) goto L15
                r7 = r6
                r4 = r8
                r3 = r2
                goto L28
            L15:
                r3 = r2
            L16:
                byte r4 = (byte) r7
                r1[r3] = r4
                int r3 = r3 + 1
                if (r3 != r8) goto L23
                java.lang.String r6 = new java.lang.String
                r6.<init>(r1, r2)
                return r6
            L23:
                r4 = r0[r6]
                r5 = r7
                r7 = r6
                r6 = r5
            L28:
                int r6 = r6 + r4
                int r7 = r7 + 1
                r5 = r7
                r7 = r6
                r6 = r5
                goto L16
            */
            throw new UnsupportedOperationException("Method not decompiled: com.facetec.sdk.ow.b.$$e(byte, int, int):java.lang.String");
        }

        static {
            init$1();
            $10 = 0;
            $11 = 1;
            init$0();
            f95940g = 0;
            h = 1;
            char[] cArr = new char[2156];
            ByteBuffer.wrap("1\u000fý\\©uU\u001e\u0001oÍ?ùß¥äQ\u0084\u001d\u009eÉ¹ô[ hlG\u0018\u0011Ä,ðÄ¼Êhõ\u0014\u009bÀ³\u008c\u0087»Cgx\u0013\u0001ß\u001b\u008b5G\u0015\u008bFßo#\u0004wu»%\u008fÅÓþ'\u009ek\u0084¿£\u0082AÖr\u001a]n\u001a²;\u0086ÊÊÇ\u001eÕb\u0096¶ªú°ÍI\u0011fe\u001eây.*z\u0003\u0086hÒ\u0019\u001eI*©v\u0092\u0082òÎè\u001aÏ'-s\u001e¿1Ëu\u0017G#¸o\u00adây.=z\u001f\u0086mÒ\u0019\u001eC*©v\u009a\u0082ãÎâ\u001aÃ'qs\u0011¿\u0001Ëj\u0017Z#°o§»\u0095Çö\u0013é_Ìh'´\nÀb\fkXTd§Gf\u008b4ß\r#bw\u0006»U\u008f¾ÓÏ'ùkã¿Ö\u00821ây.+z\u0012\u0086}Ò\u0019\u001e]*¯v\u0093\u0082¸Îþ\u001aÔ'1s\u0006\u0005¨Éì\u009dÓa¬5\u0086ù\u008dÍs\u0091\u0000e\u0015)\u0019ý:Àà\u0094ÑXÚ,\u0093ð\u008eÄs\u0088~14ýg©JU'\u0001\u001aÍLù¥¥ÐQ«\u001d¶É\u0082ô} ]lLâ$.!zH\u0086|ÒY\u001eA*²vÐ\u0082äÎë\u001aÂ',s\u0019¿\u0007Ëb\u0017a#¸o«»\u0092ÇÁ\u0013Ò_Àh5´Oâ$.!zH\u0086|ÒY\u001eA*²vÐ\u0082äÎë\u001aÂ',s\u0019¿\u0007Ëb\u0017a#¸o«»\u0092ÇÁ\u0013Ò_Àh5´Lây.=z\u001f\u0086mÒB\u001eK*«vÑ\u0082úÎç\u001aÄ'qs\u001a¿\u0007Ëd\u0017P#´oà»\u0095Çñ©ÖeÅ1ãÍ\u0092\u0099»U´\u001b\u009d×\u0098(Oä\u000b°)L[\u0018tÔ}à\u009d¼çHÂ\u0004ÑÐþíG¹.u=\u0001]Ý}é¶¥µqý\rÆÙå\u0095õ¢\u0005~e\nCÆW\u0092~®\u009cz²6·ÂÜây.=z\u001f\u0086mÒB\u001eK*«vÑ\u0082ôÎç\u001aÈ'qs\u0018¿\u000bËk\u0017K#\u0080o\u0083»ËÇî\u0013Ä_Áh6ây.=z\u001f\u0086mÒB\u001eK*«vÑ\u0082úÎç\u001aÄ'qs\u001a¿\u0007Ëd\u0017P#³o£»\u0093ÇÈ\u0013û_Þh4´\u0011Àf\f XUd±\u0012{Þ(\u008a\u0001vj\"\u001bîBÚ¡\u0086\u0091rá>ëêÑ×9\u0083\u0007O\u0018U:\u0099?ÍV1be]©Y\u009d´Á\u00845¦yø\u00ad×\u00903Ä\u001cõ¹9ªm\u0086\u0091ìÅÒ\t\u0081=)a\u001a\u0095cây.>z\u0014\u0086qÒU\u001e\u0001* v\u0097\u0082úÎë\u001aÕ''s\u0005¿\u001aËc\u0017S#¥øÁ4Ò`ò\u009c\u0092È¼\u0004±â$.!zH\u0086nÒD\u001eA*¢v\u008b\u0082õÎú\u001a\u0088'3s\u0017¿\u0000Ës\u0017X#·o\u00ad»\u0092Çë\u0013Ä_Ëh4#KïQ»rG\u001dôS8^la\u0090\u0018Ä*\b(<Ç`¥\u0094\u0090Ø\u0082\f 1\u0005ea©\u007fÝ]\u0001/5ÆyÙ\u00adæÑ\u008c\u0005íI¼~C¢~ÖM\u001a\u001dN2rÀ¦æêÄ\u001e\u0094B»wV»dïa\u0013\u000eG-\u008b?¿Öãù\u0017\u0086[\u0089\u0005\u009bÉ\u0096\u009d©aÐ5âùàÍ\u000f\u0091meX)JýhÀÍ\u0094©X·,\u0095ðçÄ\u000e\u0088\u0011\\. Dô%¸t\u008f\u008bS¶'\u0085ëÕ¿ú\u0083\bW.\u001b\fï\\³s\u0086\u009eJ¬\u001e\u00adâÆ¶åz÷N\u0014\u00121\u0089ÌEÁ\u0011þí\u0087¹µu·AX\u001d:é\u000f¥\u001dq?L\u009a\u0018þÔà Â|°HY\u0004FÐy¬\u0013xr46\u0003Ãßº«\u009fg\u00953¥â&.+z\u0014\u0086mÒ_\u001e]*²vÐ\u0082åÎ÷\u001aÕ'ps\u0014¿\nË(\u0017Z#³o¬»\u0093Çù\u0013\u0098_Üh)´PÀz\foXE&ËêÆ¾ùB\u0080\u0016²Ú°î_²=F\b\n\u001aÞ8ã\u009d·ù{ç\u000fÅÓ·ç^«A\u007f~\u0003\u0014×u\u009b1¬Äp½\u0004\u0096È\u0080\u009c¨â&.+z\u0014\u0086mÒ_\u001e]*²vÐ\u0082åÎ÷\u001aÕ'ps\u0014¿\nË(\u0017Z#³o¬»\u0093Çù\u0013\u0098_Üh)´PÀ{\f`XEt_¸Sìv\u0010\u0019D:\u00887ây.>z\u0014\u0086qÒU\u001e\u0001*«v\u0091\u0082òÎû\u001aÊ';s\u0005tD¸Hìm\u0010\u0002D5\u0088?¼Çàé\u0014\u0086ây.=z\u001f\u0086mÒB\u001eK*«vÑ\u0082ðÎü\u001aÇ'3s\u0013¿\u0019Ëi\u0017L#½oá»\u0091Ç÷\u0013Ø_Êh)´\tÀe\f#XUd§°\u0085ü\u009a\bãTÓa\t\u00ad=ù\u0003\u0005lQ@\u009dK©´õÐ\u0001üMï\u0099Ôây.8z\u0003\u0086pÒR\u001eA*´vÑ\u0082úÎç\u001aÄ'hsB¿AËn\u0017I#ùo¯»\u0093Çú\u0013ß_Áhh´\u000eÀd\fgXKd¿°\u0084ü\u0097\b¨TÉa?\u00ad ù\u0002\u0005qQA\u009d]©èõ\u008d\u0001ùë\u0011'Psk\u008f\u0018Û:\u0017)#Ü\u007f¹\u008b\u0092Ç\u008f\u0013¬.\u0000z*¶)Â\u0006\u001e!*\u0091fÎ²ùÎ\u0095\u001a±V«a^½yÉ\r\u0005\u0003Q<m\u0098¹éõï\u0001\u0080]²hQ¤Qð}\fXX-\u0094)ây.=z\u001f\u0086mÒB\u001eK*«vÑ\u0082úÎç\u001aÄ'hsB¿AËe\u0017R#¹o»»\u0082ÇÁ\u0013×_Çh\"´\u0012ÀI\fgXHdª°\u0093ü\u009c\bàTßa5\u00ad+ùK\u0005}QF\u009d^©èõ\u008d\u0001ù!Öí\u0084¹½EÒ\u0011¶Ýèé\u0007µ8AM\r\u000eÙ`ä\u009f°°|µ\b\u0087Ôòà\u0015¬\u000ex<\u0004UÐj\u009cd«\u009bw§\u0003ÐÏÂ\u009bì§_s+?\"2[þaªBV-\u0002\u0011Î\u000búø¦ÝR³\u001eªâ\u0085.\u0086z«\u0086ÖÒÿ\u001eÿ*\u000eüb0qdC\u0098&Ì\f\u0000\u00104ähÄâ$.!zH\u0086nÒD\u001eA*¢v\u008b\u0082õÎú\u001a\u0088':s\u0013¿\u0018Ëo\u0017]#³â .,z\t\u0086fÒ\u000e\u001e\u0018*¶¨ldv0UÌ&\u0098\u0019T\u001a`ø\u0097î[ô\u000f×ó¤§\u009bk\u0098_z\u0003~÷1»ioOâ1.+z\b\u0086{ÒD\u001eG*¥v¡\u0082îÎ¶\u001a\u0090'\u0001s@¿Zâ$.!zH\u0086nÒD\u001eA*¢v\u008b\u0082õÎú\u001a\u0088'3s\u0019¿\nËc\u0017RÕs\u0019|M[]è\u0091øÅÈ9©m\u008c¡\u0081\u0095rÉWâ\u0017.>z\u0016\u0086>Òd\u001e[*¨v\u008a\u0082ÿÎã\u001aÃ'~s\u0010¿\u0001Ët\u0017\u001e#\u0095o¦»\u0094Çñ\u0013Û_Ëâ\u0017. z\u0002\u0086lÒY\u001eG*¢vÞ\u0082ÅÎÊ\u001aí'~s\u0014¿\u001bËo\u0017R#¢oî»\u0080Çñ\u0013Ä_\u008eh>´FÀ â\u0017. z\u0002\u0086lÒY\u001eG*¢vÞ\u0082ÅÎÊ\u001aí'~s\u0014¿\u001bËo\u0017R#¢oî»\u0080Çñ\u0013Ä_\u008eh>´FÀ \fQX\u0010dêâ$.!zH\u0086vÒW\u001e\\*¢v\u0089\u0082÷Îü\u001aÃ\u0016²Ú¢\u008e\u0089rù&ÓêÄÞ6\u0082\u0015â .,z\t\u0086fÒ\u000e\u001e\u0018çÇ+Ì\u007fë\u0083\u009e×½\u001b¸©!e$1MÍk\u0099AUDa§=\u008eÉð\u0085ÿQ\u008dl98\u0001ô\n\u0080m\\_±q}t)\u001dÕ \u0081\u0006M\tyý%ÎÑ¯\u009dõI\u0082tn NìNâgâ$.!zH\u0086mÒS\u001eM*³v\u008c\u0082óâfÛ:\u0017?CV¿bë]'Y\u0013´O\u0084»¦÷à#Ê\u001e/J\f\u0086\u0005ò{.Tâ0.;z\n\u0086rÒi\u001eV*þvÈ\u0093£_¦\u000bÏ÷û£ÄoÀ[-\u0007\u001dó?¿okHV·\u0002\u0096Î\u008cºófÉR#\u001e Ê\u000f¶mâ1.+z\b\u0086{ÒD\u001eG*¥vÑ\u0082åÎê\u001aÍ'qs\u0011¿\u000bËh\u0017[#¤o§»\u0085â1.+z\b\u0086{ÒD\u001eG*¥v¡\u0082îÎ¶\u001a\u0090'qs\u0005¿\nËm\u0017a#®oö»ÐÇ±\u0013Ñ_Ëh(´\u001bÀd\fgXEd\u0081°\u008eüÖ\b°¸[tA bÜ\u0011\u0088.D-pÏ,»Ø\u009b\u0094\u008b@£}S)påa\u00913M'yØ5Ïá£\u009d\u0093I¹\u0005ª2Iîf\u009a\u0015V\u0007â1.+z\b\u0086{ÒD\u001eG*¥vÑ\u0082àÎì\u001aÉ'&sN¿XËv\u0017\u0011# o¬»\u0089Çæ\u0013\u008e_\u0098h6â1.!z\t\u0086yÒZ\u001eK*év\u008d\u0082òÎå\u001aù'9s\u0006¿\u0006Ëi\u0017P#³o\u0091»\u009eÇ¦\u0013\u0080_\u0081h!´\u001bÀx\fkXTd·°\u0095ü±\bþT\u0086a`[y\u0097|Ã\u0015?!k\u0004§\u001c\u0093ïÏÏ;¤w²£\u009f\u009efÊYÑ\b\u001d\rIdµPáu-m\u0019\u009eE»±×ýÃ)í\u0014\u0017@t\u008c ø_${\u0010\u0096\\\u0086\u0088äôÔ ólì[\r\u00877óH?RkxW\u009b\u0083´Ï¶â\u0017. z\u0002\u0086lÒY\u001eG*¢vÓ\u0082îÎ¶\u001a\u009072û7¯^Sj\u0007UËQÿ¼£\u008cW®\u001büÏÙò;¦\u0010j\u0014\u001eqÂQöîº±n\u0094â\".+z\u0015\u0086jÒ\u001bâ?. z\u000f\u0086jÒ\u0018\u001e]*°v\u009d\u0082¸Îÿ\u001aÃ'3s\u0003¿CËv\u0017L#¹o¾»\u0095â'.+z\u000b\u0086kÒ\u0018\u001eF*±vÐ\u0082ûÎï\u001aÏ'0s\u001d¿\u000bË\u007f\u0017Mâ'.+z\u000b\u0086kÒ\u0018\u001e]* vÐ\u0082ðÎï\u001aÍ';s)¿\rËg\u0017S#³o¼»\u0087â'.+z\u000b\u0086kÒ\u0018\u001e]* vÐ\u0082úÎí\u001aÂ'\u0001s\u0012¿\u000bËh\u0017M#¿oº»\u009fÖ³\u001a¶Nß²âæÄ*Ë\u001e?B\f¶mú7.P\u0013§G\u0085\u008b\u008bÿþ#À\u0017%[w\u008f\u0000ól'LkL\\µâ$.!zH\u0086|ÒY\u001eA*²vÐ\u0082çÎë\u001aË'+sX¿\u000fËp\u0017Z#\u0089o »\u0087Çó\u0013Ó¯ÊcÏ7¦Ë\u009f\u009f¼S\u00adg\u0006;rÏ\r\u0083\tW$jÔ>¶òæ\u0086\u0081Z¾n_\"Eöz\u008a\u0000^*\u0012)%Æùä ¡l¤8ÍÄë\u0090Á\\Äh'4\u000eÀp\u008c\u007fX\re¹1\u0086ý\u0082\u0089ïUßa}--ù\n\u0085uQT\u001dN*±ö\u008b\u0082áNâ\u001aÍ&/Ãö\u000fó[\u009a§¿ó\u009d?\u008f\u000b`WI£)ïr;\u0016\u0006ùRÍ\u009eÐê°6Â\u0002bNu\u009aZæ+2\u0001~\u000eIä\u0095Þá\u00ad-²y\u0080â$.!zH\u0086mÒO\u001e]*²v\u009b\u0082ûÎÑ\u001aÃ'&s\u0002¿@Ëd\u0017K#¿o¢»\u0082Ç°\u0013Ð_Çh(´\u0019Às\f|XVd¬°\u009fü\u0080\bòü,0)d@\u0098`Ì[\u0000H4ªh\u0099\u009cìÐ¨\u0004Ì9#m\u0017¡\nÕj\t\u0018=¸q¯¥\u0080Ùñ\rÛAÔv>ª\u0004Þw\u0012hFZ!ííè¹\u0081E¡\u0011\u009aÝ\u0089ékµXA-\r\u0018Ù\u000bäû°Ô|Ê\báÔ\u0095àj¬nxC\u00043ÐQ\u009c\u0001«æwÙ\u0003¸Ï¢\u009b\u009d§gsM?NË!\u0097\u0003â~Ú:\u0016.âl\u00892ây.*z\u0003\u0086hÒ\u0019\u001e_*£v\u0093\u0082ãÎÑ\u001aÖ'7s\u0006¿\u000bÔ\u009a\u0018ÉLà°\u008bäú(¾\u001cJ@~´\u001eø\b,1\u0011\u0092E÷\u0089ìý\u0096!¸\u0015WYL\u008dkñ\u0019%\ni*^À\u0082óö\u008c:\u0089ây.*z\u0003\u0086hÒ\u0019\u001e]*©v\u009d\u0082ýÎë\u001aÒ'qs\u0011¿\u000bËh\u0017G#²¦¹jê>ÃÂ¨\u0096ÙZ\u009dni2]Æ=\u008a+^\u0012c±7ÇûË\u008f«S\u008bgrÒ¬\u001eèJÊ¶¸âÌ.\u008a\u001avFF²6þ\u0004*\u0007\u0017ùCÂ\u008fØû¶ây.=z\u001f\u0086mÒB\u001eK*«vÑ\u0082úÎç\u001aÄ'qs\u001a¿\u0007Ëd\u0017]#\u0089o£»\u0087Çò\u0013Ú_Áh%´!Àr\fkXDd«°\u0091ü±\b÷TÛa;\u00ad;ùH\u0005mQYây.*z\u0003\u0086hÒ\u0019\u001eL*µv\u008a\u0082ÉÎé\u001aÖ'-ây.*z\u0003\u0086hÒ\u0019\u001eL*µv\u008a\u0082ÉÎú\u001aÏ'3s\u0013ßa\u00132G\u001b»pï\u0001#E\u0017±K\u0085¿åóó'Ê\u001aiN\f\u0082\u0005öj*@\u001e¡Rº\u0086\u009aúã.ÜbÒ\u0015\u008eÙÊ\u008dèq\u009a%µé¼Ý\\\u0081&u\r9\u0010í3Ð\u0086\u0084íHð<\u0093à«ÔR\u0098MLw0\u0006ä-¨=\u009fÔCû7¾û\u0093¯¿\u0093@G/\u000bjÿ\u001e¨½dî0ÇÌ¬\u0098ÝT\u0088`q<NÈ3\u0084)P\u0001mÿây.*z\u0003\u0086hÒ\u0019\u001eL*µv\u008a\u0082ñÎ÷\u001aÔ'1N\n\u0082YÖp*\u001b~j²?\u0086ÆÚù.\u0088b\u0098¶²\u008bC@û\u008c¨Ø\u0081$êp\u009b¼Î\u00887Ô\b {l~¸M\u0085¹ây.*z\u0003\u0086hÒ\u0019\u001eL*µv\u008a\u0082àÎã\u001aÕ'9ây.*z\u0003\u0086hÒ\u0019\u001eL*µv\u008a\u0082æÎé\u001aÇ'7s\u0006¿\rL\u0010\u0080CÔj(\u0001|p°%\u0084ÜØã, `\u008e´¢\u0089RW\u009a\u009bÉÏä3\u0089g´«â\u009fAÃr7\u0002{\u0003¯)\u0092ÒÆô\né~\u0096¢ò\u0096\u001bÚU\u000egrR¦7ê>ÝÑ\u0001öÜ \u0010zDQ¸3ì@ \u0000\u0014öHÉ¼«ð¸$\u0088\u0019tM\u0000\u0081uõ,)\u0013\u001dÜQÿ\u0085Þùµ-\u008aa\u0093VY\u008aHþ#23f\u001aZõây.>z\u0014\u0086qÒU\u001e\u0001*¯v\u0091\u0082æÎá\u001aÔ'*s\u0005³C\u007f\r+%×\u001b\u0083)Ã-\u000fj[@§%ó\u0001?U\u000báWÏ£®ï¼;Ý\u0006gRC\u009eJê!ù\u00935\u009ea¥\u009dÐÉø\u0005ã1\u0007mr\u0099SÕC\u0001h<\u0098h²¤¥Ð×\fô8Zt\u001f +ñ\u0096=\u008bi¨\u0095õÁÖ\rÇ99e\r\u0091XÝQ\t~4Ü`©¬\u00adW\u0085\u009b×Ïî3\u0081gå«¿\u009f_Ãf7\u0003{\u0013¯\u0005\u0092ÁÆå\nö~\u009f¢¡\u0096YÚ\u001c\u000ebr\u000f¦&â4.\"z\u0013\u0086{ÒE\u001eZ*§v\u009d\u0082ýÎýây.+z\u0012\u0086}Ò\u0019\u001eC*©v\u008b\u0082øÎú\u001aÕây.*z\u0007\u0086jÒW\u001e\u0001*¢v\u0091\u0082áÎà\u001aÊ'1s\u0017¿\nËu\u0017\u0011#øoª»\u0096Ç±\u0013×_Þh6´\rÀ8\fvXKd²ây.>z\u0014\u0086qÒU\u001e\u0001*¥v\u008e\u0082ãÎç\u001aÈ'8s\u0019HT\u0084dÐO,?x\u0015´\u0002\u0080ðÜÓÕv\u0019%M\b±eåX)\u000e\u001d¤A\u0098µêùâ-\u0086\u0010!D\u000b\u0088\u000eüo X\u0014µX¤\u008c\u009að¾$ÚhÔ_;\u0083^÷);.oJS¾\u0087\u0094ËÏ?äcØV:\u009a3Î\u00062gfPªS\u009e½Âß6ôzä®Ä\u009d$Á\u00105\fyl".getBytes(LocalizedMessage.DEFAULT_ENCODING)).asCharBuffer().get(cArr, 0, 2156);
            e = cArr;
            d = 8502434998299405902L;
        }

        public b(ql qlVar) {
            super(qlVar);
            this.a = false;
            this.c = 0L;
        }

        private void a(IOException iOException) {
            int i = f95940g + 95;
            h = i % 128;
            if (i % 2 == 0) {
                throw null;
            }
            if (this.a) {
                return;
            }
            this.a = true;
            ow owVar = ow.this;
            owVar.a.b(false, owVar, iOException);
            int i2 = h + 33;
            f95940g = i2 % 128;
            if (i2 % 2 != 0) {
                throw null;
            }
        }

        /* JADX WARN: Can't wrap try/catch for region: R(32:236|(1:238)|239|240|(1:242)(6:243|(7:245|246|(1:248)(1:249)|250|251|(2:269|427)(6:255|(6:257|258|(1:260)|261|262|(0)(0))|264|(1:266)(1:267)|268|428)|270)|426|271|(1:273)(1:274)|275)|276|277|(1:279)|280|(1:282)(4:283|(1:285)|286|287)|288|(1:292)(3:293|(2:294|(6:296|297|(1:299)(1:300)|301|302|(1:416)(3:305|(5:307|(1:309)|310|311|(1:417)(1:419))(1:418)|314))(2:415|315))|316)|317|(7:320|(1:322)(1:323)|324|(18:326|(6:328|329|(1:331)(1:332)|333|334|(3:420|344|(1:346)(1:347))(2:424|348))(6:337|338|(1:340)|341|342|(3:421|344|(0)(0))(2:425|348))|351|388|352|353|393|354|(1:356)|359|360|361|(1:363)(1:364)|370|371|(1:373)|374|375)|423|349|318)|422|350|351|388|352|353|393|354|(0)|359|360|361|(0)(0)|370|371|(0)|374|375) */
        /* JADX WARN: Code restructure failed: missing block: B:369:0x3809, code lost:
        
            r0 = r62 ^ 151;
         */
        /* JADX WARN: Removed duplicated region for block: B:110:0x0c0b A[Catch: all -> 0x3a1a, TryCatch #3 {all -> 0x3a1a, blocks: (B:6:0x00da, B:8:0x00e7, B:10:0x012c, B:23:0x02ae, B:25:0x02bb, B:27:0x0302, B:34:0x041a, B:36:0x0427, B:37:0x0461, B:66:0x065e, B:68:0x0664, B:69:0x06a0, B:89:0x0994, B:91:0x09a1, B:93:0x09e8, B:108:0x0bfe, B:110:0x0c0b, B:111:0x0c45, B:136:0x0dfc, B:138:0x0e09, B:139:0x0e45, B:147:0x0fc4, B:149:0x0fd1, B:151:0x1010, B:159:0x109d, B:161:0x10ac, B:162:0x10e2, B:183:0x1386, B:185:0x1393, B:187:0x13d4, B:207:0x1642, B:209:0x164f, B:211:0x1692, B:213:0x172b, B:216:0x174e, B:218:0x1768, B:219:0x17a4, B:222:0x1842, B:224:0x1853, B:225:0x188f, B:231:0x1957, B:233:0x1964, B:234:0x19a0, B:236:0x19a9, B:238:0x19c3, B:239:0x1a03, B:277:0x294c, B:279:0x2959, B:280:0x2991, B:297:0x2eb2, B:299:0x2ebf, B:301:0x2f00, B:307:0x2fd4, B:309:0x2fe1, B:310:0x301d, B:329:0x343e, B:331:0x3451, B:333:0x34a1, B:371:0x3846, B:373:0x3853, B:374:0x3887, B:338:0x3548, B:340:0x3558, B:341:0x3598, B:283:0x299d, B:285:0x29b6, B:286:0x29f7, B:246:0x265f, B:248:0x266c, B:250:0x26ba, B:258:0x26d7, B:260:0x26e7, B:261:0x272b, B:214:0x1739, B:192:0x147d, B:194:0x148a, B:195:0x14c2, B:167:0x11d5, B:169:0x11e4, B:170:0x121a, B:98:0x0a93, B:100:0x0aa0, B:101:0x0ae0, B:43:0x0545, B:45:0x0552, B:46:0x058e, B:56:0x05ed, B:58:0x05fa, B:59:0x0636), top: B:391:0x00da }] */
        /* JADX WARN: Removed duplicated region for block: B:113:0x0c50  */
        /* JADX WARN: Removed duplicated region for block: B:119:0x0c9a  */
        /* JADX WARN: Removed duplicated region for block: B:122:0x0d49  */
        /* JADX WARN: Removed duplicated region for block: B:134:0x0dc1  */
        /* JADX WARN: Removed duplicated region for block: B:138:0x0e09 A[Catch: all -> 0x3a1a, TryCatch #3 {all -> 0x3a1a, blocks: (B:6:0x00da, B:8:0x00e7, B:10:0x012c, B:23:0x02ae, B:25:0x02bb, B:27:0x0302, B:34:0x041a, B:36:0x0427, B:37:0x0461, B:66:0x065e, B:68:0x0664, B:69:0x06a0, B:89:0x0994, B:91:0x09a1, B:93:0x09e8, B:108:0x0bfe, B:110:0x0c0b, B:111:0x0c45, B:136:0x0dfc, B:138:0x0e09, B:139:0x0e45, B:147:0x0fc4, B:149:0x0fd1, B:151:0x1010, B:159:0x109d, B:161:0x10ac, B:162:0x10e2, B:183:0x1386, B:185:0x1393, B:187:0x13d4, B:207:0x1642, B:209:0x164f, B:211:0x1692, B:213:0x172b, B:216:0x174e, B:218:0x1768, B:219:0x17a4, B:222:0x1842, B:224:0x1853, B:225:0x188f, B:231:0x1957, B:233:0x1964, B:234:0x19a0, B:236:0x19a9, B:238:0x19c3, B:239:0x1a03, B:277:0x294c, B:279:0x2959, B:280:0x2991, B:297:0x2eb2, B:299:0x2ebf, B:301:0x2f00, B:307:0x2fd4, B:309:0x2fe1, B:310:0x301d, B:329:0x343e, B:331:0x3451, B:333:0x34a1, B:371:0x3846, B:373:0x3853, B:374:0x3887, B:338:0x3548, B:340:0x3558, B:341:0x3598, B:283:0x299d, B:285:0x29b6, B:286:0x29f7, B:246:0x265f, B:248:0x266c, B:250:0x26ba, B:258:0x26d7, B:260:0x26e7, B:261:0x272b, B:214:0x1739, B:192:0x147d, B:194:0x148a, B:195:0x14c2, B:167:0x11d5, B:169:0x11e4, B:170:0x121a, B:98:0x0a93, B:100:0x0aa0, B:101:0x0ae0, B:43:0x0545, B:45:0x0552, B:46:0x058e, B:56:0x05ed, B:58:0x05fa, B:59:0x0636), top: B:391:0x00da }] */
        /* JADX WARN: Removed duplicated region for block: B:142:0x0e86  */
        /* JADX WARN: Removed duplicated region for block: B:143:0x0e8c  */
        /* JADX WARN: Removed duplicated region for block: B:146:0x0fb7  */
        /* JADX WARN: Removed duplicated region for block: B:161:0x10ac A[Catch: all -> 0x3a1a, TryCatch #3 {all -> 0x3a1a, blocks: (B:6:0x00da, B:8:0x00e7, B:10:0x012c, B:23:0x02ae, B:25:0x02bb, B:27:0x0302, B:34:0x041a, B:36:0x0427, B:37:0x0461, B:66:0x065e, B:68:0x0664, B:69:0x06a0, B:89:0x0994, B:91:0x09a1, B:93:0x09e8, B:108:0x0bfe, B:110:0x0c0b, B:111:0x0c45, B:136:0x0dfc, B:138:0x0e09, B:139:0x0e45, B:147:0x0fc4, B:149:0x0fd1, B:151:0x1010, B:159:0x109d, B:161:0x10ac, B:162:0x10e2, B:183:0x1386, B:185:0x1393, B:187:0x13d4, B:207:0x1642, B:209:0x164f, B:211:0x1692, B:213:0x172b, B:216:0x174e, B:218:0x1768, B:219:0x17a4, B:222:0x1842, B:224:0x1853, B:225:0x188f, B:231:0x1957, B:233:0x1964, B:234:0x19a0, B:236:0x19a9, B:238:0x19c3, B:239:0x1a03, B:277:0x294c, B:279:0x2959, B:280:0x2991, B:297:0x2eb2, B:299:0x2ebf, B:301:0x2f00, B:307:0x2fd4, B:309:0x2fe1, B:310:0x301d, B:329:0x343e, B:331:0x3451, B:333:0x34a1, B:371:0x3846, B:373:0x3853, B:374:0x3887, B:338:0x3548, B:340:0x3558, B:341:0x3598, B:283:0x299d, B:285:0x29b6, B:286:0x29f7, B:246:0x265f, B:248:0x266c, B:250:0x26ba, B:258:0x26d7, B:260:0x26e7, B:261:0x272b, B:214:0x1739, B:192:0x147d, B:194:0x148a, B:195:0x14c2, B:167:0x11d5, B:169:0x11e4, B:170:0x121a, B:98:0x0a93, B:100:0x0aa0, B:101:0x0ae0, B:43:0x0545, B:45:0x0552, B:46:0x058e, B:56:0x05ed, B:58:0x05fa, B:59:0x0636), top: B:391:0x00da }] */
        /* JADX WARN: Removed duplicated region for block: B:165:0x117e  */
        /* JADX WARN: Removed duplicated region for block: B:166:0x1186  */
        /* JADX WARN: Removed duplicated region for block: B:177:0x12e1  */
        /* JADX WARN: Removed duplicated region for block: B:202:0x15a0  */
        /* JADX WARN: Removed duplicated region for block: B:206:0x1640  */
        /* JADX WARN: Removed duplicated region for block: B:218:0x1768 A[Catch: all -> 0x3a1a, TryCatch #3 {all -> 0x3a1a, blocks: (B:6:0x00da, B:8:0x00e7, B:10:0x012c, B:23:0x02ae, B:25:0x02bb, B:27:0x0302, B:34:0x041a, B:36:0x0427, B:37:0x0461, B:66:0x065e, B:68:0x0664, B:69:0x06a0, B:89:0x0994, B:91:0x09a1, B:93:0x09e8, B:108:0x0bfe, B:110:0x0c0b, B:111:0x0c45, B:136:0x0dfc, B:138:0x0e09, B:139:0x0e45, B:147:0x0fc4, B:149:0x0fd1, B:151:0x1010, B:159:0x109d, B:161:0x10ac, B:162:0x10e2, B:183:0x1386, B:185:0x1393, B:187:0x13d4, B:207:0x1642, B:209:0x164f, B:211:0x1692, B:213:0x172b, B:216:0x174e, B:218:0x1768, B:219:0x17a4, B:222:0x1842, B:224:0x1853, B:225:0x188f, B:231:0x1957, B:233:0x1964, B:234:0x19a0, B:236:0x19a9, B:238:0x19c3, B:239:0x1a03, B:277:0x294c, B:279:0x2959, B:280:0x2991, B:297:0x2eb2, B:299:0x2ebf, B:301:0x2f00, B:307:0x2fd4, B:309:0x2fe1, B:310:0x301d, B:329:0x343e, B:331:0x3451, B:333:0x34a1, B:371:0x3846, B:373:0x3853, B:374:0x3887, B:338:0x3548, B:340:0x3558, B:341:0x3598, B:283:0x299d, B:285:0x29b6, B:286:0x29f7, B:246:0x265f, B:248:0x266c, B:250:0x26ba, B:258:0x26d7, B:260:0x26e7, B:261:0x272b, B:214:0x1739, B:192:0x147d, B:194:0x148a, B:195:0x14c2, B:167:0x11d5, B:169:0x11e4, B:170:0x121a, B:98:0x0a93, B:100:0x0aa0, B:101:0x0ae0, B:43:0x0545, B:45:0x0552, B:46:0x058e, B:56:0x05ed, B:58:0x05fa, B:59:0x0636), top: B:391:0x00da }] */
        /* JADX WARN: Removed duplicated region for block: B:222:0x1842 A[Catch: all -> 0x3a1a, TRY_ENTER, TryCatch #3 {all -> 0x3a1a, blocks: (B:6:0x00da, B:8:0x00e7, B:10:0x012c, B:23:0x02ae, B:25:0x02bb, B:27:0x0302, B:34:0x041a, B:36:0x0427, B:37:0x0461, B:66:0x065e, B:68:0x0664, B:69:0x06a0, B:89:0x0994, B:91:0x09a1, B:93:0x09e8, B:108:0x0bfe, B:110:0x0c0b, B:111:0x0c45, B:136:0x0dfc, B:138:0x0e09, B:139:0x0e45, B:147:0x0fc4, B:149:0x0fd1, B:151:0x1010, B:159:0x109d, B:161:0x10ac, B:162:0x10e2, B:183:0x1386, B:185:0x1393, B:187:0x13d4, B:207:0x1642, B:209:0x164f, B:211:0x1692, B:213:0x172b, B:216:0x174e, B:218:0x1768, B:219:0x17a4, B:222:0x1842, B:224:0x1853, B:225:0x188f, B:231:0x1957, B:233:0x1964, B:234:0x19a0, B:236:0x19a9, B:238:0x19c3, B:239:0x1a03, B:277:0x294c, B:279:0x2959, B:280:0x2991, B:297:0x2eb2, B:299:0x2ebf, B:301:0x2f00, B:307:0x2fd4, B:309:0x2fe1, B:310:0x301d, B:329:0x343e, B:331:0x3451, B:333:0x34a1, B:371:0x3846, B:373:0x3853, B:374:0x3887, B:338:0x3548, B:340:0x3558, B:341:0x3598, B:283:0x299d, B:285:0x29b6, B:286:0x29f7, B:246:0x265f, B:248:0x266c, B:250:0x26ba, B:258:0x26d7, B:260:0x26e7, B:261:0x272b, B:214:0x1739, B:192:0x147d, B:194:0x148a, B:195:0x14c2, B:167:0x11d5, B:169:0x11e4, B:170:0x121a, B:98:0x0a93, B:100:0x0aa0, B:101:0x0ae0, B:43:0x0545, B:45:0x0552, B:46:0x058e, B:56:0x05ed, B:58:0x05fa, B:59:0x0636), top: B:391:0x00da }] */
        /* JADX WARN: Removed duplicated region for block: B:243:0x1ab1  */
        /* JADX WARN: Removed duplicated region for block: B:269:0x288c  */
        /* JADX WARN: Removed duplicated region for block: B:346:0x3649  */
        /* JADX WARN: Removed duplicated region for block: B:347:0x3652  */
        /* JADX WARN: Removed duplicated region for block: B:356:0x3703 A[Catch: all -> 0x373c, TryCatch #4 {all -> 0x373c, blocks: (B:354:0x36f4, B:356:0x3703, B:359:0x373f), top: B:393:0x36f4, outer: #1 }] */
        /* JADX WARN: Removed duplicated region for block: B:363:0x37f9 A[Catch: Exception -> 0x3809, TryCatch #1 {Exception -> 0x3809, blocks: (B:352:0x369d, B:361:0x3750, B:363:0x37f9, B:365:0x3801, B:367:0x3807, B:368:0x3808, B:354:0x36f4, B:356:0x3703, B:359:0x373f), top: B:388:0x369d, inners: #4 }] */
        /* JADX WARN: Removed duplicated region for block: B:364:0x37ff  */
        /* JADX WARN: Removed duplicated region for block: B:373:0x3853 A[Catch: all -> 0x3a1a, TryCatch #3 {all -> 0x3a1a, blocks: (B:6:0x00da, B:8:0x00e7, B:10:0x012c, B:23:0x02ae, B:25:0x02bb, B:27:0x0302, B:34:0x041a, B:36:0x0427, B:37:0x0461, B:66:0x065e, B:68:0x0664, B:69:0x06a0, B:89:0x0994, B:91:0x09a1, B:93:0x09e8, B:108:0x0bfe, B:110:0x0c0b, B:111:0x0c45, B:136:0x0dfc, B:138:0x0e09, B:139:0x0e45, B:147:0x0fc4, B:149:0x0fd1, B:151:0x1010, B:159:0x109d, B:161:0x10ac, B:162:0x10e2, B:183:0x1386, B:185:0x1393, B:187:0x13d4, B:207:0x1642, B:209:0x164f, B:211:0x1692, B:213:0x172b, B:216:0x174e, B:218:0x1768, B:219:0x17a4, B:222:0x1842, B:224:0x1853, B:225:0x188f, B:231:0x1957, B:233:0x1964, B:234:0x19a0, B:236:0x19a9, B:238:0x19c3, B:239:0x1a03, B:277:0x294c, B:279:0x2959, B:280:0x2991, B:297:0x2eb2, B:299:0x2ebf, B:301:0x2f00, B:307:0x2fd4, B:309:0x2fe1, B:310:0x301d, B:329:0x343e, B:331:0x3451, B:333:0x34a1, B:371:0x3846, B:373:0x3853, B:374:0x3887, B:338:0x3548, B:340:0x3558, B:341:0x3598, B:283:0x299d, B:285:0x29b6, B:286:0x29f7, B:246:0x265f, B:248:0x266c, B:250:0x26ba, B:258:0x26d7, B:260:0x26e7, B:261:0x272b, B:214:0x1739, B:192:0x147d, B:194:0x148a, B:195:0x14c2, B:167:0x11d5, B:169:0x11e4, B:170:0x121a, B:98:0x0a93, B:100:0x0aa0, B:101:0x0ae0, B:43:0x0545, B:45:0x0552, B:46:0x058e, B:56:0x05ed, B:58:0x05fa, B:59:0x0636), top: B:391:0x00da }] */
        /* JADX WARN: Removed duplicated region for block: B:376:0x398e  */
        /* JADX WARN: Removed duplicated region for block: B:404:0x102e A[SYNTHETIC] */
        /* JADX WARN: Removed duplicated region for block: B:414:0x174b A[SYNTHETIC] */
        /* JADX WARN: Removed duplicated region for block: B:55:0x05c2  */
        /* JADX WARN: Removed duplicated region for block: B:68:0x0664 A[Catch: all -> 0x3a1a, TryCatch #3 {all -> 0x3a1a, blocks: (B:6:0x00da, B:8:0x00e7, B:10:0x012c, B:23:0x02ae, B:25:0x02bb, B:27:0x0302, B:34:0x041a, B:36:0x0427, B:37:0x0461, B:66:0x065e, B:68:0x0664, B:69:0x06a0, B:89:0x0994, B:91:0x09a1, B:93:0x09e8, B:108:0x0bfe, B:110:0x0c0b, B:111:0x0c45, B:136:0x0dfc, B:138:0x0e09, B:139:0x0e45, B:147:0x0fc4, B:149:0x0fd1, B:151:0x1010, B:159:0x109d, B:161:0x10ac, B:162:0x10e2, B:183:0x1386, B:185:0x1393, B:187:0x13d4, B:207:0x1642, B:209:0x164f, B:211:0x1692, B:213:0x172b, B:216:0x174e, B:218:0x1768, B:219:0x17a4, B:222:0x1842, B:224:0x1853, B:225:0x188f, B:231:0x1957, B:233:0x1964, B:234:0x19a0, B:236:0x19a9, B:238:0x19c3, B:239:0x1a03, B:277:0x294c, B:279:0x2959, B:280:0x2991, B:297:0x2eb2, B:299:0x2ebf, B:301:0x2f00, B:307:0x2fd4, B:309:0x2fe1, B:310:0x301d, B:329:0x343e, B:331:0x3451, B:333:0x34a1, B:371:0x3846, B:373:0x3853, B:374:0x3887, B:338:0x3548, B:340:0x3558, B:341:0x3598, B:283:0x299d, B:285:0x29b6, B:286:0x29f7, B:246:0x265f, B:248:0x266c, B:250:0x26ba, B:258:0x26d7, B:260:0x26e7, B:261:0x272b, B:214:0x1739, B:192:0x147d, B:194:0x148a, B:195:0x14c2, B:167:0x11d5, B:169:0x11e4, B:170:0x121a, B:98:0x0a93, B:100:0x0aa0, B:101:0x0ae0, B:43:0x0545, B:45:0x0552, B:46:0x058e, B:56:0x05ed, B:58:0x05fa, B:59:0x0636), top: B:391:0x00da }] */
        /* JADX WARN: Removed duplicated region for block: B:72:0x07dd  */
        /* JADX WARN: Removed duplicated region for block: B:82:0x0856  */
        /* JADX WARN: Removed duplicated region for block: B:86:0x097f  */
        /*
            Code decompiled incorrectly, please refer to instructions dump.
            To view partially-correct code enable 'Show inconsistent code' option in preferences
        */
        public static java.lang.Object[] b(android.content.Context r61, int r62, int r63, int r64) throws java.lang.Throwable {
            /*
                Method dump skipped, instruction units count: 14883
                To view this dump change 'Code comments level' option to 'DEBUG'
            */
            throw new UnsupportedOperationException("Method not decompiled: com.facetec.sdk.ow.b.b(android.content.Context, int, int, int):java.lang.Object[]");
        }

        /* JADX WARN: Removed duplicated region for block: B:52:0x0281  */
        /* JADX WARN: Removed duplicated region for block: B:53:0x0282  */
        /*
            Code decompiled incorrectly, please refer to instructions dump.
            To view partially-correct code enable 'Show inconsistent code' option in preferences
        */
        private static void f(int r30, char r31, int r32, java.lang.Object[] r33) throws java.lang.Throwable {
            /*
                Method dump skipped, instruction units count: 666
                To view this dump change 'Code comments level' option to 'DEBUG'
            */
            throw new UnsupportedOperationException("Method not decompiled: com.facetec.sdk.ow.b.f(int, char, int, java.lang.Object[]):void");
        }

        /* JADX WARN: Removed duplicated region for block: B:10:0x0023  */
        /* JADX WARN: Removed duplicated region for block: B:8:0x001b  */
        /* JADX WARN: Unsupported multi-entry loop pattern (BACK_EDGE: B:10:0x0023 -> B:11:0x002b). Please report as a decompilation issue!!! */
        /*
            Code decompiled incorrectly, please refer to instructions dump.
            To view partially-correct code enable 'Show inconsistent code' option in preferences
        */
        private static void i(short r6, short r7, short r8, java.lang.Object[] r9) {
            /*
                int r7 = r7 + 4
                byte[] r0 = com.facetec.sdk.ow.b.$$a
                int r6 = r6 * 4
                int r1 = r6 + 1
                int r8 = r8 + 97
                byte[] r1 = new byte[r1]
                r2 = 0
                if (r0 != 0) goto L13
                r3 = r0
                r4 = r2
                r0 = r6
                goto L2b
            L13:
                r3 = r2
            L14:
                byte r4 = (byte) r8
                r1[r3] = r4
                int r4 = r3 + 1
                if (r3 != r6) goto L23
                java.lang.String r6 = new java.lang.String
                r6.<init>(r1, r2)
                r9[r2] = r6
                return
            L23:
                int r7 = r7 + 1
                r3 = r0[r7]
                r5 = r0
                r0 = r8
                r8 = r3
                r3 = r5
            L2b:
                int r8 = -r8
                int r8 = r8 + r0
                r0 = r3
                r3 = r4
                goto L14
            */
            throw new UnsupportedOperationException("Method not decompiled: com.facetec.sdk.ow.b.i(short, short, short, java.lang.Object[]):void");
        }

        public static void init$0() {
            $$a = new byte[]{115, PassportService.SFI_COM, 119, 102};
            $$b = EnumC41897g.SDK_ASSET_ILLUSTRATION_SHARE_YOUR_DATA_VALUE;
        }

        public static void init$1() {
            $$c = new byte[]{99, 53, ISO7816.INS_UNBLOCK_CHV, 107};
            $$d = 130;
        }

        @Override // com.facetec.sdk.qc, com.facetec.sdk.ql, java.io.Closeable, java.lang.AutoCloseable
        public void close() {
            h = (f95940g + 47) % 128;
            super.close();
            a(null);
            f95940g = (h + 85) % 128;
        }

        @Override // com.facetec.sdk.qc, com.facetec.sdk.ql
        public final long e(px pxVar, long j) throws IOException {
            f95940g = (h + 109) % 128;
            try {
                long jE = c().e(pxVar, j);
                if (jE <= 0) {
                    return jE;
                }
                int i = h;
                this.c += jE;
                f95940g = (i + 35) % 128;
                return jE;
            } catch (IOException e2) {
                a(e2);
                throw e2;
            }
        }
    }

    public ow(nf nfVar, ne.c cVar, oe oeVar, ov ovVar) {
        this.b = cVar;
        this.a = oeVar;
        this.c = ovVar;
        List<ng> listN = nfVar.n();
        ng ngVar = ng.H2_PRIOR_KNOWLEDGE;
        this.f = listN.contains(ngVar) ? ngVar : ng.HTTP_2;
    }

    @Override // com.facetec.sdk.oi
    public final qj a(nj njVar, long j) {
        return this.h.e();
    }

    @Override // com.facetec.sdk.oi
    public final void b() {
        this.c.b();
    }

    @Override // com.facetec.sdk.oi
    public final nh.e c(boolean z) throws ProtocolException {
        mz mzVarD = this.h.d();
        ng ngVar = this.f;
        mz.a aVar = new mz.a();
        int iD = mzVarD.d();
        ok okVarB = null;
        for (int i = 0; i < iD; i++) {
            String strA = mzVarD.a(i);
            String strB = mzVarD.b(i);
            if (strA.equals(":status")) {
                okVarB = ok.b("HTTP/1.1 ".concat(String.valueOf(strB)));
            } else if (!e.contains(strA)) {
                nn.d.e(aVar, strA, strB);
            }
        }
        if (okVarB == null) {
            throw new ProtocolException("Expected ':status' header not present");
        }
        nh.e eVarA = new nh.e().b(ngVar).e(okVarB.b).d(okVarB.a).a(aVar.c());
        if (z && nn.d.d(eVarA) == 100) {
            return null;
        }
        return eVarA;
    }

    @Override // com.facetec.sdk.oi
    public final void d(nj njVar) throws Throwable {
        if (this.h != null) {
            return;
        }
        boolean z = njVar.e() != null;
        mz mzVarA = njVar.a();
        ArrayList arrayList = new ArrayList(mzVarA.d() + 4);
        arrayList.add(new os(os.d, njVar.c()));
        arrayList.add(new os(os.e, om.a(njVar.b())));
        String strA = njVar.a("Host");
        if (strA != null) {
            arrayList.add(new os(os.h, strA));
        }
        arrayList.add(new os(os.b, njVar.b().e()));
        int iD = mzVarA.d();
        for (int i = 0; i < iD; i++) {
            qb qbVarD = qb.d(mzVarA.a(i).toLowerCase(Locale.US));
            if (!d.contains(qbVarD.d())) {
                arrayList.add(new os(qbVarD, mzVarA.b(i)));
            }
        }
        pa paVarA = this.c.a(arrayList, z);
        this.h = paVarA;
        pa.d dVar = paVarA.f;
        long jB = this.b.b();
        TimeUnit timeUnit = TimeUnit.MILLISECONDS;
        dVar.b(jB, timeUnit);
        this.h.f95942g.b(this.b.c(), timeUnit);
    }

    @Override // com.facetec.sdk.oi
    public final void e() {
        pa paVar = this.h;
        if (paVar != null) {
            paVar.e(or.CANCEL);
        }
    }

    @Override // com.facetec.sdk.oi
    public final void a() {
        this.h.e().close();
    }

    @Override // com.facetec.sdk.oi
    public final no c(nh nhVar) {
        oe oeVar = this.a;
        na naVar = oeVar.a;
        mn mnVar = oeVar.c;
        return new on(nhVar.a(Header.CONTENT_TYPE), oh.d(nhVar), qf.d(new b(this.h.i)));
    }
}