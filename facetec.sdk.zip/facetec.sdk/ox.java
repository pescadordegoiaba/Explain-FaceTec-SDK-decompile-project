package com.facetec.sdk;

import com.facetec.sdk.ou;
import java.io.Closeable;
import java.io.IOException;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import org.bouncycastle.crypto.hpke.HPKE;

/* JADX INFO: loaded from: classes4.dex */
final class ox implements Closeable {
    static final Logger e = Logger.getLogger(oy.class.getName());
    final boolean a;
    private final b b;
    private ou.d c;
    final pz d;

    public interface a {
        void a(int i, or orVar);

        void a(int i, qb qbVar);

        void a(boolean z, int i, int i2);

        void b(boolean z, int i, List<os> list);

        void c(int i, long j);

        void d(int i, List<os> list);

        void e(pb pbVar);

        void e(boolean z, int i, pz pzVar, int i2);
    }

    public static final class b implements ql {
        int a;
        byte b;
        int c;
        short d;
        int e;
        private final pz i;

        public b(pz pzVar) {
            this.i = pzVar;
        }

        @Override // com.facetec.sdk.ql
        public final qp a() {
            return this.i.a();
        }

        @Override // com.facetec.sdk.ql, java.io.Closeable, java.lang.AutoCloseable
        public final void close() {
        }

        @Override // com.facetec.sdk.ql
        public final long e(px pxVar, long j) throws IOException {
            int i;
            int iF;
            do {
                int i2 = this.a;
                if (i2 != 0) {
                    long jE = this.i.e(pxVar, Math.min(j, i2));
                    if (jE == -1) {
                        return -1L;
                    }
                    this.a = (int) (((long) this.a) - jE);
                    return jE;
                }
                this.i.f(this.d);
                this.d = (short) 0;
                if ((this.b & 4) != 0) {
                    return -1L;
                }
                i = this.e;
                int iA = ox.a(this.i);
                this.a = iA;
                this.c = iA;
                byte bG = this.i.g();
                this.b = this.i.g();
                Logger logger = ox.e;
                if (logger.isLoggable(Level.FINE)) {
                    logger.fine(oy.e(true, this.e, this.c, bG, this.b));
                }
                iF = this.i.f() & Integer.MAX_VALUE;
                this.e = iF;
                if (bG != 9) {
                    throw oy.c("%s != TYPE_CONTINUATION", Byte.valueOf(bG));
                }
            } while (iF == i);
            throw oy.c("TYPE_CONTINUATION streamId changed", new Object[0]);
        }
    }

    public ox(pz pzVar, boolean z) {
        this.d = pzVar;
        this.a = z;
        b bVar = new b(pzVar);
        this.b = bVar;
        this.c = new ou.d(bVar);
    }

    public static int a(pz pzVar) {
        return (pzVar.g() & 255) | ((pzVar.g() & 255) << 16) | ((pzVar.g() & 255) << 8);
    }

    private void b() {
        this.d.f();
        this.d.g();
    }

    @Override // java.io.Closeable, java.lang.AutoCloseable
    public final void close() {
        this.d.close();
    }

    public final boolean d(boolean z, a aVar) throws IOException {
        try {
            this.d.c(9L);
            int iA = a(this.d);
            if (iA < 0 || iA > 16384) {
                throw oy.c("FRAME_SIZE_ERROR: %s", Integer.valueOf(iA));
            }
            byte bG = this.d.g();
            if (z && bG != 4) {
                throw oy.c("Expected a SETTINGS frame but was %s", Byte.valueOf(bG));
            }
            byte bG2 = this.d.g();
            int iF = this.d.f() & Integer.MAX_VALUE;
            Logger logger = e;
            if (logger.isLoggable(Level.FINE)) {
                logger.fine(oy.e(true, iF, iA, bG, bG2));
            }
            switch (bG) {
                case 0:
                    if (iF == 0) {
                        throw oy.c("PROTOCOL_ERROR: TYPE_DATA streamId == 0", new Object[0]);
                    }
                    boolean z2 = (bG2 & 1) != 0;
                    if ((bG2 & 32) != 0) {
                        throw oy.c("PROTOCOL_ERROR: FLAG_COMPRESSED without SETTINGS_COMPRESS_DATA", new Object[0]);
                    }
                    short sG = (bG2 & 8) != 0 ? (short) (this.d.g() & 255) : (short) 0;
                    aVar.e(z2, iF, this.d, a(iA, bG2, sG));
                    this.d.f(sG);
                    return true;
                case 1:
                    if (iF == 0) {
                        throw oy.c("PROTOCOL_ERROR: TYPE_HEADERS streamId == 0", new Object[0]);
                    }
                    boolean z3 = (bG2 & 1) != 0;
                    short sG2 = (bG2 & 8) != 0 ? (short) (this.d.g() & 255) : (short) 0;
                    if ((bG2 & 32) != 0) {
                        b();
                        iA -= 5;
                    }
                    aVar.b(z3, iF, d(a(iA, bG2, sG2), sG2, bG2, iF));
                    return true;
                case 2:
                    if (iA != 5) {
                        throw oy.c("TYPE_PRIORITY length: %d != 5", Integer.valueOf(iA));
                    }
                    if (iF == 0) {
                        throw oy.c("TYPE_PRIORITY streamId == 0", new Object[0]);
                    }
                    b();
                    return true;
                case 3:
                    if (iA != 4) {
                        throw oy.c("TYPE_RST_STREAM length: %d != 4", Integer.valueOf(iA));
                    }
                    if (iF == 0) {
                        throw oy.c("TYPE_RST_STREAM streamId == 0", new Object[0]);
                    }
                    int iF2 = this.d.f();
                    or orVarB = or.b(iF2);
                    if (orVarB == null) {
                        throw oy.c("TYPE_RST_STREAM unexpected error code: %d", Integer.valueOf(iF2));
                    }
                    aVar.a(iF, orVarB);
                    return true;
                case 4:
                    if (iF != 0) {
                        throw oy.c("TYPE_SETTINGS streamId != 0", new Object[0]);
                    }
                    if ((bG2 & 1) == 0) {
                        if (iA % 6 != 0) {
                            throw oy.c("TYPE_SETTINGS length %% 6 != 0: %s", Integer.valueOf(iA));
                        }
                        pb pbVar = new pb();
                        for (int i = 0; i < iA; i += 6) {
                            int i2 = this.d.i() & HPKE.aead_EXPORT_ONLY;
                            int iF3 = this.d.f();
                            if (i2 == 2) {
                                if (iF3 != 0 && iF3 != 1) {
                                    throw oy.c("PROTOCOL_ERROR SETTINGS_ENABLE_PUSH != 0 or 1", new Object[0]);
                                }
                            } else if (i2 == 3) {
                                i2 = 4;
                            } else if (i2 != 4) {
                                if (i2 == 5 && (iF3 < 16384 || iF3 > 16777215)) {
                                    throw oy.c("PROTOCOL_ERROR SETTINGS_MAX_FRAME_SIZE: %s", Integer.valueOf(iF3));
                                }
                            } else {
                                if (iF3 < 0) {
                                    throw oy.c("PROTOCOL_ERROR SETTINGS_INITIAL_WINDOW_SIZE > 2^31 - 1", new Object[0]);
                                }
                                i2 = 7;
                            }
                            pbVar.c(i2, iF3);
                        }
                        aVar.e(pbVar);
                    } else if (iA != 0) {
                        throw oy.c("FRAME_SIZE_ERROR ack frame should be empty!", new Object[0]);
                    }
                    return true;
                case 5:
                    if (iF == 0) {
                        throw oy.c("PROTOCOL_ERROR: TYPE_PUSH_PROMISE streamId == 0", new Object[0]);
                    }
                    short sG3 = (bG2 & 8) != 0 ? (short) (this.d.g() & 255) : (short) 0;
                    aVar.d(this.d.f() & Integer.MAX_VALUE, d(a(iA - 4, bG2, sG3), sG3, bG2, iF));
                    return true;
                case 6:
                    if (iA != 8) {
                        throw oy.c("TYPE_PING length != 8: %s", Integer.valueOf(iA));
                    }
                    if (iF != 0) {
                        throw oy.c("TYPE_PING streamId != 0", new Object[0]);
                    }
                    aVar.a((bG2 & 1) != 0, this.d.f(), this.d.f());
                    return true;
                case 7:
                    if (iA < 8) {
                        throw oy.c("TYPE_GOAWAY length < 8: %s", Integer.valueOf(iA));
                    }
                    if (iF != 0) {
                        throw oy.c("TYPE_GOAWAY streamId != 0", new Object[0]);
                    }
                    int iF4 = this.d.f();
                    int iF5 = this.d.f();
                    int i3 = iA - 8;
                    if (or.b(iF5) == null) {
                        throw oy.c("TYPE_GOAWAY unexpected error code: %d", Integer.valueOf(iF5));
                    }
                    qb qbVarA = qb.b;
                    if (i3 > 0) {
                        qbVarA = this.d.a(i3);
                    }
                    aVar.a(iF4, qbVarA);
                    return true;
                case 8:
                    if (iA != 4) {
                        throw oy.c("TYPE_WINDOW_UPDATE length !=4: %s", Integer.valueOf(iA));
                    }
                    long jF = ((long) this.d.f()) & 2147483647L;
                    if (jF == 0) {
                        throw oy.c("windowSizeIncrement was 0", Long.valueOf(jF));
                    }
                    aVar.c(iF, jF);
                    return true;
                default:
                    this.d.f(iA);
                    return true;
            }
        } catch (IOException unused) {
            return false;
        }
    }

    private static int a(int i, byte b2, short s) throws IOException {
        if ((b2 & 8) != 0) {
            i--;
        }
        if (s <= i) {
            return (short) (i - s);
        }
        throw oy.c("PROTOCOL_ERROR padding %s > remaining length %s", Short.valueOf(s), Integer.valueOf(i));
    }

    private List<os> d(int i, short s, byte b2, int i2) throws Throwable {
        b bVar = this.b;
        bVar.a = i;
        bVar.c = i;
        bVar.d = s;
        bVar.b = b2;
        bVar.e = i2;
        this.c.e();
        return this.c.d();
    }
}