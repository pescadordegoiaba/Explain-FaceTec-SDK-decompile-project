package com.facetec.sdk;

import java.io.IOException;

/* JADX INFO: loaded from: classes4.dex */
public final class oy {
    static final qb a = qb.d("PRI * HTTP/2.0\r\n\r\nSM\r\n\r\n");
    private static final String[] b = {"DATA", "HEADERS", "PRIORITY", "RST_STREAM", "SETTINGS", "PUSH_PROMISE", "PING", "GOAWAY", "WINDOW_UPDATE", "CONTINUATION"};
    private static String[] e = new String[64];
    private static String[] d = new String[256];

    static {
        int i = 0;
        int i2 = 0;
        while (true) {
            String[] strArr = d;
            if (i2 >= strArr.length) {
                break;
            }
            strArr[i2] = nu.b("%8s", Integer.toBinaryString(i2)).replace(' ', '0');
            i2++;
        }
        String[] strArr2 = e;
        strArr2[0] = "";
        strArr2[1] = "END_STREAM";
        int[] iArr = {1};
        strArr2[8] = "PADDED";
        for (int i3 = 0; i3 <= 0; i3++) {
            int i4 = iArr[i3];
            StringBuilder sb = new StringBuilder();
            sb.append(e[i4]);
            sb.append("|PADDED");
            e[i4 | 8] = sb.toString();
        }
        String[] strArr3 = e;
        strArr3[4] = "END_HEADERS";
        strArr3[32] = "PRIORITY";
        strArr3[36] = "END_HEADERS|PRIORITY";
        int[] iArr2 = {4, 32, 36};
        for (int i5 = 0; i5 < 3; i5++) {
            int i6 = iArr2[i5];
            for (int i7 = 0; i7 <= 0; i7++) {
                int i8 = iArr[i7];
                String[] strArr4 = e;
                int i9 = i8 | i6;
                StringBuilder sb2 = new StringBuilder();
                sb2.append(e[i8]);
                sb2.append('|');
                sb2.append(e[i6]);
                strArr4[i9] = sb2.toString();
                StringBuilder sb3 = new StringBuilder();
                sb3.append(e[i8]);
                sb3.append('|');
                sb3.append(e[i6]);
                sb3.append("|PADDED");
                e[i9 | 8] = sb3.toString();
            }
        }
        while (true) {
            String[] strArr5 = e;
            if (i >= strArr5.length) {
                return;
            }
            if (strArr5[i] == null) {
                strArr5[i] = d[i];
            }
            i++;
        }
    }

    private oy() {
    }

    public static IllegalArgumentException a(String str, Object... objArr) {
        throw new IllegalArgumentException(nu.b(str, objArr));
    }

    public static IOException c(String str, Object... objArr) throws IOException {
        throw new IOException(nu.b(str, objArr));
    }

    /* JADX WARN: Removed duplicated region for block: B:38:0x0066  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public static java.lang.String e(boolean r3, int r4, int r5, byte r6, byte r7) {
        /*
            java.lang.String[] r0 = com.facetec.sdk.oy.b
            int r1 = r0.length
            if (r6 >= r1) goto L8
            r0 = r0[r6]
            goto L16
        L8:
            java.lang.Byte r0 = java.lang.Byte.valueOf(r6)
            java.lang.Object[] r0 = new java.lang.Object[]{r0}
            java.lang.String r1 = "0x%02x"
            java.lang.String r0 = com.facetec.sdk.nu.b(r1, r0)
        L16:
            if (r7 != 0) goto L1b
            java.lang.String r6 = ""
            goto L6a
        L1b:
            r1 = 2
            if (r6 == r1) goto L66
            r1 = 3
            if (r6 == r1) goto L66
            r1 = 4
            if (r6 == r1) goto L5b
            r1 = 6
            if (r6 == r1) goto L5b
            r1 = 7
            if (r6 == r1) goto L66
            r1 = 8
            if (r6 == r1) goto L66
            java.lang.String[] r1 = com.facetec.sdk.oy.e
            int r2 = r1.length
            if (r7 >= r2) goto L36
            r1 = r1[r7]
            goto L3a
        L36:
            java.lang.String[] r1 = com.facetec.sdk.oy.d
            r1 = r1[r7]
        L3a:
            r2 = 5
            if (r6 != r2) goto L4a
            r2 = r7 & 4
            if (r2 == 0) goto L4a
            java.lang.String r6 = "HEADERS"
            java.lang.String r7 = "PUSH_PROMISE"
            java.lang.String r6 = r1.replace(r6, r7)
            goto L6a
        L4a:
            if (r6 != 0) goto L59
            r6 = r7 & 32
            if (r6 == 0) goto L59
            java.lang.String r6 = "PRIORITY"
            java.lang.String r7 = "COMPRESSED"
            java.lang.String r6 = r1.replace(r6, r7)
            goto L6a
        L59:
            r6 = r1
            goto L6a
        L5b:
            r6 = 1
            if (r7 != r6) goto L61
            java.lang.String r6 = "ACK"
            goto L6a
        L61:
            java.lang.String[] r6 = com.facetec.sdk.oy.d
            r6 = r6[r7]
            goto L6a
        L66:
            java.lang.String[] r6 = com.facetec.sdk.oy.d
            r6 = r6[r7]
        L6a:
            if (r3 == 0) goto L6f
            java.lang.String r3 = "<<"
            goto L71
        L6f:
            java.lang.String r3 = ">>"
        L71:
            java.lang.Integer r4 = java.lang.Integer.valueOf(r4)
            java.lang.Integer r5 = java.lang.Integer.valueOf(r5)
            java.lang.Object[] r3 = new java.lang.Object[]{r3, r4, r5, r0, r6}
            java.lang.String r4 = "%s 0x%08x %5d %-13s %s"
            java.lang.String r3 = com.facetec.sdk.nu.b(r4, r3)
            return r3
        */
        throw new UnsupportedOperationException("Method not decompiled: com.facetec.sdk.oy.e(boolean, int, int, byte, byte):java.lang.String");
    }
}