package com.facetec.sdk;

import com.facetec.sdk.ou;
import java.io.Closeable;
import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;

/* JADX INFO: loaded from: classes4.dex */
public final class oz implements Closeable {
    private static final Logger b = Logger.getLogger(oy.class.getName());
    private final boolean a;
    private final pu c;
    int d;
    private final px e;
    private boolean f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    private ou.c f95941g;

    public oz(pu puVar, boolean z) {
        this.c = puVar;
        this.a = z;
        px pxVar = new px();
        this.e = pxVar;
        this.f95941g = new ou.c(pxVar);
        this.d = 16384;
    }

    /* JADX WARN: Removed duplicated region for block: B:30:0x007e  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public final synchronized void a(boolean r18, int r19, java.util.List<com.facetec.sdk.os> r20) {
        /*
            Method dump skipped, instruction units count: 357
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: com.facetec.sdk.oz.a(boolean, int, java.util.List):void");
    }

    public final synchronized void c() {
        try {
            if (this.f) {
                throw new IOException("closed");
            }
            if (this.a) {
                Logger logger = b;
                if (logger.isLoggable(Level.FINE)) {
                    logger.fine(nu.b(">> CONNECTION %s", oy.a.e()));
                }
                this.c.d(oy.a.i());
                this.c.flush();
            }
        } catch (Throwable th) {
            throw th;
        }
    }

    @Override // java.io.Closeable, java.lang.AutoCloseable
    public final synchronized void close() {
        this.f = true;
        this.c.close();
    }

    public final synchronized void d() {
        if (this.f) {
            throw new IOException("closed");
        }
        this.c.flush();
    }

    public final synchronized void e(pb pbVar) {
        try {
            if (this.f) {
                throw new IOException("closed");
            }
            int i = this.d;
            if ((pbVar.b & 32) != 0) {
                i = pbVar.a[5];
            }
            this.d = i;
            if (pbVar.b() != -1) {
                ou.c cVar = this.f95941g;
                int iB = pbVar.b();
                cVar.a = iB;
                int iMin = Math.min(iB, 16384);
                int i2 = cVar.d;
                if (i2 != iMin) {
                    if (iMin < i2) {
                        cVar.c = Math.min(cVar.c, iMin);
                    }
                    cVar.b = true;
                    cVar.d = iMin;
                    int i3 = cVar.f;
                    if (iMin < i3) {
                        if (iMin == 0) {
                            cVar.a();
                        } else {
                            cVar.e(i3 - iMin);
                        }
                    }
                }
            }
            c(0, 0, (byte) 4, (byte) 1);
            this.c.flush();
        } catch (Throwable th) {
            throw th;
        }
    }

    public final synchronized void d(boolean z, int i, int i2) {
        if (!this.f) {
            c(0, 8, (byte) 6, z ? (byte) 1 : (byte) 0);
            this.c.h(i);
            this.c.h(i2);
            this.c.flush();
        } else {
            throw new IOException("closed");
        }
    }

    public final synchronized void c(pb pbVar) {
        try {
            if (!this.f) {
                int i = 0;
                c(0, Integer.bitCount(pbVar.b) * 6, (byte) 4, (byte) 0);
                while (i < 10) {
                    if (pbVar.b(i)) {
                        this.c.f(i == 4 ? 3 : i == 7 ? 4 : i);
                        this.c.h(pbVar.d(i));
                    }
                    i++;
                }
                this.c.flush();
            } else {
                throw new IOException("closed");
            }
        } catch (Throwable th) {
            throw th;
        }
    }

    public final synchronized void d(int i, long j) {
        if (this.f) {
            throw new IOException("closed");
        }
        if (j != 0 && j <= 2147483647L) {
            c(i, 4, (byte) 8, (byte) 0);
            this.c.h((int) j);
            this.c.flush();
        } else {
            throw oy.a("windowSizeIncrement == 0 || windowSizeIncrement > 0x7fffffffL: %s", Long.valueOf(j));
        }
    }

    private void c(int i, int i2, byte b2, byte b3) {
        Logger logger = b;
        if (logger.isLoggable(Level.FINE)) {
            logger.fine(oy.e(false, i, i2, b2, b3));
        }
        int i3 = this.d;
        if (i2 > i3) {
            throw oy.a("FRAME_SIZE_ERROR length > %d: %d", Integer.valueOf(i3), Integer.valueOf(i2));
        }
        if ((Integer.MIN_VALUE & i) == 0) {
            a(this.c, i2);
            this.c.g(b2 & 255);
            this.c.g(b3 & 255);
            this.c.h(i & Integer.MAX_VALUE);
            return;
        }
        throw oy.a("reserved bit set: %s", Integer.valueOf(i));
    }

    public final synchronized void e(boolean z, int i, px pxVar, int i2) {
        if (!this.f) {
            c(i, i2, (byte) 0, z ? (byte) 1 : (byte) 0);
            if (i2 > 0) {
                this.c.a(pxVar, i2);
            }
        } else {
            throw new IOException("closed");
        }
    }

    public final synchronized void a(int i, or orVar) {
        if (!this.f) {
            if (orVar.f95934g != -1) {
                c(i, 4, (byte) 3, (byte) 0);
                this.c.h(orVar.f95934g);
                this.c.flush();
            } else {
                throw new IllegalArgumentException();
            }
        } else {
            throw new IOException("closed");
        }
    }

    public final synchronized void a(int i, or orVar, byte[] bArr) {
        try {
            if (!this.f) {
                if (orVar.f95934g != -1) {
                    c(0, bArr.length + 8, (byte) 7, (byte) 0);
                    this.c.h(i);
                    this.c.h(orVar.f95934g);
                    if (bArr.length > 0) {
                        this.c.d(bArr);
                    }
                    this.c.flush();
                } else {
                    throw oy.a("errorCode.httpCode == -1", new Object[0]);
                }
            } else {
                throw new IOException("closed");
            }
        } catch (Throwable th) {
            throw th;
        }
    }

    private static void a(pu puVar, int i) {
        puVar.g((i >>> 16) & 255);
        puVar.g((i >>> 8) & 255);
        puVar.g(i & 255);
    }
}