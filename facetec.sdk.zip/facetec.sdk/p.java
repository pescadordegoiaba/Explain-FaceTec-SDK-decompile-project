package com.facetec.sdk;

import java.util.ArrayList;

/* JADX INFO: loaded from: classes4.dex */
public final class p extends gu<ArrayList<String>> {
}