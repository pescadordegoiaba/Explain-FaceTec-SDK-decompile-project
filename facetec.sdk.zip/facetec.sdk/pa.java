package com.facetec.sdk;

import android.graphics.Color;
import android.media.AudioTrack;
import android.os.Process;
import android.os.SystemClock;
import android.view.KeyEvent;
import android.view.View;
import android.view.ViewConfiguration;
import android.widget.ExpandableListView;
import com.facetec.sdk.os;
import com.incode.welcome_sdk.modules.SelfieScan;
import com.plaid.internal.EnumC41897g;
import java.io.IOException;
import java.io.InterruptedIOException;
import java.lang.reflect.Method;
import java.net.SocketTimeoutException;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Deque;
import java.util.concurrent.RejectedExecutionException;
import net.sf.scuba.smartcards.ISO7816;
import org.jmrtd.lds.CVCAFile;

/* JADX INFO: loaded from: classes4.dex */
public final class pa {
    static final /* synthetic */ boolean m = true;
    long a;
    long b = 0;
    final ov c;
    final int d;
    final Deque<mz> e;
    final d f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    final d f95942g;
    boolean h;
    final e i;
    final a j;
    private os.b k;
    or n;

    public class d extends pw {
        private static final byte[] $$a = null;
        private static final int $$b = 0;
        private static long a;
        private static int c;
        private static char i;

        /* JADX WARN: Removed duplicated region for block: B:10:0x0026  */
        /* JADX WARN: Removed duplicated region for block: B:8:0x0020  */
        /* JADX WARN: Unsupported multi-entry loop pattern (BACK_EDGE: B:10:0x0026 -> B:11:0x002e). Please report as a decompilation issue!!! */
        /*
            Code decompiled incorrectly, please refer to instructions dump.
            To view partially-correct code enable 'Show inconsistent code' option in preferences
        */
        private static java.lang.String $$c(byte r6, short r7, short r8) {
            /*
                int r7 = r7 * 2
                int r7 = 1 - r7
                int r8 = r8 * 7
                int r8 = 104 - r8
                int r6 = r6 * 4
                int r6 = r6 + 4
                byte[] r0 = com.facetec.sdk.pa.d.$$a
                byte[] r1 = new byte[r7]
                r2 = 0
                if (r0 != 0) goto L18
                r3 = r0
                r4 = r2
                r0 = r8
                r8 = r6
                goto L2e
            L18:
                r3 = r2
            L19:
                byte r4 = (byte) r8
                r1[r3] = r4
                int r3 = r3 + 1
                if (r3 != r7) goto L26
                java.lang.String r6 = new java.lang.String
                r6.<init>(r1, r2)
                return r6
            L26:
                r4 = r0[r6]
                r5 = r8
                r8 = r6
                r6 = r4
                r4 = r3
                r3 = r0
                r0 = r5
            L2e:
                int r6 = -r6
                int r8 = r8 + 1
                int r6 = r6 + r0
                r0 = r8
                r8 = r6
                r6 = r0
                r0 = r3
                r3 = r4
                goto L19
            */
            throw new UnsupportedOperationException("Method not decompiled: com.facetec.sdk.pa.d.$$c(byte, short, short):java.lang.String");
        }

        static {
            init$0();
            a = 1396024866991524551L;
            c = 1453607623;
            i = (char) 25935;
        }

        public d() {
        }

        private static void g(char c2, String str, int i2, String str2, String str3, Object[] objArr) throws Throwable {
            int i3;
            int i4;
            char c3;
            char[] charArray = str3 != null ? str3.toCharArray() : str3;
            char[] charArray2 = str2 != null ? str2.toCharArray() : str2;
            char[] charArray3 = str != null ? str.toCharArray() : str;
            hi hiVar = new hi();
            int length = charArray3.length;
            char[] cArr = new char[length];
            int length2 = charArray2.length;
            char[] cArr2 = new char[length2];
            int i5 = 0;
            System.arraycopy(charArray3, 0, cArr, 0, length);
            System.arraycopy(charArray2, 0, cArr2, 0, length2);
            cArr[0] = (char) (cArr[0] ^ c2);
            int i6 = 2;
            cArr2[2] = (char) (cArr2[2] + ((char) i2));
            int length3 = charArray.length;
            char[] cArr3 = new char[length3];
            hiVar.d = 0;
            while (hiVar.d < length3) {
                try {
                    Object[] objArr2 = {hiVar};
                    Object objD = an.d(1217746441);
                    if (objD == null) {
                        objD = an.d((Process.myPid() >> 22) + EnumC41897g.SDK_ASSET_ICON_PRODUCT_IDV_VALUE, (char) (63338 - View.resolveSize(i5, i5)), 25 - (ViewConfiguration.getScrollFriction() > SelfieScan.RECOGNITION_FAIL_RESULT ? 1 : (ViewConfiguration.getScrollFriction() == SelfieScan.RECOGNITION_FAIL_RESULT ? 0 : -1)), 1056212306, false, "b", new Class[]{Object.class});
                    }
                    int iIntValue = ((Integer) ((Method) objD).invoke(null, objArr2)).intValue();
                    Object[] objArr3 = {hiVar};
                    Object objD2 = an.d(1379992360);
                    if (objD2 == null) {
                        byte b = (byte) i5;
                        i3 = i6;
                        byte b2 = b;
                        i4 = i5;
                        objD2 = an.d(688 - View.resolveSizeAndState(i5, i5, i5), (char) (33107 - (Process.myPid() >> 22)), 23 - View.resolveSizeAndState(i5, i5, i5), 606130291, false, $$c(b, b2, (byte) (b2 + 1)), new Class[]{Object.class});
                    } else {
                        i3 = i6;
                        i4 = i5;
                    }
                    int iIntValue2 = ((Integer) ((Method) objD2).invoke(null, objArr3)).intValue();
                    int i7 = cArr[hiVar.d % 4] * 32718;
                    Object[] objArr4 = new Object[3];
                    objArr4[i3] = Integer.valueOf(cArr2[iIntValue]);
                    objArr4[1] = Integer.valueOf(i7);
                    objArr4[i4] = hiVar;
                    Object objD3 = an.d(-1522168148);
                    Class cls = Integer.TYPE;
                    if (objD3 == null) {
                        int i8 = i4;
                        int iCombineMeasuredStates = 1304 - View.combineMeasuredStates(i8, i8);
                        char maxKeyCode = (char) (KeyEvent.getMaxKeyCode() >> 16);
                        int iRgb = (-16777192) - Color.rgb(i8, i8, i8);
                        c3 = 1;
                        byte b3 = (byte) i8;
                        byte b4 = b3;
                        objD3 = an.d(iCombineMeasuredStates, maxKeyCode, iRgb, -752591369, false, $$c(b3, b4, b4), new Class[]{Object.class, cls, cls});
                    } else {
                        c3 = 1;
                    }
                    ((Method) objD3).invoke(null, objArr4);
                    int i9 = cArr[iIntValue2] * 32718;
                    int i10 = i3;
                    Object[] objArr5 = new Object[i10];
                    objArr5[c3] = Integer.valueOf(cArr2[iIntValue]);
                    objArr5[0] = Integer.valueOf(i9);
                    Object objD4 = an.d(-1578548222);
                    if (objD4 == null) {
                        objD4 = an.d(1970 - View.MeasureSpec.getMode(0), (char) (KeyEvent.getMaxKeyCode() >> 16), 24 - ExpandableListView.getPackedPositionGroup(0L), -678914215, false, "i", new Class[]{cls, cls});
                    }
                    cArr2[iIntValue2] = ((Character) ((Method) objD4).invoke(null, objArr5)).charValue();
                    cArr[iIntValue2] = hiVar.e;
                    int i11 = hiVar.d;
                    cArr3[i11] = (char) (((((long) (r6 ^ charArray[i11])) ^ (a ^ 1396024866991524551L)) ^ ((long) ((int) (((long) c) ^ 1396024866991524551L)))) ^ ((long) ((char) (((long) i) ^ 1396024866991524551L))));
                    hiVar.d = i11 + 1;
                    i6 = i10;
                    i5 = 0;
                } catch (Throwable th) {
                    Throwable cause = th.getCause();
                    if (cause == null) {
                        throw th;
                    }
                    throw cause;
                }
            }
            objArr[0] = new String(cArr3);
        }

        public static void init$0() {
            $$a = new byte[]{ISO7816.INS_DECREASE, ISO7816.INS_UPDATE_BINARY, CVCAFile.CAR_TAG, -37};
            $$b = 14;
        }

        public final void a() throws IOException {
            if (c()) {
                throw b(null);
            }
        }

        @Override // com.facetec.sdk.pw
        public final IOException b(IOException iOException) {
            SocketTimeoutException socketTimeoutException = new SocketTimeoutException("timeout");
            if (iOException != null) {
                socketTimeoutException.initCause(iOException);
            }
            return socketTimeoutException;
        }

        @Override // com.facetec.sdk.pw
        public final void d() {
            pa.this.e(or.CANCEL);
            final ov ovVar = pa.this.c;
            synchronized (ovVar) {
                try {
                    long j = ovVar.i;
                    long j2 = ovVar.j;
                    if (j < j2) {
                        return;
                    }
                    ovVar.j = j2 + 1;
                    try {
                        Object[] objArr = new Object[1];
                        g((char) (6973 - (SystemClock.uptimeMillis() > 0L ? 1 : (SystemClock.uptimeMillis() == 0L ? 0 : -1))), "碽玮㲛堛", (AudioTrack.getMinVolume() > SelfieScan.RECOGNITION_FAIL_RESULT ? 1 : (AudioTrack.getMinVolume() == SelfieScan.RECOGNITION_FAIL_RESULT ? 0 : -1)), "\u0000\u0000\u0000\u0000", "涙\ue229홖\uf103竜\uf4e7控\uda9a매䘮\uda76贫㵕昹颅\uf21b", objArr);
                        Class<?> cls = Class.forName((String) objArr[0]);
                        Object[] objArr2 = new Object[1];
                        g((char) (ExpandableListView.getPackedPositionForGroup(0) > 0L ? 1 : (ExpandableListView.getPackedPositionForGroup(0) == 0L ? 0 : -1)), "雘论⒄㠧", KeyEvent.keyCodeFromString(""), "\u0000\u0000\u0000\u0000", "\ufaf8㢟ᐧ㾫ꜹ獩쫥ટ", objArr2);
                        ovVar.m = ((Long) cls.getMethod((String) objArr2[0], null).invoke(null, null)).longValue() + 1000000000;
                        try {
                            ovVar.f.execute(new np("OkHttp %s ping", ovVar.d) { // from class: com.facetec.sdk.ov.1
                                public AnonymousClass1(String str, Object... objArr3) {
                                    super(str, objArr3);
                                }

                                @Override // com.facetec.sdk.np
                                public final void c() {
                                    ov.this.c(false, 2, 0);
                                }
                            });
                        } catch (RejectedExecutionException unused) {
                        }
                    } catch (Throwable th) {
                        Throwable cause = th.getCause();
                        if (cause == null) {
                            throw th;
                        }
                        throw cause;
                    }
                } catch (Throwable th2) {
                    throw th2;
                }
            }
        }
    }

    public final class e implements ql {
        static /* synthetic */ boolean h = true;
        boolean a;
        final long b;
        final px c = new px();
        final px d = new px();
        boolean e;

        public e(long j) {
            this.b = j;
        }

        @Override // com.facetec.sdk.ql
        public final qp a() {
            return pa.this.f;
        }

        public void c(long j) {
            if (!h && Thread.holdsLock(pa.this)) {
                throw new AssertionError();
            }
            pa.this.c.d(j);
        }

        @Override // com.facetec.sdk.ql, java.io.Closeable, java.lang.AutoCloseable
        public final void close() {
            long jE;
            ArrayList<mz> arrayList;
            os.b bVar;
            synchronized (pa.this) {
                try {
                    this.e = true;
                    jE = this.d.e();
                    this.d.q();
                    if (pa.this.e.isEmpty() || pa.this.k == null) {
                        arrayList = null;
                        bVar = null;
                    } else {
                        arrayList = new ArrayList(pa.this.e);
                        pa.this.e.clear();
                        bVar = pa.this.k;
                    }
                    pa.this.notifyAll();
                } catch (Throwable th) {
                    throw th;
                }
            }
            if (jE > 0) {
                c(jE);
            }
            pa.this.f();
            if (bVar != null) {
                for (mz mzVar : arrayList) {
                }
            }
        }

        @Override // com.facetec.sdk.ql
        public final long e(px pxVar, long j) throws pi {
            or orVar;
            long jE;
            long j2;
            mz mzVar;
            os.b bVar;
            if (j < 0) {
                throw new IllegalArgumentException("byteCount < 0: ".concat(String.valueOf(j)));
            }
            while (true) {
                synchronized (pa.this) {
                    try {
                        pa.this.f.b();
                        try {
                            pa paVar = pa.this;
                            orVar = paVar.n;
                            if (orVar == null) {
                                orVar = null;
                            }
                            if (this.e) {
                                throw new IOException("stream closed");
                            }
                            if (paVar.e.isEmpty() || pa.this.k == null) {
                                if (this.d.e() > 0) {
                                    px pxVar2 = this.d;
                                    jE = pxVar2.e(pxVar, Math.min(j, pxVar2.e()));
                                    pa paVar2 = pa.this;
                                    long j3 = paVar2.b + jE;
                                    paVar2.b = j3;
                                    if (orVar == null) {
                                        j2 = -1;
                                        if (j3 >= paVar2.c.k.c() / 2) {
                                            pa paVar3 = pa.this;
                                            paVar3.c.c(paVar3.d, paVar3.b);
                                            pa.this.b = 0L;
                                        }
                                    } else {
                                        j2 = -1;
                                    }
                                } else {
                                    j2 = -1;
                                    if (this.a || orVar != null) {
                                        jE = -1;
                                    } else {
                                        pa.this.j();
                                        pa.this.f.a();
                                    }
                                }
                                mzVar = null;
                                bVar = null;
                            } else {
                                mzVar = (mz) pa.this.e.removeFirst();
                                bVar = pa.this.k;
                                jE = -1;
                                j2 = -1;
                            }
                            if (mzVar == null || bVar == null) {
                                break;
                            }
                        } finally {
                            pa.this.f.a();
                        }
                    } catch (Throwable th) {
                        throw th;
                    }
                }
            }
            if (jE != j2) {
                c(jE);
                return jE;
            }
            if (orVar == null) {
                return j2;
            }
            throw new pi(orVar);
        }
    }

    public pa(int i, ov ovVar, boolean z, boolean z2, mz mzVar) {
        ArrayDeque arrayDeque = new ArrayDeque();
        this.e = arrayDeque;
        this.f = new d();
        this.f95942g = new d();
        this.n = null;
        if (ovVar == null) {
            throw new NullPointerException("connection == null");
        }
        this.d = i;
        this.c = ovVar;
        this.a = ovVar.l.c();
        e eVar = new e(ovVar.k.c());
        this.i = eVar;
        a aVar = new a();
        this.j = aVar;
        eVar.a = z2;
        aVar.e = z;
        if (mzVar != null) {
            arrayDeque.add(mzVar);
        }
        if (a() && mzVar != null) {
            throw new IllegalStateException("locally-initiated streams shouldn't have headers yet");
        }
        if (!a() && mzVar == null) {
            throw new IllegalStateException("remotely-initiated streams should have headers");
        }
    }

    public final boolean a() {
        return this.c.a == ((this.d & 1) == 1);
    }

    public final int b() {
        return this.d;
    }

    public final qj e() {
        synchronized (this) {
            try {
                if (!this.h && !a()) {
                    throw new IllegalStateException("reply before requesting the sink");
                }
            } catch (Throwable th) {
                throw th;
            }
        }
        return this.j;
    }

    /* JADX WARN: Removed duplicated region for block: B:22:0x002b  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public final void f() {
        /*
            r2 = this;
            boolean r0 = com.facetec.sdk.pa.m
            if (r0 != 0) goto L11
            boolean r0 = java.lang.Thread.holdsLock(r2)
            if (r0 != 0) goto Lb
            goto L11
        Lb:
            java.lang.AssertionError r0 = new java.lang.AssertionError
            r0.<init>()
            throw r0
        L11:
            monitor-enter(r2)
            com.facetec.sdk.pa$e r0 = r2.i     // Catch: java.lang.Throwable -> L27
            boolean r1 = r0.a     // Catch: java.lang.Throwable -> L27
            if (r1 != 0) goto L2b
            boolean r0 = r0.e     // Catch: java.lang.Throwable -> L27
            if (r0 == 0) goto L2b
            com.facetec.sdk.pa$a r0 = r2.j     // Catch: java.lang.Throwable -> L27
            boolean r1 = r0.e     // Catch: java.lang.Throwable -> L27
            if (r1 != 0) goto L29
            boolean r0 = r0.b     // Catch: java.lang.Throwable -> L27
            if (r0 == 0) goto L2b
            goto L29
        L27:
            r0 = move-exception
            goto L43
        L29:
            r0 = 1
            goto L2c
        L2b:
            r0 = 0
        L2c:
            boolean r1 = r2.c()     // Catch: java.lang.Throwable -> L27
            monitor-exit(r2)     // Catch: java.lang.Throwable -> L27
            if (r0 == 0) goto L39
            com.facetec.sdk.or r0 = com.facetec.sdk.or.CANCEL
            r2.b(r0)
            return
        L39:
            if (r1 != 0) goto L42
            com.facetec.sdk.ov r0 = r2.c
            int r1 = r2.d
            r0.c(r1)
        L42:
            return
        L43:
            monitor-exit(r2)
            throw r0
        */
        throw new UnsupportedOperationException("Method not decompiled: com.facetec.sdk.pa.f():void");
    }

    public final void h() throws IOException {
        a aVar = this.j;
        if (aVar.b) {
            throw new IOException("stream closed");
        }
        if (aVar.e) {
            throw new IOException("stream finished");
        }
        if (this.n != null) {
            throw new pi(this.n);
        }
    }

    public final void i() {
        boolean zC;
        if (!m && Thread.holdsLock(this)) {
            throw new AssertionError();
        }
        synchronized (this) {
            this.i.a = true;
            zC = c();
            notifyAll();
        }
        if (zC) {
            return;
        }
        this.c.c(this.d);
    }

    public final void j() throws InterruptedIOException {
        try {
            wait();
        } catch (InterruptedException unused) {
            Thread.currentThread().interrupt();
            throw new InterruptedIOException();
        }
    }

    public final void b(or orVar) {
        if (d(orVar)) {
            this.c.c(this.d, orVar);
        }
    }

    public final synchronized boolean c() {
        try {
            if (this.n != null) {
                return false;
            }
            e eVar = this.i;
            if (eVar.a || eVar.e) {
                a aVar = this.j;
                if (aVar.e || aVar.b) {
                    if (this.h) {
                        return false;
                    }
                }
            }
            return true;
        } catch (Throwable th) {
            throw th;
        }
    }

    public final synchronized mz d() {
        this.f.b();
        while (this.e.isEmpty() && this.n == null) {
            try {
                j();
            } catch (Throwable th) {
                this.f.a();
                throw th;
            }
        }
        this.f.a();
        if (this.e.isEmpty()) {
            throw new pi(this.n);
        }
        return this.e.removeFirst();
    }

    public final synchronized void a(or orVar) {
        if (this.n == null) {
            this.n = orVar;
            notifyAll();
        }
    }

    public final class a implements qj {
        private static /* synthetic */ boolean c = true;
        private final px a = new px();
        boolean b;
        boolean e;

        public a() {
        }

        @Override // com.facetec.sdk.qj
        public final void a(px pxVar, long j) throws Throwable {
            if (!c && Thread.holdsLock(pa.this)) {
                throw new AssertionError();
            }
            this.a.a(pxVar, j);
            while (this.a.e() >= 16384) {
                a(false);
            }
        }

        @Override // com.facetec.sdk.qj, java.io.Closeable, java.lang.AutoCloseable
        public final void close() throws IOException {
            if (!c && Thread.holdsLock(pa.this)) {
                throw new AssertionError();
            }
            synchronized (pa.this) {
                if (this.b) {
                    return;
                }
                if (!pa.this.j.e) {
                    if (this.a.e() > 0) {
                        while (this.a.e() > 0) {
                            a(true);
                        }
                    } else {
                        pa paVar = pa.this;
                        paVar.c.e(paVar.d, true, null, 0L);
                    }
                }
                synchronized (pa.this) {
                    this.b = true;
                }
                pa.this.c.b();
                pa.this.f();
            }
        }

        @Override // com.facetec.sdk.qj, java.io.Flushable
        public final void flush() throws IOException {
            if (!c && Thread.holdsLock(pa.this)) {
                throw new AssertionError();
            }
            synchronized (pa.this) {
                pa.this.h();
            }
            while (this.a.e() > 0) {
                a(false);
                pa.this.c.b();
            }
        }

        private void a(boolean z) throws IOException {
            pa paVar;
            long jMin;
            pa paVar2;
            synchronized (pa.this) {
                pa.this.f95942g.b();
                while (true) {
                    try {
                        paVar = pa.this;
                        if (paVar.a > 0 || this.e || this.b || paVar.n != null) {
                            break;
                        } else {
                            paVar.j();
                        }
                    } finally {
                        pa.this.f95942g.a();
                    }
                }
                paVar.f95942g.a();
                pa.this.h();
                jMin = Math.min(pa.this.a, this.a.e());
                paVar2 = pa.this;
                paVar2.a -= jMin;
            }
            paVar2.f95942g.b();
            try {
                pa paVar3 = pa.this;
                paVar3.c.e(paVar3.d, z && jMin == this.a.e(), this.a, jMin);
                pa.this.f95942g.a();
            } catch (Throwable th) {
                throw th;
            }
        }

        @Override // com.facetec.sdk.qj
        public final qp a() {
            return pa.this.f95942g;
        }
    }

    public final void c(long j) {
        this.a += j;
        if (j > 0) {
            notifyAll();
        }
    }

    public final void e(or orVar) {
        if (d(orVar)) {
            this.c.e(this.d, orVar);
        }
    }

    private boolean d(or orVar) {
        if (!m && Thread.holdsLock(this)) {
            throw new AssertionError();
        }
        synchronized (this) {
            try {
                if (this.n != null) {
                    return false;
                }
                if (this.i.a && this.j.e) {
                    return false;
                }
                this.n = orVar;
                notifyAll();
                this.c.c(this.d);
                return true;
            } catch (Throwable th) {
                throw th;
            }
        }
    }
}