package com.facetec.sdk;

import org.bouncycastle.crypto.digests.Blake2xsDigest;

/* JADX INFO: loaded from: classes4.dex */
public final class pb {
    final int[] a = new int[10];
    int b;

    public final boolean b(int i) {
        return ((1 << i) & this.b) != 0;
    }

    public final pb c(int i, int i2) {
        if (i >= 0) {
            int[] iArr = this.a;
            if (i < iArr.length) {
                this.b = (1 << i) | this.b;
                iArr[i] = i2;
            }
        }
        return this;
    }

    public final int d(int i) {
        return this.a[i];
    }

    public final int b() {
        if ((this.b & 2) != 0) {
            return this.a[1];
        }
        return -1;
    }

    public final int c() {
        return (this.b & 128) != 0 ? this.a[7] : Blake2xsDigest.UNKNOWN_DIGEST_LENGTH;
    }
}