package com.facetec.sdk;

/* JADX INFO: loaded from: classes4.dex */
public interface pd {
    public static final pd d = new pd() { // from class: com.facetec.sdk.pd.1
        @Override // com.facetec.sdk.pd
        public final boolean e(pz pzVar, int i) {
            pzVar.f(i);
            return true;
        }
    };

    boolean e(pz pzVar, int i);
}