package com.facetec.sdk;

import java.security.NoSuchAlgorithmException;
import java.security.Provider;
import java.util.List;
import javax.net.ssl.SSLContext;
import javax.net.ssl.SSLSocket;
import javax.net.ssl.SSLSocketFactory;
import org.conscrypt.Conscrypt;

/* JADX INFO: loaded from: classes4.dex */
public final class pe extends pm {
    private pe() {
    }

    private static Provider d() {
        return Conscrypt.newProviderBuilder().provideTrustManager().build();
    }

    @Override // com.facetec.sdk.pm
    public final String b(SSLSocket sSLSocket) {
        return Conscrypt.isConscrypt(sSLSocket) ? Conscrypt.getApplicationProtocol(sSLSocket) : super.b(sSLSocket);
    }

    @Override // com.facetec.sdk.pm
    public final SSLContext c() {
        try {
            return SSLContext.getInstance("TLSv1.3", d());
        } catch (NoSuchAlgorithmException e) {
            try {
                return SSLContext.getInstance("TLS", d());
            } catch (NoSuchAlgorithmException unused) {
                throw new IllegalStateException("No TLS provider", e);
            }
        }
    }

    @Override // com.facetec.sdk.pm
    public final void e(SSLSocketFactory sSLSocketFactory) {
        if (Conscrypt.isConscrypt(sSLSocketFactory)) {
            Conscrypt.setUseEngineSocket(sSLSocketFactory, true);
        }
    }

    @Override // com.facetec.sdk.pm
    public final void d(SSLSocket sSLSocket, String str, List<ng> list) {
        if (!Conscrypt.isConscrypt(sSLSocket)) {
            super.d(sSLSocket, str, list);
            return;
        }
        if (str != null) {
            Conscrypt.setUseSessionTickets(sSLSocket, true);
            Conscrypt.setHostname(sSLSocket, str);
        }
        Conscrypt.setApplicationProtocols(sSLSocket, (String[]) pm.a(list).toArray(new String[0]));
    }

    public static pe b() {
        try {
            Class.forName("org.conscrypt.Conscrypt");
            if (Conscrypt.isAvailable()) {
                return new pe();
            }
            return null;
        } catch (ClassNotFoundException unused) {
            return null;
        }
    }
}