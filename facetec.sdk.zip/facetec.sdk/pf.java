package com.facetec.sdk;

import android.annotation.SuppressLint;
import android.net.ssl.SSLSockets;
import java.io.IOException;
import java.util.List;
import javax.net.ssl.SSLParameters;
import javax.net.ssl.SSLSocket;
import org.codehaus.mojo.animal_sniffer.IgnoreJRERequirement;

/* JADX INFO: loaded from: classes4.dex */
@SuppressLint({"NewApi"})
final class pf extends pg {
    private pf(Class<?> cls) {
        super(cls, null, null, null, null);
    }

    public static pm d() {
        if (!pm.f()) {
            return null;
        }
        try {
            if (pg.b() >= 29) {
                return new pf(Class.forName("com.android.org.conscrypt.SSLParametersImpl"));
            }
        } catch (ClassNotFoundException unused) {
        }
        return null;
    }

    @Override // com.facetec.sdk.pg, com.facetec.sdk.pm
    @IgnoreJRERequirement
    public final String b(SSLSocket sSLSocket) {
        String applicationProtocol = sSLSocket.getApplicationProtocol();
        if (applicationProtocol == null || applicationProtocol.isEmpty()) {
            return null;
        }
        return applicationProtocol;
    }

    @Override // com.facetec.sdk.pg, com.facetec.sdk.pm
    @SuppressLint({"NewApi"})
    @IgnoreJRERequirement
    public final void d(SSLSocket sSLSocket, String str, List<ng> list) throws IOException {
        try {
            if (SSLSockets.isSupportedSocket(sSLSocket)) {
                SSLSockets.setUseSessionTickets(sSLSocket, true);
            }
            SSLParameters sSLParameters = sSLSocket.getSSLParameters();
            sSLParameters.setApplicationProtocols((String[]) pm.a(list).toArray(new String[0]));
            sSLSocket.setSSLParameters(sSLParameters);
        } catch (IllegalArgumentException e) {
            throw new IOException("Android internal error", e);
        }
    }
}