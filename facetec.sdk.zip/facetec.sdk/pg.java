package com.facetec.sdk;

import android.os.Build;
import android.util.Log;
import java.io.IOException;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.security.NoSuchAlgorithmException;
import java.security.Security;
import java.security.cert.Certificate;
import java.security.cert.TrustAnchor;
import java.security.cert.X509Certificate;
import java.util.List;
import javax.net.ssl.SSLContext;
import javax.net.ssl.SSLPeerUnverifiedException;
import javax.net.ssl.SSLSocket;
import javax.net.ssl.X509TrustManager;

/* JADX INFO: loaded from: classes4.dex */
class pg extends pm {
    private final Class<?> a;
    private final pl<Socket> b;
    private final pl<Socket> c;
    private final pl<Socket> d;
    private final pl<Socket> e;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    private final a f95944g = a.d();

    public static final class a {
        public static int d;
        public static int e;
        private final Method a;
        private final Method b;
        private final Method c;

        private a(Method method, Method method2, Method method3) {
            this.a = method;
            this.b = method2;
            this.c = method3;
        }

        public static int a() {
            int i = e;
            int i2 = i % 8060172;
            e = i + 1;
            if (i2 != 0) {
                return d;
            }
            int iMaxMemory = (int) Runtime.getRuntime().maxMemory();
            d = iMaxMemory;
            return iMaxMemory;
        }

        public static a d() throws NoSuchMethodException {
            Method method;
            Method method2;
            Method method3 = null;
            try {
                Class<?> cls = Class.forName("dalvik.system.CloseGuard");
                Method method4 = cls.getMethod("get", null);
                method2 = cls.getMethod("open", String.class);
                method = cls.getMethod("warnIfOpen", null);
                method3 = method4;
            } catch (Exception unused) {
                method = null;
                method2 = null;
            }
            return new a(method3, method2, method);
        }

        public final Object b(String str) {
            Method method = this.a;
            if (method != null) {
                try {
                    Object objInvoke = method.invoke(null, null);
                    this.b.invoke(objInvoke, str);
                    return objInvoke;
                } catch (Exception unused) {
                }
            }
            return null;
        }

        public final boolean e(Object obj) {
            if (obj == null) {
                return false;
            }
            try {
                this.c.invoke(obj, null);
                return true;
            } catch (Exception unused) {
                return false;
            }
        }
    }

    public static final class b implements pt {
        private final Method b;
        private final X509TrustManager c;

        public b(X509TrustManager x509TrustManager, Method method) {
            this.b = method;
            this.c = x509TrustManager;
        }

        @Override // com.facetec.sdk.pt
        public final X509Certificate d(X509Certificate x509Certificate) {
            try {
                TrustAnchor trustAnchor = (TrustAnchor) this.b.invoke(this.c, x509Certificate);
                if (trustAnchor != null) {
                    return trustAnchor.getTrustedCert();
                }
            } catch (IllegalAccessException e) {
                throw nu.e("unable to get issues and signature", e);
            } catch (InvocationTargetException unused) {
            }
            return null;
        }

        public final boolean equals(Object obj) {
            if (obj == this) {
                return true;
            }
            if (!(obj instanceof b)) {
                return false;
            }
            b bVar = (b) obj;
            return this.c.equals(bVar.c) && this.b.equals(bVar.b);
        }

        public final int hashCode() {
            return this.c.hashCode() + (this.b.hashCode() * 31);
        }
    }

    public static final class c extends po {
        private final Method a;
        private final Object c;

        public c(Object obj, Method method) {
            this.c = obj;
            this.a = method;
        }

        @Override // com.facetec.sdk.po
        public final List<Certificate> a(List<Certificate> list, String str) throws SSLPeerUnverifiedException {
            try {
                return (List) this.a.invoke(this.c, (X509Certificate[]) list.toArray(new X509Certificate[list.size()]), "RSA", str);
            } catch (IllegalAccessException e) {
                throw new AssertionError(e);
            } catch (InvocationTargetException e2) {
                SSLPeerUnverifiedException sSLPeerUnverifiedException = new SSLPeerUnverifiedException(e2.getMessage());
                sSLPeerUnverifiedException.initCause(e2);
                throw sSLPeerUnverifiedException;
            }
        }

        public final boolean equals(Object obj) {
            return obj instanceof c;
        }

        public final int hashCode() {
            return 0;
        }
    }

    public pg(Class<?> cls, pl<Socket> plVar, pl<Socket> plVar2, pl<Socket> plVar3, pl<Socket> plVar4) {
        this.a = cls;
        this.b = plVar;
        this.d = plVar2;
        this.e = plVar3;
        this.c = plVar4;
    }

    private boolean c(String str, Class<?> cls, Object obj) {
        try {
            return ((Boolean) cls.getMethod("isCleartextTrafficPermitted", String.class).invoke(obj, str)).booleanValue();
        } catch (NoSuchMethodException unused) {
            return a(str, cls, obj);
        }
    }

    @Override // com.facetec.sdk.pm
    public final void a(Socket socket, InetSocketAddress inetSocketAddress, int i) throws IOException {
        try {
            socket.connect(inetSocketAddress, i);
        } catch (AssertionError e) {
            if (!nu.e(e)) {
                throw e;
            }
            throw new IOException(e);
        } catch (ClassCastException e2) {
            throw e2;
        } catch (SecurityException e3) {
            IOException iOException = new IOException("Exception in connect");
            iOException.initCause(e3);
            throw iOException;
        }
    }

    @Override // com.facetec.sdk.pm
    public String b(SSLSocket sSLSocket) {
        byte[] bArr;
        pl<Socket> plVar = this.e;
        if (plVar == null || !plVar.e(sSLSocket) || (bArr = (byte[]) this.e.a(sSLSocket, new Object[0])) == null) {
            return null;
        }
        return new String(bArr, nu.e);
    }

    @Override // com.facetec.sdk.pm
    public void d(SSLSocket sSLSocket, String str, List<ng> list) {
        if (str != null) {
            this.b.b(sSLSocket, Boolean.TRUE);
            this.d.b(sSLSocket, str);
        }
        pl<Socket> plVar = this.c;
        if (plVar == null || !plVar.e(sSLSocket)) {
            return;
        }
        px pxVar = new px();
        int size = list.size();
        for (int i = 0; i < size; i++) {
            ng ngVar = list.get(i);
            if (ngVar != ng.HTTP_1_0) {
                pxVar.g(ngVar.toString().length());
                pxVar.a(ngVar.toString());
            }
        }
        this.c.a(sSLSocket, pxVar.o());
    }

    @Override // com.facetec.sdk.pm
    public final Object e(String str) {
        return this.f95944g.b(str);
    }

    @Override // com.facetec.sdk.pm
    public final void e(String str, Object obj) {
        if (this.f95944g.e(obj)) {
            return;
        }
        a(5, str, (Throwable) null);
    }

    @Override // com.facetec.sdk.pm
    public final po e(X509TrustManager x509TrustManager) {
        try {
            Class<?> cls = Class.forName("android.net.http.X509TrustManagerExtensions");
            return new c(cls.getConstructor(X509TrustManager.class).newInstance(x509TrustManager), cls.getMethod("checkServerTrusted", X509Certificate[].class, String.class, String.class));
        } catch (Exception unused) {
            return super.e(x509TrustManager);
        }
    }

    @Override // com.facetec.sdk.pm
    public final boolean b(String str) {
        try {
            Class<?> cls = Class.forName("android.security.NetworkSecurityPolicy");
            return c(str, cls, cls.getMethod("getInstance", null).invoke(null, null));
        } catch (ClassNotFoundException | NoSuchMethodException unused) {
            return super.b(str);
        } catch (IllegalAccessException e) {
            e = e;
            throw nu.e("unable to determine cleartext support", e);
        } catch (IllegalArgumentException e2) {
            e = e2;
            throw nu.e("unable to determine cleartext support", e);
        } catch (InvocationTargetException e3) {
            e = e3;
            throw nu.e("unable to determine cleartext support", e);
        }
    }

    @Override // com.facetec.sdk.pm
    public final SSLContext c() {
        try {
            return SSLContext.getInstance("TLS");
        } catch (NoSuchAlgorithmException e) {
            throw new IllegalStateException("No TLS provider", e);
        }
    }

    @Override // com.facetec.sdk.pm
    public final void a(int i, String str, Throwable th) {
        int iMin;
        int i2 = i != 5 ? 3 : 5;
        if (th != null) {
            StringBuilder sb = new StringBuilder();
            sb.append(str);
            sb.append('\n');
            sb.append(Log.getStackTraceString(th));
            str = sb.toString();
        }
        int length = str.length();
        int i3 = 0;
        while (i3 < length) {
            int iIndexOf = str.indexOf(10, i3);
            if (iIndexOf == -1) {
                iIndexOf = length;
            }
            while (true) {
                iMin = Math.min(iIndexOf, i3 + 4000);
                Log.println(i2, "OkHttp", str.substring(i3, iMin));
                if (iMin >= iIndexOf) {
                    break;
                } else {
                    i3 = iMin;
                }
            }
            i3 = iMin + 1;
        }
    }

    @Override // com.facetec.sdk.pm
    public final pt b(X509TrustManager x509TrustManager) {
        try {
            Method declaredMethod = x509TrustManager.getClass().getDeclaredMethod("findTrustAnchorByIssuerAndSignature", X509Certificate.class);
            declaredMethod.setAccessible(true);
            return new b(x509TrustManager, declaredMethod);
        } catch (NoSuchMethodException unused) {
            return super.b(x509TrustManager);
        }
    }

    private boolean a(String str, Class<?> cls, Object obj) {
        try {
            return ((Boolean) cls.getMethod("isCleartextTrafficPermitted", null).invoke(obj, null)).booleanValue();
        } catch (NoSuchMethodException unused) {
            return super.b(str);
        }
    }

    private static boolean d() {
        if (Security.getProvider("GMSCore_OpenSSL") != null) {
            return true;
        }
        try {
            Class.forName("android.net.Network");
            return true;
        } catch (ClassNotFoundException unused) {
            return false;
        }
    }

    public static int b() {
        try {
            return Build.VERSION.SDK_INT;
        } catch (NoClassDefFoundError unused) {
            return 0;
        }
    }

    public static pm a() {
        Class<?> cls;
        pl plVar;
        pl plVar2;
        try {
            if (!pm.f()) {
                return null;
            }
            try {
                cls = Class.forName("com.android.org.conscrypt.SSLParametersImpl");
            } catch (ClassNotFoundException unused) {
                cls = Class.forName("org.apache.harmony.xnet.provider.jsse.SSLParametersImpl");
            }
            Class<?> cls2 = cls;
            pl plVar3 = new pl(null, "setUseSessionTickets", Boolean.TYPE);
            pl plVar4 = new pl(null, "setHostname", String.class);
            if (d()) {
                plVar = new pl(byte[].class, "getAlpnSelectedProtocol", new Class[0]);
                plVar2 = new pl(null, "setAlpnProtocols", byte[].class);
            } else {
                plVar = null;
                plVar2 = null;
            }
            return new pg(cls2, plVar3, plVar4, plVar, plVar2);
        } catch (ClassNotFoundException unused2) {
            return null;
        }
    }
}