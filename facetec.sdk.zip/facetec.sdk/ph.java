package com.facetec.sdk;

import java.io.File;
import java.io.IOException;

/* JADX INFO: loaded from: classes4.dex */
public interface ph {

    /* JADX INFO: renamed from: com.facetec.sdk.ph$5, reason: invalid class name */
    public class AnonymousClass5 implements ph {
        @Override // com.facetec.sdk.ph
        public final void a(File file) throws IOException {
            if (!file.delete() && file.exists()) {
                throw new IOException("failed to delete ".concat(String.valueOf(file)));
            }
        }
    }

    void a(File file);
}