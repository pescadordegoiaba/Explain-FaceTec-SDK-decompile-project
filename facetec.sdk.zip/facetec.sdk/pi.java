package com.facetec.sdk;

import java.io.IOException;

/* JADX INFO: loaded from: classes4.dex */
public final class pi extends IOException {
    public final or a;

    public pi(or orVar) {
        super("stream was reset: ".concat(String.valueOf(orVar)));
        this.a = orVar;
    }
}