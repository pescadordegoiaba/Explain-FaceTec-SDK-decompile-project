package com.facetec.sdk;

import java.lang.reflect.InvocationHandler;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.lang.reflect.Proxy;
import java.util.List;
import javax.net.ssl.SSLSocket;

/* JADX INFO: loaded from: classes4.dex */
final class pj extends pm {
    private final Method a;
    private final Method b;
    private final Class<?> c;
    private final Method d;
    private final Class<?> e;

    public static class c implements InvocationHandler {
        String c;
        private final List<String> d;
        boolean e;

        public c(List<String> list) {
            this.d = list;
        }

        @Override // java.lang.reflect.InvocationHandler
        public final Object invoke(Object obj, Method method, Object[] objArr) {
            String name = method.getName();
            Class<?> returnType = method.getReturnType();
            if (objArr == null) {
                objArr = nu.a;
            }
            if (name.equals("supports") && Boolean.TYPE == returnType) {
                return Boolean.TRUE;
            }
            if (name.equals("unsupported") && Void.TYPE == returnType) {
                this.e = true;
                return null;
            }
            if (name.equals("protocols") && objArr.length == 0) {
                return this.d;
            }
            if ((name.equals("selectProtocol") || name.equals("select")) && String.class == returnType && objArr.length == 1) {
                Object obj2 = objArr[0];
                if (obj2 instanceof List) {
                    List list = (List) obj2;
                    int size = list.size();
                    for (int i = 0; i < size; i++) {
                        if (this.d.contains(list.get(i))) {
                            String str = (String) list.get(i);
                            this.c = str;
                            return str;
                        }
                    }
                    String str2 = this.d.get(0);
                    this.c = str2;
                    return str2;
                }
            }
            if ((!name.equals("protocolSelected") && !name.equals("selected")) || objArr.length != 1) {
                return method.invoke(this, objArr);
            }
            this.c = (String) objArr[0];
            return null;
        }
    }

    private pj(Method method, Method method2, Method method3, Class<?> cls, Class<?> cls2) {
        this.b = method;
        this.a = method2;
        this.d = method3;
        this.e = cls;
        this.c = cls2;
    }

    public static pm a() {
        try {
            Class<?> cls = Class.forName("org.eclipse.jetty.alpn.ALPN");
            StringBuilder sb = new StringBuilder();
            sb.append("org.eclipse.jetty.alpn.ALPN");
            sb.append("$Provider");
            Class<?> cls2 = Class.forName(sb.toString());
            StringBuilder sb2 = new StringBuilder();
            sb2.append("org.eclipse.jetty.alpn.ALPN");
            sb2.append("$ClientProvider");
            Class<?> cls3 = Class.forName(sb2.toString());
            StringBuilder sb3 = new StringBuilder();
            sb3.append("org.eclipse.jetty.alpn.ALPN");
            sb3.append("$ServerProvider");
            return new pj(cls.getMethod("put", SSLSocket.class, cls2), cls.getMethod("get", SSLSocket.class), cls.getMethod("remove", SSLSocket.class), cls3, Class.forName(sb3.toString()));
        } catch (ClassNotFoundException | NoSuchMethodException unused) {
            return null;
        }
    }

    @Override // com.facetec.sdk.pm
    public final String b(SSLSocket sSLSocket) {
        try {
            c cVar = (c) Proxy.getInvocationHandler(this.a.invoke(null, sSLSocket));
            boolean z = cVar.e;
            if (!z && cVar.c == null) {
                pm.i().a(4, "ALPN callback dropped: HTTP/2 is disabled. Is alpn-boot on the boot class path?", (Throwable) null);
                return null;
            }
            if (z) {
                return null;
            }
            return cVar.c;
        } catch (IllegalAccessException e) {
            e = e;
            throw nu.e("unable to get selected protocol", e);
        } catch (InvocationTargetException e2) {
            e = e2;
            throw nu.e("unable to get selected protocol", e);
        }
    }

    @Override // com.facetec.sdk.pm
    public final void d(SSLSocket sSLSocket, String str, List<ng> list) {
        try {
            this.b.invoke(null, sSLSocket, Proxy.newProxyInstance(pm.class.getClassLoader(), new Class[]{this.e, this.c}, new c(pm.a(list))));
        } catch (IllegalAccessException | InvocationTargetException e) {
            throw nu.e("unable to set alpn", e);
        }
    }

    @Override // com.facetec.sdk.pm
    public final void e(SSLSocket sSLSocket) {
        try {
            this.d.invoke(null, sSLSocket);
        } catch (IllegalAccessException | InvocationTargetException e) {
            throw nu.e("unable to remove alpn", e);
        }
    }
}