package com.facetec.sdk;

import android.os.Process;
import java.io.IOException;
import java.net.Proxy;
import java.net.ProxySelector;
import java.net.SocketAddress;
import java.net.URI;
import java.util.Collections;
import java.util.List;

/* JADX INFO: loaded from: classes4.dex */
public final class pk extends ProxySelector {
    public static int b;
    public static int e;

    public static int d() {
        int i = b;
        int i2 = i % 5418251;
        b = i + 1;
        if (i2 != 0) {
            return e;
        }
        int elapsedCpuTime = (int) Process.getElapsedCpuTime();
        e = elapsedCpuTime;
        return elapsedCpuTime;
    }

    @Override // java.net.ProxySelector
    public final void connectFailed(URI uri, SocketAddress socketAddress, IOException iOException) {
    }

    @Override // java.net.ProxySelector
    public final List<Proxy> select(URI uri) {
        if (uri != null) {
            return Collections.singletonList(Proxy.NO_PROXY);
        }
        throw new IllegalArgumentException("uri must not be null");
    }
}