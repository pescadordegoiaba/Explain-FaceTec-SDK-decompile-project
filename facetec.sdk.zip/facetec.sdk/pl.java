package com.facetec.sdk;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;

/* JADX INFO: loaded from: classes4.dex */
final class pl<T> {
    private final Class<?> c;
    private final String d;
    private final Class[] e;

    public pl(Class<?> cls, String str, Class... clsArr) {
        this.c = cls;
        this.d = str;
        this.e = clsArr;
    }

    private Object d(T t, Object... objArr) {
        Method methodD = d(t.getClass());
        if (methodD != null) {
            try {
                return methodD.invoke(t, objArr);
            } catch (IllegalAccessException e) {
                AssertionError assertionError = new AssertionError("Unexpectedly could not call: ".concat(String.valueOf(methodD)));
                assertionError.initCause(e);
                throw assertionError;
            }
        }
        StringBuilder sb = new StringBuilder("Method ");
        sb.append(this.d);
        sb.append(" not supported for object ");
        sb.append(t);
        throw new AssertionError(sb.toString());
    }

    public final Object a(T t, Object... objArr) {
        try {
            return d(t, objArr);
        } catch (InvocationTargetException e) {
            Throwable targetException = e.getTargetException();
            if (targetException instanceof RuntimeException) {
                throw ((RuntimeException) targetException);
            }
            AssertionError assertionError = new AssertionError("Unexpected exception");
            assertionError.initCause(targetException);
            throw assertionError;
        }
    }

    public final Object b(T t, Object... objArr) {
        try {
            return e(t, objArr);
        } catch (InvocationTargetException e) {
            Throwable targetException = e.getTargetException();
            if (targetException instanceof RuntimeException) {
                throw ((RuntimeException) targetException);
            }
            AssertionError assertionError = new AssertionError("Unexpected exception");
            assertionError.initCause(targetException);
            throw assertionError;
        }
    }

    public final boolean e(T t) {
        return d(t.getClass()) != null;
    }

    private Object e(T t, Object... objArr) {
        Method methodD = d(t.getClass());
        if (methodD == null) {
            return null;
        }
        try {
            return methodD.invoke(t, objArr);
        } catch (IllegalAccessException unused) {
            return null;
        }
    }

    private Method d(Class<?> cls) {
        Class<?> cls2;
        String str = this.d;
        if (str == null) {
            return null;
        }
        Method methodD = d(cls, str, this.e);
        if (methodD == null || (cls2 = this.c) == null || cls2.isAssignableFrom(methodD.getReturnType())) {
            return methodD;
        }
        return null;
    }

    private static Method d(Class<?> cls, String str, Class[] clsArr) {
        try {
            Method method = cls.getMethod(str, clsArr);
            try {
                if ((method.getModifiers() & 1) == 0) {
                    return null;
                }
                return method;
            } catch (NoSuchMethodException unused) {
                return method;
            }
        } catch (NoSuchMethodException unused2) {
            return null;
        }
    }
}