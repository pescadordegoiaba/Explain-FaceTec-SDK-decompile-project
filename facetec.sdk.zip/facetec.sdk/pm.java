package com.facetec.sdk;

import android.graphics.ImageFormat;
import android.media.AudioTrack;
import android.os.Process;
import android.os.SystemClock;
import android.text.TextUtils;
import android.view.KeyEvent;
import android.view.View;
import android.view.ViewConfiguration;
import android.widget.ExpandableListView;
import com.incode.welcome_sdk.modules.SelfieScan;
import java.lang.reflect.Method;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.security.NoSuchAlgorithmException;
import java.security.Security;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.net.ssl.SSLContext;
import javax.net.ssl.SSLSocket;
import javax.net.ssl.SSLSocketFactory;
import javax.net.ssl.X509TrustManager;

/* JADX INFO: loaded from: classes4.dex */
public class pm {
    private static final byte[] $$a = null;
    private static final int $$b = 0;
    private static int[] b;
    private static final Logger c;
    private static final pm e;

    /* JADX WARN: Removed duplicated region for block: B:10:0x0026  */
    /* JADX WARN: Removed duplicated region for block: B:8:0x0020  */
    /* JADX WARN: Unsupported multi-entry loop pattern (BACK_EDGE: B:10:0x0026 -> B:11:0x002a). Please report as a decompilation issue!!! */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    private static java.lang.String $$c(short r5, int r6, byte r7) {
        /*
            byte[] r0 = com.facetec.sdk.pm.$$a
            int r7 = r7 * 4
            int r7 = 3 - r7
            int r6 = r6 * 2
            int r6 = r6 + 119
            int r5 = r5 * 4
            int r1 = 1 - r5
            byte[] r1 = new byte[r1]
            r2 = 0
            int r5 = 0 - r5
            if (r0 != 0) goto L18
            r4 = r5
            r3 = r2
            goto L2a
        L18:
            r3 = r2
        L19:
            byte r4 = (byte) r6
            r1[r3] = r4
            int r7 = r7 + 1
            if (r3 != r5) goto L26
            java.lang.String r5 = new java.lang.String
            r5.<init>(r1, r2)
            return r5
        L26:
            int r3 = r3 + 1
            r4 = r0[r7]
        L2a:
            int r4 = -r4
            int r6 = r6 + r4
            goto L19
        */
        throw new UnsupportedOperationException("Method not decompiled: com.facetec.sdk.pm.$$c(short, int, byte):java.lang.String");
    }

    static {
        pm pmVarE;
        init$0();
        h();
        if (f()) {
            pmVarE = pf.d();
            if (pmVarE == null && (pmVarE = pg.a()) == null) {
                throw new NullPointerException("No platform found on Android");
            }
        } else {
            try {
                Object[] objArr = new Object[1];
                j(new int[]{987870699, -1819195252, -832231471, 2110608039, -1660407313, 1526381959, 1435575171, 1505746989}, TextUtils.lastIndexOf("", '0') + 17, objArr);
                Class<?> cls = Class.forName((String) objArr[0]);
                Object[] objArr2 = new Object[1];
                j(new int[]{1207600941, -191727118, 1496820756, 536436516, -37616541, -1716213254}, 10 - TextUtils.lastIndexOf("", '0', 0, 0), objArr2);
                if ((!("conscrypt".equals(cls.getMethod((String) objArr2[0], String.class).invoke(null, "okhttp.platform")) ? true : "Conscrypt".equals(Security.getProviders()[0].getName())) || (pmVarE = pe.b()) == null) && (pmVarE = pn.e()) == null && (pmVarE = pj.a()) == null) {
                    pmVarE = new pm();
                }
            } catch (Throwable th) {
                Throwable cause = th.getCause();
                if (cause == null) {
                    throw th;
                }
                throw cause;
            }
        }
        e = pmVarE;
        c = Logger.getLogger(nf.class.getName());
    }

    public static boolean f() throws Throwable {
        try {
            Object[] objArr = new Object[1];
            j(new int[]{987870699, -1819195252, -832231471, 2110608039, -1660407313, 1526381959, 1435575171, 1505746989}, (ViewConfiguration.getWindowTouchSlop() >> 8) + 16, objArr);
            Class<?> cls = Class.forName((String) objArr[0]);
            Object[] objArr2 = new Object[1];
            j(new int[]{1207600941, -191727118, 1496820756, 536436516, -37616541, -1716213254}, 12 - (ViewConfiguration.getScrollFriction() > SelfieScan.RECOGNITION_FAIL_RESULT ? 1 : (ViewConfiguration.getScrollFriction() == SelfieScan.RECOGNITION_FAIL_RESULT ? 0 : -1)), objArr2);
            return "Dalvik".equals(cls.getMethod((String) objArr2[0], String.class).invoke(null, "java.vm.name"));
        } catch (Throwable th) {
            Throwable cause = th.getCause();
            if (cause != null) {
                throw cause;
            }
            throw th;
        }
    }

    public static void h() {
        b = new int[]{-1864704677, 785496325, 1389787490, 762483468, -1976651405, -770016412, -137717841, 1961082428, -1649381238, 2116603183, -87234453, 1998478101, -748646002, -205423866, -1063746620, -990456824, 1876608948, 1667982220};
    }

    public static pm i() {
        return e;
    }

    public static void init$0() {
        $$a = new byte[]{86, 117, -27, 75};
        $$b = 116;
    }

    private static void j(int[] iArr, int i, Object[] objArr) throws Throwable {
        int i2;
        long j;
        String str;
        char[] cArr;
        int i3;
        int i4;
        String str2 = "";
        hg hgVar = new hg();
        char[] cArr2 = new char[4];
        int i5 = 2;
        char[] cArr3 = new char[iArr.length * 2];
        int[] iArr2 = b;
        Class cls = Integer.TYPE;
        int i6 = 16;
        int i7 = 0;
        if (iArr2 != null) {
            int length = iArr2.length;
            i2 = 2027942060;
            int[] iArr3 = new int[length];
            int i8 = 0;
            j = 0;
            while (i8 < length) {
                try {
                    Object[] objArr2 = {Integer.valueOf(iArr2[i8])};
                    Object objD = an.d(2027942060);
                    if (objD == null) {
                        i3 = i5;
                        i4 = i6;
                        byte b2 = (byte) i7;
                        byte b3 = (byte) (b2 + 1);
                        objD = an.d(617 - (Process.myPid() >> 22), (char) (ViewConfiguration.getEdgeSlop() >> 16), ExpandableListView.getPackedPositionType(0L) + 23, 247342071, false, $$c(b2, b3, (byte) (b3 - 1)), new Class[]{cls});
                    } else {
                        i3 = i5;
                        i4 = i6;
                    }
                    iArr3[i8] = ((Integer) ((Method) objD).invoke(null, objArr2)).intValue();
                    i8++;
                    i5 = i3;
                    i6 = i4;
                    i7 = 0;
                } catch (Throwable th) {
                    Throwable cause = th.getCause();
                    if (cause == null) {
                        throw th;
                    }
                    throw cause;
                }
            }
            iArr2 = iArr3;
        } else {
            i2 = 2027942060;
            j = 0;
        }
        int i9 = i5;
        int i10 = i6;
        int length2 = iArr2.length;
        int[] iArr4 = new int[length2];
        int[] iArr5 = b;
        if (iArr5 != null) {
            int length3 = iArr5.length;
            int[] iArr6 = new int[length3];
            int i11 = 0;
            while (i11 < length3) {
                Object[] objArr3 = {Integer.valueOf(iArr5[i11])};
                Object objD2 = an.d(i2);
                if (objD2 == null) {
                    int iIndexOf = TextUtils.indexOf((CharSequence) str2, '0') + 618;
                    char cKeyCodeFromString = (char) KeyEvent.keyCodeFromString(str2);
                    int trimmedLength = TextUtils.getTrimmedLength(str2) + 23;
                    str = str2;
                    byte b4 = (byte) 0;
                    byte b5 = (byte) (b4 + 1);
                    cArr = cArr2;
                    objD2 = an.d(iIndexOf, cKeyCodeFromString, trimmedLength, 247342071, false, $$c(b4, b5, (byte) (b5 - 1)), new Class[]{cls});
                } else {
                    str = str2;
                    cArr = cArr2;
                }
                iArr6[i11] = ((Integer) ((Method) objD2).invoke(null, objArr3)).intValue();
                i11++;
                str2 = str;
                cArr2 = cArr;
            }
            iArr5 = iArr6;
        }
        char[] cArr4 = cArr2;
        char c2 = 0;
        System.arraycopy(iArr5, 0, iArr4, 0, length2);
        hgVar.c = 0;
        while (true) {
            int i12 = hgVar.c;
            if (i12 >= iArr.length) {
                objArr[0] = new String(cArr3, 0, i);
                return;
            }
            int i13 = iArr[i12];
            char c3 = (char) (i13 >> 16);
            cArr4[c2] = c3;
            char c4 = (char) i13;
            cArr4[1] = c4;
            char c5 = (char) (iArr[i12 + 1] >> 16);
            cArr4[i9] = c5;
            char c6 = (char) iArr[i12 + 1];
            cArr4[3] = c6;
            hgVar.d = (c3 << 16) + c4;
            hgVar.a = (c5 << 16) + c6;
            hg.a(iArr4);
            int i14 = 0;
            while (i14 < i10) {
                int i15 = hgVar.d ^ iArr4[i14];
                hgVar.d = i15;
                int iB = hg.b(i15);
                Object[] objArr4 = new Object[4];
                objArr4[3] = hgVar;
                objArr4[i9] = hgVar;
                objArr4[1] = Integer.valueOf(iB);
                objArr4[0] = hgVar;
                Object objD3 = an.d(-1264699187);
                if (objD3 == null) {
                    byte b6 = (byte) 0;
                    byte b7 = b6;
                    objD3 = an.d(((Process.getThreadPriority(0) + 20) >> 6) + 1558, (char) (ImageFormat.getBitsPerPixel(0) + 63318), ImageFormat.getBitsPerPixel(0) + 33, -1023415402, false, $$c(b6, b7, b7), new Class[]{Object.class, cls, Object.class, Object.class});
                }
                int iIntValue = ((Integer) ((Method) objD3).invoke(null, objArr4)).intValue();
                hgVar.d = hgVar.a;
                hgVar.a = iIntValue;
                i14++;
                i10 = 16;
            }
            int i16 = hgVar.d;
            int i17 = hgVar.a;
            hgVar.d = i17;
            hgVar.a = i16;
            i10 = 16;
            int i18 = i16 ^ iArr4[16];
            hgVar.a = i18;
            int i19 = i17 ^ iArr4[17];
            hgVar.d = i19;
            cArr4[0] = (char) (i19 >>> 16);
            cArr4[1] = (char) i19;
            cArr4[i9] = (char) (i18 >>> 16);
            cArr4[3] = (char) i18;
            hg.a(iArr4);
            int i20 = hgVar.c;
            cArr3[i20 * 2] = cArr4[0];
            cArr3[(i20 * 2) + 1] = cArr4[1];
            cArr3[(i20 * 2) + 2] = cArr4[i9];
            cArr3[(i20 * 2) + 3] = cArr4[3];
            int i21 = i9;
            Object[] objArr5 = new Object[i21];
            objArr5[1] = hgVar;
            objArr5[0] = hgVar;
            Object objD4 = an.d(-204410541);
            if (objD4 == null) {
                objD4 = an.d(310 - View.MeasureSpec.getMode(0), (char) ((SystemClock.elapsedRealtime() > j ? 1 : (SystemClock.elapsedRealtime() == j ? 0 : -1)) - 1), (Process.getElapsedCpuTime() > j ? 1 : (Process.getElapsedCpuTime() == j ? 0 : -1)) + 22, -2051988984, false, "A", new Class[]{Object.class, Object.class});
            }
            ((Method) objD4).invoke(null, objArr5);
            i9 = i21;
            c2 = 0;
        }
    }

    public void a(Socket socket, InetSocketAddress inetSocketAddress, int i) {
        socket.connect(inetSocketAddress, i);
    }

    public String b(SSLSocket sSLSocket) {
        return null;
    }

    public SSLContext c() {
        try {
            Object[] objArr = new Object[1];
            j(new int[]{987870699, -1819195252, -832231471, 2110608039, -1660407313, 1526381959, 1435575171, 1505746989}, 17 - (SystemClock.currentThreadTimeMillis() > (-1L) ? 1 : (SystemClock.currentThreadTimeMillis() == (-1L) ? 0 : -1)), objArr);
            Class<?> cls = Class.forName((String) objArr[0]);
            Object[] objArr2 = new Object[1];
            j(new int[]{1207600941, -191727118, 1496820756, 536436516, -37616541, -1716213254}, (AudioTrack.getMinVolume() > SelfieScan.RECOGNITION_FAIL_RESULT ? 1 : (AudioTrack.getMinVolume() == SelfieScan.RECOGNITION_FAIL_RESULT ? 0 : -1)) + 11, objArr2);
            if ("1.7".equals(cls.getMethod((String) objArr2[0], String.class).invoke(null, "java.specification.version"))) {
                try {
                    return SSLContext.getInstance("TLSv1.2");
                } catch (NoSuchAlgorithmException unused) {
                }
            }
            try {
                return SSLContext.getInstance("TLS");
            } catch (NoSuchAlgorithmException e2) {
                throw new IllegalStateException("No TLS provider", e2);
            }
        } catch (Throwable th) {
            Throwable cause = th.getCause();
            if (cause != null) {
                throw cause;
            }
            throw th;
        }
    }

    public void d(SSLSocket sSLSocket, String str, List<ng> list) {
    }

    public void e(SSLSocket sSLSocket) {
    }

    public String toString() {
        return getClass().getSimpleName();
    }

    public void a(int i, String str, Throwable th) {
        c.log(i == 5 ? Level.WARNING : Level.INFO, str, th);
    }

    public boolean b(String str) {
        return true;
    }

    public void e(SSLSocketFactory sSLSocketFactory) {
    }

    public pt b(X509TrustManager x509TrustManager) {
        return new pp(x509TrustManager.getAcceptedIssuers());
    }

    public Object e(String str) {
        if (c.isLoggable(Level.FINE)) {
            return new Throwable(str);
        }
        return null;
    }

    public static List<String> a(List<ng> list) {
        ArrayList arrayList = new ArrayList(list.size());
        int size = list.size();
        for (int i = 0; i < size; i++) {
            ng ngVar = list.get(i);
            if (ngVar != ng.HTTP_1_0) {
                arrayList.add(ngVar.toString());
            }
        }
        return arrayList;
    }

    public void e(String str, Object obj) {
        if (obj == null) {
            StringBuilder sb = new StringBuilder();
            sb.append(str);
            sb.append(" To see where this was allocated, set the OkHttpClient logger level to FINE: Logger.getLogger(OkHttpClient.class.getName()).setLevel(Level.FINE);");
            str = sb.toString();
        }
        a(5, str, (Throwable) obj);
    }

    public po e(X509TrustManager x509TrustManager) {
        return new ps(b(x509TrustManager));
    }
}