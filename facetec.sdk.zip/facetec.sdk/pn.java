package com.facetec.sdk;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.List;
import javax.net.ssl.SSLParameters;
import javax.net.ssl.SSLSocket;

/* JADX INFO: loaded from: classes4.dex */
final class pn extends pm {
    private Method c;
    private Method e;

    private pn(Method method, Method method2) {
        this.e = method;
        this.c = method2;
    }

    public static pn e() {
        try {
            return new pn(SSLParameters.class.getMethod("setApplicationProtocols", String[].class), SSLSocket.class.getMethod("getApplicationProtocol", null));
        } catch (NoSuchMethodException unused) {
            return null;
        }
    }

    @Override // com.facetec.sdk.pm
    public final String b(SSLSocket sSLSocket) {
        try {
            String str = (String) this.c.invoke(sSLSocket, null);
            if (str != null) {
                if (!str.equals("")) {
                    return str;
                }
            }
            return null;
        } catch (IllegalAccessException e) {
            throw nu.e("failed to get ALPN selected protocol", e);
        } catch (InvocationTargetException e2) {
            if (e2.getCause() instanceof UnsupportedOperationException) {
                return null;
            }
            throw nu.e("failed to get ALPN selected protocol", e2);
        }
    }

    @Override // com.facetec.sdk.pm
    public final void d(SSLSocket sSLSocket, String str, List<ng> list) {
        try {
            SSLParameters sSLParameters = sSLSocket.getSSLParameters();
            List<String> listA = pm.a(list);
            this.e.invoke(sSLParameters, listA.toArray(new String[listA.size()]));
            sSLSocket.setSSLParameters(sSLParameters);
        } catch (IllegalAccessException | InvocationTargetException e) {
            throw nu.e("unable to set ssl parameters", e);
        }
    }
}