package com.facetec.sdk;

import java.security.cert.Certificate;
import java.util.List;

/* JADX INFO: loaded from: classes4.dex */
public abstract class po {
    public abstract List<Certificate> a(List<Certificate> list, String str);
}