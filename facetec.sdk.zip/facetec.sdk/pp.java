package com.facetec.sdk;

import android.os.Process;
import android.os.SystemClock;
import android.telephony.cdma.CdmaCellLocation;
import android.text.TextUtils;
import android.view.Gravity;
import android.view.ViewConfiguration;
import android.widget.ExpandableListView;
import com.plaid.internal.EnumC41897g;
import java.lang.reflect.Method;
import java.security.cert.X509Certificate;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.Map;
import java.util.Set;
import javax.security.auth.x500.X500Principal;
import net.sf.scuba.smartcards.ISO7816;
import net.sf.scuba.smartcards.ISOFileInfo;
import org.bouncycastle.crypto.signers.PSSSigner;
import org.bouncycastle.i18n.LocalizedMessage;
import org.jmrtd.PassportService;
import org.jmrtd.lds.CVCAFile;

/* JADX INFO: loaded from: classes4.dex */
public final class pp implements pt {
    private static final byte[] $$a = null;
    private static final int $$b = 0;
    private static final byte[] $$c = null;
    private static final byte[] $$d = null;
    private static final int $$e = 0;
    private static final int $$f = 0;
    private static int $10;
    private static int $11;
    private static boolean a;
    private static char[] b;
    private static int d;
    private static boolean e;
    private static int f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    private static int f95945g;
    private static short[] h;
    private static byte[] i;
    private static int j;
    private static int k;
    private static int n;
    private final Map<X500Principal, Set<X509Certificate>> c = new LinkedHashMap();

    /* JADX WARN: Removed duplicated region for block: B:10:0x0021  */
    /* JADX WARN: Removed duplicated region for block: B:8:0x001b  */
    /* JADX WARN: Unsupported multi-entry loop pattern (BACK_EDGE: B:10:0x0021 -> B:11:0x0028). Please report as a decompilation issue!!! */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    private static java.lang.String $$g(byte r7, short r8, short r9) {
        /*
            int r8 = r8 + 102
            int r7 = r7 + 4
            byte[] r0 = com.facetec.sdk.pp.$$c
            int r9 = r9 * 4
            int r9 = r9 + 1
            byte[] r1 = new byte[r9]
            r2 = 0
            if (r0 != 0) goto L13
            r8 = r7
            r3 = r9
            r5 = r2
            goto L28
        L13:
            r3 = r2
        L14:
            byte r4 = (byte) r8
            int r5 = r3 + 1
            r1[r3] = r4
            if (r5 != r9) goto L21
            java.lang.String r7 = new java.lang.String
            r7.<init>(r1, r2)
            return r7
        L21:
            int r7 = r7 + 1
            r3 = r0[r7]
            r6 = r8
            r8 = r7
            r7 = r6
        L28:
            int r3 = -r3
            int r7 = r7 + r3
            r3 = r8
            r8 = r7
            r7 = r3
            r3 = r5
            goto L14
        */
        throw new UnsupportedOperationException("Method not decompiled: com.facetec.sdk.pp.$$g(byte, short, short):java.lang.String");
    }

    static {
        init$2();
        $10 = 0;
        $11 = 1;
        init$1();
        init$0();
        n = 0;
        k = 1;
        b = new char[]{8614, 8619, 8609, 8599, 8596, 8622, 8683, 8608, 8593, 8610, 8640, 8605, 8620, 8629, 8616, 8651, 8618, 8660, 8597, 8677, 8617, 8592, 8463, 8626, 8625, 8643, 8682, 8669, 8671, 8595, 8612, 8606, 8624, 8621, 8615, 8611, 8594};
        d = 1071522053;
        a = true;
        e = true;
        j = -1188022402;
        f95945g = 114796563;
        f = 1496974996;
        i = new byte[]{5, -12, 89, -41, -13, 58, -23, PassportService.SFI_DG15, -14, -10, -15, -16, 60, 35, -63, 3, -14, -70, 22, 97, ISOFileInfo.DATA_BYTES2, 10, PassportService.SFI_DG12, 8, 118, 127, 8, ISO7816.INS_PUT_DATA, -67, -53, ISOFileInfo.DATA_BYTES2, 123, 25, 126, 121, PassportService.SFI_DG13, -55, -69, 65, ISO7816.INS_UPDATE_BINARY, -66, 125, 67, 9, 18, -31, -89, -106, -105, ISOFileInfo.SECURITY_ATTR_COMPACT, 99, -101, -100, 94, -88, -109, -99, 64, ISO7816.INS_READ_BINARY_STAMPED, -109, 107, -101, 97, ISOFileInfo.FCI_BYTE, -104, ISOFileInfo.A5, ISO7816.INS_UPDATE_BINARY, -34, -53, ISOFileInfo.A5, -84, -20, -82, ISO7816.INS_WRITE_RECORD, -43, -43, -73, -61, ISO7816.INS_PUT_DATA, ISO7816.INS_WRITE_RECORD, -53, -87, -71, -82, 24, -35, -44, ISOFileInfo.A1, -37, ISOFileInfo.SECURITY_ATTR_EXP, 22, ISO7816.INS_LOAD_KEY_FILE, -89, ISOFileInfo.SECURITY_ATTR_EXP, ISO7816.INS_APPEND_RECORD, -45, ISO7816.INS_WRITE_RECORD, -43, -90, -50, ISOFileInfo.A5, -98, -98, -73, 106, 124, -41, ISOFileInfo.DATA_BYTES1, 102, -82, -110, 125, -90, 96, ISO7816.INS_READ_BINARY2, -65, ISOFileInfo.AB, -94, -103, -83, -88, -66, ISO7816.INS_READ_RECORD_STAMPED, ISO7816.INS_READ_RECORD_STAMPED, -78, -75, -53, ISO7816.INS_UPDATE_RECORD, 121, -83, -88, ISOFileInfo.DATA_BYTES1, -83, ISO7816.INS_READ_RECORD_STAMPED, ISOFileInfo.AB, -4, 105, -70, -71, ISO7816.INS_READ_BINARY_STAMPED, ISOFileInfo.A5, -67, -92, -107, 106, ISO7816.INS_GET_DATA, -120, -94, -94, 109, -81, ISO7816.INS_UPDATE_RECORD, -106, -106, -94, ISO7816.INS_LOAD_KEY_FILE, 119, -8, -113, ISO7816.INS_READ_BINARY, ISOFileInfo.FCI_EXT, -44, ISOFileInfo.PROP_INFO, -69, ISOFileInfo.FCP_BYTE, -72, -83, -113, -83, -57, 99, 99, 99, 99, 99, 99, 99, 99, 99, 99};
    }

    public pp(X509Certificate... x509CertificateArr) {
        for (X509Certificate x509Certificate : x509CertificateArr) {
            X500Principal subjectX500Principal = x509Certificate.getSubjectX500Principal();
            Set<X509Certificate> linkedHashSet = this.c.get(subjectX500Principal);
            if (linkedHashSet == null) {
                linkedHashSet = new LinkedHashSet<>(1);
                this.c.put(subjectX500Principal, linkedHashSet);
            }
            linkedHashSet.add(x509Certificate);
        }
    }

    /* JADX WARN: Code restructure failed: missing block: B:92:0x0983, code lost:
    
        r12.close();
     */
    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Removed duplicated region for block: B:103:0x0a27 A[Catch: all -> 0x0a16, Exception -> 0x0c59, TryCatch #10 {Exception -> 0x0c59, blocks: (B:70:0x086b, B:101:0x0a19, B:103:0x0a27, B:104:0x0a64, B:106:0x0a7a, B:107:0x0ab4, B:137:0x0c22, B:139:0x0c24, B:141:0x0c2a, B:142:0x0c2b, B:149:0x0c36, B:151:0x0c3c, B:152:0x0c3d, B:154:0x0c43, B:156:0x0c49, B:157:0x0c4a, B:158:0x0c4b, B:160:0x0c51, B:161:0x0c52), top: B:276:0x086b }] */
    /* JADX WARN: Removed duplicated region for block: B:106:0x0a7a A[Catch: all -> 0x0a16, Exception -> 0x0c59, TryCatch #10 {Exception -> 0x0c59, blocks: (B:70:0x086b, B:101:0x0a19, B:103:0x0a27, B:104:0x0a64, B:106:0x0a7a, B:107:0x0ab4, B:137:0x0c22, B:139:0x0c24, B:141:0x0c2a, B:142:0x0c2b, B:149:0x0c36, B:151:0x0c3c, B:152:0x0c3d, B:154:0x0c43, B:156:0x0c49, B:157:0x0c4a, B:158:0x0c4b, B:160:0x0c51, B:161:0x0c52), top: B:276:0x086b }] */
    /* JADX WARN: Removed duplicated region for block: B:111:0x0ae1 A[Catch: all -> 0x0a16, IOException -> 0x0d14, TryCatch #15 {IOException -> 0x0d14, blocks: (B:109:0x0ac6, B:111:0x0ae1, B:113:0x0b00, B:115:0x0b9a, B:117:0x0bbe, B:119:0x0be2, B:164:0x0c59, B:165:0x0d08), top: B:283:0x0ac6 }] */
    /* JADX WARN: Removed duplicated region for block: B:151:0x0c3c A[Catch: all -> 0x0a16, Exception -> 0x0c59, TryCatch #10 {Exception -> 0x0c59, blocks: (B:70:0x086b, B:101:0x0a19, B:103:0x0a27, B:104:0x0a64, B:106:0x0a7a, B:107:0x0ab4, B:137:0x0c22, B:139:0x0c24, B:141:0x0c2a, B:142:0x0c2b, B:149:0x0c36, B:151:0x0c3c, B:152:0x0c3d, B:154:0x0c43, B:156:0x0c49, B:157:0x0c4a, B:158:0x0c4b, B:160:0x0c51, B:161:0x0c52), top: B:276:0x086b }] */
    /* JADX WARN: Removed duplicated region for block: B:152:0x0c3d A[Catch: all -> 0x0a16, Exception -> 0x0c59, TryCatch #10 {Exception -> 0x0c59, blocks: (B:70:0x086b, B:101:0x0a19, B:103:0x0a27, B:104:0x0a64, B:106:0x0a7a, B:107:0x0ab4, B:137:0x0c22, B:139:0x0c24, B:141:0x0c2a, B:142:0x0c2b, B:149:0x0c36, B:151:0x0c3c, B:152:0x0c3d, B:154:0x0c43, B:156:0x0c49, B:157:0x0c4a, B:158:0x0c4b, B:160:0x0c51, B:161:0x0c52), top: B:276:0x086b }] */
    /* JADX WARN: Removed duplicated region for block: B:204:0x133b A[PHI: r1
      0x133b: PHI (r1v6 java.lang.String[]) = (r1v4 java.lang.String[]), (r1v4 java.lang.String[]), (r1v10 java.lang.String[]) binds: [B:181:0x0df5, B:183:0x0f6c, B:317:0x133b] A[DONT_GENERATE, DONT_INLINE]] */
    /* JADX WARN: Removed duplicated region for block: B:24:0x038f  */
    /* JADX WARN: Removed duplicated region for block: B:36:0x04b3 A[PHI: r6
      0x04b3: PHI (r6v118 int) = (r6v117 int), (r6v169 int) binds: [B:23:0x038d, B:304:0x04b3] A[DONT_GENERATE, DONT_INLINE]] */
    /* JADX WARN: Removed duplicated region for block: B:39:0x0576  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public static java.lang.Object[] c(android.content.Context r48, int r49, int r50, int r51) throws java.lang.Throwable {
        /*
            Method dump skipped, instruction units count: 6808
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: com.facetec.sdk.pp.c(android.content.Context, int, int, int):java.lang.Object[]");
    }

    public static void init$0() {
        $$a = new byte[]{PassportService.SFI_DG15, 58, -59, PassportService.SFI_DG15, -8, 16, -1, -4, -3, -52, 55, 14, 1, 8, -13, PassportService.SFI_DG11, 8, PSSSigner.TRAILER_IMPLICIT, ISO7816.INS_REHABILITATE_CHV, -1, -61, 21, 49, 2, -2, -1, -4, 0, 21, -9, 8, 1, -35, 39, -6, PassportService.SFI_DG11, -1, 21, -17, -27, 39, PassportService.SFI_DG11, -7, 23, -19, -49, 64, -9, PassportService.SFI_DG15, -5, -55, 40, 22, PassportService.SFI_DG12, -11, -2, 5, 3, -17, 19, 4, -5, -5, 2, PassportService.SFI_DG13, 7, -4, 7};
        $$b = 3;
    }

    public static void init$1() {
        $$d = new byte[]{113, CVCAFile.CAR_TAG, 51, 67};
        $$e = EnumC41897g.SDK_ASSET_ILLUSTRATION_BALANCE_BEAM_02_CIRCLE_VALUE;
    }

    public static void init$2() {
        $$c = new byte[]{25, 43, 92, -56};
        $$f = 112;
    }

    private static void l(int[] iArr, String str, int i2, String str2, Object[] objArr) throws Throwable {
        char[] charArray;
        int i3;
        int i4;
        String str3 = str2;
        int i5 = $11 + 37;
        $10 = i5 % 128;
        int i6 = 2;
        Object bytes = str3;
        if (i5 % 2 != 0) {
            throw null;
        }
        if (str3 != null) {
            bytes = str3.getBytes(LocalizedMessage.DEFAULT_ENCODING);
        }
        byte[] bArr = (byte[]) bytes;
        if (str != null) {
            $11 = ($10 + 41) % 128;
            charArray = str.toCharArray();
            $11 = ($10 + 75) % 128;
        } else {
            charArray = str;
        }
        char[] cArr = charArray;
        hn hnVar = new hn();
        char[] cArr2 = b;
        Class cls = Integer.TYPE;
        int i7 = -1;
        if (cArr2 != null) {
            int length = cArr2.length;
            char[] cArr3 = new char[length];
            int i8 = 0;
            while (i8 < length) {
                try {
                    Object[] objArr2 = {Integer.valueOf(cArr2[i8])};
                    Object objD = an.d(-814569747);
                    if (objD == null) {
                        i3 = i6;
                        byte b2 = (byte) i7;
                        i4 = i7;
                        objD = an.d(1804 - (Process.getElapsedCpuTime() > 0L ? 1 : (Process.getElapsedCpuTime() == 0L ? 0 : -1)), (char) (9692 - ExpandableListView.getPackedPositionGroup(0L)), 24 - TextUtils.getCapsMode("", 0, 0), -1189907018, false, $$g(b2, (byte) (b2 & 16), (byte) 0), new Class[]{cls});
                    } else {
                        i3 = i6;
                        i4 = i7;
                    }
                    cArr3[i8] = ((Character) ((Method) objD).invoke(null, objArr2)).charValue();
                    i8++;
                    i7 = i4;
                    i6 = i3;
                } catch (Throwable th) {
                    Throwable cause = th.getCause();
                    if (cause == null) {
                        throw th;
                    }
                    throw cause;
                }
            }
            cArr2 = cArr3;
        }
        int i9 = i6;
        int i10 = i7;
        Object[] objArr3 = {Integer.valueOf(d)};
        Object objD2 = an.d(-1578986303);
        if (objD2 == null) {
            byte b3 = (byte) i10;
            objD2 = an.d(2565 - TextUtils.indexOf((CharSequence) "", '0', 0, 0), (char) ((-1) - TextUtils.indexOf((CharSequence) "", '0', 0, 0)), 22 - TextUtils.lastIndexOf("", '0', 0, 0), -679262310, false, $$g(b3, (byte) (b3 & PassportService.SFI_DG15), (byte) 0), new Class[]{cls});
        }
        int iIntValue = ((Integer) ((Method) objD2).invoke(null, objArr3)).intValue();
        if (e) {
            int i11 = $11 + 39;
            $10 = i11 % 128;
            int i12 = i11 % 2;
            int length2 = bArr.length;
            hnVar.b = length2;
            char[] cArr4 = new char[length2];
            hnVar.c = 0;
            while (true) {
                int i13 = hnVar.c;
                int i14 = hnVar.b;
                if (i13 >= i14) {
                    objArr[0] = new String(cArr4);
                    return;
                }
                int i15 = $10 + 107;
                $11 = i15 % 128;
                if (i15 % 2 == 0) {
                    cArr4[i13] = (char) (cArr2[bArr[(i14 - 1) / i13] / i2] / iIntValue);
                    Object[] objArr4 = new Object[i9];
                    objArr4[1] = hnVar;
                    objArr4[0] = hnVar;
                    Object objD3 = an.d(717234065);
                    if (objD3 == null) {
                        objD3 = an.d((CdmaCellLocation.convertQuartSecToDecDegrees(0) > 0.0d ? 1 : (CdmaCellLocation.convertQuartSecToDecDegrees(0) == 0.0d ? 0 : -1)) + 1970, (char) TextUtils.getCapsMode("", 0, 0), 24 - (ViewConfiguration.getScrollBarSize() >> 8), 1554107594, false, "x", new Class[]{Object.class, Object.class});
                    }
                    ((Method) objD3).invoke(null, objArr4);
                } else {
                    cArr4[i13] = (char) (cArr2[bArr[(i14 - 1) - i13] + i2] - iIntValue);
                    Object[] objArr5 = {hnVar, hnVar};
                    Object objD4 = an.d(717234065);
                    if (objD4 == null) {
                        objD4 = an.d(1970 - Gravity.getAbsoluteGravity(0, 0), (char) (TextUtils.lastIndexOf("", '0') + 1), (SystemClock.currentThreadTimeMillis() > (-1L) ? 1 : (SystemClock.currentThreadTimeMillis() == (-1L) ? 0 : -1)) + 23, 1554107594, false, "x", new Class[]{Object.class, Object.class});
                    }
                    ((Method) objD4).invoke(null, objArr5);
                }
                i9 = 2;
            }
        } else if (a) {
            int length3 = cArr.length;
            hnVar.b = length3;
            char[] cArr5 = new char[length3];
            hnVar.c = 0;
            while (true) {
                int i16 = hnVar.c;
                int i17 = hnVar.b;
                if (i16 >= i17) {
                    objArr[0] = new String(cArr5);
                    return;
                }
                cArr5[i16] = (char) (cArr2[cArr[(i17 - 1) - i16] - i2] - iIntValue);
                Object[] objArr6 = {hnVar, hnVar};
                Object objD5 = an.d(717234065);
                if (objD5 == null) {
                    objD5 = an.d(1970 - (ViewConfiguration.getKeyRepeatDelay() >> 16), (char) (1 - (Process.getElapsedCpuTime() > 0L ? 1 : (Process.getElapsedCpuTime() == 0L ? 0 : -1))), ((Process.getThreadPriority(0) + 20) >> 6) + 24, 1554107594, false, "x", new Class[]{Object.class, Object.class});
                }
                ((Method) objD5).invoke(null, objArr6);
            }
        } else {
            int length4 = iArr.length;
            hnVar.b = length4;
            char[] cArr6 = new char[length4];
            hnVar.c = 0;
            while (true) {
                int i18 = hnVar.c;
                int i19 = hnVar.b;
                if (i18 >= i19) {
                    objArr[0] = new String(cArr6);
                    return;
                } else {
                    cArr6[i18] = (char) (cArr2[iArr[(i19 - 1) - i18] - i2] - iIntValue);
                    hnVar.c = i18 + 1;
                }
            }
        }
    }

    /* JADX WARN: Removed duplicated region for block: B:19:0x009c A[PHI: r14
      0x009c: PHI (r14v6 byte[]) = (r14v2 byte[]), (r14v7 byte[]) binds: [B:21:0x00a8, B:17:0x0099] A[DONT_GENERATE, DONT_INLINE]] */
    /* JADX WARN: Removed duplicated region for block: B:22:0x00aa A[PHI: r14
      0x00aa: PHI (r14v3 byte[] A[IMMUTABLE_TYPE]) = (r14v2 byte[]), (r14v7 byte[]) binds: [B:21:0x00a8, B:17:0x0099] A[DONT_GENERATE, DONT_INLINE]] */
    /* JADX WARN: Removed duplicated region for block: B:73:0x0302  */
    /* JADX WARN: Removed duplicated region for block: B:74:0x031d  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    private static void m(short r33, int r34, byte r35, int r36, int r37, java.lang.Object[] r38) throws java.lang.Throwable {
        /*
            Method dump skipped, instruction units count: 857
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: com.facetec.sdk.pp.m(short, int, byte, int, int, java.lang.Object[]):void");
    }

    /* JADX WARN: Removed duplicated region for block: B:10:0x0028  */
    /* JADX WARN: Removed duplicated region for block: B:8:0x0020  */
    /* JADX WARN: Unsupported multi-entry loop pattern (BACK_EDGE: B:10:0x0028 -> B:11:0x0030). Please report as a decompilation issue!!! */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    private static void o(int r6, short r7, int r8, java.lang.Object[] r9) {
        /*
            int r7 = r7 + 3
            int r8 = r8 * 3
            int r8 = 115 - r8
            int r0 = r6 + 4
            byte[] r1 = com.facetec.sdk.pp.$$a
            byte[] r0 = new byte[r0]
            int r6 = r6 + 3
            r2 = 0
            if (r1 != 0) goto L15
            r3 = r1
            r4 = r2
            r1 = r7
            goto L30
        L15:
            r3 = r8
            r8 = r7
            r7 = r3
            r3 = r2
        L19:
            byte r4 = (byte) r7
            r0[r3] = r4
            int r4 = r3 + 1
            if (r3 != r6) goto L28
            java.lang.String r6 = new java.lang.String
            r6.<init>(r0, r2)
            r9[r2] = r6
            return
        L28:
            int r8 = r8 + 1
            r3 = r1[r8]
            r5 = r1
            r1 = r8
            r8 = r3
            r3 = r5
        L30:
            int r7 = r7 + r8
            int r7 = r7 + (-2)
            r8 = r1
            r1 = r3
            r3 = r4
            goto L19
        */
        throw new UnsupportedOperationException("Method not decompiled: com.facetec.sdk.pp.o(int, short, int, java.lang.Object[]):void");
    }

    /* JADX WARN: Removed duplicated region for block: B:10:0x0026  */
    /* JADX WARN: Removed duplicated region for block: B:8:0x001e  */
    /* JADX WARN: Unsupported multi-entry loop pattern (BACK_EDGE: B:10:0x0026 -> B:11:0x002e). Please report as a decompilation issue!!! */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    private static void p(short r6, byte r7, int r8, java.lang.Object[] r9) {
        /*
            int r8 = r8 * 4
            int r8 = 1 - r8
            byte[] r0 = com.facetec.sdk.pp.$$d
            int r7 = r7 * 3
            int r7 = 4 - r7
            int r6 = r6 + 97
            byte[] r1 = new byte[r8]
            r2 = 0
            if (r0 != 0) goto L16
            r3 = r0
            r4 = r2
            r0 = r7
            r7 = r8
            goto L2e
        L16:
            r3 = r2
        L17:
            byte r4 = (byte) r6
            r1[r3] = r4
            int r3 = r3 + 1
            if (r3 != r8) goto L26
            java.lang.String r6 = new java.lang.String
            r6.<init>(r1, r2)
            r9[r2] = r6
            return
        L26:
            r4 = r0[r7]
            r5 = r7
            r7 = r6
            r6 = r4
            r4 = r3
            r3 = r0
            r0 = r5
        L2e:
            int r6 = -r6
            int r6 = r6 + r7
            int r7 = r0 + 1
            r0 = r3
            r3 = r4
            goto L17
        */
        throw new UnsupportedOperationException("Method not decompiled: com.facetec.sdk.pp.p(short, byte, int, java.lang.Object[]):void");
    }

    @Override // com.facetec.sdk.pt
    public final X509Certificate d(X509Certificate x509Certificate) {
        int i2 = n + 115;
        k = i2 % 128;
        if (i2 % 2 == 0) {
            this.c.get(x509Certificate.getIssuerX500Principal());
            throw null;
        }
        Set<X509Certificate> set = this.c.get(x509Certificate.getIssuerX500Principal());
        if (set == null) {
            n = (k + 77) % 128;
            return null;
        }
        Iterator<X509Certificate> it = set.iterator();
        n = (k + 23) % 128;
        while (!(!it.hasNext())) {
            X509Certificate next = it.next();
            try {
                x509Certificate.verify(next.getPublicKey());
                return next;
            } catch (Exception unused) {
            }
        }
        return null;
    }

    public final boolean equals(Object obj) {
        if (obj == this) {
            int i2 = n + 57;
            k = i2 % 128;
            return i2 % 2 != 0;
        }
        if (!(obj instanceof pp) || !((pp) obj).c.equals(this.c)) {
            return false;
        }
        k = (n + 13) % 128;
        return true;
    }

    public final int hashCode() {
        n = (k + 65) % 128;
        int iHashCode = this.c.hashCode();
        int i2 = k + 103;
        n = i2 % 128;
        if (i2 % 2 == 0) {
            return iHashCode;
        }
        throw null;
    }
}