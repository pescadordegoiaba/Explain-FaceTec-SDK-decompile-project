package com.facetec.sdk;

import java.io.IOException;
import java.io.InputStream;
import java.io.InterruptedIOException;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.atomic.AtomicBoolean;
import net.sf.scuba.smartcards.ISO7816;

/* JADX INFO: loaded from: classes4.dex */
public final class pq {
    private final AtomicBoolean d = new AtomicBoolean(false);
    private final CountDownLatch f = new CountDownLatch(1);

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    private byte[] f95946g;
    private byte[] h;
    private static final byte[] b = {ISO7816.INS_PSO};
    private static final String[] c = new String[0];
    private static final String[] e = {"*"};
    private static final pq a = new pq();

    public static pq b() {
        return a;
    }

    private static String c(byte[] bArr, byte[][] bArr2, int i) {
        int i2;
        boolean z;
        int i3;
        int i4;
        int length = bArr.length;
        int i5 = 0;
        while (i5 < length) {
            int i6 = (i5 + length) / 2;
            while (i6 >= 0 && bArr[i6] != 10) {
                i6--;
            }
            int i7 = i6 + 1;
            int i8 = 1;
            while (true) {
                i2 = i7 + i8;
                if (bArr[i2] == 10) {
                    break;
                }
                i8++;
            }
            int i9 = i2 - i7;
            int i10 = i;
            boolean z2 = false;
            int i11 = 0;
            int i12 = 0;
            while (true) {
                if (z2) {
                    i3 = 46;
                    z = false;
                } else {
                    z = z2;
                    i3 = bArr2[i10][i11] & 255;
                }
                i4 = i3 - (bArr[i7 + i12] & 255);
                if (i4 != 0) {
                    break;
                }
                i12++;
                i11++;
                if (i12 == i9) {
                    break;
                }
                if (bArr2[i10].length != i11) {
                    z2 = z;
                } else {
                    if (i10 == bArr2.length - 1) {
                        break;
                    }
                    i10++;
                    i11 = -1;
                    z2 = true;
                }
            }
            if (i4 >= 0) {
                if (i4 <= 0) {
                    int i13 = i9 - i12;
                    int length2 = bArr2[i10].length - i11;
                    while (true) {
                        i10++;
                        if (i10 >= bArr2.length) {
                            break;
                        }
                        length2 += bArr2[i10].length;
                    }
                    if (length2 >= i13) {
                        if (length2 <= i13) {
                            return new String(bArr, i7, i9, nu.e);
                        }
                    }
                }
                i5 = i2 + 1;
            }
            length = i6;
        }
        return null;
    }

    public final String[] b(String[] strArr) {
        String str;
        String strC;
        String strC2;
        InputStream resourceAsStream;
        int i = 0;
        if (this.d.get() || !this.d.compareAndSet(false, true)) {
            try {
                this.f.await();
            } catch (InterruptedException unused) {
                Thread.currentThread().interrupt();
            }
        } else {
            boolean z = false;
            while (true) {
                try {
                    try {
                        resourceAsStream = pq.class.getResourceAsStream("publicsuffixes.gz");
                        break;
                    } catch (InterruptedIOException unused2) {
                        Thread.interrupted();
                        z = true;
                    } catch (IOException e2) {
                        pm.i().a(5, "Failed to read public suffix list", e2);
                        if (z) {
                        }
                    }
                } catch (Throwable th) {
                    if (z) {
                        Thread.currentThread().interrupt();
                    }
                    throw th;
                }
            }
            if (resourceAsStream != null) {
                pz pzVarD = qf.d(new qe(qf.c(resourceAsStream)));
                try {
                    byte[] bArr = new byte[pzVarD.f()];
                    pzVarD.c(bArr);
                    byte[] bArr2 = new byte[pzVarD.f()];
                    pzVarD.c(bArr2);
                    synchronized (this) {
                        this.f95946g = bArr;
                        this.h = bArr2;
                    }
                    this.f.countDown();
                } finally {
                    nu.d(pzVarD);
                }
            }
            if (z) {
                Thread.currentThread().interrupt();
            }
        }
        synchronized (this) {
            if (this.f95946g == null) {
                throw new IllegalStateException("Unable to load publicsuffixes.gz resource from the classpath.");
            }
        }
        int length = strArr.length;
        byte[][] bArr3 = new byte[length][];
        for (int i2 = 0; i2 < strArr.length; i2++) {
            bArr3[i2] = strArr[i2].getBytes(nu.e);
        }
        int i3 = 0;
        while (true) {
            str = null;
            if (i3 >= length) {
                strC = null;
                break;
            }
            strC = c(this.f95946g, bArr3, i3);
            if (strC != null) {
                break;
            }
            i3++;
        }
        if (length > 1) {
            byte[][] bArr4 = (byte[][]) bArr3.clone();
            for (int i4 = 0; i4 < bArr4.length - 1; i4++) {
                bArr4[i4] = b;
                strC2 = c(this.f95946g, bArr4, i4);
                if (strC2 != null) {
                    break;
                }
            }
            strC2 = null;
        } else {
            strC2 = null;
        }
        if (strC2 != null) {
            while (true) {
                if (i >= length - 1) {
                    break;
                }
                String strC3 = c(this.h, bArr3, i);
                if (strC3 != null) {
                    str = strC3;
                    break;
                }
                i++;
            }
        }
        if (str != null) {
            return "!".concat(str).split("\\.");
        }
        if (strC == null && strC2 == null) {
            return e;
        }
        String[] strArrSplit = strC != null ? strC.split("\\.") : c;
        String[] strArrSplit2 = strC2 != null ? strC2.split("\\.") : c;
        return strArrSplit.length > strArrSplit2.length ? strArrSplit : strArrSplit2;
    }
}