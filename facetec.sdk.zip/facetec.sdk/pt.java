package com.facetec.sdk;

import java.security.cert.X509Certificate;

/* JADX INFO: loaded from: classes4.dex */
public interface pt {
    X509Certificate d(X509Certificate x509Certificate);
}