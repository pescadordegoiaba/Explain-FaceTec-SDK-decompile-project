package com.facetec.sdk;

import java.nio.channels.WritableByteChannel;

/* JADX INFO: loaded from: classes4.dex */
public interface pu extends qj, WritableByteChannel {
    pu a(qb qbVar);

    pu a(String str);

    pu d(byte[] bArr);

    pu d(byte[] bArr, int i, int i2);

    px d();

    pu f(int i);

    @Override // com.facetec.sdk.qj, java.io.Flushable
    void flush();

    pu g(int i);

    pu g(long j);

    pu h(int i);

    pu n(long j);

    pu p();
}