package com.facetec.sdk;

import android.text.TextUtils;
import android.view.KeyEvent;
import android.view.View;
import android.view.ViewConfiguration;
import java.io.UnsupportedEncodingException;
import java.lang.reflect.Method;
import net.sf.scuba.smartcards.ISO7816;
import net.sf.scuba.smartcards.ISOFileInfo;
import org.jmrtd.PassportService;
import org.jmrtd.lds.CVCAFile;

/* JADX INFO: loaded from: classes4.dex */
final class pv {
    private static final byte[] $$a = null;
    private static final int $$b = 0;
    private static final byte[] c;
    private static long e;

    /* JADX WARN: Removed duplicated region for block: B:10:0x0026  */
    /* JADX WARN: Removed duplicated region for block: B:8:0x0020  */
    /* JADX WARN: Unsupported multi-entry loop pattern (BACK_EDGE: B:10:0x0026 -> B:11:0x002d). Please report as a decompilation issue!!! */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    private static java.lang.String $$c(int r7, int r8, short r9) {
        /*
            byte[] r0 = com.facetec.sdk.pv.$$a
            int r8 = r8 * 4
            int r8 = 1 - r8
            int r7 = r7 * 4
            int r7 = 4 - r7
            int r9 = r9 * 4
            int r9 = 73 - r9
            byte[] r1 = new byte[r8]
            r2 = 0
            if (r0 != 0) goto L18
            r3 = r0
            r4 = r2
            r0 = r9
            r9 = r7
            goto L2d
        L18:
            r3 = r2
        L19:
            int r4 = r3 + 1
            byte r5 = (byte) r9
            r1[r3] = r5
            if (r4 != r8) goto L26
            java.lang.String r7 = new java.lang.String
            r7.<init>(r1, r2)
            return r7
        L26:
            r3 = r0[r7]
            r6 = r9
            r9 = r7
            r7 = r3
            r3 = r0
            r0 = r6
        L2d:
            int r7 = r7 + r0
            int r9 = r9 + 1
            r0 = r9
            r9 = r7
            r7 = r0
            r0 = r3
            r3 = r4
            goto L19
        */
        throw new UnsupportedOperationException("Method not decompiled: com.facetec.sdk.pv.$$c(int, int, short):java.lang.String");
    }

    static {
        init$0();
        c();
        c = new byte[]{65, CVCAFile.CAR_TAG, 67, ISO7816.INS_REHABILITATE_CHV, 69, 70, 71, 72, 73, 74, 75, 76, 77, 78, 79, 80, 81, 82, 83, 84, 85, 86, 87, 88, 89, 90, 97, ISOFileInfo.FCP_BYTE, 99, ISOFileInfo.FMD_BYTE, 101, 102, 103, 104, 105, 106, 107, 108, 109, 110, ISOFileInfo.FCI_BYTE, ISO7816.INS_MANAGE_CHANNEL, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, ISO7816.INS_DECREASE, 49, ISO7816.INS_INCREASE, 51, ISO7816.INS_DECREASE_STAMPED, 53, 54, 55, 56, 57, 43, 47};
    }

    private static void a(String str, int i, Object[] objArr) throws Throwable {
        char[] charArray = str != null ? str.toCharArray() : str;
        hl hlVar = new hl();
        char[] cArrB = hl.b(e ^ (-1723600592890876272L), charArray, i);
        hlVar.e = 4;
        while (true) {
            int i2 = hlVar.e;
            if (i2 >= cArrB.length) {
                objArr[0] = new String(cArrB, 4, cArrB.length - 4);
                return;
            }
            int i3 = i2 - 4;
            hlVar.d = i3;
            try {
                Object[] objArr2 = {Long.valueOf(cArrB[i2] ^ cArrB[i2 % 4]), Long.valueOf(i3), Long.valueOf(e)};
                Object objD = an.d(-291407824);
                if (objD == null) {
                    int iIndexOf = 2589 - TextUtils.indexOf("", "", 0);
                    char cNormalizeMetaState = (char) KeyEvent.normalizeMetaState(0);
                    int defaultSize = 23 - View.getDefaultSize(0, 0);
                    byte b = (byte) 0;
                    byte b2 = b;
                    String str$$c = $$c(b, b2, b2);
                    Class cls = Long.TYPE;
                    objD = an.d(iIndexOf, cNormalizeMetaState, defaultSize, -1732203669, false, str$$c, new Class[]{cls, cls, cls});
                }
                cArrB[i2] = ((Character) ((Method) objD).invoke(null, objArr2)).charValue();
                Object[] objArr3 = {hlVar, hlVar};
                Object objD2 = an.d(1066529625);
                if (objD2 == null) {
                    objD2 = an.d(311 - (ViewConfiguration.getZoomControlsTimeout() > 0L ? 1 : (ViewConfiguration.getZoomControlsTimeout() == 0L ? 0 : -1)), (char) (ViewConfiguration.getJumpTapTimeout() >> 16), (ViewConfiguration.getFadingEdgeLength() >> 16) + 23, 1240473602, false, "G", new Class[]{Object.class, Object.class});
                }
                ((Method) objD2).invoke(null, objArr3);
            } catch (Throwable th) {
                Throwable cause = th.getCause();
                if (cause == null) {
                    throw th;
                }
                throw cause;
            }
        }
    }

    public static void c() {
        e = 1160406142150370442L;
    }

    /* JADX WARN: Removed duplicated region for block: B:51:0x009a  */
    /* JADX WARN: Removed duplicated region for block: B:85:0x00ad A[SYNTHETIC] */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public static byte[] e(java.lang.String r18) {
        /*
            Method dump skipped, instruction units count: 312
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: com.facetec.sdk.pv.e(java.lang.String):byte[]");
    }

    public static void init$0() {
        $$a = new byte[]{ISO7816.INS_INCREASE, ISO7816.INS_UNBLOCK_CHV, ISO7816.INS_GET_DATA, 25};
        $$b = 158;
    }

    public static String e(byte[] bArr) {
        return e(bArr, c);
    }

    private static String e(byte[] bArr, byte[] bArr2) {
        byte[] bArr3 = new byte[((bArr.length + 2) / 3) << 2];
        int length = bArr.length - (bArr.length % 3);
        int i = 0;
        for (int i2 = 0; i2 < length; i2 += 3) {
            bArr3[i] = bArr2[(bArr[i2] & 255) >> 2];
            int i3 = i2 + 1;
            bArr3[i + 1] = bArr2[((bArr[i2] & 3) << 4) | ((bArr[i3] & 255) >> 4)];
            int i4 = i + 3;
            int i5 = (bArr[i3] & PassportService.SFI_DG15) << 2;
            int i6 = i2 + 2;
            bArr3[i + 2] = bArr2[i5 | ((bArr[i6] & 255) >> 6)];
            i += 4;
            bArr3[i4] = bArr2[bArr[i6] & 63];
        }
        int length2 = bArr.length % 3;
        if (length2 == 1) {
            bArr3[i] = bArr2[(bArr[length] & 255) >> 2];
            bArr3[i + 1] = bArr2[(bArr[length] & 3) << 4];
            bArr3[i + 2] = 61;
            bArr3[i + 3] = 61;
        } else if (length2 == 2) {
            bArr3[i] = bArr2[(bArr[length] & 255) >> 2];
            int i7 = (bArr[length] & 3) << 4;
            int i8 = length + 1;
            bArr3[i + 1] = bArr2[((bArr[i8] & 255) >> 4) | i7];
            bArr3[i + 2] = bArr2[(bArr[i8] & PassportService.SFI_DG15) << 2];
            bArr3[i + 3] = 61;
        }
        try {
            return new String(bArr3, "US-ASCII");
        } catch (UnsupportedEncodingException e2) {
            throw new AssertionError(e2);
        }
    }
}