package com.facetec.sdk;

import android.graphics.Color;
import android.os.Process;
import android.os.SystemClock;
import android.text.AndroidCharacter;
import android.text.TextUtils;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewConfiguration;
import android.widget.ExpandableListView;
import java.io.IOException;
import java.io.InterruptedIOException;
import java.lang.reflect.Method;
import java.util.concurrent.TimeUnit;

/* JADX INFO: loaded from: classes4.dex */
public class pw extends qp {
    private static final byte[] $$d = null;
    private static final int $$e = 0;
    private static final long c;
    private static final long d;
    static pw e;
    private static int[] h;
    private boolean a;
    private pw i;
    private long j;

    public static final class d extends Thread {
        public d() {
            super("Okio Watchdog");
            setDaemon(true);
        }

        /* JADX WARN: Code restructure failed: missing block: B:16:0x0017, code lost:
        
            r1.d();
         */
        @Override // java.lang.Thread, java.lang.Runnable
        /*
            Code decompiled incorrectly, please refer to instructions dump.
            To view partially-correct code enable 'Show inconsistent code' option in preferences
        */
        public final void run() {
            /*
                r3 = this;
            L0:
                java.lang.Class<com.facetec.sdk.pw> r0 = com.facetec.sdk.pw.class
                monitor-enter(r0)     // Catch: java.lang.InterruptedException -> L0
                com.facetec.sdk.pw r1 = com.facetec.sdk.pw.e()     // Catch: java.lang.Throwable -> Lb
                if (r1 != 0) goto Ld
                monitor-exit(r0)     // Catch: java.lang.Throwable -> Lb
                goto L0
            Lb:
                r1 = move-exception
                goto L1b
            Ld:
                com.facetec.sdk.pw r2 = com.facetec.sdk.pw.e     // Catch: java.lang.Throwable -> Lb
                if (r1 != r2) goto L16
                r1 = 0
                com.facetec.sdk.pw.e = r1     // Catch: java.lang.Throwable -> Lb
                monitor-exit(r0)     // Catch: java.lang.Throwable -> Lb
                return
            L16:
                monitor-exit(r0)     // Catch: java.lang.InterruptedException -> L0
                r1.d()     // Catch: java.lang.InterruptedException -> L0
                goto L0
            L1b:
                monitor-exit(r0)     // Catch: java.lang.InterruptedException -> L0
                throw r1     // Catch: java.lang.InterruptedException -> L0
            */
            throw new UnsupportedOperationException("Method not decompiled: com.facetec.sdk.pw.d.run():void");
        }
    }

    /* JADX WARN: Removed duplicated region for block: B:10:0x0024  */
    /* JADX WARN: Removed duplicated region for block: B:8:0x001e  */
    /* JADX WARN: Unsupported multi-entry loop pattern (BACK_EDGE: B:10:0x0024 -> B:11:0x002e). Please report as a decompilation issue!!! */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    private static java.lang.String $$f(short r6, int r7, byte r8) {
        /*
            int r8 = r8 * 3
            int r0 = r8 + 1
            int r6 = r6 * 2
            int r6 = 121 - r6
            byte[] r1 = com.facetec.sdk.pw.$$d
            int r7 = r7 + 4
            byte[] r0 = new byte[r0]
            r2 = 0
            if (r1 != 0) goto L16
            r3 = r1
            r4 = r2
            r1 = r7
            r7 = r8
            goto L2e
        L16:
            r3 = r2
        L17:
            byte r4 = (byte) r6
            int r7 = r7 + 1
            r0[r3] = r4
            if (r3 != r8) goto L24
            java.lang.String r6 = new java.lang.String
            r6.<init>(r0, r2)
            return r6
        L24:
            r4 = r1[r7]
            int r3 = r3 + 1
            r5 = r7
            r7 = r6
            r6 = r4
            r4 = r3
            r3 = r1
            r1 = r5
        L2e:
            int r6 = -r6
            int r6 = r6 + r7
            r7 = r1
            r1 = r3
            r3 = r4
            goto L17
        */
        throw new UnsupportedOperationException("Method not decompiled: com.facetec.sdk.pw.$$f(short, int, byte):java.lang.String");
    }

    static {
        init$0();
        h();
        long millis = TimeUnit.SECONDS.toMillis(60L);
        c = millis;
        d = TimeUnit.MILLISECONDS.toNanos(millis);
    }

    private static synchronized void a(pw pwVar, long j, boolean z) {
        if (e == null) {
            e = new pw();
            new d().start();
        }
        try {
            Object[] objArr = new Object[1];
            k(new int[]{228587603, -1799347475, 576007401, -1368389169, -827692095, 1877496604, -1138980654, 1467794965}, 16 - View.MeasureSpec.getMode(0), objArr);
            Class<?> cls = Class.forName((String) objArr[0]);
            Object[] objArr2 = new Object[1];
            k(new int[]{-1474493370, 520967517, -1529217850, 1375033216}, 7 - MotionEvent.axisFromString(""), objArr2);
            long jLongValue = ((Long) cls.getMethod((String) objArr2[0], null).invoke(null, null)).longValue();
            if (j != 0 && z) {
                pwVar.j = Math.min(j, pwVar.e_() - jLongValue) + jLongValue;
            } else if (j != 0) {
                pwVar.j = j + jLongValue;
            } else {
                if (!z) {
                    throw new AssertionError();
                }
                pwVar.j = pwVar.e_();
            }
            long jA = pwVar.a(jLongValue);
            pw pwVar2 = e;
            while (true) {
                pw pwVar3 = pwVar2.i;
                if (pwVar3 == null || jA < pwVar3.a(jLongValue)) {
                    break;
                } else {
                    pwVar2 = pwVar2.i;
                }
            }
            pwVar.i = pwVar2.i;
            pwVar2.i = pwVar;
            if (pwVar2 == e) {
                pw.class.notify();
            }
        } catch (Throwable th) {
            Throwable cause = th.getCause();
            if (cause == null) {
                throw th;
            }
            throw cause;
        }
    }

    public static void h() {
        h = new int[]{-1578847178, -517929005, 1384374974, 755902290, -675196354, -806644545, -1456812789, -1048152172, 2072637153, 235652925, 1315482768, 1739975225, -1727168624, 956728420, 1265515536, -1242604893, -1785207810, -1252454538};
    }

    public static void init$0() {
        $$d = new byte[]{109, 5, -57, 108};
        $$e = 16;
    }

    private static void k(int[] iArr, int i, Object[] objArr) throws Throwable {
        long j;
        int i2;
        int i3;
        char[] cArr;
        int[] iArr2;
        int i4;
        hg hgVar = new hg();
        char[] cArr2 = new char[4];
        int i5 = 2;
        char[] cArr3 = new char[iArr.length * 2];
        int[] iArr3 = h;
        char c2 = '0';
        Class cls = Integer.TYPE;
        int i6 = 0;
        if (iArr3 != null) {
            int length = iArr3.length;
            j = 0;
            int[] iArr4 = new int[length];
            int i7 = 0;
            while (i7 < length) {
                try {
                    Object[] objArr2 = {Integer.valueOf(iArr3[i7])};
                    Object objD = an.d(2027942060);
                    if (objD == null) {
                        i4 = i5;
                        int packedPositionChild = 616 - ExpandableListView.getPackedPositionChild(0L);
                        char cIndexOf = (char) ((-1) - TextUtils.indexOf("", c2, i6));
                        int iMakeMeasureSpec = 23 - View.MeasureSpec.makeMeasureSpec(i6, i6);
                        byte b = (byte) i6;
                        byte b2 = (byte) (b - 1);
                        objD = an.d(packedPositionChild, cIndexOf, iMakeMeasureSpec, 247342071, false, $$f(b, b2, (byte) (b2 + 1)), new Class[]{cls});
                    } else {
                        i4 = i5;
                    }
                    iArr4[i7] = ((Integer) ((Method) objD).invoke(null, objArr2)).intValue();
                    i7++;
                    i5 = i4;
                    c2 = '0';
                    i6 = 0;
                } catch (Throwable th) {
                    Throwable cause = th.getCause();
                    if (cause == null) {
                        throw th;
                    }
                    throw cause;
                }
            }
            iArr3 = iArr4;
        } else {
            j = 0;
        }
        int i8 = i5;
        int length2 = iArr3.length;
        int[] iArr5 = new int[length2];
        int[] iArr6 = h;
        if (iArr6 != null) {
            int length3 = iArr6.length;
            int[] iArr7 = new int[length3];
            int i9 = 0;
            while (i9 < length3) {
                Object[] objArr3 = {Integer.valueOf(iArr6[i9])};
                Object objD2 = an.d(2027942060);
                if (objD2 == null) {
                    cArr = cArr2;
                    byte b3 = (byte) 0;
                    byte b4 = (byte) (b3 - 1);
                    iArr2 = iArr6;
                    objD2 = an.d(TextUtils.getTrimmedLength("") + 617, (char) TextUtils.getOffsetBefore("", 0), Color.rgb(0, 0, 0) + 16777239, 247342071, false, $$f(b3, b4, (byte) (b4 + 1)), new Class[]{cls});
                } else {
                    cArr = cArr2;
                    iArr2 = iArr6;
                }
                iArr7[i9] = ((Integer) ((Method) objD2).invoke(null, objArr3)).intValue();
                i9++;
                cArr2 = cArr;
                iArr6 = iArr2;
            }
            iArr6 = iArr7;
        }
        char[] cArr4 = cArr2;
        char c3 = 0;
        System.arraycopy(iArr6, 0, iArr5, 0, length2);
        hgVar.c = 0;
        while (true) {
            int i10 = hgVar.c;
            if (i10 >= iArr.length) {
                objArr[0] = new String(cArr3, 0, i);
                return;
            }
            int i11 = iArr[i10];
            char c4 = (char) (i11 >> 16);
            cArr4[c3] = c4;
            char c5 = (char) i11;
            int i12 = 1;
            cArr4[1] = c5;
            int i13 = 16;
            char c6 = (char) (iArr[i10 + 1] >> 16);
            cArr4[i8] = c6;
            char c7 = (char) iArr[i10 + 1];
            cArr4[3] = c7;
            hgVar.d = (c4 << 16) + c5;
            hgVar.a = (c6 << 16) + c7;
            hg.a(iArr5);
            int i14 = 0;
            while (i14 < i13) {
                int i15 = hgVar.d ^ iArr5[i14];
                hgVar.d = i15;
                int iB = hg.b(i15);
                Object[] objArr4 = new Object[4];
                objArr4[3] = hgVar;
                objArr4[i8] = hgVar;
                objArr4[i12] = Integer.valueOf(iB);
                objArr4[0] = hgVar;
                Object objD3 = an.d(-1264699187);
                if (objD3 == null) {
                    byte b5 = (byte) i12;
                    i2 = i12;
                    byte b6 = (byte) (-b5);
                    i3 = i13;
                    objD3 = an.d(View.combineMeasuredStates(0, 0) + 1558, (char) (63316 - TextUtils.indexOf((CharSequence) "", '0')), 32 - View.resolveSize(0, 0), -1023415402, false, $$f(b5, b6, (byte) (b6 + 1)), new Class[]{Object.class, cls, Object.class, Object.class});
                } else {
                    i2 = i12;
                    i3 = i13;
                }
                int iIntValue = ((Integer) ((Method) objD3).invoke(null, objArr4)).intValue();
                hgVar.d = hgVar.a;
                hgVar.a = iIntValue;
                i14++;
                i12 = i2;
                i13 = i3;
            }
            int i16 = i12;
            int i17 = hgVar.d;
            int i18 = hgVar.a;
            hgVar.d = i18;
            hgVar.a = i17;
            int i19 = i17 ^ iArr5[i13];
            hgVar.a = i19;
            int i20 = i18 ^ iArr5[17];
            hgVar.d = i20;
            cArr4[0] = (char) (i20 >>> 16);
            cArr4[i16] = (char) i20;
            cArr4[i8] = (char) (i19 >>> 16);
            cArr4[3] = (char) i19;
            hg.a(iArr5);
            int i21 = hgVar.c;
            cArr3[i21 * 2] = cArr4[0];
            cArr3[(i21 * 2) + 1] = cArr4[i16];
            cArr3[(i21 * 2) + 2] = cArr4[i8];
            cArr3[(i21 * 2) + 3] = cArr4[3];
            int i22 = i8;
            Object[] objArr5 = new Object[i22];
            objArr5[i16] = hgVar;
            objArr5[0] = hgVar;
            Object objD4 = an.d(-204410541);
            if (objD4 == null) {
                objD4 = an.d(310 - TextUtils.getOffsetBefore("", 0), (char) (1 - (SystemClock.elapsedRealtime() > j ? 1 : (SystemClock.elapsedRealtime() == j ? 0 : -1))), 23 - (ViewConfiguration.getMinimumFlingVelocity() >> 16), -2051988984, false, "A", new Class[]{Object.class, Object.class});
            }
            ((Method) objD4).invoke(null, objArr5);
            i8 = i22;
            c3 = 0;
        }
    }

    public final void b() {
        if (this.a) {
            throw new IllegalStateException("Unbalanced enter/exit");
        }
        long jA_ = a_();
        boolean zB_ = b_();
        if (jA_ != 0 || zB_) {
            this.a = true;
            a(this, jA_, zB_);
        }
    }

    public final boolean c() {
        if (!this.a) {
            return false;
        }
        this.a = false;
        return a(this);
    }

    public void d() {
    }

    public final void e(boolean z) throws IOException {
        if (c() && z) {
            throw b(null);
        }
    }

    public static pw e() throws Throwable {
        pw pwVar = e.i;
        try {
            if (pwVar == null) {
                Object[] objArr = new Object[1];
                k(new int[]{228587603, -1799347475, 576007401, -1368389169, -827692095, 1877496604, -1138980654, 1467794965}, 16 - View.resolveSizeAndState(0, 0, 0), objArr);
                Class<?> cls = Class.forName((String) objArr[0]);
                Object[] objArr2 = new Object[1];
                k(new int[]{-1474493370, 520967517, -1529217850, 1375033216}, '8' - AndroidCharacter.getMirror('0'), objArr2);
                long jLongValue = ((Long) cls.getMethod((String) objArr2[0], null).invoke(null, null)).longValue();
                pw.class.wait(c);
                if (e.i == null) {
                    Object[] objArr3 = new Object[1];
                    k(new int[]{228587603, -1799347475, 576007401, -1368389169, -827692095, 1877496604, -1138980654, 1467794965}, (Process.myTid() >> 22) + 16, objArr3);
                    Class<?> cls2 = Class.forName((String) objArr3[0]);
                    Object[] objArr4 = new Object[1];
                    k(new int[]{-1474493370, 520967517, -1529217850, 1375033216}, 8 - Gravity.getAbsoluteGravity(0, 0), objArr4);
                    if (((Long) cls2.getMethod((String) objArr4[0], null).invoke(null, null)).longValue() - jLongValue >= d) {
                        return e;
                    }
                }
                return null;
            }
            Object[] objArr5 = new Object[1];
            k(new int[]{228587603, -1799347475, 576007401, -1368389169, -827692095, 1877496604, -1138980654, 1467794965}, AndroidCharacter.getMirror('0') - ' ', objArr5);
            Class<?> cls3 = Class.forName((String) objArr5[0]);
            Object[] objArr6 = new Object[1];
            k(new int[]{-1474493370, 520967517, -1529217850, 1375033216}, (ViewConfiguration.getTouchSlop() >> 8) + 8, objArr6);
            long jA = pwVar.a(((Long) cls3.getMethod((String) objArr6[0], null).invoke(null, null)).longValue());
            if (jA > 0) {
                long j = jA / 1000000;
                pw.class.wait(j, (int) (jA - (1000000 * j)));
                return null;
            }
            e.i = pwVar.i;
            pwVar.i = null;
            return pwVar;
        } catch (Throwable th) {
            Throwable cause = th.getCause();
            if (cause != null) {
                throw cause;
            }
            throw th;
        }
    }

    public final IOException c(IOException iOException) {
        return !c() ? iOException : b(iOException);
    }

    public IOException b(IOException iOException) {
        InterruptedIOException interruptedIOException = new InterruptedIOException("timeout");
        if (iOException != null) {
            interruptedIOException.initCause(iOException);
        }
        return interruptedIOException;
    }

    private static synchronized boolean a(pw pwVar) {
        pw pwVar2 = e;
        while (pwVar2 != null) {
            pw pwVar3 = pwVar2.i;
            if (pwVar3 == pwVar) {
                pwVar2.i = pwVar.i;
                pwVar.i = null;
                return false;
            }
            pwVar2 = pwVar3;
        }
        return true;
    }

    private long a(long j) {
        return this.j - j;
    }
}