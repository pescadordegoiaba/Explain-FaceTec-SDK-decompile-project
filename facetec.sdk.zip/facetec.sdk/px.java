package com.facetec.sdk;

import android.graphics.Color;
import android.graphics.ImageFormat;
import android.media.AudioTrack;
import android.os.Process;
import android.os.SystemClock;
import android.view.KeyEvent;
import android.view.View;
import com.incode.welcome_sdk.modules.SelfieScan;
import com.plaid.internal.EnumC41897g;
import java.io.EOFException;
import java.lang.reflect.Method;
import java.nio.ByteBuffer;
import java.nio.channels.ByteChannel;
import java.nio.charset.Charset;
import net.sf.scuba.smartcards.ISO7816;
import net.sf.scuba.smartcards.ISOFileInfo;

/* JADX INFO: loaded from: classes4.dex */
public final class px implements pu, pz, Cloneable, ByteChannel {
    private static final byte[] $$a = null;
    private static final int $$b = 0;
    private static long a;
    private static final byte[] c;
    long d;
    qk e;

    /* JADX WARN: Removed duplicated region for block: B:10:0x0025  */
    /* JADX WARN: Removed duplicated region for block: B:8:0x001f  */
    /* JADX WARN: Unsupported multi-entry loop pattern (BACK_EDGE: B:10:0x0025 -> B:11:0x002a). Please report as a decompilation issue!!! */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    private static java.lang.String $$c(short r7, int r8, short r9) {
        /*
            int r9 = r9 * 4
            int r9 = 73 - r9
            byte[] r0 = com.facetec.sdk.px.$$a
            int r7 = r7 + 4
            int r8 = r8 * 2
            int r8 = 1 - r8
            byte[] r1 = new byte[r8]
            r2 = 0
            if (r0 != 0) goto L15
            r9 = r7
            r3 = r8
            r4 = r2
            goto L2a
        L15:
            r3 = r2
        L16:
            int r7 = r7 + 1
            int r4 = r3 + 1
            byte r5 = (byte) r9
            r1[r3] = r5
            if (r4 != r8) goto L25
            java.lang.String r7 = new java.lang.String
            r7.<init>(r1, r2)
            return r7
        L25:
            r3 = r0[r7]
            r6 = r9
            r9 = r7
            r7 = r6
        L2a:
            int r7 = r7 + r3
            r3 = r9
            r9 = r7
            r7 = r3
            r3 = r4
            goto L16
        */
        throw new UnsupportedOperationException("Method not decompiled: com.facetec.sdk.px.$$c(short, int, short):java.lang.String");
    }

    static {
        init$0();
        s();
        c = new byte[]{ISO7816.INS_DECREASE, 49, ISO7816.INS_INCREASE, 51, ISO7816.INS_DECREASE_STAMPED, 53, 54, 55, 56, 57, 97, ISOFileInfo.FCP_BYTE, 99, ISOFileInfo.FMD_BYTE, 101, 102};
    }

    public static void init$0() {
        $$a = new byte[]{79, 9, 94, -7};
        $$b = 3;
    }

    private String o(long j) {
        return e(j, qq.e);
    }

    private static void r(String str, int i, Object[] objArr) throws Throwable {
        char[] charArray = str != null ? str.toCharArray() : str;
        hl hlVar = new hl();
        char[] cArrB = hl.b(a ^ (-1723600592890876272L), charArray, i);
        hlVar.e = 4;
        while (true) {
            int i2 = hlVar.e;
            if (i2 >= cArrB.length) {
                objArr[0] = new String(cArrB, 4, cArrB.length - 4);
                return;
            }
            int i3 = i2 - 4;
            hlVar.d = i3;
            try {
                Object[] objArr2 = {Long.valueOf(cArrB[i2] ^ cArrB[i2 % 4]), Long.valueOf(i3), Long.valueOf(a)};
                Object objD = an.d(-291407824);
                if (objD == null) {
                    int threadPriority = 23 - ((Process.getThreadPriority(0) + 20) >> 6);
                    byte b = (byte) ($$b - 4);
                    byte b2 = (byte) (b + 1);
                    String str$$c = $$c(b, b2, b2);
                    Class cls = Long.TYPE;
                    objD = an.d(2589 - View.getDefaultSize(0, 0), (char) ((SystemClock.currentThreadTimeMillis() > (-1L) ? 1 : (SystemClock.currentThreadTimeMillis() == (-1L) ? 0 : -1)) - 1), threadPriority, -1732203669, false, str$$c, new Class[]{cls, cls, cls});
                }
                cArrB[i2] = ((Character) ((Method) objD).invoke(null, objArr2)).charValue();
                Object[] objArr3 = {hlVar, hlVar};
                Object objD2 = an.d(1066529625);
                if (objD2 == null) {
                    objD2 = an.d(310 - (Process.myTid() >> 22), (char) KeyEvent.getDeadChar(0, 0), 23 - (KeyEvent.getMaxKeyCode() >> 16), 1240473602, false, "G", new Class[]{Object.class, Object.class});
                }
                ((Method) objD2).invoke(null, objArr3);
            } catch (Throwable th) {
                Throwable cause = th.getCause();
                if (cause == null) {
                    throw th;
                }
                throw cause;
            }
        }
    }

    public static void s() {
        a = -3818091833760705149L;
    }

    @Override // com.facetec.sdk.pz
    public final boolean b() {
        return this.d == 0;
    }

    @Override // com.facetec.sdk.pz
    public final void c(long j) throws EOFException {
        if (this.d < j) {
            throw new EOFException();
        }
    }

    public final /* synthetic */ Object clone() {
        px pxVar = new px();
        if (this.d == 0) {
            return pxVar;
        }
        qk qkVarE = this.e.e();
        pxVar.e = qkVarE;
        qkVarE.i = qkVarE;
        qkVarE.f = qkVarE;
        qk qkVar = this.e;
        while (true) {
            qkVar = qkVar.f;
            if (qkVar == this.e) {
                pxVar.d = this.d;
                return pxVar;
            }
            pxVar.e.i.e(qkVar.e());
        }
    }

    @Override // com.facetec.sdk.qj, java.io.Closeable, java.lang.AutoCloseable
    public final void close() {
    }

    @Override // com.facetec.sdk.pu, com.facetec.sdk.pz
    public final px d() {
        return this;
    }

    public final long e() {
        return this.d;
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof px)) {
            return false;
        }
        px pxVar = (px) obj;
        long j = this.d;
        if (j != pxVar.d) {
            return false;
        }
        long j2 = 0;
        if (j == 0) {
            return true;
        }
        qk qkVar = this.e;
        qk qkVar2 = pxVar.e;
        int i = qkVar.b;
        int i2 = qkVar2.b;
        while (j2 < this.d) {
            long jMin = Math.min(qkVar.c - i, qkVar2.c - i2);
            int i3 = 0;
            while (i3 < jMin) {
                int i4 = i + 1;
                int i5 = i2 + 1;
                if (qkVar.e[i] != qkVar2.e[i2]) {
                    return false;
                }
                i3++;
                i = i4;
                i2 = i5;
            }
            if (i == qkVar.c) {
                qkVar = qkVar.f;
                i = qkVar.b;
            }
            if (i2 == qkVar2.c) {
                qkVar2 = qkVar2.f;
                i2 = qkVar2.b;
            }
            j2 += jMin;
        }
        return true;
    }

    @Override // com.facetec.sdk.pu, com.facetec.sdk.qj, java.io.Flushable
    public final void flush() {
    }

    public final int hashCode() {
        qk qkVar = this.e;
        if (qkVar == null) {
            return 0;
        }
        int i = 1;
        do {
            int i2 = qkVar.c;
            for (int i3 = qkVar.b; i3 < i2; i3++) {
                i = (i * 31) + qkVar.e[i3];
            }
            qkVar = qkVar.f;
        } while (qkVar != this.e);
        return i;
    }

    @Override // com.facetec.sdk.pz
    public final short i() {
        long j = this.d;
        if (j < 2) {
            StringBuilder sb = new StringBuilder("size < 2: ");
            sb.append(this.d);
            throw new IllegalStateException(sb.toString());
        }
        qk qkVar = this.e;
        int i = qkVar.b;
        int i2 = qkVar.c;
        if (i2 - i < 2) {
            return (short) (((g() & 255) << 8) | (g() & 255));
        }
        byte[] bArr = qkVar.e;
        int i3 = i + 1;
        int i4 = (bArr[i] & 255) << 8;
        int i5 = i + 2;
        int i6 = (bArr[i3] & 255) | i4;
        this.d = j - 2;
        if (i5 == i2) {
            this.e = qkVar.a();
            qi.d(qkVar);
        } else {
            qkVar.b = i5;
        }
        return (short) i6;
    }

    @Override // java.nio.channels.Channel
    public final boolean isOpen() {
        return true;
    }

    @Override // com.facetec.sdk.pz
    public final int j() {
        return qq.b(f());
    }

    @Override // com.facetec.sdk.pz
    public final String k() {
        return b(Long.MAX_VALUE);
    }

    /* JADX WARN: Removed duplicated region for block: B:32:0x008a  */
    /* JADX WARN: Removed duplicated region for block: B:33:0x0094  */
    /* JADX WARN: Removed duplicated region for block: B:35:0x0098  */
    /* JADX WARN: Removed duplicated region for block: B:43:0x009c A[EDGE_INSN: B:43:0x009c->B:37:0x009c BREAK  A[LOOP:0: B:5:0x000b->B:45:?], SYNTHETIC] */
    @Override // com.facetec.sdk.pz
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public final long l() {
        /*
            r14 = this;
            long r0 = r14.d
            r2 = 0
            int r0 = (r0 > r2 ? 1 : (r0 == r2 ? 0 : -1))
            if (r0 == 0) goto La3
            r0 = 0
            r1 = r0
            r4 = r2
        Lb:
            com.facetec.sdk.qk r6 = r14.e
            byte[] r7 = r6.e
            int r8 = r6.b
            int r9 = r6.c
        L13:
            if (r8 >= r9) goto L88
            r10 = r7[r8]
            r11 = 48
            if (r10 < r11) goto L22
            r11 = 57
            if (r10 > r11) goto L22
            int r11 = r10 + (-48)
            goto L37
        L22:
            r11 = 97
            if (r10 < r11) goto L2d
            r11 = 102(0x66, float:1.43E-43)
            if (r10 > r11) goto L2d
            int r11 = r10 + (-87)
            goto L37
        L2d:
            r11 = 65
            if (r10 < r11) goto L6c
            r11 = 70
            if (r10 > r11) goto L6c
            int r11 = r10 + (-55)
        L37:
            r12 = -1152921504606846976(0xf000000000000000, double:-3.105036184601418E231)
            long r12 = r12 & r4
            int r12 = (r12 > r2 ? 1 : (r12 == r2 ? 0 : -1))
            if (r12 != 0) goto L47
            r10 = 4
            long r4 = r4 << r10
            long r10 = (long) r11
            long r4 = r4 | r10
            int r8 = r8 + 1
            int r0 = r0 + 1
            goto L13
        L47:
            com.facetec.sdk.px r0 = new com.facetec.sdk.px
            r0.<init>()
            com.facetec.sdk.px r0 = r0.g(r4)
            com.facetec.sdk.px r0 = r0.g(r10)
            java.lang.NumberFormatException r1 = new java.lang.NumberFormatException
            java.lang.StringBuilder r2 = new java.lang.StringBuilder
            java.lang.String r3 = "Number too large: "
            r2.<init>(r3)
            java.lang.String r0 = r0.m()
            r2.append(r0)
            java.lang.String r0 = r2.toString()
            r1.<init>(r0)
            throw r1
        L6c:
            if (r0 == 0) goto L70
            r1 = 1
            goto L88
        L70:
            java.lang.NumberFormatException r0 = new java.lang.NumberFormatException
            java.lang.StringBuilder r1 = new java.lang.StringBuilder
            java.lang.String r2 = "Expected leading [0-9a-fA-F] character but was 0x"
            r1.<init>(r2)
            java.lang.String r2 = java.lang.Integer.toHexString(r10)
            r1.append(r2)
            java.lang.String r1 = r1.toString()
            r0.<init>(r1)
            throw r0
        L88:
            if (r8 != r9) goto L94
            com.facetec.sdk.qk r7 = r6.a()
            r14.e = r7
            com.facetec.sdk.qi.d(r6)
            goto L96
        L94:
            r6.b = r8
        L96:
            if (r1 != 0) goto L9c
            com.facetec.sdk.qk r6 = r14.e
            if (r6 != 0) goto Lb
        L9c:
            long r1 = r14.d
            long r6 = (long) r0
            long r1 = r1 - r6
            r14.d = r1
            return r4
        La3:
            java.lang.IllegalStateException r0 = new java.lang.IllegalStateException
            java.lang.String r1 = "size == 0"
            r0.<init>(r1)
            throw r0
        */
        throw new UnsupportedOperationException("Method not decompiled: com.facetec.sdk.px.l():long");
    }

    public final String m() {
        try {
            return e(this.d, qq.e);
        } catch (EOFException e) {
            throw new AssertionError(e);
        }
    }

    @Override // com.facetec.sdk.pu
    public final /* synthetic */ pu p() {
        return this;
    }

    public final void q() {
        try {
            f(this.d);
        } catch (EOFException e) {
            throw new AssertionError(e);
        }
    }

    @Override // java.nio.channels.ReadableByteChannel
    public final int read(ByteBuffer byteBuffer) {
        qk qkVar = this.e;
        if (qkVar == null) {
            return -1;
        }
        int iMin = Math.min(byteBuffer.remaining(), qkVar.c - qkVar.b);
        byteBuffer.put(qkVar.e, qkVar.b, iMin);
        int i = qkVar.b + iMin;
        qkVar.b = i;
        this.d -= (long) iMin;
        if (i == qkVar.c) {
            this.e = qkVar.a();
            qi.d(qkVar);
        }
        return iMin;
    }

    @Override // com.facetec.sdk.pz
    public final long t() {
        return e((byte) 0, 0L, Long.MAX_VALUE);
    }

    public final String toString() {
        long j = this.d;
        if (j <= 2147483647L) {
            int i = (int) j;
            return (i == 0 ? qb.b : new qm(this, i)).toString();
        }
        StringBuilder sb = new StringBuilder("size > Integer.MAX_VALUE: ");
        sb.append(this.d);
        throw new IllegalArgumentException(sb.toString());
    }

    @Override // java.nio.channels.WritableByteChannel
    public final int write(ByteBuffer byteBuffer) {
        if (byteBuffer == null) {
            throw new IllegalArgumentException("source == null");
        }
        int iRemaining = byteBuffer.remaining();
        int i = iRemaining;
        while (i > 0) {
            qk qkVarB = b(1);
            int iMin = Math.min(i, 8192 - qkVarB.c);
            byteBuffer.get(qkVarB.e, qkVarB.c, iMin);
            i -= iMin;
            qkVarB.c += iMin;
        }
        this.d += (long) iRemaining;
        return iRemaining;
    }

    @Override // com.facetec.sdk.pz
    public final String b(long j) throws EOFException {
        if (j < 0) {
            throw new IllegalArgumentException("limit < 0: ".concat(String.valueOf(j)));
        }
        long j2 = j != Long.MAX_VALUE ? j + 1 : Long.MAX_VALUE;
        long jE = e((byte) 10, 0L, j2);
        if (jE != -1) {
            return d(jE);
        }
        if (j2 < e() && e(j2 - 1) == 13 && e(j2) == 10) {
            return d(j2);
        }
        px pxVar = new px();
        c(pxVar, 0L, Math.min(32L, e()));
        StringBuilder sb = new StringBuilder("\\n not found: limit=");
        sb.append(Math.min(e(), j));
        sb.append(" content=");
        sb.append(pxVar.n().e());
        sb.append((char) 8230);
        throw new EOFException(sb.toString());
    }

    public final px c(px pxVar, long j, long j2) {
        if (pxVar == null) {
            throw new IllegalArgumentException("out == null");
        }
        long j3 = j;
        qq.a(this.d, j3, j2);
        if (j2 != 0) {
            pxVar.d += j2;
            qk qkVar = this.e;
            while (true) {
                int i = qkVar.c;
                int i2 = qkVar.b;
                if (j3 < i - i2) {
                    break;
                }
                j3 -= (long) (i - i2);
                qkVar = qkVar.f;
            }
            qk qkVar2 = qkVar;
            long j4 = j2;
            while (j4 > 0) {
                qk qkVarE = qkVar2.e();
                int i3 = (int) (((long) qkVarE.b) + j3);
                qkVarE.b = i3;
                qkVarE.c = Math.min(i3 + ((int) j4), qkVarE.c);
                qk qkVar3 = pxVar.e;
                if (qkVar3 == null) {
                    qkVarE.i = qkVarE;
                    qkVarE.f = qkVarE;
                    pxVar.e = qkVarE;
                } else {
                    qkVar3.i.e(qkVarE);
                }
                j4 -= (long) (qkVarE.c - qkVarE.b);
                qkVar2 = qkVar2.f;
                j3 = 0;
            }
        }
        return this;
    }

    public final byte e(long j) {
        int i;
        long j2 = j;
        qq.a(this.d, j2, 1L);
        long j3 = this.d;
        if (j3 - j2 <= j2) {
            long j4 = j2 - j3;
            qk qkVar = this.e;
            do {
                qkVar = qkVar.i;
                int i2 = qkVar.c;
                i = qkVar.b;
                j4 += (long) (i2 - i);
            } while (j4 < 0);
            return qkVar.e[i + ((int) j4)];
        }
        qk qkVar2 = this.e;
        while (true) {
            int i3 = qkVar2.c;
            int i4 = qkVar2.b;
            long j5 = i3 - i4;
            if (j2 < j5) {
                return qkVar2.e[i4 + ((int) j2)];
            }
            j2 -= j5;
            qkVar2 = qkVar2.f;
        }
    }

    @Override // com.facetec.sdk.pz
    public final int f() {
        long j = this.d;
        if (j < 4) {
            StringBuilder sb = new StringBuilder("size < 4: ");
            sb.append(this.d);
            throw new IllegalStateException(sb.toString());
        }
        qk qkVar = this.e;
        int i = qkVar.b;
        int i2 = qkVar.c;
        if (i2 - i < 4) {
            return ((g() & 255) << 24) | ((g() & 255) << 16) | ((g() & 255) << 8) | (g() & 255);
        }
        byte[] bArr = qkVar.e;
        int i3 = ((bArr[i + 1] & 255) << 16) | ((bArr[i] & 255) << 24);
        int i4 = i + 3;
        int i5 = i3 | ((bArr[i + 2] & 255) << 8);
        int i6 = i + 4;
        int i7 = (bArr[i4] & 255) | i5;
        this.d = j - 4;
        if (i6 != i2) {
            qkVar.b = i6;
            return i7;
        }
        this.e = qkVar.a();
        qi.d(qkVar);
        return i7;
    }

    @Override // com.facetec.sdk.pz
    public final short h() {
        return qq.c(i());
    }

    @Override // com.facetec.sdk.pu
    /* JADX INFO: renamed from: j, reason: merged with bridge method [inline-methods] */
    public final px g(long j) {
        if (j == 0) {
            return g(48);
        }
        int iNumberOfTrailingZeros = (Long.numberOfTrailingZeros(Long.highestOneBit(j)) / 4) + 1;
        qk qkVarB = b(iNumberOfTrailingZeros);
        byte[] bArr = qkVarB.e;
        int i = qkVarB.c;
        for (int i2 = (i + iNumberOfTrailingZeros) - 1; i2 >= i; i2--) {
            bArr[i2] = c[(int) (15 & j)];
            j >>>= 4;
        }
        qkVarB.c += iNumberOfTrailingZeros;
        this.d += (long) iNumberOfTrailingZeros;
        return this;
    }

    public final qb n() {
        return new qb(o());
    }

    public final byte[] o() {
        try {
            return i(this.d);
        } catch (EOFException e) {
            throw new AssertionError(e);
        }
    }

    @Override // com.facetec.sdk.pz
    public final qb a(long j) {
        return new qb(i(j));
    }

    @Override // com.facetec.sdk.pz
    public final byte g() {
        long j = this.d;
        if (j != 0) {
            qk qkVar = this.e;
            int i = qkVar.b;
            int i2 = qkVar.c;
            int i3 = i + 1;
            byte b = qkVar.e[i];
            this.d = j - 1;
            if (i3 == i2) {
                this.e = qkVar.a();
                qi.d(qkVar);
                return b;
            }
            qkVar.b = i3;
            return b;
        }
        throw new IllegalStateException("size == 0");
    }

    @Override // com.facetec.sdk.pu
    /* JADX INFO: renamed from: h, reason: merged with bridge method [inline-methods] */
    public final px n(long j) {
        boolean z;
        if (j == 0) {
            return g(48);
        }
        int i = 1;
        if (j < 0) {
            j = -j;
            if (j < 0) {
                return a("-9223372036854775808");
            }
            z = true;
        } else {
            z = false;
        }
        if (j >= 100000000) {
            i = j < 1000000000000L ? j < 10000000000L ? j < 1000000000 ? 9 : 10 : j < 100000000000L ? 11 : 12 : j < 1000000000000000L ? j < 10000000000000L ? 13 : j < 100000000000000L ? 14 : 15 : j < 100000000000000000L ? j < 10000000000000000L ? 16 : 17 : j < 1000000000000000000L ? 18 : 19;
        } else if (j >= 10000) {
            i = j < 1000000 ? j < 100000 ? 5 : 6 : j < 10000000 ? 7 : 8;
        } else if (j >= 100) {
            i = j < 1000 ? 3 : 4;
        } else if (j >= 10) {
            i = 2;
        }
        if (z) {
            i++;
        }
        qk qkVarB = b(i);
        byte[] bArr = qkVarB.e;
        int i2 = qkVarB.c + i;
        while (j != 0) {
            i2--;
            bArr[i2] = c[(int) (j % 10)];
            j /= 10;
        }
        if (z) {
            bArr[i2 - 1] = 45;
        }
        qkVarB.c += i;
        this.d += (long) i;
        return this;
    }

    @Override // com.facetec.sdk.pu
    /* JADX INFO: renamed from: a, reason: merged with bridge method [inline-methods] */
    public final px d(byte[] bArr, int i, int i2) {
        int i3 = i;
        if (bArr != null) {
            long j = i2;
            qq.a(bArr.length, i3, j);
            int i4 = i2 + i3;
            while (i3 < i4) {
                qk qkVarB = b(1);
                int iMin = Math.min(i4 - i3, 8192 - qkVarB.c);
                try {
                    Object[] objArr = {bArr, Integer.valueOf(i3), qkVarB.e, Integer.valueOf(qkVarB.c), Integer.valueOf(iMin)};
                    Object[] objArr2 = new Object[1];
                    r("\ue78e卵\ue7e4䉮䨒㱂䆵௬热帯⠁洆㽱檙ӿ祅⌙蚟煽蚝", (Process.getElapsedCpuTime() > 0L ? 1 : (Process.getElapsedCpuTime() == 0L ? 0 : -1)), objArr2);
                    Class<?> cls = Class.forName((String) objArr2[0]);
                    Object[] objArr3 = new Object[1];
                    r("娲\u1754婓갵꜐텄ꈍ똇鍕끨씍躠苓", 1 - Color.argb(0, 0, 0, 0), objArr3);
                    String str = (String) objArr3[0];
                    Class cls2 = Integer.TYPE;
                    cls.getMethod(str, Object.class, cls2, Object.class, cls2, cls2).invoke(null, objArr);
                    i3 += iMin;
                    qkVarB.c += iMin;
                } catch (Throwable th) {
                    Throwable cause = th.getCause();
                    if (cause != null) {
                        throw cause;
                    }
                    throw th;
                }
            }
            this.d += j;
            return this;
        }
        throw new IllegalArgumentException("source == null");
    }

    public final String d(long j) throws EOFException {
        if (j > 0) {
            long j2 = j - 1;
            if (e(j2) == 13) {
                String strO = o(j2);
                f(2L);
                return strO;
            }
        }
        String strO2 = o(j);
        f(1L);
        return strO2;
    }

    public final px d(String str, int i, int i2) {
        char cCharAt;
        if (str == null) {
            throw new IllegalArgumentException("string == null");
        }
        if (i < 0) {
            throw new IllegalArgumentException("beginIndex < 0: ".concat(String.valueOf(i)));
        }
        if (i2 >= i) {
            if (i2 > str.length()) {
                StringBuilder sb = new StringBuilder("endIndex > string.length: ");
                sb.append(i2);
                sb.append(" > ");
                sb.append(str.length());
                throw new IllegalArgumentException(sb.toString());
            }
            while (i < i2) {
                char cCharAt2 = str.charAt(i);
                if (cCharAt2 < 128) {
                    qk qkVarB = b(1);
                    byte[] bArr = qkVarB.e;
                    int i3 = qkVarB.c - i;
                    int iMin = Math.min(i2, 8192 - i3);
                    int i4 = i + 1;
                    bArr[i + i3] = (byte) cCharAt2;
                    while (true) {
                        i = i4;
                        if (i >= iMin || (cCharAt = str.charAt(i)) >= 128) {
                            break;
                        }
                        i4 = i + 1;
                        bArr[i + i3] = (byte) cCharAt;
                    }
                    int i5 = qkVarB.c;
                    int i6 = (i3 + i) - i5;
                    qkVarB.c = i5 + i6;
                    this.d += (long) i6;
                } else {
                    if (cCharAt2 < 2048) {
                        g((cCharAt2 >> 6) | 192);
                        g((cCharAt2 & '?') | 128);
                    } else if (cCharAt2 >= 55296 && cCharAt2 <= 57343) {
                        int i7 = i + 1;
                        char cCharAt3 = i7 < i2 ? str.charAt(i7) : (char) 0;
                        if (cCharAt2 <= 56319 && cCharAt3 >= 56320 && cCharAt3 <= 57343) {
                            int i8 = (((cCharAt2 & 10239) << 10) | (9215 & cCharAt3)) + 65536;
                            g((i8 >> 18) | EnumC41897g.SDK_ASSET_ILLUSTRATION_PLAID_LOGO_CIRCLE_VALUE);
                            g(((i8 >> 12) & 63) | 128);
                            g(((i8 >> 6) & 63) | 128);
                            g((i8 & 63) | 128);
                            i += 2;
                        } else {
                            g(63);
                            i = i7;
                        }
                    } else {
                        g((cCharAt2 >> '\f') | 224);
                        g(((cCharAt2 >> 6) & 63) | 128);
                        g((cCharAt2 & '?') | 128);
                    }
                    i++;
                }
            }
            return this;
        }
        StringBuilder sb2 = new StringBuilder("endIndex < beginIndex: ");
        sb2.append(i2);
        sb2.append(" < ");
        sb2.append(i);
        throw new IllegalArgumentException(sb2.toString());
    }

    private String e(long j, Charset charset) {
        qq.a(this.d, 0L, j);
        if (charset == null) {
            throw new IllegalArgumentException("charset == null");
        }
        if (j > 2147483647L) {
            throw new IllegalArgumentException("byteCount > Integer.MAX_VALUE: ".concat(String.valueOf(j)));
        }
        if (j == 0) {
            return "";
        }
        qk qkVar = this.e;
        int i = qkVar.b;
        if (((long) i) + j > qkVar.c) {
            return new String(i(j), charset);
        }
        String str = new String(qkVar.e, i, (int) j, charset);
        int i2 = (int) (((long) qkVar.b) + j);
        qkVar.b = i2;
        this.d -= j;
        if (i2 == qkVar.c) {
            this.e = qkVar.a();
            qi.d(qkVar);
        }
        return str;
    }

    @Override // com.facetec.sdk.pu
    /* JADX INFO: renamed from: b, reason: merged with bridge method [inline-methods] */
    public final px a(qb qbVar) {
        if (qbVar != null) {
            qbVar.c(this);
            return this;
        }
        throw new IllegalArgumentException("byteString == null");
    }

    @Override // com.facetec.sdk.pu
    /* JADX INFO: renamed from: a, reason: merged with bridge method [inline-methods] */
    public final px h(int i) {
        qk qkVarB = b(4);
        byte[] bArr = qkVarB.e;
        int i2 = qkVarB.c;
        bArr[i2] = (byte) (i >>> 24);
        bArr[i2 + 1] = (byte) (i >>> 16);
        bArr[i2 + 2] = (byte) (i >>> 8);
        bArr[i2 + 3] = (byte) i;
        qkVarB.c = i2 + 4;
        this.d += 4;
        return this;
    }

    @Override // com.facetec.sdk.pu
    /* JADX INFO: renamed from: b, reason: merged with bridge method [inline-methods] */
    public final px d(byte[] bArr) {
        if (bArr != null) {
            return d(bArr, 0, bArr.length);
        }
        throw new IllegalArgumentException("source == null");
    }

    @Override // com.facetec.sdk.pz
    public final byte[] i(long j) throws Throwable {
        qq.a(this.d, 0L, j);
        if (j <= 2147483647L) {
            byte[] bArr = new byte[(int) j];
            c(bArr);
            return bArr;
        }
        throw new IllegalArgumentException("byteCount > Integer.MAX_VALUE: ".concat(String.valueOf(j)));
    }

    public final long c() {
        long j = this.d;
        if (j == 0) {
            return 0L;
        }
        qk qkVar = this.e.i;
        int i = qkVar.c;
        return (i >= 8192 || !qkVar.d) ? j : j - ((long) (i - qkVar.b));
    }

    public final qk b(int i) {
        if (i > 0 && i <= 8192) {
            qk qkVar = this.e;
            if (qkVar == null) {
                qk qkVarB = qi.b();
                this.e = qkVarB;
                qkVarB.i = qkVarB;
                qkVarB.f = qkVarB;
                return qkVarB;
            }
            qk qkVar2 = qkVar.i;
            return (qkVar2.c + i > 8192 || !qkVar2.d) ? qkVar2.e(qi.b()) : qkVar2;
        }
        throw new IllegalArgumentException();
    }

    @Override // com.facetec.sdk.pz
    public final void f(long j) throws EOFException {
        while (j > 0) {
            if (this.e != null) {
                int iMin = (int) Math.min(j, r0.c - r0.b);
                long j2 = iMin;
                this.d -= j2;
                j -= j2;
                qk qkVar = this.e;
                int i = qkVar.b + iMin;
                qkVar.b = i;
                if (i == qkVar.c) {
                    this.e = qkVar.a();
                    qi.d(qkVar);
                }
            } else {
                throw new EOFException();
            }
        }
    }

    @Override // com.facetec.sdk.pz
    public final String c(Charset charset) {
        try {
            return e(this.d, charset);
        } catch (EOFException e) {
            throw new AssertionError(e);
        }
    }

    @Override // com.facetec.sdk.pz
    public final void c(byte[] bArr) throws Throwable {
        int i = 0;
        while (i < bArr.length) {
            int iC = c(bArr, i, bArr.length - i);
            if (iC == -1) {
                throw new EOFException();
            }
            i += iC;
        }
    }

    @Override // com.facetec.sdk.qj
    public final void a(px pxVar, long j) throws Throwable {
        qk qkVarB;
        if (pxVar == null) {
            throw new IllegalArgumentException("source == null");
        }
        if (pxVar != this) {
            qq.a(pxVar.d, 0L, j);
            while (j > 0) {
                qk qkVar = pxVar.e;
                int i = qkVar.c;
                int i2 = qkVar.b;
                if (j < i - i2) {
                    qk qkVar2 = this.e;
                    qk qkVar3 = qkVar2 != null ? qkVar2.i : null;
                    if (qkVar3 != null && qkVar3.d) {
                        if ((((long) qkVar3.c) + j) - ((long) (qkVar3.a ? 0 : qkVar3.b)) <= 8192) {
                            qkVar.e(qkVar3, (int) j);
                            pxVar.d -= j;
                            this.d += j;
                            return;
                        }
                    }
                    int i3 = (int) j;
                    if (i3 > 0 && i3 <= i - i2) {
                        if (i3 >= 1024) {
                            qkVarB = qkVar.e();
                        } else {
                            qkVarB = qi.b();
                            try {
                                Object[] objArr = {qkVar.e, Integer.valueOf(qkVar.b), qkVarB.e, 0, Integer.valueOf(i3)};
                                Object[] objArr2 = new Object[1];
                                r("\ue78e卵\ue7e4䉮䨒㱂䆵௬热帯⠁洆㽱檙ӿ祅⌙蚟煽蚝", Color.rgb(0, 0, 0) + 16777217, objArr2);
                                Class<?> cls = Class.forName((String) objArr2[0]);
                                Object[] objArr3 = new Object[1];
                                r("娲\u1754婓갵꜐텄ꈍ똇鍕끨씍躠苓", KeyEvent.normalizeMetaState(0) + 1, objArr3);
                                String str = (String) objArr3[0];
                                Class cls2 = Integer.TYPE;
                                cls.getMethod(str, Object.class, cls2, Object.class, cls2, cls2).invoke(null, objArr);
                            } catch (Throwable th) {
                                Throwable cause = th.getCause();
                                if (cause == null) {
                                    throw th;
                                }
                                throw cause;
                            }
                        }
                        qkVarB.c = qkVarB.b + i3;
                        qkVar.b += i3;
                        qkVar.i.e(qkVarB);
                        pxVar.e = qkVarB;
                    } else {
                        throw new IllegalArgumentException();
                    }
                }
                qk qkVar4 = pxVar.e;
                long j2 = qkVar4.c - qkVar4.b;
                pxVar.e = qkVar4.a();
                qk qkVar5 = this.e;
                if (qkVar5 == null) {
                    this.e = qkVar4;
                    qkVar4.i = qkVar4;
                    qkVar4.f = qkVar4;
                } else {
                    qk qkVarE = qkVar5.i.e(qkVar4);
                    qk qkVar6 = qkVarE.i;
                    if (qkVar6 != qkVarE) {
                        if (qkVar6.d) {
                            int i4 = qkVarE.c - qkVarE.b;
                            if (i4 <= (8192 - qkVar6.c) + (qkVar6.a ? 0 : qkVar6.b)) {
                                qkVarE.e(qkVar6, i4);
                                qkVarE.a();
                                qi.d(qkVarE);
                            }
                        }
                    } else {
                        throw new IllegalStateException();
                    }
                }
                pxVar.d -= j2;
                this.d += j2;
                j -= j2;
            }
            return;
        }
        throw new IllegalArgumentException("source == this");
    }

    public final int c(byte[] bArr, int i, int i2) throws Throwable {
        qq.a(bArr.length, i, i2);
        qk qkVar = this.e;
        if (qkVar == null) {
            return -1;
        }
        int iMin = Math.min(i2, qkVar.c - qkVar.b);
        try {
            Object[] objArr = {qkVar.e, Integer.valueOf(qkVar.b), bArr, Integer.valueOf(i), Integer.valueOf(iMin)};
            Object[] objArr2 = new Object[1];
            r("\ue78e卵\ue7e4䉮䨒㱂䆵௬热帯⠁洆㽱檙ӿ祅⌙蚟煽蚝", -ImageFormat.getBitsPerPixel(0), objArr2);
            Class<?> cls = Class.forName((String) objArr2[0]);
            Object[] objArr3 = new Object[1];
            r("娲\u1754婓갵꜐텄ꈍ똇鍕끨씍躠苓", 1 - (AudioTrack.getMinVolume() > SelfieScan.RECOGNITION_FAIL_RESULT ? 1 : (AudioTrack.getMinVolume() == SelfieScan.RECOGNITION_FAIL_RESULT ? 0 : -1)), objArr3);
            String str = (String) objArr3[0];
            Class cls2 = Integer.TYPE;
            cls.getMethod(str, Object.class, cls2, Object.class, cls2, cls2).invoke(null, objArr);
            int i3 = qkVar.b + iMin;
            qkVar.b = i3;
            this.d -= (long) iMin;
            if (i3 == qkVar.c) {
                this.e = qkVar.a();
                qi.d(qkVar);
            }
            return iMin;
        } catch (Throwable th) {
            Throwable cause = th.getCause();
            if (cause != null) {
                throw cause;
            }
            throw th;
        }
    }

    @Override // com.facetec.sdk.pu
    /* JADX INFO: renamed from: e, reason: merged with bridge method [inline-methods] */
    public final px a(String str) {
        return d(str, 0, str.length());
    }

    public final px e(int i) {
        if (i < 128) {
            g(i);
            return this;
        }
        if (i < 2048) {
            g((i >> 6) | 192);
            g((i & 63) | 128);
            return this;
        }
        if (i < 65536) {
            if (i >= 55296 && i <= 57343) {
                g(63);
                return this;
            }
            g((i >> 12) | 224);
            g(((i >> 6) & 63) | 128);
            g((i & 63) | 128);
            return this;
        }
        if (i <= 1114111) {
            g((i >> 18) | EnumC41897g.SDK_ASSET_ILLUSTRATION_PLAID_LOGO_CIRCLE_VALUE);
            g(((i >> 12) & 63) | 128);
            g(((i >> 6) & 63) | 128);
            g((i & 63) | 128);
            return this;
        }
        StringBuilder sb = new StringBuilder("Unexpected code point: ");
        sb.append(Integer.toHexString(i));
        throw new IllegalArgumentException(sb.toString());
    }

    @Override // com.facetec.sdk.pu
    /* JADX INFO: renamed from: c, reason: merged with bridge method [inline-methods] */
    public final px g(int i) {
        qk qkVarB = b(1);
        byte[] bArr = qkVarB.e;
        int i2 = qkVarB.c;
        qkVarB.c = i2 + 1;
        bArr[i2] = (byte) i;
        this.d++;
        return this;
    }

    @Override // com.facetec.sdk.pz
    public final boolean c(qb qbVar) {
        int iH = qbVar.h();
        if (iH < 0 || this.d < iH || qbVar.h() < iH) {
            return false;
        }
        for (int i = 0; i < iH; i++) {
            if (e(i) != qbVar.e(i)) {
                return false;
            }
        }
        return true;
    }

    @Override // com.facetec.sdk.pu
    /* JADX INFO: renamed from: d, reason: merged with bridge method [inline-methods] */
    public final px f(int i) {
        qk qkVarB = b(2);
        byte[] bArr = qkVarB.e;
        int i2 = qkVarB.c;
        bArr[i2] = (byte) (i >>> 8);
        bArr[i2 + 1] = (byte) i;
        qkVarB.c = i2 + 2;
        this.d += 2;
        return this;
    }

    public final long e(ql qlVar) {
        if (qlVar == null) {
            throw new IllegalArgumentException("source == null");
        }
        long j = 0;
        while (true) {
            long jE = qlVar.e(this, 8192L);
            if (jE == -1) {
                return j;
            }
            j += jE;
        }
    }

    @Override // com.facetec.sdk.ql
    public final long e(px pxVar, long j) throws Throwable {
        if (pxVar == null) {
            throw new IllegalArgumentException("sink == null");
        }
        if (j >= 0) {
            long j2 = this.d;
            if (j2 == 0) {
                return -1L;
            }
            if (j > j2) {
                j = j2;
            }
            pxVar.a(this, j);
            return j;
        }
        throw new IllegalArgumentException("byteCount < 0: ".concat(String.valueOf(j)));
    }

    public final long e(byte b, long j, long j2) {
        qk qkVar;
        long j3 = 0;
        if (j >= 0 && j2 >= j) {
            long j4 = this.d;
            long j5 = j2 > j4 ? j4 : j2;
            if (j == j5 || (qkVar = this.e) == null) {
                return -1L;
            }
            if (j4 - j < j) {
                while (j4 > j) {
                    qkVar = qkVar.i;
                    j4 -= (long) (qkVar.c - qkVar.b);
                }
            } else {
                while (true) {
                    long j6 = ((long) (qkVar.c - qkVar.b)) + j3;
                    if (j6 >= j) {
                        break;
                    }
                    qkVar = qkVar.f;
                    j3 = j6;
                }
                j4 = j3;
            }
            long j7 = j;
            while (j4 < j5) {
                byte[] bArr = qkVar.e;
                int iMin = (int) Math.min(qkVar.c, (((long) qkVar.b) + j5) - j4);
                for (int i = (int) ((((long) qkVar.b) + j7) - j4); i < iMin; i++) {
                    if (bArr[i] == b) {
                        return ((long) (i - qkVar.b)) + j4;
                    }
                }
                j4 += (long) (qkVar.c - qkVar.b);
                qkVar = qkVar.f;
                j7 = j4;
            }
            return -1L;
        }
        throw new IllegalArgumentException(String.format("size=%s fromIndex=%s toIndex=%s", Long.valueOf(this.d), Long.valueOf(j), Long.valueOf(j2)));
    }

    @Override // com.facetec.sdk.qj
    public final qp a() {
        return qp.b;
    }
}