package com.facetec.sdk;

import java.util.concurrent.TimeUnit;

/* JADX INFO: loaded from: classes4.dex */
public final class py extends qp {
    public qp c;

    public py(qp qpVar) {
        if (qpVar == null) {
            throw new IllegalArgumentException("delegate == null");
        }
        this.c = qpVar;
    }

    @Override // com.facetec.sdk.qp
    public final long a_() {
        return this.c.a_();
    }

    @Override // com.facetec.sdk.qp
    public final qp b(long j, TimeUnit timeUnit) {
        return this.c.b(j, timeUnit);
    }

    @Override // com.facetec.sdk.qp
    public final boolean b_() {
        return this.c.b_();
    }

    @Override // com.facetec.sdk.qp
    public final qp c_() {
        return this.c.c_();
    }

    @Override // com.facetec.sdk.qp
    public final qp d(long j) {
        return this.c.d(j);
    }

    @Override // com.facetec.sdk.qp
    public final qp d_() {
        return this.c.d_();
    }

    @Override // com.facetec.sdk.qp
    public final long e_() {
        return this.c.e_();
    }

    @Override // com.facetec.sdk.qp
    public final void i() throws Throwable {
        this.c.i();
    }
}