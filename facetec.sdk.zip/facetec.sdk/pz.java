package com.facetec.sdk;

import java.nio.channels.ReadableByteChannel;
import java.nio.charset.Charset;

/* JADX INFO: loaded from: classes4.dex */
public interface pz extends ql, ReadableByteChannel {
    qb a(long j);

    String b(long j);

    boolean b();

    String c(Charset charset);

    void c(long j);

    void c(byte[] bArr);

    boolean c(qb qbVar);

    px d();

    int f();

    void f(long j);

    byte g();

    short h();

    short i();

    byte[] i(long j);

    int j();

    String k();

    long l();

    long t();
}