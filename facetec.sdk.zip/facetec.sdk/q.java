package com.facetec.sdk;

import java.nio.charset.StandardCharsets;
import java.util.ArrayList;

/* JADX INFO: loaded from: classes4.dex */
public class q {
    ArrayList<String> a;
    String b;
    String c;
    EnumC39477r d;
    String e;
    String f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    boolean f95947g;
    int h;
    String i;
    String j;

    public /* synthetic */ q() {
    }

    public static q b(byte[] bArr) {
        return (q) new em().e().b().c(new String(bArr, 0, bArr.length, StandardCharsets.UTF_8), q.class);
    }

    public q(String str, EnumC39477r enumC39477r, ArrayList<String> arrayList, String str2, String str3, String str4, String str5, boolean z) {
        this.b = str;
        this.d = enumC39477r;
        this.a = arrayList;
        this.c = null;
        this.e = str2;
        this.i = str3;
        this.j = str4;
        this.f = str5;
        this.f95947g = z;
        this.h = 0;
    }
}