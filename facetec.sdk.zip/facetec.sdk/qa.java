package com.facetec.sdk;

import android.content.Context;
import com.facetec.sdk.cb;
import java.lang.reflect.Method;
import net.sf.scuba.smartcards.ISO7816;
import org.jmrtd.PassportService;
import org.jmrtd.lds.CVCAFile;

/* JADX INFO: loaded from: classes4.dex */
public abstract class qa implements qj {
    private static final byte[] $$a = null;
    private static final int $$b = 0;
    private static int c;
    private static int e;
    private final qj b;

    static {
        init$0();
        e = 0;
        c = 1;
    }

    public qa(qj qjVar) {
        if (qjVar == null) {
            throw new IllegalArgumentException("delegate == null");
        }
        this.b = qjVar;
    }

    public static void d(long j, long j2) throws Throwable {
        int i = c + 115;
        e = i % 128;
        if (i % 2 != 0) {
            cb.a.class.getField("b").get(null);
            throw null;
        }
        Object obj = cb.a.class.getField("b").get(null);
        int i2 = c;
        int i3 = (i2 | 101) << 1;
        int i4 = -(((~i2) & 101) | (i2 & (-102)));
        e = (((i3 | i4) << 1) - (i4 ^ i3)) % 128;
        try {
            Object[] objArr = {null, obj};
            byte[] bArr = $$a;
            byte b = (byte) (-bArr[9]);
            byte b2 = b;
            Object[] objArr2 = new Object[1];
            f(b, b2, (byte) (b2 - 1), objArr2);
            Class<?> cls = Class.forName((String) objArr2[0]);
            byte b3 = bArr[9];
            byte b4 = (byte) (b3 + 1);
            Object[] objArr3 = new Object[1];
            f(b4, b4, (byte) (-b3), objArr3);
            Method method = cls.getMethod((String) objArr3[0], Context.class, cb.a.class);
            method.setAccessible(true);
            method.invoke(null, objArr);
            int i5 = c;
            int i6 = (i5 | 69) << 1;
            int i7 = -(((~i5) & 69) | (i5 & (-70)));
            e = ((i6 & i7) + (i7 | i6)) % 128;
        } catch (Throwable th) {
            Throwable cause = th.getCause();
            if (cause == null) {
                throw th;
            }
            throw cause;
        }
    }

    /* JADX WARN: Removed duplicated region for block: B:10:0x0029  */
    /* JADX WARN: Removed duplicated region for block: B:8:0x0021  */
    /* JADX WARN: Unsupported multi-entry loop pattern (BACK_EDGE: B:10:0x0029 -> B:11:0x002d). Please report as a decompilation issue!!! */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    private static void f(int r5, byte r6, int r7, java.lang.Object[] r8) {
        /*
            int r6 = r6 * 17
            int r6 = 20 - r6
            int r5 = r5 * 2
            int r5 = 101 - r5
            byte[] r0 = com.facetec.sdk.qa.$$a
            int r7 = r7 * 17
            int r1 = 18 - r7
            byte[] r1 = new byte[r1]
            int r7 = 17 - r7
            r2 = 0
            if (r0 != 0) goto L19
            r4 = r5
            r5 = r7
            r3 = r2
            goto L2d
        L19:
            r3 = r2
        L1a:
            byte r4 = (byte) r5
            int r6 = r6 + 1
            r1[r3] = r4
            if (r3 != r7) goto L29
            java.lang.String r5 = new java.lang.String
            r5.<init>(r1, r2)
            r8[r2] = r5
            return
        L29:
            r4 = r0[r6]
            int r3 = r3 + 1
        L2d:
            int r5 = r5 + r4
            int r5 = r5 + 3
            goto L1a
        */
        throw new UnsupportedOperationException("Method not decompiled: com.facetec.sdk.qa.f(int, byte, int, java.lang.Object[]):void");
    }

    public static void init$0() {
        $$a = new byte[]{81, 99, 107, 124, 9, -5, -66, 53, -8, -1, -1, PassportService.SFI_DG12, -18, -5, -56, CVCAFile.CAR_TAG, -18, 4, ISO7816.INS_GET_RESPONSE, ISO7816.INS_INCREASE, -4};
        $$b = 45;
    }

    @Override // com.facetec.sdk.qj
    public void a(px pxVar, long j) {
        this.b.a(pxVar, j);
    }

    @Override // com.facetec.sdk.qj, java.io.Closeable, java.lang.AutoCloseable
    public void close() {
        this.b.close();
    }

    @Override // com.facetec.sdk.qj, java.io.Flushable
    public void flush() {
        this.b.flush();
    }

    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append(getClass().getSimpleName());
        sb.append("(");
        sb.append(this.b.toString());
        sb.append(")");
        return sb.toString();
    }

    @Override // com.facetec.sdk.qj
    public final qp a() {
        return this.b.a();
    }
}