package com.facetec.sdk;

import android.graphics.Color;
import android.graphics.drawable.Drawable;
import android.os.Process;
import android.text.TextUtils;
import android.view.View;
import android.view.ViewConfiguration;
import android.widget.ExpandableListView;
import com.incode.welcome_sdk.modules.SelfieScan;
import java.io.EOFException;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.Arrays;
import net.sf.scuba.smartcards.ISO7816;
import org.bouncycastle.i18n.LocalizedMessage;
import org.bouncycastle.pqc.jcajce.spec.McElieceCCA2KeyGenParameterSpec;
import org.jmrtd.PassportService;

/* JADX INFO: loaded from: classes4.dex */
public class qb implements Serializable, Comparable<qb> {
    private static final byte[] $$a = null;
    private static final int $$b = 0;
    public static final qb b;
    private static char[] c;
    private static int f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    private static char[] f95948g;
    private static boolean i;
    private static boolean j;
    private transient String a;
    final byte[] d;
    transient int e;

    private static String $$c(int i2, int i3, int i4) {
        int i5 = 118 - i4;
        byte[] bArr = $$a;
        int i6 = i3 * 2;
        int i7 = (i2 * 4) + 4;
        byte[] bArr2 = new byte[i6 + 1];
        int i8 = -1;
        if (bArr == null) {
            i5 = (-i5) + i6;
            i7++;
            bArr = bArr;
            i8 = -1;
        }
        while (true) {
            int i9 = i8 + 1;
            bArr2[i9] = (byte) i5;
            if (i9 == i6) {
                return new String(bArr2, 0);
            }
            i5 = (-bArr[i7]) + i5;
            i7++;
            bArr = bArr;
            i8 = i9;
        }
    }

    static {
        init$0();
        g();
        c = new char[]{'0', '1', '2', '3', '4', '5', '6', '7', '8', '9', 'a', 'b', 'c', 'd', 'e', 'f'};
        b = c(new byte[0]);
    }

    public qb(byte[] bArr) {
        this.d = bArr;
    }

    public static qb c(byte... bArr) {
        if (bArr != null) {
            return new qb((byte[]) bArr.clone());
        }
        throw new IllegalArgumentException("data == null");
    }

    public static qb d(String str) {
        if (str == null) {
            throw new IllegalArgumentException("s == null");
        }
        qb qbVar = new qb(str.getBytes(qq.e));
        qbVar.a = str;
        return qbVar;
    }

    public static void g() {
        f95948g = new char[]{8579, 8602, 8311, 8655, 8589, 8591, 8576, 8596, 8306, 8308, 8309, 8582, 8590, 8587, 8580, 8584, 8585};
        f = 1071522297;
        i = true;
        j = true;
    }

    public static void init$0() {
        $$a = new byte[]{118, 33, 67, 92};
        $$b = 115;
    }

    private static void k(int[] iArr, String str, int i2, String str2, Object[] objArr) throws Throwable {
        String str3 = str2;
        Object bytes = str3;
        if (str3 != null) {
            bytes = str3.getBytes(LocalizedMessage.DEFAULT_ENCODING);
        }
        byte[] bArr = (byte[]) bytes;
        char[] charArray = str != null ? str.toCharArray() : str;
        hn hnVar = new hn();
        char[] cArr = f95948g;
        Class cls = Integer.TYPE;
        int i3 = 0;
        if (cArr != null) {
            int length = cArr.length;
            char[] cArr2 = new char[length];
            int i4 = 0;
            while (i4 < length) {
                try {
                    Object[] objArr2 = {Integer.valueOf(cArr[i4])};
                    Object objD = an.d(-814569747);
                    if (objD == null) {
                        int packedPositionType = ExpandableListView.getPackedPositionType(0L) + 1803;
                        char cResolveOpacity = (char) (Drawable.resolveOpacity(i3, i3) + 9692);
                        int iRed = 24 - Color.red(i3);
                        byte b2 = (byte) i3;
                        byte b3 = b2;
                        objD = an.d(packedPositionType, cResolveOpacity, iRed, -1189907018, false, $$c(b2, b3, b3), new Class[]{cls});
                    }
                    cArr2[i4] = ((Character) ((Method) objD).invoke(null, objArr2)).charValue();
                    i4++;
                    i3 = 0;
                } catch (Throwable th) {
                    Throwable cause = th.getCause();
                    if (cause == null) {
                        throw th;
                    }
                    throw cause;
                }
            }
            cArr = cArr2;
        }
        Object[] objArr3 = {Integer.valueOf(f)};
        Object objD2 = an.d(-1578986303);
        if (objD2 == null) {
            byte b4 = (byte) 0;
            byte b5 = b4;
            objD2 = an.d((ViewConfiguration.getFadingEdgeLength() >> 16) + 2566, (char) (ViewConfiguration.getLongPressTimeout() >> 16), 23 - TextUtils.indexOf("", "", 0, 0), -679262310, false, $$c(b4, b5, (byte) (b5 + 1)), new Class[]{cls});
        }
        int iIntValue = ((Integer) ((Method) objD2).invoke(null, objArr3)).intValue();
        if (j) {
            int length2 = bArr.length;
            hnVar.b = length2;
            char[] cArr3 = new char[length2];
            hnVar.c = 0;
            while (true) {
                int i5 = hnVar.c;
                int i6 = hnVar.b;
                if (i5 >= i6) {
                    objArr[0] = new String(cArr3);
                    return;
                }
                cArr3[i5] = (char) (cArr[bArr[(i6 - 1) - i5] + i2] - iIntValue);
                Object[] objArr4 = {hnVar, hnVar};
                Object objD3 = an.d(717234065);
                if (objD3 == null) {
                    objD3 = an.d((ViewConfiguration.getScrollFriction() > SelfieScan.RECOGNITION_FAIL_RESULT ? 1 : (ViewConfiguration.getScrollFriction() == SelfieScan.RECOGNITION_FAIL_RESULT ? 0 : -1)) + 1969, (char) (ViewConfiguration.getLongPressTimeout() >> 16), Color.alpha(0) + 24, 1554107594, false, "x", new Class[]{Object.class, Object.class});
                }
                ((Method) objD3).invoke(null, objArr4);
            }
        } else if (i) {
            int length3 = charArray.length;
            hnVar.b = length3;
            char[] cArr4 = new char[length3];
            hnVar.c = 0;
            while (true) {
                int i7 = hnVar.c;
                int i8 = hnVar.b;
                if (i7 >= i8) {
                    objArr[0] = new String(cArr4);
                    return;
                }
                cArr4[i7] = (char) (cArr[charArray[(i8 - 1) - i7] - i2] - iIntValue);
                Object[] objArr5 = {hnVar, hnVar};
                Object objD4 = an.d(717234065);
                if (objD4 == null) {
                    objD4 = an.d(((Process.getThreadPriority(0) + 20) >> 6) + 1970, (char) (ViewConfiguration.getMaximumDrawingCacheSize() >> 24), View.resolveSizeAndState(0, 0, 0) + 24, 1554107594, false, "x", new Class[]{Object.class, Object.class});
                }
                ((Method) objD4).invoke(null, objArr5);
            }
        } else {
            int length4 = iArr.length;
            hnVar.b = length4;
            char[] cArr5 = new char[length4];
            hnVar.c = 0;
            while (true) {
                int i9 = hnVar.c;
                int i10 = hnVar.b;
                if (i9 >= i10) {
                    objArr[0] = new String(cArr5);
                    return;
                } else {
                    cArr5[i9] = (char) (cArr[iArr[(i10 - 1) - i9] - i2] - iIntValue);
                    hnVar.c = i9 + 1;
                }
            }
        }
    }

    private void readObject(ObjectInputStream objectInputStream) throws IOException {
        int i2 = objectInputStream.readInt();
        if (i2 < 0) {
            throw new IllegalArgumentException("byteCount < 0: ".concat(String.valueOf(i2)));
        }
        byte[] bArr = new byte[i2];
        int i3 = 0;
        while (i3 < i2) {
            int i4 = objectInputStream.read(bArr, i3, i2 - i3);
            if (i4 == -1) {
                throw new EOFException();
            }
            i3 += i4;
        }
        qb qbVar = new qb(bArr);
        try {
            Field declaredField = qb.class.getDeclaredField("d");
            declaredField.setAccessible(true);
            declaredField.set(this, qbVar.d);
        } catch (IllegalAccessException unused) {
            throw new AssertionError();
        } catch (NoSuchFieldException unused2) {
            throw new AssertionError();
        }
    }

    private void writeObject(ObjectOutputStream objectOutputStream) throws IOException {
        objectOutputStream.writeInt(this.d.length);
        objectOutputStream.write(this.d);
    }

    public qb a() {
        return b("SHA-256");
    }

    public qb b() {
        return b(McElieceCCA2KeyGenParameterSpec.SHA1);
    }

    @Override // java.lang.Comparable
    public /* synthetic */ int compareTo(qb qbVar) {
        qb qbVar2 = qbVar;
        int iH = h();
        int iH2 = qbVar2.h();
        int iMin = Math.min(iH, iH2);
        for (int i2 = 0; i2 < iMin; i2++) {
            int iE = e(i2) & 255;
            int iE2 = qbVar2.e(i2) & 255;
            if (iE != iE2) {
                return iE < iE2 ? -1 : 1;
            }
        }
        if (iH == iH2) {
            return 0;
        }
        return iH < iH2 ? -1 : 1;
    }

    public String e() {
        byte[] bArr = this.d;
        char[] cArr = new char[bArr.length << 1];
        int i2 = 0;
        for (byte b2 : bArr) {
            int i3 = i2 + 1;
            char[] cArr2 = c;
            cArr[i2] = cArr2[(b2 >> 4) & 15];
            i2 += 2;
            cArr[i3] = cArr2[b2 & PassportService.SFI_DG15];
        }
        return new String(cArr);
    }

    public boolean equals(Object obj) {
        if (obj == this) {
            return true;
        }
        if (obj instanceof qb) {
            qb qbVar = (qb) obj;
            int iH = qbVar.h();
            byte[] bArr = this.d;
            if (iH == bArr.length && qbVar.e(0, bArr, 0, bArr.length)) {
                return true;
            }
        }
        return false;
    }

    public qb f() {
        int i2 = 0;
        while (true) {
            byte[] bArr = this.d;
            if (i2 >= bArr.length) {
                return this;
            }
            byte b2 = bArr[i2];
            if (b2 >= 65 && b2 <= 90) {
                byte[] bArr2 = (byte[]) bArr.clone();
                bArr2[i2] = (byte) (b2 + ISO7816.INS_VERIFY);
                for (int i3 = i2 + 1; i3 < bArr2.length; i3++) {
                    byte b3 = bArr2[i3];
                    if (b3 >= 65 && b3 <= 90) {
                        bArr2[i3] = (byte) (b3 + ISO7816.INS_VERIFY);
                    }
                }
                return new qb(bArr2);
            }
            i2++;
        }
    }

    public int h() {
        return this.d.length;
    }

    public int hashCode() {
        int i2 = this.e;
        if (i2 != 0) {
            return i2;
        }
        int iHashCode = Arrays.hashCode(this.d);
        this.e = iHashCode;
        return iHashCode;
    }

    public byte[] i() {
        return (byte[]) this.d.clone();
    }

    /* JADX WARN: Code restructure failed: missing block: B:19:0x0032, code lost:
    
        r3 = -1;
     */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public java.lang.String toString() {
        /*
            Method dump skipped, instruction units count: 213
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: com.facetec.sdk.qb.toString():java.lang.String");
    }

    public static qb a(String str) {
        if (str == null) {
            throw new IllegalArgumentException("base64 == null");
        }
        byte[] bArrE = pv.e(str);
        if (bArrE != null) {
            return new qb(bArrE);
        }
        return null;
    }

    private qb b(String str) {
        try {
            return c(MessageDigest.getInstance(str).digest(this.d));
        } catch (NoSuchAlgorithmException e) {
            throw new AssertionError(e);
        }
    }

    public String c() {
        return pv.e(this.d);
    }

    public void c(px pxVar) {
        byte[] bArr = this.d;
        pxVar.d(bArr, 0, bArr.length);
    }

    public String d() {
        String str = this.a;
        if (str != null) {
            return str;
        }
        String str2 = new String(this.d, qq.e);
        this.a = str2;
        return str2;
    }

    public qb a(int i2, int i3) throws Throwable {
        if (i2 >= 0) {
            byte[] bArr = this.d;
            if (i3 > bArr.length) {
                StringBuilder sb = new StringBuilder("endIndex > length(");
                sb.append(this.d.length);
                sb.append(")");
                throw new IllegalArgumentException(sb.toString());
            }
            int i4 = i3 - i2;
            if (i4 >= 0) {
                if (i2 == 0 && i3 == bArr.length) {
                    return this;
                }
                byte[] bArr2 = new byte[i4];
                try {
                    Object[] objArr = {bArr, Integer.valueOf(i2), bArr2, 0, Integer.valueOf(i4)};
                    Object[] objArr2 = new Object[1];
                    k(null, null, 127 - TextUtils.getOffsetBefore("", 0), "\u008d\u008c\u008b\u008a\u0089\u0088\u0084\u0087\u0086\u0082\u0085\u0084\u0082\u0083\u0082\u0081", objArr2);
                    Class<?> cls = Class.forName((String) objArr2[0]);
                    Object[] objArr3 = new Object[1];
                    k(null, null, 128 - (ViewConfiguration.getZoomControlsTimeout() > 0L ? 1 : (ViewConfiguration.getZoomControlsTimeout() == 0L ? 0 : -1)), "\u0089\u0091\u0090\u008f\u0089\u0082\u008e\u008e\u0082", objArr3);
                    String str = (String) objArr3[0];
                    Class cls2 = Integer.TYPE;
                    cls.getMethod(str, Object.class, cls2, Object.class, cls2, cls2).invoke(null, objArr);
                    return new qb(bArr2);
                } catch (Throwable th) {
                    Throwable cause = th.getCause();
                    if (cause != null) {
                        throw cause;
                    }
                    throw th;
                }
            }
            throw new IllegalArgumentException("endIndex < beginIndex");
        }
        throw new IllegalArgumentException("beginIndex < 0");
    }

    public static qb e(String str) {
        if (str.length() % 2 == 0) {
            int length = str.length() / 2;
            byte[] bArr = new byte[length];
            for (int i2 = 0; i2 < length; i2++) {
                int i3 = i2 << 1;
                bArr[i2] = (byte) ((e(str.charAt(i3)) << 4) + e(str.charAt(i3 + 1)));
            }
            return c(bArr);
        }
        throw new IllegalArgumentException("Unexpected hex string: ".concat(str));
    }

    public boolean d(int i2, qb qbVar, int i3, int i4) {
        return qbVar.e(0, this.d, 0, i4);
    }

    private static int e(char c2) {
        if (c2 >= '0' && c2 <= '9') {
            return c2 - '0';
        }
        if (c2 >= 'a' && c2 <= 'f') {
            return c2 - 'W';
        }
        if (c2 < 'A' || c2 > 'F') {
            throw new IllegalArgumentException("Unexpected hex digit: ".concat(String.valueOf(c2)));
        }
        return c2 - '7';
    }

    public byte e(int i2) {
        return this.d[i2];
    }

    public boolean e(int i2, byte[] bArr, int i3, int i4) {
        if (i2 < 0) {
            return false;
        }
        byte[] bArr2 = this.d;
        return i2 <= bArr2.length - i4 && i3 >= 0 && i3 <= bArr.length - i4 && qq.b(bArr2, i2, bArr, i3, i4);
    }
}