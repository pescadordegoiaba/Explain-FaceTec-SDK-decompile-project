package com.facetec.sdk;

/* JADX INFO: loaded from: classes4.dex */
public abstract class qc implements ql {
    private final ql b;

    public qc(ql qlVar) {
        if (qlVar == null) {
            throw new IllegalArgumentException("delegate == null");
        }
        this.b = qlVar;
    }

    @Override // com.facetec.sdk.ql
    public final qp a() {
        return this.b.a();
    }

    public final ql c() {
        return this.b;
    }

    @Override // com.facetec.sdk.ql, java.io.Closeable, java.lang.AutoCloseable
    public void close() {
        this.b.close();
    }

    @Override // com.facetec.sdk.ql
    public long e(px pxVar, long j) {
        return this.b.e(pxVar, j);
    }

    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append(getClass().getSimpleName());
        sb.append("(");
        sb.append(this.b.toString());
        sb.append(")");
        return sb.toString();
    }
}