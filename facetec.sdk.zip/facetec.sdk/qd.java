package com.facetec.sdk;

import java.nio.ByteBuffer;

/* JADX INFO: loaded from: classes4.dex */
final class qd implements pu {
    private qj b;
    private px c = new px();
    private boolean e;

    public qd(qj qjVar) {
        if (qjVar == null) {
            throw new NullPointerException("sink == null");
        }
        this.b = qjVar;
    }

    @Override // com.facetec.sdk.qj
    public final void a(px pxVar, long j) throws Throwable {
        if (this.e) {
            throw new IllegalStateException("closed");
        }
        this.c.a(pxVar, j);
        p();
    }

    @Override // com.facetec.sdk.qj, java.io.Closeable, java.lang.AutoCloseable
    public final void close() throws Throwable {
        if (this.e) {
            return;
        }
        try {
            px pxVar = this.c;
            long j = pxVar.d;
            if (j > 0) {
                this.b.a(pxVar, j);
            }
            th = null;
        } catch (Throwable th) {
            th = th;
        }
        try {
            this.b.close();
        } catch (Throwable th2) {
            if (th == null) {
                th = th2;
            }
        }
        this.e = true;
        if (th != null) {
            qq.d(th);
        }
    }

    @Override // com.facetec.sdk.pu, com.facetec.sdk.pz
    public final px d() {
        return this.c;
    }

    @Override // com.facetec.sdk.pu
    public final pu f(int i) {
        if (this.e) {
            throw new IllegalStateException("closed");
        }
        this.c.f(i);
        return p();
    }

    @Override // com.facetec.sdk.pu, com.facetec.sdk.qj, java.io.Flushable
    public final void flush() {
        if (this.e) {
            throw new IllegalStateException("closed");
        }
        px pxVar = this.c;
        long j = pxVar.d;
        if (j > 0) {
            this.b.a(pxVar, j);
        }
        this.b.flush();
    }

    @Override // com.facetec.sdk.pu
    public final pu g(int i) {
        if (this.e) {
            throw new IllegalStateException("closed");
        }
        this.c.g(i);
        return p();
    }

    @Override // com.facetec.sdk.pu
    public final pu h(int i) {
        if (this.e) {
            throw new IllegalStateException("closed");
        }
        this.c.h(i);
        return p();
    }

    @Override // java.nio.channels.Channel
    public final boolean isOpen() {
        return !this.e;
    }

    @Override // com.facetec.sdk.pu
    public final pu n(long j) {
        if (this.e) {
            throw new IllegalStateException("closed");
        }
        this.c.n(j);
        return p();
    }

    @Override // com.facetec.sdk.pu
    public final pu p() {
        if (this.e) {
            throw new IllegalStateException("closed");
        }
        long jC = this.c.c();
        if (jC > 0) {
            this.b.a(this.c, jC);
        }
        return this;
    }

    public final String toString() {
        StringBuilder sb = new StringBuilder("buffer(");
        sb.append(this.b);
        sb.append(")");
        return sb.toString();
    }

    @Override // java.nio.channels.WritableByteChannel
    public final int write(ByteBuffer byteBuffer) {
        if (this.e) {
            throw new IllegalStateException("closed");
        }
        int iWrite = this.c.write(byteBuffer);
        p();
        return iWrite;
    }

    @Override // com.facetec.sdk.pu
    public final pu d(byte[] bArr) {
        if (this.e) {
            throw new IllegalStateException("closed");
        }
        this.c.d(bArr);
        return p();
    }

    @Override // com.facetec.sdk.pu
    public final pu a(qb qbVar) {
        if (!this.e) {
            this.c.a(qbVar);
            return p();
        }
        throw new IllegalStateException("closed");
    }

    @Override // com.facetec.sdk.pu
    public final pu g(long j) {
        if (!this.e) {
            this.c.g(j);
            return p();
        }
        throw new IllegalStateException("closed");
    }

    @Override // com.facetec.sdk.pu
    public final pu d(byte[] bArr, int i, int i2) {
        if (!this.e) {
            this.c.d(bArr, i, i2);
            return p();
        }
        throw new IllegalStateException("closed");
    }

    @Override // com.facetec.sdk.pu
    public final pu a(String str) {
        if (!this.e) {
            this.c.a(str);
            return p();
        }
        throw new IllegalStateException("closed");
    }

    @Override // com.facetec.sdk.qj
    public final qp a() {
        return this.b.a();
    }
}