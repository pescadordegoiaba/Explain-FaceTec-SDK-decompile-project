package com.facetec.sdk;

import java.io.EOFException;
import java.io.IOException;
import java.util.zip.CRC32;
import java.util.zip.Inflater;

/* JADX INFO: loaded from: classes4.dex */
public final class qe implements ql {
    private final qg c;
    private final pz d;
    private final Inflater e;
    private int b = 0;
    private final CRC32 a = new CRC32();

    public qe(ql qlVar) {
        if (qlVar == null) {
            throw new IllegalArgumentException("source == null");
        }
        Inflater inflater = new Inflater(true);
        this.e = inflater;
        pz pzVarD = qf.d(qlVar);
        this.d = pzVarD;
        this.c = new qg(pzVarD, inflater);
    }

    private void b(px pxVar, long j, long j2) {
        qk qkVar = pxVar.e;
        while (true) {
            int i = qkVar.c;
            int i2 = qkVar.b;
            if (j < i - i2) {
                break;
            }
            j -= (long) (i - i2);
            qkVar = qkVar.f;
        }
        while (j2 > 0) {
            int i3 = (int) (((long) qkVar.b) + j);
            int iMin = (int) Math.min(qkVar.c - i3, j2);
            this.a.update(qkVar.e, i3, iMin);
            j2 -= (long) iMin;
            qkVar = qkVar.f;
            j = 0;
        }
    }

    private static void d(String str, int i, int i2) throws IOException {
        if (i2 != i) {
            throw new IOException(String.format("%s: actual 0x%08x != expected 0x%08x", str, Integer.valueOf(i2), Integer.valueOf(i)));
        }
    }

    @Override // com.facetec.sdk.ql
    public final qp a() {
        return this.d.a();
    }

    @Override // com.facetec.sdk.ql, java.io.Closeable, java.lang.AutoCloseable
    public final void close() {
        this.c.close();
    }

    @Override // com.facetec.sdk.ql
    public final long e(px pxVar, long j) throws IOException {
        if (j < 0) {
            throw new IllegalArgumentException("byteCount < 0: ".concat(String.valueOf(j)));
        }
        if (j == 0) {
            return 0L;
        }
        if (this.b == 0) {
            this.d.c(10L);
            byte bE = this.d.d().e(3L);
            boolean z = ((bE >> 1) & 1) == 1;
            if (z) {
                b(this.d.d(), 0L, 10L);
            }
            d("ID1ID2", 8075, this.d.i());
            this.d.f(8L);
            if (((bE >> 2) & 1) == 1) {
                this.d.c(2L);
                if (z) {
                    b(this.d.d(), 0L, 2L);
                }
                long jH = this.d.d().h();
                this.d.c(jH);
                if (z) {
                    b(this.d.d(), 0L, jH);
                }
                this.d.f(jH);
            }
            if (((bE >> 3) & 1) == 1) {
                long jT = this.d.t();
                if (jT == -1) {
                    throw new EOFException();
                }
                if (z) {
                    b(this.d.d(), 0L, jT + 1);
                }
                this.d.f(jT + 1);
            }
            if (((bE >> 4) & 1) == 1) {
                long jT2 = this.d.t();
                if (jT2 == -1) {
                    throw new EOFException();
                }
                if (z) {
                    b(this.d.d(), 0L, jT2 + 1);
                }
                this.d.f(jT2 + 1);
            }
            if (z) {
                d("FHCRC", this.d.h(), (short) this.a.getValue());
                this.a.reset();
            }
            this.b = 1;
        }
        if (this.b == 1) {
            long j2 = pxVar.d;
            long jE = this.c.e(pxVar, j);
            if (jE != -1) {
                b(pxVar, j2, jE);
                return jE;
            }
            this.b = 2;
        }
        if (this.b == 2) {
            d("CRC", this.d.j(), (int) this.a.getValue());
            d("ISIZE", this.d.j(), (int) this.e.getBytesWritten());
            this.b = 3;
            if (!this.d.b()) {
                throw new IOException("gzip finished without exhausting source");
            }
        }
        return -1L;
    }
}