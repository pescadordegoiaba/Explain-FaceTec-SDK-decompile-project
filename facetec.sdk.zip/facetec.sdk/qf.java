package com.facetec.sdk;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.Socket;
import java.net.SocketTimeoutException;
import java.util.logging.Level;
import java.util.logging.Logger;

/* JADX INFO: loaded from: classes4.dex */
public final class qf {
    static final Logger d = Logger.getLogger(qf.class.getName());

    private qf() {
    }

    private static ql a(final InputStream inputStream, final qp qpVar) {
        if (inputStream == null) {
            throw new IllegalArgumentException("in == null");
        }
        if (qpVar != null) {
            return new ql() { // from class: com.facetec.sdk.qf.4
                @Override // com.facetec.sdk.ql
                public final qp a() {
                    return qpVar;
                }

                @Override // com.facetec.sdk.ql, java.io.Closeable, java.lang.AutoCloseable
                public final void close() throws IOException {
                    inputStream.close();
                }

                @Override // com.facetec.sdk.ql
                public final long e(px pxVar, long j) throws Throwable {
                    if (j < 0) {
                        throw new IllegalArgumentException("byteCount < 0: ".concat(String.valueOf(j)));
                    }
                    if (j == 0) {
                        return 0L;
                    }
                    try {
                        qpVar.i();
                        qk qkVarB = pxVar.b(1);
                        int i = inputStream.read(qkVarB.e, qkVarB.c, (int) Math.min(j, 8192 - qkVarB.c));
                        if (i == -1) {
                            return -1L;
                        }
                        qkVarB.c += i;
                        long j2 = i;
                        pxVar.d += j2;
                        return j2;
                    } catch (AssertionError e) {
                        if (qf.e(e)) {
                            throw new IOException(e);
                        }
                        throw e;
                    }
                }

                public final String toString() {
                    StringBuilder sb = new StringBuilder("source(");
                    sb.append(inputStream);
                    sb.append(")");
                    return sb.toString();
                }
            };
        }
        throw new IllegalArgumentException("timeout == null");
    }

    public static qj c(Socket socket) throws IOException {
        if (socket == null) {
            throw new IllegalArgumentException("socket == null");
        }
        if (socket.getOutputStream() == null) {
            throw new IOException("socket's output stream == null");
        }
        final pw pwVarA = a(socket);
        final OutputStream outputStream = socket.getOutputStream();
        if (outputStream == null) {
            throw new IllegalArgumentException("out == null");
        }
        final qj qjVar = new qj() { // from class: com.facetec.sdk.qf.2
            @Override // com.facetec.sdk.qj
            public final void a(px pxVar, long j) throws Throwable {
                qq.a(pxVar.d, 0L, j);
                while (j > 0) {
                    pwVarA.i();
                    qk qkVar = pxVar.e;
                    int iMin = (int) Math.min(j, qkVar.c - qkVar.b);
                    outputStream.write(qkVar.e, qkVar.b, iMin);
                    int i = qkVar.b + iMin;
                    qkVar.b = i;
                    long j2 = iMin;
                    j -= j2;
                    pxVar.d -= j2;
                    if (i == qkVar.c) {
                        pxVar.e = qkVar.a();
                        qi.d(qkVar);
                    }
                }
            }

            @Override // com.facetec.sdk.qj, java.io.Closeable, java.lang.AutoCloseable
            public final void close() throws IOException {
                outputStream.close();
            }

            @Override // com.facetec.sdk.qj, java.io.Flushable
            public final void flush() throws IOException {
                outputStream.flush();
            }

            public final String toString() {
                StringBuilder sb = new StringBuilder("sink(");
                sb.append(outputStream);
                sb.append(")");
                return sb.toString();
            }

            @Override // com.facetec.sdk.qj
            public final qp a() {
                return pwVarA;
            }
        };
        return new qj() { // from class: com.facetec.sdk.pw.1
            private static final byte[] $$a = null;
            private static final int $$b = 0;
            private static final byte[] $$c = null;
            private static final int $$d = 0;
            private static int $10;
            private static int $11;
            private static long a;
            private static int b;
            private static int c;
            private /* synthetic */ qj e;

            /* JADX WARN: Removed duplicated region for block: B:20:0x001c  */
            /* JADX WARN: Removed duplicated region for block: B:22:0x0022  */
            /* JADX WARN: Unsupported multi-entry loop pattern (BACK_EDGE: B:22:0x0022 -> B:23:0x0024). Please report as a decompilation issue!!! */
            /*
                Code decompiled incorrectly, please refer to instructions dump.
                To view partially-correct code enable 'Show inconsistent code' option in preferences
            */
            private static java.lang.String $$e(byte r5, short r6, short r7) {
                /*
                    byte[] r0 = com.facetec.sdk.pw.AnonymousClass1.$$c
                    int r6 = r6 * 4
                    int r6 = 4 - r6
                    int r7 = r7 * 3
                    int r1 = r7 + 1
                    int r5 = 100 - r5
                    byte[] r1 = new byte[r1]
                    r2 = 0
                    if (r0 != 0) goto L14
                    r3 = r7
                    r4 = r2
                    goto L24
                L14:
                    r3 = r2
                L15:
                    byte r4 = (byte) r5
                    r1[r3] = r4
                    int r4 = r3 + 1
                    if (r3 != r7) goto L22
                    java.lang.String r5 = new java.lang.String
                    r5.<init>(r1, r2)
                    return r5
                L22:
                    r3 = r0[r6]
                L24:
                    int r5 = r5 + r3
                    int r6 = r6 + 1
                    r3 = r4
                    goto L15
                */
                throw new UnsupportedOperationException("Method not decompiled: com.facetec.sdk.pw.AnonymousClass1.$$e(byte, short, short):java.lang.String");
            }

            static {
                init$1();
                $10 = 0;
                $11 = 1;
                init$0();
                c = 0;
                b = 1;
                a = -6484855842108689199L;
            }

            public AnonymousClass1(final qj qjVar2) {
                qjVar = qjVar2;
            }

            /* JADX WARN: Removed duplicated region for block: B:104:0x01f7  */
            /* JADX WARN: Removed duplicated region for block: B:105:0x01f8  */
            /*
                Code decompiled incorrectly, please refer to instructions dump.
                To view partially-correct code enable 'Show inconsistent code' option in preferences
            */
            private static void f(java.lang.String r29, int r30, java.lang.Object[] r31) throws java.lang.Throwable {
                /*
                    Method dump skipped, instruction units count: 515
                    To view this dump change 'Code comments level' option to 'DEBUG'
                */
                throw new UnsupportedOperationException("Method not decompiled: com.facetec.sdk.pw.AnonymousClass1.f(java.lang.String, int, java.lang.Object[]):void");
            }

            /* JADX WARN: Removed duplicated region for block: B:20:0x0022  */
            /* JADX WARN: Removed duplicated region for block: B:22:0x002a  */
            /* JADX WARN: Unsupported multi-entry loop pattern (BACK_EDGE: B:22:0x002a -> B:23:0x002c). Please report as a decompilation issue!!! */
            /*
                Code decompiled incorrectly, please refer to instructions dump.
                To view partially-correct code enable 'Show inconsistent code' option in preferences
            */
            private static void g(int r6, int r7, int r8, java.lang.Object[] r9) {
                /*
                    int r7 = r7 * 3
                    int r7 = 3 - r7
                    int r8 = r8 + 98
                    byte[] r0 = com.facetec.sdk.pw.AnonymousClass1.$$a
                    int r6 = r6 * 4
                    int r6 = r6 + 1
                    byte[] r1 = new byte[r6]
                    r2 = 0
                    if (r0 != 0) goto L15
                    r3 = r6
                    r8 = r7
                    r4 = r2
                    goto L2c
                L15:
                    r3 = r8
                    r8 = r7
                    r7 = r3
                    r3 = r2
                L19:
                    int r4 = r3 + 1
                    byte r5 = (byte) r7
                    r1[r3] = r5
                    int r8 = r8 + 1
                    if (r4 != r6) goto L2a
                    java.lang.String r6 = new java.lang.String
                    r6.<init>(r1, r2)
                    r9[r2] = r6
                    return
                L2a:
                    r3 = r0[r8]
                L2c:
                    int r7 = r7 + r3
                    r3 = r4
                    goto L19
                */
                throw new UnsupportedOperationException("Method not decompiled: com.facetec.sdk.pw.AnonymousClass1.g(int, int, int, java.lang.Object[]):void");
            }

            public static void init$0() {
                $$a = new byte[]{70, 83, 77, 1};
                $$b = 81;
            }

            public static void init$1() {
                $$c = new byte[]{102, 29, -34, 39};
                $$d = 78;
            }

            /* JADX WARN: Code restructure failed: missing block: B:59:0x0054, code lost:
            
                com.facetec.sdk.pw.this.b();
             */
            /* JADX WARN: Code restructure failed: missing block: B:60:0x0059, code lost:
            
                r2.a(r12, r0);
             */
            /* JADX WARN: Code restructure failed: missing block: B:62:0x0066, code lost:
            
                r0 = move-exception;
             */
            /* JADX WARN: Code restructure failed: missing block: B:64:0x0069, code lost:
            
                r0 = move-exception;
             */
            /* JADX WARN: Code restructure failed: missing block: B:67:0x0071, code lost:
            
                throw com.facetec.sdk.pw.this.c(r0);
             */
            /* JADX WARN: Code restructure failed: missing block: B:68:0x0072, code lost:
            
                com.facetec.sdk.pw.this.e(false);
             */
            /* JADX WARN: Code restructure failed: missing block: B:69:0x0078, code lost:
            
                throw r0;
             */
            @Override // com.facetec.sdk.qj
            /*
                Code decompiled incorrectly, please refer to instructions dump.
                To view partially-correct code enable 'Show inconsistent code' option in preferences
            */
            public final void a(com.facetec.sdk.px r12, long r13) throws java.io.IOException {
                /*
                    r11 = this;
                    int r0 = com.facetec.sdk.pw.AnonymousClass1.b
                    int r0 = r0 + 17
                    int r1 = r0 % 128
                    com.facetec.sdk.pw.AnonymousClass1.c = r1
                    int r0 = r0 % 2
                    if (r0 == 0) goto L15
                    long r1 = r12.d
                    r3 = 0
                    r5 = r13
                    com.facetec.sdk.qq.a(r1, r3, r5)
                    goto L1e
                L15:
                    r9 = r13
                    long r5 = r12.d
                    r7 = 0
                    com.facetec.sdk.qq.a(r5, r7, r9)
                    r5 = r9
                L1e:
                    r13 = r5
                L1f:
                    r0 = 0
                    int r2 = (r13 > r0 ? 1 : (r13 == r0 ? 0 : -1))
                    if (r2 <= 0) goto L79
                    com.facetec.sdk.qk r2 = r12.e
                L27:
                    r3 = 65536(0x10000, double:3.2379E-319)
                    int r3 = (r0 > r3 ? 1 : (r0 == r3 ? 0 : -1))
                    if (r3 >= 0) goto L54
                    int r3 = r2.c
                    int r4 = r2.b
                    int r3 = r3 - r4
                    long r3 = (long) r3
                    long r0 = r0 + r3
                    int r3 = (r0 > r13 ? 1 : (r0 == r13 ? 0 : -1))
                    if (r3 < 0) goto L49
                    int r0 = com.facetec.sdk.pw.AnonymousClass1.c
                    int r0 = r0 + 69
                    int r1 = r0 % 128
                    com.facetec.sdk.pw.AnonymousClass1.b = r1
                    int r0 = r0 % 2
                    if (r0 == 0) goto L47
                    r0 = r13
                    goto L54
                L47:
                    r12 = 0
                    throw r12
                L49:
                    com.facetec.sdk.qk r2 = r2.f
                    int r3 = com.facetec.sdk.pw.AnonymousClass1.b
                    int r3 = r3 + 31
                    int r3 = r3 % 128
                    com.facetec.sdk.pw.AnonymousClass1.c = r3
                    goto L27
                L54:
                    com.facetec.sdk.pw r2 = com.facetec.sdk.pw.this
                    r2.b()
                    com.facetec.sdk.qj r2 = r2     // Catch: java.lang.Throwable -> L66 java.io.IOException -> L69
                    r2.a(r12, r0)     // Catch: java.lang.Throwable -> L66 java.io.IOException -> L69
                    long r13 = r13 - r0
                    com.facetec.sdk.pw r0 = com.facetec.sdk.pw.this
                    r1 = 1
                    r0.e(r1)
                    goto L1f
                L66:
                    r0 = move-exception
                    r12 = r0
                    goto L72
                L69:
                    r0 = move-exception
                    r12 = r0
                    com.facetec.sdk.pw r13 = com.facetec.sdk.pw.this     // Catch: java.lang.Throwable -> L66
                    java.io.IOException r12 = r13.c(r12)     // Catch: java.lang.Throwable -> L66
                    throw r12     // Catch: java.lang.Throwable -> L66
                L72:
                    com.facetec.sdk.pw r13 = com.facetec.sdk.pw.this
                    r14 = 0
                    r13.e(r14)
                    throw r12
                L79:
                    return
                */
                throw new UnsupportedOperationException("Method not decompiled: com.facetec.sdk.pw.AnonymousClass1.a(com.facetec.sdk.px, long):void");
            }

            @Override // com.facetec.sdk.qj, java.io.Closeable, java.lang.AutoCloseable
            public void close() throws IOException {
                b = (c + 107) % 128;
                pw.this.b();
                try {
                    try {
                        qjVar.close();
                        pw.this.e(true);
                        b = (c + 35) % 128;
                    } catch (IOException e) {
                        throw pw.this.c(e);
                    }
                } catch (Throwable th) {
                    pw.this.e(false);
                    throw th;
                }
            }

            @Override // com.facetec.sdk.qj, java.io.Flushable
            public void flush() throws IOException {
                b = (c + 15) % 128;
                pw.this.b();
                try {
                    try {
                        qjVar.flush();
                        pw.this.e(true);
                        b = (c + 55) % 128;
                    } catch (IOException e) {
                        throw pw.this.c(e);
                    }
                } catch (Throwable th) {
                    pw.this.e(false);
                    throw th;
                }
            }

            public String toString() {
                StringBuilder sb = new StringBuilder("AsyncTimeout.sink(");
                sb.append(qjVar);
                sb.append(")");
                String string = sb.toString();
                int i = b + 65;
                c = i % 128;
                if (i % 2 != 0) {
                    int i2 = 43 / 0;
                }
                return string;
            }

            @Override // com.facetec.sdk.qj
            public final qp a() {
                int i = c;
                int i2 = i + 11;
                b = i2 % 128;
                if (i2 % 2 == 0) {
                    throw null;
                }
                pw pwVar = pw.this;
                b = (i + 103) % 128;
                return pwVar;
            }

            /* JADX WARN: Multi-variable type inference failed */
            /* JADX WARN: Removed duplicated region for block: B:141:0x025c A[PHI: r16
              0x025c: PHI (r16v2 java.lang.String) = (r16v31 java.lang.String), (r16v32 java.lang.String) binds: [B:134:0x020a, B:139:0x0259] A[DONT_GENERATE, DONT_INLINE]] */
            /* JADX WARN: Removed duplicated region for block: B:172:0x03e3 A[Catch: Exception -> 0x0498, TryCatch #4 {Exception -> 0x0498, blocks: (B:170:0x03dd, B:172:0x03e3, B:173:0x03e4, B:175:0x03eb, B:182:0x047f, B:188:0x049c, B:190:0x04a2, B:191:0x04a3, B:176:0x0428, B:178:0x0435, B:181:0x0478), top: B:209:0x0282, inners: #2 }] */
            /* JADX WARN: Removed duplicated region for block: B:173:0x03e4 A[Catch: Exception -> 0x0498, TryCatch #4 {Exception -> 0x0498, blocks: (B:170:0x03dd, B:172:0x03e3, B:173:0x03e4, B:175:0x03eb, B:182:0x047f, B:188:0x049c, B:190:0x04a2, B:191:0x04a3, B:176:0x0428, B:178:0x0435, B:181:0x0478), top: B:209:0x0282, inners: #2 }] */
            /* JADX WARN: Removed duplicated region for block: B:186:0x0498 A[PHI: r16
              0x0498: PHI (r16v7 ??) = (r16v6 ??), (r16v9 ??), (r16v10 ??), (r16v10 ??), (r16v13 ??) binds: [B:174:0x03e5, B:200:0x0498, B:183:0x0483, B:185:0x0496, B:167:0x03d2] A[DONT_GENERATE, DONT_INLINE]] */
            /* JADX WARN: Removed duplicated region for block: B:210:0x027a A[EXC_TOP_SPLITTER, PHI: r16
              0x027a: PHI (r16v5 ??) = (r16v26 ??), (r16v27 ??) binds: [B:142:0x0260, B:139:0x0259] A[DONT_GENERATE, DONT_INLINE], SYNTHETIC] */
            /* JADX WARN: Type inference failed for: r16v10 */
            /* JADX WARN: Type inference failed for: r16v13 */
            /* JADX WARN: Type inference failed for: r16v14 */
            /* JADX WARN: Type inference failed for: r16v26 */
            /* JADX WARN: Type inference failed for: r16v27 */
            /* JADX WARN: Type inference failed for: r16v28 */
            /* JADX WARN: Type inference failed for: r16v29 */
            /* JADX WARN: Type inference failed for: r16v3 */
            /* JADX WARN: Type inference failed for: r16v30 */
            /* JADX WARN: Type inference failed for: r16v4 */
            /* JADX WARN: Type inference failed for: r16v5 */
            /* JADX WARN: Type inference failed for: r16v6 */
            /* JADX WARN: Type inference failed for: r16v7 */
            /* JADX WARN: Type inference failed for: r16v8 */
            /* JADX WARN: Type inference failed for: r16v9 */
            /*
                Code decompiled incorrectly, please refer to instructions dump.
                To view partially-correct code enable 'Show inconsistent code' option in preferences
            */
            public static java.lang.Object[] a(android.content.Context r28, int r29, int r30, int r31) throws java.lang.Throwable {
                /*
                    Method dump skipped, instruction units count: 1349
                    To view this dump change 'Code comments level' option to 'DEBUG'
                */
                throw new UnsupportedOperationException("Method not decompiled: com.facetec.sdk.pw.AnonymousClass1.a(android.content.Context, int, int, int):java.lang.Object[]");
            }
        };
    }

    public static pz d(ql qlVar) {
        return new qh(qlVar);
    }

    public static pu e(qj qjVar) {
        return new qd(qjVar);
    }

    public static ql e(Socket socket) throws IOException {
        if (socket == null) {
            throw new IllegalArgumentException("socket == null");
        }
        if (socket.getInputStream() == null) {
            throw new IOException("socket's input stream == null");
        }
        final pw pwVarA = a(socket);
        final ql qlVarA = a(socket.getInputStream(), pwVarA);
        return new ql() { // from class: com.facetec.sdk.pw.2
            private /* synthetic */ ql a;

            public AnonymousClass2(final ql qlVarA2) {
                qlVar = qlVarA2;
            }

            @Override // com.facetec.sdk.ql
            public final qp a() {
                return pw.this;
            }

            @Override // com.facetec.sdk.ql, java.io.Closeable, java.lang.AutoCloseable
            public final void close() throws IOException {
                try {
                    try {
                        qlVar.close();
                        pw.this.e(true);
                    } catch (IOException e) {
                        throw pw.this.c(e);
                    }
                } catch (Throwable th) {
                    pw.this.e(false);
                    throw th;
                }
            }

            @Override // com.facetec.sdk.ql
            public final long e(px pxVar, long j) throws IOException {
                pw.this.b();
                try {
                    try {
                        long jE = qlVar.e(pxVar, j);
                        pw.this.e(true);
                        return jE;
                    } catch (IOException e) {
                        throw pw.this.c(e);
                    }
                } catch (Throwable th) {
                    pw.this.e(false);
                    throw th;
                }
            }

            public final String toString() {
                StringBuilder sb = new StringBuilder("AsyncTimeout.source(");
                sb.append(qlVar);
                sb.append(")");
                return sb.toString();
            }
        };
    }

    private static pw a(final Socket socket) {
        return new pw() { // from class: com.facetec.sdk.qf.5
            @Override // com.facetec.sdk.pw
            public final IOException b(IOException iOException) {
                SocketTimeoutException socketTimeoutException = new SocketTimeoutException("timeout");
                if (iOException != null) {
                    socketTimeoutException.initCause(iOException);
                }
                return socketTimeoutException;
            }

            @Override // com.facetec.sdk.pw
            public final void d() {
                try {
                    socket.close();
                } catch (AssertionError e) {
                    if (!qf.e(e)) {
                        throw e;
                    }
                    Logger logger = qf.d;
                    Level level = Level.WARNING;
                    StringBuilder sb = new StringBuilder("Failed to close timed out socket ");
                    sb.append(socket);
                    logger.log(level, sb.toString(), (Throwable) e);
                } catch (Exception e2) {
                    Logger logger2 = qf.d;
                    Level level2 = Level.WARNING;
                    StringBuilder sb2 = new StringBuilder("Failed to close timed out socket ");
                    sb2.append(socket);
                    logger2.log(level2, sb2.toString(), (Throwable) e2);
                }
            }
        };
    }

    public static boolean e(AssertionError assertionError) {
        return (assertionError.getCause() == null || assertionError.getMessage() == null || !assertionError.getMessage().contains("getsockname failed")) ? false : true;
    }

    public static ql c(InputStream inputStream) {
        return a(inputStream, new qp());
    }
}