package com.facetec.sdk;

import java.io.EOFException;
import java.io.IOException;
import java.util.zip.DataFormatException;
import java.util.zip.Inflater;

/* JADX INFO: loaded from: classes4.dex */
public final class qg implements ql {
    private final Inflater b;
    private int c;
    private final pz d;
    private boolean e;

    public qg(pz pzVar, Inflater inflater) {
        if (pzVar == null) {
            throw new IllegalArgumentException("source == null");
        }
        if (inflater == null) {
            throw new IllegalArgumentException("inflater == null");
        }
        this.d = pzVar;
        this.b = inflater;
    }

    private void c() {
        int i = this.c;
        if (i == 0) {
            return;
        }
        int remaining = i - this.b.getRemaining();
        this.c -= remaining;
        this.d.f(remaining);
    }

    @Override // com.facetec.sdk.ql
    public final qp a() {
        return this.d.a();
    }

    @Override // com.facetec.sdk.ql, java.io.Closeable, java.lang.AutoCloseable
    public final void close() {
        if (this.e) {
            return;
        }
        this.b.end();
        this.e = true;
        this.d.close();
    }

    @Override // com.facetec.sdk.ql
    public final long e(px pxVar, long j) {
        boolean z;
        if (j < 0) {
            throw new IllegalArgumentException("byteCount < 0: ".concat(String.valueOf(j)));
        }
        if (this.e) {
            throw new IllegalStateException("closed");
        }
        if (j == 0) {
            return 0L;
        }
        do {
            z = false;
            if (this.b.needsInput()) {
                c();
                if (this.b.getRemaining() != 0) {
                    throw new IllegalStateException("?");
                }
                if (this.d.b()) {
                    z = true;
                } else {
                    qk qkVar = this.d.d().e;
                    int i = qkVar.c;
                    int i2 = qkVar.b;
                    int i3 = i - i2;
                    this.c = i3;
                    this.b.setInput(qkVar.e, i2, i3);
                }
            }
            try {
                qk qkVarB = pxVar.b(1);
                int iInflate = this.b.inflate(qkVarB.e, qkVarB.c, (int) Math.min(j, 8192 - qkVarB.c));
                if (iInflate > 0) {
                    qkVarB.c += iInflate;
                    long j2 = iInflate;
                    pxVar.d += j2;
                    return j2;
                }
                if (!this.b.finished() && !this.b.needsDictionary()) {
                }
                c();
                if (qkVarB.b != qkVarB.c) {
                    return -1L;
                }
                pxVar.e = qkVarB.a();
                qi.d(qkVarB);
                return -1L;
            } catch (DataFormatException e) {
                throw new IOException(e);
            }
        } while (!z);
        throw new EOFException("source exhausted prematurely");
    }
}