package com.facetec.sdk;

import android.os.Process;
import java.io.EOFException;
import java.nio.ByteBuffer;
import java.nio.charset.Charset;

/* JADX INFO: loaded from: classes4.dex */
final class qh implements pz {
    public static int a;
    public static int d;
    private ql b;
    private px c = new px();
    private boolean e;

    public qh(ql qlVar) {
        if (qlVar == null) {
            throw new NullPointerException("source == null");
        }
        this.b = qlVar;
    }

    @Override // com.facetec.sdk.pz
    public final qb a(long j) throws EOFException {
        c(j);
        return this.c.a(j);
    }

    @Override // com.facetec.sdk.pz
    public final boolean b() {
        if (this.e) {
            throw new IllegalStateException("closed");
        }
        return this.c.b() && this.b.e(this.c, 8192L) == -1;
    }

    @Override // com.facetec.sdk.pz
    public final void c(long j) throws EOFException {
        if (!e(j)) {
            throw new EOFException();
        }
    }

    @Override // com.facetec.sdk.ql, java.io.Closeable, java.lang.AutoCloseable
    public final void close() {
        if (this.e) {
            return;
        }
        this.e = true;
        this.b.close();
        this.c.q();
    }

    @Override // com.facetec.sdk.pz
    public final px d() {
        return this.c;
    }

    @Override // com.facetec.sdk.ql
    public final long e(px pxVar, long j) {
        if (pxVar == null) {
            throw new IllegalArgumentException("sink == null");
        }
        if (j < 0) {
            throw new IllegalArgumentException("byteCount < 0: ".concat(String.valueOf(j)));
        }
        if (this.e) {
            throw new IllegalStateException("closed");
        }
        px pxVar2 = this.c;
        if (pxVar2.d == 0 && this.b.e(pxVar2, 8192L) == -1) {
            return -1L;
        }
        return this.c.e(pxVar, Math.min(j, this.c.d));
    }

    @Override // com.facetec.sdk.pz
    public final int f() throws EOFException {
        c(4L);
        return this.c.f();
    }

    @Override // com.facetec.sdk.pz
    public final byte g() throws EOFException {
        c(1L);
        return this.c.g();
    }

    @Override // com.facetec.sdk.pz
    public final short h() throws EOFException {
        c(2L);
        return this.c.h();
    }

    @Override // com.facetec.sdk.pz
    public final byte[] i(long j) throws EOFException {
        c(j);
        return this.c.i(j);
    }

    @Override // java.nio.channels.Channel
    public final boolean isOpen() {
        return !this.e;
    }

    @Override // com.facetec.sdk.pz
    public final int j() throws EOFException {
        c(4L);
        return this.c.j();
    }

    @Override // com.facetec.sdk.pz
    public final String k() {
        return b(Long.MAX_VALUE);
    }

    @Override // com.facetec.sdk.pz
    public final long l() throws EOFException {
        byte bE;
        c(1L);
        int i = 0;
        while (true) {
            int i2 = i + 1;
            if (!e(i2)) {
                break;
            }
            bE = this.c.e(i);
            if ((bE < 48 || bE > 57) && ((bE < 97 || bE > 102) && (bE < 65 || bE > 70))) {
                break;
            }
            i = i2;
        }
        if (i == 0) {
            throw new NumberFormatException(String.format("Expected leading [0-9a-fA-F] character but was %#x", Byte.valueOf(bE)));
        }
        return this.c.l();
    }

    @Override // java.nio.channels.ReadableByteChannel
    public final int read(ByteBuffer byteBuffer) {
        px pxVar = this.c;
        if (pxVar.d == 0 && this.b.e(pxVar, 8192L) == -1) {
            return -1;
        }
        return this.c.read(byteBuffer);
    }

    @Override // com.facetec.sdk.pz
    public final long t() {
        return e((byte) 0, 0L, Long.MAX_VALUE);
    }

    public final String toString() {
        StringBuilder sb = new StringBuilder("buffer(");
        sb.append(this.b);
        sb.append(")");
        return sb.toString();
    }

    @Override // com.facetec.sdk.pz
    public final void c(byte[] bArr) throws Throwable {
        try {
            c(bArr.length);
            this.c.c(bArr);
        } catch (EOFException e) {
            int i = 0;
            while (true) {
                px pxVar = this.c;
                long j = pxVar.d;
                if (j <= 0) {
                    throw e;
                }
                int iC = pxVar.c(bArr, i, (int) j);
                if (iC == -1) {
                    throw new AssertionError();
                }
                i += iC;
            }
        }
    }

    @Override // com.facetec.sdk.ql
    public final qp a() {
        return this.b.a();
    }

    @Override // com.facetec.sdk.pz
    public final void f(long j) throws EOFException {
        if (this.e) {
            throw new IllegalStateException("closed");
        }
        while (j > 0) {
            px pxVar = this.c;
            if (pxVar.d == 0 && this.b.e(pxVar, 8192L) == -1) {
                throw new EOFException();
            }
            long jMin = Math.min(j, this.c.e());
            this.c.f(jMin);
            j -= jMin;
        }
    }

    @Override // com.facetec.sdk.pz
    public final short i() throws EOFException {
        c(2L);
        return this.c.i();
    }

    @Override // com.facetec.sdk.pz
    public final String b(long j) throws EOFException {
        if (j >= 0) {
            long j2 = j == Long.MAX_VALUE ? Long.MAX_VALUE : j + 1;
            long jE = e((byte) 10, 0L, j2);
            if (jE != -1) {
                return this.c.d(jE);
            }
            if (j2 < Long.MAX_VALUE && e(j2) && this.c.e(j2 - 1) == 13 && e(j2 + 1) && this.c.e(j2) == 10) {
                return this.c.d(j2);
            }
            px pxVar = new px();
            px pxVar2 = this.c;
            pxVar2.c(pxVar, 0L, Math.min(32L, pxVar2.e()));
            StringBuilder sb = new StringBuilder("\\n not found: limit=");
            sb.append(Math.min(this.c.e(), j));
            sb.append(" content=");
            sb.append(pxVar.n().e());
            sb.append((char) 8230);
            throw new EOFException(sb.toString());
        }
        throw new IllegalArgumentException("limit < 0: ".concat(String.valueOf(j)));
    }

    @Override // com.facetec.sdk.pz
    public final String c(Charset charset) {
        if (charset != null) {
            this.c.e(this.b);
            return this.c.c(charset);
        }
        throw new IllegalArgumentException("charset == null");
    }

    private boolean e(long j) {
        px pxVar;
        if (j >= 0) {
            if (this.e) {
                throw new IllegalStateException("closed");
            }
            do {
                pxVar = this.c;
                if (pxVar.d >= j) {
                    return true;
                }
            } while (this.b.e(pxVar, 8192L) != -1);
            return false;
        }
        throw new IllegalArgumentException("byteCount < 0: ".concat(String.valueOf(j)));
    }

    @Override // com.facetec.sdk.pz
    public final boolean c(qb qbVar) {
        int iH = qbVar.h();
        if (!this.e) {
            if (iH < 0 || qbVar.h() < iH) {
                return false;
            }
            for (int i = 0; i < iH; i++) {
                long j = i;
                if (!e(1 + j) || this.c.e(j) != qbVar.e(i)) {
                    return false;
                }
            }
            return true;
        }
        throw new IllegalStateException("closed");
    }

    private long e(byte b, long j, long j2) {
        if (this.e) {
            throw new IllegalStateException("closed");
        }
        if (j2 < 0) {
            throw new IllegalArgumentException(String.format("fromIndex=%s toIndex=%s", 0L, Long.valueOf(j2)));
        }
        long jMax = j;
        while (jMax < j2) {
            byte b2 = b;
            long j3 = j2;
            long jE = this.c.e(b2, jMax, j3);
            if (jE != -1) {
                return jE;
            }
            px pxVar = this.c;
            long j4 = pxVar.d;
            if (j4 >= j3 || this.b.e(pxVar, 8192L) == -1) {
                break;
            }
            jMax = Math.max(jMax, j4);
            b = b2;
            j2 = j3;
        }
        return -1L;
    }

    public static int e() {
        int i = a;
        int i2 = i % 8732427;
        a = i + 1;
        if (i2 != 0) {
            return d;
        }
        int iMyTid = Process.myTid();
        d = iMyTid;
        return iMyTid;
    }
}