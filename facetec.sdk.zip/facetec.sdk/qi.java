package com.facetec.sdk;

/* JADX INFO: loaded from: classes4.dex */
final class qi {
    private static qk b;
    private static long d;

    private qi() {
    }

    public static qk b() {
        synchronized (qi.class) {
            qk qkVar = b;
            if (qkVar == null) {
                return new qk();
            }
            b = qkVar.f;
            qkVar.f = null;
            d -= 8192;
            return qkVar;
        }
    }

    public static void d(qk qkVar) {
        if (qkVar.f != null || qkVar.i != null) {
            throw new IllegalArgumentException();
        }
        if (qkVar.a) {
            return;
        }
        synchronized (qi.class) {
            try {
                long j = d;
                if (j + 8192 > 65536) {
                    return;
                }
                d = j + 8192;
                qkVar.f = b;
                qkVar.c = 0;
                qkVar.b = 0;
                b = qkVar;
            } catch (Throwable th) {
                throw th;
            }
        }
    }
}