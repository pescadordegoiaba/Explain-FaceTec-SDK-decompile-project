package com.facetec.sdk;

import android.graphics.Color;
import android.graphics.ImageFormat;
import android.graphics.drawable.Drawable;
import android.os.Process;
import android.text.TextUtils;
import android.view.KeyEvent;
import android.view.ViewConfiguration;
import com.incode.welcome_sdk.modules.SelfieScan;
import com.plaid.internal.EnumC41897g;
import java.lang.reflect.Method;

/* JADX INFO: loaded from: classes4.dex */
final class qk {
    private static final byte[] $$a = null;
    private static final int $$b = 0;
    private static int[] h;
    boolean a;
    int b;
    int c;
    boolean d;
    final byte[] e;
    qk f;
    qk i;

    /* JADX WARN: Removed duplicated region for block: B:10:0x0028  */
    /* JADX WARN: Removed duplicated region for block: B:8:0x0022  */
    /* JADX WARN: Unsupported multi-entry loop pattern (BACK_EDGE: B:10:0x0028 -> B:11:0x002f). Please report as a decompilation issue!!! */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    private static java.lang.String $$c(int r7, byte r8, byte r9) {
        /*
            int r8 = r8 * 2
            int r8 = 3 - r8
            int r7 = r7 * 2
            int r7 = r7 + 1
            int r9 = r9 * 2
            int r9 = r9 + 119
            byte[] r0 = com.facetec.sdk.qk.$$a
            byte[] r1 = new byte[r7]
            r2 = 0
            if (r0 != 0) goto L18
            r3 = r0
            r4 = r2
            r0 = r9
            r9 = r8
            goto L2f
        L18:
            r3 = r2
        L19:
            int r8 = r8 + 1
            int r4 = r3 + 1
            byte r5 = (byte) r9
            r1[r3] = r5
            if (r4 != r7) goto L28
            java.lang.String r7 = new java.lang.String
            r7.<init>(r1, r2)
            return r7
        L28:
            r3 = r0[r8]
            r6 = r9
            r9 = r8
            r8 = r3
            r3 = r0
            r0 = r6
        L2f:
            int r8 = r8 + r0
            r0 = r9
            r9 = r8
            r8 = r0
            r0 = r3
            r3 = r4
            goto L19
        */
        throw new UnsupportedOperationException("Method not decompiled: com.facetec.sdk.qk.$$c(int, byte, byte):java.lang.String");
    }

    static {
        init$0();
        h = new int[]{-1446061923, 1424468483, 491005512, 1903096112, 1887017124, 2119668104, -1955081026, -1097723650, 950961147, 1296999453, 2023434820, -546920831, 213317606, -647948553, -1599558987, 530690209, 798070464, -456460425};
    }

    public qk() {
        this.e = new byte[8192];
        this.d = true;
        this.a = false;
    }

    private static void g(int[] iArr, int i, Object[] objArr) throws Throwable {
        char c;
        char[] cArr;
        int[] iArr2;
        int i2;
        int i3;
        int i4;
        hg hgVar = new hg();
        char[] cArr2 = new char[4];
        int i5 = 2;
        char[] cArr3 = new char[iArr.length * 2];
        int[] iArr3 = h;
        int i6 = 2027942060;
        Class cls = Integer.TYPE;
        int i7 = 16;
        int i8 = 0;
        if (iArr3 != null) {
            int length = iArr3.length;
            int[] iArr4 = new int[length];
            int i9 = 0;
            while (i9 < length) {
                try {
                    Object[] objArr2 = {Integer.valueOf(iArr3[i9])};
                    Object objD = an.d(i6);
                    if (objD == null) {
                        i3 = i6;
                        i2 = i5;
                        byte b = (byte) i8;
                        i4 = i7;
                        byte b2 = b;
                        objD = an.d(617 - (ViewConfiguration.getFadingEdgeLength() >> 16), (char) (Process.myPid() >> 22), Drawable.resolveOpacity(i8, i8) + 23, 247342071, false, $$c(b, b2, (byte) (b2 + 1)), new Class[]{cls});
                    } else {
                        i2 = i5;
                        i3 = i6;
                        i4 = i7;
                    }
                    iArr4[i9] = ((Integer) ((Method) objD).invoke(null, objArr2)).intValue();
                    i9++;
                    i6 = i3;
                    i5 = i2;
                    i7 = i4;
                    i8 = 0;
                } catch (Throwable th) {
                    Throwable cause = th.getCause();
                    if (cause == null) {
                        throw th;
                    }
                    throw cause;
                }
            }
            iArr3 = iArr4;
        }
        int i10 = i5;
        int i11 = i6;
        int i12 = i7;
        int length2 = iArr3.length;
        int[] iArr5 = new int[length2];
        int[] iArr6 = h;
        if (iArr6 != null) {
            int length3 = iArr6.length;
            int[] iArr7 = new int[length3];
            int i13 = 0;
            while (i13 < length3) {
                Object[] objArr3 = {Integer.valueOf(iArr6[i13])};
                Object objD2 = an.d(i11);
                if (objD2 == null) {
                    cArr = cArr2;
                    byte b3 = (byte) 0;
                    byte b4 = b3;
                    iArr2 = iArr6;
                    objD2 = an.d(617 - (ViewConfiguration.getDoubleTapTimeout() >> 16), (char) (ViewConfiguration.getWindowTouchSlop() >> 8), 22 - TextUtils.lastIndexOf("", '0', 0, 0), 247342071, false, $$c(b3, b4, (byte) (b4 + 1)), new Class[]{cls});
                } else {
                    cArr = cArr2;
                    iArr2 = iArr6;
                }
                iArr7[i13] = ((Integer) ((Method) objD2).invoke(null, objArr3)).intValue();
                i13++;
                cArr2 = cArr;
                iArr6 = iArr2;
            }
            iArr6 = iArr7;
        }
        char[] cArr4 = cArr2;
        char c2 = 0;
        System.arraycopy(iArr6, 0, iArr5, 0, length2);
        hgVar.c = 0;
        while (true) {
            int i14 = hgVar.c;
            if (i14 >= iArr.length) {
                objArr[0] = new String(cArr3, 0, i);
                return;
            }
            int i15 = iArr[i14];
            char c3 = (char) (i15 >> 16);
            cArr4[c2] = c3;
            char c4 = (char) i15;
            char c5 = 1;
            cArr4[1] = c4;
            char c6 = (char) (iArr[i14 + 1] >> 16);
            cArr4[i10] = c6;
            char c7 = (char) iArr[i14 + 1];
            cArr4[3] = c7;
            hgVar.d = (c3 << 16) + c4;
            hgVar.a = (c6 << 16) + c7;
            hg.a(iArr5);
            int i16 = 0;
            while (i16 < i12) {
                int i17 = hgVar.d ^ iArr5[i16];
                hgVar.d = i17;
                int iB = hg.b(i17);
                Object[] objArr4 = new Object[4];
                objArr4[3] = hgVar;
                objArr4[i10] = hgVar;
                objArr4[c5] = Integer.valueOf(iB);
                objArr4[0] = hgVar;
                Object objD3 = an.d(-1264699187);
                if (objD3 == null) {
                    byte b5 = (byte) 0;
                    byte b6 = b5;
                    c = c5;
                    objD3 = an.d(TextUtils.indexOf("", "", 0) + 1558, (char) (63318 - (ViewConfiguration.getZoomControlsTimeout() > 0L ? 1 : (ViewConfiguration.getZoomControlsTimeout() == 0L ? 0 : -1))), 32 - (ViewConfiguration.getTapTimeout() >> 16), -1023415402, false, $$c(b5, b6, b6), new Class[]{Object.class, cls, Object.class, Object.class});
                } else {
                    c = c5;
                }
                int iIntValue = ((Integer) ((Method) objD3).invoke(null, objArr4)).intValue();
                hgVar.d = hgVar.a;
                hgVar.a = iIntValue;
                i16++;
                c5 = c;
                i12 = 16;
            }
            char c8 = c5;
            int i18 = hgVar.d;
            int i19 = hgVar.a;
            hgVar.d = i19;
            hgVar.a = i18;
            i12 = 16;
            int i20 = i18 ^ iArr5[16];
            hgVar.a = i20;
            int i21 = i19 ^ iArr5[17];
            hgVar.d = i21;
            cArr4[0] = (char) (i21 >>> 16);
            cArr4[c8] = (char) i21;
            cArr4[i10] = (char) (i20 >>> 16);
            cArr4[3] = (char) i20;
            hg.a(iArr5);
            int i22 = hgVar.c;
            cArr3[i22 * 2] = cArr4[0];
            cArr3[(i22 * 2) + 1] = cArr4[c8];
            cArr3[(i22 * 2) + 2] = cArr4[i10];
            cArr3[(i22 * 2) + 3] = cArr4[3];
            int i23 = i10;
            Object[] objArr5 = new Object[i23];
            objArr5[c8] = hgVar;
            objArr5[0] = hgVar;
            Object objD4 = an.d(-204410541);
            if (objD4 == null) {
                objD4 = an.d((ViewConfiguration.getScrollFriction() > SelfieScan.RECOGNITION_FAIL_RESULT ? 1 : (ViewConfiguration.getScrollFriction() == SelfieScan.RECOGNITION_FAIL_RESULT ? 0 : -1)) + EnumC41897g.SDK_ASSET_PLAID_LOGO_LOADING_INDICATOR_DARK_APPEARANCE_VALUE, (char) (ViewConfiguration.getWindowTouchSlop() >> 8), ImageFormat.getBitsPerPixel(0) + 24, -2051988984, false, "A", new Class[]{Object.class, Object.class});
            }
            ((Method) objD4).invoke(null, objArr5);
            i10 = i23;
            c2 = 0;
        }
    }

    public static void init$0() {
        $$a = new byte[]{115, 102, 60, 8};
        $$b = EnumC41897g.SDK_ASSET_ILLUSTRATION_SHARE_YOUR_DATA_VALUE;
    }

    public final qk a() {
        qk qkVar = this.f;
        qk qkVar2 = qkVar != this ? qkVar : null;
        qk qkVar3 = this.i;
        qkVar3.f = qkVar;
        this.f.i = qkVar3;
        this.f = null;
        this.i = null;
        return qkVar2;
    }

    public final qk e() {
        this.a = true;
        return new qk(this.e, this.b, this.c);
    }

    public final qk e(qk qkVar) {
        qkVar.i = this;
        qkVar.f = this.f;
        this.f.i = qkVar;
        this.f = qkVar;
        return qkVar;
    }

    public qk(byte[] bArr, int i, int i2) {
        this.e = bArr;
        this.b = i;
        this.c = i2;
        this.a = true;
        this.d = false;
    }

    public final void e(qk qkVar, int i) {
        char c;
        char c2;
        if (qkVar.d) {
            int i2 = qkVar.c;
            int i3 = i2 + i;
            Class cls = Integer.TYPE;
            if (i3 <= 8192) {
                c = 3;
                c2 = 2;
            } else if (!qkVar.a) {
                c2 = 2;
                int i4 = qkVar.b;
                if ((i2 + i) - i4 <= 8192) {
                    byte[] bArr = qkVar.e;
                    try {
                        Object[] objArr = {bArr, Integer.valueOf(i4), bArr, 0, Integer.valueOf(i2 - i4)};
                        Object[] objArr2 = new Object[1];
                        g(new int[]{-750054779, -556032588, -1586618113, -181269699, 581199060, -786624769, -2130698254, 1242336308}, (ViewConfiguration.getWindowTouchSlop() >> 8) + 16, objArr2);
                        Class<?> cls2 = Class.forName((String) objArr2[0]);
                        c = 3;
                        Object[] objArr3 = new Object[1];
                        g(new int[]{-2029145387, -971887286, -1930234160, -1914626563, -226773695, 1123002440}, 9 - (ViewConfiguration.getScrollBarFadeDuration() >> 16), objArr3);
                        cls2.getMethod((String) objArr3[0], Object.class, cls, Object.class, cls, cls).invoke(null, objArr);
                        qkVar.c -= qkVar.b;
                        qkVar.b = 0;
                    } catch (Throwable th) {
                        Throwable cause = th.getCause();
                        if (cause == null) {
                            throw th;
                        }
                        throw cause;
                    }
                } else {
                    throw new IllegalArgumentException();
                }
            } else {
                throw new IllegalArgumentException();
            }
            byte[] bArr2 = this.e;
            int i5 = this.b;
            byte[] bArr3 = qkVar.e;
            int i6 = qkVar.c;
            Object[] objArr4 = new Object[5];
            objArr4[4] = Integer.valueOf(i);
            objArr4[c] = Integer.valueOf(i6);
            objArr4[c2] = bArr3;
            objArr4[1] = Integer.valueOf(i5);
            objArr4[0] = bArr2;
            Object[] objArr5 = new Object[1];
            g(new int[]{-750054779, -556032588, -1586618113, -181269699, 581199060, -786624769, -2130698254, 1242336308}, 16 - Color.red(0), objArr5);
            Class<?> cls3 = Class.forName((String) objArr5[0]);
            Object[] objArr6 = new Object[1];
            g(new int[]{-2029145387, -971887286, -1930234160, -1914626563, -226773695, 1123002440}, KeyEvent.getDeadChar(0, 0) + 9, objArr6);
            cls3.getMethod((String) objArr6[0], Object.class, cls, Object.class, cls, cls).invoke(null, objArr4);
            qkVar.c += i;
            this.b += i;
            return;
        }
        throw new IllegalArgumentException();
    }
}