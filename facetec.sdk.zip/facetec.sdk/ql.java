package com.facetec.sdk;

import java.io.Closeable;

/* JADX INFO: loaded from: classes4.dex */
public interface ql extends Closeable {
    qp a();

    @Override // java.io.Closeable, java.lang.AutoCloseable
    void close();

    long e(px pxVar, long j);
}