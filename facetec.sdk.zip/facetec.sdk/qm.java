package com.facetec.sdk;

import android.os.Process;
import android.text.TextUtils;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.View;
import com.incode.welcome_sdk.modules.SelfieScan;
import com.plaid.internal.EnumC41897g;
import java.lang.reflect.Method;
import java.util.Arrays;

/* JADX INFO: loaded from: classes4.dex */
final class qm extends qb {
    private static final byte[] $$d = null;
    private static final int $$e = 0;
    private static long j;
    private transient int[] a;
    private transient byte[][] c;

    /* JADX WARN: Removed duplicated region for block: B:10:0x0022  */
    /* JADX WARN: Removed duplicated region for block: B:8:0x001c  */
    /* JADX WARN: Unsupported multi-entry loop pattern (BACK_EDGE: B:10:0x0022 -> B:11:0x0026). Please report as a decompilation issue!!! */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    private static java.lang.String $$f(short r5, short r6, short r7) {
        /*
            int r7 = r7 * 4
            int r7 = 4 - r7
            int r6 = r6 * 3
            int r0 = r6 + 1
            byte[] r1 = com.facetec.sdk.qm.$$d
            int r5 = r5 * 4
            int r5 = r5 + 73
            byte[] r0 = new byte[r0]
            r2 = 0
            if (r1 != 0) goto L16
            r4 = r7
            r3 = r2
            goto L26
        L16:
            r3 = r2
        L17:
            byte r4 = (byte) r5
            r0[r3] = r4
            if (r3 != r6) goto L22
            java.lang.String r5 = new java.lang.String
            r5.<init>(r0, r2)
            return r5
        L22:
            int r3 = r3 + 1
            r4 = r1[r7]
        L26:
            int r7 = r7 + 1
            int r4 = -r4
            int r5 = r5 + r4
            goto L17
        */
        throw new UnsupportedOperationException("Method not decompiled: com.facetec.sdk.qm.$$f(short, short, short):java.lang.String");
    }

    static {
        init$0();
        j = -4906701256833853048L;
    }

    public qm(px pxVar, int i) {
        super(null);
        qq.a(pxVar.d, 0L, i);
        qk qkVar = pxVar.e;
        int i2 = 0;
        int i3 = 0;
        int i4 = 0;
        while (i3 < i) {
            int i5 = qkVar.c;
            int i6 = qkVar.b;
            if (i5 == i6) {
                throw new AssertionError("s.limit == s.pos");
            }
            i3 += i5 - i6;
            i4++;
            qkVar = qkVar.f;
        }
        this.c = new byte[i4][];
        this.a = new int[i4 << 1];
        qk qkVar2 = pxVar.e;
        int i7 = 0;
        while (i2 < i) {
            byte[][] bArr = this.c;
            bArr[i7] = qkVar2.e;
            int i8 = qkVar2.c;
            int i9 = qkVar2.b;
            i2 += i8 - i9;
            if (i2 > i) {
                i2 = i;
            }
            int[] iArr = this.a;
            iArr[i7] = i2;
            iArr[bArr.length + i7] = i9;
            qkVar2.a = true;
            i7++;
            qkVar2 = qkVar2.f;
        }
    }

    public static void init$0() {
        $$d = new byte[]{115, 102, 60, 8};
        $$e = EnumC41897g.SDK_ASSET_HEADER_FINAL_SUCCESS_DARK_APPEARANCE_VALUE;
    }

    private qb j() {
        return new qb(i());
    }

    private static void l(String str, int i, Object[] objArr) throws Throwable {
        char[] charArray = str != null ? str.toCharArray() : str;
        hl hlVar = new hl();
        char[] cArrB = hl.b(j ^ (-1723600592890876272L), charArray, i);
        hlVar.e = 4;
        while (true) {
            int i2 = hlVar.e;
            if (i2 >= cArrB.length) {
                objArr[0] = new String(cArrB, 4, cArrB.length - 4);
                return;
            }
            int i3 = i2 - 4;
            hlVar.d = i3;
            try {
                Object[] objArr2 = {Long.valueOf(cArrB[i2] ^ cArrB[i2 % 4]), Long.valueOf(i3), Long.valueOf(j)};
                Object objD = an.d(-291407824);
                if (objD == null) {
                    int mode = 2589 - View.MeasureSpec.getMode(0);
                    char deadChar = (char) KeyEvent.getDeadChar(0, 0);
                    int iIndexOf = 23 - TextUtils.indexOf("", "", 0, 0);
                    byte b = (byte) 0;
                    byte b2 = b;
                    String str$$f = $$f(b, b2, b2);
                    Class cls = Long.TYPE;
                    objD = an.d(mode, deadChar, iIndexOf, -1732203669, false, str$$f, new Class[]{cls, cls, cls});
                }
                cArrB[i2] = ((Character) ((Method) objD).invoke(null, objArr2)).charValue();
                Object[] objArr3 = {hlVar, hlVar};
                Object objD2 = an.d(1066529625);
                if (objD2 == null) {
                    objD2 = an.d((Process.getElapsedCpuTime() > 0L ? 1 : (Process.getElapsedCpuTime() == 0L ? 0 : -1)) + EnumC41897g.SDK_ASSET_PLAID_LOGO_LOADING_INDICATOR_DARK_APPEARANCE_VALUE, (char) View.getDefaultSize(0, 0), 23 - (TypedValue.complexToFraction(0, SelfieScan.RECOGNITION_FAIL_RESULT, SelfieScan.RECOGNITION_FAIL_RESULT) > SelfieScan.RECOGNITION_FAIL_RESULT ? 1 : (TypedValue.complexToFraction(0, SelfieScan.RECOGNITION_FAIL_RESULT, SelfieScan.RECOGNITION_FAIL_RESULT) == SelfieScan.RECOGNITION_FAIL_RESULT ? 0 : -1)), 1240473602, false, "G", new Class[]{Object.class, Object.class});
                }
                ((Method) objD2).invoke(null, objArr3);
            } catch (Throwable th) {
                Throwable cause = th.getCause();
                if (cause == null) {
                    throw th;
                }
                throw cause;
            }
        }
    }

    private Object writeReplace() {
        return j();
    }

    @Override // com.facetec.sdk.qb
    public final qb a() {
        return j().a();
    }

    @Override // com.facetec.sdk.qb
    public final qb b() {
        return j().b();
    }

    @Override // com.facetec.sdk.qb
    public final String c() {
        return j().c();
    }

    @Override // com.facetec.sdk.qb
    public final String d() {
        return j().d();
    }

    @Override // com.facetec.sdk.qb
    public final String e() {
        return j().e();
    }

    @Override // com.facetec.sdk.qb
    public final boolean equals(Object obj) {
        if (obj == this) {
            return true;
        }
        if (obj instanceof qb) {
            qb qbVar = (qb) obj;
            if (qbVar.h() == h() && d(0, qbVar, 0, h())) {
                return true;
            }
        }
        return false;
    }

    @Override // com.facetec.sdk.qb
    public final qb f() {
        return j().f();
    }

    @Override // com.facetec.sdk.qb
    public final int h() {
        return this.a[this.c.length - 1];
    }

    @Override // com.facetec.sdk.qb
    public final int hashCode() {
        int i = this.e;
        if (i != 0) {
            return i;
        }
        int length = this.c.length;
        int i2 = 0;
        int i3 = 1;
        int i4 = 0;
        while (i2 < length) {
            byte[] bArr = this.c[i2];
            int[] iArr = this.a;
            int i5 = iArr[length + i2];
            int i6 = iArr[i2];
            int i7 = (i6 - i4) + i5;
            while (i5 < i7) {
                i3 = (i3 * 31) + bArr[i5];
                i5++;
            }
            i2++;
            i4 = i6;
        }
        this.e = i3;
        return i3;
    }

    @Override // com.facetec.sdk.qb
    public final byte[] i() throws Throwable {
        int[] iArr = this.a;
        byte[][] bArr = this.c;
        byte[] bArr2 = new byte[iArr[bArr.length - 1]];
        int length = bArr.length;
        int i = 0;
        int i2 = 0;
        while (i < length) {
            int[] iArr2 = this.a;
            int i3 = iArr2[length + i];
            int i4 = iArr2[i];
            try {
                Object[] objArr = {this.c[i], Integer.valueOf(i3), bArr2, Integer.valueOf(i2), Integer.valueOf(i4 - i2)};
                Object[] objArr2 = new Object[1];
                l("孝ᘾ雳嬷ꅇ䍲\uf8b5晛蜓蔪\udc02䊴\ue3fa秈끐鴃츎婲闆亮", (TypedValue.complexToFraction(0, SelfieScan.RECOGNITION_FAIL_RESULT, SelfieScan.RECOGNITION_FAIL_RESULT) > SelfieScan.RECOGNITION_FAIL_RESULT ? 1 : (TypedValue.complexToFraction(0, SelfieScan.RECOGNITION_FAIL_RESULT, SelfieScan.RECOGNITION_FAIL_RESULT) == SelfieScan.RECOGNITION_FAIL_RESULT ? 0 : -1)), objArr2);
                Class<?> cls = Class.forName((String) objArr2[0]);
                Object[] objArr3 = new Object[1];
                l("㸁췑簝㹠窻朩\u125f䈀\ue218廊㛢曱蚸", Gravity.getAbsoluteGravity(0, 0), objArr3);
                String str = (String) objArr3[0];
                Class cls2 = Integer.TYPE;
                cls.getMethod(str, Object.class, cls2, Object.class, cls2, cls2).invoke(null, objArr);
                i++;
                i2 = i4;
            } catch (Throwable th) {
                Throwable cause = th.getCause();
                if (cause != null) {
                    throw cause;
                }
                throw th;
            }
        }
        return bArr2;
    }

    @Override // com.facetec.sdk.qb
    public final String toString() {
        return j().toString();
    }

    @Override // com.facetec.sdk.qb
    public final qb a(int i, int i2) {
        return j().a(i, i2);
    }

    @Override // com.facetec.sdk.qb
    public final void c(px pxVar) {
        int length = this.c.length;
        int i = 0;
        int i2 = 0;
        while (i < length) {
            int[] iArr = this.a;
            int i3 = iArr[length + i];
            int i4 = iArr[i];
            qk qkVar = new qk(this.c[i], i3, (i3 + i4) - i2);
            qk qkVar2 = pxVar.e;
            if (qkVar2 == null) {
                qkVar.i = qkVar;
                qkVar.f = qkVar;
                pxVar.e = qkVar;
            } else {
                qkVar2.i.e(qkVar);
            }
            i++;
            i2 = i4;
        }
        pxVar.d += (long) i2;
    }

    @Override // com.facetec.sdk.qb
    public final boolean d(int i, qb qbVar, int i2, int i3) {
        if (h() - i3 < 0) {
            return false;
        }
        int iA = a(0);
        while (i3 > 0) {
            int i4 = iA == 0 ? 0 : this.a[iA - 1];
            int iMin = Math.min(i3, ((this.a[iA] - i4) + i4) - i);
            int[] iArr = this.a;
            byte[][] bArr = this.c;
            if (!qbVar.e(i2, bArr[iA], (i - i4) + iArr[bArr.length + iA], iMin)) {
                return false;
            }
            i += iMin;
            i2 += iMin;
            i3 -= iMin;
            iA++;
        }
        return true;
    }

    @Override // com.facetec.sdk.qb
    public final byte e(int i) {
        qq.a(this.a[this.c.length - 1], i, 1L);
        int iA = a(i);
        int i2 = iA == 0 ? 0 : this.a[iA - 1];
        int[] iArr = this.a;
        byte[][] bArr = this.c;
        return bArr[iA][(i - i2) + iArr[bArr.length + iA]];
    }

    private int a(int i) {
        int iBinarySearch = Arrays.binarySearch(this.a, 0, this.c.length, i + 1);
        return iBinarySearch >= 0 ? iBinarySearch : ~iBinarySearch;
    }

    @Override // com.facetec.sdk.qb
    public final boolean e(int i, byte[] bArr, int i2, int i3) {
        if (i < 0 || i > h() - i3 || i2 < 0 || i2 > bArr.length - i3) {
            return false;
        }
        int iA = a(i);
        while (i3 > 0) {
            int i4 = iA == 0 ? 0 : this.a[iA - 1];
            int iMin = Math.min(i3, ((this.a[iA] - i4) + i4) - i);
            int[] iArr = this.a;
            byte[][] bArr2 = this.c;
            if (!qq.b(bArr2[iA], (i - i4) + iArr[bArr2.length + iA], bArr, i2, iMin)) {
                return false;
            }
            i += iMin;
            i2 += iMin;
            i3 -= iMin;
            iA++;
        }
        return true;
    }
}