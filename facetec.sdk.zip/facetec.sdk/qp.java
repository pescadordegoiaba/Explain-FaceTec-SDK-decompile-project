package com.facetec.sdk;

import android.graphics.Color;
import android.os.SystemClock;
import android.text.TextUtils;
import android.view.View;
import android.view.ViewConfiguration;
import java.io.InterruptedIOException;
import java.lang.reflect.Method;
import java.util.concurrent.TimeUnit;

/* JADX INFO: loaded from: classes4.dex */
public class qp {
    private static final byte[] $$g = null;
    private static final int $$h = 0;
    public static final qp b;
    private static long d;
    private long a;
    private boolean c;
    private long e;

    /* JADX WARN: Removed duplicated region for block: B:10:0x0025  */
    /* JADX WARN: Removed duplicated region for block: B:8:0x001f  */
    /* JADX WARN: Unsupported multi-entry loop pattern (BACK_EDGE: B:10:0x0025 -> B:11:0x0027). Please report as a decompilation issue!!! */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    private static java.lang.String $$i(short r6, byte r7, byte r8) {
        /*
            int r8 = r8 * 4
            int r8 = r8 + 73
            int r6 = r6 * 3
            int r6 = r6 + 4
            byte[] r0 = com.facetec.sdk.qp.$$g
            int r7 = r7 * 3
            int r7 = 1 - r7
            byte[] r1 = new byte[r7]
            r2 = 0
            if (r0 != 0) goto L17
            r3 = r8
            r4 = r2
            r8 = r6
            goto L27
        L17:
            r3 = r2
        L18:
            int r4 = r3 + 1
            byte r5 = (byte) r8
            r1[r3] = r5
            if (r4 != r7) goto L25
            java.lang.String r6 = new java.lang.String
            r6.<init>(r1, r2)
            return r6
        L25:
            r3 = r0[r6]
        L27:
            int r6 = r6 + 1
            int r8 = r8 + r3
            r3 = r4
            goto L18
        */
        throw new UnsupportedOperationException("Method not decompiled: com.facetec.sdk.qp.$$i(short, byte, byte):java.lang.String");
    }

    static {
        init$0();
        f();
        b = new qp() { // from class: com.facetec.sdk.qp.3
            @Override // com.facetec.sdk.qp
            public final qp b(long j, TimeUnit timeUnit) {
                return this;
            }

            @Override // com.facetec.sdk.qp
            public final qp d(long j) {
                return this;
            }

            @Override // com.facetec.sdk.qp
            public final void i() {
            }
        };
    }

    public static void f() {
        d = -8917334952364268817L;
    }

    public static void init$0() {
        $$g = new byte[]{86, 117, -27, 75};
        $$h = 61;
    }

    private static void l(String str, int i, Object[] objArr) throws Throwable {
        long j;
        char[] charArray = str != null ? str.toCharArray() : str;
        hl hlVar = new hl();
        char[] cArrB = hl.b(d ^ (-1723600592890876272L), charArray, i);
        hlVar.e = 4;
        while (true) {
            int i2 = hlVar.e;
            if (i2 >= cArrB.length) {
                objArr[0] = new String(cArrB, 4, cArrB.length - 4);
                return;
            }
            int i3 = i2 - 4;
            hlVar.d = i3;
            try {
                Object[] objArr2 = {Long.valueOf(cArrB[i2] ^ cArrB[i2 % 4]), Long.valueOf(i3), Long.valueOf(d)};
                Object objD = an.d(-291407824);
                if (objD == null) {
                    int scrollBarSize = 2589 - (ViewConfiguration.getScrollBarSize() >> 8);
                    char keyRepeatTimeout = (char) (ViewConfiguration.getKeyRepeatTimeout() >> 16);
                    int i4 = 24 - (SystemClock.uptimeMillis() > 0L ? 1 : (SystemClock.uptimeMillis() == 0L ? 0 : -1));
                    byte b2 = (byte) 0;
                    byte b3 = b2;
                    j = 0;
                    String str$$i = $$i(b2, b3, b3);
                    Class cls = Long.TYPE;
                    objD = an.d(scrollBarSize, keyRepeatTimeout, i4, -1732203669, false, str$$i, new Class[]{cls, cls, cls});
                } else {
                    j = 0;
                }
                cArrB[i2] = ((Character) ((Method) objD).invoke(null, objArr2)).charValue();
                Object[] objArr3 = {hlVar, hlVar};
                Object objD2 = an.d(1066529625);
                if (objD2 == null) {
                    objD2 = an.d(310 - Color.green(0), (char) TextUtils.indexOf("", "", 0, 0), 24 - (SystemClock.elapsedRealtimeNanos() > j ? 1 : (SystemClock.elapsedRealtimeNanos() == j ? 0 : -1)), 1240473602, false, "G", new Class[]{Object.class, Object.class});
                }
                ((Method) objD2).invoke(null, objArr3);
            } catch (Throwable th) {
                Throwable cause = th.getCause();
                if (cause == null) {
                    throw th;
                }
                throw cause;
            }
        }
    }

    public long a_() {
        return this.a;
    }

    public qp b(long j, TimeUnit timeUnit) {
        if (j < 0) {
            throw new IllegalArgumentException("timeout < 0: ".concat(String.valueOf(j)));
        }
        if (timeUnit == null) {
            throw new IllegalArgumentException("unit == null");
        }
        this.a = timeUnit.toNanos(j);
        return this;
    }

    public boolean b_() {
        return this.c;
    }

    public qp c_() {
        this.a = 0L;
        return this;
    }

    public qp d(long j) {
        this.c = true;
        this.e = j;
        return this;
    }

    public qp d_() {
        this.c = false;
        return this;
    }

    public long e_() {
        if (this.c) {
            return this.e;
        }
        throw new IllegalStateException("No deadline");
    }

    public void i() throws Throwable {
        if (Thread.interrupted()) {
            Thread.currentThread().interrupt();
            throw new InterruptedIOException("interrupted");
        }
        if (this.c) {
            long j = this.e;
            try {
                Object[] objArr = new Object[1];
                l("ந顔箎킼ூ鑊挆\uf5a0㩺ꙃㄕ螫样\ue80dܫ妰鸯㩓픙殠", 1 - (ViewConfiguration.getWindowTouchSlop() >> 8), objArr);
                Class<?> cls = Class.forName((String) objArr[0]);
                Object[] objArr2 = new Object[1];
                l("씈뀆䷋쀣앦반啛\ue531\uf4a0踔ݜ霿", View.combineMeasuredStates(0, 0) + 1, objArr2);
                if (j - ((Long) cls.getMethod((String) objArr2[0], null).invoke(null, null)).longValue() <= 0) {
                    throw new InterruptedIOException("deadline reached");
                }
            } catch (Throwable th) {
                Throwable cause = th.getCause();
                if (cause == null) {
                    throw th;
                }
                throw cause;
            }
        }
    }
}