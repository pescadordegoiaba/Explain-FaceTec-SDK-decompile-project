package com.facetec.sdk;

import ai.luciq.library.networkv2.request.Constants;
import java.nio.charset.Charset;

/* JADX INFO: loaded from: classes4.dex */
public final class qq {
    public static final Charset e = Charset.forName(Constants.UTF_8);

    public static void a(long j, long j2, long j3) {
        if ((j2 | j3) < 0 || j2 > j || j - j2 < j3) {
            throw new ArrayIndexOutOfBoundsException(String.format("size=%s offset=%s byteCount=%s", Long.valueOf(j), Long.valueOf(j2), Long.valueOf(j3)));
        }
    }

    public static int b(int i) {
        return ((i & 255) << 24) | (((-16777216) & i) >>> 24) | ((16711680 & i) >>> 8) | ((65280 & i) << 8);
    }

    public static short c(short s) {
        return (short) (((s & 255) << 8) | (((65535 & s) >>> 8) & 255));
    }

    public static void d(Throwable th) throws Throwable {
        throw th;
    }

    public static boolean b(byte[] bArr, int i, byte[] bArr2, int i2, int i3) {
        for (int i4 = 0; i4 < i3; i4++) {
            if (bArr[i4 + i] != bArr2[i4 + i2]) {
                return false;
            }
        }
        return true;
    }
}