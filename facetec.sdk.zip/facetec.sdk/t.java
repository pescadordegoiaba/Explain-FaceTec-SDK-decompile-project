package com.facetec.sdk;

import android.app.Activity;
import android.app.Fragment;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.ImageFormat;
import android.graphics.PointF;
import android.graphics.drawable.Drawable;
import android.media.AudioTrack;
import android.os.Process;
import android.os.SystemClock;
import android.telephony.cdma.CdmaCellLocation;
import android.text.AndroidCharacter;
import android.text.TextUtils;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewConfiguration;
import android.widget.ExpandableListView;
import com.facetec.sdk.am;
import com.facetec.sdk.ay;
import com.facetec.sdk.bv;
import com.facetec.sdk.cx;
import com.facetec.sdk.ed;
import com.facetec.sdk.j;
import com.facetec.sdk.nd;
import com.facetec.sdk.nf;
import com.facetec.sdk.ov;
import com.incode.welcome_sdk.modules.SelfieScan;
import com.plaid.internal.EnumC41897g;
import com.withpersona.sdk2.inquiry.network.core.HttpStatusCode;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.IOException;
import java.nio.ByteBuffer;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;
import java.util.UUID;
import net.sf.scuba.smartcards.ISO7816;
import net.sf.scuba.smartcards.ISOFileInfo;
import org.bouncycastle.i18n.LocalizedMessage;

/* JADX INFO: loaded from: classes4.dex */
final class t {
    private static final byte[] $$a = null;
    private static final int $$b = 0;
    private static int $10;
    private static int $11;
    static String a;
    static boolean b;
    static boolean c;
    static String d;
    static int e;
    private static dh f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    static int f95949g;
    private static long h;
    static boolean i;
    private static /* synthetic */ boolean j;
    private static char[] k;
    private static int l;
    private static long m;
    private static long n;
    private static char[] o;
    private static int p;
    private static int r;
    private static int t;

    /* JADX INFO: renamed from: com.facetec.sdk.t$5, reason: invalid class name */
    public static /* synthetic */ class AnonymousClass5 {
        static final /* synthetic */ int[] b;
        static final /* synthetic */ int[] c;
        static final /* synthetic */ int[] d;

        static {
            int[] iArr = new int[dh.values().length];
            b = iArr;
            try {
                iArr[dh.CAMERA_PERMISSION.ordinal()] = 1;
            } catch (NoSuchFieldError unused) {
            }
            try {
                b[dh.INITIAL_FACE_SCAN_GET_READY.ordinal()] = 2;
            } catch (NoSuchFieldError unused2) {
            }
            try {
                b[dh.FACE_SCAN_ZOOMED.ordinal()] = 3;
            } catch (NoSuchFieldError unused3) {
            }
            try {
                b[dh.FACE_SCAN_UNZOOMED.ordinal()] = 4;
            } catch (NoSuchFieldError unused4) {
            }
            try {
                b[dh.RETRY_SIDE_BY_SIDE.ordinal()] = 5;
            } catch (NoSuchFieldError unused5) {
            }
            try {
                b[dh.RETRY_GET_READY.ordinal()] = 6;
            } catch (NoSuchFieldError unused6) {
            }
            try {
                b[dh.RESULT_UPLOAD.ordinal()] = 7;
            } catch (NoSuchFieldError unused7) {
            }
            try {
                b[dh.ID_SCAN_START.ordinal()] = 8;
            } catch (NoSuchFieldError unused8) {
            }
            try {
                b[dh.NFC_START.ordinal()] = 9;
            } catch (NoSuchFieldError unused9) {
            }
            try {
                b[dh.RESULT_OCR.ordinal()] = 10;
            } catch (NoSuchFieldError unused10) {
            }
            try {
                b[dh.SECURING_CAMERA.ordinal()] = 11;
            } catch (NoSuchFieldError unused11) {
            }
            try {
                b[dh.RESULT_ID_FEEDBACK.ordinal()] = 12;
            } catch (NoSuchFieldError unused12) {
            }
            try {
                b[dh.RESULT_ADDITIONAL_REVIEW.ordinal()] = 13;
            } catch (NoSuchFieldError unused13) {
            }
            int[] iArr2 = new int[ej.values().length];
            c = iArr2;
            try {
                iArr2[ej.Unknown.ordinal()] = 1;
            } catch (NoSuchFieldError unused14) {
            }
            try {
                c[ej.InvalidMrzKey.ordinal()] = 2;
            } catch (NoSuchFieldError unused15) {
            }
            try {
                c[ej.ResponseError.ordinal()] = 3;
            } catch (NoSuchFieldError unused16) {
            }
            try {
                c[ej.ConnectionError.ordinal()] = 4;
            } catch (NoSuchFieldError unused17) {
            }
            try {
                c[ej.UnknownRetry.ordinal()] = 5;
            } catch (NoSuchFieldError unused18) {
            }
            try {
                c[ej.IncompatibleDoc.ordinal()] = 6;
            } catch (NoSuchFieldError unused19) {
            }
            int[] iArr3 = new int[c.values().length];
            d = iArr3;
            try {
                iArr3[c.FACESCAN_CALLBACK_CALLED.ordinal()] = 1;
            } catch (NoSuchFieldError unused20) {
            }
            try {
                d[c.ID_SCAN_CALLBACK_CALLED.ordinal()] = 2;
            } catch (NoSuchFieldError unused21) {
            }
            try {
                d[c.DEVELOPER_USED_FACESCAN_CALLBACK.ordinal()] = 3;
            } catch (NoSuchFieldError unused22) {
            }
            try {
                d[c.DEVELOPER_USED_ID_SCAN_CALLBACK.ordinal()] = 4;
            } catch (NoSuchFieldError unused23) {
            }
            try {
                d[c.DOCUMENT_TYPE_PRESSED.ordinal()] = 5;
            } catch (NoSuchFieldError unused24) {
            }
            try {
                d[c.FULL_SESSION_START.ordinal()] = 6;
            } catch (NoSuchFieldError unused25) {
            }
            try {
                d[c.GET_READY_IM_READY_SHOWN_AND_READY.ordinal()] = 7;
            } catch (NoSuchFieldError unused26) {
            }
            try {
                d[c.GET_READY_IM_READY_PRESSED.ordinal()] = 8;
            } catch (NoSuchFieldError unused27) {
            }
            try {
                d[c.GET_READY_IM_READY_SHOWN_AND_READY_RETRY.ordinal()] = 9;
            } catch (NoSuchFieldError unused28) {
            }
            try {
                d[c.GET_READY_IM_READY_PRESSED_RETRY.ordinal()] = 10;
            } catch (NoSuchFieldError unused29) {
            }
            try {
                d[c.CAMERA2_ERROR.ordinal()] = 11;
            } catch (NoSuchFieldError unused30) {
            }
            try {
                d[c.NON_FATAL_ERROR.ordinal()] = 12;
            } catch (NoSuchFieldError unused31) {
            }
            try {
                d[c.SEVERE_ERROR.ordinal()] = 13;
            } catch (NoSuchFieldError unused32) {
            }
            try {
                d[c.VOCAL_GUIDANCE_STARTED.ordinal()] = 14;
            } catch (NoSuchFieldError unused33) {
            }
            try {
                d[c.CAMERA_LEGACY_ERROR.ordinal()] = 15;
            } catch (NoSuchFieldError unused34) {
            }
            try {
                d[c.CAMERA_ERROR.ordinal()] = 16;
            } catch (NoSuchFieldError unused35) {
            }
            try {
                d[c.NFC_ERROR.ordinal()] = 17;
            } catch (NoSuchFieldError unused36) {
            }
            try {
                d[c.NFC_USER_MOVED_DEVICE.ordinal()] = 18;
            } catch (NoSuchFieldError unused37) {
            }
            try {
                d[c.DEFINITELY_BUG_IF_SEEN.ordinal()] = 19;
            } catch (NoSuchFieldError unused38) {
            }
            try {
                d[c.STARTPREVIEW_EXCEPTION.ordinal()] = 20;
            } catch (NoSuchFieldError unused39) {
            }
            try {
                d[c.UNEXPECTED_NULL.ordinal()] = 21;
            } catch (NoSuchFieldError unused40) {
            }
            try {
                d[c.EXIT_SCREEN_TYPE.ordinal()] = 22;
            } catch (NoSuchFieldError unused41) {
            }
            try {
                d[c.EXIT_SCREEN_ELAPSED_TIME.ordinal()] = 23;
            } catch (NoSuchFieldError unused42) {
            }
            try {
                d[c.SESSION_RESULT_UNEXPECTED_NULL.ordinal()] = 24;
            } catch (NoSuchFieldError unused43) {
            }
            try {
                d[c.PHOENIX_HANDLER_UNEXPECTED_NULL.ordinal()] = 25;
            } catch (NoSuchFieldError unused44) {
            }
            try {
                d[c.ROOT_DEVICE_DETECTED.ordinal()] = 26;
            } catch (NoSuchFieldError unused45) {
            }
            try {
                d[c.DEVICE_SYSTEM_PROPERTY_ANNOTATION_ERROR.ordinal()] = 27;
            } catch (NoSuchFieldError unused46) {
            }
            try {
                d[c.CANCEL_BUTTON_RESOURCE_ID_ERROR.ordinal()] = 28;
            } catch (NoSuchFieldError unused47) {
            }
            try {
                d[c.LOW_MEMORY_ERROR.ordinal()] = 29;
            } catch (NoSuchFieldError unused48) {
            }
            try {
                d[c.LOW_MEMORY_WARNING.ordinal()] = 30;
            } catch (NoSuchFieldError unused49) {
            }
            try {
                d[c.CAMERA_ALREADY_CLOSED.ordinal()] = 31;
            } catch (NoSuchFieldError unused50) {
            }
            try {
                d[c.F2F_ERROR.ordinal()] = 32;
            } catch (NoSuchFieldError unused51) {
            }
            try {
                d[c.IMAGE_DATA_UNEXPECTED_NULL.ordinal()] = 33;
            } catch (NoSuchFieldError unused52) {
            }
            try {
                d[c.DIAGNOSTIC_WAIT_TIME.ordinal()] = 34;
            } catch (NoSuchFieldError unused53) {
            }
            try {
                d[c.DIAGNOSTIC_UPLOAD_ERROR.ordinal()] = 35;
            } catch (NoSuchFieldError unused54) {
            }
            try {
                d[c.ON_RESUME_ERROR.ordinal()] = 36;
            } catch (NoSuchFieldError unused55) {
            }
            try {
                d[c.UNEXPECTED_EARLY_EXIT_FACESCAN.ordinal()] = 37;
            } catch (NoSuchFieldError unused56) {
            }
            try {
                d[c.UNEXPECTED_EARLY_EXIT_IDSCAN.ordinal()] = 38;
            } catch (NoSuchFieldError unused57) {
            }
            try {
                d[c.CAMERA_CAPTURE_FAILED_DEFAULT.ordinal()] = 39;
            } catch (NoSuchFieldError unused58) {
            }
            try {
                d[c.CAMERA_CONFIGURE_FAILED_DEFAULT.ordinal()] = 40;
            } catch (NoSuchFieldError unused59) {
            }
            try {
                d[c.CAMERA_CAPTURE_FAILED_ATTEMPT_FALLBACK.ordinal()] = 41;
            } catch (NoSuchFieldError unused60) {
            }
            try {
                d[c.INIT_START.ordinal()] = 42;
            } catch (NoSuchFieldError unused61) {
            }
            try {
                d[c.INIT_SKIPPED_APP_VALIDATED.ordinal()] = 43;
            } catch (NoSuchFieldError unused62) {
            }
            try {
                d[c.INIT_FAIL_PUBLIC_KEY.ordinal()] = 44;
            } catch (NoSuchFieldError unused63) {
            }
            try {
                d[c.INIT_FAIL_DEVICE_NOT_SUPPORTED.ordinal()] = 45;
            } catch (NoSuchFieldError unused64) {
            }
            try {
                d[c.INIT_FAIL_VERSION_DEPRECATED.ordinal()] = 46;
            } catch (NoSuchFieldError unused65) {
            }
            try {
                d[c.INIT_FAIL_DEVICE_KEY_REJECTED.ordinal()] = 47;
            } catch (NoSuchFieldError unused66) {
            }
            try {
                d[c.INIT_FAIL_NETWORK_ERROR.ordinal()] = 48;
            } catch (NoSuchFieldError unused67) {
            }
            try {
                d[c.INIT_FINISH.ordinal()] = 49;
            } catch (NoSuchFieldError unused68) {
            }
            try {
                d[c.ID_FEEDBACK_SHOWN.ordinal()] = 50;
            } catch (NoSuchFieldError unused69) {
            }
            try {
                d[c.ADDITIONAL_REVIEW_BUTTON_PRESSED.ordinal()] = 51;
            } catch (NoSuchFieldError unused70) {
            }
            try {
                d[c.FACETEC_SESSION_ACTIVITY_ON_RESUME.ordinal()] = 52;
            } catch (NoSuchFieldError unused71) {
            }
            try {
                d[c.FACETEC_SESSION_ACTIVITY_ON_PAUSE.ordinal()] = 53;
            } catch (NoSuchFieldError unused72) {
            }
            try {
                d[c.FACETEC_SESSION_ACTIVITY_ON_WINDOW_FOCUS_CHANGED.ordinal()] = 54;
            } catch (NoSuchFieldError unused73) {
            }
            try {
                d[c.FACETEC_SDK_ACTIVITY_CONTEXT_SWITCH_TRIGGERED.ordinal()] = 55;
            } catch (NoSuchFieldError unused74) {
            }
            try {
                d[c.OPEN_FRONT_CAMERA2.ordinal()] = 56;
            } catch (NoSuchFieldError unused75) {
            }
            try {
                d[c.OPEN_FRONT_CAMERA1.ordinal()] = 57;
            } catch (NoSuchFieldError unused76) {
            }
            try {
                d[c.CALCULATE_FRONT_CAMERA_SIZE_START.ordinal()] = 58;
            } catch (NoSuchFieldError unused77) {
            }
            try {
                d[c.CALCULATE_FRONT_CAMERA_SIZE_EXCEPTION.ordinal()] = 59;
            } catch (NoSuchFieldError unused78) {
            }
            try {
                d[c.SELECTED_FRONT_CAMERA_SIZE.ordinal()] = 60;
            } catch (NoSuchFieldError unused79) {
            }
            try {
                d[c.CAMERA_PERMISSION_SHOWN.ordinal()] = 61;
            } catch (NoSuchFieldError unused80) {
            }
            try {
                d[c.PRE_SESSION_PHASE_2_START.ordinal()] = 62;
            } catch (NoSuchFieldError unused81) {
            }
            try {
                d[c.PRE_SESSION_START_ERROR.ordinal()] = 63;
            } catch (NoSuchFieldError unused82) {
            }
            try {
                d[c.RESULT_SCREEN_SHOWN.ordinal()] = 64;
            } catch (NoSuchFieldError unused83) {
            }
            try {
                d[c.CAMERA_EVICTED_CONTEXT_SWITCH.ordinal()] = 65;
            } catch (NoSuchFieldError unused84) {
            }
            try {
                d[c.FACESCAN_CAMERA_CREATED.ordinal()] = 66;
            } catch (NoSuchFieldError unused85) {
            }
            try {
                d[c.SESSION_CAMERA_CLEANUP_CALLED.ordinal()] = 67;
            } catch (NoSuchFieldError unused86) {
            }
            try {
                d[c.NATIVE_AUDIT_TRAIL_METHOD_RETURNS_NULL.ordinal()] = 68;
            } catch (NoSuchFieldError unused87) {
            }
            try {
                d[c.SCAN_RESULT_BLOB_DECODE_ERROR.ordinal()] = 69;
            } catch (NoSuchFieldError unused88) {
            }
            try {
                d[c.UNEXPECTED_ACTIVITY_WINDOW_SIZE.ordinal()] = 70;
            } catch (NoSuchFieldError unused89) {
            }
            try {
                d[c.ASYNC_FACE_SCAN_SUCCESS_TASK_ERROR.ordinal()] = 71;
            } catch (NoSuchFieldError unused90) {
            }
            try {
                d[c.LOG_SUCCESSFUL_ENROLLMENT_ERROR.ordinal()] = 72;
            } catch (NoSuchFieldError unused91) {
            }
            try {
                d[c.VG_PLAY_SOUND_ERROR.ordinal()] = 73;
            } catch (NoSuchFieldError unused92) {
            }
            try {
                d[c.VG_TEXT_TO_SPEECH_ERROR.ordinal()] = 74;
            } catch (NoSuchFieldError unused93) {
            }
            try {
                d[c.POWER_BUTTON_PRESSED.ordinal()] = 75;
            } catch (NoSuchFieldError unused94) {
            }
            try {
                d[c.UNEXPECTED_HOOK_CHECK_ERROR.ordinal()] = 76;
            } catch (NoSuchFieldError unused95) {
            }
            try {
                d[c.ID_SCAN_BACK_CAMERA_TAKEPHOTO_API_RESOLUTION.ordinal()] = 77;
            } catch (NoSuchFieldError unused96) {
            }
            try {
                d[c.ID_SCAN_BACK_CAMERA_TAKEPHOTO_API_ELAPSED_TIME.ordinal()] = 78;
            } catch (NoSuchFieldError unused97) {
            }
        }
    }

    public enum b {
        USER_CANCELLED,
        USER_FAILED,
        USER_WAS_SUCCESSFUL,
        PRE_SESSION_PHASE_1_TIMEOUT,
        PRE_SESSION_PHASE_2_TIMEOUT,
        SESSION_TIMEOUT,
        SESSION_CONTEXT_SWITCH,
        WAYPOINT_UPLOAD
    }

    public static class d extends ay.b {
        private final Context c;
        private final q d;

        public d(Context context, q qVar) {
            this.c = context.getApplicationContext();
            this.d = qVar;
        }

        @Override // com.facetec.sdk.ay.b
        public final void c() throws Throwable {
            Object[] objArr = {this.c};
            int iE = ov.b.AnonymousClass1.e();
            t.e(ov.b.AnonymousClass1.e(), objArr, ov.b.AnonymousClass1.e(), ov.b.AnonymousClass1.e(), -156914999, 156915000, iE);
        }

        @Override // com.facetec.sdk.ay.b
        public final void e(boolean z) throws Throwable {
            q qVar = this.d;
            int i = qVar.h + 1;
            qVar.h = i;
            if (i < 3) {
                t.e(this.c, z, qVar);
            } else {
                if (z) {
                    return;
                }
                Object[] objArr = {this.c, qVar};
                int iE = ov.b.AnonymousClass1.e();
                t.e(ov.b.AnonymousClass1.e(), objArr, ov.b.AnonymousClass1.e(), ov.b.AnonymousClass1.e(), -1562709845, 1562709849, iE);
            }
        }
    }

    /* JADX WARN: Removed duplicated region for block: B:10:0x0023  */
    /* JADX WARN: Removed duplicated region for block: B:8:0x001d  */
    /* JADX WARN: Unsupported multi-entry loop pattern (BACK_EDGE: B:10:0x0023 -> B:11:0x002c). Please report as a decompilation issue!!! */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    private static java.lang.String $$c(byte r6, int r7, byte r8) {
        /*
            int r7 = r7 * 4
            int r7 = 3 - r7
            int r6 = r6 * 4
            int r0 = r6 + 1
            int r8 = 111 - r8
            byte[] r1 = com.facetec.sdk.t.$$a
            byte[] r0 = new byte[r0]
            r2 = 0
            if (r1 != 0) goto L15
            r3 = r1
            r4 = r2
            r1 = r6
            goto L2c
        L15:
            r3 = r2
        L16:
            byte r4 = (byte) r8
            r0[r3] = r4
            int r7 = r7 + 1
            if (r3 != r6) goto L23
            java.lang.String r6 = new java.lang.String
            r6.<init>(r0, r2)
            return r6
        L23:
            int r3 = r3 + 1
            r4 = r1[r7]
            r5 = r1
            r1 = r8
            r8 = r4
            r4 = r3
            r3 = r5
        L2c:
            int r8 = -r8
            int r8 = r8 + r1
            r1 = r3
            r3 = r4
            goto L16
        */
        throw new UnsupportedOperationException("Method not decompiled: com.facetec.sdk.t.$$c(byte, int, byte):java.lang.String");
    }

    static {
        init$0();
        $10 = 0;
        $11 = 1;
        p = 0;
        t = 1;
        l = 0;
        r = 1;
        d();
        a();
        Color.green(0);
        ViewConfiguration.getKeyRepeatTimeout();
        Color.blue(0);
        int i2 = (p + 81) % 128;
        t = i2;
        p = (i2 + 107) % 128;
        j = true;
        f = dh.CAMERA_PERMISSION;
        h = 0L;
        a = "";
        d = ao.t;
        c = false;
        e = 0;
        b = true;
        f95949g = 0;
        i = true;
        t = (p + 49) % 128;
    }

    private static /* synthetic */ Object a(Object[] objArr) throws Throwable {
        c cVar = (c) objArr[0];
        es esVar = (es) objArr[1];
        Context context = (Context) objArr[2];
        ey eyVar = new ey();
        Object[] objArr2 = new Object[1];
        q((char) View.MeasureSpec.makeMeasureSpec(0, 0), (ViewConfiguration.getTouchSlop() >> 8) + EnumC41897g.SDK_ASSET_ILLUSTRATION_PLAID_LOGO_NAVBAR_VALUE, 2 - View.MeasureSpec.makeMeasureSpec(0, 0), objArr2);
        String strIntern = ((String) objArr2[0]).intern();
        Object[] objArr3 = new Object[1];
        q((char) View.MeasureSpec.getSize(0), ((Process.getThreadPriority(0) + 20) >> 6) + 2570, ExpandableListView.getPackedPositionType(0L) + 2, objArr3);
        eyVar.c(strIntern, ((String) objArr3[0]).intern());
        Object[] objArr4 = new Object[1];
        q((char) View.MeasureSpec.getMode(0), (ViewConfiguration.getScrollBarSize() >> 8) + 2572, Color.alpha(0) + 9, objArr4);
        eyVar.c(((String) objArr4[0]).intern(), a);
        Object[] objArr5 = new Object[1];
        q((char) (ViewConfiguration.getTouchSlop() >> 8), 2582 - (Process.getElapsedCpuTime() > 0L ? 1 : (Process.getElapsedCpuTime() == 0L ? 0 : -1)), 7 - TextUtils.indexOf("", ""), objArr5);
        eyVar.c(((String) objArr5[0]).intern(), UUID.randomUUID().toString());
        Object[] objArr6 = new Object[1];
        q((char) KeyEvent.getDeadChar(0, 0), 2588 - (Process.myTid() >> 22), (SystemClock.elapsedRealtimeNanos() > 0L ? 1 : (SystemClock.elapsedRealtimeNanos() == 0L ? 0 : -1)) + 18, objArr6);
        eyVar.c(((String) objArr6[0]).intern(), cp.a);
        Object[] objArr7 = new Object[1];
        q((char) (1 - (ViewConfiguration.getGlobalActionKeyTimeout() > 0L ? 1 : (ViewConfiguration.getGlobalActionKeyTimeout() == 0L ? 0 : -1))), Color.alpha(0) + 2607, (ViewConfiguration.getScrollDefaultDelay() >> 16) + 1, objArr7);
        eyVar.c(((String) objArr7[0]).intern(), c(cVar));
        Object[] objArr8 = new Object[1];
        q((char) (ViewConfiguration.getEdgeSlop() >> 16), MotionEvent.axisFromString("") + 2609, (ViewConfiguration.getScrollBarFadeDuration() >> 16) + 9, objArr8);
        String strIntern2 = ((String) objArr8[0]).intern();
        try {
            Object[] objArr9 = new Object[1];
            s((PointF.length(SelfieScan.RECOGNITION_FAIL_RESULT, SelfieScan.RECOGNITION_FAIL_RESULT) > SelfieScan.RECOGNITION_FAIL_RESULT ? 1 : (PointF.length(SelfieScan.RECOGNITION_FAIL_RESULT, SelfieScan.RECOGNITION_FAIL_RESULT) == SelfieScan.RECOGNITION_FAIL_RESULT ? 0 : -1)), (char) TextUtils.getOffsetAfter("", 0), 16 - (KeyEvent.getMaxKeyCode() >> 16), objArr9);
            Class<?> cls = Class.forName((String) objArr9[0]);
            Object[] objArr10 = new Object[1];
            s(17 - (SystemClock.currentThreadTimeMillis() > (-1L) ? 1 : (SystemClock.currentThreadTimeMillis() == (-1L) ? 0 : -1)), (char) ((-1) - TextUtils.lastIndexOf("", '0')), 16 - ExpandableListView.getPackedPositionChild(0L), objArr10);
            eyVar.b(strIntern2, Integer.valueOf((int) (((Long) cls.getMethod((String) objArr10[0], null).invoke(null, null)).longValue() / 1000)));
            Object[] objArr11 = new Object[1];
            q((char) TextUtils.indexOf("", "", 0, 0), View.MeasureSpec.getMode(0) + 2617, View.MeasureSpec.getMode(0) + 9, objArr11);
            String strIntern3 = ((String) objArr11[0]).intern();
            l = (r + 113) % 128;
            Object[] objArr12 = new Object[1];
            s(View.combineMeasuredStates(0, 0), (char) (TextUtils.lastIndexOf("", '0', 0, 0) + 1), 17 - (SystemClock.elapsedRealtime() > 0L ? 1 : (SystemClock.elapsedRealtime() == 0L ? 0 : -1)), objArr12);
            Class<?> cls2 = Class.forName((String) objArr12[0]);
            Object[] objArr13 = new Object[1];
            s(View.MeasureSpec.getMode(0) + 16, (char) (ViewConfiguration.getScrollDefaultDelay() >> 16), 17 - (ViewConfiguration.getPressedStateDuration() >> 16), objArr13);
            Long l2 = (Long) cls2.getMethod((String) objArr13[0], null).invoke(null, null);
            l2.longValue();
            eyVar.b(strIntern3, l2);
            if (esVar != null) {
                Object[] objArr14 = new Object[1];
                q((char) ((SystemClock.elapsedRealtime() > 0L ? 1 : (SystemClock.elapsedRealtime() == 0L ? 0 : -1)) - 1), AndroidCharacter.getMirror('0') + 2578, 4 - View.combineMeasuredStates(0, 0), objArr14);
                eyVar.a(((String) objArr14[0]).intern(), esVar);
            }
            nf nfVarB = ay.b(context);
            Object[] objArr15 = new Object[1];
            q((char) ((ExpandableListView.getPackedPositionForGroup(0) > 0L ? 1 : (ExpandableListView.getPackedPositionForGroup(0) == 0L ? 0 : -1)) + 46180), TextUtils.getOffsetAfter("", 0) + 2630, 46 - (AudioTrack.getMinVolume() > SelfieScan.RECOGNITION_FAIL_RESULT ? 1 : (AudioTrack.getMinVolume() == SelfieScan.RECOGNITION_FAIL_RESULT ? 0 : -1)), objArr15);
            try {
                nfVarB.b(j.d(context, ((String) objArr15[0]).intern(), eyVar, Boolean.FALSE)).e(new mm() { // from class: com.facetec.sdk.t.4
                    @Override // com.facetec.sdk.mm
                    public final void b(nh nhVar) {
                        nhVar.a();
                    }

                    @Override // com.facetec.sdk.mm
                    public final void c(IOException iOException) {
                    }
                });
                l = (r + 101) % 128;
                return null;
            } catch (j.c e2) {
                e2.printStackTrace();
                return null;
            }
        } catch (Throwable th) {
            Throwable cause = th.getCause();
            if (cause != null) {
                throw cause;
            }
            throw th;
        }
    }

    public static void b(Context context, b bVar) throws Throwable {
        l = (r + 29) % 128;
        if (!((Boolean) bk.d(-261957882, nf.a.e(), nf.a.e(), nf.a.e(), nf.a.e(), new Object[0], 261957889)).booleanValue()) {
            int i2 = l + 125;
            r = i2 % 128;
            if (i2 % 2 == 0) {
                throw null;
            }
            return;
        }
        if (bVar != b.USER_WAS_SUCCESSFUL) {
            try {
                Object[] objArr = new Object[1];
                s(ViewConfiguration.getFadingEdgeLength() >> 16, (char) (1 - (SystemClock.uptimeMillis() > 0L ? 1 : (SystemClock.uptimeMillis() == 0L ? 0 : -1))), 16 - (ViewConfiguration.getWindowTouchSlop() >> 8), objArr);
                Class<?> cls = Class.forName((String) objArr[0]);
                s((ViewConfiguration.getTapTimeout() >> 16) + 16, (char) KeyEvent.normalizeMetaState(0), 16 - TextUtils.lastIndexOf("", '0', 0, 0), new Object[1]);
                d(context, c.EXIT_SCREEN_TYPE, a(f), null);
                d(context, c.EXIT_SCREEN_ELAPSED_TIME, String.valueOf((((Long) cls.getMethod((String) r3[0], null).invoke(null, null)).longValue() - h) / 1000.0d), null);
            } catch (Throwable th) {
                Throwable cause = th.getCause();
                if (cause == null) {
                    throw th;
                }
                throw cause;
            }
        }
    }

    private static /* synthetic */ Object c(Object[] objArr) {
        Context context = (Context) objArr[0];
        q qVar = (q) objArr[1];
        int i2 = r + 57;
        l = i2 % 128;
        int i3 = i2 % 2;
        b(context, qVar);
        if (i3 != 0) {
            throw null;
        }
        int i4 = l + 49;
        r = i4 % 128;
        if (i4 % 2 != 0) {
            return null;
        }
        throw null;
    }

    public static void d(Context context, ed.d dVar) throws Throwable {
        l = (r + EnumC41897g.SDK_ASSET_ILLUSTRATION_CALENDAR_VALUE) % 128;
        if (((Boolean) bk.d(-261957882, nf.a.e(), nf.a.e(), nf.a.e(), nf.a.e(), new Object[0], 261957889)).booleanValue()) {
            ey eyVar = new ey();
            Object[] objArr = new Object[1];
            q((char) ((SystemClock.elapsedRealtimeNanos() > 0L ? 1 : (SystemClock.elapsedRealtimeNanos() == 0L ? 0 : -1)) - 1), 82 - ExpandableListView.getPackedPositionType(0L), 13 - TextUtils.lastIndexOf("", '0'), objArr);
            eyVar.c(((String) objArr[0]).intern(), dVar.s);
            Object[] objArr2 = new Object[1];
            q((char) (13604 - TextUtils.getCapsMode("", 0, 0)), 96 - (ViewConfiguration.getLongPressTimeout() >> 16), (SystemClock.uptimeMillis() > 0L ? 1 : (SystemClock.uptimeMillis() == 0L ? 0 : -1)) + 10, objArr2);
            eyVar.c(((String) objArr2[0]).intern(), FaceTecSDK.d.vocalGuidanceCustomization.mode.toString());
            c(context, c.VOCAL_GUIDANCE_STARTED, eyVar);
            r = (l + 33) % 128;
        }
    }

    public static /* synthetic */ void e(Context context, boolean z, q qVar) throws Throwable {
        l = (r + 77) % 128;
        c(context, z, qVar);
        l = (r + 97) % 128;
    }

    public static void init$0() {
        $$a = new byte[]{78, -86, ISOFileInfo.DATA_BYTES1, ISOFileInfo.DATA_BYTES1};
        $$b = EnumC41897g.SDK_ASSET_ILLUSTRATION_SIGNATURE_VALUE;
    }

    /* JADX WARN: Removed duplicated region for block: B:52:0x028c  */
    /* JADX WARN: Removed duplicated region for block: B:53:0x028d  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    private static void q(char r32, int r33, int r34, java.lang.Object[] r35) throws java.lang.Throwable {
        /*
            Method dump skipped, instruction units count: 664
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: com.facetec.sdk.t.q(char, int, int, java.lang.Object[]):void");
    }

    /* JADX WARN: Removed duplicated region for block: B:35:0x015f  */
    /* JADX WARN: Removed duplicated region for block: B:36:0x0160  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    private static void s(int r23, char r24, int r25, java.lang.Object[] r26) throws java.lang.Throwable {
        /*
            Method dump skipped, instruction units count: 361
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: com.facetec.sdk.t.s(int, char, int, java.lang.Object[]):void");
    }

    public static void c(Context context, ej ejVar, String str) throws Throwable {
        c cVar;
        int i2 = r + 21;
        l = i2 % 128;
        if (i2 % 2 != 0) {
            ((Boolean) bk.d(-261957882, nf.a.e(), nf.a.e(), nf.a.e(), nf.a.e(), new Object[0], 261957889)).booleanValue();
            throw null;
        }
        if (!((Boolean) bk.d(-261957882, nf.a.e(), nf.a.e(), nf.a.e(), nf.a.e(), new Object[0], 261957889)).booleanValue()) {
            int i3 = r + 3;
            l = i3 % 128;
            if (i3 % 2 != 0) {
                int i4 = 52 / 0;
                return;
            }
            return;
        }
        if (ejVar == ej.ConnectionError) {
            l = (r + 115) % 128;
            cVar = c.NFC_USER_MOVED_DEVICE;
        } else {
            cVar = c.NFC_ERROR;
        }
        ey eyVar = new ey();
        eyVar.c(e(cVar), e(ejVar));
        Object[] objArr = new Object[1];
        q((char) ((-1) - TextUtils.indexOf((CharSequence) "", '0', 0)), (ViewConfiguration.getMaximumFlingVelocity() >> 16) + 107, 5 - ExpandableListView.getPackedPositionGroup(0L), objArr);
        eyVar.c(((String) objArr[0]).intern(), str);
        c(context, cVar, eyVar);
    }

    private static String e(c cVar) throws Throwable {
        r = (l + 41) % 128;
        int i2 = AnonymousClass5.d[cVar.ordinal()];
        if (i2 == 1) {
            Object[] objArr = new Object[1];
            q((char) (1 - (ViewConfiguration.getGlobalActionKeyTimeout() > 0L ? 1 : (ViewConfiguration.getGlobalActionKeyTimeout() == 0L ? 0 : -1))), ViewConfiguration.getTouchSlop() >> 8, View.resolveSize(0, 0) + 21, objArr);
            return ((String) objArr[0]).intern();
        }
        if (i2 == 2) {
            Object[] objArr2 = new Object[1];
            q((char) Drawable.resolveOpacity(0, 0), Color.green(0) + 21, (TypedValue.complexToFraction(0, SelfieScan.RECOGNITION_FAIL_RESULT, SelfieScan.RECOGNITION_FAIL_RESULT) > SelfieScan.RECOGNITION_FAIL_RESULT ? 1 : (TypedValue.complexToFraction(0, SelfieScan.RECOGNITION_FAIL_RESULT, SelfieScan.RECOGNITION_FAIL_RESULT) == SelfieScan.RECOGNITION_FAIL_RESULT ? 0 : -1)) + 19, objArr2);
            return ((String) objArr2[0]).intern();
        }
        if (i2 == 3) {
            Object[] objArr3 = new Object[1];
            q((char) ((TypedValue.complexToFloat(0) > SelfieScan.RECOGNITION_FAIL_RESULT ? 1 : (TypedValue.complexToFloat(0) == SelfieScan.RECOGNITION_FAIL_RESULT ? 0 : -1)) + 27986), ExpandableListView.getPackedPositionChild(0L) + 41, KeyEvent.getDeadChar(0, 0) + 16, objArr3);
            String strIntern = ((String) objArr3[0]).intern();
            int i3 = r + 45;
            l = i3 % 128;
            if (i3 % 2 != 0) {
                int i4 = 25 / 0;
            }
            return strIntern;
        }
        if (i2 == 4) {
            Object[] objArr4 = new Object[1];
            q((char) (6838 - ExpandableListView.getPackedPositionGroup(0L)), 56 - View.resolveSize(0, 0), 13 - TextUtils.lastIndexOf("", '0', 0), objArr4);
            return ((String) objArr4[0]).intern();
        }
        if (i2 != 5) {
            return c(cVar);
        }
        Object[] objArr5 = new Object[1];
        q((char) (2590 - TextUtils.getOffsetBefore("", 0)), ExpandableListView.getPackedPositionChild(0L) + 71, 12 - (PointF.length(SelfieScan.RECOGNITION_FAIL_RESULT, SelfieScan.RECOGNITION_FAIL_RESULT) > SelfieScan.RECOGNITION_FAIL_RESULT ? 1 : (PointF.length(SelfieScan.RECOGNITION_FAIL_RESULT, SelfieScan.RECOGNITION_FAIL_RESULT) == SelfieScan.RECOGNITION_FAIL_RESULT ? 0 : -1)), objArr5);
        return ((String) objArr5[0]).intern();
    }

    private static void b(final Context context, final q qVar) {
        l = (r + 97) % 128;
        if (!((Boolean) bk.d(-261957882, nf.a.e(), nf.a.e(), nf.a.e(), nf.a.e(), new Object[0], 261957889)).booleanValue()) {
            r = (l + 43) % 128;
        } else {
            dj.d(new Runnable() { // from class: com.facetec.sdk.剑王
                @Override // java.lang.Runnable
                public final void run() {
                    t.e(context, qVar);
                }
            });
        }
    }

    public static void d(Context context, ar arVar, boolean z, bv.b bVar, String str) throws Throwable {
        boolean zBooleanValue;
        byte[][] bArrT;
        String strIntern;
        int i2 = l + 39;
        r = i2 % 128;
        if (i2 % 2 != 0) {
            if (context != null && c() && arVar != null) {
                int i3 = arVar.e;
                int i4 = arVar.b;
                ey eyVar = new ey();
                if (!z) {
                    Object[] objArr = new Object[1];
                    q((char) (Color.blue(0) + 56384), (-16776986) - Color.rgb(0, 0, 0), 11 - (ViewConfiguration.getMinimumFlingVelocity() >> 16), objArr);
                    strIntern = ((String) objArr[0]).intern();
                    if (bVar == bv.b.FRONT) {
                        bArrT = cv.s();
                    } else {
                        bArrT = cv.r();
                    }
                } else {
                    try {
                        zBooleanValue = ah.e(context).booleanValue();
                    } catch (ak e2) {
                        e2.printStackTrace();
                        c cVar = c.CAMERA_ERROR;
                        StringBuilder sb = new StringBuilder();
                        Object[] objArr2 = new Object[1];
                        q((char) (KeyEvent.getMaxKeyCode() >> 16), TextUtils.indexOf("", "", 0) + EnumC41897g.SDK_ASSET_ILLUSTRATION_ATOMIC_LOGO_VALUE, 38 - Drawable.resolveOpacity(0, 0), objArr2);
                        sb.append(((String) objArr2[0]).intern());
                        sb.append(e2);
                        d(context, cVar, sb.toString(), e2);
                        zBooleanValue = true;
                    }
                    Object[] objArr3 = new Object[1];
                    q((char) (TextUtils.getOffsetBefore("", 0) + 14417), 225 - (ViewConfiguration.getLongPressTimeout() >> 16), (AudioTrack.getMaxVolume() > SelfieScan.RECOGNITION_FAIL_RESULT ? 1 : (AudioTrack.getMaxVolume() == SelfieScan.RECOGNITION_FAIL_RESULT ? 0 : -1)) + 4, objArr3);
                    String strIntern2 = ((String) objArr3[0]).intern();
                    bArrT = cv.T(zBooleanValue, i3, i4);
                    strIntern = strIntern2;
                }
                if (bArrT.length == 0) {
                    return;
                }
                i = false;
                if (!j && bArrT[0].length != ((i3 * i4) << 2)) {
                    throw new AssertionError();
                }
                Object[] objArr4 = new Object[1];
                q((char) TextUtils.indexOf("", "", 0, 0), KeyEvent.getDeadChar(0, 0) + EnumC41897g.SDK_ASSET_ILLUSTRATION_PLAID_LOGO_NAVBAR_VALUE, (TypedValue.complexToFraction(0, SelfieScan.RECOGNITION_FAIL_RESULT, SelfieScan.RECOGNITION_FAIL_RESULT) > SelfieScan.RECOGNITION_FAIL_RESULT ? 1 : (TypedValue.complexToFraction(0, SelfieScan.RECOGNITION_FAIL_RESULT, SelfieScan.RECOGNITION_FAIL_RESULT) == SelfieScan.RECOGNITION_FAIL_RESULT ? 0 : -1)) + 2, objArr4);
                String strIntern3 = ((String) objArr4[0]).intern();
                Object[] objArr5 = new Object[1];
                q((char) KeyEvent.getDeadChar(0, 0), (SystemClock.elapsedRealtimeNanos() > 0L ? 1 : (SystemClock.elapsedRealtimeNanos() == 0L ? 0 : -1)) + EnumC41897g.SDK_ASSET_ILLUSTRATION_PLAID_OVERLAY_ACCOUNT_NUMBER_CONFIRMED_VALUE, View.combineMeasuredStates(0, 0) + 2, objArr5);
                eyVar.c(strIntern3, ((String) objArr5[0]).intern());
                Object[] objArr6 = new Object[1];
                q((char) (AudioTrack.getMinVolume() > SelfieScan.RECOGNITION_FAIL_RESULT ? 1 : (AudioTrack.getMinVolume() == SelfieScan.RECOGNITION_FAIL_RESULT ? 0 : -1)), (Process.myPid() >> 22) + EnumC41897g.SDK_ASSET_ILLUSTRATION_PLAID_OVERLAY_BALANCE_BEAM_02_VALUE, View.resolveSize(0, 0) + 9, objArr6);
                eyVar.c(((String) objArr6[0]).intern(), strIntern);
                Object[] objArr7 = new Object[1];
                q((char) (10989 - (Process.getElapsedCpuTime() > 0L ? 1 : (Process.getElapsedCpuTime() == 0L ? 0 : -1))), TextUtils.getOffsetBefore("", 0) + 254, TextUtils.indexOf("", "", 0, 0) + 14, objArr7);
                eyVar.c(((String) objArr7[0]).intern(), bk.b(context, false));
                Object[] objArr8 = new Object[1];
                q((char) (ViewConfiguration.getWindowTouchSlop() >> 8), KeyEvent.keyCodeFromString("") + EnumC41897g.SDK_ASSET_HEADER_ENABLE_TRANSFERS_VALUE, 12 - Drawable.resolveOpacity(0, 0), objArr8);
                eyVar.c(((String) objArr8[0]).intern(), str);
                ey eyVar2 = new ey();
                Object[] objArr9 = new Object[1];
                q((char) (TextUtils.lastIndexOf("", '0', 0) + 1), 281 - (SystemClock.uptimeMillis() > 0L ? 1 : (SystemClock.uptimeMillis() == 0L ? 0 : -1)), (AudioTrack.getMaxVolume() > SelfieScan.RECOGNITION_FAIL_RESULT ? 1 : (AudioTrack.getMaxVolume() == SelfieScan.RECOGNITION_FAIL_RESULT ? 0 : -1)), objArr9);
                eyVar2.b(((String) objArr9[0]).intern(), Integer.valueOf(i3));
                Object[] objArr10 = new Object[1];
                q((char) View.resolveSize(0, 0), AndroidCharacter.getMirror('0') + 233, (Process.getElapsedCpuTime() > 0L ? 1 : (Process.getElapsedCpuTime() == 0L ? 0 : -1)), objArr10);
                eyVar2.b(((String) objArr10[0]).intern(), Integer.valueOf(i4));
                Object[] objArr11 = new Object[1];
                q((char) (48069 - (ViewConfiguration.getTouchSlop() >> 8)), 330 - AndroidCharacter.getMirror('0'), 2 - ExpandableListView.getPackedPositionType(0L), objArr11);
                eyVar.a(((String) objArr11[0]).intern(), eyVar2);
                nd.a aVar = new nd.a();
                nb nbVar = nd.d;
                if (nbVar != null) {
                    if (nbVar.d.equals("multipart")) {
                        aVar.a = nbVar;
                        String strD = new em().e().b().d(eyVar);
                        Object[] objArr12 = new Object[1];
                        q((char) (20162 - Gravity.getAbsoluteGravity(0, 0)), 284 - Color.argb(0, 0, 0, 0), TextUtils.lastIndexOf("", '0', 0) + 11, objArr12);
                        aVar.b(nd.b.d(((String) objArr12[0]).intern(), null, ni.a(null, strD)));
                        for (int i5 = 1; i5 <= bArrT.length; i5++) {
                            byte[] bArr = bArrT[i5 - 1];
                            Bitmap bitmapCreateBitmap = Bitmap.createBitmap(i3, i4, Bitmap.Config.ARGB_8888);
                            ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
                            bitmapCreateBitmap.copyPixelsFromBuffer(ByteBuffer.wrap(bArr));
                            bitmapCreateBitmap.compress(Bitmap.CompressFormat.PNG, 100, byteArrayOutputStream);
                            byte[] byteArray = byteArrayOutputStream.toByteArray();
                            StringBuilder sb2 = new StringBuilder();
                            sb2.append(i5);
                            Object[] objArr13 = new Object[1];
                            q((char) ((ViewConfiguration.getMinimumFlingVelocity() >> 16) + 20290), (ViewConfiguration.getScrollDefaultDelay() >> 16) + EnumC41897g.SDK_ASSET_ILLUSTRATION_PLAID_LOGO_ONLY_VALUE, (Process.getElapsedCpuTime() > 0L ? 1 : (Process.getElapsedCpuTime() == 0L ? 0 : -1)) + 3, objArr13);
                            sb2.append(((String) objArr13[0]).intern());
                            String string = sb2.toString();
                            Object[] objArr14 = new Object[1];
                            q((char) (Color.argb(0, 0, 0, 0) + 53445), (KeyEvent.getMaxKeyCode() >> 16) + EnumC41897g.SDK_ASSET_BANK_ICON_CIRCLE_VALUE, 9 - (TypedValue.complexToFraction(0, SelfieScan.RECOGNITION_FAIL_RESULT, SelfieScan.RECOGNITION_FAIL_RESULT) > SelfieScan.RECOGNITION_FAIL_RESULT ? 1 : (TypedValue.complexToFraction(0, SelfieScan.RECOGNITION_FAIL_RESULT, SelfieScan.RECOGNITION_FAIL_RESULT) == SelfieScan.RECOGNITION_FAIL_RESULT ? 0 : -1)), objArr14);
                            aVar.b(nd.b.d(strIntern, string, ni.d(nb.a(((String) objArr14[0]).intern()), byteArray)));
                        }
                        nf nfVarB = ay.b(context);
                        View.combineMeasuredStates(0, 0);
                        ViewConfiguration.getMaximumFlingVelocity();
                        ViewConfiguration.getEdgeSlop();
                        Arrays.fill(bArrT, (Object) null);
                        try {
                            if (!aVar.b.isEmpty()) {
                                nd ndVar = new nd(aVar.d, aVar.a, aVar.b);
                                Object[] objArr15 = new Object[1];
                                q((char) (636 - (ViewConfiguration.getScrollBarSize() >> 8)), View.resolveSize(0, 0) + EnumC41897g.SDK_ASSET_ILLUSTRATION_CLIPBOARD_CIRCLE_DARK_APPEARANCE_VALUE, 52 - (ExpandableListView.getPackedPositionForGroup(0) > 0L ? 1 : (ExpandableListView.getPackedPositionForGroup(0) == 0L ? 0 : -1)), objArr15);
                                nfVarB.b(j.d(context, ((String) objArr15[0]).intern(), Boolean.TRUE).b(ndVar).d()).e(new mm() { // from class: com.facetec.sdk.t.3
                                    @Override // com.facetec.sdk.mm
                                    public final void b(nh nhVar) {
                                        t.i = true;
                                        nhVar.a();
                                    }

                                    @Override // com.facetec.sdk.mm
                                    public final void c(IOException iOException) {
                                    }
                                });
                                return;
                            }
                            throw new IllegalStateException("Multipart body must have at least one part.");
                        } catch (j.c e3) {
                            e3.printStackTrace();
                            return;
                        }
                    }
                    throw new IllegalArgumentException("multipart != ".concat(String.valueOf(nbVar)));
                }
                throw new NullPointerException("type == null");
            }
            r = (l + 41) % 128;
            return;
        }
        throw null;
    }

    private static String e(ej ejVar) throws Throwable {
        int i2 = r + 69;
        l = i2 % 128;
        if (i2 % 2 == 0) {
            switch (AnonymousClass5.c[ejVar.ordinal()]) {
                case 1:
                    Object[] objArr = new Object[1];
                    q((char) ((TypedValue.complexToFloat(0) > SelfieScan.RECOGNITION_FAIL_RESULT ? 1 : (TypedValue.complexToFloat(0) == SelfieScan.RECOGNITION_FAIL_RESULT ? 0 : -1)) + 16544), (-16777104) - Color.rgb(0, 0, 0), Color.argb(0, 0, 0, 0) + 7, objArr);
                    return ((String) objArr[0]).intern();
                case 2:
                    Object[] objArr2 = new Object[1];
                    q((char) (ViewConfiguration.getEdgeSlop() >> 16), (ViewConfiguration.getScrollBarFadeDuration() >> 16) + 119, (Process.getElapsedCpuTime() > 0L ? 1 : (Process.getElapsedCpuTime() == 0L ? 0 : -1)) + 12, objArr2);
                    return ((String) objArr2[0]).intern();
                case 3:
                    Object[] objArr3 = new Object[1];
                    q((char) (ViewConfiguration.getEdgeSlop() >> 16), TextUtils.getCapsMode("", 0, 0) + EnumC41897g.SDK_ASSET_ILLUSTRATION_IN_CONTROL_VALUE, Color.argb(0, 0, 0, 0) + 13, objArr3);
                    return ((String) objArr3[0]).intern();
                case 4:
                    Object[] objArr4 = new Object[1];
                    q((char) ((Process.getThreadPriority(0) + 20) >> 6), 146 - (ViewConfiguration.getGlobalActionKeyTimeout() > 0L ? 1 : (ViewConfiguration.getGlobalActionKeyTimeout() == 0L ? 0 : -1)), 15 - (ViewConfiguration.getEdgeSlop() >> 16), objArr4);
                    String strIntern = ((String) objArr4[0]).intern();
                    int i3 = r + 59;
                    l = i3 % 128;
                    if (i3 % 2 == 0) {
                        return strIntern;
                    }
                    throw null;
                case 5:
                    Object[] objArr5 = new Object[1];
                    q((char) (TextUtils.indexOf((CharSequence) "", '0', 0) + 1), (ViewConfiguration.getGlobalActionKeyTimeout() > 0L ? 1 : (ViewConfiguration.getGlobalActionKeyTimeout() == 0L ? 0 : -1)) + EnumC41897g.SDK_ASSET_ILLUSTRATION_INCOME_VALUE, 11 - TextUtils.lastIndexOf("", '0'), objArr5);
                    return ((String) objArr5[0]).intern();
                case 6:
                    Object[] objArr6 = new Object[1];
                    q((char) (ViewConfiguration.getDoubleTapTimeout() >> 16), (ViewConfiguration.getMaximumFlingVelocity() >> 16) + EnumC41897g.SDK_ASSET_ILLUSTRATION_CONSENT_HEADER_WEB3_DARK_APPEARANCE_VALUE, 15 - View.resolveSizeAndState(0, 0, 0), objArr6);
                    String strIntern2 = ((String) objArr6[0]).intern();
                    l = (r + EnumC41897g.SDK_ASSET_ILLUSTRATION_DEPOSIT_SWITCH_VALUE) % 128;
                    return strIntern2;
                default:
                    return String.valueOf(ejVar);
            }
        }
        int i4 = AnonymousClass5.c[ejVar.ordinal()];
        throw null;
    }

    private static void c(final Context context, final c cVar, final es esVar) {
        int i2 = l;
        r = (i2 + 115) % 128;
        if (context != null) {
            r = (i2 + 117) % 128;
            if (((Boolean) bk.d(-261957882, nf.a.e(), nf.a.e(), nf.a.e(), nf.a.e(), new Object[0], 261957889)).booleanValue()) {
                dj.a(new Runnable() { // from class: com.facetec.sdk.剑祖
                    @Override // java.lang.Runnable
                    public final void run() throws Throwable {
                        t.b(cVar, esVar, context);
                    }
                });
            }
        }
    }

    private static /* synthetic */ Object b(Object[] objArr) {
        final Runnable runnable = (Runnable) objArr[0];
        Thread thread = new Thread() { // from class: com.facetec.sdk.t.1
            @Override // java.lang.Thread, java.lang.Runnable
            public final void run() {
                setPriority(1);
                Process.setThreadPriority(19);
                runnable.run();
            }
        };
        thread.setPriority(1);
        thread.start();
        int i2 = r + 15;
        l = i2 % 128;
        if (i2 % 2 == 0) {
            return null;
        }
        throw null;
    }

    private static void c(final Context context, final boolean z, final q qVar) throws Throwable {
        l = (r + 53) % 128;
        if (((Boolean) bk.d(-261957882, nf.a.e(), nf.a.e(), nf.a.e(), nf.a.e(), new Object[0], 261957889)).booleanValue()) {
            final Context applicationContext = context.getApplicationContext();
            Object[] objArr = {new Runnable() { // from class: com.facetec.sdk.剑礼
                @Override // java.lang.Runnable
                public final void run() {
                    t.a(applicationContext, context, qVar, z);
                }
            }};
            int iE = ov.b.AnonymousClass1.e();
            e(ov.b.AnonymousClass1.e(), objArr, ov.b.AnonymousClass1.e(), ov.b.AnonymousClass1.e(), -1580775931, 1580775933, iE);
            int i2 = r + 5;
            l = i2 % 128;
            if (i2 % 2 != 0) {
                throw null;
            }
        }
    }

    public static void b(dh dhVar) throws Throwable {
        int i2 = l + 13;
        int i3 = i2 % 128;
        r = i3;
        if (i2 % 2 != 0) {
            f = dhVar;
            l = (i3 + 17) % 128;
            try {
                Object[] objArr = new Object[1];
                s(TextUtils.indexOf("", ""), (char) ((SystemClock.currentThreadTimeMillis() > (-1L) ? 1 : (SystemClock.currentThreadTimeMillis() == (-1L) ? 0 : -1)) - 1), (SystemClock.uptimeMillis() > 0L ? 1 : (SystemClock.uptimeMillis() == 0L ? 0 : -1)) + 15, objArr);
                Class<?> cls = Class.forName((String) objArr[0]);
                Object[] objArr2 = new Object[1];
                s((ViewConfiguration.getKeyRepeatTimeout() >> 16) + 16, (char) (ExpandableListView.getPackedPositionForGroup(0) > 0L ? 1 : (ExpandableListView.getPackedPositionForGroup(0) == 0L ? 0 : -1)), (AudioTrack.getMinVolume() > SelfieScan.RECOGNITION_FAIL_RESULT ? 1 : (AudioTrack.getMinVolume() == SelfieScan.RECOGNITION_FAIL_RESULT ? 0 : -1)) + 17, objArr2);
                h = ((Long) cls.getMethod((String) objArr2[0], null).invoke(null, null)).longValue();
                return;
            } catch (Throwable th) {
                Throwable cause = th.getCause();
                if (cause == null) {
                    throw th;
                }
                throw cause;
            }
        }
        f = dhVar;
        throw null;
    }

    public static void a(Context context, ArrayList<String> arrayList, String str, EnumC39477r enumC39477r, String str2, String str3, boolean z) throws Throwable {
        int i2 = r + 15;
        l = i2 % 128;
        if (i2 % 2 == 0) {
            if (c()) {
                Object[] objArr = new Object[1];
                q((char) (MotionEvent.axisFromString("") + 1), 487 - TextUtils.indexOf("", "", 0), 14 - (ViewConfiguration.getTouchSlop() >> 8), objArr);
                cv.H(((String) objArr[0]).intern(), 2);
                String strY = cv.y(h.a());
                if (strY.equals("")) {
                    int i3 = l + 91;
                    r = i3 % 128;
                    if (i3 % 2 != 0) {
                        if (!(!str.equals("")) && enumC39477r == EnumC39477r.FACE_SCAN) {
                            return;
                        }
                    } else {
                        str.equals("");
                        throw null;
                    }
                }
                String str4 = enumC39477r == EnumC39477r.ID_SCAN_ONLY ? str3 : str2;
                b = false;
                c(context.getApplicationContext(), false, new q(strY, enumC39477r, e(arrayList), str, cp.a, str4, str3, z));
                return;
            }
            return;
        }
        c();
        throw null;
    }

    private static synchronized q c(Context context) {
        q qVarB;
        File file;
        int length;
        int i2;
        try {
            File[] fileArrListFiles = context.getCacheDir().listFiles();
            qVarB = null;
            if (fileArrListFiles != null) {
                int i3 = l + 125;
                r = i3 % 128;
                if (i3 % 2 == 0) {
                    length = fileArrListFiles.length;
                    i2 = 1;
                } else {
                    length = fileArrListFiles.length;
                    i2 = 0;
                }
                while (i2 < length) {
                    file = fileArrListFiles[i2];
                    String name = file.getName();
                    Object[] objArr = new Object[1];
                    q((char) (ViewConfiguration.getKeyRepeatDelay() >> 16), 501 - Color.green(0), View.MeasureSpec.makeMeasureSpec(0, 0) + 15, objArr);
                    if (name.startsWith(((String) objArr[0]).intern())) {
                        r = (l + 77) % 128;
                        break;
                    }
                    i2++;
                }
                file = null;
            } else {
                file = null;
            }
            if (file != null) {
                int i4 = r + 89;
                l = i4 % 128;
                try {
                    try {
                    } catch (Exception e2) {
                        e2.printStackTrace();
                    }
                    if (i4 % 2 != 0) {
                        qVarB = q.b(bq.e(file, d(context, file.getName())));
                        int i5 = 93 / 0;
                    } else {
                        qVarB = q.b(bq.e(file, d(context, file.getName())));
                    }
                } finally {
                    file.delete();
                }
            }
        } catch (Throwable th) {
            throw th;
        }
        return qVarB;
    }

    private static /* synthetic */ Object e(Object[] objArr) {
        final Context context = (Context) objArr[0];
        int i2 = r + 115;
        l = i2 % 128;
        if (i2 % 2 != 0) {
            ((Boolean) bk.d(-261957882, nf.a.e(), nf.a.e(), nf.a.e(), nf.a.e(), new Object[0], 261957889)).booleanValue();
            throw null;
        }
        if (!((Boolean) bk.d(-261957882, nf.a.e(), nf.a.e(), nf.a.e(), nf.a.e(), new Object[0], 261957889)).booleanValue()) {
            return null;
        }
        dj.d(new Runnable() { // from class: com.facetec.sdk.剑神
            @Override // java.lang.Runnable
            public final void run() throws Throwable {
                t.a(context);
            }
        });
        r = (l + 111) % 128;
        return null;
    }

    public static void b(Context context) throws Throwable {
        int iE = ov.b.AnonymousClass1.e();
        int iE2 = ov.b.AnonymousClass1.e();
        e(ov.b.AnonymousClass1.e(), new Object[]{context}, ov.b.AnonymousClass1.e(), iE2, -156914999, 156915000, iE);
    }

    private static void b(Runnable runnable) throws Throwable {
        int iE = ov.b.AnonymousClass1.e();
        int iE2 = ov.b.AnonymousClass1.e();
        e(ov.b.AnonymousClass1.e(), new Object[]{runnable}, ov.b.AnonymousClass1.e(), iE2, -1580775931, 1580775933, iE);
    }

    private static String b() {
        int iE = ov.b.AnonymousClass1.e();
        int iE2 = ov.b.AnonymousClass1.e();
        return (String) e(ov.b.AnonymousClass1.e(), new Object[0], ov.b.AnonymousClass1.e(), iE2, 620545391, -620545391, iE);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static /* synthetic */ void b(c cVar, es esVar, Context context) throws Throwable {
        int iE = ov.b.AnonymousClass1.e();
        int iE2 = ov.b.AnonymousClass1.e();
        e(ov.b.AnonymousClass1.e(), new Object[]{cVar, esVar, context}, ov.b.AnonymousClass1.e(), iE2, 1765722492, -1765722489, iE);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static /* synthetic */ void e(Context context, q qVar) {
        int i2 = l;
        r = (i2 + EnumC41897g.SDK_ASSET_ILLUSTRATION_CALENDAR_VALUE) % 128;
        if (!j) {
            int i3 = i2 + 43;
            r = i3 % 128;
            if (i3 % 2 == 0) {
                throw null;
            }
            if (context == null) {
                throw new AssertionError();
            }
        }
        int iE = ov.b.AnonymousClass1.e();
        String str = (String) e(ov.b.AnonymousClass1.e(), new Object[0], ov.b.AnonymousClass1.e(), ov.b.AnonymousClass1.e(), 620545391, -620545391, iE);
        try {
            bq.d(new File(context.getCacheDir(), str), d(context, str), new em().e().b().e(qVar).getBytes(StandardCharsets.UTF_8));
            int i4 = r + 31;
            l = i4 % 128;
            if (i4 % 2 != 0) {
                throw null;
            }
        } catch (Exception e2) {
            e2.printStackTrace();
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    /* JADX WARN: Code restructure failed: missing block: B:12:0x001f, code lost:
    
        throw new java.lang.AssertionError();
     */
    /* JADX WARN: Code restructure failed: missing block: B:7:0x0014, code lost:
    
        if (r4 != null) goto L13;
     */
    /* JADX WARN: Code restructure failed: missing block: B:9:0x0017, code lost:
    
        if (r4 != null) goto L13;
     */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public static /* synthetic */ void a(android.content.Context r4) throws java.lang.Throwable {
        /*
            boolean r0 = com.facetec.sdk.t.j
            r1 = 0
            if (r0 != 0) goto L20
            int r0 = com.facetec.sdk.t.r
            int r0 = r0 + 107
            int r2 = r0 % 128
            com.facetec.sdk.t.l = r2
            int r0 = r0 % 2
            if (r0 == 0) goto L17
            r0 = 88
            int r0 = r0 / r1
            if (r4 == 0) goto L1a
            goto L20
        L17:
            if (r4 == 0) goto L1a
            goto L20
        L1a:
            java.lang.AssertionError r4 = new java.lang.AssertionError
            r4.<init>()
            throw r4
        L20:
            android.content.Context r4 = r4.getApplicationContext()
            com.facetec.sdk.q r0 = c(r4)
            if (r0 == 0) goto L3c
            int r2 = com.facetec.sdk.t.l
            int r2 = r2 + 27
            int r3 = r2 % 128
            com.facetec.sdk.t.r = r3
            int r2 = r2 % 2
            if (r2 != 0) goto L3a
        L36:
            c(r4, r1, r0)
            goto L3c
        L3a:
            r1 = 1
            goto L36
        L3c:
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: com.facetec.sdk.t.a(android.content.Context):void");
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static /* synthetic */ void a(Context context, Context context2, q qVar, boolean z) {
        ay.c(context).d(context2, qVar, z, new d(context, qVar));
        int i2 = l + 43;
        r = i2 % 128;
        if (i2 % 2 == 0) {
            throw null;
        }
    }

    private static ArrayList<String> e(ArrayList<String> arrayList) {
        ArrayList<String> arrayList2 = new ArrayList<>();
        Iterator<String> it = arrayList.iterator();
        r = (l + 119) % 128;
        while (it.hasNext()) {
            l = (r + 87) % 128;
            arrayList2.add(cj.b(it.next()));
        }
        return arrayList2;
    }

    private static String a(dh dhVar) throws Throwable {
        r = (l + 81) % 128;
        switch (AnonymousClass5.b[dhVar.ordinal()]) {
            case 1:
                Object[] objArr = new Object[1];
                q((char) (65227 - (SystemClock.uptimeMillis() > 0L ? 1 : (SystemClock.uptimeMillis() == 0L ? 0 : -1))), View.combineMeasuredStates(0, 0) + 539, Drawable.resolveOpacity(0, 0) + 16, objArr);
                String strIntern = ((String) objArr[0]).intern();
                r = (l + 109) % 128;
                return strIntern;
            case 2:
                Object[] objArr2 = new Object[1];
                q((char) ((Process.myPid() >> 22) + 62852), 555 - (PointF.length(SelfieScan.RECOGNITION_FAIL_RESULT, SelfieScan.RECOGNITION_FAIL_RESULT) > SelfieScan.RECOGNITION_FAIL_RESULT ? 1 : (PointF.length(SelfieScan.RECOGNITION_FAIL_RESULT, SelfieScan.RECOGNITION_FAIL_RESULT) == SelfieScan.RECOGNITION_FAIL_RESULT ? 0 : -1)), 23 - (ViewConfiguration.getFadingEdgeLength() >> 16), objArr2);
                return ((String) objArr2[0]).intern();
            case 3:
                Object[] objArr3 = new Object[1];
                q((char) (ExpandableListView.getPackedPositionForGroup(0) > 0L ? 1 : (ExpandableListView.getPackedPositionForGroup(0) == 0L ? 0 : -1)), 578 - TextUtils.getOffsetBefore("", 0), 14 - (ViewConfiguration.getMinimumFlingVelocity() >> 16), objArr3);
                String strIntern2 = ((String) objArr3[0]).intern();
                r = (l + 59) % 128;
                return strIntern2;
            case 4:
                Object[] objArr4 = new Object[1];
                q((char) TextUtils.indexOf("", "", 0), 591 - TextUtils.lastIndexOf("", '0'), 16 - TextUtils.getTrimmedLength(""), objArr4);
                return ((String) objArr4[0]).intern();
            case 5:
                Object[] objArr5 = new Object[1];
                q((char) (((byte) KeyEvent.getModifierMetaStateMask()) + 1), 607 - ImageFormat.getBitsPerPixel(0), 15 - TextUtils.getOffsetBefore("", 0), objArr5);
                return ((String) objArr5[0]).intern();
            case 6:
                Object[] objArr6 = new Object[1];
                q((char) (MotionEvent.axisFromString("") + 1), Color.alpha(0) + 623, (Process.getElapsedCpuTime() > 0L ? 1 : (Process.getElapsedCpuTime() == 0L ? 0 : -1)) + 12, objArr6);
                return ((String) objArr6[0]).intern();
            case 7:
                Object[] objArr7 = new Object[1];
                q((char) (TextUtils.indexOf("", "", 0) + 37109), Process.getGidForName("") + 637, (ViewConfiguration.getMaximumFlingVelocity() >> 16) + 12, objArr7);
                return ((String) objArr7[0]).intern();
            case 8:
                Object[] objArr8 = new Object[1];
                q((char) (9818 - (KeyEvent.getMaxKeyCode() >> 16)), AndroidCharacter.getMirror('0') + 600, TextUtils.indexOf((CharSequence) "", '0', 0, 0) + 12, objArr8);
                return ((String) objArr8[0]).intern();
            case 9:
                Object[] objArr9 = new Object[1];
                q((char) (ViewConfiguration.getTouchSlop() >> 8), TextUtils.lastIndexOf("", '0', 0, 0) + 660, 8 - Color.red(0), objArr9);
                return ((String) objArr9[0]).intern();
            case 10:
                Object[] objArr10 = new Object[1];
                q((char) (Process.myTid() >> 22), View.MeasureSpec.getMode(0) + 667, 9 - (ViewConfiguration.getEdgeSlop() >> 16), objArr10);
                return ((String) objArr10[0]).intern();
            case 11:
                Object[] objArr11 = new Object[1];
                q((char) (63687 - (ViewConfiguration.getMinimumFlingVelocity() >> 16)), TextUtils.getCapsMode("", 0, 0) + 676, 14 - TextUtils.getTrimmedLength(""), objArr11);
                return ((String) objArr11[0]).intern();
            case 12:
                Object[] objArr12 = new Object[1];
                q((char) ((-1) - (ExpandableListView.getPackedPositionForChild(0, 0) > 0L ? 1 : (ExpandableListView.getPackedPositionForChild(0, 0) == 0L ? 0 : -1))), ((Process.getThreadPriority(0) + 20) >> 6) + 690, (ViewConfiguration.getPressedStateDuration() >> 16) + 16, objArr12);
                return ((String) objArr12[0]).intern();
            case 13:
                Object[] objArr13 = new Object[1];
                q((char) (21243 - (ExpandableListView.getPackedPositionForChild(0, 0) > 0L ? 1 : (ExpandableListView.getPackedPositionForChild(0, 0) == 0L ? 0 : -1))), AndroidCharacter.getMirror('0') + 658, 21 - TextUtils.indexOf((CharSequence) "", '0', 0, 0), objArr13);
                return ((String) objArr13[0]).intern();
            default:
                return String.valueOf(dhVar);
        }
    }

    public static boolean c() {
        r = (l + 73) % 128;
        boolean zC = h.c();
        l = (r + 31) % 128;
        return zC;
    }

    private static String c(c cVar) throws Throwable {
        switch (AnonymousClass5.d[cVar.ordinal()]) {
            case 1:
                Object[] objArr = new Object[1];
                q((char) (29678 - Color.red(0)), 794 - Color.argb(0, 0, 0, 0), 22 - (ExpandableListView.getPackedPositionForGroup(0) > 0L ? 1 : (ExpandableListView.getPackedPositionForGroup(0) == 0L ? 0 : -1)), objArr);
                return ((String) objArr[0]).intern();
            case 2:
                Object[] objArr2 = new Object[1];
                q((char) (TextUtils.lastIndexOf("", '0', 0) + 1), Color.alpha(0) + 924, 20 - Color.red(0), objArr2);
                String strIntern = ((String) objArr2[0]).intern();
                int i2 = r + 81;
                l = i2 % 128;
                if (i2 % 2 == 0) {
                    return strIntern;
                }
                throw null;
            case 3:
                Object[] objArr3 = new Object[1];
                q((char) (Color.red(0) + 4972), (ViewConfiguration.getKeyRepeatTimeout() >> 16) + 876, Color.alpha(0) + 29, objArr3);
                return ((String) objArr3[0]).intern();
            case 4:
                Object[] objArr4 = new Object[1];
                q((char) (AudioTrack.getMinVolume() > SelfieScan.RECOGNITION_FAIL_RESULT ? 1 : (AudioTrack.getMinVolume() == SelfieScan.RECOGNITION_FAIL_RESULT ? 0 : -1)), TextUtils.lastIndexOf("", '0', 0, 0) + 945, 26 - TextUtils.lastIndexOf("", '0', 0, 0), objArr4);
                return ((String) objArr4[0]).intern();
            case 5:
                Object[] objArr5 = new Object[1];
                q((char) (TextUtils.lastIndexOf("", '0', 0) + 44436), (ViewConfiguration.getMaximumFlingVelocity() >> 16) + 905, 19 - ExpandableListView.getPackedPositionType(0L), objArr5);
                return ((String) objArr5[0]).intern();
            case 6:
                Object[] objArr6 = new Object[1];
                q((char) ((SystemClock.elapsedRealtimeNanos() > 0L ? 1 : (SystemClock.elapsedRealtimeNanos() == 0L ? 0 : -1)) - 1), 728 - (ViewConfiguration.getScrollDefaultDelay() >> 16), 15 - TextUtils.indexOf((CharSequence) "", '0', 0), objArr6);
                return ((String) objArr6[0]).intern();
            case 7:
                Object[] objArr7 = new Object[1];
                q((char) (28206 - (CdmaCellLocation.convertQuartSecToDecDegrees(0) > 0.0d ? 1 : (CdmaCellLocation.convertQuartSecToDecDegrees(0) == 0.0d ? 0 : -1))), Color.rgb(0, 0, 0) + 16777960, (ViewConfiguration.getTouchSlop() >> 8) + 28, objArr7);
                return ((String) objArr7[0]).intern();
            case 8:
                Object[] objArr8 = new Object[1];
                q((char) (ViewConfiguration.getTapTimeout() >> 16), TextUtils.getCapsMode("", 0, 0) + 772, 22 - (ViewConfiguration.getMaximumFlingVelocity() >> 16), objArr8);
                return ((String) objArr8[0]).intern();
            case 9:
                Object[] objArr9 = new Object[1];
                q((char) (Gravity.getAbsoluteGravity(0, 0) + 58826), 816 - KeyEvent.keyCodeFromString(""), 33 - ((Process.getThreadPriority(0) + 20) >> 6), objArr9);
                return ((String) objArr9[0]).intern();
            case 10:
                Object[] objArr10 = new Object[1];
                q((char) (49775 - (ViewConfiguration.getJumpTapTimeout() >> 16)), 848 - (ExpandableListView.getPackedPositionForChild(0, 0) > 0L ? 1 : (ExpandableListView.getPackedPositionForChild(0, 0) == 0L ? 0 : -1)), 27 - (ViewConfiguration.getScrollDefaultDelay() >> 16), objArr10);
                return ((String) objArr10[0]).intern();
            case 11:
                Object[] objArr11 = new Object[1];
                q((char) TextUtils.indexOf("", ""), (ViewConfiguration.getMaximumFlingVelocity() >> 16) + 971, 12 - (ViewConfiguration.getLongPressTimeout() >> 16), objArr11);
                return ((String) objArr11[0]).intern();
            case 12:
                Object[] objArr12 = new Object[1];
                q((char) (ExpandableListView.getPackedPositionForGroup(0) > 0L ? 1 : (ExpandableListView.getPackedPositionForGroup(0) == 0L ? 0 : -1)), ((Process.getThreadPriority(0) + 20) >> 6) + 983, KeyEvent.keyCodeFromString("") + 13, objArr12);
                return ((String) objArr12[0]).intern();
            case 13:
                Object[] objArr13 = new Object[1];
                q((char) (ViewConfiguration.getKeyRepeatTimeout() >> 16), 996 - View.MeasureSpec.getMode(0), 10 - TextUtils.indexOf((CharSequence) "", '0'), objArr13);
                return ((String) objArr13[0]).intern();
            case 14:
                Object[] objArr14 = new Object[1];
                q((char) (ViewConfiguration.getMaximumFlingVelocity() >> 16), TextUtils.getTrimmedLength("") + 1007, TextUtils.getCapsMode("", 0, 0) + 20, objArr14);
                return ((String) objArr14[0]).intern();
            case 15:
                Object[] objArr15 = new Object[1];
                q((char) (48202 - (ViewConfiguration.getKeyRepeatTimeout() >> 16)), 1027 - KeyEvent.getDeadChar(0, 0), 16 - Process.getGidForName(""), objArr15);
                return ((String) objArr15[0]).intern();
            case 16:
                Object[] objArr16 = new Object[1];
                q((char) ((TypedValue.complexToFraction(0, SelfieScan.RECOGNITION_FAIL_RESULT, SelfieScan.RECOGNITION_FAIL_RESULT) > SelfieScan.RECOGNITION_FAIL_RESULT ? 1 : (TypedValue.complexToFraction(0, SelfieScan.RECOGNITION_FAIL_RESULT, SelfieScan.RECOGNITION_FAIL_RESULT) == SelfieScan.RECOGNITION_FAIL_RESULT ? 0 : -1)) + 19263), 1045 - (ViewConfiguration.getScrollFriction() > SelfieScan.RECOGNITION_FAIL_RESULT ? 1 : (ViewConfiguration.getScrollFriction() == SelfieScan.RECOGNITION_FAIL_RESULT ? 0 : -1)), 11 - TextUtils.getOffsetAfter("", 0), objArr16);
                return ((String) objArr16[0]).intern();
            case 17:
                Object[] objArr17 = new Object[1];
                q((char) (14849 - (ViewConfiguration.getKeyRepeatTimeout() >> 16)), 1055 - View.getDefaultSize(0, 0), 8 - (ViewConfiguration.getLongPressTimeout() >> 16), objArr17);
                return ((String) objArr17[0]).intern();
            case 18:
                Object[] objArr18 = new Object[1];
                q((char) (TextUtils.lastIndexOf("", '0') + 54653), (ViewConfiguration.getFadingEdgeLength() >> 16) + 1063, ImageFormat.getBitsPerPixel(0) + 19, objArr18);
                return ((String) objArr18[0]).intern();
            case 19:
                Object[] objArr19 = new Object[1];
                q((char) (3404 - TextUtils.getCapsMode("", 0, 0)), (SystemClock.uptimeMillis() > 0L ? 1 : (SystemClock.uptimeMillis() == 0L ? 0 : -1)) + 1080, 20 - (AudioTrack.getMaxVolume() > SelfieScan.RECOGNITION_FAIL_RESULT ? 1 : (AudioTrack.getMaxVolume() == SelfieScan.RECOGNITION_FAIL_RESULT ? 0 : -1)), objArr19);
                return ((String) objArr19[0]).intern();
            case 20:
                Object[] objArr20 = new Object[1];
                q((char) ((-1) - MotionEvent.axisFromString("")), (ViewConfiguration.getMinimumFlingVelocity() >> 16) + 1100, TextUtils.getTrimmedLength("") + 21, objArr20);
                return ((String) objArr20[0]).intern();
            case 21:
                Object[] objArr21 = new Object[1];
                q((char) ((ViewConfiguration.getScrollFriction() > SelfieScan.RECOGNITION_FAIL_RESULT ? 1 : (ViewConfiguration.getScrollFriction() == SelfieScan.RECOGNITION_FAIL_RESULT ? 0 : -1)) + 58086), 1120 - TextUtils.indexOf((CharSequence) "", '0', 0), 14 - Gravity.getAbsoluteGravity(0, 0), objArr21);
                return ((String) objArr21[0]).intern();
            case 22:
                Object[] objArr22 = new Object[1];
                q((char) (ViewConfiguration.getTouchSlop() >> 8), (-16776081) - Color.rgb(0, 0, 0), Color.blue(0) + 14, objArr22);
                return ((String) objArr22[0]).intern();
            case 23:
                Object[] objArr23 = new Object[1];
                q((char) TextUtils.indexOf("", "", 0, 0), TextUtils.getOffsetAfter("", 0) + 1149, ((Process.getThreadPriority(0) + 20) >> 6) + 21, objArr23);
                return ((String) objArr23[0]).intern();
            case 24:
                Object[] objArr24 = new Object[1];
                q((char) Color.red(0), View.combineMeasuredStates(0, 0) + 1170, 27 - (Process.myPid() >> 22), objArr24);
                return ((String) objArr24[0]).intern();
            case 25:
                Object[] objArr25 = new Object[1];
                q((char) (TextUtils.lastIndexOf("", '0', 0, 0) + 70), View.getDefaultSize(0, 0) + 1197, TextUtils.getTrimmedLength("") + 28, objArr25);
                return ((String) objArr25[0]).intern();
            case 26:
                Object[] objArr26 = new Object[1];
                q((char) (MotionEvent.axisFromString("") + 1), (AudioTrack.getMaxVolume() > SelfieScan.RECOGNITION_FAIL_RESULT ? 1 : (AudioTrack.getMaxVolume() == SelfieScan.RECOGNITION_FAIL_RESULT ? 0 : -1)) + 1224, (ViewConfiguration.getDoubleTapTimeout() >> 16) + 4, objArr26);
                return ((String) objArr26[0]).intern();
            case 27:
                Object[] objArr27 = new Object[1];
                q((char) (((byte) KeyEvent.getModifierMetaStateMask()) + 1), (ViewConfiguration.getScrollFriction() > SelfieScan.RECOGNITION_FAIL_RESULT ? 1 : (ViewConfiguration.getScrollFriction() == SelfieScan.RECOGNITION_FAIL_RESULT ? 0 : -1)) + 1228, 3 - TextUtils.indexOf("", ""), objArr27);
                return ((String) objArr27[0]).intern();
            case 28:
                Object[] objArr28 = new Object[1];
                q((char) (ViewConfiguration.getFadingEdgeLength() >> 16), 1231 - TextUtils.lastIndexOf("", '0', 0, 0), 6 - (ViewConfiguration.getZoomControlsTimeout() > 0L ? 1 : (ViewConfiguration.getZoomControlsTimeout() == 0L ? 0 : -1)), objArr28);
                return ((String) objArr28[0]).intern();
            case 29:
                Object[] objArr29 = new Object[1];
                q((char) (CdmaCellLocation.convertQuartSecToDecDegrees(0) > 0.0d ? 1 : (CdmaCellLocation.convertQuartSecToDecDegrees(0) == 0.0d ? 0 : -1)), 1237 - ExpandableListView.getPackedPositionType(0L), (ViewConfiguration.getFadingEdgeLength() >> 16) + 3, objArr29);
                return ((String) objArr29[0]).intern();
            case 30:
                Object[] objArr30 = new Object[1];
                q((char) (1105 - View.MeasureSpec.getSize(0)), 1240 - (ViewConfiguration.getPressedStateDuration() >> 16), (ViewConfiguration.getZoomControlsTimeout() > 0L ? 1 : (ViewConfiguration.getZoomControlsTimeout() == 0L ? 0 : -1)) + 2, objArr30);
                return ((String) objArr30[0]).intern();
            case 31:
                Object[] objArr31 = new Object[1];
                q((char) (1 - (SystemClock.uptimeMillis() > 0L ? 1 : (SystemClock.uptimeMillis() == 0L ? 0 : -1))), 1243 - (ViewConfiguration.getPressedStateDuration() >> 16), 3 - ((Process.getThreadPriority(0) + 20) >> 6), objArr31);
                return ((String) objArr31[0]).intern();
            case 32:
                Object[] objArr32 = new Object[1];
                q((char) ((SystemClock.uptimeMillis() > 0L ? 1 : (SystemClock.uptimeMillis() == 0L ? 0 : -1)) + 1307), (CdmaCellLocation.convertQuartSecToDecDegrees(0) > 0.0d ? 1 : (CdmaCellLocation.convertQuartSecToDecDegrees(0) == 0.0d ? 0 : -1)) + 1246, ((byte) KeyEvent.getModifierMetaStateMask()) + 9, objArr32);
                return ((String) objArr32[0]).intern();
            case 33:
                Object[] objArr33 = new Object[1];
                q((char) ((Process.getElapsedCpuTime() > 0L ? 1 : (Process.getElapsedCpuTime() == 0L ? 0 : -1)) - 1), 1253 - ((byte) KeyEvent.getModifierMetaStateMask()), ((byte) KeyEvent.getModifierMetaStateMask()) + 22, objArr33);
                return ((String) objArr33[0]).intern();
            case 34:
                Object[] objArr34 = new Object[1];
                q((char) ((AudioTrack.getMaxVolume() > SelfieScan.RECOGNITION_FAIL_RESULT ? 1 : (AudioTrack.getMaxVolume() == SelfieScan.RECOGNITION_FAIL_RESULT ? 0 : -1)) - 1), AndroidCharacter.getMirror('0') + 1227, 3 - Gravity.getAbsoluteGravity(0, 0), objArr34);
                return ((String) objArr34[0]).intern();
            case 35:
                Object[] objArr35 = new Object[1];
                q((char) (TextUtils.lastIndexOf("", '0', 0) + 15917), 1279 - (SystemClock.elapsedRealtime() > 0L ? 1 : (SystemClock.elapsedRealtime() == 0L ? 0 : -1)), 3 - Drawable.resolveOpacity(0, 0), objArr35);
                return ((String) objArr35[0]).intern();
            case 36:
                Object[] objArr36 = new Object[1];
                q((char) (((byte) KeyEvent.getModifierMetaStateMask()) + ISO7816.INS_UNBLOCK_CHV), (Process.getElapsedCpuTime() > 0L ? 1 : (Process.getElapsedCpuTime() == 0L ? 0 : -1)) + 1280, 3 - Color.green(0), objArr36);
                String strIntern2 = ((String) objArr36[0]).intern();
                int i3 = l + 73;
                r = i3 % 128;
                if (i3 % 2 != 0) {
                    return strIntern2;
                }
                throw null;
            case 37:
                Object[] objArr37 = new Object[1];
                q((char) View.combineMeasuredStates(0, 0), 1284 - (KeyEvent.getMaxKeyCode() >> 16), TextUtils.getTrimmedLength("") + 34, objArr37);
                return ((String) objArr37[0]).intern();
            case 38:
                Object[] objArr38 = new Object[1];
                q((char) (43235 - (SystemClock.uptimeMillis() > 0L ? 1 : (SystemClock.uptimeMillis() == 0L ? 0 : -1))), View.resolveSize(0, 0) + 1318, (ViewConfiguration.getFadingEdgeLength() >> 16) + 32, objArr38);
                return ((String) objArr38[0]).intern();
            case 39:
                Object[] objArr39 = new Object[1];
                q((char) (ViewConfiguration.getPressedStateDuration() >> 16), AndroidCharacter.getMirror('0') + 1302, (SystemClock.elapsedRealtimeNanos() > 0L ? 1 : (SystemClock.elapsedRealtimeNanos() == 0L ? 0 : -1)) + 25, objArr39);
                return ((String) objArr39[0]).intern();
            case 40:
                Object[] objArr40 = new Object[1];
                q((char) (62240 - (ViewConfiguration.getMaximumDrawingCacheSize() >> 24)), 1376 - TextUtils.getCapsMode("", 0, 0), (ViewConfiguration.getZoomControlsTimeout() > 0L ? 1 : (ViewConfiguration.getZoomControlsTimeout() == 0L ? 0 : -1)) + 27, objArr40);
                return ((String) objArr40[0]).intern();
            case 41:
                Object[] objArr41 = new Object[1];
                q((char) (64382 - (ExpandableListView.getPackedPositionForGroup(0) > 0L ? 1 : (ExpandableListView.getPackedPositionForGroup(0) == 0L ? 0 : -1))), (ViewConfiguration.getDoubleTapTimeout() >> 16) + 1404, 34 - Color.red(0), objArr41);
                return ((String) objArr41[0]).intern();
            case 42:
                Object[] objArr42 = new Object[1];
                q((char) (TextUtils.lastIndexOf("", '0', 0) + 1), 1437 - TextUtils.indexOf((CharSequence) "", '0', 0), 17 - (SystemClock.elapsedRealtime() > 0L ? 1 : (SystemClock.elapsedRealtime() == 0L ? 0 : -1)), objArr42);
                return ((String) objArr42[0]).intern();
            case 43:
                Object[] objArr43 = new Object[1];
                q((char) (35321 - (ViewConfiguration.getScrollFriction() > SelfieScan.RECOGNITION_FAIL_RESULT ? 1 : (ViewConfiguration.getScrollFriction() == SelfieScan.RECOGNITION_FAIL_RESULT ? 0 : -1))), TextUtils.getCapsMode("", 0, 0) + 1454, View.combineMeasuredStates(0, 0) + 30, objArr43);
                return ((String) objArr43[0]).intern();
            case 44:
                Object[] objArr44 = new Object[1];
                q((char) (TextUtils.lastIndexOf("", '0') + 49572), 1484 - (AudioTrack.getMinVolume() > SelfieScan.RECOGNITION_FAIL_RESULT ? 1 : (AudioTrack.getMinVolume() == SelfieScan.RECOGNITION_FAIL_RESULT ? 0 : -1)), (TypedValue.complexToFraction(0, SelfieScan.RECOGNITION_FAIL_RESULT, SelfieScan.RECOGNITION_FAIL_RESULT) > SelfieScan.RECOGNITION_FAIL_RESULT ? 1 : (TypedValue.complexToFraction(0, SelfieScan.RECOGNITION_FAIL_RESULT, SelfieScan.RECOGNITION_FAIL_RESULT) == SelfieScan.RECOGNITION_FAIL_RESULT ? 0 : -1)) + 24, objArr44);
                return ((String) objArr44[0]).intern();
            case 45:
                Object[] objArr45 = new Object[1];
                q((char) (5382 - (ViewConfiguration.getScrollDefaultDelay() >> 16)), (SystemClock.elapsedRealtime() > 0L ? 1 : (SystemClock.elapsedRealtime() == 0L ? 0 : -1)) + 1507, 33 - (ViewConfiguration.getMaximumFlingVelocity() >> 16), objArr45);
                return ((String) objArr45[0]).intern();
            case 46:
                Object[] objArr46 = new Object[1];
                q((char) (19246 - (ViewConfiguration.getScrollDefaultDelay() >> 16)), (SystemClock.uptimeMillis() > 0L ? 1 : (SystemClock.uptimeMillis() == 0L ? 0 : -1)) + 1540, (ViewConfiguration.getMaximumDrawingCacheSize() >> 24) + 32, objArr46);
                return ((String) objArr46[0]).intern();
            case 47:
                Object[] objArr47 = new Object[1];
                q((char) (TypedValue.complexToFloat(0) > SelfieScan.RECOGNITION_FAIL_RESULT ? 1 : (TypedValue.complexToFloat(0) == SelfieScan.RECOGNITION_FAIL_RESULT ? 0 : -1)), Color.rgb(0, 0, 0) + 16778789, 32 - View.resolveSizeAndState(0, 0, 0), objArr47);
                return ((String) objArr47[0]).intern();
            case 48:
                Object[] objArr48 = new Object[1];
                q((char) ExpandableListView.getPackedPositionGroup(0L), View.combineMeasuredStates(0, 0) + 1605, 27 - Drawable.resolveOpacity(0, 0), objArr48);
                return ((String) objArr48[0]).intern();
            case 49:
                Object[] objArr49 = new Object[1];
                q((char) ((Process.getThreadPriority(0) + 20) >> 6), ((byte) KeyEvent.getModifierMetaStateMask()) + 1633, 18 - (ViewConfiguration.getScrollFriction() > SelfieScan.RECOGNITION_FAIL_RESULT ? 1 : (ViewConfiguration.getScrollFriction() == SelfieScan.RECOGNITION_FAIL_RESULT ? 0 : -1)), objArr49);
                return ((String) objArr49[0]).intern();
            case 50:
                Object[] objArr50 = new Object[1];
                q((char) KeyEvent.normalizeMetaState(0), 1649 - (ViewConfiguration.getTapTimeout() >> 16), (SystemClock.currentThreadTimeMillis() > (-1L) ? 1 : (SystemClock.currentThreadTimeMillis() == (-1L) ? 0 : -1)) + 14, objArr50);
                return ((String) objArr50[0]).intern();
            case 51:
                Object[] objArr51 = new Object[1];
                q((char) (6079 - (ViewConfiguration.getTouchSlop() >> 8)), 1664 - TextUtils.getOffsetBefore("", 0), 27 - (ViewConfiguration.getScrollBarFadeDuration() >> 16), objArr51);
                return ((String) objArr51[0]).intern();
            case 52:
                Object[] objArr52 = new Object[1];
                q((char) View.combineMeasuredStates(0, 0), (ViewConfiguration.getMaximumDrawingCacheSize() >> 24) + 1691, 30 - Drawable.resolveOpacity(0, 0), objArr52);
                return ((String) objArr52[0]).intern();
            case 53:
                Object[] objArr53 = new Object[1];
                q((char) (ViewConfiguration.getEdgeSlop() >> 16), 1721 - KeyEvent.getDeadChar(0, 0), View.resolveSize(0, 0) + 29, objArr53);
                return ((String) objArr53[0]).intern();
            case 54:
                Object[] objArr54 = new Object[1];
                q((char) (ViewConfiguration.getScrollBarFadeDuration() >> 16), Color.argb(0, 0, 0, 0) + 1750, 39 - (ViewConfiguration.getMaximumFlingVelocity() >> 16), objArr54);
                return ((String) objArr54[0]).intern();
            case 55:
                Object[] objArr55 = new Object[1];
                q((char) (32895 - TextUtils.lastIndexOf("", '0', 0)), 1789 - ExpandableListView.getPackedPositionType(0L), 47 - TextUtils.indexOf((CharSequence) "", '0', 0, 0), objArr55);
                return ((String) objArr55[0]).intern();
            case 56:
                Object[] objArr56 = new Object[1];
                q((char) View.MeasureSpec.getSize(0), 1836 - TextUtils.indexOf((CharSequence) "", '0'), TextUtils.getOffsetAfter("", 0) + 16, objArr56);
                return ((String) objArr56[0]).intern();
            case 57:
                Object[] objArr57 = new Object[1];
                q((char) (AndroidCharacter.getMirror('0') - '0'), 1853 - View.MeasureSpec.makeMeasureSpec(0, 0), 16 - ExpandableListView.getPackedPositionType(0L), objArr57);
                return ((String) objArr57[0]).intern();
            case 58:
                Object[] objArr58 = new Object[1];
                q((char) (61534 - AndroidCharacter.getMirror('0')), 1869 - (ViewConfiguration.getTouchSlop() >> 8), (ViewConfiguration.getJumpTapTimeout() >> 16) + 29, objArr58);
                return ((String) objArr58[0]).intern();
            case 59:
                Object[] objArr59 = new Object[1];
                q((char) (59333 - TextUtils.indexOf((CharSequence) "", '0', 0, 0)), TextUtils.getTrimmedLength("") + 1898, (ViewConfiguration.getDoubleTapTimeout() >> 16) + 33, objArr59);
                return ((String) objArr59[0]).intern();
            case 60:
                Object[] objArr60 = new Object[1];
                q((char) (3079 - (Process.getElapsedCpuTime() > 0L ? 1 : (Process.getElapsedCpuTime() == 0L ? 0 : -1))), 1931 - (Process.myTid() >> 22), (ViewConfiguration.getKeyRepeatDelay() >> 16) + 23, objArr60);
                return ((String) objArr60[0]).intern();
            case 61:
                Object[] objArr61 = new Object[1];
                q((char) KeyEvent.getDeadChar(0, 0), 1954 - (ViewConfiguration.getMaximumDrawingCacheSize() >> 24), Drawable.resolveOpacity(0, 0) + 21, objArr61);
                return ((String) objArr61[0]).intern();
            case 62:
                Object[] objArr62 = new Object[1];
                q((char) (1 - (ViewConfiguration.getZoomControlsTimeout() > 0L ? 1 : (ViewConfiguration.getZoomControlsTimeout() == 0L ? 0 : -1))), 1975 - KeyEvent.keyCodeFromString(""), (ViewConfiguration.getFadingEdgeLength() >> 16) + 21, objArr62);
                return ((String) objArr62[0]).intern();
            case 63:
                Object[] objArr63 = new Object[1];
                q((char) Color.argb(0, 0, 0, 0), 1995 - TextUtils.indexOf((CharSequence) "", '0', 0), KeyEvent.keyCodeFromString("") + 27, objArr63);
                return ((String) objArr63[0]).intern();
            case 64:
                Object[] objArr64 = new Object[1];
                q((char) (ViewConfiguration.getWindowTouchSlop() >> 8), (TypedValue.complexToFloat(0) > SelfieScan.RECOGNITION_FAIL_RESULT ? 1 : (TypedValue.complexToFloat(0) == SelfieScan.RECOGNITION_FAIL_RESULT ? 0 : -1)) + 2023, 23 - TextUtils.indexOf((CharSequence) "", '0'), objArr64);
                return ((String) objArr64[0]).intern();
            case 65:
                Object[] objArr65 = new Object[1];
                q((char) (54514 - (ViewConfiguration.getPressedStateDuration() >> 16)), 2047 - (TypedValue.complexToFraction(0, SelfieScan.RECOGNITION_FAIL_RESULT, SelfieScan.RECOGNITION_FAIL_RESULT) > SelfieScan.RECOGNITION_FAIL_RESULT ? 1 : (TypedValue.complexToFraction(0, SelfieScan.RECOGNITION_FAIL_RESULT, SelfieScan.RECOGNITION_FAIL_RESULT) == SelfieScan.RECOGNITION_FAIL_RESULT ? 0 : -1)), (AudioTrack.getMinVolume() > SelfieScan.RECOGNITION_FAIL_RESULT ? 1 : (AudioTrack.getMinVolume() == SelfieScan.RECOGNITION_FAIL_RESULT ? 0 : -1)) + 26, objArr65);
                return ((String) objArr65[0]).intern();
            case 66:
                Object[] objArr66 = new Object[1];
                q((char) ((ViewConfiguration.getGlobalActionKeyTimeout() > 0L ? 1 : (ViewConfiguration.getGlobalActionKeyTimeout() == 0L ? 0 : -1)) + 33850), 2121 - AndroidCharacter.getMirror('0'), 22 - (AudioTrack.getMaxVolume() > SelfieScan.RECOGNITION_FAIL_RESULT ? 1 : (AudioTrack.getMaxVolume() == SelfieScan.RECOGNITION_FAIL_RESULT ? 0 : -1)), objArr66);
                return ((String) objArr66[0]).intern();
            case 67:
                Object[] objArr67 = new Object[1];
                q((char) (CdmaCellLocation.convertQuartSecToDecDegrees(0) > 0.0d ? 1 : (CdmaCellLocation.convertQuartSecToDecDegrees(0) == 0.0d ? 0 : -1)), (ViewConfiguration.getScrollBarSize() >> 8) + 2094, (ViewConfiguration.getWindowTouchSlop() >> 8) + 26, objArr67);
                return ((String) objArr67[0]).intern();
            case 68:
                Object[] objArr68 = new Object[1];
                q((char) (TextUtils.getOffsetBefore("", 0) + 21953), (ViewConfiguration.getKeyRepeatDelay() >> 16) + 2120, 33 - View.combineMeasuredStates(0, 0), objArr68);
                return ((String) objArr68[0]).intern();
            case 69:
                Object[] objArr69 = new Object[1];
                q((char) ((ViewConfiguration.getScrollBarFadeDuration() >> 16) + 32079), (ViewConfiguration.getScrollBarSize() >> 8) + 2153, 25 - (ViewConfiguration.getPressedStateDuration() >> 16), objArr69);
                return ((String) objArr69[0]).intern();
            case 70:
                Object[] objArr70 = new Object[1];
                q((char) (1 - (ViewConfiguration.getGlobalActionKeyTimeout() > 0L ? 1 : (ViewConfiguration.getGlobalActionKeyTimeout() == 0L ? 0 : -1))), 2178 - (CdmaCellLocation.convertQuartSecToDecDegrees(0) > 0.0d ? 1 : (CdmaCellLocation.convertQuartSecToDecDegrees(0) == 0.0d ? 0 : -1)), (ViewConfiguration.getScrollBarSize() >> 8) + 28, objArr70);
                return ((String) objArr70[0]).intern();
            case 71:
                Object[] objArr71 = new Object[1];
                q((char) ((-1) - TextUtils.lastIndexOf("", '0')), TextUtils.lastIndexOf("", '0', 0, 0) + 2207, (KeyEvent.getMaxKeyCode() >> 16) + 29, objArr71);
                return ((String) objArr71[0]).intern();
            case 72:
                Object[] objArr72 = new Object[1];
                q((char) (Process.myTid() >> 22), (PointF.length(SelfieScan.RECOGNITION_FAIL_RESULT, SelfieScan.RECOGNITION_FAIL_RESULT) > SelfieScan.RECOGNITION_FAIL_RESULT ? 1 : (PointF.length(SelfieScan.RECOGNITION_FAIL_RESULT, SelfieScan.RECOGNITION_FAIL_RESULT) == SelfieScan.RECOGNITION_FAIL_RESULT ? 0 : -1)) + 2235, (ViewConfiguration.getPressedStateDuration() >> 16) + 28, objArr72);
                return ((String) objArr72[0]).intern();
            case 73:
                Object[] objArr73 = new Object[1];
                q((char) ((-16759150) - Color.rgb(0, 0, 0)), 2263 - Color.green(0), (ExpandableListView.getPackedPositionForChild(0, 0) > 0L ? 1 : (ExpandableListView.getPackedPositionForChild(0, 0) == 0L ? 0 : -1)) + 17, objArr73);
                return ((String) objArr73[0]).intern();
            case 74:
                Object[] objArr74 = new Object[1];
                q((char) (1 - (ViewConfiguration.getGlobalActionKeyTimeout() > 0L ? 1 : (ViewConfiguration.getGlobalActionKeyTimeout() == 0L ? 0 : -1))), (CdmaCellLocation.convertQuartSecToDecDegrees(0) > 0.0d ? 1 : (CdmaCellLocation.convertQuartSecToDecDegrees(0) == 0.0d ? 0 : -1)) + 2279, 20 - (SystemClock.elapsedRealtimeNanos() > 0L ? 1 : (SystemClock.elapsedRealtimeNanos() == 0L ? 0 : -1)), objArr74);
                return ((String) objArr74[0]).intern();
            case 75:
                Object[] objArr75 = new Object[1];
                q((char) ((ViewConfiguration.getMaximumDrawingCacheSize() >> 24) + 46487), (ViewConfiguration.getWindowTouchSlop() >> 8) + 2298, 18 - Color.argb(0, 0, 0, 0), objArr75);
                return ((String) objArr75[0]).intern();
            case 76:
                Object[] objArr76 = new Object[1];
                q((char) (KeyEvent.getDeadChar(0, 0) + 50482), 2316 - View.getDefaultSize(0, 0), 32 - (ViewConfiguration.getGlobalActionKeyTimeout() > 0L ? 1 : (ViewConfiguration.getGlobalActionKeyTimeout() == 0L ? 0 : -1)), objArr76);
                return ((String) objArr76[0]).intern();
            case 77:
                Object[] objArr77 = new Object[1];
                q((char) (31325 - ((Process.getThreadPriority(0) + 20) >> 6)), (ExpandableListView.getPackedPositionForChild(0, 0) > 0L ? 1 : (ExpandableListView.getPackedPositionForChild(0, 0) == 0L ? 0 : -1)) + 2348, 39 - (SystemClock.uptimeMillis() > 0L ? 1 : (SystemClock.uptimeMillis() == 0L ? 0 : -1)), objArr77);
                return ((String) objArr77[0]).intern();
            case 78:
                Object[] objArr78 = new Object[1];
                q((char) ExpandableListView.getPackedPositionGroup(0L), (SystemClock.currentThreadTimeMillis() > (-1L) ? 1 : (SystemClock.currentThreadTimeMillis() == (-1L) ? 0 : -1)) + 2384, (KeyEvent.getMaxKeyCode() >> 16) + 39, objArr78);
                return ((String) objArr78[0]).intern();
            default:
                return String.valueOf(cVar);
        }
    }

    private static String e(Context context) throws Throwable {
        r = (l + 85) % 128;
        if (!(context instanceof FaceTecSessionActivity)) {
            return "";
        }
        StringBuilder sb = new StringBuilder();
        Object[] objArr = new Object[1];
        q((char) (TextUtils.lastIndexOf("", '0') + 61104), View.resolveSize(0, 0) + 2424, View.getDefaultSize(0, 0) + 39, objArr);
        sb.append(((String) objArr[0]).intern());
        sb.append(((bi) context).t());
        Object[] objArr2 = new Object[1];
        q((char) (View.resolveSizeAndState(0, 0, 0) + 32767), (ViewConfiguration.getMinimumFlingVelocity() >> 16) + 2463, (ViewConfiguration.getEdgeSlop() >> 16) + 18, objArr2);
        sb.append(((String) objArr2[0]).intern());
        int iD = am.AnonymousClass3.d();
        int iD2 = am.AnonymousClass3.d();
        int iD3 = am.AnonymousClass3.d();
        sb.append(((Integer) av.a(iD2, am.AnonymousClass3.d(), 225112006, iD3, -225112006, new Object[0], iD)).intValue() - 1);
        Object[] objArr3 = new Object[1];
        q((char) (50387 - TextUtils.getTrimmedLength("")), ImageFormat.getBitsPerPixel(0) + 2482, 2 - TextUtils.lastIndexOf("", '0', 0, 0), objArr3);
        sb.append(((String) objArr3[0]).intern());
        String string = sb.toString();
        l = (r + 45) % 128;
        return string;
    }

    public static /* synthetic */ Object e(int i2, Object[] objArr, int i3, int i4, int i5, int i6, int i7) throws Throwable {
        int i8 = ~i6;
        int i9 = ~(i8 | i7);
        int i10 = ~(i5 | i7);
        int i11 = ~i5;
        int i12 = ~i7;
        int i13 = i9 | i10 | (~(i11 | i12 | i6));
        int i14 = i9 | (~(i8 | i5)) | i10;
        int i15 = (~(i7 | i6)) | (~(i11 | i7)) | (~(i8 | i12 | i5));
        int i16 = i6 + i5 + i4 + (1880080305 * i2) + (458392769 * i3);
        int i17 = i16 * i16;
        int i18 = ((766573918 * i6) - Integer.MIN_VALUE) + (1582236324 * i5) + (i13 * (-407831203)) + (815662406 * i14) + ((-407831203) * i15) + (1174405120 * i4) + (1711276032 * i2) + ((-973078528) * i3) + (68288512 * i17);
        int i19 = ((i6 * 319678698) - 2002258816) + (i5 * 319678284) + (i13 * EnumC41897g.SDK_ASSET_ICON_COMMENT_VALUE) + (i14 * (-414)) + (i15 * EnumC41897g.SDK_ASSET_ICON_COMMENT_VALUE) + (i4 * 319678491) + (i2 * (-161570901)) + (i3 * (-1160779685)) + (i17 * (-1109000192));
        int i20 = i18 + (i19 * i19 * (-1432485888));
        if (i20 == 1) {
            return e(objArr);
        }
        if (i20 == 2) {
            return b(objArr);
        }
        if (i20 == 3) {
            return a(objArr);
        }
        if (i20 == 4) {
            return c(objArr);
        }
        if (i20 != 5) {
            String strB = bh.b(22, 22);
            StringBuilder sb = new StringBuilder();
            Object[] objArr2 = new Object[1];
            q((char) (Process.myPid() >> 22), KeyEvent.normalizeMetaState(0) + 501, (Process.myTid() >> 22) + 15, objArr2);
            sb.append(((String) objArr2[0]).intern());
            sb.append(strB);
            String string = sb.toString();
            r = (l + 105) % 128;
            return string;
        }
        Context context = (Context) objArr[0];
        c cVar = (c) objArr[1];
        cx.d dVar = (cx.d) objArr[2];
        r = (l + 113) % 128;
        if (!((Boolean) bk.d(-261957882, nf.a.e(), nf.a.e(), nf.a.e(), nf.a.e(), new Object[0], 261957889)).booleanValue()) {
            l = (r + 45) % 128;
            return null;
        }
        d(context, cVar, String.valueOf(dVar), null);
        return null;
    }

    private static String a(Activity activity) throws Throwable {
        String strIntern;
        String strIntern2;
        String strIntern3;
        r = (l + 17) % 128;
        if (activity == null) {
            return "";
        }
        Fragment fragmentD = bh.d(activity);
        if (fragmentD == null) {
            Object[] objArr = new Object[1];
            q((char) (ExpandableListView.getPackedPositionChild(0L) + 1), (ViewConfiguration.getDoubleTapTimeout() >> 16) + 2484, 3 - TextUtils.lastIndexOf("", '0', 0), objArr);
            strIntern = ((String) objArr[0]).intern();
        } else {
            strIntern = fragmentD.getTag();
            l = (r + 111) % 128;
        }
        StringBuilder sb = new StringBuilder();
        Object[] objArr2 = new Object[1];
        q((char) (46356 - (ExpandableListView.getPackedPositionForGroup(0) > 0L ? 1 : (ExpandableListView.getPackedPositionForGroup(0) == 0L ? 0 : -1))), 2488 - (TypedValue.complexToFraction(0, SelfieScan.RECOGNITION_FAIL_RESULT, SelfieScan.RECOGNITION_FAIL_RESULT) > SelfieScan.RECOGNITION_FAIL_RESULT ? 1 : (TypedValue.complexToFraction(0, SelfieScan.RECOGNITION_FAIL_RESULT, SelfieScan.RECOGNITION_FAIL_RESULT) == SelfieScan.RECOGNITION_FAIL_RESULT ? 0 : -1)), TextUtils.getOffsetAfter("", 0) + 39, objArr2);
        sb.append(((String) objArr2[0]).intern());
        if (activity.isFinishing()) {
            Object[] objArr3 = new Object[1];
            q((char) (Process.getGidForName("") + 18615), TextUtils.indexOf((CharSequence) "", '0', 0, 0) + 2528, 3 - TextUtils.lastIndexOf("", '0', 0), objArr3);
            strIntern2 = ((String) objArr3[0]).intern();
            r = (l + 73) % 128;
        } else {
            Object[] objArr4 = new Object[1];
            q((char) (TextUtils.lastIndexOf("", '0', 0) + 10818), ((byte) KeyEvent.getModifierMetaStateMask()) + ISO7816.INS_DELETE_FILE, 4 - MotionEvent.axisFromString(""), objArr4);
            strIntern2 = ((String) objArr4[0]).intern();
        }
        sb.append(strIntern2);
        Object[] objArr5 = new Object[1];
        q((char) (Gravity.getAbsoluteGravity(0, 0) + 37218), (Process.myTid() >> 22) + 2536, (CdmaCellLocation.convertQuartSecToDecDegrees(0) > 0.0d ? 1 : (CdmaCellLocation.convertQuartSecToDecDegrees(0) == 0.0d ? 0 : -1)) + 21, objArr5);
        sb.append(((String) objArr5[0]).intern());
        if (activity.hasWindowFocus()) {
            Object[] objArr6 = new Object[1];
            q((char) ((ViewConfiguration.getKeyRepeatDelay() >> 16) + 18614), (ViewConfiguration.getKeyRepeatDelay() >> 16) + 2527, (ViewConfiguration.getTapTimeout() >> 16) + 4, objArr6);
            strIntern3 = ((String) objArr6[0]).intern();
            l = (r + 119) % 128;
        } else {
            Object[] objArr7 = new Object[1];
            q((char) (10817 - (ViewConfiguration.getMinimumFlingVelocity() >> 16)), KeyEvent.normalizeMetaState(0) + 2531, 5 - (ViewConfiguration.getScrollBarSize() >> 8), objArr7);
            strIntern3 = ((String) objArr7[0]).intern();
        }
        sb.append(strIntern3);
        Object[] objArr8 = new Object[1];
        q((char) (48668 - (ViewConfiguration.getFadingEdgeLength() >> 16)), 2605 - AndroidCharacter.getMirror('0'), 13 - (ViewConfiguration.getJumpTapTimeout() >> 16), objArr8);
        sb.append(((String) objArr8[0]).intern());
        sb.append(strIntern);
        Object[] objArr9 = new Object[1];
        q((char) (50388 - (SystemClock.currentThreadTimeMillis() > (-1L) ? 1 : (SystemClock.currentThreadTimeMillis() == (-1L) ? 0 : -1))), 2481 - (ViewConfiguration.getWindowTouchSlop() >> 8), View.resolveSizeAndState(0, 0, 0) + 3, objArr9);
        sb.append(((String) objArr9[0]).intern());
        return sb.toString();
    }

    public static void d(Context context, Throwable th, c cVar, String str, boolean z, int i2) throws Throwable {
        c cVar2;
        String string;
        if (th != null) {
            n.a(th);
        }
        if (((Boolean) bk.d(-261957882, nf.a.e(), nf.a.e(), nf.a.e(), nf.a.e(), new Object[0], 261957889)).booleanValue()) {
            if (z) {
                int i3 = r + 117;
                l = i3 % 128;
                if (i3 % 2 != 0) {
                    cVar2 = c.UNEXPECTED_EARLY_EXIT_FACESCAN;
                    int i4 = 16 / 0;
                } else {
                    cVar2 = c.UNEXPECTED_EARLY_EXIT_FACESCAN;
                }
            } else {
                cVar2 = c.UNEXPECTED_EARLY_EXIT_IDSCAN;
            }
            if (cVar != cVar2) {
                d(context, cVar, str, th);
            }
            try {
                if (z) {
                    StringBuilder sb = new StringBuilder();
                    Object[] objArr = new Object[1];
                    q((char) (58142 - (PointF.length(SelfieScan.RECOGNITION_FAIL_RESULT, SelfieScan.RECOGNITION_FAIL_RESULT) > SelfieScan.RECOGNITION_FAIL_RESULT ? 1 : (PointF.length(SelfieScan.RECOGNITION_FAIL_RESULT, SelfieScan.RECOGNITION_FAIL_RESULT) == SelfieScan.RECOGNITION_FAIL_RESULT ? 0 : -1))), (ViewConfiguration.getDoubleTapTimeout() >> 16) + 359, TextUtils.getTrimmedLength("") + 21, objArr);
                    sb.append(((String) objArr[0]).intern());
                    sb.append(FaceTecSessionStatus.values()[i2].toString());
                    string = sb.toString();
                } else {
                    StringBuilder sb2 = new StringBuilder();
                    Object[] objArr2 = new Object[1];
                    q((char) ((ViewConfiguration.getScrollBarSize() >> 8) + 16832), View.MeasureSpec.getSize(0) + 380, Process.getGidForName("") + 21, objArr2);
                    sb2.append(((String) objArr2[0]).intern());
                    sb2.append(FaceTecIDScanStatus.values()[i2].toString());
                    string = sb2.toString();
                    r = (l + 35) % 128;
                }
            } catch (Exception unused) {
                if (j) {
                    string = "";
                } else {
                    throw new AssertionError();
                }
            }
            StringBuilder sb3 = new StringBuilder();
            sb3.append(str);
            Object[] objArr3 = new Object[1];
            q((char) ((ViewConfiguration.getMaximumDrawingCacheSize() >> 24) + 34743), (ViewConfiguration.getJumpTapTimeout() >> 16) + 400, 2 - ExpandableListView.getPackedPositionChild(0L), objArr3);
            sb3.append(((String) objArr3[0]).intern());
            sb3.append(ah.g());
            Object[] objArr4 = new Object[1];
            q((char) (34743 - Drawable.resolveOpacity(0, 0)), MotionEvent.axisFromString("") + HttpStatusCode.UNAUTHORIZED_401, KeyEvent.keyCodeFromString("") + 3, objArr4);
            sb3.append(((String) objArr4[0]).intern());
            sb3.append(string);
            d(context, cVar2, sb3.toString(), th);
        }
    }

    public static void a() {
        char[] cArr = new char[2676];
        ByteBuffer.wrap("â00\u000fFE\u0094\u009bªåù-\u000fg]°sÕ\u0081ÏÔ\u0016êJ8\u0083Nü\u009d#³LÁ³\u0017\u009d%Óx\u0012\u008eBâ?0\nFu\u0094\u009dª×ù \u000fE]¿sæ\u0081ÚÔ\u0013êL8\u0093NÜ\u009d#³mÁ£\u0017\u0082%Ò\u008fb]]+\u0017ùÉÇ·\u0094\u007fb50â\u001e\u0087ì\u009d¹X\u0087\u0000UÆ#½ðwÞ'ø\u0089*¼\\Ã\u008e+°aã\u0096\u0015óG\tiL\u009btÎ²ðé\"#TSè,:\u001fL[\u009e\u0095 Åó5\u0005vW´yÜ\u008bÉÞ\bàEâ%0\u0001FS\u0094\u0090ªÒù\u000f\u000fh]ºs×\u0081ÍÔ\u0012êW8\u0099Nà×\u0011\u0005?sp¡¨\u009f÷Ì\u0004:Vh·FÝ´îá'â20\u000bFD\u0094\u008bªÑ¢£p \u0006íÔ0êy¹\u0099OÈâ\u001f0\u0000FP\u0094\u009fªÚù'\u000fb]\u0093sä\u0081ÔÔ-ê[8\u008fâ\u00040\u000bFU\u0094\u008eªÙù \u000fu]»sÓ\u0081ÜÔ\u0014êQ8\u0084â\u00150\u0001FH\u0094\u0090ªÓù-\u000fr]·sù\u0081ÀÔ#êL8\u0084Ná\u009d4â\u00030\u0000FM\u0094\u0090ªÙù9\u000fh]\u008csó\u0081ÚÔ\u0014êGâ\u001f0\u0000FE\u0094\u0091ªÛù>\u000fg]ªsÿ\u0081ÌÔ\nê[8²Ná\u009d%â\u00130\u001cFT\u0094\u0091ªÄùn\u000fa]»sâ\u0081ÚÔ\u000fêP8\u0091N®\u009d\u0005³\u007fÁ»\u0017\u008b%Ôx\u001f\u008e\u0004Üîòõ\u0001+Wfe^»\u0089ÉÌ\u001c\u00022.@µ\u0096ê¥7û\u001a\tS_\u008dm\u008c\u0080nÚa\bL~\u0007¬Á\u0092\u0080>pì]\u009a/Húv¥%mÓ'\u0081ð¯¦]\u0080\bAâ$0\u001aâ?0\râ?0\u0003FG\u0094\u0099ªÓù\u001a\u000f\u007f]®sóÈÓ\u001aìl¹¾f\u0080;ÓÎ%\u0086wSY\u000e«+þåÀ¼\u0012Sd\u0006â20\u0007FG\u0094\u0099ªØù!\u000fu]ªsÿ\u0081ÍÔ/êZâ!â>Yà\u008bÑ¬ä~Í\b\u0096Ú]ä\u0019·éA°\u0013y=&Ï\u001f\u00ad:\u007f\\\t\nÛÛ2úàÆ\u0096\u0082D\\z\u0016)¤ß³\u008du£4àB2fD.\u0096ò¨¹û\b\rU_\u008dq\u008b\u0083¢Ösèl:ðL\u009d\u009fU±\u000fÃË\u0015ç'®zj\u008cdÞÑð\u0095\u0003OUEg3¹êË«\u001e%0\u0004B\u008b\u0094Ì§\u001bù=\u000b ]ío¥\u0082_ÔUæÏ8\u009fJ¾\u009dn¯+ÁÚ\u0013\u0093&Hx\u0016\u008a\u0087Üâî´\u0001e\u0001\u000eÓ\u0011¥[w\u0085Iü\u001a5ì{¾\u0093\u0090íbÃ7\u000b\tIÛ\u0087\u00adþ~\u000bPt\"©ô\u0084ÆÍ\u009b\u0013m\b£ÐqÏ\u0007\u0085Õ[ë\"¸ëN¥\u001cW2\u0012À=\u0095Å«\u009fyX\u000f\u001dÜòò¿\u0080bV[d\u00159\u009eeÁ·¥Á±â\"<Kîe\u0098%Jàt\u0088'MÑ\u0001\u0083Ñ\u00ad°_\u00ad\na4=æè~\n¬$Úd\b¡6Ée\f\u0093@Á\u0090ïé\u001dêH9vt¤±â\u00170\rFR\u0094\u0097ªÀù'\u000fr]§s¶\u0081ýÔ\u0012ê_8\u0082Në\u009df³WÁ¸\u0017\u0088%Éâ\u00170\nFB\u0094\u0097ªÂù'\u000fi]°s÷\u0081ÂÔFêw8\u0098Nè\u009d)â\u00050\u001aFG\u0094\u009dªÝùn\u000fR]¬s÷\u0081ÍÔ\u0003â\u00050\u000bFU\u0094\u008dªßù!\u000fh]þsß\u0081ÀÔ\u0000êQâ&0\u000fF_\u0094\u0092ªÙù/\u000fb]\u0088só\u0081ÜÔ\u0015êW8\u0099Nàâ\"0\u000bFK\u0094\u008eªéù#\u000fo]°sä\u0081\u0097Ô\u000eê\n8ÏN½\u009d0\u0012»À¡¶ëd8Z}\t\u0084ÿ\u0088\u00ad\u0016\u0083Qql$\u00ad\u001a°È+¾Em\u008bCÂ1\u001dç4Õ(\u0088¶~÷,\u0012\u0002\b\u001cÿÎÅ¸\u0081jQT\u000e\u0007åñ\u009c£q\u008d.\u007f\t*Å\u0014\u0087ÆO°-cãMº\u0017»Å\u0084³Ëa\u000e_[\f«úî¨\u001c\u0086stI!\u0087\u001féÍ\u0011»kh¬FÝ47â\u001eÐp\u008d\u009f{Ó).\u0007{â00\u000fFE\u0094\u009bªåù-\u000fg]°sÌ\u0081ÁÔ\têS8\u0093Nêâ00\u000fFE\u0094\u009bªåù-\u000fg]°sÃ\u0081ÀÔ\u001cêQ8\u0099Nã\u009d#³zâ$0\u000bFR\u0094\u008cªÏù\u001d\u000fo]ºsó\u0081ìÔ\u001fêm8\u009fNê\u009d#â$0\u000bFR\u0094\u008cªÏù\t\u000fc]ªsÄ\u0081ËÔ\u0007êZ8\u008frÑ þÖ \u0004~:/iÏ\u009f¦Í[ã\u000f\u00114Dòz¯Äe\u0016P`/²Ç\u008c\u008dßz)\u000f{ðU\u00ad§\u0086òHâ80\bFE\u0094\u00adªÂù/\u000ft]ªâ$0\u000bFU\u0094\u008bªÚù:\u000fI]\u009dsÄ\u001aâÈÌ¾\u0082lLR\u0003\u0001à÷¯¥~\u008b\u0012y\b,Ì\u0012\u009cÀC¶(â$0\u000bFU\u0094\u008bªÚù:\u000fO]ºsÐ\u0081ËÔ\u0003êZ8\u0094Nï\u009d%³u°Øb÷\u0014©Æwø&«Æ]»\u000fF!\u000eÓ;\u0086î¸«je\u001c\u001cÏÛá\u008e\u0093xEww,*ëÜ¯\u008eEâ00\u001bFJ\u0094\u0092ªåù+\u000fu]\u00adsÿ\u0081ÁÔ\bêm8\u0082Nï\u009d4³j\u008c\u001f^%(|ú\u0082Äý\u0097\u0001aL3\u0089\u001dñïíº\u001a\u0084uV¹ Äó\u0011Ýc¯\u0090y¯Kÿ\u0016>àY²\u008e\u009cÌo\"9]\u000baÕ¬§éâ10\u000bFR\u0094¬ªÓù/\u000fb]§sß\u0081ÃÔ4ê[8\u0097Nê\u009d?³NÁ¤\u0017\u008b%Õx\r\u008eSÜª\u0091ÞCá5«çuÙ\u000b\u008aÃ|\u0089.^\u0000;ò!§ä\u0099¼Kz=\u0001îËÀ\u009b²{daV$\u000büý½¯D\u0007ûÕÁ£\u0098qfO\u0019\u001cåê¨¸m\u0096\u0015d\t1þ\u000f\u0091Ý]« xõV\u0087$tòKÀ\u001b\u009dÚk½9j\u0017(äÆ²¹\u0080\u0085^H,\rùî×¡¥xs&@å ^òd\u0084=VÃh¼;@Í\r\u009fÈ±°C¬\u0016[(4úø\u008c\u0085_Pq!\u0003ËÕäçººbL<\u001eÅ0»ÃT\u0095\r§3yðñ^#gU<\u0087÷¹¶êM\u001c\u001aN×`\u0088\u0092\u0097Çyù7+þ]¤\u008eK \u0011Òß\u0004Ñ6©ks\u009d4Ïáá\u008b\u0012^D\u0016v ¨ëÚ±\u000fqO¡\u009d\u0092ëÖ9\u0018\u0007HT¸¢ûð9ÞQ,Dy\u0085GÈ\u00955ão0°\u001eþl6º\u0018\u0088Qâ?0\nFu\u0094\u009dª×ù \u000fE]¿sú\u0081ÂÔ\u0004ê_8\u0095Nå\u009d\u0005³\u007fÁº\u0017\u0082%Ãx\u001aâ20\u000bFP\u0094\u009bªÚù!\u000fv]»sä\u0081ûÔ\u0015ê[8\u0092NÇ\u009d\u0002³MÁµ\u0017\u008f%Èx=\u008eWÜ¢òê\u0001<WweM»\u008dâ50\u000fFK\u0094\u009bªÄù/\u000f4]\u009bsä\u0081ÜÔ\têLâ80\u0001FH\u0094¸ª×ù:\u000fg]²sÓ\u0081ÜÔ\u0014êQ8\u0084â%0\u000bFP\u0094\u009bªÄù+\u000fC]¬sä\u0081ÁÔ\u0014â 0\u0001FE\u0094\u009fªÚù\t\u000fs]·sò\u0081ÏÔ\bê]8\u0093NÝ\u009d2³\u007fÁ¤\u0017\u009a%Ãx\u001a^\u007f\u008cEú\u0001(Ñ\u0016\u008eEe³\u0000áñÏ»=\u0085hOV\r\u0084ùò¶!~\u000f;}î©\n{0\rtß¤áû²\u0010D|\u0016\u00938ÛÊþ\u009f+Ø9\n\t|D®º\u0090ÅÃ=5hg\u00ad7Dåt\u00939A×\u007f¹,WÚ\b\u0088ï¦\u0085T¤\u0001\u007f?&íÎ\u009b\u0097HLf\u000b\u0014ÉÂ÷ï~=GK\f\u0099Û§\u0094ôk\u0002>P÷~¶\u008c\u009bÙhç\u00075ÝC\u008b\u0090l¾\u0001Ìÿ\u001aÇ(\u0084â%0\u001aFG\u0094\u008cªÂù\u001e\u000ft]»sà\u0081ÇÔ\u0003êI8³Nö\u009d%³{Á¦\u0017\u009a%Ïx\u0011\u008eX\u0000ÄÒç¤¤vaH!\u001bÌí\u0082¿M\u0091\u0014c-6Ï\b¬Ú}¬\u0005â30\u0016FO\u0094\u008aªåù-\u000ft]»só\u0081ÀÔ2êG8\u0086Nëâ30\u0016FO\u0094\u008aªåù-\u000ft]»só\u0081ÀÔ#êR8\u0097Nþ\u009d5³{Á²\u0017º%Ïx\u0013\u008eSâ%0\u000bFU\u0094\u008dªßù!\u000fh]\u008csó\u0081ÝÔ\u0013êR8\u0082NÛ\u009d(³{Á®\u0017\u009e%Ãx\u001d\u008eBÜ«òâ\u0001\u0010WceB»\u008aâc0CF\f\u0094Þª\u009dùb\u000f;]Ós²\u0081\u0085ÔGê\u00178ÖN¹\u009dV³5Áö\u0017Ó%\u0093x^\u008e\u0010Üÿò¦\u0001\u007fW\u001de\u001e»ÏÉ\u0097â70\u0006FT\u0094\u009aâ20\u001eFCâ50\fFT\u0094\u0097ªÓâ:0\u0003FCæk4RB\u0000â50\u000fFEç,5@C\\\u0091§¯Øü \nuX°â?0\u0003FA\u0094ºª×ù:\u000fg]\u008bsø\u0081ËÔ\u001eêN8\u0093Ní\u009d2³{Á²\u0017 %Óx\u0012\u008eZâ20\u0019FRÜ\u001e\u000e'xk\u009f\u0012M7;hâ\u00030\u0000FC\u0094\u0086ªÆù+\u000fe]ªsó\u0081ÊÔ#ê_8\u0084Nâ\u009d?³[Á®\u0017\u0087%Òx8\u008eWÜ\u00adòã\u0001\rWueO»\u0088Éÿ\u001c\u00182j@´\u0096ñ¥?û\nJá\u0098âî¡<d\u0002$QÉ§\u0087õHÛ\u0011)(|ÁB½\u0090fæ\u00005Ý\u001b¹iL¿e\u008d0ÐÕ&\u0090t\u007fZ\u0007©Ýÿ\u009aÍ\u008d\u0013ja8´æ\u009a\u0083èM>\u0018â50\u000fFK\u0094\u009bªÄù/\u000fE]¿sæ\u0081ÚÔ\u0013êL8\u0093NÈ\u009d'³wÁº\u0017\u008b%Âx:\u008eSÜ¨òç\u0001+WzeZ\u0011\u0015Ã/µkg»Yä\n\u000füe®\u0091\u0080Ørè'/\u0019yË£½Ün\u0003@x2\u0097ä§Öê\u008b;}r/ª\u0001Ãò\u0018¤W\u0096{Hª:ê\u0019KËq½5oåQº\u0002Qô;¦Á\u0088\u0098z¤/m\u00112Ãíµ¶fYH\t:ÄìõÞ¼\u0083Au<'Ä\t\u009dúM¬\u0018\u009e$@Þ2¡çdÉ\u001c»Úm\u0081^K\u0000{â?0\u0000FO\u0094\u008aªåù:\u000fg]¬sâ\u0081ïÔ\bêZ8\u0084Ná\u009d/³zkÇ¹øÏ·\u001dr#\u001dpÝ\u0086\u0097ÔVú\u001e\b3]úc\u0087±~Ç\u0006\u0014è:\u0087HB\u009e\u007f¬:ñç\u0007ºUS{\u001a\u0088çÞ\u0080ì²2l@)\u0095ç»\u0092#\u009cñ£\u0087ìU)kS8\u008cÎÌ\u009c\u0011²e@x\u0015§+ñù<\u008fN\\®rØ\u0000\fÖ\fäk¹¹Oç\u001d\u00023LÀ\u0099÷9%\u0006SI\u0081\u008c¿öì)\u001aiH´fÔ\u0094ÍÁ\u0016ÿQ-\u0093[í\u0088\u000e¦wÔ¤\u0002»0Õm\b\u009b@É§çò\u0014,BupL®¡ÜÖ\t\u0014'zU¯\u0083ñ°4©\u0011{.\raß¤áÞ²\u0001DA\u0016\u009c8îÊå\u009f:¡cs±\u0005ÏÖ\u0006øt\u008a\u009d\\°nú35Å{\u0097\u0081¹ÜJ\u0015\u001c\\.Að¦\u0082ôW*yO\u000b\u0081ÝÔâ?0\u0000FO\u0094\u008aªðù/\u000fo]²sÒ\u0081ËÔ\u0010êW8\u0095Në\u009d\r³{Á¯\u0017¼%Ãx\u0014\u008eSÜ\u00adòò\u0001;Wreo»\u0088ÉÚ\u001c\u00042a@¯\u0096úâ?0\u0000FO\u0094\u008aªðù/\u000fo]²sØ\u0081ËÔ\u0012êI8\u0099Nü\u009d-³[Á¤\u0017\u009c%Éx\f\u008ewÜ òâ\u0001,WyeG»\u0082â?0\u0000FO\u0094\u008aªðù'\u000fh]·så\u0081ÆÔ'êP8\u0092Nü\u009d)³wÁ²â?0\nF`\u0094\u009bªÓù*\u000fd]¿sõ\u0081ÅÔ5êV8\u0099Nù\u009d(õ\u0088'µQý\u0083(½}î\u0098\u0018ÖJ\u000fdH\u0096}Ã\u008býä/?YX\u008a\u009c¤ÖÖ+\u0000$2moµ\u0099æË\u001fåi\u0016\u0093@Ìrâ¬*â\u00100\u000fFE\u0094\u009bªâù+\u000fe]\u008dsó\u0081ÝÔ\u0015êW8\u0099Nà\u009d\u0007³}Á¢\u0017\u0087%Ðx\u0017\u008eBÜ·òÉ\u00010WDeK»\u0095ÉË\u001c\u001b2kâ\u00100\u000fFE\u0094\u009bªâù+\u000fe]\u008dsó\u0081ÝÔ\u0015êW8\u0099Nà\u009d\u0007³}Á¢\u0017\u0087%Ðx\u0017\u008eBÜ·òÉ\u00010WFeO»\u0093ÉÍ\u001c\u0013â\u00100\u000fFE\u0094\u009bªâù+\u000fe]\u008dsó\u0081ÝÔ\u0015êW8\u0099Nà\u009d\u0007³}Á¢\u0017\u0087%Ðx\u0017\u008eBÜ·òÑ\u00017WxeJ»\u0089ÉÉ\u001c02a@¥\u0096ë¥%û-\tN_\u009fmØ\u0080)Öcb\u0090°\u008fÆÅ\u0014\u001b*by«\u008fåÝ\róR\u0001eT§jÝ¸\u0002Îg\u001d°3÷A\"\u0097\u0017¥eø\u0091\u000eØ\\:rc\u0081¦×âåý;\u0011IW\u009c\u0082²íÀ.\u0016J%¤{\u0087\u0089Áß\u0019íS\u0000¼VÇd8ºbÈK\u001f\u0094-úC\u0013\u0091b¤§úçâ90\u001eFC\u0094\u0090ªðù<\u000fi]°sâ\u0081íÔ\u0007êS8\u0093Nü\u009d'³,â90\u001eFC\u0094\u0090ªðù<\u000fi]°sâ\u0081íÔ\u0007êS8\u0093Nü\u009d'³/\u0012\u001bÀ!¶dd³Zí\t\fÿI\u00ad\u0084\u0083ÝqÆ$:\u001a\u007fÈ¶¾Ôm+CQ1\u0095ç¥Õú\u00881~K,\u0089\u0002Òñ\u0015§k\u0095tK©9âì,\u0005ó×É¡\u008cs[M\u0005\u001eäè¡ºl\u00945f.3Ò\r\u0097ß^©<zÃT¹&}ðMÂ\u0012\u009fÙi£;a\u0015:æý°\u0095\u0082\u0090\\C.\u001dûÀÕ¼§iq7Bþî#<\rJL\u0098\u009d¦Óõ<\u0003eQ¼\u007fÖ\u008dÚØ\u000fæV4\u0084BË\u0091!¿uÍµ\u001b\u009a)Át+\u0082YÐ²þåâ50\u000fFK\u0094\u009bªÄù/\u000fV]»sä\u0081ÃÔ\u000fêM8\u0085Nç\u009d)³pÁ\u0085\u0017\u0086%Éx\t\u008eXâ\u00060\u001cFC\u0094\u00adªÓù=\u000fu]·sù\u0081ÀÔ6êV8\u0097Ný\u009d#³,Á\u0085\u0017\u009a%Çx\f\u008eBâ\u00060\u001cFC\u0094\u00adªÓù=\u000fu]·sù\u0081ÀÔ5êJ8\u0097Nü\u009d2³[Á¤\u0017\u009c%Éx\f\u008ewÜ òâ\u0001,WyeG»\u0082â\u00040\u000bFU\u0094\u008bªÚù:\u000fU]½sä\u0081ËÔ\u0003êP8¥Næ\u009d)³iÁ¸\u0017¯%Èx\u001a\u008eDÜ¡òï\u0001:6çäý\u0092¹@i~6-ÝÛ±\u0089Z§\rU?\u0000à>©ì`\u009a?IÛg\u0082\u0015PÃyñ,¬øZ\u0097\bK&\u001dÕØ\u0083\u0087±´f+´4Â~\u0010 .Þ}\u0016\u008b\\Ù\u008b÷î\u0005ôP0n`¼¿ÊÔ\u0019>7WE\u0088\u0093´¡éü \niâ\u00050\u000bFU\u0094\u008dªßù!\u000fh]\u009ds÷\u0081ÃÔ\u0003êL8\u0097NÍ\u009d*³{Á·\u0017\u0080%Óx\u000e\u008euÜ¯òê\u00012WseJ·ÙeÎ\u0013\u0093ÁVÿ\u0001¬êZ\u0086\bj&3Ô\u0006\u0081Ó¿«mE\u001b.Èîæ³\u0094ZBJp\u0013-×Û\u0098\u0089k§\u0015Tú\u0002£0\u009aîU\u009c\u0011IÄg\u0081\u0015rÃ3ðû\u009fJMB;\béß×«\u0084dr: ä\u000eµü\u0095©k\u0097\u001dEÖ3£àMÎ4¼újÎX\u008d\u0005Tó<¡ó\u008f»|~*+â\u00030\u0000FC\u0094\u0086ªÆù+\u000fe]ªsó\u0081ÊÔ'ê]8\u0082Nç\u009d0³wÁ¢\u0017\u0097%ñx\u0017\u008eXÜªòé\u0001)WEeG»\u009cÉÛâ\u00170\u001dF_\u0094\u0090ªÕù\b\u000fg]½só\u0081ýÔ\u0005ê_8\u0098NÝ\u009d3³}Áµ\u0017\u008b%Õx\r\u008ebÜ¯òõ\u00015WSe\\»\u0094ÉÑ\u001c\u0004â\u001a0\u0001FA\u0094\u00adªÃù-\u000fe]»så\u0081ÝÔ\u0000êK8\u009aNË\u009d(³lÁ¹\u0017\u0082%Êx\u0013\u008eSÜ òò\u0001\u001bWde\\»\u0089ÉÌ¤\u0092v»\u0000äÒ\u0000ìE¿¥IÇ\u001b#5qÇR\u0092\u0090¬é~\u0016\bnÛ»õþâ\u00000)Fr\u0094\u009bªÎù:\u000fR]±sÅ\u0081ÞÔ\u0003ê[8\u0095Næ\u009d\u0003³lÁ¤\u0017\u0081%ÔW\u0091\u0085\u0096óÆ!\f\u001fSL\u009bºäè=Æu4Va\u009f_ù\u008d\u0013û|(¢\u0006út$¢\u001d'%õ2\u0083pQ¾oë<\u0015ÊP\u0098¹¶ÊDù\u0011,/|ý¡\u008bßX\u0000vI\u0004\u0080Ò\u0094àû½#Ko\u0019¿7ÜÄ\t\u0092G w~\u0091\fþÙ6÷S\u0085\u0086\u0098BJw<(îÀÐ\u008a\u0083}u\u0019'â\t¨û\u0098®x\u0090\u0002BÆ4¶çiÉ\"»ßmÒ_\u0090\u0002Fô;¦û\u0088´{w-$\u001f2Áë³ªfyH6:èì¬ßg\u0081Fs\u000f%Ê\u0017\u0084ú}â\u001f0*Fu\u0094\u009dª×ù \u000fD]¿sõ\u0081ÅÔ%ê_8\u009bNë\u009d4³\u007fÁ\u0082\u0017\u008f%Íx\u001b\u008efÜ¦òé\u0001*Wyeo»¶É÷\u001c32b@§\u0096î¥%û\u000b\tB_ªmß\u0080#Öc\f\u0082Þá¨©z\u0002D|\u0017\u0092áÚ³\u0018\u009dVoo:é\u0004ØÖ7 Gs\u0086]\u0091/TùlË)\u0096\u0099`ø2\u0012\u001cjï\u009e¹×\u008bõU,'iò\u00adÜò®\u001exXK\u008d\u0015¢çá±4\u0083}nÛ8\u0089\u009d\u0089Oí9ùëGÕ(\u0086Òp\u009c\"r\f\nþ0«÷\u0095\u0082Gf1\u0004â×Ì\u0095¾\u0013h1&¥ô\u009d\u0082\u0088â80\u001bFJ\u0094\u0092W9\u0085Zó\u0012!«\u001fÁL.º{è¼Æë4Îa\u000b_\n\u008d±ûî(3\u0006~t§¢Ú\u0090ûÍ\u0004;DiµG²´gâ/Ð\u001a\u000e\u009b|Ù©$\u0087sõ¼#ã\u00101N\u0012¼[ê\u0084ØÅ5`c2ª\u0094xª\u000eåÜ-Èq\u001aNl\u000b¾Ì\u0080\u0092s\u0014¡,×8\u0005¼;ôhD\u009e\u0005ÌÏâ£\u0010¥Ej{8©ûß\u009b\fb\"\u0013P×\u0086ù´·é&\u001ft\\j\u008e\u000eø\u001a*\u0084\u0014ØG3±}ã¯Íï?Üj\u000eT\u0018\u0086Êâ 0\\â&0\u000bFT\u0094²ªÙù/\u000fb]\u0097sÒâ30\u0018FC\u0094\u0090ªÂù\u0007\u000fBâ&0\u000bFT\u0094¸ª×ù-\u000fc]\u008asó\u0081ÍÔ5ê[8\u0085Ný\u009d/³qÁ¸\u0017§%ââ3â\"0\u0007FK\u0094\u009bªÅù:\u000fg]³sæâ30\u0018FC\u0094\u0090ªÂù\n\u000fg]ªsóâ20\u000fFR\u0094\u009fVZ\u0084~ò6 ê\u001e¡M\u0010»Mé\u0095Ç\u00935º`k^t\u008cèú\u0085)M\u0007\u0017uÓ£ÿ\u0091¶Ìr:|hÉF\u008dµWã]Ñ+\u000fò}³¨=\u0086\u001cô\u0093\"Ô\u0011\u0003O%½8ëõÙ½4GbMPÉ\u008e\u0097ü¹+q\u00193wý¥\u0084".getBytes(LocalizedMessage.DEFAULT_ENCODING)).asCharBuffer().get(cArr, 0, 2676);
        k = cArr;
        n = 6573702760078258286L;
    }

    public static void d(Context context, String str, int i2) throws Throwable {
        r = (l + 51) % 128;
        if (!((Boolean) bk.d(-261957882, nf.a.e(), nf.a.e(), nf.a.e(), nf.a.e(), new Object[0], 261957889)).booleanValue()) {
            int i3 = r + 91;
            l = i3 % 128;
            if (i3 % 2 != 0) {
                throw null;
            }
            return;
        }
        ey eyVar = new ey();
        Object[] objArr = new Object[1];
        q((char) (((byte) KeyEvent.getModifierMetaStateMask()) + 1), 403 - TextUtils.getCapsMode("", 0, 0), 1 - (ViewConfiguration.getScrollBarSize() >> 8), objArr);
        eyVar.c(((String) objArr[0]).intern(), str);
        Object[] objArr2 = new Object[1];
        q((char) (((Process.getThreadPriority(0) + 20) >> 6) + 56938), 404 - (ViewConfiguration.getJumpTapTimeout() >> 16), KeyEvent.keyCodeFromString("") + 13, objArr2);
        eyVar.b(((String) objArr2[0]).intern(), Integer.valueOf(EnumC41897g.SDK_ASSET_TRANSFER_ICON_CIRCLE_VALUE));
        Object[] objArr3 = new Object[1];
        q((char) (TextUtils.indexOf((CharSequence) "", '0', 0) + 39980), (ViewConfiguration.getScrollBarSize() >> 8) + 417, 13 - (ViewConfiguration.getFadingEdgeLength() >> 16), objArr3);
        eyVar.b(((String) objArr3[0]).intern(), Integer.valueOf(i2));
        c(context, c.DIAGNOSTIC_WAIT_TIME, eyVar);
    }

    public static void d(Context context, c cVar, String str, Throwable th) {
        Activity activity;
        Object obj;
        if (context != null) {
            if (((Boolean) bk.d(-261957882, nf.a.e(), nf.a.e(), nf.a.e(), nf.a.e(), new Object[0], 261957889)).booleanValue()) {
                ey eyVar = new ey();
                if (context instanceof Activity) {
                    int i2 = l + 21;
                    r = i2 % 128;
                    if (i2 % 2 == 0) {
                        activity = (Activity) context;
                        Object[] objArr = new Object[1];
                        q((char) (KeyEvent.getMaxKeyCode() + 1), 18009 >>> (SystemClock.uptimeMillis() > 1L ? 1 : (SystemClock.uptimeMillis() == 1L ? 0 : -1)), 108 << TextUtils.lastIndexOf("", (char) 15), objArr);
                        obj = objArr[0];
                    } else {
                        activity = (Activity) context;
                        Object[] objArr2 = new Object[1];
                        q((char) (KeyEvent.getMaxKeyCode() >> 16), 431 - (SystemClock.uptimeMillis() > 0L ? 1 : (SystemClock.uptimeMillis() == 0L ? 0 : -1)), TextUtils.lastIndexOf("", '0') + 20, objArr2);
                        obj = objArr2[0];
                    }
                    eyVar.c(((String) obj).intern(), a(activity));
                }
                if (str != null) {
                    Object[] objArr3 = new Object[1];
                    q((char) Color.green(0), 449 - Color.blue(0), 16 - (ViewConfiguration.getScrollFriction() > SelfieScan.RECOGNITION_FAIL_RESULT ? 1 : (ViewConfiguration.getScrollFriction() == SelfieScan.RECOGNITION_FAIL_RESULT ? 0 : -1)), objArr3);
                    eyVar.c(((String) objArr3[0]).intern(), str);
                }
                if (th != null) {
                    r = (l + 71) % 128;
                    String strA = s.a(th);
                    Object[] objArr4 = new Object[1];
                    q((char) TextUtils.getOffsetAfter("", 0), 464 - TextUtils.indexOf("", ""), 11 - (ViewConfiguration.getPressedStateDuration() >> 16), objArr4);
                    eyVar.c(((String) objArr4[0]).intern(), strA);
                }
                if (cVar == c.UNEXPECTED_EARLY_EXIT_FACESCAN || cVar == c.UNEXPECTED_EARLY_EXIT_IDSCAN) {
                    Object[] objArr5 = new Object[1];
                    q((char) (ViewConfiguration.getScrollBarFadeDuration() >> 16), (ViewConfiguration.getWindowTouchSlop() >> 8) + 475, 12 - ((Process.getThreadPriority(0) + 20) >> 6), objArr5);
                    eyVar.c(((String) objArr5[0]).intern(), e(context));
                }
                c(context, cVar, eyVar);
            }
        }
    }

    private static byte[] d(Context context, String str) throws Throwable {
        byte[] bArrD = h.d(context);
        StringBuilder sb = new StringBuilder();
        Object[] objArr = new Object[1];
        q((char) (61614 - View.MeasureSpec.getMode(0)), 515 - TextUtils.lastIndexOf("", '0'), 23 - (TypedValue.complexToFraction(0, SelfieScan.RECOGNITION_FAIL_RESULT, SelfieScan.RECOGNITION_FAIL_RESULT) > SelfieScan.RECOGNITION_FAIL_RESULT ? 1 : (TypedValue.complexToFraction(0, SelfieScan.RECOGNITION_FAIL_RESULT, SelfieScan.RECOGNITION_FAIL_RESULT) == SelfieScan.RECOGNITION_FAIL_RESULT ? 0 : -1)), objArr);
        sb.append(((String) objArr[0]).intern());
        sb.append(str);
        byte[] bArrB = bp.b(bArrD, sb.toString());
        int i2 = l + 53;
        r = i2 % 128;
        if (i2 % 2 != 0) {
            return bArrB;
        }
        throw null;
    }

    public static /* synthetic */ void d(Context context, q qVar) throws Throwable {
        int iE = ov.b.AnonymousClass1.e();
        int iE2 = ov.b.AnonymousClass1.e();
        e(ov.b.AnonymousClass1.e(), new Object[]{context, qVar}, ov.b.AnonymousClass1.e(), iE2, -1562709845, 1562709849, iE);
    }

    public static void d() {
        o = new char[]{57916, 46707, 19112, 7931, 45928, 18286, 7087, 45028, 16401, 5148, 43181, 31939, 4373, 42326, 31115, 3527, 57909, 46695, 19116, 7912, 45859, 18284, 7098, 45022, 16415, 5215, 43163, 31991, 4367, 42318, 31106, 3523, 42597};
        m = 2166913959742846482L;
    }

    public static void c(Context context, c cVar, cx.d dVar) throws Throwable {
        int iE = ov.b.AnonymousClass1.e();
        int iE2 = ov.b.AnonymousClass1.e();
        e(ov.b.AnonymousClass1.e(), new Object[]{context, cVar, dVar}, ov.b.AnonymousClass1.e(), iE2, 1706766979, -1706766974, iE);
    }
}