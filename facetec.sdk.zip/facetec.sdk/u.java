package com.facetec.sdk;

/* JADX INFO: loaded from: classes4.dex */
enum u {
    INTRA_SESSION,
    INTRA_FACETEC_SESSION,
    INTER_FACETEC_SESSION
}