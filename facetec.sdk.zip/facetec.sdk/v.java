package com.facetec.sdk;

import android.graphics.Color;
import android.media.AudioTrack;
import android.os.SystemClock;
import android.text.TextUtils;
import android.util.TypedValue;
import android.view.View;
import android.view.ViewConfiguration;
import android.widget.ExpandableListView;
import com.incode.welcome_sdk.modules.SelfieScan;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import net.sf.scuba.smartcards.ISO7816;
import org.bouncycastle.i18n.LocalizedMessage;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

/* JADX INFO: loaded from: classes4.dex */
final class v {
    public static int h;
    public static int j;
    y a;
    y d;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    y f95951g;
    List<List<Integer>> b = new ArrayList();
    int e = 0;
    int c = 0;

    /* JADX INFO: renamed from: com.facetec.sdk.v$4, reason: invalid class name */
    public static /* synthetic */ class AnonymousClass4 {
        static final /* synthetic */ int[] c;

        static {
            int[] iArr = new int[d.values().length];
            c = iArr;
            try {
                iArr[d.b.ordinal()] = 1;
            } catch (NoSuchFieldError unused) {
            }
            try {
                c[d.a.ordinal()] = 2;
            } catch (NoSuchFieldError unused2) {
            }
            try {
                c[d.e.ordinal()] = 3;
            } catch (NoSuchFieldError unused3) {
            }
            try {
                c[d.d.ordinal()] = 4;
            } catch (NoSuchFieldError unused4) {
            }
            try {
                c[d.c.ordinal()] = 5;
            } catch (NoSuchFieldError unused5) {
            }
            try {
                c[d.j.ordinal()] = 6;
            } catch (NoSuchFieldError unused6) {
            }
        }
    }

    /* JADX WARN: Failed to restore enum class, 'enum' modifier and super class removed */
    /* JADX WARN: Unknown enum class pattern. Please report as an issue! */
    public static final class d {
        private static final byte[] $$a = null;
        private static final int $$b = 0;
        private static int $10;
        private static int $11;
        public static final d a;
        public static final d b;
        public static final d c;
        public static final d d;
        public static final d e;

        /* JADX INFO: renamed from: g, reason: collision with root package name */
        private static final /* synthetic */ d[] f95952g;
        private static int h;
        private static char[] i;
        public static final d j;
        private static int k;
        private static int l;
        private static boolean m;
        private static boolean n;
        private static int o;
        private static int r;
        final String f;

        /* JADX WARN: Removed duplicated region for block: B:10:0x0021  */
        /* JADX WARN: Removed duplicated region for block: B:8:0x001b  */
        /* JADX WARN: Unsupported multi-entry loop pattern (BACK_EDGE: B:10:0x0021 -> B:11:0x0029). Please report as a decompilation issue!!! */
        /*
            Code decompiled incorrectly, please refer to instructions dump.
            To view partially-correct code enable 'Show inconsistent code' option in preferences
        */
        private static java.lang.String $$c(byte r7, int r8, int r9) {
            /*
                byte[] r0 = com.facetec.sdk.v.d.$$a
                int r9 = r9 + 4
                int r7 = r7 * 3
                int r7 = r7 + 1
                int r8 = r8 + 117
                byte[] r1 = new byte[r7]
                r2 = 0
                if (r0 != 0) goto L13
                r3 = r0
                r4 = r2
                r0 = r9
                goto L29
            L13:
                r3 = r2
            L14:
                int r4 = r3 + 1
                byte r5 = (byte) r8
                r1[r3] = r5
                if (r4 != r7) goto L21
                java.lang.String r7 = new java.lang.String
                r7.<init>(r1, r2)
                return r7
            L21:
                int r9 = r9 + 1
                r3 = r0[r9]
                r6 = r0
                r0 = r9
                r9 = r3
                r3 = r6
            L29:
                int r9 = -r9
                int r8 = r8 + r9
                r9 = r0
                r0 = r3
                r3 = r4
                goto L14
            */
            throw new UnsupportedOperationException("Method not decompiled: com.facetec.sdk.v.d.$$c(byte, int, int):java.lang.String");
        }

        static {
            init$0();
            $10 = 0;
            $11 = 1;
            o = 0;
            r = 1;
            k = 0;
            l = 1;
            d();
            Object[] objArr = new Object[1];
            p(null, Color.blue(0) + 127, null, "\u0082\u0081", objArr);
            b = new d("HASH_SET", 0, ((String) objArr[0]).intern());
            a = new d("SIZE", 1, "s");
            e = new d("SESSION_COUNT", 2, "sc");
            d = new d("INTRA_SESSION_LOOP_DETECTION_LEVEL", 3, "l1");
            c = new d("INTRA_FACETEC_SESSION_LOOP_DETECTION_LEVEL", 4, "l2");
            j = new d("INTER_FACETEC_SESSION_LOOP_DETECTION_LEVEL", 5, "l3");
            f95952g = e();
            r = (o + 57) % 128;
        }

        private d(String str, int i2, String str2) {
            this.f = str2;
        }

        public static void d() {
            i = new char[]{8614, 8639};
            h = 1071522078;
            n = true;
            m = true;
        }

        private static /* synthetic */ d[] e() {
            int i2 = l + 23;
            k = i2 % 128;
            if (i2 % 2 == 0) {
                return new d[]{b, a, e, d, c, j};
            }
            d[] dVarArr = new d[34];
            dVarArr[1] = b;
            dVarArr[0] = a;
            dVarArr[2] = e;
            dVarArr[5] = d;
            dVarArr[3] = c;
            dVarArr[2] = j;
            return dVarArr;
        }

        public static void init$0() {
            $$a = new byte[]{29, -26, 91, ISO7816.INS_REHABILITATE_CHV};
            $$b = 0;
        }

        private static void p(int[] iArr, int i2, String str, String str2, Object[] objArr) throws Throwable {
            long j2;
            float f;
            int i3;
            String str3 = str2;
            Object bytes = str3;
            if (str3 != null) {
                bytes = str3.getBytes(LocalizedMessage.DEFAULT_ENCODING);
            }
            byte[] bArr = (byte[]) bytes;
            char[] charArray = str != null ? str.toCharArray() : str;
            hn hnVar = new hn();
            char[] cArr = i;
            Class cls = Integer.TYPE;
            float f2 = SelfieScan.RECOGNITION_FAIL_RESULT;
            int i4 = 0;
            if (cArr != null) {
                int length = cArr.length;
                char[] cArr2 = new char[length];
                int i5 = 0;
                while (i5 < length) {
                    try {
                        Object[] objArr2 = {Integer.valueOf(cArr[i5])};
                        Object objD = an.d(-814569747);
                        if (objD == null) {
                            int touchSlop = 1803 - (ViewConfiguration.getTouchSlop() >> 8);
                            char c2 = (char) (9692 - (TypedValue.complexToFloat(i4) > f2 ? 1 : (TypedValue.complexToFloat(i4) == f2 ? 0 : -1)));
                            int i6 = (TypedValue.complexToFloat(i4) > f2 ? 1 : (TypedValue.complexToFloat(i4) == f2 ? 0 : -1)) + 24;
                            byte b2 = (byte) $$b;
                            f = f2;
                            byte b3 = (byte) (b2 + 1);
                            i3 = i4;
                            objD = an.d(touchSlop, c2, i6, -1189907018, false, $$c(b2, b3, (byte) (-b3)), new Class[]{cls});
                        } else {
                            f = f2;
                            i3 = i4;
                        }
                        cArr2[i5] = ((Character) ((Method) objD).invoke(null, objArr2)).charValue();
                        i5++;
                        f2 = f;
                        i4 = i3;
                    } catch (Throwable th) {
                        Throwable cause = th.getCause();
                        if (cause == null) {
                            throw th;
                        }
                        throw cause;
                    }
                }
                cArr = cArr2;
            }
            float f3 = f2;
            int i7 = i4;
            Object[] objArr3 = {Integer.valueOf(h)};
            Object objD2 = an.d(-1578986303);
            if (objD2 == null) {
                int mode = View.MeasureSpec.getMode(i7) + 2566;
                char c3 = (char) (1 - (SystemClock.elapsedRealtime() > 0L ? 1 : (SystemClock.elapsedRealtime() == 0L ? 0 : -1)));
                int longPressTimeout = (ViewConfiguration.getLongPressTimeout() >> 16) + 23;
                byte b4 = (byte) $$b;
                byte b5 = b4;
                j2 = 0;
                objD2 = an.d(mode, c3, longPressTimeout, -679262310, false, $$c(b4, b5, (byte) (b5 - 1)), new Class[]{cls});
            } else {
                j2 = 0;
            }
            int iIntValue = ((Integer) ((Method) objD2).invoke(null, objArr3)).intValue();
            if (m) {
                int length2 = bArr.length;
                hnVar.b = length2;
                char[] cArr3 = new char[length2];
                hnVar.c = i7;
                $11 = ($10 + 109) % 128;
                while (true) {
                    int i8 = hnVar.c;
                    int i9 = hnVar.b;
                    if (i8 >= i9) {
                        objArr[0] = new String(cArr3);
                        return;
                    }
                    int i10 = $10 + 31;
                    $11 = i10 % 128;
                    if (i10 % 2 == 0) {
                        cArr3[i8] = (char) (cArr[bArr[i9 - i8] >> i2] % iIntValue);
                        Object[] objArr4 = {hnVar, hnVar};
                        Object objD3 = an.d(717234065);
                        if (objD3 == null) {
                            objD3 = an.d((ViewConfiguration.getWindowTouchSlop() >> 8) + 1970, (char) (1 - (SystemClock.uptimeMillis() > j2 ? 1 : (SystemClock.uptimeMillis() == j2 ? 0 : -1))), ExpandableListView.getPackedPositionChild(j2) + 25, 1554107594, false, "x", new Class[]{Object.class, Object.class});
                        }
                        ((Method) objD3).invoke(null, objArr4);
                    } else {
                        cArr3[i8] = (char) (cArr[bArr[(i9 - 1) - i8] + i2] - iIntValue);
                        Object[] objArr5 = {hnVar, hnVar};
                        Object objD4 = an.d(717234065);
                        if (objD4 == null) {
                            objD4 = an.d(View.MeasureSpec.getMode(0) + 1970, (char) View.MeasureSpec.getMode(0), TextUtils.indexOf("", "", 0, 0) + 24, 1554107594, false, "x", new Class[]{Object.class, Object.class});
                        }
                        ((Method) objD4).invoke(null, objArr5);
                    }
                }
            } else if (n) {
                $10 = ($11 + 119) % 128;
                int length3 = charArray.length;
                hnVar.b = length3;
                char[] cArr4 = new char[length3];
                hnVar.c = 0;
                while (true) {
                    int i11 = hnVar.c;
                    int i12 = hnVar.b;
                    if (i11 >= i12) {
                        objArr[0] = new String(cArr4);
                        return;
                    }
                    int i13 = $11 + 37;
                    $10 = i13 % 128;
                    if (i13 % 2 != 0) {
                        cArr4[i11] = (char) (cArr[charArray[0] >>> i2] * iIntValue);
                        Object[] objArr6 = {hnVar, hnVar};
                        Object objD5 = an.d(717234065);
                        if (objD5 == null) {
                            objD5 = an.d(1971 - (ViewConfiguration.getGlobalActionKeyTimeout() > j2 ? 1 : (ViewConfiguration.getGlobalActionKeyTimeout() == j2 ? 0 : -1)), (char) View.MeasureSpec.makeMeasureSpec(0, 0), 23 - TextUtils.indexOf((CharSequence) "", '0', 0), 1554107594, false, "x", new Class[]{Object.class, Object.class});
                        }
                        ((Method) objD5).invoke(null, objArr6);
                    } else {
                        cArr4[i11] = (char) (cArr[charArray[(i12 - 1) - i11] - i2] - iIntValue);
                        Object[] objArr7 = {hnVar, hnVar};
                        Object objD6 = an.d(717234065);
                        if (objD6 == null) {
                            objD6 = an.d(1970 - Color.blue(0), (char) TextUtils.indexOf("", "", 0, 0), 25 - (AudioTrack.getMaxVolume() > f3 ? 1 : (AudioTrack.getMaxVolume() == f3 ? 0 : -1)), 1554107594, false, "x", new Class[]{Object.class, Object.class});
                        }
                        ((Method) objD6).invoke(null, objArr7);
                    }
                }
            } else {
                int length4 = iArr.length;
                hnVar.b = length4;
                char[] cArr5 = new char[length4];
                hnVar.c = 0;
                while (true) {
                    int i14 = hnVar.c;
                    int i15 = hnVar.b;
                    if (i14 >= i15) {
                        objArr[0] = new String(cArr5);
                        return;
                    }
                    int i16 = $11 + 117;
                    $10 = i16 % 128;
                    if (i16 % 2 != 0) {
                        cArr5[i14] = (char) (cArr[iArr[0] * i2] >> iIntValue);
                    } else {
                        cArr5[i14] = (char) (cArr[iArr[(i15 - 1) - i14] - i2] - iIntValue);
                        i14++;
                    }
                    hnVar.c = i14;
                }
            }
        }

        public static d valueOf(String str) {
            k = (l + 91) % 128;
            d dVar = (d) Enum.valueOf(d.class, str);
            k = (l + 13) % 128;
            return dVar;
        }

        public static d[] values() {
            int i2 = k + 91;
            l = i2 % 128;
            if (i2 % 2 != 0) {
                return (d[]) f95952g.clone();
            }
            int i3 = 12 / 0;
            return (d[]) f95952g.clone();
        }
    }

    public v() {
        y yVar = y.NOT_RAN;
        this.a = yVar;
        this.d = yVar;
        this.f95951g = yVar;
    }

    public static v a(String str) {
        v vVar = new v();
        try {
            JSONObject jSONObject = new JSONObject(str);
            JSONArray jSONArray = jSONObject.getJSONArray(d.b.f);
            ArrayList arrayList = new ArrayList();
            for (int i = 0; i < jSONArray.length(); i++) {
                JSONArray jSONArray2 = jSONArray.getJSONArray(i);
                ArrayList arrayList2 = new ArrayList();
                for (int i2 = 0; i2 < jSONArray2.length(); i2++) {
                    arrayList2.add(Integer.valueOf(jSONArray2.getInt(i2)));
                }
                arrayList.add(arrayList2);
            }
            for (d dVar : d.values()) {
                switch (AnonymousClass4.c[dVar.ordinal()]) {
                    case 1:
                        vVar.b = arrayList;
                        break;
                    case 2:
                        vVar.e = jSONObject.getInt(dVar.f);
                        break;
                    case 3:
                        vVar.c = jSONObject.getInt(dVar.f);
                        break;
                    case 4:
                        vVar.a = y.b(jSONObject.getInt(dVar.f));
                        break;
                    case 5:
                        vVar.d = y.b(jSONObject.getInt(dVar.f));
                        break;
                    case 6:
                        vVar.f95951g = y.b(jSONObject.getInt(dVar.f));
                        break;
                }
            }
        } catch (Exception unused) {
        }
        return vVar;
    }

    public final JSONObject d() {
        JSONObject jSONObject = new JSONObject();
        try {
            for (d dVar : d.values()) {
                switch (AnonymousClass4.c[dVar.ordinal()]) {
                    case 1:
                        jSONObject.put(dVar.f, new JSONArray((Collection) this.b));
                        break;
                    case 2:
                        jSONObject.put(dVar.f, this.e);
                        break;
                    case 3:
                        jSONObject.put(dVar.f, this.c);
                        break;
                    case 4:
                        jSONObject.put(dVar.f, this.a.a);
                        break;
                    case 5:
                        jSONObject.put(dVar.f, this.d.a);
                        break;
                    case 6:
                        jSONObject.put(dVar.f, this.f95951g.a);
                        break;
                }
            }
        } catch (JSONException unused) {
        }
        return jSONObject;
    }

    public static int a() {
        int i = j;
        int i2 = i % 5822475;
        j = i + 1;
        if (i2 != 0) {
            return h;
        }
        int iMaxMemory = (int) Runtime.getRuntime().maxMemory();
        h = iMaxMemory;
        return iMaxMemory;
    }
}