package com.facetec.sdk;

import android.graphics.Color;
import android.graphics.ImageFormat;
import android.media.AudioTrack;
import android.os.Process;
import android.os.SystemClock;
import android.text.AndroidCharacter;
import android.text.TextUtils;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.View;
import android.view.ViewConfiguration;
import android.widget.ExpandableListView;
import com.incode.welcome_sdk.modules.SelfieScan;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.List;
import org.jmrtd.PassportService;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

/* JADX INFO: loaded from: classes4.dex */
final class w {
    private static final byte[] $$a = null;
    private static final int $$b = 0;
    private static int $10;
    private static int $11;
    private static char o;
    private static char p;
    private static char q;
    private static char r;
    private static char s;
    private static char[] t;
    private static int u;
    private static int y;
    y h;
    y i;
    y j;
    private y k;
    private x l;
    private y m;
    List<ai> a = new ArrayList();
    List<String> d = new ArrayList();
    List<List<Integer>> e = new ArrayList();

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    private List<List<ai>> f95953g = new ArrayList();
    private List<List<ai>> n = new ArrayList();
    List<List<List<ai>>> c = new ArrayList();
    List<List<List<ai>>> b = new ArrayList();
    List<List<List<ai>>> f = new ArrayList();

    /* JADX WARN: Removed duplicated region for block: B:10:0x0024  */
    /* JADX WARN: Removed duplicated region for block: B:8:0x001e  */
    /* JADX WARN: Unsupported multi-entry loop pattern (BACK_EDGE: B:10:0x0024 -> B:11:0x002d). Please report as a decompilation issue!!! */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    private static java.lang.String $$c(short r6, byte r7, int r8) {
        /*
            byte[] r0 = com.facetec.sdk.w.$$a
            int r7 = r7 * 4
            int r1 = r7 + 1
            int r6 = r6 + 4
            int r8 = 116 - r8
            byte[] r1 = new byte[r1]
            r2 = 0
            if (r0 != 0) goto L13
            r3 = r0
            r4 = r2
            r0 = r6
            goto L2d
        L13:
            r3 = r8
            r8 = r6
            r6 = r3
            r3 = r2
        L17:
            byte r4 = (byte) r6
            int r8 = r8 + 1
            r1[r3] = r4
            if (r3 != r7) goto L24
            java.lang.String r6 = new java.lang.String
            r6.<init>(r1, r2)
            return r6
        L24:
            int r3 = r3 + 1
            r4 = r0[r8]
            r5 = r0
            r0 = r8
            r8 = r4
            r4 = r3
            r3 = r5
        L2d:
            int r6 = r6 + r8
            r8 = r0
            r0 = r3
            r3 = r4
            goto L17
        */
        throw new UnsupportedOperationException("Method not decompiled: com.facetec.sdk.w.$$c(short, byte, int):java.lang.String");
    }

    static {
        init$0();
        $10 = 0;
        $11 = 1;
        y = 0;
        u = 1;
        o = (char) 34889;
        s = (char) 13353;
        p = (char) 19946;
        r = (char) 47265;
        t = new char[]{3871, 15079, 3865, 3864, 15085, 15077, 15080, 3870, 15027, 15026, 3866, 15074, 3869, 15072, 15024, 15095};
        q = (char) 3871;
    }

    public w() {
        y yVar = y.NOT_RAN;
        this.m = yVar;
        this.k = yVar;
        this.i = yVar;
        this.j = yVar;
        this.h = yVar;
        this.l = new x();
    }

    public static void init$0() {
        $$a = new byte[]{120, PassportService.SFI_DG11, 65, 93};
        $$b = 83;
    }

    /* JADX WARN: Removed duplicated region for block: B:8:0x0017  */
    /* JADX WARN: Removed duplicated region for block: B:9:0x001c  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    private static void v(java.lang.String r29, int r30, java.lang.Object[] r31) throws java.lang.Throwable {
        /*
            Method dump skipped, instruction units count: 438
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: com.facetec.sdk.w.v(java.lang.String, int, java.lang.Object[]):void");
    }

    private static void w(int i, String str, byte b, Object[] objArr) throws Throwable {
        int i2;
        int i3;
        char c;
        char c2;
        char c3;
        char c4;
        char c5;
        long j;
        char[] charArray = str != null ? str.toCharArray() : str;
        ho hoVar = new ho();
        char[] cArr = t;
        Class cls = Integer.TYPE;
        char c6 = '0';
        long j2 = 0;
        int i4 = 0;
        if (cArr != null) {
            $11 = ($10 + 63) % 128;
            int length = cArr.length;
            char[] cArr2 = new char[length];
            int i5 = 0;
            while (i5 < length) {
                try {
                    Object[] objArr2 = {Integer.valueOf(cArr[i5])};
                    Object objD = an.d(-1584280535);
                    if (objD == null) {
                        int i6 = 2158 - (ExpandableListView.getPackedPositionForGroup(i4) > j2 ? 1 : (ExpandableListView.getPackedPositionForGroup(i4) == j2 ? 0 : -1));
                        j = j2;
                        char scrollBarSize = (char) (ViewConfiguration.getScrollBarSize() >> 8);
                        int mirror = AndroidCharacter.getMirror(c6) - 25;
                        byte b2 = (byte) (-1);
                        c5 = c6;
                        byte b3 = (byte) (b2 + 1);
                        objD = an.d(i6, scrollBarSize, mirror, -672129166, false, $$c(b2, b3, b3), new Class[]{cls});
                    } else {
                        c5 = c6;
                        j = j2;
                    }
                    cArr2[i5] = ((Character) ((Method) objD).invoke(null, objArr2)).charValue();
                    i5++;
                    c6 = c5;
                    j2 = j;
                    i4 = 0;
                } catch (Throwable th) {
                    Throwable cause = th.getCause();
                    if (cause == null) {
                        throw th;
                    }
                    throw cause;
                }
            }
            cArr = cArr2;
        }
        char c7 = c6;
        long j3 = j2;
        Object[] objArr3 = {Integer.valueOf(q)};
        Object objD2 = an.d(-1584280535);
        if (objD2 == null) {
            byte b4 = (byte) (-1);
            byte b5 = (byte) (b4 + 1);
            objD2 = an.d(AndroidCharacter.getMirror(c7) + 2110, (char) (ViewConfiguration.getPressedStateDuration() >> 16), (ViewConfiguration.getScrollBarFadeDuration() >> 16) + 23, -672129166, false, $$c(b4, b5, b5), new Class[]{cls});
        }
        char cCharValue = ((Character) ((Method) objD2).invoke(null, objArr3)).charValue();
        char[] cArr3 = new char[i];
        if (i % 2 != 0) {
            i2 = i - 1;
            cArr3[i2] = (char) (charArray[i2] - b);
        } else {
            i2 = i;
        }
        int i7 = 2;
        char c8 = 1;
        if (i2 > 1) {
            hoVar.b = 0;
            while (true) {
                int i8 = hoVar.b;
                if (i8 >= i2) {
                    break;
                }
                char c9 = charArray[i8];
                hoVar.d = c9;
                char c10 = charArray[i8 + 1];
                hoVar.e = c10;
                if (c9 == c10) {
                    int i9 = $10 + 57;
                    $11 = i9 % 128;
                    if (i9 % i7 == 0) {
                        cArr3[i8] = (char) (c9 + b);
                        cArr3[i8 % 0] = (char) (c10 << b);
                    } else {
                        cArr3[i8] = (char) (c9 - b);
                        cArr3[i8 + 1] = (char) (c10 - b);
                    }
                    i3 = i7;
                    c = c8;
                } else {
                    Object[] objArr4 = new Object[13];
                    objArr4[12] = hoVar;
                    objArr4[11] = Integer.valueOf(cCharValue);
                    objArr4[10] = hoVar;
                    objArr4[9] = hoVar;
                    objArr4[8] = Integer.valueOf(cCharValue);
                    objArr4[7] = hoVar;
                    objArr4[6] = hoVar;
                    objArr4[5] = Integer.valueOf(cCharValue);
                    objArr4[4] = hoVar;
                    objArr4[3] = hoVar;
                    objArr4[i7] = Integer.valueOf(cCharValue);
                    objArr4[c8] = hoVar;
                    i3 = i7;
                    objArr4[0] = hoVar;
                    Object objD3 = an.d(945118461);
                    if (objD3 == null) {
                        c = c8;
                        int bitsPerPixel = 2355 - ImageFormat.getBitsPerPixel(0);
                        c2 = '\n';
                        char absoluteGravity = (char) Gravity.getAbsoluteGravity(0, 0);
                        c3 = '\t';
                        int iIndexOf = TextUtils.indexOf("", c7) + 24;
                        byte b6 = (byte) (-1);
                        byte b7 = (byte) (b6 + 1);
                        c4 = 7;
                        String str$$c = $$c(b6, b7, (byte) (b7 + 2));
                        Class cls2 = Integer.TYPE;
                        objD3 = an.d(bitsPerPixel, absoluteGravity, iIndexOf, 1312067494, false, str$$c, new Class[]{Object.class, Object.class, cls2, Object.class, Object.class, cls2, Object.class, Object.class, cls2, Object.class, Object.class, cls2, Object.class});
                    } else {
                        c = c8;
                        c2 = '\n';
                        c3 = '\t';
                        c4 = 7;
                    }
                    int iIntValue = ((Integer) ((Method) objD3).invoke(null, objArr4)).intValue();
                    int i10 = hoVar.f95903g;
                    if (iIntValue == i10) {
                        Object[] objArr5 = new Object[11];
                        objArr5[c2] = hoVar;
                        objArr5[c3] = Integer.valueOf(cCharValue);
                        objArr5[8] = hoVar;
                        objArr5[c4] = Integer.valueOf(cCharValue);
                        objArr5[6] = Integer.valueOf(cCharValue);
                        objArr5[5] = hoVar;
                        objArr5[4] = hoVar;
                        objArr5[3] = Integer.valueOf(cCharValue);
                        objArr5[i3] = Integer.valueOf(cCharValue);
                        objArr5[c] = hoVar;
                        objArr5[0] = hoVar;
                        Object objD4 = an.d(-1909092408);
                        if (objD4 == null) {
                            int packedPositionType = 877 - ExpandableListView.getPackedPositionType(j3);
                            char cRgb = (char) ((-16777216) - Color.rgb(0, 0, 0));
                            int i11 = 24 - (ExpandableListView.getPackedPositionForGroup(0) > j3 ? 1 : (ExpandableListView.getPackedPositionForGroup(0) == j3 ? 0 : -1));
                            byte b8 = (byte) (-1);
                            byte b9 = (byte) (b8 + 1);
                            String str$$c2 = $$c(b8, b9, (byte) (b9 + 3));
                            Class cls3 = Integer.TYPE;
                            objD4 = an.d(packedPositionType, cRgb, i11, -128689005, false, str$$c2, new Class[]{Object.class, Object.class, cls3, cls3, Object.class, Object.class, cls3, cls3, Object.class, cls3, Object.class});
                        }
                        int iIntValue2 = ((Integer) ((Method) objD4).invoke(null, objArr5)).intValue();
                        int i12 = (hoVar.a * cCharValue) + hoVar.f95903g;
                        int i13 = hoVar.b;
                        cArr3[i13] = cArr[iIntValue2];
                        cArr3[i13 + 1] = cArr[i12];
                    } else {
                        int i14 = hoVar.c;
                        int i15 = hoVar.a;
                        if (i14 == i15) {
                            int i16 = ((hoVar.j + cCharValue) - 1) % cCharValue;
                            hoVar.j = i16;
                            int i17 = ((i10 + cCharValue) - 1) % cCharValue;
                            hoVar.f95903g = i17;
                            int i18 = (i15 * cCharValue) + i17;
                            int i19 = hoVar.b;
                            cArr3[i19] = cArr[(i14 * cCharValue) + i16];
                            cArr3[i19 + 1] = cArr[i18];
                        } else {
                            int i20 = (i14 * cCharValue) + i10;
                            int i21 = (i15 * cCharValue) + hoVar.j;
                            int i22 = hoVar.b;
                            cArr3[i22] = cArr[i20];
                            cArr3[i22 + 1] = cArr[i21];
                        }
                    }
                }
                hoVar.b += 2;
                i7 = i3;
                c8 = c;
                c7 = '0';
            }
        }
        int i23 = 0;
        while (i23 < i) {
            int i24 = $10;
            int i25 = i24 + 79;
            $11 = i25 % 128;
            if (i25 % 2 == 0) {
                cArr3[i23] = (char) (cArr3[i23] ^ 31660);
                i23 += 87;
            } else {
                cArr3[i23] = (char) (cArr3[i23] ^ 13722);
                i23++;
            }
            $11 = (i24 + 3) % 128;
        }
        objArr[0] = new String(cArr3);
    }

    public final JSONObject b() throws Throwable {
        List<ai> list = this.a;
        JSONArray jSONArray = new JSONArray();
        int i = 0;
        while (i < list.size()) {
            int i2 = u + 13;
            y = i2 % 128;
            if (i2 % 2 != 0) {
                jSONArray.put(list.get(i).d());
                i += 33;
            } else {
                jSONArray.put(list.get(i).d());
                i++;
            }
            u = (y + 97) % 128;
        }
        JSONArray jSONArrayE = af.e(this.f95953g);
        JSONArray jSONArrayE2 = af.e(this.n);
        JSONArray jSONArrayD = af.d(this.c);
        JSONArray jSONArrayD2 = af.d(this.b);
        JSONArray jSONArrayD3 = af.d(this.f);
        JSONObject jSONObject = new JSONObject();
        try {
            Object[] objArr = new Object[1];
            v("麻蒂乪\ufdef", (ViewConfiguration.getMinimumFlingVelocity() >> 16) + 3, objArr);
            jSONObject.put(((String) objArr[0]).intern(), jSONArray.toString());
            Object[] objArr2 = new Object[1];
            v("삏랮乪\ufdef", 3 - (AudioTrack.getMinVolume() > SelfieScan.RECOGNITION_FAIL_RESULT ? 1 : (AudioTrack.getMinVolume() == SelfieScan.RECOGNITION_FAIL_RESULT ? 0 : -1)), objArr2);
            jSONObject.put(((String) objArr2[0]).intern(), this.d.toString());
            Object[] objArr3 = new Object[1];
            v("⢿\ud8ca", View.getDefaultSize(0, 0) + 2, objArr3);
            jSONObject.put(((String) objArr3[0]).intern(), this.e.toString());
            Object[] objArr4 = new Object[1];
            v("Ǘ歁춆Х乪\ufdef", 5 - (ViewConfiguration.getScrollBarFadeDuration() >> 16), objArr4);
            jSONObject.put(((String) objArr4[0]).intern(), jSONArrayE.toString());
            Object[] objArr5 = new Object[1];
            v("ᔆ䱬춆Х乪\ufdef", 4 - TextUtils.lastIndexOf("", '0', 0, 0), objArr5);
            jSONObject.put(((String) objArr5[0]).intern(), jSONArrayE2.toString());
            Object[] objArr6 = new Object[1];
            w((Process.myTid() >> 22) + 5, "\u0007\f\u0005\u000e㖳", (byte) (8 - Color.green(0)), objArr6);
            jSONObject.put(((String) objArr6[0]).intern(), jSONArrayD.toString());
            Object[] objArr7 = new Object[1];
            v("磍茅鈱\uf7a5㿐괄", (SystemClock.currentThreadTimeMillis() > (-1L) ? 1 : (SystemClock.currentThreadTimeMillis() == (-1L) ? 0 : -1)) + 4, objArr7);
            jSONObject.put(((String) objArr7[0]).intern(), jSONArrayD2.toString());
            Object[] objArr8 = new Object[1];
            w(5 - TextUtils.indexOf("", "", 0), "\u0007\f\u0005\u000e㗣", (byte) ((ViewConfiguration.getTapTimeout() >> 16) + 58), objArr8);
            jSONObject.put(((String) objArr8[0]).intern(), jSONArrayD3.toString());
            Object[] objArr9 = new Object[1];
            w((ViewConfiguration.getLongPressTimeout() >> 16) + 5, "\u0007\u0006\u0005\t㘿", (byte) ((ViewConfiguration.getZoomControlsTimeout() > 0L ? 1 : (ViewConfiguration.getZoomControlsTimeout() == 0L ? 0 : -1)) + 72), objArr9);
            jSONObject.put(((String) objArr9[0]).intern(), String.valueOf(this.m.a));
            Object[] objArr10 = new Object[1];
            w((AudioTrack.getMinVolume() > SelfieScan.RECOGNITION_FAIL_RESULT ? 1 : (AudioTrack.getMinVolume() == SelfieScan.RECOGNITION_FAIL_RESULT ? 0 : -1)) + 5, "\t\u0007\u0005\t㙁", (byte) (View.MeasureSpec.makeMeasureSpec(0, 0) + 75), objArr10);
            jSONObject.put(((String) objArr10[0]).intern(), String.valueOf(this.k.a));
            Object[] objArr11 = new Object[1];
            v("磍茅ᮭ\ud9a3숯\uf023", TextUtils.indexOf("", "", 0, 0) + 5, objArr11);
            jSONObject.put(((String) objArr11[0]).intern(), String.valueOf(this.i.a));
            Object[] objArr12 = new Object[1];
            w(5 - ExpandableListView.getPackedPositionGroup(0L), "\u0007\f\u0006\u0005㗺", (byte) (83 - (SystemClock.elapsedRealtime() > 0L ? 1 : (SystemClock.elapsedRealtime() == 0L ? 0 : -1))), objArr12);
            jSONObject.put(((String) objArr12[0]).intern(), String.valueOf(this.j.a));
            Object[] objArr13 = new Object[1];
            w((ViewConfiguration.getMaximumFlingVelocity() >> 16) + 5, "\u0007\f\u0006\u0005㗚", (byte) ((ViewConfiguration.getScrollDefaultDelay() >> 16) + 49), objArr13);
            jSONObject.put(((String) objArr13[0]).intern(), String.valueOf(this.h.a));
            Object[] objArr14 = new Object[1];
            v("㞗㈿㏐⽎퍪\uf034", (TypedValue.complexToFraction(0, SelfieScan.RECOGNITION_FAIL_RESULT, SelfieScan.RECOGNITION_FAIL_RESULT) > SelfieScan.RECOGNITION_FAIL_RESULT ? 1 : (TypedValue.complexToFraction(0, SelfieScan.RECOGNITION_FAIL_RESULT, SelfieScan.RECOGNITION_FAIL_RESULT) == SelfieScan.RECOGNITION_FAIL_RESULT ? 0 : -1)) + 5, objArr14);
            jSONObject.put(((String) objArr14[0]).intern(), new JSONObject().toString());
        } catch (JSONException unused) {
        }
        return jSONObject;
    }
}