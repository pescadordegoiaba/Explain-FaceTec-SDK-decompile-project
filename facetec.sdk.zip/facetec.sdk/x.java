package com.facetec.sdk;

/* JADX INFO: loaded from: classes4.dex */
final class x {
}