package com.facetec.sdk;

/* JADX INFO: loaded from: classes4.dex */
enum y {
    NOT_RAN(0),
    NOT_DETECTED(1),
    DETECTED(2);

    final int a;

    y(int i) {
        this.a = i;
    }

    public static y b(int i) {
        for (y yVar : values()) {
            if (yVar.a == i) {
                return yVar;
            }
        }
        throw new IllegalArgumentException();
    }
}