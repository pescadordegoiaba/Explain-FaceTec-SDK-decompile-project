package com.facetec.sdk;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/* JADX INFO: loaded from: classes4.dex */
final class z {
    w a = new w();
    ad e = new ad();
    boolean d = false;
    boolean c = false;
    boolean b = false;

    private static boolean c(List<Integer> list) {
        return list.size() >= 3 && af.i(list);
    }

    /* JADX WARN: Multi-variable type inference failed */
    public final boolean a(List<List<Integer>> list, int i, u uVar) {
        int iMax;
        int i2;
        List list2;
        int i3;
        List<Integer> list3;
        int i4;
        List<Integer> list4;
        ai aiVar;
        int iIntValue;
        List<List<Integer>> list5 = list;
        int i5 = i;
        int i6 = 0;
        if (list5.size() <= i5) {
            return false;
        }
        List listAsList = Arrays.asList(af.c(af.j(list5.subList(0, i5))));
        int i7 = i5;
        int i8 = 0;
        while (true) {
            int i9 = 1;
            if (i7 >= list5.size()) {
                boolean z = i6;
                if (i8 > 0) {
                    return true;
                }
                return z;
            }
            List<Integer> list6 = list5.get(i7);
            int i10 = i6;
            while (true) {
                if (i10 >= list6.size()) {
                    iMax = i6;
                    i2 = iMax;
                    break;
                }
                if (listAsList.contains(list6.get(i10))) {
                    iMax = Math.max(i6, i10 - 4);
                    i2 = 1;
                    break;
                }
                i10 += 3;
            }
            if (uVar == u.INTRA_SESSION || i2 != 0) {
                while (iMax < list6.size()) {
                    ArrayList arrayList = new ArrayList();
                    int i11 = i6;
                    while (true) {
                        int i12 = iMax + i11;
                        if (i12 >= list6.size()) {
                            break;
                        }
                        int iIntValue2 = list6.get(i12).intValue();
                        arrayList.add(Integer.valueOf(iIntValue2));
                        if (c(arrayList)) {
                            break;
                        }
                        if (iIntValue2 == ((Integer) arrayList.get(arrayList.size() - i9)).intValue()) {
                            while (true) {
                                i12++;
                                if (i12 >= list6.size() || iIntValue2 != (iIntValue = list6.get(i12).intValue())) {
                                    break;
                                }
                                arrayList.add(Integer.valueOf(iIntValue));
                                i11++;
                            }
                        }
                        i11 += i9;
                    }
                    if (c(arrayList)) {
                        int i13 = i6;
                        while (i13 < list5.size() && (uVar == u.INTRA_SESSION || i13 < i5)) {
                            List<Integer> list7 = list5.get(i13);
                            int i14 = i6;
                            while (i14 < list7.size() - arrayList.size()) {
                                ArrayList arrayList2 = new ArrayList();
                                int i15 = i6;
                                boolean z2 = i9 == true ? 1 : 0;
                                while (i6 < arrayList.size()) {
                                    int iIntValue3 = list7.get(i14 + i6).intValue();
                                    int i16 = iIntValue3 == ((Integer) arrayList.get(i6)).intValue() ? z2 ? 1 : 0 : i15;
                                    int i17 = (i14 == iMax && i13 == i7) ? z2 ? 1 : 0 : i15;
                                    if (i16 == 0 || i17 != 0) {
                                        break;
                                    }
                                    arrayList2.add(Integer.valueOf(iIntValue3));
                                    if (arrayList2.size() == arrayList.size()) {
                                        i8++;
                                        ArrayList arrayList3 = new ArrayList();
                                        ArrayList arrayList4 = new ArrayList();
                                        list2 = listAsList;
                                        if (uVar == u.INTER_FACETEC_SESSION) {
                                            int i18 = i15;
                                            while (i18 < arrayList.size()) {
                                                int i19 = iMax + i18;
                                                int i20 = i18;
                                                int i21 = i15;
                                                int i22 = i21;
                                                while (true) {
                                                    if (i21 >= this.e.d.size()) {
                                                        i4 = i6;
                                                        list4 = list6;
                                                        aiVar = new ai();
                                                        break;
                                                    }
                                                    w wVar = this.e.d.get(i21);
                                                    int i23 = i21;
                                                    list4 = list6;
                                                    int size = i15;
                                                    int i24 = i22;
                                                    i4 = i6;
                                                    int i25 = size;
                                                    while (i25 < wVar.e.size()) {
                                                        List<Integer> list8 = wVar.e.get(i25);
                                                        int i26 = i25;
                                                        int i27 = i19 + size;
                                                        int i28 = i24;
                                                        if (i24 == i7 && i27 < wVar.a.size()) {
                                                            aiVar = wVar.a.get(i27);
                                                            break;
                                                        }
                                                        i24 = i28 + 1;
                                                        size += list8.size();
                                                        i25 = i26 + 1;
                                                    }
                                                    int i29 = i24;
                                                    i21 = i23 + 1;
                                                    i6 = i4;
                                                    list6 = list4;
                                                    i22 = i29;
                                                }
                                                arrayList3.add(aiVar);
                                                i18 = i20 + 1;
                                                i6 = i4;
                                                list6 = list4;
                                            }
                                            i3 = i6;
                                            list3 = list6;
                                            for (int i30 = i15; i30 < arrayList2.size(); i30++) {
                                                arrayList4.add(a(i13, i14 + i30));
                                            }
                                            List<List<List<ai>>> list9 = this.a.f;
                                            List[] listArr = new List[2];
                                            listArr[i15] = arrayList3;
                                            listArr[z2 ? 1 : 0] = arrayList4;
                                            list9.add(new ArrayList(Arrays.asList(listArr)));
                                        } else {
                                            i3 = i6;
                                            list3 = list6;
                                            int i31 = uVar != u.INTRA_SESSION ? i15 : this.e.a;
                                            for (int i32 = i15; i32 < arrayList.size(); i32++) {
                                                arrayList3.add(a(i31 + i7, iMax + i32));
                                            }
                                            for (int i33 = i15; i33 < arrayList2.size(); i33++) {
                                                arrayList4.add(a(i31 + i13, i14 + i33));
                                            }
                                            if (uVar == u.INTRA_SESSION) {
                                                List<List<List<ai>>> list10 = this.a.c;
                                                List[] listArr2 = new List[2];
                                                listArr2[i15] = arrayList3;
                                                listArr2[z2 ? 1 : 0] = arrayList4;
                                                list10.add(new ArrayList(Arrays.asList(listArr2)));
                                            } else {
                                                List<List<List<ai>>> list11 = this.a.b;
                                                List[] listArr3 = new List[2];
                                                listArr3[i15] = arrayList3;
                                                listArr3[z2 ? 1 : 0] = arrayList4;
                                                list11.add(new ArrayList(Arrays.asList(listArr3)));
                                            }
                                        }
                                        if (i8 == 5) {
                                            return z2;
                                        }
                                    } else {
                                        list2 = listAsList;
                                        i3 = i6;
                                        list3 = list6;
                                    }
                                    i6 = i3 + 1;
                                    listAsList = list2;
                                    list6 = list3;
                                }
                                i14++;
                                i6 = i15;
                                i9 = z2 ? 1 : 0;
                                listAsList = listAsList;
                                list6 = list6;
                            }
                            byte b = i9 == true ? 1 : 0;
                            i13++;
                            list5 = list;
                            i5 = i;
                        }
                    }
                    iMax++;
                    list5 = list;
                    i5 = i;
                    i6 = i6;
                    i9 = i9 == true ? 1 : 0;
                    listAsList = listAsList;
                    list6 = list6;
                }
            }
            i7++;
            list5 = list;
            i5 = i;
            i6 = i6;
            listAsList = listAsList;
        }
    }

    private ai a(int i, int i2) {
        int i3 = 0;
        for (int i4 = 0; i4 < this.e.e.size(); i4++) {
            w wVar = this.e.e.get(i4);
            int size = 0;
            for (int i5 = 0; i5 < wVar.e.size(); i5++) {
                List<Integer> list = wVar.e.get(i5);
                int i6 = i2 + size;
                if (i3 == i && i6 < wVar.a.size()) {
                    return wVar.a.get(i6);
                }
                i3++;
                size += list.size();
            }
        }
        return new ai();
    }
}